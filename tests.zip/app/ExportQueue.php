<?php

namespace App;
use Maatwebsite\Excel\Concerns\FromArray;
use App\Models\Active_Accounts_Mapping;
use Auth;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;

class ExportQueue implements FromArray, WithHeadings, ShouldAutoSize, WithEvents
{
    protected $invoices;

    public function __construct(array $invoices)
    {
        $this->invoices = $invoices;
    }

    public function array(): array
    {
        return $this->invoices;
    }
    public function headings(): array
    {
        
        return ['ID','ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
        'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
        'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR', 
        'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE', 
        'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER', 'ACCESS_RULES'];
    }
    public function registerEvents(): array
{

    
    return [
        AfterSheet::class    => function(AfterSheet $event) {
            $styleArray = [
                'font' => [
                    'bold' => true,
                ],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
                'borders' => [
                    'top' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => [
                        'argb' => 'FFA0A0A0',
                    ]
                ],
            ];
            $styleArray2 = [
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
                'borders' => [
                    'outline' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ]
            ];
            $highestRow = $event->sheet->getDelegate()->getHighestRow();
            $cellRange = 'A1:AU1'; 
            //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);
            $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
            $cellRange = 'A2:AU'.$highestRow;
            $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);



            $cellRange = 'F2:AU'.$highestRow;
            // Set first row to height 20
            $event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

        },
    ];
}
}