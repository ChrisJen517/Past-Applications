<?php

namespace App;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Config;
use PHPMailer\PHPMailer\PHPMailer;

class RNNMailer extends PHPMailer
{
    /**
     * RNNMailer constructor.
     *
     * @param bool|null $exceptions
     */
    public function __construct($exceptions = null, $user = null)
    {
        parent::__construct($exceptions);
        $this->isSMTP();
        $this->Timeout = 30;
        $this->Host = Config::get('app.mail_host');
        $this->SMTPAuth = true;
        $this->Username = Config::get('app.mail_username');
        $this->Password = Config::get('app.mail_password');
        $this->SMTPSecure = 'tls';
        $this->Port = Config::get('app.mail_port');
        $this->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true,
            ),
        );

        $this->findSenderInformation($user);
        // parent::addReplyTo('michaelc@rnngroup.com', 'Michael Chestney');
        $this->isHTML(true);
    }

    public function findSenderInformation($user = null) {
        // * Set the default sender for the entire application
        $this->setFrom('response@rnngroup.com', 'Apollo');

        if (empty($user))
            $user = Auth::user();

        /*
        * Sent by a job or unauthenticated route
        * or if their role does not have a corporation attached to it
        ! In the future, I'd like to get rockyskiptracing.com added to the sendgrid so that we can use that domain for things like:
        ! Sending a password reset email from an admin account and emails sent from roles without corporations.
        */
        if (empty($user) || in_array($user->role, ['powerlead', 'directory_agent', 'admin', 'powerlead_directory_manager']))
            return;

        $role = $user->role;
        switch ($role) {
            case 'agent':
                $roleLink = $user->agent_link;
                break;
            case 'manager':
                $roleLink = $user->manager_link;
                break;
            case 'corporate_admin':
                $roleLink = $user->corporate_admin_link;
                break;
            default:
                return;
        }

        $corporation_id = $roleLink->corporation_id;
        $corporate_settings = Corporate_Settings::select('sender_email_address', 'sender_email_name')->where('corporation_id', $corporation_id)->first();

        // * Should never happen but just to avoid erroring out
        if (empty($corporate_settings))
            return;

        $emailAddress = $corporate_settings->sender_email_address;
        $emailName = $corporate_settings->sender_email_name;
        $this->setFrom($emailAddress, $emailName);
    }

    public function addAddress($address, $name = '')
    {
        $env = Config::get('app.env');
        if ($env == 'prod')
            parent::addAddress($address, $name);
        else{
            parent::addAddress('nkrausemc@gmail.com', 'Noah Krause');
            parent::addAddress('masterco43@gmail.com', 'Michael Chestney');
        }
    }

    public function addReplyTo($address, $name = '')
    {
        $env = Config::get('app.env');
        if ($env == 'prod')
            parent::addReplyTo($address, $name);
        else{
            parent::addAddress('nkrausemc@gmail.com', 'Noah Krause');
            parent::addAddress('masterco43@gmail.com', 'Michael Chestney');
        }
    }

    public function addAddresses($addresses) {
        if (!is_array($addresses)) {
            $this->addAddress($addresses);
            return;
        }

        $env = Config::get('app.env');
        if ($env == 'prod') {
            foreach($addresses as $address) {
                $this->addAddress($address);
            }
        } else {
            parent::addAddress('nkrausemc@gmail.com', 'Noah Krause');
            parent::addAddress('masterco43@gmail.com', 'Michael Chestney');
        }
    }
}
