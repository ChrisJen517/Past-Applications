<?php

namespace App;
use Maatwebsite\Excel\Concerns\FromArray;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;

class ExportVerifications implements FromArray, WithHeadings, ShouldAutoSize, WithEvents
{
    protected $invoices;

    public function __construct($input)
    {
        foreach ($input as $entry) {
           $this->invoices[$entry['agent_id']] = [
                $entry['coe'],
                $entry['agent_id'],
                $entry['agent_name'],
                $entry['accounts_worked_count'],
                $entry['verified_hits_count'],
                $entry['calls_count'],
                $entry['verified_hits_per_hour'],
                $entry['hitsBefore8'],
                $entry['hits8'],
                $entry['hits9'],
                $entry['hits10'],
                $entry['hits11'],
                $entry['hits12'],
                $entry['hits13'],
                $entry['hits14'],
                $entry['hits15'],
                $entry['hits16'],
                $entry['hits17'],
                $entry['hits18']
            ];
        }
    }

    public function array(): array
    {
        return $this->invoices;
    }
    public function headings(): array
    {
        return ['COE', 'Agent_ID', 'Agent', 'Total Accounts Worked', 'Total Verifications', 'Total Calls', 'Average Verifications Per Hour', 'PRE 8AM', '8AM - 9AM', '9AM - 10AM', '10AM - 11AM', '11AM - 12PM',
        '12PM - 1PM', '1PM - 2PM', '2PM - 3PM', '3PM - 4PM', '4PM - 5PM', '5PM - 6PM', '6PM - 7PM'
        ];
    }
    public function registerEvents(): array
{


    return [
        AfterSheet::class    => function(AfterSheet $event) {
            $styleArray = [
                'font' => [
                    'bold' => true,
                ],
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
                'borders' => [
                    'top' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ],
                'fill' => [
                    'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                    'startColor' => [
                        'argb' => 'FFA0A0A0',
                    ]
                ],
            ];
            $styleArray2 = [
                'alignment' => [
                    'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                ],
                'borders' => [
                    'outline' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                    ],
                ]
            ];
            // All headers - set font size to 14
            $highestRow = $event->sheet->getDelegate()->getHighestRow();
            $cellRange = 'A1:S1';
            //$event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);
            $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
            $cellRange = 'A2:S'.$highestRow;
            $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);


            $cellRange = 'G2:S'.$highestRow;
            // Set first row to height 20
            $event->sheet->getDelegate()->getRowDimension(1)->setRowHeight(20);

            $conditional1 = new \PhpOffice\PhpSpreadsheet\Style\Conditional();
            $conditional1->setConditionType(\PhpOffice\PhpSpreadsheet\Style\Conditional::CONDITION_CELLIS);
            $conditional1->setOperatorType(\PhpOffice\PhpSpreadsheet\Style\Conditional::OPERATOR_EQUAL);
            $conditional1->addCondition('0');
            $conditional1->getStyle()->getFont()->getColor()->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_RED);
            $conditional1->getStyle()->getFont()->setBold(true);

            $conditional2 = new \PhpOffice\PhpSpreadsheet\Style\Conditional();
            $conditional2->setConditionType(\PhpOffice\PhpSpreadsheet\Style\Conditional::CONDITION_CELLIS);
            $conditional2->setOperatorType(\PhpOffice\PhpSpreadsheet\Style\Conditional::OPERATOR_EQUAL);
            $conditional2->addCondition(1);
            $conditional2->getStyle()->getFont()->getColor()->setARGB(\PhpOffice\PhpSpreadsheet\Style\Color::COLOR_BLUE);
            $conditional2->getStyle()->getFont()->setBold(true);

            $conditionalStyles = $event->sheet->getDelegate()->getStyle($cellRange)->getConditionalStyles();
            $conditionalStyles[] = $conditional1;
            $conditionalStyles[] = $conditional2;

            $event->sheet->getDelegate()->getStyle($cellRange)->setConditionalStyles($conditionalStyles);

        },
    ];
}
}
