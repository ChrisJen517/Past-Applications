<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\old_passwords;
use App\RNNMailer;
use App\Models\Role;
use App\User;
use Auth;
use Carbon\Carbon;
use Config;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use PHPMailer\PHPMailer\PHPMailer;
use Illuminate\Support\Facades\Log;



class AccountController extends Controller
{
    public function showChangePassword()
    {
        if (Auth::user()->password_valid == 0) {
            return view('login/changePassword');
        } else {
            return redirect('/success');
        }

    }

    public function changePassword(Request $request)
    {
        //Validating request
        $this->validate($request, [
            'newPasswordName' => 'required',
        ]);

        // Accessing current user
        $user = Auth::user();
        // Changing password
        $date = Carbon::now()->subDays(365)->format('Y-m-d');
        $passwordHistories = $user->passwordHistories()->where("created_at", '>', $date)->get();
        if ($user->password == bcrypt($request->input('newPasswordName'))) {
            return back()->with('error', 'Your Password Can Not Be Your Previous Password.');
        }
        foreach ($passwordHistories as $passwordHistory) {
            $passwordHistory->password;
            if (Hash::check($request->get('newPasswordName'), $passwordHistory->password)) {
                // The passwords matches
                return back()->with("message", "Your new password can not be same as any of your recent passwords. Please choose a new password.");
            }
        }

        $oldPassword = new old_passwords();
        $oldPassword->password = $user->password;
        $oldPassword->user_id = $user->user_id;
        $oldPassword->save();
        $user->password = bcrypt($request->input('newPasswordName'));
        $user->password_valid = 1;

        $user->save();

        if (Auth::user()->role == 'admin') {
            return redirect('/admin/dashboard')->with('message', 'Password Changed');
        } elseif (Auth::user()->role == 'manager') {
            return redirect('/managerManageInventory');
        } elseif (Auth::user()->role == 'corporate_admin') {
            return redirect('/corporateAdmin/manageTeamQueues');
        } elseif (Auth::user()->role == 'agent') {
            return redirect('/agent/todaysReminders');
        } elseif (Auth::user()->role == 'directory_agent') {
            return redirect('/directory_agent/todaysReminders');
        } elseif (Auth::user()->role == 'powerlead') {
            return redirect('/powerlead/dashboard');
        } elseif(Auth::user()->role == 'powerlead_directory_manager'){
            return redirect('/powerleadDirectoryManager/pages/manageAccounts');
        }
    }

    public function resetPassword()
    {
        return view('auth/resetPassword');
    }

    public function sendResetPassword(request $request)
    {
        $User = User::where('email', '=', $request->email)->first();
        if (empty($User)) {
            return redirect('/login')->with('message', 'If Account was found password was reset');
        }

        $oldPassword = new old_passwords();
        $oldPassword->password = $User->password;
        $oldPassword->user_id = $User->user_id;
        $oldPassword->save();
        $token = rand(100000000000, 999999999999);
        $User->password = bcrypt($token);
        $User->password_valid = 0;
        $User->save();

        $mail = new RNNMailer(true, $User);

        //Recipients
        $mail->addAddress($User->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $User->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        Log::debug("Password reset for: ".$User->first_name." ".$User->last_name." By: Login Page");

        return redirect('/login')->with('message', 'If Account was found password was reset');
    }
}
