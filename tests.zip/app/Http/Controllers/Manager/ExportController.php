<?php

namespace App\Http\Controllers\Manager;

use App\Models\Active_Account;
use App\Models\Agent;
use App\ExportQueue;
use App\Http\Controllers\Controller;
use Auth;
use DB;
use Excel;

class ExportController extends Controller
{
    public function agentQueue($id)
    {

        $accessList = [];
        if (!empty(Auth::user()->has_access)) {
            $user_access = DB::Select(DB::Raw('Select shortcode from access_levels where id in(' . Auth::user()->has_access . ')'));

            foreach ($user_access as $access) {
                $accessList[] = strtoupper($access->shortcode);
            }
        }
       
        //   dd($rules);
        $accounts = Active_Account::select('ID', 'ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
            'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
            'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR',
            'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE',
            'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER', 'ACCESS_RULES')
            ->where('ACCT_AGENT', $id)
            ->get();
        $filteredAccounts = [];

       
        foreach($accounts as $account){
            if($account->ACCESS_RULES != null || $account->ACCESS_RULES != "")
            {
                $rule = explode(',', $account->ACCESS_RULES);
                foreach($rule as $r){
                    if(!in_array(strtoupper($r), $accessList))
                    {
                        continue;
                    }else{
                        $filteredAccounts[$account->ID] = $account;

                    }
                }
                
            }else{
                $filteredAccounts[$account->ID] = $account;
            }
        }
     
        
        return $filteredAccounts;

        
    }

    public function exportQueue($id)
    {
        if(Agent::where('agent_id', $id)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1)
            return back()->with('error', 'Agent is not on your team!');

        $export = new ExportQueue($this->agentQueue($id));
        $agent = Agent::where('agent_id', $id)->first();
        $file = 'Agent_Queue' . '-' . $agent->corporation_id . '.xlsx';
        return Excel::download($export, $file);
    }
}
