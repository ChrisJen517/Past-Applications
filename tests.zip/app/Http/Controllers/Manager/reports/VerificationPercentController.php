<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use DB;
use App\Models\Team;
use Illuminate\Http\Request;

class VerificationPercentController extends Controller
{
    public function showVerificationPercent(Request $request){
        if($request->from == null)
            $startTime = date("Y-m-d", strtotime("-30 days"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $endTime = date("Y-m-d");
        else
            $endTime = date('Y-m-d', strtotime($request->to));

        $message = "from ".$startTime." to ".$endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $scorePercents = $this->getData($startTime, $endTime);
        return view('manager.pages.reports.verificationPercent')->with('scorePercents', $scorePercents)->with('message', $message);
    }

    public function getData($from, $to){
        $manager = Auth::user()->manager_link;
        //gets list of capcodes
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->select('capcode', 'id', 'type')->get();

        //gets active agents
        $agents = Agent::where('team_id', $manager->team_id)->where('created_at', '<', $to)->with('user_link')->select('agent_id','user_id', 'team_id')->get();
        $teams = Team::where('corporation_id', $manager->corporation_id)->where('created_at', '<', $to)
        ->where(function($q) use ($from){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($from) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $from );}); })
        ->select('team_id', 'name')->get();

        $agentIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
        }
        $verified = [];
        $verifiedCapcodes = $capcodes->where('type', 'verified');
        foreach($verifiedCapcodes as $capcode){
            $verified[] = $capcode->id;
        }
        $verified = implode(',', $verified);

        $selectScores = "";
        $verfiedScoes = "";
        for($i = 1; $i < 11; $i++){
            $selectScores = $selectScores."COUNT(IF(POESCORE = $i AND CAPCODE IN (".$verified."), 1, NULL)) as verified".$i.", ";
            $verfiedScoes = $verfiedScoes."COUNT(IF(POESCORE = $i, 1, NULL)) as total".$i.", ";
        }

        $closedCounts = Inactive_Account::select(DB::RAW($verfiedScoes.''.$selectScores.' ACCT_AGENT'))
        ->whereIn('ACCT_AGENT', $agentIds)->whereDate('LAST_WORKED', '>=', $from)->whereDate('LAST_WORKED', '<=', $to)
        ->groupby('ACCT_AGENT')->get();

        $workedCounts = Active_Account::select(DB::RAW($selectScores.' ACCT_AGENT'))
        ->whereIn('ACCT_AGENT', $agentIds)->whereDate('LAST_WORKED', '>=', $from)->whereDate('LAST_WORKED', '<=', $to)
        ->groupby('ACCT_AGENT')->get();

        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $team = $teams->where('team_id', $agent->team_id)->first()->name ?? '';

            $finalData[$agent->agent_id] = [
                'agentId' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'team' => $team,
            ];

            $agentsWorked = $workedCounts->where('ACCT_AGENT', $agent->agent_id)->first();
            $agentsClosed = $closedCounts->where('ACCT_AGENT', $agent->agent_id)->first();

            for($i = 1; $i < 11; $i++){
                $scoreWorked = $agentsWorked->{"total".$i} ?? 0;
                $scoreClosed = $agentsClosed->{"total".$i} ?? 0;
                $scoreVerified = $agentsClosed->{"verified".$i} ?? 0;

                $totalWorked = $scoreWorked + $scoreClosed;

                if($totalWorked == 0){
                    $finalData[$agent->agent_id][$i.'total'] = '';
                    $finalData[$agent->agent_id][$i.'percent'] = '0.00';
                }
                else{
                    $finalData[$agent->agent_id][$i.'total'] = $totalWorked;
                    $finalData[$agent->agent_id][$i.'percent'] = bcdiv($scoreVerified*100, $totalWorked, 2);
                }
            }
        }

        return $finalData;
    }
}