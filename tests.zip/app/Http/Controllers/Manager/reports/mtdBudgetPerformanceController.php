<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Traits\DateUtils;
use App\User;
use DateTime;

class mtdBudgetPerformanceController extends Controller
{
    use DateUtils;

    public function showMtd(){
        $manager = Auth::user()->manager_link;

        $start = date('Y-m-01');
        $endDate = date("Y-m-d");

        $reportData = $this->getData($manager, $start, date('Y-m-d' , strtotime($endDate.' +1 day')));

        $daysWorked = $this->getWorkingDays(date("Y-m-01"), $endDate);

        $agentData = $reportData[0];
        $teamData = $reportData[1];

        $message = "from ".$start." to ".$endDate;

        $graphData = [];
        foreach($agentData as $agent)
        {

            $graphData[] =
            array(
                $agent['name'],
                $agent['verified'],
                $agent['verified'],
                $agent['goal']*$daysWorked-$agent['verified'],
                $agent['goal']*$daysWorked-$agent['verified']
            );
        }
        return view('manager.pages.reports.mtdBudgetPerformance')->with('teamData', $teamData)->with('agentData', $agentData)->with('graphData', $graphData)->with('daysWorked', $daysWorked)->with('timeMessage', $message);
    }


    public function getData($manager, $startTime, $endTime){

        $startTime = date('Y-m-d H:i:s', strtotime($startTime));
        $endTime = date('Y-m-d H:i:s', strtotime($endTime));

        $agents = Agent::where('team_id', $manager->team_id)->where('created_at', '<', $endTime)->with('user_link')->select('agent_id','user_id', 'team_id')->get();
        $team = Team::where('team_id', $manager->team_id)->select('team_goals', 'team_id', 'name')->get()->first();
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->where('type', 'verified')->select('id')->get();

        //gets the user and agent ids as a list
        $agentIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
        }

        //gets all capcodes into an array
        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        $teamData = [
            'name' => $team->name,
            'goal' =>  $team->team_goals,
            'verified' => 0,
            'agents' => 0,
        ];


        //gets all of the agents worked accounts and
        $accounts = Inactive_Account::wherein('ACCT_AGENT', $agentIds)->wherein('CAPCODE', $codes)
        ->select('ACCT_AGENT', 'CAPCODE')->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime)->get();

        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $verified = count($accounts->wherein('ACCT_AGENT', $agent->agent_id));

            $agentData[$agent->agent_id] = [
                'id' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'goal' => $teamData['goal'],
                'verified' => $verified,
            ];

            $teamData['verified'] += $verified;
            $teamData['agents']++;
        }


        $reportData[] = $agentData;
        $reportData[] = $teamData;

        return $reportData;
    }
}
