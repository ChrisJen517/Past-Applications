<?php

namespace App\Http\Controllers\Manager\reports;

use Illuminate\Http\Request;
use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\User;
use App\Models\Active_Account;
use DateTime;

class dailyBudgetPerformanceController extends Controller
{ 
    public function dailyBudgetByTeam(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', strtotime($request->from));
            $endTime = date('Y-m-d', strtotime($request->from." +1 day"));
        }
        
        $finalData = $this->getDataTeam( $startTime, $endTime);

        if($request->from == null)
            $message = "from today"; 
        else{
            $messageTime = date('Y-m-d', strtotime($request->from));
            $message = "from ".$messageTime;
        }

        if($finalData == null)
            return view('manager.pages.reports.dailyBudgetPerformanceTeam')->with('highestValue', 0)->with('teams', [])->with('timeMessage', $message);  
        
        $highestValue = 10;
        foreach($finalData as $data){
            if($data[1] > $highestValue)
                $highestValue = $data[1];
            if($data[3] > $highestValue)
                $highestValue = $data[3];
        }
        
        return view('manager.pages.reports.dailyBudgetPerformanceTeam')->with('teams', $finalData)->with('highestValue', $highestValue)->with('timeMessage', $message);
    }
    
    public function dailyBudgetByAgent(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', $request->from );
            $endTime = date('Y-m-d', $request->from." +1 day");
        }
        $finalData = $this->getData( $startTime, $endTime);
        
        if($request->from == null)
            $message = "from today"; 
        else{
            $messageTime = date('Y-m-d', strtotime($request->from));
            $message = "from ".$messageTime;
        }

        if($finalData == null)
            return view('manager.pages.reports.dailyBudgetPerformanceAgent')->with('highestValue', 0)->with('agents', [])->with('timeMessage', $message);
        
        $highestValue = 10;

        foreach($finalData as $data){
            if($data[1] > $highestValue)
                $highestValue = $data[1];
            if($data[3] > $highestValue)
                $highestValue = $data[3];
        }

        return view('manager.pages.reports.dailyBudgetPerformanceAgent')->with('highestValue', $highestValue) ->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter){
        //gets list of verified capcodes
        $corporation_id = Auth::user()->corporation_manager_link->corporation_id;
        $team_id = Auth::user()->manager_link->team_id;
        $team = Team::find($team_id);
        $capcodes = Capcode::where('corporation_id', $corporation_id)
        ->where('type', 'verified')->select('id')->get();

        $agents = Agent::where('team_id', $team_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('agent_id','user_id', 'team_id')->get();

        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        $agentIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
        }

        if($agents->first() == null)
            return $finalData = null;

        //gets all accounts
        $inactiveAccounts = Inactive_Account::where('corporation_id', $corporation_id)->where('team_id', $team_id)
        ->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->wherein('ACCT_AGENT', $agentIds)->wherein('CAPCODE', $codes)
        ->select('CAPCODE', 'ACCT_AGENT')->get();

        $finalData = [];
        foreach($agents as $agent){
                
            $deactivated_date = $agent->user_link->deactivate_date;

            $daysDiff = abs(round((strtotime($dayAfter) - strtotime($day))/86400)); //Calculates the difference between the two dates in days
            
            if($team->team_goals != null || $team->team_goals != '')
                $dailyGoals = $team->team_goals * $daysDiff;
            else
                $dailyGoals = 10 * $daysDiff;
    
            if($deactivated_date > $day || $deactivated_date == null){

                $verified = count($inactiveAccounts->where('ACCT_AGENT', $agent->agent_id));

                $finalData[] =[
                    $agent->user_link->first_name.' '.$agent->user_link->last_name,
                    $verified,
                    $verified,
                    $dailyGoals,
                    $dailyGoals
                ];
            }
        }

        return $finalData;
    }

    public function getDataTeam($day, $dayAfter){
        //gets list of verified capcodes
        $corporation_id = Auth::user()->corporation_manager_link->corporation_id;
        $capcodes = Capcode::where('corporation_id', $corporation_id)
        ->where('type', 'verified')->select('id')->get();
        $agents = Agent::where('corporation_id', $corporation_id)->with('user_link')->get();

        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        $teams = Team::where('corporation_id', $corporation_id)->where('created_at', '<', $dayAfter)->get();
        

        if($teams->first() == null)
            return $finalData = null;

        //gets all accounts
        $inactiveAccounts = Inactive_Account::where('corporation_id', $corporation_id)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->where('ACCT_AGENT', '!=', null)->whereIn('CAPCODE', $codes)->select('CAPCODE', 'TEAM_ID')->get();
        $finalData = [];

        foreach($teams as $team){
            if(($team->deactivate_date < $day) && ($team->is_deactivated == 1))
                continue;

            $teamAgents = $agents->where('team_id', $team->team_id);
            $agentCount = 0;
            
            foreach($teamAgents as $agent){
                if($agent->user_link->is_deactivated == 0 || $agent->user_link->deactivate_date > $day)
                    $agentCount++; 
            }

            $daysDiff = abs(round((strtotime($dayAfter) - strtotime($day))/86400)); //Calculates the difference between the two dates in days
            
            if($team->team_goals != null || $team->team_goals != '')
                $dailyGoals = $team->team_goals * $agentCount * $daysDiff;
            else
                $dailyGoals = 10 * $agentCount * $daysDiff;

            $verified = count($inactiveAccounts->where('TEAM_ID', $team->team_id));

            $finalData[] =[
                $team->name,
                $verified,
                $verified,
                $dailyGoals,
                $dailyGoals
            ];
        }


        return $finalData;
    }
}