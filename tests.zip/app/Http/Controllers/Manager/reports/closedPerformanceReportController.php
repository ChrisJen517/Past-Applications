<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Models\Manager;
use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Team_Distribution_Rules;
use App\Models\Worked_History;
use DateTime;

class closedPerformanceReportController extends Controller
{ 
    public function showClosed(){
        $finalData = $this->getData( date("Y-m-d", strtotime("-1 week")), date("Y-m-d", strtotime("+1 day")));

        $message = "for the past seven days";
        return view('manager.pages.reports.closeActionPerformance')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function closedTime(Request $request){
        if($request->from == null)
            $startTime = date("Y-m-d", strtotime("-1 week"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $endTime = date("Y-m-d");
        else
            $endTime = date('Y-m-d', strtotime($request->to));

        $message = "from ".$startTime." to ".$endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $finalData = $this->getData( $startTime, $endTime);

        return view('manager.pages.reports.closeActionPerformance')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($from, $to){
        $manager = Auth::user()->manager_link;
        $agents = Agent::where('team_id', $manager->team_id)->where('created_at', '<', $to)->with('user_link')->select('agent_id','user_id')->get();
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->select('id', 'type', 'capcode')->get();

        //if there are no agents returns an empty array
        if($agents->first() == null)
            return [];

        $inconclusive = [];
        $allCap = [];
        foreach($capcodes as $capcode){
            $allCap[] = $capcode->id;

            if($capcode->type == 'inconclusive'  || $capcode->capcode == 2335)
                $inconclusive[] = $capcode->id;
        }

        //sets up the final array
        $finalData = [];
        $agentIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentData[$agent->agent_id] = [
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'none' => 0,
                'inconclusive' => 0,
            ];

            $agentIds[] = $agent->agent_id;
        }

        $inactive = Inactive_Account::whereIn('ACCT_AGENT', $agentIds)->whereIn('CAPCODE', $inconclusive)->where('LAST_WORKED', '>', $from)->where('LAST_WORKED', '<', $to)->get();
        $unknown = Inactive_Account::whereIn('ACCT_AGENT', $agentIds)->whereNotIn('CAPCODE', $allCap)->where('LAST_WORKED', '>', $from)->where('LAST_WORKED', '<', $to)->get();

        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentData[$agent->agent_id]['none'] = count($unknown->where('ACCT_AGENT', $agent->agent_id));
            $agentData[$agent->agent_id]['inconclusive'] = count($inactive->where('ACCT_AGENT', $agent->agent_id));
        }
        
        $finalData = [];
        foreach($agentData as $data){
            $finalData[] = $data;
        }

        return $finalData;
    }
}