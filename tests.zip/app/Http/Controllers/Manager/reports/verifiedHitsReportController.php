<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Models\Manager;
use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Team_Distribution_Rules;
use App\Models\Worked_History;
use DateTime;

class verifiedHitsReportController extends Controller
{ 
    public function showVerified(){
        $finalData = $this->getData( date("Y-m-d", strtotime("-1 week")), date("Y-m-d", strtotime("+1 day")));

        $message = "for the past seven days";
        return view('manager.pages.reports.verifiedHits')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function verifiedTime(Request $request){
        if($request->from == null)
            $startTime = date("Y-m-d", strtotime("-1 week"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $endTime = date("Y-m-d", strtotime("+1 day"));
        else
            $endTime = date('Y-m-d', strtotime($request->to));

        $finalData = $this->getData( $startTime, $endTime);
        $message = "from ".$startTime." to ".$endTime;

        return view('manager.pages.reports.verifiedHits')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter){
        $manager = Auth::user()->manager_link;

        $agents = Agent::where('team_id', $manager->team_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->where('type', 'verified')->select('id')->get();

        if($agents->first() == null)
            return [];

        $agentIds = [];    
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
        }

        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        //gets all accounts in the time frame that have an agent
        $active = Active_Account::whereIn('ACCT_AGENT', $agentIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->select('CAPCODE','ACCT_AGENT')->get();
        $closed = Inactive_Account::whereIn('ACCT_AGENT', $agentIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->select('CAPCODE','ACCT_AGENT')->get();
        $verified = $closed->wherein('CAPCODE', $codes);

        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentData[] =[
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'worked' => count($active->where('ACCT_AGENT', $agent->agent_id)) + count($closed->where('ACCT_AGENT', $agent->agent_id)),
                'verified' => count($verified->where('ACCT_AGENT', $agent->agent_id)),
            ];
        }

        return $agentData;
    }
}