<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Models\Manager;
use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Team_Distribution_Rules;
use App\Models\Worked_History;
use DateTime;
use DB;
use App\Traits\getIdCombinations;


class managerAccessRulesBreakController extends Controller
{
    use getIdCombinations;

    public function getManagerAccessRuleBreakdown(){

        $corporation_id = Auth::User()->corporation_manager_link->corporation_id;
        $team_id = Auth::User()->manager_link->team_id;
        $team =  Team::find($team_id);
        $agents = Agent::where('team_id', $team_id)->with('user_link')->get();
        $team_rules = DB::SELECT(DB::RAW("SELECT team_id as 'teamid', (SELECT GROUP_CONCAT(distinct(has_access))  from users inner join agents on users.user_id = agents.user_id WHERE agents.team_id = teamid) AS 'rule_team' FROM teams WHERE corporation_id = ".$corporation_id." and team_id = ".$team_id.";
        "));
          $query_builder = "SELECT ACCESS_RULES AS 'RULES', COUNT(ID) AS 'COUNTs', (SELECT GROUP_CONCAT(id ORDER BY id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) and CORPORATION_ID = ".$corporation_id.") AS 'shortcode_id'";

            $query_builder = $query_builder.", (SELECT count(ID) from active_accounts where ACCESS_RULES = RULES and CORPORATION_ID = ".$corporation_id." and TEAM_ID = ".$team_id.") AS 'COUNT_".$team_id."', 
        (0) AS 'ID_".$team_id."',
            (SELECT count(ID) from active_accounts where ACCESS_RULES = RULES and CORPORATION_ID = ".$corporation_id." and TEAM_ID = ".$team_id." AND ACCT_AGENT IS NOT NULL) AS 'AGENTCOUNT_".$team_id."'";

        $query_builder = $query_builder." FROM `active_accounts` WHERE `corporation_id` = ".$corporation_id." AND `TEAM_ID` = ".$team_id." AND ACCESS_RULES IS NOT NULL AND ACCESS_RULES != '' GROUP BY `ACCESS_RULES` ORDER BY COUNTs DESC";
        $available_counts = DB::SELECT(DB::RAW($query_builder));
            
        $array = explode(',',$team_rules[0]->rule_team);
        sort($array);
        if($array[0] == '')
        {
            array_shift($array); 
        }
        $array = collect($array);
        $array = $array->unique()->toArray();
        $teamAccessLevelsSet = [];
        $teamAccessLevels[$team_rules[0]->teamid] = $this->getIdCombinations($teamAccessLevelsSet, $array);
    
        $teamAccessLevels[$team_rules[0]->teamid] = collect($teamAccessLevels[$team_rules[0]->teamid]);

        foreach($agents as $agent){
            $rule_array = explode(',',$agent->user_link->has_access);
            sort($rule_array);
            if($rule_array[0] == '')
            {
                array_shift($rule_array); 
            }
            $rule_array = collect($rule_array);
            $rule_array = $rule_array->unique()->toArray();
            $agentAccessSet = [];
            $agentAccessLevels[$agent->agent_id] = $this->getIdCombinations($agentAccessSet, $rule_array);
            $agentAccessLevels[$agent->agent_id] = collect($agentAccessLevels[$agent->agent_id]);
        }

        foreach($available_counts as $available_count){
            $count_team_term = "ID_".$team_rules[0]->teamid;

            if($teamAccessLevels[$team_rules[0]->teamid]->contains($available_count->shortcode_id))
            {
                foreach($agents as $agent){
                    if($agentAccessLevels[$agent->agent_id]->contains($available_count->shortcode_id)){
                        $available_count->$count_team_term++;
                    }
                }
            }

        }
        
        return view('manager.pages.reports.accessRulesBreakdown')->with('datas', $available_counts)->with('team', $team);
    }
}