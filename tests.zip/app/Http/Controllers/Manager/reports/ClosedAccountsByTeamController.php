<?php

namespace App\Http\Controllers\Manager\Reports;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;

class ClosedAccountsByTeamController extends Controller
{
    public function showClosed(Request $request)
    {
        if (count($request->all()) == 0) {
            $startTime = date("Y-m-d");
            $endTime = date("Y-m-d");
        } else {
            if ($request->from == null) {
                $startTime = date("Y-m-d", strtotime("-1 week"));
            } else {
                $startTime = date('Y-m-d', strtotime($request->from));
            }

            if ($request->to == null) {
                $endTime = date("Y-m-d");
            } else {
                $endTime = date('Y-m-d', strtotime($request->to));
            }
        }

        $timeMessage = 'From ' . $startTime . ' to ' . $endTime;

        $endTime = date("Y-m-d", strtotime($endTime . " +1 day"));

        $verifiedCapcodes = Capcode::where('corporation_id', Auth::user()->manager_link->corporation_id)->where('type', 'verified')->get();

        $unverifiedCapcodes = Capcode::where('corporation_id', Auth::user()->manager_link->corporation_id)->where('type', '!=', 'verified')->get();

        foreach ($verifiedCapcodes as $capcode) {
            $verifiedCodes[] = $capcode->id;
        }

        foreach ($unverifiedCapcodes as $capcode) {
            $unverifiedCodes[] = $capcode->id;
        }

        $verifiedClosed = Inactive_Account::where('team_id', Auth::user()->manager_link->team_id)
            ->where("LAST_WORKED", ">", $startTime)
            ->where("LAST_WORKED", "<", $endTime)
            ->where('ON_HOLD', '!=', 1)
            ->with('inactive_capcode_link')
            ->whereIn('CAPCODE', $verifiedCodes)
            ->orderBy('last_worked', 'DESC')->limit(500)->get();

        $unverifiedClosed = Inactive_Account::where('team_id', Auth::user()->manager_link->team_id)
            ->where("LAST_WORKED", ">", $startTime)
            ->where("LAST_WORKED", "<", $endTime)
            ->where('ON_HOLD', '!=', 1)
            ->with('inactive_capcode_link')
            ->whereIn('CAPCODE', $unverifiedCodes)
            ->orderBy('last_worked', 'DESC')->limit(500)->get();

        return view('manager.pages.reports.closedAccountsByTeam')->with('verifiedClosed', $verifiedClosed)
            ->with('unverifiedClosed', $unverifiedClosed)
            ->with('verifiedCapcodes', $verifiedCapcodes)->with('unverifiedCapcodes', $unverifiedCapcodes)
            ->with('timeMessage', $timeMessage);
    }
}
