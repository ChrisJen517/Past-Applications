<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Traits\DateUtils;
use App\Models\Worked_History;
use Carbon\Carbon;
use DateTime;
use DB;

class SDRReportController extends Controller
{
    use DateUtils;

    public function showSDR(){
        $finalData = $this->getData( date("Y-m-d", strtotime("-1 week")), date("Y-m-d", strtotime("+1 day")));

        $message = "for the past seven days";
        return view('manager.pages.reports.SDR')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function SDRTime(Request $request){
        if($request->from == null)
            $startTime = date("Y-m-d", strtotime("-1 week"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $endTime = date("Y-m-d");
        else
            $endTime = date('Y-m-d', strtotime($request->to));

        $message = "from ".$startTime." to ".$endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $finalData = $this->getData( $startTime, $endTime);

        return view('manager.pages.reports.SDR')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($from, $to){
        $manager = Auth::user()->manager_link;
        $agents = Agent::where('team_id', $manager->team_id)->where('created_at', '<', $to)->with('user_link')->select('agent_id','user_id')->get();
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->where(function($q){
            $q->where('type', 'verified')->orWhere('capcode', 2210);})->select('id', 'capcode', 'type')->get();

        //if there are no agents returns an empty array
        if($agents->first() == null)
            return [];

        //gets the ids of the verified capcodes
        $verified = [];
        $verifiedCapcodes = $capcodes->where('type', 'verified');
        foreach($verifiedCapcodes as $capcode)
            $verified[] = $capcode->id;

        $callCapcode = $capcodes->where('capcode', 2210)->first()->id;

        //sets up the final array
        $finalData = [];
        $agentIds = [];
        $userIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $finalData[$agent->agent_id] = [
                'agentId' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'totalCalls' => 0,
                'totalWorked' => 0,
                'averageWork' => 0,
                'totalVerified' => 0,
                'daysWorked' => 0,
                'hoursWorked' => 0,
                'score1' => 0,
                'score2' => 0,
                'score3' => 0,
                'score4' => 0,
                'score5' => 0,
                'score6' => 0,
                'score7' => 0,
                'score8' => 0,
                'score9' => 0,
                'score10' => 0,
            ];

            $agentIds[] = $agent->agent_id;
            $userIds[] = $agent->user_link->user_id;

        }

        //gets all the agents accounts
        $active = Active_Account::select('ACCT_AGENT', 'POESCORE', 'CAPCODE')->whereIn('ACCT_AGENT', $agentIds)
        ->where('LAST_WORKED', '>', $from)->where('LAST_WORKED', '<', $to)->get();
        $closed = Inactive_Account::select('ACCT_AGENT', 'POESCORE', 'CAPCODE')->whereIn('ACCT_AGENT', $agentIds)
        ->where('LAST_WORKED', '>', $from)->where('LAST_WORKED', '<', $to)->get();

        //if there are any accounts goes through and fills the array
        if(($active->first() != null) && ($closed->first() != null)){
            //lists all accounts to get the work history
            $accounts = [];
            foreach($active as $account)
                $accounts[] = $account->ID;
            foreach($closed as $account)
                $accounts[] = $account->ID;

            $workCounts = Worked_History::select(DB::RAW("count(*) as total, agent_id as agent,
            COUNT(IF(capcode = '".$callCapcode."', 1, NULL))  as calls"))
            ->where('updated_at', '>', $from)->where('updated_at', '<', $to)->where('user_role', 'agent')->wherein('agent_id', $agentIds)
            ->groupby('agent_id')->get();

            foreach($agents as $agent){
                if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                    continue;

                //verified accounts of the agent
                $agentVerified = $closed->where('ACCT_AGENT', $agent->agent_id)->whereIn('CAPCODE', $verified);

                $finalData[$agent->agent_id]['totalWorked'] = count($active->where('ACCT_AGENT', $agent->agent_id)) + count($closed->where('ACCT_AGENT', $agent->agent_id));

                $agentCount = $workCounts->where('agent', $agent->agent_id)->first();

                if(!empty($agentCount)){
                    $finalData[$agent->agent_id]['totalCalls'] = $agentCount->calls;
                    if($finalData[$agent->agent_id]['totalWorked'] != 0)
                        $finalData[$agent->agent_id]['averageWork'] = $agentCount->total / $finalData[$agent->agent_id]['totalWorked'];
                }

                $finalData[$agent->agent_id]['totalVerified'] = count($agentVerified);
                $finalData[$agent->agent_id]['score1'] = count($agentVerified->where('POESCORE', 1));
                $finalData[$agent->agent_id]['score2'] = count($agentVerified->where('POESCORE', 2));
                $finalData[$agent->agent_id]['score3'] = count($agentVerified->where('POESCORE', 3));
                $finalData[$agent->agent_id]['score4'] = count($agentVerified->where('POESCORE', 4));
                $finalData[$agent->agent_id]['score5'] = count($agentVerified->where('POESCORE', 5));
                $finalData[$agent->agent_id]['score6'] = count($agentVerified->where('POESCORE', 6));
                $finalData[$agent->agent_id]['score7'] = count($agentVerified->where('POESCORE', 7));
                $finalData[$agent->agent_id]['score8'] = count($agentVerified->where('POESCORE', 8));
                $finalData[$agent->agent_id]['score9'] = count($agentVerified->where('POESCORE', 9));
                $finalData[$agent->agent_id]['score10'] = count($agentVerified->where('POESCORE', 10));

            }
        }

        //gets all of the log ins commented out due to activity log being removed
        // $activity = Activity_Log::whereIn('user_id', $userIds)->where('UPDATED_AT', '>', $from)->where('UPDATED_AT', '<', $to)->get();

        // //gets the time spent working per agent
        // foreach($agents as $agent){
        //     if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
        //         continue;

        //     $totalLogins = $activity->where('user_id', $agent->user_link->user_id);


        //     $hours = 0;
        //     $minutes = 0;
        //     $seconds = 0;
        //     foreach($totalLogins as $login){
        //         if($login->total_time != null){
        //             $hours = $hours + intval(date('H', strtotime($login->total_time)));
        //             $minutes = $minutes + intval(date('i', strtotime($login->total_time)));
        //             $seconds = $seconds + intval(date('s', strtotime($login->total_time)));
        //         }
        //     }
        //     $minutes = $minutes + ($seconds/60);
        //     $hours =  $hours + ($minutes/60);

        //     $finalData[$agent->agent_id]['daysWorked'] = count($totalLogins->groupby('date'));
        //     $finalData[$agent->agent_id]['hoursWorked'] = (int) $hours;

        // }

        $daysWorked = $this->getWorkingDays($from, $to);
        $daysWorked--;

        if(date("Y-m-d", strtotime($to." -1 day")) == date("Y-m-d")){
            $hoursWorked = $daysWorked * 8;

            $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
            $hoursSinceStart = $minutesSinceStart/60;
            if ($hoursSinceStart > 8 || $hoursSinceStart < 0)
                $hoursSinceStart = 8;

            $hoursWorked += $hoursSinceStart;
        }
        else{
            $hoursWorked = $daysWorked * 8;
        }

        $hoursWorked = round($hoursWorked, 2);

        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $finalData[$agent->agent_id]['daysWorked'] = $daysWorked;
            $finalData[$agent->agent_id]['hoursWorked'] = $hoursWorked;
        }

        return $finalData;
    }
}
