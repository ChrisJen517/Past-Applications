<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Worked_History;
use Carbon\Carbon;
use DB;

class callsPerHourAgentReportController extends Controller
{
    public function callsPerHour(){
        $finalData = $this->getData( date('Y-m-d'), date('Y-m-d', strtotime('tomorrow')));

        $message = "from today";
        
        return view('manager.pages.reports.callsPerHourAgent')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function callsPerHourTime(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', strtotime($request->from));
            $endTime = date('Y-m-d', strtotime($request->from.' +1 day'));
        }

        $finalData = $this->getData( $startTime, $endTime);
        $message = "from ".$startTime;
        
        return view('manager.pages.reports.callsPerHourAgent')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter){
        $manager = Auth::user()->manager_link;
        $team_id = $manager->team_id;
        $corporation_id = $manager->corporation_id;

        $callCode = Capcode::where('corporation_id', $corporation_id)->where('capcode', 2210)->first()->id;

        $agents = Agent::where('team_id', $team_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();

        if($agents->first() == null)
            return [];

        $agentIds = [];    
        $userIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
            $userIds[] = $agent->user_link->user_id;
        }

        //gets all accounts in the time frame that have an agent
        $CallHistory = Worked_History::select(DB::RAW("count(*) as calls,  agent_id, hour(updated_at) as hour"))
        ->where('updated_at', '>', $day)->where('updated_at', '<', $dayAfter)->where('user_role', 'agent')->where('capcode', $callCode)
        ->groupBy('agent_id')->groupBy(DB::RAW('hour(updated_at)'))
        ->get();

        //gets the hours as a temporary replace for activity log
        if($day == date("Y-m-d")){
            $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
            $hours = $minutesSinceStart/60;
            if ($hours > 8 || $hours < 0)
                $hours = 8;
        }
        else{
            $hours = 8;
        }

        //gets all the hourly sections into an array
        for($i = 8; $i < 20; $i++){
            $hoursDevider[] = $i;
        }

        //gets all of the log ins
        // $activity = Activity_Log::whereIn('user_id', $userIds)->where('UPDATED_AT', '>' , $day)->where('UPDATED_AT', '<', $dayAfter)->get();

        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            // $totalLogins = $activity->where('user_id', $agent->user_link->user_id);
    
            // $hours = 0;
            // $minutes = 0;
            // $seconds = 0;
            // foreach($totalLogins as $login){
            //     if($login->total_time != null){
            //         $hours = $hours + intval(date('H', strtotime($login->total_time)));
            //         $minutes = $minutes + intval(date('i', strtotime($login->total_time)));
            //         $seconds = $seconds + intval(date('s', strtotime($login->total_time)));
            //     }
            // }
            // $minutes = $minutes + ($seconds/60);
            // $hours =  $hours + ($minutes/60);

            $count = 0;          

            $agentData[$agent->agent_id] =[
                'ID' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'unique' => $count,
                'callPerHour' => 0,
                'byHour' => [],
            ];

            //gets all of the hours into the sub array
            $hourCalls = $CallHistory->where('agent_id', $agent->agent_id)->where('hour', '>=', '0')->where('hour', '<', $hoursDevider[0])->first();

            if($hourCalls != null)
                $agentData[$agent->agent_id]['byHour'][] = $hourCalls->calls;
            else
                $agentData[$agent->agent_id]['byHour'][] = 0;

            for($i = 0; $i < 11; $i++){
                $hourCalls = $CallHistory->where('agent_id', $agent->agent_id)->where('hour', '>=', $hoursDevider[$i])->where('hour', '<', $hoursDevider[$i+1])->first();
            
                if($hourCalls != null)
                    $agentData[$agent->agent_id]['byHour'][] = $hourCalls->calls;
                else
                    $agentData[$agent->agent_id]['byHour'][] = 0;
            }

            for($i = 0; $i < 12; $i++){
                $count += $agentData[$agent->agent_id]['byHour'][$i];
            }
            $agentData[$agent->agent_id]['unique'] = $count;

            if($hours != 0)
                $CallPerHour = $count/$hours;
            else
                $CallPerHour = 0;

            $agentData[$agent->agent_id]['callPerHour'] = $CallPerHour;
        }

        //puts them into one last array to remove keys for the javascrpit foreach loop
        $finalData = [];
        foreach($agentData as $data){
            $finalData[] = $data;
        }

        return $finalData;
    }
}