<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Worked_History;
use Carbon\Carbon;
use DateTime;
use DB;

class verificationsPerHourController extends Controller
{ 
    public function verificationPerHour(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', strtotime($request->from));
            $endTime = date('Y-m-d', strtotime($request->from.' +1 day'));
        }

        $finalData = $this->getData( $startTime, $endTime);
        $message = "from ".$startTime;

        return view('manager.pages.reports.verificationsPerHour')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter){
        $manager = Auth::user()->manager_link;

        $agents = Agent::where('team_id', $manager->team_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->where('type', 'verified')->select('id')->get();

        if($agents->first() == null)
            return [];

        $agentIds = [];    
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
        }

        //gets all verified capcodes into an array
        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        //gets all accounts in the time frame that have an agent
        $active = Active_Account::whereIn('ACCT_AGENT', $agentIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->select('CAPCODE','ACCT_AGENT')->get();
        $closed = Inactive_Account::whereIn('ACCT_AGENT', $agentIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->select('CAPCODE','ACCT_AGENT', 'LAST_WORKED')->get();
        $verified = $closed->wherein('CAPCODE', $codes);

        //hours worked for the day
        $dayParsed = Carbon::parse($day);
        if ($dayParsed->isToday()) {
            $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
            $hoursSinceStart = $minutesSinceStart/60;
            if ($hoursSinceStart > 8 || $hoursSinceStart <= 0)
                $hoursSinceStart = 8;
        } else
            $hoursSinceStart = 8;

        //gets all the hourly sections into an array
        for($i = 8; $i < 20; $i++){
            if($i < 10)
                $hoursDevider[] = ' 0'.$i.':00:00';
            else
                $hoursDevider[] = ' '.$i.':00:00';
        }
        
        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentData[$agent->agent_id] =[
                'ID' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'worked' => count($active->where('ACCT_AGENT', $agent->agent_id)) + count($closed->where('ACCT_AGENT', $agent->agent_id)),
                'verified' => count($verified->where('ACCT_AGENT', $agent->agent_id)),
                'byHour' => [],
                'averageVerified' => count($verified->where('ACCT_AGENT', $agent->agent_id))/$hoursSinceStart,
            ];

            //gets all of the hours into the sub array
            $agentData[$agent->agent_id]['byHour'][] =  count($verified->where('ACCT_AGENT', $agent->agent_id)
                                                        ->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<=', $day.$hoursDevider[0]));
            for($i = 0; $i < 11; $i++){
                $agentData[$agent->agent_id]['byHour'][] = count($verified->where('ACCT_AGENT', $agent->agent_id)
                                                            ->where('LAST_WORKED', '>', $day.$hoursDevider[$i])->where('LAST_WORKED', '<=', $day.$hoursDevider[$i+1]));
            }
        }

        //puts them into one last array to remove keys
        $finalData = [];
        foreach($agentData as $data){
            $finalData[] = $data;
        }

        return $finalData;
    }

}