<?php

namespace App\Http\Controllers\Manager\reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Carbon\Carbon;

class averageAgentWorkReportController extends Controller
{
    public function averageWork(){
        $finalData = $this->getData(date('Y-m-d'), date('Y-m-d', strtotime('tomorrow')));

        $message = "from today";
        
        return view('manager.pages.reports.averageAgentWork')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function averageWorkTime(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', strtotime($request->from));
            $endTime = date('Y-m-d', strtotime($request->from.' +1 day'));
        }

        $finalData = $this->getData( $startTime, $endTime);
        $message = "from ".$startTime;
        
        return view('manager.pages.reports.averageAgentWork')->with('agents', $finalData)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter){
        $team_id = Auth::user()->manager_link->team_id;

        $agents = Agent::where('team_id', $team_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();

        if($agents->first() == null)
            return [];

        $agentIds = [];    
        $userIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentIds[] = $agent->agent_id;
            $userIds[] = $agent->user_link->user_id;
        }

        //gets all accounts
        $activeAccounts = Active_Account::whereIn('ACCT_AGENT', $agentIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->where('ACCT_AGENT', '!=', null)->select('ACCT_AGENT', 'LAST_WORKED')->get();
        $inactiveAccounts = Inactive_Account::whereIn('ACCT_AGENT', $agentIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->where('ACCT_AGENT', '!=', null)->select('CAPCODE', 'ACCT_AGENT', 'LAST_WORKED')->get();

        //gets all of the log ins, commented out code is to be left for when activity log is fixed
        //$activity = Activity_Log::whereIn('user_id', $userIds)->where('UPDATED_AT', '>', $day)->where('UPDATED_AT', '<', $dayAfter)->get();
        if($day == date("Y-m-d")){
            $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
            $hours = $minutesSinceStart/60;
            if ($hours > 8 || $hours < 0)
                $hours = 8;
        }
        else{
            $hours = 8;
        }

        //gets all the hourly sections into an array
        for($i = 8; $i < 20; $i++){
            if($i < 10)
                $hoursDevider[] = ' 0'.$i.':00:00';
            else
                $hoursDevider[] = ' '.$i.':00:00';
        }

        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            // $totalLogins = $activity->where('user_id', $agent->user_link->user_id);

        
            // $hours = 0;
            // $minutes = 0;
            // $seconds = 0;
            // foreach($totalLogins as $login){
            //     if($login->total_time != null){
            //         $hours = $hours + intval(date('H', strtotime($login->total_time)));
            //         $minutes = $minutes + intval(date('i', strtotime($login->total_time)));
            //         $seconds = $seconds + intval(date('s', strtotime($login->total_time)));
            //     }
            // }
            // $minutes = $minutes + ($seconds/60);
            // $hours =  $hours + ($minutes/60);

            $worked = count($activeAccounts->where('ACCT_AGENT', $agent->agent_id)) + count($inactiveAccounts->where('ACCT_AGENT', $agent->agent_id));

            if($hours != 0)
                $average = $worked/$hours;
            else
                $average = 0;


            $agentData[$agent->agent_id] =[
                'ID' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'worked' => $worked,
                'average' => $average,
                'byHour' => [],
            ];

            //gets all of the hours into the sub array
            $agentData[$agent->agent_id]['byHour'][] =  count($activeAccounts->where('ACCT_AGENT', $agent->agent_id)
                                                        ->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<=', $day.$hoursDevider[0]))
                                                        + count($inactiveAccounts->where('ACCT_AGENT', $agent->agent_id)
                                                        ->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<=', $day.$hoursDevider[0]));
            for($i = 0; $i < 11; $i++){
                $agentData[$agent->agent_id]['byHour'][] = count($activeAccounts->where('ACCT_AGENT', $agent->agent_id)
                                                            ->where('LAST_WORKED', '>', $day.$hoursDevider[$i])->where('LAST_WORKED', '<=', $day.$hoursDevider[$i+1]))
                                                            + count($inactiveAccounts->where('ACCT_AGENT', $agent->agent_id)
                                                            ->where('LAST_WORKED', '>', $day.$hoursDevider[$i])->where('LAST_WORKED', '<=', $day.$hoursDevider[$i+1]));
            }
        }

        //puts them into one last array to remove keys for the javascrpit foreach loop
        $finalData = [];
        foreach($agentData as $data){
            $finalData[] = $data;
        }

        return $finalData;
    }
}