<?php

namespace App\Http\Controllers\Manager;

use App\Models\Agent;
use App\User;
use App\Models\old_passwords;
use App\Models\Manager;
use App\Models\Team;
use App\Models\Access_Levels;
use Config;
use App\Http\Controllers\Controller;
use App\RNNMailer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use File;
use App\Traits\AccountDistrubution;
use App\Traits\CheckPassword;
use Illuminate\Support\Facades\Log;


class manageUsersController extends Controller
{
    use AccountDistrubution;
    use CheckPassword;

    private $notAllowedIds = array(
        '1901', '1902', '1904', '3333', '9999'
    );

    public function manageUsers(){

        $manager = Manager::where('user_id', Auth::user()->user_id)->first();

        $users = User::selectRaw('users.user_id, users.first_name, users.last_name, users.email, users.role, users.role_list, users.has_access, users.is_deactivated, users.active')
        ->leftJoin('agents', function ($join) {
            $join->on('agents.user_id', '=', 'users.user_id');
        })->whereRaw('(agents.team_id = '. $manager->team_id.') AND (users.role_list NOT LIKE "%admin%" AND users.role_list NOT LIKE "%manager%" AND users.role_list NOT LIKE "%directory_agent%" or users.role_list is null) ')->get();

        $team = Team::where('team_id', $manager->team_id)->with('agent_link')->first();
        $access_levels = Access_Levels::where('corporation_id', $manager->corporation_id)->get();
        $user_levels = explode(',', Auth::user()->has_access);
        return view('manager.pages.manageUsers')->with('users', $users)->with('team', $team)->with('access_levels', $access_levels)->with('user_levels', $user_levels);
    }

    public function addAgent(Request $request){

        $this->validate($request, [
            'first_name' => 'required|max:90',
            'last_name' => 'required|max:90',
            'email' => 'required|unique:users|max:90',
        ]);

        $manager = Manager::where('user_id', Auth::user()->user_id)->first();

        $user = new User();
        $user->email = $request->email;
        $token = rand(100000000000, 999999999999);
        //$user->password = bcrypt("Password1!");
        $user->password = bcrypt($token);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->role = 'agent';
        $user->role_list = 'agent';
        $user->password_valid = 0;
        $user->active = 1;
        $user->save();

        $agent = new Agent();
        $agent->team_id = $manager->team_id;
        $agent->corporation_id = $manager->corporation_id;
        $agent->user_id = $user->user_id;
        $agent->save();

        if(in_array($agent->agent_id, $this->notAllowedIds)) {
            if($agent->agent_id <= 1904)
                $agent->agent_id = 1905;
            else
                $agent->agent_id += 1;
        }


        $mail = new RNNMailer(true, $user);

        $path = '/home/rocky/public_html/ProfilePictures/'.$user->user_id.'';
        $env = Config::get('app.env');
        if ($env != 'prod') {
            $path = public_path('ProfilePictures/'.$user->user_id.'');
        }
        if (!file_exists($path)) {
            mkdir($path);
        }
        $file = File::get(public_path('ProfilePictures/baseAvatar.png'));
        File::put(public_path('ProfilePictures/' . $user->user_id . '/avatar.png'), $file);

        //Recipients
        $mail->addAddress($request->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body    = "Your Account Name is $request->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        return redirect('managerManageUsers')->with("success", "Agent Created!");
    }

    public function blockAgent($id)
    {
        if(Agent::where('user_id', $id)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1)
            return back()->with('error', "That agent is not on your team!");

        $User = User::with('agent_link')->find($id);
        if($User->user_id == Auth::user()->user_id)
            return back()->with('error', "You cannot block yourself");

        if($User->role == 'agent'){
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = null WHERE ACCT_AGENT = '.$User->agent_link->agent_id.';'));
        }
        $User->active = 0;
        $User->save();

        return redirect()->back()->with('message', 'Agent Blocked');
    }

    public function unblockAgent($id)
    {
        if(Agent::where('user_id', $id)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1)
            return back()->with('error', "That agent is not on your team!");

        $User = User::with('agent_link')->find($id);

        $message = $this->redistributeToAgent($User->agent_link->agent_id);

        $User->active = 1;
        $User->save();

        return redirect()->back()->with('message', $message);
    }

    public function pauseAgent($agentId, $willPause) {
        $agent = Agent::where('agent_id', $agentId)->first();
        if (empty($agent)) {
            $data[] = 'Invalid agent.';
            $data[] = "error";
            return response()->json($data);
        }

        $agent->paused = $willPause ? 1 : 0;
        $agent->save();

        return response()->json('Successfully ' . ($willPause ? "" : "un") . "paused the agent's queue.");
    }

    public function deleteAgent($id)
    {
        $user = User::find($id);

        if($user == Auth::user()) {
            return back()->with('error', 'You cannot delete yourself');
        }

        if(Agent::where('user_id', $id)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1)
            return back()->with('error', "That agent is not on your team!");

        DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = '.$user->agent_link->agent_id.';'));
        $user->active = 0;
        $user->is_deactivated = 1;
        $user->deactivate_date = Carbon::now();
        $user->save();

        return redirect()->back()->with('message', 'Agent Deactivated');
    }

    public function reactivateAgent($id) {
        $user = User::find($id);
        $agent = Agent::where('user_id', $id)->where('team_id', Auth::user()->manager_link->team_id);
        if ($agent->count() < 1)
            return back()->with('error', "That agent is not on your team!");

        $agent = $agent->first();
        $agent->active = 1;

        $user->active = 1;
        $user->is_deactivated = 0;
        $user->deactivate_date = null;
        $user->save();
        $agent->save();

        return redirect()->back()->with('message', 'Agent Reactivated');
    }

    public function getAccessIds(Request $request)
    {
        $shortcodes = $request->titles;
        $access_levels = Access_Levels::where('corporation_id', Auth::user()->corporation_manager_link->corporation_id)->get();
        $accessIds = [];
        foreach($access_levels as $access){
            if(in_array($access->shortcode, $shortcodes)){
                $accessIds[] = $access->id;
            }
        }

        echo json_encode($accessIds);

    }


    public function updateAgent(Request $request){

        $this->validate($request, [
            'first_name' => 'max:90',
            'last_name' => 'max:90',
            'newPassword' => 'max:90',
            'c_password' => 'max:90',
        ]);

        $list = '';
        if($request->exists('accessLevels') && !empty($request->accessLevels)){
            foreach($request->accessLevels as $access){
                $list = $list.$access.',';
            }
        }
        $list = substr_replace($list ,'', -1);

        $user = User::find($request->idName);

        if(Agent::where('user_id', $request->idName)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1)
            return back()->with('error', "That agent is not on your team!");

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;

        //if agent has their accounts changed removes them
        $redistribute = false;
        if(($user->has_access != $list) && ($user->role == 'agent')){
            $redistribute = true;
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = '.$user->agent_link->agent_id.';'));
        }

        $user->has_access = $list;

        if($request->newPassword != NULL){
            if(!$this->CheckPassword($request->newPassword))
                return back()->with('error', 'Password does not meet requirments!');

            if($request->newPassword != $request->c_password)
                return back()->with('error', 'Passwords do not match!');

            $date = Carbon::now()->subDays(365)->format('Y-m-d');
            $passwordHistories = $user->passwordHistories()->where("created_at", '>', $date)->get();
            foreach($passwordHistories as $passwordHistory){
                echo $passwordHistory->password;
                if (Hash::check($request->get('newPassword'), $passwordHistory->password)) {
                    // The passwords matches
                    return redirect()->back()->with("error","Your new password can not be same as any of your recent passwords. Please choose a new password.");
                }
            }

            $oldPassword = new old_passwords();
            $oldPassword->password = $user->password;
            $oldPassword->user_id = $request->idName;
            $oldPassword->save();
            $user->password = bcrypt($request->input('newPassword'));
        }

        $user->save();

        //if the account is removed, redistribute
        if($redistribute)
            $this->redistributeToAgent($user->agent_link->agent_id);

        return redirect('managerManageUsers')->with("success", "Agent Updated");
    }

    public function sendPasswordReset($id)
    {
        if(Agent::where('user_id', $id)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1)
            return back()->with('error', "That agent is not on your team!");

        $User = User::find($id);

        $oldPassword = new old_passwords();
        $oldPassword->password = $User->password;
        $oldPassword->user_id = $User->user_id;
        $oldPassword->save();
        $token = rand(100000000000, 999999999999);
        $User->password = bcrypt($token);
        $User->password_valid = 0;
        $User->save();

        $mail = new RNNMailer(true, $User);

        //Recipients
        $mail->addAddress($User->email);

        // Content<p>{{  }}</p>
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body    = "Your Account Name is $User->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        Log::debug("Password reset for: ".$User->first_name." ".$User->last_name." By: ".Auth::user()->first_name." ".Auth::user()->last_name);

        return redirect()->back()->with('message', 'Password Reset');
    }
}
