<?php

namespace App\Http\Controllers\Manager;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Manager;
use App\Models\Redistribution_Record;
use App\Traits\GetOrderArray;
use App\Traits\AccountDistrubution;
use App\Models\Worked_History;
use Auth;
use DB;
use Illuminate\Http\Request;
use App\Traits\getIdCombinations;
use App\User;

class manageInventoryController extends Controller
{
    use GetOrderArray, getIdCombinations;

    public function manageInventory()
    {
        $team_id = Manager::where('user_id', Auth::user()->user_id)->first()->team_id;
        $corporation_id = Auth::User()->corporation_manager_link->corporation_id;
        $agents = Agent::where('team_id', $team_id)->with('user_link')->get();

        $agentIds = $this->getAgents($team_id);
        $agentCounts = DB::SELECT(DB::RAW("SELECT ACCT_AGENT AS agent, agents.paused as paused, users.first_name, users.last_name, COUNT(DISTINCT ID) AS Total_Active,
        (Select COUNT(ID) from active_accounts where ACCT_AGENT = agent and LAST_WORKED IS NOT NULL AND LAST_WORKED != '') AS Working_On,
        (Select COUNT(ID) from active_accounts where ACCT_AGENT = agent and (LAST_WORKED IS NULL OR LAST_WORKED = '')) AS Never_Worked
        FROM active_accounts
        INNER JOIN agents on active_accounts.ACCT_AGENT = agents.agent_id INNER JOIN users on agents.user_id = users.user_id
        WHERE ACCT_AGENT IN ($agentIds) GROUP BY ACCT_AGENT;"));

        foreach ($agents as $agent) {
            if ($agent->user_link->is_deactivated == 1 || $agent->user_link->active == 0) {
                continue;
            }

            $inArray = false;
            foreach ($agentCounts as $list) {
                if ($list->agent == $agent->agent_id) {
                    $agentList[] = [
                        "ACCT_AGENT" => $list->agent,
                        "first_name" => $list->first_name,
                        "last_name" => $list->last_name,
                        "Total_Active" => $list->Total_Active,
                        "Working_On" => $list->Working_On,
                        "Never_Worked" => $list->Never_Worked,
                        "paused" => $list->paused
                    ];
                    $inArray = true;
                    break;
                }
            }

            if (!$inArray) {
                $agentList[] = [
                    "ACCT_AGENT" => $agent->agent_id,
                    "first_name" => $agent->user_link->first_name,
                    "last_name" => $agent->user_link->last_name,
                    "Total_Active" => 0,
                    "Working_On" => 0,
                    "Never_Worked" => 0,
                    "paused" => $agent->paused
                ];
            }
        }

        $agentScores = DB::SELECT(DB::RAW("SELECT count(ID) as count, ACCT_AGENT, poescore, users.last_name, users.first_name
        FROM active_accounts
        INNER JOIN agents on active_accounts.ACCT_AGENT = agents.agent_id
        INNER JOIN users on agents.user_id = users.user_id
        WHERE active_accounts.team_id = $team_id
        AND ACCT_AGENT is not null
        GROUP BY poescore, acct_agent
        ORDER BY acct_agent, poescore asc"));

        $scoresArray = [];

        foreach ($agentScores as $score) {
            for ($i = 0; $i <= 10; $i++) {
                if ($i == $score->poescore) {
                    $scoresArray[$score->ACCT_AGENT][$i] = ['count' . $i => $score->count];
                }

            }
            $scoresArray[$score->ACCT_AGENT][11] = $score->ACCT_AGENT;
            $scoresArray[$score->ACCT_AGENT][12] = $score->first_name;
            $scoresArray[$score->ACCT_AGENT][13] = $score->last_name;
        }

        foreach ($agents as $agent) {
            if ($agent->user_link->is_deactivated == 1) {
                continue;
            }

            $inArray = false;
            foreach ($scoresArray as $list) {
                if ($list[11] == $agent->agent_id) {
                    $inArray = true;
                    break;
                }
            }

            if (!$inArray) {
                for ($i = 0; $i <= 10; $i++) {
                    $scoresArray[$agent->agent_id][$i] = ['count' . $i => 0];
                }
                $scoresArray[$agent->agent_id][11] = $agent->agent_id;
                $scoresArray[$agent->agent_id][12] = $agent->user_link->first_name;
                $scoresArray[$agent->agent_id][13] = $agent->user_link->last_name;
            }
        }

        //if there are no agents makes a blank list
        if (!isset($agentList)) {
            $agentList = [];
        }

        return view('manager.pages.manageInventory')->with('agents', $agentList)->with('agentScores', $scoresArray)->with('corporation_id', $corporation_id);
    }

    public function getAgents($team_id)
    {

        $agents = Agent::where('team_id', $team_id)->get();
        $agentList = '';
        foreach ($agents as $agent) {
            $agentList = $agentList . ' "' . $agent->agent_id . '",';
        }
        $agentList = substr_replace($agentList, '', -1);
        if ($agentList == '') {
            $agentList = '0';
        }
        return $agentList;
    }

    public function getAccountCases(Request $request)
    {
        $id = $request->agent_id;
        $cases = Active_Account::select('ACCT_CASE')->where('ACCT_AGENT', $id)->whereNotNull('ACCT_CASE')->get();
        $account_cases = array();
        foreach ($cases as $key => $value) {
            if ($value['ACCT_CASE'] != " ") {
                $account_cases[] = $value['ACCT_CASE'];
            }
        }

        echo json_encode($account_cases);
    }

    public function tossAgentAccounts(Request $request)
    {
        $corporation_id = Auth::User()->corporation_manager_link->corporation_id;
        $team_id = Manager::where('user_id', Auth::user()->user_id)->first()->team_id;

        $this->validate($request, [
            'agent_selected' => 'required',
            'send_to_agent' => 'required',
        ]);

        if (Agent::where('agent_id', $request->agent_selected)->where('team_id', Auth::user()->manager_link->team_id)->count() < 1) {
            return back()->with('error', 'Selected agent is not on your team!');
        }

        if (Agent::whereIn('agent_id', $request->send_to_agent)->where('team_id', Auth::user()->manager_link->team_id)->count() < count($request->send_to_agent)) {
            return back()->with('error', 'One or more target Agents are not on your team!');
        }

        $orderArray = $this->getOrderArray($corporation_id, $team_id);
        $first = $orderArray[0];
        $second = $orderArray[1];
        $third = $orderArray[2];

        $case = $request->account_case;
        $unworked = $request->unworked_check;
        $agent = $request->agent_selected;

        $accounts = Active_Account::select('ID', 'ACCT_AGENT', 'ACCESS_RULES')->where('ACCT_AGENT', $agent)
            ->when($case, function ($query, $case) {
                return $query->whereIn('ACCT_CASE', $case);
            })
            ->when($unworked, function ($query, $agent) {
                return $query->whereNull('LAST_WORKED')->orWhere('LAST_WORKED', '')->where('ACCT_AGENT', $agent);
            })
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })
            ->when($third, function ($query, $third) {
                return $query->orderByRaw($third);
            })->orderBy('LAST_WORKED')
            ->get();

        $sendAgents = $request->send_to_agent;
        $maxNeeded = $request->max_per_agent * count($sendAgents);
        $agentList = implode(',', $sendAgents);

        //gets the list of agents and their access levels
        $agents = DB::SELECT(DB::RAW("SELECT
        agent_id,
        (SELECT has_access FROM users as u WHERE a.user_id = u.user_id ) as access_levels,
        (SELECT group_concat(shortcode) from access_levels WHERE FIND_IN_SET(id,access_levels)) AS shortcodes
        FROM agents as a INNER JOIN users on a.user_id = users.user_id
        where corporation_id = $corporation_id and agent_id IN ($agentList) and users.is_deactivated = 0 ORDER BY LENGTH(access_Levels) DESC"));

        //gets all possible combinations in the company accounts
        $query_builder = "SELECT ACCESS_RULES AS 'RULES',
        (SELECT GROUP_CONCAT(id order by id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) AND corporation_id = $corporation_id)  AS 'shortcode_id'";
        $count = 0;
        foreach ($agents as $agent) {
            $query_builder = $query_builder . ", (0) AS 'ID_" . $agent->agent_id . "'";
            $count++;
        }
        $query_builder = $query_builder . "FROM `active_accounts` WHERE `corporation_id` = " . $corporation_id . " AND `ACCT_AGENT` = $request->agent_selected AND `ACCESS_RULES` != '' AND `ACCESS_RULES` IS NOT NULL GROUP BY `ACCESS_RULES`";
        $agentRules = DB::SELECT(DB::RAW($query_builder));

        $agentAccessLevels = [];

        //initialize count and agent arrays, and get list of agent access level combinations
        $ruleSet = [];
        foreach ($agents as $agent) {
            $array = explode(',', $agent->access_levels);
            $agentAccessLevelSet = [];
            $agentAccessLevels[] = collect($this->getIdCombinations($agentAccessLevelSet, $array));

            $agentCountArray[] = 0;
            $agentUpdateArray[] = "";
            $ruleSet[] = [];

        }

        //gets the set of workable rules for each agent
        $nonWorkableCodes = [];
        $removeMessage = "";
        foreach ($agentRules as $agentRule) {
            $i = 0;
            $notWorkable = true;
            foreach ($agents as $agent) {
                if ($agentAccessLevels[$i]->contains($agentRule->shortcode_id)) {
                    $ruleSet[$i][] = strtoupper($agentRule->RULES);
                    $ruleSet[$i][] = strtolower($agentRule->RULES);
                }

                $i++;
            }

            //adds to array of non workable accounts
            if ($notWorkable) {
                $nonWorkableCodes[] = strtolower($agentRule->RULES);
                $nonWorkableCodes[] = strtoupper($agentRule->RULES);
                $removeMessage = $agentRule->RULES . ', ' . $removeMessage;
            }

        }

        //removes accounts that cannot be worked
        if (!empty($nonWorkableCodes)) {
            $removedCount = count($accounts->whereIn('ACCESS_RULES', $nonWorkableCodes));
            $accounts = $accounts->whereNotIn('ACCESS_RULES', $nonWorkableCodes);
            $removeMessage = substr_replace($removeMessage, "", -2);
        }

        //gets the total count and the max based on the information given
        $totalCount = count($accounts);
        $movedAccounts = 0;
        $lefToMove = 0;
        if ($request->max_per_agent) {
            $max = $request->max_per_agent;
        } else {
            $max = ceil($totalCount / count($sendAgents));
        }

        while ($totalCount > 0) {
            $i = 0;
            $maxCount = 0;
            foreach ($accounts as $account) {

                $totalCount--;
                $i++;
                //checking to see if looped through all agents
                if ($i >= count($sendAgents)) {
                    $i = 0;
                }
                //checking to see if agent has reached max
                if ($agentCountArray[$i] >= $max) {
                    $maxCount++;
                    //check to see if all agents have reached max
                    if ($maxCount == count($agentCountArray)) {
                        break;
                    }
                    continue;
                }

                $loopcount = 0;
                $teamMemberStart = $i;
                startCheckRule:
                //add acct_id to agent array
                if (($account->ACCESS_RULES == null) || ($account->ACCESS_RULES == "")) {
                    $agentUpdateArray[$i] = $agentUpdateArray[$i] . '"' . $account->ID . '", ';
                    $agentCountArray[$i] += 1;
                    $movedAccounts++;
                } elseif (in_array($account->ACCESS_RULES, $ruleSet[$i])) {
                    $agentUpdateArray[$i] = $agentUpdateArray[$i] . '"' . $account->ID . '", ';
                    $agentCountArray[$i] += 1;
                    $movedAccounts++;
                    $i = $teamMemberStart;
                } elseif ($loopcount >= count($sendAgents)) {
                    $i = $teamMemberStart;
                } else {
                    $i++;
                    if ($i >= count($sendAgents)) {
                        $i = 0;
                    }
                    $loopcount++;
                    goto startCheckRule;
                }
            }

        }

        //updates the database
        for ($i = 0; $i < count($sendAgents); $i++) {
            if ($agentUpdateArray[$i] != "") {
                $agentUpdateArray[$i] = substr_replace($agentUpdateArray[$i], "", -2);
                DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = ' . $sendAgents[$i] . '  WHERE `ID` IN (' . $agentUpdateArray[$i] . ');'));
            }
        }

        //add redistribution record to update agent queues
        $redistribution_record = new Redistribution_Record();
        $redistribution_record->corporation_id = $corporation_id;
        $redistribution_record->team_id = $team_id;
        $redistribution_record->save();

        //if an account had to be removed, displays an error
        if ($removeMessage != "" && $movedAccounts < $maxNeeded) {
            $lefToMove = abs($maxNeeded - $movedAccounts);
            return back()->with('error', 'Unable to assign ' . $lefToMove . ' accounts, agents were missing following access rules: ' . $removeMessage . '. Accounts with those Access Rules: ' . $removedCount);
        } else {
            return back()->with('success', 'Successfully Updated Accounts');
        }


    }

    use AccountDistrubution;
    public function redistribute(Request $request)
    {

        $corporation_id = Auth::User()->corporation_manager_link->corporation_id;

        DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL
            WHERE `LAST_WORKED` IS NULL AND `TEAM_ID` = ' . $request->teamId . ';'));

        $this->setAgentQueueByTeam($request->teamId);

        $redistribution_record = new Redistribution_Record();
        $redistribution_record->corporation_id = $corporation_id;
        $redistribution_record->team_id = $request->teamId;
        $redistribution_record->save();

        return back()->with('success', 'Successfully Redistributed accounts');
    }
}
