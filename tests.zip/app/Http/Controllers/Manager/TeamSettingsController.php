<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use App\Models\Manager;
use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller; 
use App\Models\Team_Distribution_Rules;

class TeamSettingsController extends Controller
{ 
    public function teamSettings(){
        $manager = Manager::where('user_id', Auth::user()->user_id)->first();

        $team = Team::find($manager->team_id);

        $rules = Team_Distribution_Rules::where('team_id', $manager->team_id)->first();

        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;
        
        if($rules != null){
            //sets priorities for dropdowns
            $priority[] = $rules->priority;
            $priority[] = $rules->second_priority;
            $priority[] = $rules->third_priority;

            //sets value to checked if they were set as a priority
            if(in_array('ACCT_DUE_DATE', $priority))
                $preset[0] = 1;
            if(in_array('POESCORE', $priority))
                $preset[1] = 1;
            if(in_array('ACCT_SOURCE', $priority))
                $preset[2] = 1;
        }  
        else{
            $priority[] = "";
            $priority[] = "";
            $priority[] = "";
        }
        
        return view('manager.pages.teamSettings')->with('team', $team)->with('preset', $preset)->with('priority', $priority);
    }

    public function updateGoals(Request $request){
        $this->validate($request, [
            'new_goal' => 'required|numeric'
        ]);

        
        $team = Team::find(Auth::user()->manager_link->team_id);
        

        $team->team_goals = $request->input('new_goal');
        $team->save();

        return back()->with("success", "Goal Updated!");
    }

    public function updateAgentDistrubutionRules(Request $request){
        
        $this->validate($request, [
            'checked.*' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'priority' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'prioritySecond' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
        ]);

        $team_id = Auth::user()->manager_link->team_id;
        $rules = Team_Distribution_Rules::where('team_id', $team_id)->first();
        
        if($rules == null)
            $rules = new Team_Distribution_Rules;
        
        $rules->team_id = $team_id;

        //sets the priorities based on the number checked
        if(count($request->checked) == 1){
            $rules->priority = $request->checked[0];
            $rules->second_priority = null;
            $rules->third_priority = null;
        }
        else {
            $rules->priority = $request->priority;

            if(count($request->checked) == 2){
                if($request->priority != $request->checked[0])
                    $rules->second_priority = $request->checked[0];
                else
                    $rules->second_priority = $request->checked[1];

                $rules->third_priority = null;
            }
            if(count($request->checked) == 3){
                $rules->second_priority = $request->prioritySecond;
                $priorities[] = $request->priority;
                $priorities[] = $request->prioritySecond;

                if(!in_array('POESCORE', $priorities))
                    $rules->third_priority = 'POESCORE';
                else if(!in_array('ACCT_DUE_DATE', $priorities))
                    $rules->third_priority = 'ACCT_DUE_DATE';
                else
                    $rules->third_priority = 'ACCT_SOURCE';
            }
        }
            
        $rules->save();

        return back()->with('message', 'Priority Updated');

    }
}