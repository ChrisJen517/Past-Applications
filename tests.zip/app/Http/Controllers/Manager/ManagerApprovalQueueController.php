<?php

namespace App\Http\Controllers\Manager;

use App\Models\Active_Account;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class ManagerApprovalQueueController extends Controller
{
    public function showApprovalQueue()
    {
        $manager = Auth::user()->manager_link;
        $team_id = $manager->team_id;
        $corporation_id = $manager->corporation_id;
        
        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'pending_approval')->get();
        $approvals = [];

        foreach($capcodes as $capcode)
        {
            $approvals[] = $capcode->id;
        }
        $accounts = Active_Account::whereIn('CAPCODE', $approvals)->where('TEAM_ID', $team_id)->get();
        
        return view('manager.pages.approvalQueue')->with('accounts', $accounts);
    }
}
