<?php

namespace App\Http\Controllers\Manager;

use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Traits\DateUtils;
use App\User;
use DateTime;

class compPlanController extends Controller
{
    use DateUtils;

    public function showCompPlan(){
        $manager = Auth::user()->manager_link;
        $teamGoal = Team::where('team_id', $manager->team_id)->select('team_goals')->first()->team_goals;

        $start = date('01-m-Y');

        $reportData = $this->getData($manager, $start, date('Y-m-d' , strtotime(' +1 day')));
        $daysWorked = ceil($this->getWorkingDays($start, date('Y-m-d')));

        return view('manager.pages.compPlan')->with('teamGoal', $teamGoal)->with('reportData', $reportData)->with('daysWorked', $daysWorked);
    }


    public function getData($manager, $startTime, $endTime){
        $agents = Agent::where('team_id', $manager->team_id)->select('agent_id','user_id')->get();
        $capcodes = Capcode::where('corporation_id', $manager->corporation_id)->select('id')->where('type', 'verified')->get();

        $userIds = [];
        $agentIds = [];
        foreach($agents as $agent){
            $userIds[] = $agent->user_id;
            $agentIds[] = $agent->agent_id;
        }

        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        $accounts = Inactive_Account::wherein('ACCT_AGENT', $agentIds)->wherein('CAPCODE', $codes)
        ->select('ACCT_AGENT', 'CAPCODE')->where('UPDATED_AT', '>', $startTime)->where('UPDATED_AT', '<', $endTime)->get();
        $users = User::wherein('user_id', $userIds)->select('first_name', 'last_name', 'user_id')->get();

        $reportData = [];
        foreach($agents as $agent){
            $name = $users->where('user_id', $agent->user_id)->first();

            $verified = count($accounts->wherein('ACCT_AGENT', $agent->agent_id));

            $reportData[$agent->agent_id] = [
                'name' => $name->first_name.' '.$name->last_name,
                'verified' => $verified,
            ];
        }

        return $reportData;
    }
}
