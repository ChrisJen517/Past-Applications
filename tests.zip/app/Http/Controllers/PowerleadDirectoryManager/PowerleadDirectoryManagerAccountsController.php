<?php

namespace App\Http\Controllers\PowerleadDirectoryManager;

use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Http\Controllers\Controller;
use App\Models\old_passwords;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Capcode;
use App\Models\Powerlead_Directory_Manager;
use App\Traits\AccountDistrubution;
use App\Traits\DirectoryAgentAccounts;
use App\User;
use Carbon\Carbon;
use Auth;
use DB;
use Storage;
use File;
use Config;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use App\Jobs\PowerleadRedistributionQueue;
use App\RNNMailer;
use App\Traits\FindMinimumIds;
use Illuminate\Support\Facades\Log;
use App\Traits\MangeRoleAccounts;


class PowerleadDirectoryManagerAccountsController extends Controller
{
    use AccountDistrubution;
    use DirectoryAgentAccounts;
    use FindMinimumIds;
    use MangeRoleAccounts;

    public function showManageAccounts()
    {
        $users = User::selectRaw('users.user_id, users.first_name, users.last_name, users.email, users.role, users.is_deactivated, users.active, users.role_list, users.has_access')
        ->whereRaw('(users.role_list NOT LIKE "%admin%" AND users.role_list NOT LIKE "%manager%") AND (role = "directory_agent" or role = "powerlead")')
        ->with('directory_agent_link')->with('directory_agent_link')->with('powerlead_link')->get();
        $minimumDirectPower = $this->getMinimumPowerleadDirectoryID();

        return view('powerleadDirectoryManager.pages.manageAccounts')->with('users', $users)->with('minimumDirectPower', $minimumDirectPower);
    }

    public function addUser(Request $request)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|unique:users',
        ]);

        if(!empty($request->directory_agent_id)) {
            if(Directory_Agent::where('directory_agent_id', $request->directory_agent_id)->exists())
                return back()->with('error', "Agent ID is already in use");
        }
        if(!empty($request->powerlead_id)) {
            if(Powerlead::where('id', $request->powerlead_id)->exists())
                return back()->with('error', "Agent ID is already in use");
        }

        $role_list = $request->input('role_list');
        if($role_list == null){
            $role_list = [];
        }
        if(!in_array($request->input('role'), $role_list))
            $role_list[] = $request->input('role');
        $role_list = implode(',', $role_list);

        $user = new User();
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $token = rand(100000000000, 999999999999);
        $user->password = bcrypt($token);
        $user->role = $request->input('role');
        $user->password_valid = 0;
        $user->active = 1;
        $user->save();

        switch ($request->input('role')){
            case "directory_agent":
                $role = new Directory_Agent();
                $role->dir_account_type = $request->dir_account_type;
                $role->directory_agent_id = $request->directory_agent_id;
            break;
            case "powerlead":
                $role = new Powerlead();
                $role->id = $request->powerlead_id;
            break;
        }

        if($role != null){
            $role->user_id = $user->user_id;
            $role->save();
        }
        $this->AddRoleAccounts($user, null, null, null, $request->directory_agent_id, $request->powerlead_id);

        $path = '/home/rocky/public_html/ProfilePictures/'.$user->user_id.'';
        $env = Config::get('app.env');
        if ($env != 'prod') {
            $path = public_path('ProfilePictures/'.$user->user_id.'');
        }
        if (!file_exists($path)) {
            mkdir($path);
        }
        $file = File::get(public_path('ProfilePictures/baseAvatar.png'));
        File::put(public_path('ProfilePictures/' . $user->user_id . '/avatar.png'), $file);

        $mail = new RNNMailer(true, $user);

        //Recipients
        $mail->addAddress($request->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $request->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        return redirect()->back()->with('message', 'Account Created');
    }

    public function updateUser(Request $request)
    {
        $user = User::find($request->userId);
        if($user->role != 'powerlead' && $user->role != 'directory_agent'){
            return redirect()->back()->with('error', 'Access Denied');
        }
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
        ]);

        if(!empty($request->directory_agent_id)) {
            if(Directory_Agent::where('directory_agent_id', $request->directory_agent_id)->where('user_id', '!=', $request->idName)->exists())
                return back()->with('error', "Agent ID is already in use");
        }
        if(!empty($request->powerlead_id)) {
            if(Powerlead::where('id', $request->powerlead_id)->where('user_id', '!=', $request->idName)->exists())
                return back()->with('error', "Agent ID is already in use");
        }

        $role_list = $request->input('role_list');
        if($role_list == null){
            $role_list = [];
        }
        $role_list = implode(',', $role_list);
        $old_role_list = $user->role_list;

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;

        if ($request->newPassword != null) {
            $date = Carbon::now()->subDays(365)->format('Y-m-d');
            $passwordHistories = $user->passwordHistories()->where("created_at", '>', $date)->get();
            foreach ($passwordHistories as $passwordHistory) {
                echo $passwordHistory->password;
                if (Hash::check($request->get('newPassword'), $passwordHistory->password)) {
                    // The passwords matches
                    return redirect()->back()->with("error", "Your new password can not be same as any of your recent passwords. Please choose a new password.");
                }
            }

            $oldPassword = new old_passwords();
            $oldPassword->password = $user->password;
            $oldPassword->user_id = $user->user_id;
            $oldPassword->save();
            $user->password = bcrypt($request->newPassword);
            $user->password_valid = 1;
        }

        if($old_role_list != $role_list){
            $this->AddRoleAccounts($user, null, null, null, $request->directory_agent_id, $request->powerlead_id);

            //checks to see if there are any missing roles
            $old_role_list = explode(',', $old_role_list);
            $role_list = explode(',', $role_list);
            $missing_roles = [];
            foreach($old_role_list as $old_role){
                if(!in_array($old_role, $role_list))
                    $missing_roles[] = $old_role;
            }
            //deactivates any missing roles
            if(!empty($missing_roles)){
                $this->deactivateRoles($user, $missing_roles);
            }
            if(in_array($user->role, $missing_roles))
                $user->role = $role_list[0];
        }

        if($user->role == "directory_agent"){
            $directory_agent = Directory_Agent::where('user_id', $user->user_id)->first();
            $directory_agent->dir_account_type = $request->dir_account_type;
            $directory_agent->save();
        }

        $user->save();

        return redirect()->back()->with('message', 'Account Updated');

    }

    public function searchAccounts(Request $request)
    {

        $activeDirectories = Directory_Active_Account::where(function ($q) use ($request) {
            if ($request->name != null) {
                $q->where(function ($q) use ($request) {
                    $q->where('aka', 'like', '%' . $request->name . '%');
                    $q->orwhere('employer_name', 'like', '%' . $request->name . '%');
                });
            }
            if ($request->phone != null) {
                $q->where('direct_phone', $request->phone);
            }
            if ($request->directory_account_id != null) {
                $q->where('directory_account_id', $request->directory_account_id);
            }

        })->orderBy('last_worked', 'DESC')->paginate(100);

        $inactiveDirectories = Directory_Inactive_Account::where(function ($q) use ($request) {
            if ($request->name != null) {
                $q->where('aka', 'like', '%' . $request->name . '%');
                $q->orwhere('employer_name', 'like', '%' . $request->name . '%');
            }
            if ($request->phone != null) {
                $q->where('direct_phone', $request->phone);
            }
            if ($request->directory_account_id != null) {
                $q->where('directory_account_id', $request->directory_account_id);
            }

        })->orderBy('last_worked', 'DESC')->paginate(100);

        $powerleads = Powerlead_Accounts::where(function ($q) use ($request) {
            if ($request->name != null) {
                $q->orwhere('employer_name', 'like', '%' . $request->name . '%');
            }
            if ($request->phone != null) {
                $q->where('local_phone', $request->phone);
                $q->orWhere('main_phone', $request->phone);
            }
            if ($request->directory_account_id != null) {
                $q->where('id', $request->directory_account_id);
            }

        })->orderBy('updated_at', 'DESC')->paginate(100);

        $directoryCapcodes = Directory_Capcode::get();
        $powerleadCapcodes = Powerlead_Capcode::get();

        return view('powerleadDirectoryManager.pages.searchResults')->with('activeDirectories', $activeDirectories)
            ->with('inactiveDirectories', $inactiveDirectories)->with('powerleads', $powerleads)
            ->with('directoryCapcodes', $directoryCapcodes)->with('powerleadCapcodes', $powerleadCapcodes);
    }

    public function sendPasswordReset($id)
    {
        $User = User::find($id);
        if($User->role != 'powerlead' && $User->role != 'directory_agent'){
            return redirect()->back()->with('error', 'Access Denied');
        }
        $oldPassword = new old_passwords();
        $oldPassword->password = $User->password;
        $oldPassword->user_id = $User->user_id;
        $oldPassword->save();
        $token = rand(100000000000, 999999999999);
        $User->password = bcrypt($token);
        $User->password_valid = 0;
        $User->save();

        $mail = new RNNMailer(true, $User);

        //Recipients
        $mail->addAddress($User->email);

        // Content<p>{{  }}</p>
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $User->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        Log::debug("Password reset for: ".$User->first_name." ".$User->last_name." By: ".Auth::user()->first_name." ".Auth::user()->last_name);

        return back();

    }

    public function deleteUser($id)
    {
        $User = User::find($id);
        if($User->role != 'powerlead' && $User->role != 'directory_agent'){
            return redirect()->back()->with('error', 'Access Denied');
        }

        $name = $User->first_name . ' ' . $User->last_name;
        $User->active = 0;
        $User->is_deactivated = 1;
        $User->deactivate_date = Carbon::now();
        $User->save();

        $this->deactivateRoles($User, explode(',', $User->role_list));

        return back()->with('message', $name . ' was deactivated!');
    }

    public function reactivateUser($id)
    {
        $User = User::find($id);
        if($User->role != 'powerlead' && $User->role != 'directory_agent'){
            return redirect()->back()->with('error', 'Access Denied');
        }
        if ($User->role == 'powerlead') {
            $powerlead = Powerlead::where('user_id', $User->user_id)->first();
            $powerlead->active = 1;
            $powerlead->save();
        } else if ($User->role == 'directory_agent') {
            $DirectoryAgent = Directory_Agent::where('user_id', $User->user_id)->first();
            $DirectoryAgent->active = 1;
            $DirectoryAgent->save();
        }
        $name = $User->first_name . ' ' . $User->last_name;
        $User->active = 1;
        $User->is_deactivated = 0;
        $User->deactivate_date = NULL;
        $User->save();

        $this->AddRoleAccounts($User, null, null);

        return back()->with('message', $name . ' was reactivated!');
    }
}