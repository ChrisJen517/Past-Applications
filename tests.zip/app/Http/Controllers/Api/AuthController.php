<?php
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\User; 
use Illuminate\Support\Facades\Auth; 
use Validator;
class AuthController extends Controller 
{
 public $successStatus = 200;
  
 public function register(Request $request) {    
    $validator = Validator::make($request->all(), [ 
                'first_name' => 'required',
                'last_name' => 'required',
                'email' => 'required|email',
                'password' => 'required',  
                'role' => 'required',
                'password_valid' => 'required',
                'active' => 'required' 
        ]);     
    if ($validator->fails()) {          
        return response()->json(['error'=>$validator->errors()], 401);                        }    
    $input = $request->all();  
    $input['password'] = bcrypt($input['password']);
    $user = new User();       
    $user->first_name = $request->input('name');
    $user->last_name = $request->input('last_name');
    $user->email = $request->input('email');
    $user->password = bcrypt($request->input('password'));
    $user->role = $request->input('role');
    $user->password_valid = $request->input('password_valid');
    $user->active = $request->input('active');
    $user->save();
    $success['token'] =  $user->createToken('AppName')->accessToken;

    return response()->json(['success'=>$success], $this->successStatus); 
    }

    public function login(){ 
    if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){ 
    $user = Auth::user(); 
    $success['token'] =  $user->createToken('AppName')-> accessToken; 
        return response()->json(['success' => $success], $this-> successStatus); 
    } else{ 
    return response()->json(['error'=>'Unauthorised'], 401); 
    } 
    }

    
    public function getUser() 
    {
        $user = Auth::user();
        return response()->json(['success' => $user], $this->successStatus); 
    }

} 
