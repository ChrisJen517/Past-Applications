<?php
namespace App\Http\Controllers\Api;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use DB;
use Auth;


class CorporateAPIController extends Controller 
{
    public $successStatus = 200;

    public function corpLogin(request $request){ 
        if(Auth::attempt(['email' => request('email'), 'password' => request('password')])){ 
           $user = Auth::user();
           if($user->role = "corporate_api")
            { 
                $success['token'] =  $user->createToken('AppName')-> accessToken; 
                return response()->json(['success' => $success], $this-> successStatus);
            }
            else{
                return response()->json(['error'=>'Unauthorised'], 401); 
            }
          } else{ 
           return response()->json(['error'=>'Unauthorised'], 401); 
           } 
    }

    public function uploadInactive(Request $request)
    {
            $user = Auth::user();
            if($user->role != 'corporate_api')
            {
                return response()->json(['error'=>'Unauthorised'], 401); 

            }
                $ssn_string = '"'.$request->ssn.'"';
                $corporation_id = $user->corporate_api_link->corporation_id;
                $active_ssn = DB::select(DB::raw("SELECT * FROM active_accounts WHERE ACCT_SSN IN ($ssn_string) AND CORPORATION_ID = '$corporation_id';"));
            if($active_ssn == null)
            {
                return response()->json(['error'=> $request->ssn." SSN Doesn't Exist"], 401); 
            }
            else
            {
                DB::select(DB::raw("CALL move_to_inactive('$ssn_string', $corporation_id);"));
                $success = $request->ssn." SSN moved to inactive";
                return response()->json(['success'=>$success], $this->successStatus); 
            }      
    }
}