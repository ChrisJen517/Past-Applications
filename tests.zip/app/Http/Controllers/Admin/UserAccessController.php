<?php

namespace App\Http\Controllers\Admin;

use App\Models\Access_Levels;
use App\Http\Controllers\Controller;
use App\Traits\HasAccess;
use App\User;
use Illuminate\Http\Request;

class UserAccessController extends Controller
{
    use HasAccess;


    public function setUserAccess(Request $request)
    {
        // return $request->all();
        $list = '';
        foreach ($request->permissions as $permission) {
            $list = $list . $permission . ',';
        }

        $list = substr_replace($list, '', -1);
        return $list;

    }

    public function getAccessLevels(Request $request)
    { 
        $access_levels = Access_Levels::where('corporation_id', $request->corporation_id)->orderBy('id','asc')->get();

        $accessArray = [];
        foreach ($access_levels as $access) {
            $accessArray[$access->id] = [
                "id" => $access->id,
                "name" => $access->name,
                "shortcode" => $access->shortcode
            ];
        }
        echo json_encode($accessArray);
    }

}
