<?php

namespace App\Http\Controllers\Admin;

use App\Models\CorporateAdmin;
use App\Models\Manager;
use App\Models\Agent;
use App\Models\Corporation;
use App\Models\Message;
use App\Models\Message_Thread;
use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Controller;
use App\User;

class AdminSupportRequestController extends Controller
{
    public function allContact(){
        //gets the most recent thread's id
        $mostRecent = Message_Thread::orderByDesc("updated_at")->first();

        if($mostRecent == NULL)
            return view('manageContactUs.adminSide.allContact')->with('startID', -1)->with('startTime', -1);

        return view('manageContactUs.adminSide.allContact')->with('startID', $mostRecent->thread_id)->with('startTime', $mostRecent->updated_at);
    }

    public function allMessages($id){
        //loads all messages of the thread
        $title = Message_Thread::where('thread_id', $id)->first();
        
        //only updates it if the last read message was a client message
        if($title->answer_admin == 0){
            $title->answer_admin = 2;
            $title->save();
        }

        //gets the messages
        $messages = Message::where('thread_id', $id)->get();

        return view('manageContactUs.adminSide.messages')->with('messages', $messages)->with('title', $title->title);
    }

    public function allThreads(){
        //gets the thread ids belonging to the user
        $threads = Message_Thread::orderByDesc("updated_at")->get();

        return view('manageContactUs.adminSide.threads')->with('help', $threads);
    }

    public function findThread($search){
        //gets the thread ids belonging to the user
        $threads = Message_Thread::where('title','like','%'.$search.'%')->orderByDesc("updated_at")->get();

        return view('manageContactUs.adminSide.threads')->with('help', $threads);
    }

    public function newRequest(Request $request){
        $this->validate($request, [
            'supportRequestTitle' => 'required|max:50',
            'supportRequestMessage' => 'required|max:250',
        ]);

        $date = date('Y-m-d H:i:s');
        //creates the new thread
        $thread = new Message_Thread();
        $thread->user_id = $request->supportRequestUserId;
        $thread->title = $request->supportRequestTitle;
        $thread->answer_admin = 1;
        $thread->created_at = $date;
        $thread->updated_at = $date;
        $thread->save();

        //creates a new message for the new thread
        $message = new Message();
        $message->user_id = $request->supportRequestUserId;
        $message->message = $request->supportRequestMessage;
        $message->role = 'admin';
        $message->thread_id = $thread->thread_id;
        $message->save();

        return back()->with('success', 'Message sent');
    }

    //the funtion for allowing the user to send a response
    public function respondRequest(Request $request){
        $this->validate($request, [
            'message' => 'required|max:250'
        ]);
        //saves the message
        $message = new Message();
        $message->user_id = $request->userId;
        $message->message = $request->message;
        $message->role = 'admin';
        $message->thread_id = $request->thread_id;
        $message->save();

        //updates the thread updated at
        $thread = Message_Thread::find($request->thread_id);
        $thread->answer_admin = 1;
        $thread->updated_at= $message->created_at;
        $thread->save();
    }

    public function recentTime(){
        //returns the most recent message that a client gave
        echo Message_Thread::where('answer_admin', 0)->orderByDesc("updated_at")->first();
    }

    public function numberOfMessages(){
        //returns the most recent message that a client gave
        echo Message_Thread::where('answer_admin', 0)->count();
    }

    public function getCoporationNames()
    {
        $corporations = Corporation::get();

        return response()->json($corporations);
    }

    public function getAllUsers($id){
        $managers = Manager::select('user_id')->where('corporation_id', $id);
        $agents = Agent::select('user_id')->where('corporation_id', $id);
        $corporateAdmins = CorporateAdmin::select('user_id')->where('corporation_id', $id);

        $users = User::wherein('user_id', $managers)->orWhereIn('user_id', $agents)->orWherein('user_id', $corporateAdmins)->where('is_deactivated', 0)->orderby('role')->orderby('last_name')->get();

        return response()->json($users);
    }
}