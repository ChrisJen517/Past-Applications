<?php

namespace App\Http\Controllers\Admin\Directory;

use App\Models\Active_Account;
use Illuminate\Http\Request;
use App\Models\Directory_Agent;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Capcode;
use App\Models\Directory_Setting;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Traits\DirectoryAgentAccounts;
use DB;

class DirectoryHoldingQueueController extends Controller
{
    public function holdingQueue(){
        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->where('active', 1)->with('user_link')->get();

        if($agents->first() == null)
            return view('/admin/pages/directory/directoryHoldingQueue')->with('agents', null);

        $totals = Directory_Active_Account::select(DB::RAW('count(*) as total, count(if(last_worked is null, 1, null)) as unworked,
        count(if((live_flag = 1) AND (directory_agent_id IS NOT NULL), 1, null)) as directory_live_assigned,
        count(if((live_flag = 1) AND (directory_agent_id IS NULL), 1, null)) as directory_live_unassigned,
        count(if((fresh_flag = 1) AND (directory_agent_id IS NOT NULL), 1, null)) as directory_fresh_assigned,
        count(if((fresh_flag = 1) AND (directory_agent_id IS NULL), 1, null)) as directory_fresh_unassigned,
        count(IF((phone_verified = 1) AND (directory_agent_id IS NOT NULL), 1, null)) as phone_verified_assigned,
        count(IF((phone_verified = 1) AND (directory_agent_id IS NULL), 1, null)) as phone_verified_unassigned'))->first();
        $all = $totals->total;
        $directory_live['assigned'] = $totals->directory_live_assigned;
        $directory_live['unassigned'] = $totals->directory_live_unassigned;
        $directory_live['total'] = $totals->directory_live_unassigned + $totals->directory_live_assigned;
        $directory_fresh['assigned'] = $totals->directory_fresh_assigned;
        $directory_fresh['unassigned'] = $totals->directory_fresh_unassigned;
        $directory_fresh['total'] = $totals->directory_fresh_unassigned + $totals->directory_fresh_assigned;
        $phone_verified['assigned'] = $totals->phone_verified_assigned;
        $phone_verified['unassigned'] = $totals->phone_verified_unassigned;
        $phone_verified['total'] = $totals->phone_verified_unassigned + $totals->phone_verified_assigned;
        $worked = $totals->total - $totals->unworked;
        $unworked = $totals->unworked;

        $allAgentAccounts = Directory_Active_Account::select(DB::RAW(
            'directory_agent_id,
            count(if(last_worked is null, 1, null)) as unworked,
            count(if(last_worked is not null or last_worked != "", 1, null)) as worked'
        ))->groupBy('directory_agent_id')->get();

        $agentData = [];
        foreach($agents as $agent){
            if($agent->user_link->is_deactivated == 1)
                continue;

            $agentAccounts = $allAgentAccounts->where('directory_agent_id', $agent->directory_agent_id)->first();
            $agentWorked = $agentAccounts->worked ?? 0;
            $agentUnworked = $agentAccounts->unworked ?? 0;

            $agentData[$agent->directory_agent_id] = [
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'id' => $agent->directory_agent_id,
                'worked' => $agentWorked,
                'unworked' => $agentUnworked,
            ];
        }

        //grabs all timezone options
        $activeTimeZones = Active_Account::selectRaw('distinct(TIME_ZONE)')->whereNotNull('DIRECTORY_LINK')->whereNotNull('TIME_ZONE')->where('TIME_ZONE', '!=', '')->get();
        $timeZones = [];
        foreach($activeTimeZones as $zones){
            $timeZones[] = $zones->TIME_ZONE;
        }
        $inactiveTimeZones = Inactive_Account::selectRaw('distinct(TIME_ZONE)')->whereNotNull('DIRECTORY_LINK')->whereNotNull('TIME_ZONE')->where('TIME_ZONE', '!=', '')->whereNotIn('TIME_ZONE', $timeZones)->get();
        foreach($inactiveTimeZones as $zones){
            $timeZones[] = $zones->TIME_ZONE;
        }

        return view('/admin/pages/directory/directoryHoldingQueue')->with('all', $all)
        ->with('worked', $worked)->with('unworked', $unworked)
        ->with('directory_fresh', $directory_fresh)->with('phone_verified',$phone_verified)->with('directory_live', $directory_live)
        ->with('agents', $agentData)->with('timeZones', $timeZones);
    }

    use DirectoryAgentAccounts;
    public function redistribute(){
        DB::select(DB::raw('UPDATE `directory_active_accounts` SET `directory_agent_id` = NULL
                WHERE `LAST_WORKED` IS NULL AND directory_agent_id IS NOT NULL;'));
        $this->distributeDirectory();

        return back()->with('success', 'Accounts distributed to agents!');
    }

    public function tossAccounts(Request $request){
        if($request->toss_type == 'toQueue'){
            $this->validate($request, [
                'send_to_team' => 'required',
            ]);
            return $this->tossToQueue($request);
        }
        else{
            $this->validate($request, [
                'send_to_agent' => 'required',
            ]);
            return $this->tossToAgents($request);
        }
    }

    public function tossToAgents(Request $request){
        //sets up the where statements
        if($request->toss_type == 'agent')
            $whereStatements = " directory_agent_id = ".$request->agent_selected;
        else{ // means it is from the queue
            if($request->team_selected == 'fresh')// from the fresh queue
                $whereStatements = " directory_agent_id IS NULL AND fresh_flag = 1";
            else{ // from the verified phone queue
                $whereStatements = " directory_agent_id IS NULL AND phone_verified = 1";
            }
        }

        if($request->state_selected != ''){
            $whereStatements = $whereStatements." AND directory_active_accounts.state like '%".$request->state_selected."%'";
        }
        if($request->time_zone != ''){
            $whereStatements = $whereStatements." AND time_zone = '".$request->time_zone."'";
        }
        if($request->unworked_check){
            $whereStatements = $whereStatements." AND last_worked IS NULL";
        }

        //gets all the needed accounts
        $accounts = DB::SELECT(DB::RAW("SELECT distinct( directory_account_id) FROM directory_active_accounts
        WHERE ".$whereStatements." ORDER BY due_date asc;"));

        $sendAgents = $request->send_to_agent;
        $agentCounts = Directory_Active_Account::selectRaw('count(*) as totalAccounts, directory_agent_id')->whereIn('directory_agent_id', $sendAgents)->groupBy('directory_agent_id')->get();
        $maxForAllAgents = Directory_Setting::first()->max_accounts;
        //sets the max number of accounts
        if ($request->max_per_agent != null)
            $baseMax = $request->max_per_agent;
        else
            $baseMax = ceil(count($accounts)/count($sendAgents));

        //sets the array that holds the agents accounts
        $max = [];
        for($i = 0; $i < count($sendAgents); $i++){
            $agentAcounts[] = [];

            $totalAccounts = $agentCounts->where('directory_agent_id', $sendAgents[$i])->first()->totalAccounts ?? 0;
            $toTeamMax = $maxForAllAgents - $totalAccounts;
            if($toTeamMax < $baseMax)
                $max[] = $toTeamMax;
            else
                $max[] = $baseMax;
        }

        //variables set for looping
        $i = 0;
        $checkAllMax = 0;

        foreach($accounts as $account){
            startMaxCheck:

            if(count($agentAcounts[$i]) >= $max[$i]){
                $checkAllMax++;

                $i++;
                //checking to see if looped through all agents
                if ($i >= count($sendAgents)) {
                    $i = 0;
                }

                if($checkAllMax >= count($sendAgents))
                    break;
                else
                    goto startMaxCheck;
            }
            else{
                $checkAllMax = 0;
            }

            $agentAcounts[$i][] = $account->directory_account_id;

            $i++;
            //checking to see if looped through all agents
            if ($i >= count($sendAgents)) {
                $i = 0;
            }
        }

        //updates the database
        for ($i = 0; $i < count($sendAgents); $i++) {
            if (!empty($agentAcounts[$i])) {
                $accountIds = implode(',', $agentAcounts[$i]);
                DB::select(DB::raw('UPDATE `directory_active_accounts` SET `directory_agent_id` = ' . $sendAgents[$i] . ', UPDATED_AT = NOW()
                                    WHERE `directory_account_id` IN (' . $accountIds . ');'));
            }
        }

        return back()->with('success', 'Accounts tossed to agents!');
    }

    public function tossToQueue(Request $request){
        //sets up the where statements
        $whereStatements = " directory_agent_id = ".$request->agent_selected;
        if($request->state_selected != ''){
            $whereStatements = $whereStatements." AND directory_active_accounts.state like '%".$request->state_selected."%'";
        }
        if($request->time_zone != ''){
            $whereStatements = $whereStatements." AND time_zone = '".$request->time_zone."')";
        }
        if($request->unworked_check){
            $whereStatements = $whereStatements." AND last_worked IS NULL";
        }

        //sets a limit if there is one
        $limitStatement = '';
        if($request->max_per_agent)
            $limitStatement = "LIMIT ".$request->max_per_agent;

        //updates all the needed accounts
        DB::SELECT(DB::RAW("UPDATE directory_active_accounts SET `directory_agent_id` = NULL WHERE ".$whereStatements. ' ' .$limitStatement.";"));

        return back()->with('success', 'Accounts tossed to queue!');
    }
}
