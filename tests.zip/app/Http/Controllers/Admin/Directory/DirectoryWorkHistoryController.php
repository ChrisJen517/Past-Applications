<?php

namespace App\Http\Controllers\Admin\Directory;

use Illuminate\Http\Request;
use App\User;
use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Work_History;
use App\Http\Controllers\Controller;
use DateTime;
use Carbon\Carbon;

class DirectoryWorkHistoryController extends Controller
{
    public function followups(Request $request) {
        if (empty($request->startTime)) {
            $startTime = Carbon::now()->format('Y-m-d');
        } else {
            $startTime = Carbon::parse($request->startTime)->format('Y-m-d');
        }

        if ($startTime == date('Y-m-d'))
            $timeMessage = "from today";
        else
            $timeMessage = "from $startTime";

        $endTime = Carbon::parse($startTime)->addDay()->format('Y-m-d');

        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->with('user_link')->get();

        if($agents->first() == null)
            return view('/admin/pages/directory/directoryFollowups')->with('workedHistory', []);

        $capcodes = Directory_Capcode::select('capcode_id', 'capcode')->where('type', 'inconclusive')->whereNotIn('capcode', [2224, 2225])->get();
        $capcodeArray = array_column($capcodes->toArray(), 'capcode_id');

        $histories = Directory_Work_History::select('verification_notes', 'work_notes', 'directory_account_id', 'created_at', 'capcode', 'worker_id')
        ->where('created_at', '>=', $startTime)
        ->where('created_at', '<=', $endTime)
        ->where('worker_role', 'directory_agent')
        ->whereIn('capcode', $capcodeArray)
        ->get();

        $workedHistory = [];
        foreach($histories as $history) {
            $assigned = $history->worked_id;

            if ($history->worker_id != null) {
                $agent = $agents->where('directory_agent_id', $history->worker_id)->first();

                if ($agent != null) {
                    $user = $agent->user_link;
                    $assigned = $history->worker_id.": ".$user['first_name']." ".$user['last_name'];
                }
            }

            $foundCapcode = $capcodes->where('capcode_id', $history->capcode)->first();
            if ($foundCapcode != null)
                $capcode = $foundCapcode->capcode;
            else
                $capcode = $history->capcode;

            $workedHistory[] = [
                'agent' => $assigned,
                'capcode' => $capcode,
                'last_worked' => $history->created_at,
                'notes' => $history->verification_notes,
                'notes_worked' => $history->work_notes,
                'id' => $history->directory_account_id
            ];
        }

        return view('/admin/pages/directory/directoryFollowups')->with('workedHistory', $workedHistory)->with('capcodes', $capcodes)->with('timeMessage', $timeMessage);
    }
}
