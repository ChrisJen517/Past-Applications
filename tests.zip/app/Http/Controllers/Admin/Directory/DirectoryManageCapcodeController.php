<?php

namespace App\Http\Controllers\Admin\Directory;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Capcode;
use App\Models\Directory_Capcode;
use Auth;
use App\Models\Corporation;

class DirectoryManageCapcodeController extends Controller
{

    private $requiredCapcodes = array(
        '1103', '1104', '1116', '1118', '1122', '1110', '1111', '1119', '1120', '1121', '1113', '1114', //verified
        '2224', '2225', //inconclusive
        '3400', '4408', '4411', '6000' //unverified
    );
    
    public function showCapcodeManagementDirectory()
    {
        $verifieds = Directory_Capcode::where('type', 'verified')->get();
        $inconclusives = Directory_Capcode::where('type', 'inconclusive')->get();
        $unverifieds = Directory_Capcode::where('type', 'unverified')->get();
        return view('admin.pages.directory.directoryCapcodeManagement')->with('verifieds', $verifieds)->with('inconclusives', $inconclusives)->with('unverifieds', $unverifieds)->with('requiredCapcodes', $this->requiredCapcodes);
    }

    public function addAdminCapcodeDirectory(Request $request)
    {
        $this->validate($request, [
            'capcode' => 'required',
            'name' => 'required|max:255',
            'type' => 'required'
        ]);

        if(Directory_Capcode::where('capcode', $request->capcode)->exists())
        {
            return redirect()->back()->with('error', 'This capcode is in use.');
        }

        $capcode = new Directory_Capcode();
        $capcode->capcode = $request->capcode;

        $capcode->name = $request->name;
        $capcode->description = $request->description;
        $capcode->type = $request->type;
        if($request->type == 'verified')
            $capcode->profile_type = $request->profile_type;
        else
            $capcode->profile_type = null;
        $capcode->save();


        return redirect()->back()->with('success', 'Capcode added successfully');
    }

    public function updateAdminCapcodeDirectory(Request $request)
    {

        $id = $request->capcode_id;

        $this->validate($request, [
            'capcode' => 'required',
            'name' => 'required|max:255',
            'type' => 'required'
        ]);

        if(Directory_Capcode::where('capcode', $request->capcode)->where('capcode_id', '!=', $request->capcode_id)->exists())
        {
            return redirect()->back()->with('error', 'This capcode is in use.');
        }

        $capcode = Directory_Capcode::where('capcode_id', $request->capcode_id)->first();
        $capcode->capcode = $request->capcode;
        $capcode->name = $request->name;
        $capcode->description = $request->description;
        $capcode->type = $request->type;
        if($request->type == 'verified')
            $capcode->profile_type = $request->profile_type;
        else
            $capcode->profile_type = null;
        $capcode->save();

        return redirect()->back()->with('success', 'Capcode updated successfully');
    }

    public function archiveCapcodeDirectory($id)
    {
        $capcode = Directory_Capcode::find($id);

        $capcode->is_archived = ($capcode->is_archived == 0 ? 1 : 0);
        $capcode->save();

        return redirect()->back()->with('message', 'Capcode successfully ' . ($capcode->is_archived == 0 ? 'un' : '') . 'archived');
    }
}