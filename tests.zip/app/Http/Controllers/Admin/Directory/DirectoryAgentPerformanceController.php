<?php

namespace App\Http\Controllers\Admin\Directory;

use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Work_History;
use App\Http\Controllers\Controller;
use App\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use App\Traits\DateUtils;

class DirectoryAgentPerformanceController extends Controller
{
    use DateUtils;

    public function seeReport()
    {
        $data = $this->getData('all', date("Y-m-d"), date("Y-m-d", strtotime("+1 day")));

        if ($data == null) {
            return view('/admin/pages/directory/directoryAgentPerformance')->with('data', null)->with('agents', null)->with('timeMessage', null)->with('compare', null);
        }

        $agents = $this->getUserList();

        $message = "from today";

        return view('/admin/pages/directory/directoryAgentPerformance')->with('data', $data)->with('agents', $agents)->with('timeMessage', $message)->with('compare', $data['comparison']);
    }

    public function seeReportTime(Request $request)
    {
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        $message = "from: " . $startTime . " to " . $endTime;
        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $data = $this->getData($request->agent, $startTime, $endTime);
        $agents = $this->getUserList();

        return view('/admin/pages/directory/directoryAgentPerformance')->with('data', $data)->with('agents', $agents)->with('timeMessage', $message)->with('compare', $data['comparison']);
    }

    public function getData($agentId, $startTime, $endTime)
    {
        if ($agentId == "all") {
            $agents = Directory_Agent::select('directory_agent_id', 'user_id')->where('created_at', '<', $endTime)->with('user_link')->get();
        } else {
            $agents = Directory_Agent::where('directory_agent_id', $agentId)->select('directory_agent_id', 'user_id')->get();
        }

        if ($agents->first() == null) {
            return null;
        }

        //gets all accounts
        $activeAccounts = Directory_Active_Account::selectRaw("count(*) as totalUses, directory_agent_id, directory_capcodes.capcode, directory_capcodes.type")
        ->leftJoin('directory_capcodes', function ($join) {
            $join->on('directory_capcodes.capcode_id', '=', 'directory_active_accounts.capcode');
        })
        ->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime)->groupBy('directory_agent_id')->groupBy('directory_capcodes.capcode')->get();
        $inactiveAccounts = Directory_Inactive_Account::selectRaw("count(*) as totalUses, directory_agent_id, directory_capcodes.capcode, directory_capcodes.type")
        ->leftJoin('directory_capcodes', function ($join) {
            $join->on('directory_capcodes.capcode_id', '=', 'directory_inactive_accounts.capcode');
        })
        ->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime)->groupBy('directory_agent_id')->groupBy('directory_capcodes.capcode')->get();

        $followups = Directory_Work_History::where('created_at', '>', $startTime)->where('created_at', '<', $endTime)
        ->where('worker_id', '!=', null)->where('worker_role', 'directory_agent')
        ->SELECT(DB::raw('count(*) as count, worker_id, directory_account_id'))
        ->groupBy('directory_account_id')->groupBy('worker_id')->get();

        //Get the count of each unique call - This should exclude repeated calls to the same number in the same hour
        $callsMade = collect(DB::select(DB::raw("SELECT
            worker_id,
            COUNT(DISTINCT CONCAT(worker_id, '||', verification_notes,
                    '||', directory_account_id, '||', MONTH(CREATED_AT),
                    '-', DAY(CREATED_AT), '-', YEAR(CREATED_AT),
                    '-', HOUR(CREATED_AT))) AS calls_made
        FROM
            directory_work_history
        WHERE
            verification_notes LIKE 'Made a call to:%'
            AND created_at BETWEEN DATE('".$startTime."') AND DATE('".$endTime."')
        GROUP BY worker_id;")));

        $finalData = [];
        $capcodeUse = [];

        $totalUses['verified'] = 0;
        $totalUses['unverified'] = 0;
        $totalUses['inconclusive'] = 0;

        $hoursWorked = $this->getHours($startTime, $endTime);
        if($hoursWorked == 0)
            $hoursWorked = 0.01;

        foreach ($agents as $agent) {
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agentCounts['verified'] = 0;
            $agentCounts['unverified'] = 0;
            $agentCounts['inconclusive'] = 0;

            $unworked = $activeAccounts->where('directory_agent_id', $agent->directory_agent_id)->where('capcode', null)->first()->totalUses ?? 0;
            $userActive = $activeAccounts->where('directory_agent_id', $agent->directory_agent_id)->where('capcode', '!=', null);
            $userInactive = $inactiveAccounts->where('directory_agent_id', $agent->directory_agent_id)->where('capcode', '!=', null);

            //gets the totals for the capcodes and the types
            foreach($userActive as $active){
                $agentCounts[$active->type] += $active->totalUses;
                $totalUses[$active->type] += $active->totalUses;

                if(!array_key_exists($active->capcode, $capcodeUse)) {
                    $capcodeUse[$active->capcode] = [
                        'capcode' => $active->capcode,
                        'count' => $active->totalUses,
                        'type' => $active->type,
                    ];
                } else {
                    $capcodeUse[$active->capcode]['count'] += $active->totalUses;
                }
            }
            foreach($userInactive as $inactive){
                $agentCounts[$inactive->type] += $inactive->totalUses;
                $totalUses[$inactive->type] += $inactive->totalUses;

                if (!array_key_exists($inactive->capcode, $capcodeUse)) {
                    $capcodeUse[$inactive->capcode] = [
                        'capcode' => $inactive->capcode,
                        'count' => $inactive->totalUses,
                        'type' => $inactive->type,
                    ];
                } else {
                    $capcodeUse[$inactive->capcode]['count'] += $inactive->totalUses;
                }
            }

            //gets the number of followups made for an account
            $agentFollowups = $followups->where('worker_id', $agent->directory_agent_id)->where('count', '>', 1);
            $followupCount = 0;
            foreach($agentFollowups as $agentFollowup){
                $followupCount = $followupCount + $agentFollowup->count - 1;
            }

            $agentCall = $callsMade->where('worker_id', $agent->directory_agent_id)->first()->calls_made ?? 0;

            $agentData[$agent->directory_agent_id] = [
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'id' => $agent->directory_agent_id,
                'followup' => $followupCount,
                'unworked' => $unworked,
                'inconclusive' => $agentCounts['inconclusive'],
                'unverified' => $agentCounts['unverified'],
                'verified' => $agentCounts['verified'],
                'callsMade' => $agentCall,
                'hoursWorked' => $hoursWorked,
                'averageCalls' => round($agentCall/$hoursWorked, 2),
            ];
        }

        //compiles into an array to an array to 
        $finalData[] = $agentData;
        $finalData[] = $capcodeUse;
        $finalData[] = $totalUses;
        $finalData['comparison'] = $this->agentComparison($activeAccounts, $inactiveAccounts, $startTime, $endTime);

        return $finalData;
    }

    public function getUserList()
    {
        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->where('active', 1)->with('user_link')->get();
        $agentData = [];
        foreach ($agents as $agent) {
            $agentData[$agent->directory_agent_id] = [
                'id' => $agent->directory_agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
            ];
        }

        return $agentData;
    }

    public function agentComparison($activeAccounts, $inactiveAccounts, $startTime, $endTime)
    {
        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->where('created_at', '<', $endTime)->with('user_link')->get();

        $agentData = [];
        foreach ($agents as $agent) {
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $userActive = $activeAccounts->where('directory_agent_id', $agent->directory_agent_id)->where('capcode', '!=', null);
            $userInactive = $inactiveAccounts->where('directory_agent_id', $agent->directory_agent_id)->where('capcode', '!=', null);

            $agentCounts['verified'] = 0;
            $agentCounts['unverified'] = 0;
            $agentCounts['inconclusive'] = 0;

            foreach($userActive as $active){
                $agentCounts[$active->type] += $active->totalUses;
            }
            foreach($userInactive as $inactive){
                $agentCounts[$inactive->type] += $inactive->totalUses;
            }
            
            $total = $agentCounts['inconclusive']+$agentCounts['unverified']+$agentCounts['verified'];
            if($total != 0 ){
                $agentData[] = [
                    'name' => $agent->user_link->first_name . ' ' . $agent->user_link->last_name,
                    'inconclusive' => $agentCounts['inconclusive'],
                    'unverified' => $agentCounts['unverified'],
                    'verified' => $agentCounts['verified'],
                ];
            }
        }

        return $agentData;
    }

    public function gethours($startTime, $endTime){
        $daysWorked = $this->getWorkingDays($startTime, $endTime);
        $daysWorked--; // endTime is 1 day after the chosen date.
        if (date("Y-m-d", strtotime($endTime. ' -1 day')) == date("Y-m-d")){
            $daysWorked--; // subtract a full day if the end time is the current date (so we can add hours up to 8)
            $hoursWorked = $daysWorked * 8;

            $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
            $hoursSinceStart = $minutesSinceStart/60;
            if ($hoursSinceStart > 8 || $hoursSinceStart < 0)
                $hoursSinceStart = 8;

            $hoursWorked += $hoursSinceStart;
        }
        else{
            $hoursWorked = $daysWorked * 8;
        }

        $hoursWorked = round($hoursWorked, 2);

        return $hoursWorked;
    }
}