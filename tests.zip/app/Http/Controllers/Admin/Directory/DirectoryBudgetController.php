<?php

namespace App\Http\Controllers\Admin\Directory;

use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Setting;
use App\Http\Controllers\Controller;
use App\Traits\DateUtils;
use Illuminate\Http\Request;
use DB;

class DirectoryBudgetController extends Controller
{

    use DateUtils;

    public function getBudget()
    {
        $months = $this->getData();
        $directory = Directory_Setting::first();
        if (empty($directory)) {
            $cost = 0;
        } else {
            $cost = $directory->cost;
        }
        return view('/admin/pages/directory/directoryBudgetPerformance')->with('months', $months)->with('cost', $cost);
    }

    public function changeCost(Request $request)
    {
        $cost = Directory_Setting::first();
        $cost->cost = $request->cost;
        $cost->save();

        return redirect('/admin/directory/budget');
    }

    public function getData()
    {
        //gets the first of each month, and tommorow
        $dates[] = date('Y-m-d', strtotime('first day of this months - 5 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 4 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 3 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 2 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 1 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months'));
        $dates[] = date('Y-m-d', strtotime('+1 day'));

        //gets all verified capcodes, along with the fax and email capcodes 
        $codes = Directory_Capcode::where('type', 'verified')->select('capcode_id', 'capcode', 'profile_type')->get();
        $verified = [];
        $faxCode = [];
        $emailCode = [];
        foreach ($codes as $code) {
            $verified[] = $code->capcode_id;
            switch ($code->profile_type){
                case 'fax_profile':
                    $faxCode[] = $code->capcode_id;
                break;
                case 'email_profile':
                    $emailCode[] = $code->capcode_id;
                break;
            }
        }

        //gets all of the agent accounts
        $Allagents = Directory_Agent::with('user_link')->get();

        //gets the totals of the verifed accounts, and of the ones via call and email
        $inactiveAccounts = Directory_Inactive_Account::select(DB::raw("count(*) as verified, month(last_worked) as month,
        count(IF(capcode in (".implode(',', $faxCode).") ,1,null)) as faxes,
        count(IF(capcode in (".implode(',', $emailCode)."),1,null)) as emails"))
        ->where('last_worked', '>', $dates[0])->where('last_worked', '<', $dates[6])
        ->whereIn('capcode', $verified)->groupBy(DB::raw('month(last_worked)'))->get();

        //resets the date to be more accurate on the day count
        $dates[7] = date('Y-m-d');

        $finaldata = [];
        for ($i = 0; $i < 6; $i++) {
            //gets the number of active agents in the month
            $agents = $Allagents->where('created_at', '<', $dates[$i + 1]);
            $agentCount = 0;
            foreach ($agents as $agent) {
                if (($agent->user_link->deactivate_date < $dates[$i]) && ($agent->user_link->is_deactivated == 1)) {
                    continue;
                } else {
                    $agentCount++;
                }

            }

            //gets the number of working days in the month
            $days = $this->getWorkingDays($dates[$i], $dates[$i + 1]);

            //gets the counts of all the month before putting it into an array
            $currentMonths = $inactiveAccounts->where('month', date('m', strtotime($dates[$i])))->first();
            if(empty($currentMonths)){
                $faxes = 0;
                $email = 0;
                $verifiedTotal = 0;
            }
            else{
                $faxes = $currentMonths->faxes;
                $email = $currentMonths->emails;
                $verifiedTotal = $currentMonths->verified;
            }
            
            $percent = $faxes + $email;
            if ($verifiedTotal != 0) {
                $percent = round($percent / $verifiedTotal, 2);
            }

            $finaldata[] = array(
                date('F', strtotime($dates[$i])),
                $days,
                $agentCount,
                $faxes,
                $email,
                $verifiedTotal,
                $percent,
            );
        }

        return $finaldata;
    }
}
