<?php

namespace App\Http\Controllers\Admin\Directory;

use App\Http\Controllers\Controller;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use Illuminate\Support\Facades\DB;

class DirectoryQueueReportController extends Controller
{

    public function queueByTimezone() {
        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->where('active', 1)->with('user_link')->get();

        if($agents->first() == null)
            return view('/admin/pages/directory/queueByTimezone')->with('totalData', null);

        $timezones = ['EST', 'PST', 'CST', 'MST', 'AKST', 'AST', 'HST'];

        $queryString = 'count(if(fresh_flag = 1 AND directory_agent_id is NULL, 1, NULL)) as fresh_total,
        count(if(phone_verified = 1 AND directory_agent_id is NULL, 1, NULL)) as phone_total,
        count(if(fresh_flag = 1 AND directory_agent_id is NULL and (time_zone is NULL or time_zone=""), 1, NULL)) as fresh_NF,
        count(if(phone_verified = 1 AND directory_agent_id is NULL and (time_zone is NULL or time_zone=""), 1, NULL)) as phone_NF,';
        $i = 1;
        foreach($timezones as $timezone) {
            $queryString .= "count(if((fresh_flag = 1) AND (time_zone='${timezone}') AND directory_agent_id IS NULL, 1, null)) as fresh_${timezone},
            count(IF((phone_verified = 1) AND (time_zone='${timezone}') AND directory_agent_id IS NULL, 1, null)) as phone_${timezone}" . ($i < count($timezones) ? ',' : '');
            $i++;
        }

        $totals = Directory_Active_Account::select(DB::RAW($queryString))->first();
        $totalData = [];

        $totalData['fresh'] = [
            'id' => 'N/A',
            'name' => 'Directory Fresh Queue',
            'totalActive' => $totals->fresh_total,
            'EST' => $totals->fresh_EST,
            'PST' => $totals->fresh_PST,
            'CST' => $totals->fresh_CST,
            'MST' => $totals->fresh_MST,
            'AKST' => $totals->fresh_AKST,
            'AST' => $totals->fresh_AST,
            'HST' => $totals->fresh_HST,
            'NF' =>  $totals->fresh_NF
        ];

        $totalData['phone'] = [
            'id' => 'N/A',
            'name' => 'Phone Verified Queue',
            'totalActive' => $totals->phone_total,
            'EST' => $totals->phone_EST,
            'PST' => $totals->phone_PST,
            'CST' => $totals->phone_CST,
            'MST' => $totals->phone_MST,
            'AKST' => $totals->phone_AKST,
            'AST' => $totals->phone_AST,
            'HST' => $totals->phone_HST,
            'NF' =>  $totals->phone_NF
        ];

        $allAgentAccounts = Directory_Active_Account::select(DB::RAW(
            'directory_agent_id,
            count(*) as total,
            count(if(time_zone="EST", 1, NULL)) as EST,
            count(if(time_zone="PST", 1, NULL)) as PST,
            count(if(time_zone="CST", 1, NULL)) as CST,
            count(if(time_zone="MST", 1, NULL)) as MST,
            count(if(time_zone="AKST", 1, NULL)) as AKST,
            count(if(time_zone="AST", 1, NULL)) as AST,
            count(if(time_zone="HST", 1, NULL)) as HST,
            count(if(time_zone is NULL or time_zone="", 1, NULL)) as NF'
        ))->groupBy('directory_agent_id')->get();

        foreach($agents as $agent){
            if($agent->user_link->is_deactivated == 1)
                continue;

            $agentAccount = $allAgentAccounts->where('directory_agent_id', $agent->directory_agent_id)->first();
            if (empty($agentAccount)) {
                $totalData[$agent->directory_agent_id] = [
                    'id' => $agent->directory_agent_id,
                    'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                    'totalActive' => 0,
                    'EST' => 0,
                    'PST' => 0,
                    'CST' => 0,
                    'MST' => 0,
                    'AKST' => 0,
                    'AST' => 0,
                    'HST' => 0,
                    'NF' => 0
                ];
            } else {
                $totalData[$agent->directory_agent_id] = [
                    'id' => $agent->directory_agent_id,
                    'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                    'totalActive' => $agentAccount->total,
                    'EST' => $agentAccount->EST,
                    'PST' => $agentAccount->PST,
                    'CST' => $agentAccount->CST,
                    'MST' => $agentAccount->MST,
                    'AKST' => $agentAccount->AKST,
                    'AST' => $agentAccount->AST,
                    'HST' => $agentAccount->HST,
                    'NF' => $agentAccount->NF
                ];
            }
        }

        return view('/admin/pages/directory/queueByTimezone')->with('totalData', $totalData);
    }

}
