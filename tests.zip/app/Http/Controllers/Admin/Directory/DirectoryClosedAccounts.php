<?php

namespace App\Http\Controllers\Admin\Directory;

use Illuminate\Http\Request;
use Carbon\Carbon;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Http\Controllers\Controller;
use Yajra\DataTables\Facades\DataTables;

class DirectoryClosedAccounts extends Controller
{
    public function showClosed(Request $request)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        if ($request->from == null)
            $startTime = date("Y-m-d", strtotime("-0 day"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if ($request->to == null)
            $endTime = date("Y-m-d", strtotime("+1 day"));
        else
            $endTime = date('Y-m-d', strtotime($request->to . " +1 day"));

        $endTime = Carbon::parse($endTime)->subDay(1)->format('m/d/Y');
        $startTime = Carbon::parse($startTime)->format('m/d/Y');

        return view('admin.pages.directory.inactiveAccounts')->with('startTime', $startTime)->with('endTime', $endTime);
    }

    public function getVerifiedTable(Request $request) {
        ini_set('memory_limit', '1024M');
        $startTime = Carbon::parse($request->startTime)->format('Y-m-d');
        $endTime = Carbon::parse($request->endTime)->format('Y-m-d');

        $verifiedCapcodes = Directory_Capcode::where('type', 'verified')->get();

        $verifiedCodes = [];
        foreach ($verifiedCapcodes as $capcode) {
            $verifiedCodes[] = $capcode->capcode_id;
        }
        $verifiedCodesImploded = implode(',', $verifiedCodes);

        $verifiedClosed = Directory_Inactive_Account::
            selectRaw("created_at, directory_account_id, directory_agent_id, employer_name, time_zone, direct_phone, empl_org_phone, DATE_FORMAT(last_worked, '%m/%d/%Y') as last_worked, aka, capcode")
            ->whereRaw("capcode in ($verifiedCodesImploded) AND last_worked >= DATE('$startTime') AND last_worked < DATE('$endTime')")
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();

        return DataTables::of($verifiedClosed)->make(true);
    }

    public function getInconclusiveTable(Request $request) {
        ini_set('memory_limit', '1024M');
        $startTime = Carbon::parse($request->startTime)->format('Y-m-d');
        $endTime = Carbon::parse($request->endTime)->format('Y-m-d');

        $inconclusiveCapcodes = Directory_Capcode::where('type', 'inconclusive')->get();

        $inconclusiveCodes = [];
        foreach ($inconclusiveCapcodes as $capcode) {
            $inconclusiveCodes[] = $capcode->capcode_id;
        }
        $inconclusiveCodesImploded = implode(',', $inconclusiveCodes);

        $inconclusiveClosed = Directory_Inactive_Account::
            selectRaw("created_at, directory_account_id, directory_agent_id, employer_name, time_zone, direct_phone, empl_org_phone, DATE_FORMAT(last_worked, '%m/%d/%Y') as last_worked, aka, capcode")
            ->whereRaw("capcode in ($inconclusiveCodesImploded) AND last_worked >= DATE('$startTime') AND last_worked < DATE('$endTime')")
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();

        return DataTables::of($inconclusiveClosed)->make(true);
    }

    public function getUnverifiedTable(Request $request) {
        ini_set('memory_limit', '1024M');
        $startTime = Carbon::parse($request->startTime)->format('Y-m-d');
        $endTime = Carbon::parse($request->endTime)->format('Y-m-d');

        $unverifiedCapcodes = Directory_Capcode::where('type', 'unverified')->get();

        $unverifiedCodes = [];
        foreach ($unverifiedCapcodes as $capcode) {
            $unverifiedCodes[] = $capcode->capcode_id;
        }
        $unverifiedCodesImploded = implode(',', $unverifiedCodes);

        $unverifiedClosed = Directory_Inactive_Account::
            selectRaw("created_at, directory_account_id, directory_agent_id, employer_name, time_zone, direct_phone, empl_org_phone, DATE_FORMAT(last_worked, '%m/%d/%Y') as last_worked, aka, capcode")
            ->whereRaw("capcode in ($unverifiedCodesImploded) AND last_worked >= DATE('$startTime') AND last_worked < DATE('$endTime')")
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();

        return DataTables::of($unverifiedClosed)->make(true);
    }
}
