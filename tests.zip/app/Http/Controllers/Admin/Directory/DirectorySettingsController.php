<?php

namespace App\Http\Controllers\Admin\Directory;

use Illuminate\Http\Request;
use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Setting;
use App\Http\Controllers\Controller;
use App\Traits\DirectoryAgentAccounts;

class DirectorySettingsController extends Controller
{
    public function getSettings(){
        $settings = Directory_Setting::first();

        if($settings == null){
            $settings = new Directory_Setting();
            $settings->max_accounts = 50;
            $settings->max_attempts = 5;
            $settings->live_max_attempts = 3;
            $settings->redistribute_accounts = 1;
            $settings->save();
        }

        return view('/admin/pages/directory/directorySettings')->with('settings', $settings);
    }

    public function updateSettings(Request $request){

        $settings = Directory_Setting::first();

        if($settings == null)
            $settings = new Directory_Setting();

        $settings->max_accounts = $request->max_accounts;
        $settings->max_attempts = $request->max_attempts;
        $settings->live_max_attempts = $request->live_max_attempts;
        $settings->redistribute_accounts = $request->redistribute_accounts;
        $settings->save();

        return back()->with('success', "Settings updated!");
    }
}