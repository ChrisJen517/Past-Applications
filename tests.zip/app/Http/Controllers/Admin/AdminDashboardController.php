<?php

namespace App\Http\Controllers\Admin;

use App\Models\Activity_Log;
use App\Models\Corporation;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use DB;

class AdminDashboardController extends Controller
{
    public function dashboard()
    {
        $weekArray = array();
        $corporations = Corporation::get();
        $corpTotalArray = [];
        $corpDayArray = [];
        for ($i = 6; $i >= 0; $i--) {
            $weekArray[] = Carbon::now()->sub($i . 'days')->toDateString();
        }
        $logArray = array();
        $rnnArray = [];

        //loop through days of week and set values for all reports
        for ($i = 0; $i < count($weekArray); $i++) {
            $log = Activity_Log::Select(DB::RAW('SEC_TO_TIME(SUM(TIME_TO_SEC(total_time))) as timeSum'))->where('date', $weekArray[$i])->first();
            
            $rnnLog = Activity_Log::select(DB::RAW('SEC_TO_TIME(SUM(TIME_TO_SEC(total_time))) as timeSum'))
            ->join('users', 'users.user_id', 'activity_logs.user_id')
            ->where('date', $weekArray[$i])
            ->whereIn('role', ['admin', 'directory_agent', 'powerlead'])->first(); 
            
            $logArray[] = $log->timeSum;
            $rnnArray[] = $rnnLog->timeSum;
            if($corporations->isEmpty() == true){
                $corpDayArray[] = 0.0;
            }
            foreach ($corporations as $corporation) {
                $corpTotal = Activity_Log::Select(DB::RAW('SEC_TO_TIME(SUM(TIME_TO_SEC(total_time))) as timeSum'))->where('date', $weekArray[$i])->where('corporation_id', $corporation->corporation_id)->first();

                if($corpTotal->timeSum != null && $corpTotal->timeSum != '')
                {
                    $str = explode(':', $corpTotal->timeSum);
                    $mins = (int) $str[1] / 60;
                    $hour = (int) $str[0];
                    $sum = $hour + $mins;
                    $sum = floatval(number_format($sum, 2));
                    $corpDayArray[] = $sum;
                }
                elseif(empty($corpTotal) == true){
                    $corpDayArray[] = 0.0;
                }
                else{
                    $corpDayArray[] = 0.0;
                }
                
            }

            $corpTotalArray[$i] = $corpDayArray;
            array_unshift($corpTotalArray[$i], $weekArray[$i]);
            unset($corpDayArray);
        }

        //modify time sums to integers
        for ($i = 0; $i < count($weekArray); $i++) {
            $sum = 0;
            $rnnSum = 0;
            if ($logArray[$i] != null) {
                $str = explode(':', $logArray[$i]);
                $mins = (int) $str[1] / 60;
                $hour = (int) $str[0];
                $sum = $hour + $mins;
                $sum = floatval(number_format($sum, 2));
            }
            if ($rnnArray[$i] != null) {
                $str = explode(':', $rnnArray[$i]);
                $mins = (int) $str[1] / 60;
                $hour = (int) $str[0];
                $rnnSum = $hour + $mins;
                $rnnSum = floatval(number_format($rnnSum, 2));
            }
            $date = strtotime($weekArray[$i]);
            $date = date('m/d/Y', $date);
            $dataArray[$i] = array($date, $sum);
            $rnnDataArray[$i] = array($date, $rnnSum);
        }
        //Create column headers for corporation report   
        $nameArray = ['Day'];
        foreach ($corporations as $corp) {
            $nameArray[] = $corp->name;
        }
        if(count($nameArray) == 1){
            array_push($nameArray, 'Total');
        }
        array_unshift($corpTotalArray, $nameArray);
        
        
        return view('/admin.dashboardLayouts.adminLayout2')->with('data', json_encode($dataArray))->with('corpData', json_encode($corpTotalArray))->with('rnnData', json_encode($rnnDataArray));
    }

}
