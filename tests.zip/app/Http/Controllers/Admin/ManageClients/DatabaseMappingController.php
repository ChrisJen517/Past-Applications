<?php

namespace App\Http\Controllers\Admin\ManageClients;

use App\Models\Active_Accounts_Mapping;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Schema;

class DatabaseMappingController extends Controller
{
    public function showMapping($id)
    {
        $corporation_id = $id;
        $AAM = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();

        return view('admin.pages.manageClients.databaseMapping')->with('AAM', $AAM)->with('corporation_id', $corporation_id);
    }

    public function updateMapping(request $request)
    {
        $this->validate($request, [
            'ACCT_DUE_DATE' => 'required',
            'ACCT_SSN' => 'required',
            'ACCT_ID' => 'required',
        ]);
        $corporation_id = $request->corporation_id;
        $AAMCheck = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();

        if ($AAMCheck == null) {
            $AAM = new Active_Accounts_Mapping;
            $AAM->ACCT_CLIENT = $request->ACCT_CLIENT;
            $AAM->CLIENT_PHONE = $request->ACCT_CLIENT_PHONE;
            $AAM->ACCT_AGENT = $request->ACCT_AGENT;
            $AAM->TEAM_ID = $request->TEAM_ID;
            $AAM->ACCT_CASE = $request->ACCT_CASE;
            $AAM->ACCT_DUE_DATE = $request->ACCT_DUE_DATE;
            $AAM->ACCT_SSN = $request->ACCT_SSN;
            $AAM->ACCT_FIRST_NAME = $request->ACCT_FIRST_NAME;
            $AAM->ACCT_LAST_NAME = $request->ACCT_LAST_NAME;
            $AAM->ACCT_AD1 = $request->ACCT_AD1;
            $AAM->ACCT_AD2 = $request->ACCT_AD2;
            $AAM->ACCT_CITY = $request->ACCT_CITY;
            $AAM->ACCT_ST = $request->ACCT_ST;
            $AAM->ACCT_ZIP = $request->ACCT_ZIP;
            $AAM->ACCT_DOB = $request->ACCT_DOB;
            $AAM->ACCT_ID = $request->ACCT_ID;
            $AAM->ACCT_SOURCE = $request->ACCT_SOURCE;
            $AAM->EMPL_NAME = $request->EMPL_NAME;
            $AAM->EMPL_ADDR1 = $request->EMPL_ADDR1;
            $AAM->EMPL_ADDR2 = $request->EMPL_ADDR2;
            $AAM->EMPL_CITY = $request->EMPL_CITY;
            $AAM->EMPL_ST = $request->EMPL_ST;
            $AAM->EMPL_ZIP = $request->EMPL_ZIP;
            $AAM->EMPL_HR_ADDR = $request->EMPL_HR_ADDR;
            $AAM->EMPL_PHONE1_NMBR = $request->EMPL_PHONE1_NMBR;
            $AAM->EMPL_PH_SOURCE = $request->EMPL_PH_SOURCE;
            $AAM->EMPL_FAX = $request->EMPL_FAX;
            $AAM->EMPL_EMAIL = $request->EMPL_EMAIL;
            $AAM->EMPL_TITLE = $request->EMPL_TITLE;
            $AAM->EMPL_CONTACT = $request->EMPL_CONTACT;
            $AAM->EMPL_CONTACT_TITLE = $request->EMPL_CONTACT_TITLE;
            $AAM->TIME_ZONE = $request->TIME_ZONE;
            $AAM->POESCORE = $request->POESCORE;
            $AAM->corporation_id = $corporation_id;
            $AAM->POWERLEAD_FLAG = $request->POWERLEAD_FLAG;
            $AAM->TIER = $request->TIER;
            $AAM->ACCESS_RULES = $request->ACCESS_RULES;
            $AAM->ACCT_TYPE = $request->ACCT_TYPE;
            $AAM->Save();

            return redirect()->back()->with('message', 'Mapping Added!');
        }

        else {

            $AAMCheck->ACCT_CLIENT = $request->ACCT_CLIENT;
            $AAMCheck->CLIENT_PHONE = $request->ACCT_CLIENT_PHONE;
            $AAMCheck->ACCT_AGENT = $request->ACCT_AGENT;
            $AAMCheck->ACCT_DUE_DATE = $request->ACCT_DUE_DATE;
            $AAMCheck->TEAM_ID = $request->TEAM_ID;
            $AAMCheck->ACCT_CASE = $request->ACCT_CASE;
            $AAMCheck->ACCT_SSN = $request->ACCT_SSN;
            $AAMCheck->ACCT_FIRST_NAME = $request->ACCT_FIRST_NAME;
            $AAMCheck->ACCT_LAST_NAME = $request->ACCT_LAST_NAME;
            $AAMCheck->ACCT_AD1 = $request->ACCT_AD1;
            $AAMCheck->ACCT_AD2 = $request->ACCT_AD2;
            $AAMCheck->ACCT_CITY = $request->ACCT_CITY;
            $AAMCheck->ACCT_ST = $request->ACCT_ST;
            $AAMCheck->ACCT_ZIP = $request->ACCT_ZIP;
            $AAMCheck->ACCT_DOB = $request->ACCT_DOB;
            $AAMCheck->ACCT_ID = $request->ACCT_ID;
            $AAMCheck->ACCT_SOURCE = $request->ACCT_SOURCE;
            $AAMCheck->EMPL_NAME = $request->EMPL_NAME;
            $AAMCheck->EMPL_ADDR1 = $request->EMPL_ADDR1;
            $AAMCheck->EMPL_ADDR2 = $request->EMPL_ADDR2;
            $AAMCheck->EMPL_CITY = $request->EMPL_CITY;
            $AAMCheck->EMPL_ST = $request->EMPL_ST;
            $AAMCheck->EMPL_ZIP = $request->EMPL_ZIP;
            $AAMCheck->EMPL_HR_ADDR = $request->EMPL_HR_ADDR;
            $AAMCheck->EMPL_PHONE1_NMBR = $request->EMPL_PHONE1_NMBR;
            $AAMCheck->EMPL_PH_SOURCE = $request->EMPL_PH_SOURCE;
            $AAMCheck->EMPL_FAX = $request->EMPL_FAX;
            $AAMCheck->EMPL_EMAIL = $request->EMPL_EMAIL;
            $AAMCheck->EMPL_TITLE = $request->EMPL_TITLE;
            $AAMCheck->EMPL_CONTACT = $request->EMPL_CONTACT;
            $AAMCheck->EMPL_CONTACT_TITLE = $request->EMPL_CONTACT_TITLE;
            $AAMCheck->TIME_ZONE = $request->TIME_ZONE;
            $AAMCheck->TEAM_RULE = $request->TEAM_RULE;
            $AAMCheck->POESCORE = $request->POESCORE;
            $AAMCheck->corporation_id = $corporation_id;
            $AAMCheck->POWERLEAD_FLAG = $request->POWERLEAD_FLAG;
            $AAMCheck->TIER = $request->TIER;
            $AAMCheck->ACCESS_RULES = $request->ACCESS_RULES;
            $AAMCheck->ACCT_TYPE = $request->ACCT_TYPE;
            $AAMCheck->save();
            return redirect()->back()->with('message', 'Mapping Updated');
        }
    }

    public function checkCSVMapping(request $request)
    {
        $corporation_id = $request->corporation_id;
        $active_accounts_mapping = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();
        $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts_mapping');


        if ($active_accounts_mapping->ACCT_DUE_DATE == null
        || $active_accounts_mapping->ACCT_SSN == null
        || $active_accounts_mapping->ACCT_ID == null) {
            return back()->with('error', 'File missing required headers. Please set up reupload database mapping form');
        }

        $file = new \SplFileObject($request->testMappingFile);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];

        // Grabbing names of the columns in the CSV file
        foreach ($file as $row) {
            foreach ($row as $header) {
                $headers[] = $header;
            }
            break;
        }

        $count = 0;
        $countHead = 0;
        $number_of_matched_columns = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach ($headers as $head) {
            foreach ($active_accounts_mapping_columns as $column) {
                if ($active_accounts_mapping->$column == $head) {
                    if ($count == 0) {
                        $number_of_matched_columns++;
                        $count++;
                    } else {

                        $number_of_matched_columns++;
                    }
                }
            }
        }

        // Checking if # of Database mapped columns are all on the CSV File
        $expected_col_number = 0;
        foreach ($active_accounts_mapping_columns as $column) {
            if ($active_accounts_mapping->$column != null) {
                $expected_col_number++;
            }
        }
        $expected_col_number = $expected_col_number - 4;
        if ($expected_col_number != $number_of_matched_columns) {
            return redirect()->back()->with('error', 'More columns mapped than found on CSV, check database mapping.');
        } else {
            return redirect()->back()->with('message', 'Successfully Mapped CSV File Headers.');
        }
    }
}
