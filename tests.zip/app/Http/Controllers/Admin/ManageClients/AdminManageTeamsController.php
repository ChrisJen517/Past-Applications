<?php

namespace App\Http\Controllers\Admin\ManageClients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Team_Distribution_Rules;
use App\Models\Team;
use App\Models\Manager;
use App\Models\Agent;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class AdminManageTeamsController extends Controller
{

    public function teamUsers($id)
    {
        $rules = Team_Distribution_Rules::where('team_id', $id)->first();

        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;

        if($rules != null){
            //sets priorities for dropdowns
            $priority[] = $rules->priority;
            $priority[] = $rules->second_priority;
            $priority[] = $rules->third_priority;

            //sets value to checked if they were set as a priority
            if(in_array('ACCT_DUE_DATE', $priority))
                $preset[0] = 1;
            if(in_array('POESCORE', $priority))
                $preset[1] = 1;
            if(in_array('ACCT_SOURCE', $priority))
                $preset[2] = 1;
        }
        else{
            $priority[] = "";
            $priority[] = "";
            $priority[] = "";
        }
        $team = Team::where('team_id', $id)->first();

        $users = User::selectRaw('users.user_id, users.first_name, users.last_name, users.email, users.role, users.is_deactivated, users.active')
        ->leftJoin('agents', function ($join) {
            $join->on('agents.user_id', '=', 'users.user_id');
        })
        ->leftJoin('managers', function ($join) {
            $join->on('managers.user_id', '=', 'users.user_id');
        })->whereRaw('(agents.team_id = '.$id.' or managers.team_id = '.$id.')')->get();

        $teams = Team::where('corporation_id', $team->corporation_id)->get();

        return view('admin.pages.manageClients.teamUsers')->with('users', $users)->with('team', $team)->with('teams', $teams)->with('preset', $preset)->with('priority', $priority);
    }

    public function updateCorporateTeam(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
        ]);
        $team = Team::find($request->teamId);
        $team->name = $request->name;
        $team->max_accounts = $request->max_accounts;
        $team->max_attempts = $request->max_attempts;
        $team->team_goals = $request->team_goals;
        $team->save();

        $rules = Team_Distribution_Rules::where('team_id', $team->team_id)->first();

        if($rules == null)
            $rules = new Team_Distribution_Rules;

        $rules->team_id = $team->team_id;

        //sets the priorities based on the number checked
        if(count($request->checked) == 1){
            $rules->priority = $request->checked[0];
            $rules->second_priority = null;
            $rules->third_priority = null;
        }
        else {
            $rules->priority = $request->priority;

            if(count($request->checked) == 2){
                if($request->priority != $request->checked[0])
                    $rules->second_priority = $request->checked[0];
                else
                    $rules->second_priority = $request->checked[1];

                $rules->third_priority = null;
            }
            if(count($request->checked) == 3){
                $rules->second_priority = $request->prioritySecond;
                $priorities[] = $request->priority;
                $priorities[] = $request->prioritySecond;

                if(!in_array('POESCORE', $priorities))
                    $rules->third_priority = 'POESCORE';
                else if(!in_array('ACCT_DUE_DATE', $priorities))
                    $rules->third_priority = 'ACCT_DUE_DATE';
                else
                    $rules->third_priority = 'ACCT_SOURCE';
            }
        }

        $rules->save();


        return back()->with('message', 'Team Updated');
    }

    //Update which team a user belongs to
    public function updateUserTeam($userId, $teamId)
    {

        if(Agent::where('user_id', $userId)->exists())
        {
            $agent = Agent::where('user_id', $userId)->first();
            $agent->team_id = $teamId;
            $agent->save();
            return back()->with('message', 'User Updated to Team Successfully');
        }
        $manager = Manager::where('user_id', $userId)->first();
        $manager->team_id = $teamId;
        $manager->save();
        return back()->with('message', 'User Updated to Team Successfully');

    }


    public function deleteCorporateTeam($id)
    {
        $team = Team::where('team_id', $id)->with('agent_link')->with('manager_link')->first();

        if (count($team->agent_link) > 0 || count($team->manager_link) > 0) {
            $userIds = [];

            foreach($team->agent_link as $agent) {
                $user = $agent->user_link;
                $userIds[] = $user->user_id;
            }

            foreach($team->manager_link as $manager) {
                $user = $manager->user_link;
                $userIds[] = $user->user_id;
            }

            if (!empty($userIds)) {
                $userIds = implode(',', $userIds);
                DB::select(DB::raw('UPDATE `users` SET `active` = 0, `is_deactivated` = 1, `deactivate_date`=NOW() WHERE `user_id` IN ('.$userIds.');'));
            }
        }

        DB::select(DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = NULL, `TEAM_NAME` = NULL WHERE `TEAM_ID` = '.$team->team_id.';'));

        $team->is_deactivated = 1;
        $team->deactivate_date = Carbon::now();
        $team->save();

        return back()->with('message', $team->name . ' has been successfully deactivated.');
    }

    public function reactivateTeam($id){
        $team = Team::where('team_id', $id)->first();
        if(empty($team)){
            return back()->with('error', 'Cannot find team!');
        }

        $team->is_deactivated = 0;
        $team->deactivate_date = null;
        $team->save();

        return back()->with('message', $team->name . ' has been successfully reactivated.');
    }
}
