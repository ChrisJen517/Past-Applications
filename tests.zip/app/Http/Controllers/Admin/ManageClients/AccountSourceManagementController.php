<?php

namespace App\Http\Controllers\Admin\ManageClients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Corporation;
use App\Models\Account_Source;
use Illuminate\Support\Facades\DB;

class AccountSourceManagementController extends Controller
{
    public function showAccountSourceManagement($id)
    {
        $corporation = Corporation::find($id);
        $sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();

        return view('admin.pages.manageClients.adminAccountSourceManagement')->with('corporation', $corporation)->with('sources', $sources);
    }

    public function addAccountSource(Request $request)
    {
        $corporation = Corporation::find($request->corporation_id);

        $this->validate($request, [
            'name' => 'required',
            'shortcode' => 'required',
        ]);

        if (strpos($request->shortcode, ',') !== false) {
            return redirect()->back()->with('error', 'Shortcodes can not contain a comma.');
        }

        if (Account_Source::where('shortcode', $request->shortcode)->where('corporation_id', $corporation->corporation_id)->exists()) {
            return redirect()->back()->with('error', 'This shortcode is in use.');
        }

        $max = Account_Source::where('corporation_id', $corporation->corporation_id)->orderBy('priority', 'desc')->first();
        if($max == null)
            $priority = 1;
        else
            $priority = $max->priority + 1;

        $account_source = new Account_Source();
        $account_source->name = $request->name;
        $account_source->description = $request->description;
        $account_source->shortcode = $request->shortcode;
        $account_source->priority = $priority;
        $account_source->corporation_id = $corporation->corporation_id;

        $account_source->save();

        return redirect()->back()->with('success', 'Account Updated Successfully');
    }

    public function updatePriority(Request $request)
    {
        $corporation_id = $request->corporation_id;
        $shortcodes = $request->shortcodes;
        $orders = $request->orders;

        // Call the stored procedure to save the priority of the sources
        DB::statement('call SAVE_SOURCE_PRIORITY(?,?,?)', array(
            implode(',', $shortcodes) . ',',
            implode(',', $orders) . ',',
            $corporation_id
        ));
    }

    public function updateAccountSource(Request $request)
    {
        $corporation = Corporation::find($request->corporation_id);

        if (strpos($request->shortcode, ',') !== false) {
            return redirect()->back()->with('error', 'Shortcodes can not contain a comma.');
        }

        if (Account_Source::where('shortcode', $request->shortcode)
        ->where('corporation_id', $corporation->corporation_id)
        ->where('account_source_id', '!=', $request->account_source_id)
        ->exists()) {
            return redirect()->back()->with('error', 'This shortcode is in use.');
        }
        $account_source = Account_Source::where('account_source_id', $request->account_source_id)->first();

        $account_source->name = $request->name;
        $account_source->description = $request->description;
        $account_source->shortcode = $request->shortcode;
        $account_source->save();

        return redirect()->back()->with('success', 'Account Source Updated Successfully');
    }

    public function deleteAccountSource($id)
    {
        $account_source = Account_Source::find($id);

        $account_source->delete();

        return redirect()->back()->with('message', 'Account Source Successfully Deleted');
    }
}
