<?php

namespace App\Http\Controllers\Admin\ManageClients;

use App\Models\Access_Levels;
use App\Models\Capcode;
use App\Models\Corporate_Api;
use App\Models\Corporate_Settings;
use App\Models\Corporation;
use App\Models\Corporation_Contact;
use App\Models\Distribution_Rules;
use App\Http\Controllers\Controller;
use App\Jobs\RemoveUnworkableQueue;
use App\Jobs\UnblockAutoFaxEmailQueue;
use App\Models\State;
use App\Models\Team;
use App\Models\Team_Distribution_Rules;
use App\Traits\AccountDistrubution;
use App\User;
use App\Models\Verification_Requirements;
use DateTime;
use DB;
use Illuminate\Http\Request;
use App\Models\Redistribution_Record;

class AdminManageCompaniesController extends Controller
{
    use AccountDistrubution;

    public function showManageCorporations()
    {
        $corporations = Corporation::all();

        $states = State::all();
        return view('/admin/pages/manageClients/manageCorporations')->with('corporations', $corporations)->with('states', $states);
    }

    public function editCorporation($id)
    {
        $states = State::all();
        $corporation = Corporation::findOrFail($id);
        $corporation_contacts = $corporation->corporationContacts()->get();
        $corporate_settings = Corporate_Settings::where('corporation_id', $id)->first();
        $teams = Team::where('corporation_id', $id)->with('agent_link')->with('manager_link')->get();
        $capcodes = Capcode::where('corporation_id', $id)->get();
        $export_setting = explode(',', $corporate_settings->capcode_export);

        $rules = Distribution_Rules::where('corporation_id', $id)->first();

        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;

        if ($rules != null) {
            //sets priorities for dropdowns
            $priority[] = $rules->priority;
            $priority[] = $rules->second_priority;
            $priority[] = $rules->third_priority;

            //sets value to checked if they were set as a priority
            if (in_array('ACCT_DUE_DATE', $priority)) {
                $preset[0] = 1;
            }

            if (in_array('POESCORE', $priority)) {
                $preset[1] = 1;
            }

            if (in_array('ACCT_SOURCE', $priority)) {
                $preset[2] = 1;
            }
        } else {
            $priority[] = "";
            $priority[] = "";
            $priority[] = "";
        }

        //verification requirements
        $requirements = Verification_Requirements::where('corporation_id', $id)->first();
        if ($requirements == null) {
            $requirements = new Verification_Requirements();
            $requirements->corporation_id = $id;
            $requirements->save();
        }

        return view('/admin/pages/manageClients/editCorporation')->with('corporate_settings', $corporate_settings)->with('corporation', $corporation)
            ->with('states', $states)->with('corporation_contacts', $corporation_contacts)->with('teams', $teams)->with('preset', $preset)
            ->with('priority', $priority)->with('capcodes', $capcodes)->with('export_setting', $export_setting)->with('requirements', $requirements);
    }

    public function AddCorporation(request $request)
    {
        $corporation = new Corporation;
        $corporation->name = $request->name;
        $corporation->email = $request->email;
        $corporation->street_address = $request->address;
        $corporation->state = $request->state;
        $corporation->city = $request->city;
        $corporation->zip = $request->zip;
        $corporation->save();

        $this->generateDefaultCapcodes($corporation->corporation_id);

        $user = new User;
        $user->role = 'corporate_api';
        $user->active = '1';
        $user->password_valid = '1';

        //creates a random 12 digit number for the email field that is unique
        do {
            $email = rand(100000000000, 999999999999);
            $test = User::where('email', $email)->first();
        } while ($test != null);

        $user->email = $email;
        $token = rand(100000000000, 999999999999);
        $user->password = bcrypt($token);
        $user->save();

        $api = new Corporate_Api;
        $api->corporation_id = $corporation->corporation_id;
        $api->user_id = $user->user_id;
        $api->UP = $token;
        $api->save();

        $requirements = new Verification_Requirements();
        $requirements->corporation_id = $corporation->corporation_id;
        $requirements->save();

        $rules = new Distribution_Rules;
        $rules->corporation_id = $corporation->corporation_id;
        $rules->priority = "POESCORE";
        $rules->second_priority = "ACCT_DUE_DATE";
        $rules->save();

        $corporate_settings = new Corporate_Settings;
        $corporate_settings->corporation_id = $corporation->corporation_id;
        $corporate_settings->save();

        $access_level = new Access_Levels;
        $access_level->corporation_id = $corporation->corporation_id;
        $access_level->shortcode = "AWG7";
        $access_level->name = "AWG7";
        $access_level->desc = "Access level for AWG7 type accounts";
        $access_level->save();

        $access_level = new Access_Levels;
        $access_level->corporation_id = $corporation->corporation_id;
        $access_level->shortcode = "IVR";
        $access_level->name = "IVR";
        $access_level->desc = "Access level for IVR type accounts";
        $access_level->save();

        return back()->with('success', 'Corporation Added');
    }

    private function generateDefaultCapcodes($id)
    {
        $curTime = new \DateTime();
        $created_at = $curTime->format("Y-m-d H:i:s");

        DB::select(DB::raw("CALL generateDefaultCapcodeList($id, '$created_at' );"));
    }

    public function AddCorporationContact(request $request)
    {
        $corporation_contacts = new Corporation_Contact;
        $corporation_contacts->name = $request->name;
        $corporation_contacts->email = $request->email;
        $corporation_contacts->job_title = $request->job_title;
        $corporation_contacts->phone_number = $request->phone_number;
        $corporation_contacts->corporation_id = $request->corporation_id;
        $corporation_contacts->save();

        return back()->with('success', 'Corporation Contact Added');
    }

    public function updateCorporation(request $request)
    {
        $corporation = Corporation::find($request->id);
        $corporation->name = $request->name;
        $corporation->street_address = $request->address;
        $corporation->city = $request->city;
        $corporation->state = $request->state;
        $corporation->zip = $request->zip;
        $corporation->email = $request->email;
        $corporation->save();

        $capcode_export_save = '';
        if ($request->capcode_export) {
            foreach ($request->capcodes_export as $capcode_export) {
                $capcode_export_save = $capcode_export_save . $capcode_export . ",";
            }
        }
        $capcode_export_save = substr_replace($capcode_export_save, "", -1);

        $corporate_settings = Corporate_Settings::where('corporation_id', $corporation->corporation_id)->first();

        // * Disabled temporarily until we figure out a way to add more subdomains to sendgrid
        // if (!empty($request->sender_email_address)) {
        //     $corporate_settings->sender_email_address = $request->sender_email_address;
        // }

        if (!empty($request->sender_email_name)) {
            $corporate_settings->sender_email_name = $request->sender_email_name;
        }

        // $corporate_settings->hold_accounts_automatically = $request->hold_accounts;
        $corporate_settings->hold_accounts_below_score = $request->below_score;
        $corporate_settings->export_frequency = $request->exportFrequency;
        $corporate_settings->directory_option = $request->directory_option;
        $corporate_settings->auto_remove_accounts_past_due = $request->remove_past_due;
        $corporate_settings->rnn_scoring = $request->rnn_scoring;
        $corporate_settings->show_client = $request->show_client;
        $corporate_settings->auto_redistribute = $request->auto_redistribute;
        $corporate_settings->powerlead_active = $request->powerlead_active;
        $corporate_settings->power_hold = $request->power_hold;
        $corporate_settings->capcode_export = $capcode_export_save;
        $corporate_settings->export_time = date("Y-m-d G:i:s", DateTime::createFromFormat("G:i", $request->exportTime)->getTimeStamp());

        //fax template upload
        if ($request->fax_upload != null) {
            $extension = pathinfo($_FILES['fax_upload']['name'], PATHINFO_EXTENSION);

            //saves the file
            $file = $request->file('fax_upload');
            $download = $file->storeAs('templates', $request->id . '_fax_template.' . $extension);

            $corporate_settings->fax_path = 'templates/' . $request->id . '_fax_template.' . $extension;
        }

        //email upload
        if ($request->email_upload != null) {
            $extension = pathinfo($_FILES['email_upload']['name'], PATHINFO_EXTENSION);

            //saves the file
            $file = $request->file('email_upload');
            $download = $file->storeAs('templates', $request->id . '_email_template.' . $extension);

            $corporate_settings->email_path = 'templates/' . $request->id . '_email_template.' . $extension;
        }
        $corporate_settings->save();

        $rules = Distribution_Rules::where('corporation_id', $corporation->corporation_id)->first();
        if ($rules == null) {
            $rules = new Distribution_Rules;
        }

        $rules->corporation_id = $corporation->corporation_id;

        //sets the priorities based on the number checked
        if (count($request->checked) == 1) {
            $rules->priority = $request->checked[0];
            $rules->second_priority = null;
            $rules->third_priority = null;
        } else {
            $rules->priority = $request->priority;

            if (count($request->checked) == 2) {
                if ($request->priority != $request->checked[0]) {
                    $rules->second_priority = $request->checked[0];
                } else {
                    $rules->second_priority = $request->checked[1];
                }

                $rules->third_priority = null;
            }
            if (count($request->checked) == 3) {
                $rules->second_priority = $request->prioritySecond;
                $priorities[] = $request->priority;
                $priorities[] = $request->prioritySecond;

                if (!in_array('POESCORE', $priorities)) {
                    $rules->third_priority = 'POESCORE';
                } else if (!in_array('ACCT_DUE_DATE', $priorities)) {
                    $rules->third_priority = 'ACCT_DUE_DATE';
                } else {
                    $rules->third_priority = 'ACCT_SOURCE';
                }
            }
        }

        $rules->save();

        if($request->updateTeams == 1){
            $this->setAllTeamsPriority($rules->priority, $rules->second_priority, $rules->third_priority, $corporation->corporation_id);
        }

        //verification requirements
        $requirements = Verification_Requirements::where('corporation_id', $corporation->corporation_id)->first();

        if ($requirements == null) {
            $requirements = new Verification_Requirements();
            $requirements->corporation_id = $corporation->corporation_id;
        }

        $requirements->employer_type = $request->employer_type;
        $requirements->employer_name = $request->employer_name;
        $requirements->employer_phone = $request->employer_phone;
        $requirements->employer_address_1 = $request->employer_address_1;
        $requirements->employer_address_2 = $request->employer_address_2;
        $requirements->employer_city = $request->employer_city;
        $requirements->employer_state = $request->employer_state;
        $requirements->employer_zip = $request->employer_zip;
        $requirements->consumer_title = $request->consumer_title;
        $requirements->employer_fax = $request->employer_fax;
        $requirements->employer_email = $request->employer_email;
        $requirements->verification_mailing_address = $request->verification_mailing_address;
        $requirements->verification_contact_name = $request->verification_contact_name;
        $requirements->verification_contact_title = $request->verification_contact_title;
        $requirements->future_verifications = $request->future_verifications;
        $requirements->save();

        return back()->with('success', 'Corporation Updated');
    }

    public function removePastDueAccounts($id)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        //gets the pass due capcode id
        $pastDue = Capcode::where('corporation_id', $id)->where('capcode', 5514)->first();
        if($pastDue != null){
            $pastDue = $pastDue->id;
        }
        else{
            return back()->with('error', 'Corporation is missing 5514 Past Due Capcode');
        }

        //updates the capcode to the past due
        DB::Select(DB::RAW('UPDATE `active_accounts` SET CAPCODE = '.$pastDue.' where CORPORATION_ID =' . $id . ' AND ACCT_DUE_DATE < now();'));

        DB::Select(DB::raw('INSERT INTO inactive_accounts (SELECT *
                from `active_accounts` where CORPORATION_ID =' . $id . ' AND ACCT_DUE_DATE < now());'));

        DB::select(DB::raw('DELETE FROM active_accounts WHERE ACCT_DUE_DATE < now() AND CORPORATION_ID =' . $id));

        //clean up job
        $this->dispatch(new UnblockAutoFaxEmailQueue($id));
        $this->dispatch(new RemoveUnworkableQueue($id));

        return back()->with('success', 'Past Due Accounts Removed');
    }

    public function autoRedistributeAccounts($id)
    {

        DB::select(DB::raw('UPDATE active_accounts
        SET acct_agent = NULL
        WHERE last_worked IS NULL
        AND Corporation_id =' . $id));

        $this->setAgentQueue($id);

        $redistribution_record = new Redistribution_Record();
        $redistribution_record->corporation_id = $id;
        $redistribution_record->team_id = 0;
        $redistribution_record->save();

        return back()->with('success', 'Accounts Re-distributed!');
    }

    public function updateContact(request $request)
    {
        $corporation_contacts = Corporation_Contact::find($request->idName);
        $corporation_contacts->name = $request->name;
        $corporation_contacts->email = $request->email;
        $corporation_contacts->job_title = $request->job_title;
        $corporation_contacts->phone_number = $request->phone_number;
        $corporation_contacts->save();

        return back()->with('success', 'Corporation Contact Updated');
    }

    public function blockCorporation(Request $request)
    {
        $corpId = $request->get('corpId');
        $corp = Corporation::where('corporation_id', $corpId)->first();

        $corp->active = 0;
        $corp->save();
    }

    public function unblockCorporation(Request $request)
    {
        $corpId = $request->get('corpId');
        $corp = Corporation::where('corporation_id', $corpId)->first();

        $corp->active = 1;
        $corp->save();
    }

    public function deleteContact($id)
    {
        $corporation_contacts = Corporation_Contact::find($id);
        $corporation_contacts->delete();

        return back()->with('success', 'Corporation Contact Deleted');
    }

    public function corpAddTeam(Request $request)
    {
        if (Team::where('name', '=', $request->teamName)->where('corporation_id', '=', $request->corp_id)->doesntExist()) {
            $this->validate($request, [
                'teamName' => 'required',
            ]);
            $team = new Team;
            $team->name = $request->teamName;
            $team->corporation_id = $request->corp_id;
            $team->max_accounts = 50;
            $team->save();

            $rules = Distribution_Rules::where('corporation_id', $request->corp_id)->first();
            if ($rules != null) {
                $team_distribution_rules = new Team_Distribution_Rules;
                $team_distribution_rules->priority = $rules->priority;
                $team_distribution_rules->second_priority = $rules->second_priority;
                $team_distribution_rules->third_priority = $rules->third_priority;
                $team_distribution_rules->team_id = $team->team_id;
                $team_distribution_rules->save();
            } else {
                $team_distribution_rules = new Team_Distribution_Rules;
                $team_distribution_rules->priority = 'ACCT_DUE_DATE';
                $team_distribution_rules->second_priority = 'POESCORE';
                $team_distribution_rules->team_id = $team->team_id;
                $team_distribution_rules->save();
            }

            return back()->with('message', 'Team Created');
        } else {
            return back()->with('error', 'Team Name Already Exists');
        }
    }

    public function downloadTemplate($id, $type)
    {

        $corporate_settings = Corporate_Settings::where('corporation_id', $id)->first();

        if ($type == 'Fax') {
            $filepath = $corporate_settings->fax_path;
        } else {
            $filepath = $corporate_settings->email_path;
        }

        if ($filepath == null) {
            return back()->with('error', "No template has been saved");
        } else {
            return response()->download(storage_path('app/public/' . $filepath), null, [
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
                'Pragma' => 'no-cache',
            ]);
        }
    }

    public function setAllTeamsPriority($first, $second, $third, $corporation_id){
        $teams = Team::select('team_id')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->get();

        $teamIds = [];
        foreach($teams as $team){
            $teamIds[] = $team->team_id;
        }

        $eachTeamRules = Team_Distribution_Rules::whereIn('team_id', $teamIds)->get();

        foreach($teams as $team){
            $thisTeamRules = $eachTeamRules->where('team_id', $team->team_id)->first();

            if($thisTeamRules == null){
                $thisTeamRules = new Team_Distribution_Rules;
                $thisTeamRules->team_id = $team->team_id;
            }

            $thisTeamRules->priority = $first;
            $thisTeamRules->second_priority = $second;
            $thisTeamRules->third_priority = $third;

            $thisTeamRules->save();
        }
    }
}
