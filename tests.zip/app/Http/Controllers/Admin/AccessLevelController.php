<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Corporation;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\Access_Levels;

class AccessLevelController extends Controller
{
    public function showAccessLevel()
    {
        $corporations = Corporation::select('corporation_id', 'name')->where('active', 1)->get();
        $corporationIds = $corporations->pluck('corporation_id')->toArray();
        $access_levels = Access_Levels::whereIn('corporation_id', $corporationIds)->get();
        $requiredAccessLevels = ["AWG7", "IVR"];
        return view('admin/pages/accessLevelManagement')->with('access_levels', $access_levels)->with('corporations', $corporations)->with('requiredAccessLevels', $requiredAccessLevels);
    }

    public function showAccessLevelCorporations()
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $access_levels = Auth::user()->has_access;
        $access_levels = collect($access_levels);
        $access_levels = Access_Levels::where('corporation_id', $corporation_id)->get();
        $requiredAccessLevels = ["AWG7", "IVR"];
        return view('corporateAdmin/pages/database/accessLevelManagement')->with('access_levels', $access_levels)->with('requiredAccessLevels', $requiredAccessLevels);
    }

    public function addPermissions(request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:45',
            'shortcode' => 'required|max:45',
            'desc' => 'max:200'
        ]);
        if(Auth::User()->role == 'admin'){
            $corporation_id = $request->corporation_id;
        }else{
            $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        }
        $count = DB::table('access_levels')->where('corporation_id', $corporation_id)
            ->where(function($q) use ($request) {
                $q->where('shortcode', $request->shortcode)->orWhere('name', $request->name);
            })->count();
        //return $count;
        if ($count > 0) {
            return back()->with('error', 'Company Already has that Access Level Name or Shortcode. These must be unique.');
        }

        $access_level = new Access_Levels;
        $access_level->name = $request->name;
        $access_level->desc = $request->desc;
        $access_level->shortcode = strtoupper($request->shortcode);
        $access_level->corporation_id = $corporation_id;
        $access_level->save();

        //if the user is a corporate admin, adds the access level to them
        if(Auth::User()->role == 'corporate_admin'){
            $user = Auth::user();
            $user->has_access = $user->has_access.",".$access_level->id;
            $user->save();
        }

        return back()->with('success', 'Permission added');
    }

    public function UpdatePermission(request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:45',
            'shortcode' => 'required|max:45',
            'desc' => 'max:200'
        ]);
        if(Auth::User()->role == 'admin'){
            $corporation_id = $request->corporation_id;
        }else{
            $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        }
        $count = DB::table('access_levels')->where('corporation_id', $corporation_id)
            ->where(function($q) use ($request) {
                $q->where('shortcode', $request->shortcode)->orWhere('name', $request->name);
            })->where('id', '!=', $request->idName)->count();

        //return $count;
        if ($count > 0) {
            return back()->with('error', 'Company Already has that Access Level Name or Shortcode. These must be unique.');
        }

        $access_level = Access_Levels::findOrFail($request->idName);
        $access_level->name = $request->name;
        $access_level->desc = $request->desc;
        $access_level->shortcode = strtoupper($request->shortcode);
        $access_level->corporation_id = $corporation_id;
        $access_level->save();

        return back()->with('success', 'Permission updated');
    }
}
