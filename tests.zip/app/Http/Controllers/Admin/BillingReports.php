<?php

namespace App\Http\Controllers\Admin;

use App\Models\Active_Account;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Capcode;
use App\Models\Directory_Capcode;
use Auth;
use App\Models\Corporation;
use App\RNNMailer;
use DB;
use Carbon\Carbon;
use App\Models\Worked_History;
use Illuminate\Console\Command;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Config;
use Schema;


class BillingReports extends Controller
{
    public function seeBilling(){
        return view('admin.pages.billingReport');
    }

    public function seeInvoice(){
        return view('admin.pages.invoiceReport');
    }

    public function checkRecent() {
        //removes the needed titles and sets it to lowercase
        // $companyType = ['"incorporated"', '"corporation"', '"llc"', '"ltd"', '"llp"', '"s-corp"', '"inc"', '"corp"'];
        // $removeCompanyType = "LOWER(EMPL_NAME)";
        // foreach($companyType as $type){
        //     $removeCompanyType = "REPLACE(".$removeCompanyType.", ".$type.", '')";
        // }
        // //return $removeCompanyType;
        // DB::SELECT(DB::RAW("UPDATE active_accounts Set NAME_MATCH = ".$removeCompanyType.";"));

        // //removes the special characters
        // $specialCharaters = ["'".'"'."'", '"'."'".'"', '"!"', '"@"', '"#"', '"$"', '"%"','"^"','"&"','"*"','"("','")"','"{"','"["','"}"','"]"','"|"','";"','":"','"<"','","','"."','">"','"?"','"/"','"-"','"_"','"="','"+"','"`"','"~"', '" "'];
        // $removeSpecialCharaters = "REPLACE(NAME_MATCH, '/', '')";
        // foreach($specialCharaters as $character){
        //     $removeSpecialCharaters = "REPLACE(".$removeSpecialCharaters.", ".$character.", '')";
        // }
        // DB::SELECT(DB::RAW("UPDATE active_accounts Set NAME_MATCH = ".$removeSpecialCharaters.";"));
    }
}
