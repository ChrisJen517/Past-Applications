<?php

namespace App\Http\Controllers\Admin;

use Auth;
use App\Models\Agent;
use App\Models\Corporate_Admin;
use App\Models\Corporation;
use App\Http\Controllers\Controller;
use App\Models\Manager;
use App\Models\old_passwords;
use App\Models\Role;
use App\Models\Team;
use App\User;
use Carbon\Carbon;
use DataTables;
use File;
use Config;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use PHPMailer\PHPMailer\PHPMailer;
use Storage;
use App\Mail\ExceptionOccured;
use App\Models\Directory_Agent;
use App\Models\Powerlead;
use App\Jobs\PowerleadRedistributionQueue;
use DB;
use App\Models\Access_Levels;
use App\Models\Powerlead_Directory_Manager;
use App\RNNMailer;
use App\Traits\AccountDistrubution;
use App\Traits\DirectoryAgentAccounts;
use App\Traits\FindMinimumIds;
use App\Traits\MangeRoleAccounts;
use Illuminate\Support\Facades\Log;


class AdminManageAccountsController extends Controller
{
    use AccountDistrubution, FindMinimumIds, MangeRoleAccounts;

    private $notAllowedIds = array(
        '1901', '1902', '1904', '3333', '9999'
    );

    public function showManageAccounts()
    {
        $corporations = Corporation::get();
        $access_levels = Access_Levels::get();
        $minimumDirectPower = $this->getMinimumPowerleadDirectoryID();

        return view('admin/pages/manageAccounts')->with('corporations', $corporations)->with('access_levels', $access_levels)->with('minimumDirectPower', $minimumDirectPower);
    }

    public function getUsersTable($deactive)
    {
        if($deactive == 0)
            $users = User::where('role', '!=', 'corporate_api')->where('is_deactivated', 0)->with('corporation_agent_link')->with('agent_link')->with('corporation_manager_link')->with('manager_link')->with('powerlead_link')->with('corporation_corporate_admin_link')->with('directory_agent_link')->get();
        else
            $users = User::where('role', '!=', 'corporate_api')->with('corporation_agent_link')->with('agent_link')->with('corporation_manager_link')->with('manager_link')->with('corporation_corporate_admin_link')->with('powerlead_link')->with('directory_agent_link')->get();
        $collection = null;
        foreach ($users as $user) {

            switch ($user->role) {
                case 'agent':
                    $link = $user->corporation_agent_link;
                    break;
                case 'manager':
                    $link = $user->corporation_manager_link;
                    break;
                case 'corporate_admin':
                    $link = $user->corporation_corporate_admin_link;
                    break;
                default:
                    $link = null;
            }

            $global = ['user_id' => $user->user_id, 'name' => $user->first_name . ' ' . $user->last_name, 'first_name' => $user->first_name, 'last_name' => $user->last_name, 'email' => $user->email,
                'active' => $user->active, 'role' => $user->role, 'is_deactivated' => $user->is_deactivated, 'has_access' => $user->has_access, 'corporation' => 'none',
                'role_list' => $user->role_list, 'agent_id' => $user->agent_link->agent_id ?? NULL, 'directory_agent_id' => $user->directory_agent_link->directory_agent_id ?? NULL, 'powerlead_id' => $user->powerlead_link->id ?? NULL];

            if ($link != null)
                $global = array_merge($global, ['corporation_id' => $link->corporation_id, 'corporation' => $link->name, 'corporation_active' => $link->active]);

            if($user->role == 'directory_agent'){
                $type = $user->directory_agent_link->dir_account_type ?? 'fresh';
                $global = array_merge($global, ['dir_account_type' => $type]);
            } else if($user->role == 'agent'){
                $global = array_merge($global, ['team_id' => $user->agent_link->team_id ?? NULL]);
            } else if($user->role == 'manager'){
                $global = array_merge($global, ['team_id' => $user->manager_link->team_id ?? NULL]);
            }

            if ($collection == null) {
                $collection = collect(
                    [$global]
                );
            } else {
                $collection->push(
                    $global
                );
            }
        }
        return DataTables::of($collection)->make(true);
    }

    public function getTeamNames($id)
    {
        $teams = Team::where('corporation_id', '=', $id)->where('is_deactivated', 0)->get();

        return response()->json($teams);
    }

    public function getManagerNames($id)
    {
        $managers = Manager::where('team_id', '=', $id)->with('user_link')->get();

        return response()->json($managers);
    }

    use DirectoryAgentAccounts;
    public function addAccount(request $request)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required|unique:users',
        ]);

        if(!empty($request->agent_id)) {
            if(Agent::where('agent_id', $request->agent_id)->exists() || in_array($request->agent_id, $this->notAllowedIds))
                return back()->with('error', "Agent ID is already in use");
        }
        if(!empty($request->directory_agent_id)) {
            if(Directory_Agent::where('directory_agent_id', $request->directory_agent_id)->exists())
                return back()->with('error', "Agent ID is already in use");
        }
        if(!empty($request->powerlead_id)) {
            if(Powerlead::where('id', $request->powerlead_id)->exists())
                return back()->with('error', "Agent ID is already in use");
        }

        $role_list = $request->input('role_list');
        if($role_list == null){
            $role_list = [];
        }
        if(!in_array($request->input('role'), $role_list))
            $role_list[] = $request->input('role');
        $role_list = implode(',', $role_list);

        $user = new User();
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->email = $request->input('email');
        $user->role_list = $role_list;
        $token = rand(100000000000, 999999999999);
        $user->password = bcrypt($token);
        $user->role = $request->input('role');
        $user->password_valid = 0;
        $user->active = 1;
        $user->save();

        switch($request->input('role')) {
            case 'corporate_admin':
                $new_account = new Corporate_Admin();
                $new_account->corporation_id = $request->input('corporation');
                break;
            case 'manager':
                $new_account = new Manager();
                $new_account->corporation_id = $request->input('corporation');
                $new_account->team_id = $request->input('team');
                break;
            case 'powerlead_directory_manager':
                $new_account = new Powerlead_Directory_Manager();
                break;
            case 'agent':
                $new_account = new Agent();
                $new_account->corporation_id = $request->input('corporation');
                $new_account->team_id = $request->input('team');
                $new_account->agent_id = $request->agent_id;
                break;
            case 'directory_agent':
                $new_account = new Directory_Agent();
                $new_account->dir_account_type = $request->dir_account_type;
                $new_account->directory_agent_id = $request->directory_agent_id;
                break;
            case 'powerlead':
                $new_account = new Powerlead();
                $new_account->id = $request->powerlead_id;
                $this->dispatch(new PowerleadRedistributionQueue(true));
                break;
        }


        if(!empty($new_account)){
            $new_account->user_id = $user->user_id;
            $new_account->save();
        }

        $this->AddRoleAccounts($user, $request->input('corporation'), $request->input('team'), $request->agent_id, $request->directory_agent_id, $request->powerlead_id);

        $path = '/home/rocky/public_html/ProfilePictures/'.$user->user_id.'';
        $env = Config::get('app.env');
        if ($env != 'prod') {
            $path = public_path('ProfilePictures/'.$user->user_id.'');
        }
        if (!file_exists($path)) {
            mkdir($path);
        }
        $file = File::get(public_path('ProfilePictures/baseAvatar.png'));
        File::put(public_path('ProfilePictures/' . $user->user_id . '/avatar.png'), $file);

        $mail = new RNNMailer(true, $user);

        //Recipients
        $mail->addAddress($request->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $request->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        return redirect()->back()->with('message', 'Account Created');
    }

    public function updateAccount(Request $request)
    {
        $this->validate($request, [
            'first_name' => 'required',
            'last_name' => 'required',
            'email' => 'required',
        ]);

        if(!empty($request->agent_id)) {
            if(Agent::where('agent_id', $request->agent_id)->where('user_id', '!=', $request->idName)->exists() || in_array($request->agent_id, $this->notAllowedIds))
                return back()->with('error', "Agent ID is already in use");
        }
        if(!empty($request->directory_agent_id)) {
            if(Directory_Agent::where('directory_agent_id', $request->directory_agent_id)->where('user_id', '!=', $request->idName)->exists())
                return back()->with('error', "Agent ID is already in use");
        }
        if(!empty($request->powerlead_id)) {
            if(Powerlead::where('id', $request->powerlead_id)->where('user_id', '!=', $request->idName)->exists())
                return back()->with('error', "Agent ID is already in use");
        }

        $list = '';
        if($request->exists('permissions')){
            foreach($request->permissions as $permission){
                $list = $list.$permission.',';
            }
        }
        $list = substr_replace($list ,'', -1);

        $user = User::find($request->idName);

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;

        $role_list = $request->input('role_list');
        if($role_list == null){
            $role_list = [];
        }
        $role_list = implode(',', $role_list);
        $old_role_list = $user->role_list;
        $user->role_list = $role_list;

        //if agent has their accounts changed removes them
        $redistribute = false;
        if(($user->has_access != $list) && ($user->role == 'agent')){
            $redistribute = true;
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = '.$user->agent_link->agent_id.';'));
        }

        if($user->role == "directory_agent"){
            $directory_agent = Directory_Agent::where('user_id', $user->user_id)->first();
            $directory_agent->dir_account_type = $request->dir_account_type;
            $directory_agent->save();
        }

        $user->has_access = $list;

        if ($request->newPassword != null) {
            $date = Carbon::now()->subDays(365)->format('Y-m-d');
            $passwordHistories = $user->passwordHistories()->where("created_at", '>', $date)->get();
            foreach ($passwordHistories as $passwordHistory) {
                echo $passwordHistory->password;
                if (Hash::check($request->get('newPassword'), $passwordHistory->password)) {
                    // The passwords matches
                    return redirect()->back()->with("error", "Your new password can not be same as any of your recent passwords. Please choose a new password.");
                }
            }

            $oldPassword = new old_passwords();
            $oldPassword->password = $user->password;
            $oldPassword->user_id = $user->user_id;
            $oldPassword->save();
            $user->password = bcrypt($request->newPassword);
            $user->password_valid = 1;
        }

        if($old_role_list != $role_list){
            $corporationId = null;
            $teamId = null;
            switch ($user->role){
                case "corporate_admin":
                    $corporate_admin = Corporate_Admin::select('corporation_id')->where('user_id', $user->user_id)->first();
                    $corporationId = $corporate_admin->corporation_id;
                    $teamId = null;
                break;
                case "manager":
                    $manager = Manager::select('corporation_id', 'team_id')->where('user_id', $user->user_id)->first();
                    $corporationId = $manager->corporation_id;
                    $teamId = $manager->team_id;
                break;
                case "agent":
                    $agent = Agent::select('corporation_id', 'team_id')->where('user_id', $user->user_id)->first();
                    $corporationId = $agent->corporation_id;
                    $teamId = $agent->team_id;
                break;
            }

            $this->AddRoleAccounts($user, $corporationId, $teamId, $request->agent_id, $request->directory_agent_id, $request->powerlead_id);

            //checks to see if there are any missing roles
            $old_role_list = explode(',', $old_role_list);
            $role_list = explode(',', $role_list);
            $missing_roles = [];
            foreach($old_role_list as $old_role){
                if(!in_array($old_role, $role_list))
                    $missing_roles[] = $old_role;
            }
            //deactivates any missing roles
            if(!empty($missing_roles)){
                $this->deactivateRoles($user, $missing_roles);
            }
            if(in_array($user->role, $missing_roles))
                $user->role = $role_list[0];
        }

        $user->save();

        //if the account is removed, redistribute
        if($redistribute)
            $this->redistributeToAgent($user->agent_link->agent_id);

        return redirect()->back()->with('message', 'Account Updated');
    }

    public function sendPasswordReset($id)
    {
        $User = User::find($id);

        $oldPassword = new old_passwords();
        $oldPassword->password = $User->password;
        $oldPassword->user_id = $User->user_id;
        $oldPassword->save();
        $token = rand(100000000000, 999999999999);
        $User->password = bcrypt($token);
        $User->password_valid = 0;
        $User->save();

        $mail = new RNNMailer(true, $User);

        //Recipients
        $mail->addAddress($User->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $User->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        Log::debug("Password reset for: ".$User->first_name." ".$User->last_name." By: ".Auth::user()->first_name." ".Auth::user()->last_name);
    }

    public function blockAccount($id)
    {
        $user = User::find($id);

        if($user == Auth::user()) {
            $data[] = 'You cannot delete yourself';
            $data[] = "error";
            return response()->json($data);
        }

        $user->active = 0;
        $name = $user->first_name.' '.$user->last_name;
        $user->save();

        if($user->role == 'agent')
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = '.$user->agent_link->agent_id.';'));

        if($user->role == 'directory_agent'){
            $agent = Directory_Agent::where('user_id', $id)->first();
            $this->removeAccounts($agent->directory_agent_id);
            $agent->active = 0;
            $agent->save();
        }

        if($user->role == "powerlead"){
            DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 2, `POWERLEAD_AGENT_ID` = null WHERE `POWERLEAD_CAPCODE` = 3 AND POWERLEAD_AGENT_ID = '.$user->powerlead_link->id.';'));
            DB::select(DB::raw('UPDATE `powerlead_accounts` SET `powerlead_agent_id` = NULL WHERE `verified` is null AND `powerlead_agent_id` = '.$user->powerlead_link->id.';'));
        }

        $this->deactivateRoles($user, explode(',', $user->role_list));

        return response()->json($name);
    }

    public function unblockAccount($id)
    {
        $user = User::find($id);

        $user->active = 1;
        $message = $user->first_name.' '.$user->last_name ;
        $user->save();

        switch ($user->role){
            case 'agent':
                $message = $this->redistributeToAgent($user->agent_link->agent_id);
                // $this->redistributeToAgent($user->agent_link->agent_id);
            break;
            case 'powerlead':
                $this->dispatch(new PowerleadRedistributionQueue(true));
            break;
            case 'directory_agent':
                $agent = Directory_Agent::where('user_id', $id)->first();
                $agent->active = 1;
                $agent->save();
                $this->distributeDirectory();
            break;
        }

        $this->AddRoleAccounts($user, null, null);
        return response()->json($message);
    }

    public function deleteAccount($id)
    {
        $user = User::find($id);
        if($user == Auth::user()) {
            $data[] = 'You cannot delete yourself';
            $data[] = "error";
            return response()->json($data);
        }

        if($user->role == 'corporate_admin')
        {
            $corporate_admin = Corporate_admin::where('user_id', $user->user_id)->first();
            $all_corporate_admins = Corporate_admin::where('corporation_id', $corporate_admin->corporation_id)->get();

            $corporate_admin_count = 0;
            foreach($all_corporate_admins as $corp){
                if($corp->user_link->is_deactivated == 0)
                    $corporate_admin_count++;
            }

            if($corporate_admin_count <= 1 )
            {
                $data[] = 'Cannot Deactivate Corportate Admin Account. This is the last remaining Corporate Admin for this Corporation.';
                $data[] = "error";
                return response()->json($data);
            }
        } elseif ($user->role == 'agent') {
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = '.$user->agent_link->agent_id.';'));
        } elseif($user->role == 'directory_agent'){
            $DirectoryAgent = Directory_Agent::where('user_id', $user->user_id)->first();
            $this->removeAccounts($DirectoryAgent->directory_agent_id);
            $DirectoryAgent->active = 0;
            $DirectoryAgent->save();
        }
        $name = $user->first_name.' '.$user->last_name;
        $user->active = 0;
        $user->is_deactivated = 1;
        $user->deactivate_date = Carbon::now();
        $user->save();

        $this->deactivateRoles($user, explode(',', $user->role_list));

        $data[] = $name.' was deactivated!';
        $data[] = "success";
        return response()->json($data);
    }



    public function reactivateAccount($id, $team_id)
    {
        $user = User::find($id);

        if($team_id == null && ($user->role == 'agent' || $user->role == 'manager')){
            $data[] = 'No available teams to send agent to.';
            $data[] = "error";
            return response()->json($data);
        }

        switch($user->role){
            case 'corporate_admin':
                $role_profile = Corporate_admin::where('user_id', $user->user_id)->first();
                break;
            case 'directory_agent':
                $role_profile = Directory_Agent::where('user_id', $user->user_id)->first();
                $role_profile->active = 1;
                break;
            case 'powerlead':
                $role_profile = Powerlead::where('user_id', $user->user_id)->first();
                $role_profile->active = 1;
                break;
            case 'agent':
                $role_profile = Agent::where('user_id', $id)->first();
                $role_profile->team_id = $team_id;
                $role_profile->active = 1;
                break;
            case 'manager':
                $role_profile = Manager::where('user_id', $id)->first();
                $role_profile->team_id = $team_id;
                break;
            case 'admin':
                $role_profile = NULL;
                break;
            default:
                $data[] = 'We ran into an issue, please reach out if this persists.';
                $data[] = "error";
                return response()->json($data);
        }

        if($role_profile != NULL){
            if($corporation = Corporation::where("corporation_id", $role_profile->corporation_id)->first() && $role_profile->corporation_id != NULL){
                $corporation = Corporation::where("corporation_id", $role_profile->corporation_id)->first();
                if($corporation->active != 1){
                    $data[] = 'This corporation is not active, please reactivate the corporation before reactivating any users.';
                    $data[] = "error";
                    return response()->json($data);
                }
            } else if(!Corporation::where("corporation_id", $role_profile->corporation_id)->exists() && $role_profile->corporation_id != NULL){
                $data[] = 'There seems to have been a issue, please reach out for assistance.';
                $data[] = "error";
                return response()->json($data);
            }
            $role_profile->save();
        }

        $name = $user->first_name.' '.$user->last_name;
        $user->active = 1;
        $user->is_deactivated = 0;
        $user->deactivate_date = NULL;
        $user->save();

        $this->AddRoleAccounts($user, null, $team_id);

        $data[] = $name.' was reactivated!';
        $data[] = "success";
        return response()->json($data);
    }
}