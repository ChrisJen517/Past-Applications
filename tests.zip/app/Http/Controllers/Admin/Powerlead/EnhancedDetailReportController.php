<?php

namespace App\Http\Controllers\Admin\Powerlead;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Capcode;
use App\Models\Worked_History;
use App\User;
use App\Models\Directory_Agent;
use App\Models\Powerlead;
use App\Models\Powerlead_Directory_Manager;
use DateTime;
use DB;

class EnhancedDetailReportController extends Controller
{
    public function showReport(){
        $data = $this->getData();

        return view('/admin/pages/powerlead/enhancedDetailReport')->with('months', $data);
    }

    public function getData(){
        //needed date range
        $dates[] = date('Y-m-d', strtotime('first day of this months - 3 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 2 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 1 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months + 1 months'));

        //initalizes the final array
        $finalData[intval(date('m', strtotime($dates[3])))] = [];
        $finalData[intval(date('m', strtotime($dates[2])))] = [];
        $finalData[intval(date('m', strtotime($dates[1])))] = [];
        $finalData[intval(date('m', strtotime($dates[0])))] = [];

        $agents = Powerlead::select('user_id', 'created_at', 'id')->with('user_link')->get();

        //gets needed capcodes
        $capcodes = Capcode::select('capcode', 'id')->whereIn('capcode', [2216, 2217, 2211, 1111, 1112, 4411, 4408, 6000])->get();
        $capcodeIds = [];
        $verified   = [];
        $received   = [];
        foreach($capcodes as $capcode){
            if( ($capcode->capcode == 2216) || ($capcode->capcode == 2217) || ($capcode->capcode == 2211))
                $capcodeIds[] = "'".$capcode->id."'";
            else if( ($capcode->capcode == 1111) || ($capcode->capcode == 1112))
                $verified[] = "'".$capcode->id."'";

            if( ($capcode->capcode == 1111) || ($capcode->capcode == 1112) || ($capcode->capcode == 4411) || ($capcode->capcode == 4408) || ($capcode->capcode == 6000))
                $received[] = "'".$capcode->id."'";
        }
        $capcodeIds = implode(",", $capcodeIds);
        $verified = implode(",", $verified);
        $received = implode(",", $received);

        
        //get all of the history
        $history = DB::SELECT(DB::RAW("SELECT pa.powerlead_agent_id as 'id_agent',
        MONTH(wh.created_at) AS 'created_month',
        COUNT(IF(capcode in (".$capcodeIds.") AND wh.notes like '% Sent by Powerlead%', 1, NULL)) as 'sent',
        COUNT(IF(capcode in (".$verified."), 1, NULL) ) as 'verified',
        COUNT(IF(capcode in  (".$received."), 1, NULL) ) as 'received'
        FROM worked_history wh
        	INNER JOIN powerlead_accounts pa on wh.active_account_id = pa.active_account_id
        WHERE wh.created_at BETWEEN '".$dates[0]."' AND '".$dates[4]."' AND pa.powerlead_agent_id IS NOT NULL AND pa.powerlead_agent_id != 0
        GROUP BY pa.powerlead_agent_id, MONTH(wh.created_at);"));

        //moves history into the final array
        foreach($history as $row){
            $finalData[$row->created_month][$row->id_agent] = [
                'agent_id' => $row->id_agent,
                'name' => '',
                'sent' => $row->sent,
                'received' => $row->received,
                'verified' => $row->verified
            ]; 
        }

        //sets all the agents and their names
        for($i = 0; $i <= 3; $i++){
            $monthNumber = intval(date('m', strtotime($dates[$i])));

            foreach($agents as $agent){
                if(($agent->user_link->deactivate_date < $dates[$i] && $agent->user_link->is_deactivated == 1) || ($agent->created_at >= $dates[$i])) {
                    if(isset($finalData[$monthNumber][$agent->id]))
                        unset($finalData[$monthNumber][$agent->id]);
                    continue;
                }

                if(isset($finalData[$monthNumber][$agent->id])){
                    $finalData[$monthNumber][$agent->id]['name'] = $agent->user_link->first_name." ".$agent->user_link->last_name;
                } else {
                    $finalData[$monthNumber][$agent->id] = [
                        'agent_id' => $agent->id,
                        'name' => $agent->user_link->first_name." ".$agent->user_link->last_name,
                        'sent' => 0,
                        'received' => 0,
                        'verified' => 0
                    ];
                }
            }
        }

        return $finalData;
    }
}