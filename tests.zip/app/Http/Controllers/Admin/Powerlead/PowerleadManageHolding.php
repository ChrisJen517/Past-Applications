<?php

namespace App\Http\Controllers\Admin\Powerlead;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use App\Models\Powerlead;
use App\Models\Active_Account;
use Excel;
use DateTime;
use App\ExportPowerleadQue;
use App\Jobs\PowerleadScoreDistributionQueue;
use App\Jobs\PowerleadRedistributionQueue;
use App\Models\Powerlead_Settings;

class PowerleadManageHolding extends Controller
{
    public function managePowerleadHolding(){

        $active_accounts_assigned = DB::SELECT(DB::RAW("SELECT users.first_name, users.last_name, powerlead_agent.id, (SELECT COUNT(*) FROM active_accounts WHERE active_accounts.POWERLEAD_AGENT_ID = powerlead_agent.id AND active_accounts.POWERLEAD_CAPCODE = 3) AS 'TOTAL_ACCOUNTS' FROM users inner join powerlead_agent on users.user_id = powerlead_agent.user_id where users.is_deactivated = 0  GROUP BY users.user_id;"));
        $unassigned_accounts = Active_Account::selectRaw("POESCORE, COUNT(IF(POWERLEAD_CAPCODE = 2, 1, null)) AS UNASSIGNED, COUNT(IF(POWERLEAD_CAPCODE = 2 OR POWERLEAD_CAPCODE = 3, 1, null)) AS ALL_ACCOUNTS, COUNT(IF(POWERLEAD_CAPCODE = 1, 1, null)) AS ON_HOLD")->groupBy('POESCORE')->get();

        $totalActive = 0;
        $totalUnassigned = 0;
        $totalHold = 0;
        for ($i = 0; $i < count($active_accounts_assigned); $i++) {
            $totalActive += $active_accounts_assigned[$i]->TOTAL_ACCOUNTS ?? 0;
        }

        //put into an array to make sure numbers 1-10 are displayed
        $unassigned_accounts_array = [];
        for ($i = 1; $i < 11; $i++) {
            $unassigned_account = $unassigned_accounts->where('POESCORE', $i)->first();
            $totalUnassigned += $unassigned_account->UNASSIGNED ?? 0;
            $totalHold += $unassigned_account->ON_HOLD ?? 0;
            $unassigned_accounts_array[$i] = ['UNASSIGNED' => $unassigned_account->UNASSIGNED ?? 0, 
                                            'ALL_ACCOUNTS' => $unassigned_account->ALL_ACCOUNTS ?? 0, 
                                            'ON_HOLD' => $unassigned_account->ON_HOLD ?? 0];
        }

        return view('admin/pages/powerlead/managePowerleadHolding')->with('active_accounts_assigned', $active_accounts_assigned)
        ->with('unassigned_accounts', $unassigned_accounts_array)->with('totalActive', $totalActive)->with('totalUnassigned', $totalUnassigned)->with('totalHold', $totalHold);
    }

    public function releasePowerleadHeldAccounts($score){
        DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 2 WHERE POWERLEAD_CAPCODE = 1 AND POESCORE = '.$score.';'));

        $this->dispatch(new PowerleadScoreDistributionQueue());

        return redirect()->back()->with('success', 'Released All Active Accounts with the Score of '.$score);
    }

    public function holdPowerleadAccounts($score, $type){
        if($type == "All")
            DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 1 WHERE (POWERLEAD_CAPCODE = 2 or POWERLEAD_CAPCODE = 3)  AND POESCORE = '.$score.';'));
        else
            DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 1 WHERE POWERLEAD_CAPCODE = 2  AND POESCORE = '.$score.';'));

        $this->dispatch(new PowerleadScoreDistributionQueue());

        return redirect()->back()->with('success', 'Held '.$type.' Active Accounts with the Score of '.$score);
    }

    public function powerleadQueue($id)
    {
        $accounts = Active_Account::select('ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
        'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
        'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR',
        'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE',
        'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER','CLIENT_NAME', 'CLIENT_PHONE', 'POWERLEAD_ID', 'POWERLEAD_AGENT_ID')->where('POWERLEAD_AGENT_ID', $id)->get();
        return $accounts->ToArray();
    }
    public function exportPowerleadQueue($id){

        $export = new ExportPowerleadQue($this->powerleadQueue($id));
        $agent = Powerlead::where('id', $id)->with('user_link')->first();
        $dateTime = new DateTime();
        $timestamp = $dateTime->getTimestamp();
        $file = 'Agent_Queue'.'-'.$agent->user_link->last_name.'-'.$agent->user_link->first_name.'-'.$timestamp.'.xlsx';
        Excel::store($export, $file);
        return response()->download(storage_path('app/public/'.$file));
    }

    public function redistrubuteAccounts(){
        $this->dispatch(new PowerleadRedistributionQueue(true));
        return redirect()->back()->with('success', 'Redistributing all Powerlead Accounts, This will take a moment to update');
    }

    public function tossAccounts(Request $request){
        if($request->type == 'toTeam')
            return $this->clearAgentAccounts($request);
        else
            return $this->tossAgentAccounts($request);
    }

    public function clearAgentAccounts(Request $request){
        $this->validate($request, [
            'agent_selected' => 'required',
        ]);

        $limit = $request->max_per_agent;
        $scores = $request->account_score;

        $powerlead_settings = Powerlead_Settings::first();
        $first = $powerlead_settings->priority;
        $second = $powerlead_settings->second_priority;

        $accounts = Active_Account::select('ID', 'POWERLEAD_ID')
        ->where('POWERLEAD_AGENT_ID', $request->agent_selected)->where('POWERLEAD_CAPCODE', 3)
        ->when(!empty($scores), function ($query) use ($scores) {
            return $query->whereIn('POESCORE', $scores);
        })
        ->when($first, function ($query, $first) {
            return $query->orderByRaw($first);
        })
        ->when($second, function ($query, $second) {
            return $query->orderByRaw($second);
        })
        ->when($limit, function ($query, $limit){ return $query->limit($limit);})
        ->get();

        $accountIds = [];
        $powerleadIds = [];
        foreach($accounts as $account){
            $accountIds[] = $account->ID;
            $powerleadIds[] = $account->POWERLEAD_ID;
        }

        if(!empty($accountIds))
            DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 2, `POWERLEAD_AGENT_ID` = null WHERE `ID` IN (' . implode(',', $accountIds). ');'));
        if(!empty($powerleadIds))
            DB::select(DB::raw('UPDATE `powerlead_accounts` SET `powerlead_agent_id` = null  WHERE `id` IN (' . implode(',', $accountIds) . ');'));

        return back()->with('success', 'Successfully Updated Accounts');
    }

    public function tossAgentAccounts(Request $request){
        $this->validate($request, [
            'send_to_agent' => 'required',
        ]);

        //moves arrays from request into a variable for consistency with manager/corporate admin version
        $scores = $request->account_score;
        $sendAgents = $request->send_to_agent;

        if($request->type == 'fromAgent'){
            $fromAgent = $request->agent_selected;
            $fromTeam = null;
        }
        else{
            $fromAgent = null;
            $fromTeam = true;
        }

        $powerlead_settings = Powerlead_Settings::first();
        $first = $powerlead_settings->priority;
        $second = $powerlead_settings->second_priority;
        $maxForAgents = $powerlead_settings->max_accounts;
        $maximumAccountsNeeded = $maxForAgents * count($sendAgents);

        $accounts = Active_Account::select('ID', 'POWERLEAD_ID')
            ->when($fromTeam, function ($query){
                //used when from queue to agent
                $query->where('POWERLEAD_AGENT_ID', null)->where('POWERLEAD_CAPCODE', 2);
            })
            ->when($fromAgent, function ($query, $fromAgent){
                //used from agent to agent
                $query->where('POWERLEAD_AGENT_ID', $fromAgent)->where('POWERLEAD_CAPCODE', 3);
            })
            ->when(!empty($scores), function ($query) use ($scores) {
                return $query->whereIn('POESCORE', $scores);
            })
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })
            ->limit($maximumAccountsNeeded)
            ->get();

        $agentCounts = Active_Account::selectRAW('POWERLEAD_AGENT_ID, count(*) as totalAccounts')
        ->whereIn('POWERLEAD_AGENT_ID', $sendAgents)
        ->where('POWERLEAD_CAPCODE', 3)
        ->groupBy('POWERLEAD_AGENT_ID')
        ->get();

        //finds the max of each agent
        $totalCount = count($accounts);
        if ($request->max_per_agent)
            $potentialMax = $request->max_per_agent;
        else
            $potentialMax = ceil($totalCount / count($sendAgents));

        //initalizes the arrays for the list of agents
        foreach($sendAgents as $sendAgent){
            $agentCountArray[] = 0;
            $agentUpdateArray[] = "";
            $powerUpdateArray[] = '';

            //finds if the max accounts should be based on the count or
            $agentCount = $agentCounts->where('POWERLEAD_AGENT_ID', $sendAgent)->first()->totalAccounts ?? 0;
            $toMax = $maxForAgents - $agentCount;
            if($toMax < $potentialMax)
                $max[] = $toMax;
            else
                $max[] = $potentialMax;
        }

        while ($totalCount > 0) {
            $i = 0;
            $maxCount = 0;
            foreach ($accounts as $account) {
                $totalCount--;
                $i++;
                //checking to see if looped through all agents
                if ($i >= count($sendAgents)) {
                    $i = 0;
                }
                //checking to see if agent has reached max
                if ($agentCountArray[$i] >= $max[$i]) {
                    $maxCount++;
                    //check to see if all agents have reached max
                    if ($maxCount == count($agentCountArray)) {
                        break;
                    }
                    continue;
                }

                $agentUpdateArray[$i] = $agentUpdateArray[$i] . '"' . $account->ID . '", ';
                $powerUpdateArray[$i] = $powerUpdateArray[$i] . '"' . $account->POWERLEAD_ID . '", ';
                $agentCountArray[$i] += 1;
            }
        }

        //updates the database
        for ($i = 0; $i < count($sendAgents); $i++) {
            if ($agentUpdateArray[$i] != "") {
                $agentUpdateArray[$i] = substr_replace($agentUpdateArray[$i], "", -2);
                DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 3, `POWERLEAD_AGENT_ID` = ' . $sendAgents[$i] . '  WHERE `ID` IN (' . $agentUpdateArray[$i] . ');'));
            }
            if ($powerUpdateArray[$i] != "") {
                $powerUpdateArray[$i] = substr_replace($powerUpdateArray[$i], "", -2);
                DB::select(DB::raw('UPDATE `powerlead_accounts` SET `powerlead_agent_id` = ' . $sendAgents[$i] . '  WHERE `id` IN (' . $powerUpdateArray[$i] . ');'));
            }
        }

        return back()->with('success', 'Successfully Updated Accounts');
    }
}