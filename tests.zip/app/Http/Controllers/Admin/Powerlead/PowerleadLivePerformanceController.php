<?php

namespace App\Http\Controllers\Admin\Powerlead;

use App\Http\Controllers\Controller;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PowerleadLivePerformanceController extends Controller
{
    public function getPowerleadDatedLivePeformanceReport(request $request)
    {
        if ($request->from == null) {
            $from_date = Carbon::now()->format('Y-m-d');
        } else {
            $from_date = $request->from;
            $from_date = date('Y-m-d', strtotime($request->from));
        }
        if ($request->to == null) {
            $to_date = Carbon::now()->format('Y-m-d');
        } else {
            $to_date = $request->to;
            $to_date = date('Y-m-d', strtotime($request->to));
        }

        $message = "From ".$from_date." to ".$to_date;

        $reportData = $this->getReportData($from_date, $to_date);
        $livePerformance = $reportData[0];
        $chart_livePerformance = $reportData[1];
        $averageTimeAll = $reportData[2];
        $totalTimeAll = $reportData[3];

        return view('/admin/pages/powerlead/powerleadLivePerformance')->with('livePerformances', $livePerformance)->with('timeMessage', $message)
        ->with('chart_livePerformance', $chart_livePerformance)->with('averageTimeAll', $averageTimeAll)->with('totalTimeAll', $totalTimeAll);
    }

    public function getReportData($from_date, $to_date){
        $work_historys = Powerlead_Accounts::selectRaw("powerlead_agent_id AS AGENT_ID, COUNT(ID) AS TOTAL_WORKED, SUM(timespent)/COUNT(ID) AS AVERAGE_TIME, SUM(timespent) TOTAL_TIME,
        COUNT(IF(verified = 1,1,NULL)) AS 'TOTAL_VERIFIED'")
        ->whereRaw("updated_at >= DATE('$from_date') AND updated_at <= DATE_ADD('$to_date', INTERVAL 1 DAY) AND verified is not null AND POWERLEAD_AGENT_ID IS NOT NULL")
        ->groupBy('powerlead_agent_id')->get();

        $agents = Powerlead::select('id', 'user_id')->whereRaw("date(created_at) <= '$to_date'")->with('user_link')->get();

        $averageTimeAll = 0;
        $totalTimeAll = 0;
        $livePerformance = [];
        $chart_livePerformance = [];

        foreach ($agents as $agent) {
            if(($agent->user_link->deactivate_date < $from_date) && ($agent->user_link->is_deactivated == 1))
                continue;

            $work_history = $work_historys->where('AGENT_ID', $agent->id)->first();
            
            //if the agent has no history create a blank history
            if($work_history == null){
                $livePerformance[] = array(
                    "AGENT_ID" => $agent->id,
                    "AGENT_NAME" => $agent->user_link->first_name . " " . $agent->user_link->last_name,
                    "TOTAL_WORKED" => 0,
                    "AVERAGE_TIME_SPENT" => '0:00',
                    "TOTAL_TIME" => '00:00:00',
                    "UNVERIFIED" => 0,
                    "VERIFIED" => 0,
                    "AVERAGE_VERIFIED" => "0%",
                    "AVERAGE_NOT_FOUND" => "0%",
                );
                continue;
            }
            //otherwise just fill in the history data
            else{
                $averageTimeAll += $work_history->AVERAGE_TIME;
                $average_time_spent = $this->getAverageTime($work_history->AVERAGE_TIME);
                $totalTimeAll += $work_history->TOTAL_TIME;
                $totalTime = $this->getTotalTime($work_history->TOTAL_TIME);

                $average_verified = $work_history->TOTAL_VERIFIED / $work_history->TOTAL_WORKED;
                $average_verified = round(100 * $average_verified, 0). "%";
                $unverified = $work_history->TOTAL_WORKED - $work_history->TOTAL_VERIFIED;
                $average_not_found = round(100 * $unverified / $work_history->TOTAL_WORKED, 0)."%";

                $fullPowerleadName = $agent->user_link->first_name . " " . $agent->user_link->last_name;

                //sets data for the graph
                $livePerformance[] = array(
                    "AGENT_ID" => $work_history->AGENT_ID,
                    "AGENT_NAME" => $fullPowerleadName,
                    "TOTAL_WORKED" => $work_history->TOTAL_WORKED,
                    "AVERAGE_TIME_SPENT" => $average_time_spent,
                    "TOTAL_TIME" => $totalTime,
                    "UNVERIFIED" => $unverified,
                    "VERIFIED" => $work_history->TOTAL_VERIFIED,
                    "AVERAGE_VERIFIED" => $average_verified,
                    "AVERAGE_NOT_FOUND" => $average_not_found,
                );

                //sets data for the report
                $chart_livePerformance[] = array(
                    $fullPowerleadName,
                    $unverified,
                    $unverified,
                    $work_history->TOTAL_VERIFIED,
                    $work_history->TOTAL_VERIFIED,
                );
            }
        }

        //gets the average time for all agents
        if(count($chart_livePerformance) != 0){
            $averageTimeAll = $this->getAverageTime($averageTimeAll/count($chart_livePerformance));
        }
        else{
            $averageTimeAll = "0:00";
        }

        //gets the total time for all agents
        $totalTimeAll = $this->getTotalTime($totalTimeAll);

        $finalData[] = $livePerformance;
        $finalData[] = $chart_livePerformance;
        $finalData[] = $averageTimeAll;
        $finalData[] = $totalTimeAll;

        return $finalData;
    }

    public function getAverageTime($timeSeconds){
        $average_time_spent_minutes = (int) ($timeSeconds/60);
        $average_time_spent_seconds =  (int) ($timeSeconds%60);
        if ($average_time_spent_seconds < 10)
            $average_time_spent_seconds = "0" . $average_time_spent_seconds;
        return $average_time_spent_minutes . ":" . $average_time_spent_seconds;
    }

    public function getTotalTime($timeSeconds){
        $times = [];
        $times[] = (int) ($timeSeconds % 60);
        $times[] = (int) (($timeSeconds/60)%60);
        $times[] = (int) (($timeSeconds/60)/60);
        for($i = 0; $i < 3; $i++){
            if($times[$i] < 10)
                $times[$i] = "0".$times[$i];
        }
        return $times[2].":".$times[1].":".$times[0];
    }
}