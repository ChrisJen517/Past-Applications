<?php

namespace App\Http\Controllers\Admin\Powerlead;

use App\Models\Active_Account;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Settings;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;

class PowerleadClosedAccountsController extends Controller
{
    public function getPowerleadDatedWorkHistory(request $request)
    {
        if($request->from == null)
            $from_date = date("Y-m-d");
        else
            $from_date = date('Y-m-d', strtotime($request->from));
        if($request->to == null)
            $to_date = date("Y-m-d");
        else
            $to_date = date('Y-m-d', strtotime($request->to));

        $timeMessage = "From ".$from_date." To ".$to_date;

        $to_date = date("Y-m-d", strtotime($to_date." +1 day"));

        $verifiedHistory = Powerlead_Accounts::
            selectRaw('powerlead_accounts.id as id, powerlead_accounts.local_phone, powerlead_accounts.email, powerlead_accounts.fax, 
                powerlead_accounts.local_address, powerlead_accounts.main_phone, powerlead_accounts.powerlead_agent_id, active_accounts.EMPL_NAME as active_name, inactive_accounts.EMPL_NAME as inactive_name')
            ->leftJoin('active_accounts', function ($join) {
                $join->on('active_accounts.POWERLEAD_ID', '=', 'powerlead_accounts.id');
            })
            ->leftJoin('inactive_accounts', function ($join) {
                $join->on('inactive_accounts.POWERLEAD_ID', '=', 'powerlead_accounts.id');
            })
            ->where('verified', 1)->whereDate('powerlead_accounts.updated_at', '>=', $from_date)->whereDate('powerlead_accounts.updated_at', '<=', $to_date)->limit(1000)->get();
        $unverifiedHistory = Powerlead_Accounts::
            selectRaw('powerlead_accounts.id as id, powerlead_accounts.local_phone, powerlead_accounts.email, powerlead_accounts.fax, 
                powerlead_accounts.local_address, powerlead_accounts.main_phone, powerlead_accounts.powerlead_agent_id, active_accounts.EMPL_NAME as active_name, inactive_accounts.EMPL_NAME as inactive_name')
            ->leftJoin('active_accounts', function ($join) {
                $join->on('active_accounts.POWERLEAD_ID', '=', 'powerlead_accounts.id');
            })
            ->leftJoin('inactive_accounts', function ($join) {
                $join->on('inactive_accounts.POWERLEAD_ID', '=', 'powerlead_accounts.id');
            })
            ->where('verified', 0)->whereDate('powerlead_accounts.updated_at', '>=', $from_date)->whereDate('powerlead_accounts.updated_at', '<=', $to_date)->limit(1000)->get();

        $agentsQuery = Powerlead::select('id', 'user_id')->with('user_link')->get();
        $agents = [];
        foreach ($agentsQuery as $agent) {
            $agents[$agent->id] = $agent->user_link->first_name . ' ' . $agent->user_link->last_name;
        }

        return view('/admin/pages/powerlead/powerleadWorkHistory')->with('verifiedHistory', $verifiedHistory)->with('unverifiedHistory', $unverifiedHistory)->with('timeMessage', $timeMessage)->with('agents', $agents);
    }

}