<?php

namespace App\Http\Controllers\Admin\Powerlead;

use App\Http\Controllers\Controller;
use App\Models\Powerlead_Settings;
use Illuminate\Http\Request;

class PowerleadSettingsController extends Controller
{
    public function powerleadSettings(){
        $powerleadSettings = Powerlead_Settings::first();
        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;

        if ($powerleadSettings != null) {
            //sets priorities for dropdowns
            $priority[] = $powerleadSettings->priority;
            $priority[] = $powerleadSettings->second_priority;

            //sets value to checked if they were set as a priority
            if (in_array('ACCT_DUE_DATE', $priority)) {
                $preset[0] = 1;
            }

            if (in_array('POESCORE DESC', $priority)) {
                $preset[1] = 1;
            }

        } else {
            $powerleadSettings = new Powerlead_Settings;
            $powerleadSettings->hold_accounts_automatically = 1;
            $powerleadSettings->hold_accounts_below_score = 0;
            $powerleadSettings->max_accounts = 50;
            $powerleadSettings->save();
            $priority[] = "";
            $priority[] = "";

        }

        return view('admin/pages/powerlead/powerleadSettings')->with('powerlead_settings', $powerleadSettings)->with('preset', $preset)->with('priority', $priority);
    }

    public function updatePowerleadSettings(request $request)
    {

        $powerleadSettings = Powerlead_Settings::first();

        $powerleadSettings->hold_accounts_below_score = $request->below_score;
        $powerleadSettings->max_accounts = $request->max_accounts;
        //sets the priorities based on the number checked
        if (count($request->checked) == 1) {
            $powerleadSettings->priority = $request->checked[0];
            $powerleadSettings->second_priority = null;
        } else {
            $powerleadSettings->priority = $request->priority;

            if (count($request->checked) == 2) {
                if ($request->priority != $request->checked[0]) {
                    $powerleadSettings->second_priority = $request->checked[0];
                } else {
                    $powerleadSettings->second_priority = $request->checked[1];
                }

            }
        }
        $powerleadSettings->save();
        return redirect()->back()->with('success', 'Powerlead Settings Updated');
    }
}