<?php

namespace App\Http\Controllers\Admin\Powerlead;

use App\Models\Active_Account;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Powerlead_Accounts;
use Illuminate\Http\Request;

class PowerleadActionsController extends Controller
{
    public function getPowerAcctDetails($id){
        $power_account = Powerlead_Accounts::find($id);
        if($power_account == null)
            return back()->with('error', 'Account Not Found');

            $active_account = Active_Account::find($power_account->active_account_id);

        if ($active_account == null || empty($active_account)) {
            $active_account = Inactive_Account::find($power_account->active_account_id);
            if($active_account == null)
            {
                $active_account = new \stdClass;
                $active_account->ID = "Not found, some information may be missing";
                $active_account->ACCT_FIRST_NAME = null;
                $active_account->ACCT_LAST_NAME = null;
                $active_account->ACCT_CITY = null;
                $active_account->ACCT_ST = null;
                $active_account->ACCT_ZIP = null;
                $active_account->EMPL_PHONE1_NMBR =  $power_account->main_phone;
                $active_account->EMPL_NAME = $power_account->employer_name;
                $active_account->EMPL_ADDR1 = $power_account->employer_address;
                $active_account->EMPL_CITY = NULL;
                $active_account->EMPL_ST = NULL;
                $active_account->EMPL_ZIP = NULL;
            }
        }

        return view('/powerlead/pages/form')->with('active_account', $active_account)->with('power_account', $power_account)->with('agent_id', $power_account->powerlead_agent_id);

    }

    public function adminLinkLeadData(request $request){
        $power_account = Powerlead_Accounts::find($request->powerlead_id);
        $power_account->local_phone = $request->local_phone;
        $power_account->employer_name = $request->employer_name;
        $power_account->local_address = $request->local_address;
        $power_account->website = $request->website;
        $power_account->main_phone = $request->main_phone;
        $power_account->employer_address = $request->employer_address;
        $power_account->fax = $request->fax;
        $power_account->email = $request->email;
        $power_account->save();

        //finds the needed account
        $coeAccount = Active_Account::where('POWERLEAD_ID', $request->powerlead_account_id)->first();
        if($coeAccount == null){
            $coeAccount = Inactive_Account::where('POWERLEAD_ID', $request->powerlead_account_id)->first();
        }

        //updates the accounts one last time
        if ($request->not_found_button == "Not_Found") {
            $power_account->verified = 0;
            $power_account->save();
            if($coeAccount != null){
                $coeAccount->POWERLEAD_CAPCODE = 6;
                $coeAccount->save();
            }
            return back()->with('success', 'Account Unverified');
        }
        else{
            $power_account->verified = 1;
            $power_account->save();
            if($coeAccount != null){
                $coeAccount->POWERLEAD_CAPCODE = 5;
                $coeAccount->save();
            }
            return back()->with('success', 'Account Verified');
        }
    }

}
