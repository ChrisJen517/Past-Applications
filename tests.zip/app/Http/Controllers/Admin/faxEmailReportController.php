<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Capcode;
use App\Models\Worked_History;
use App\User;
use App\Models\Directory_Agent;
use App\Models\Powerlead;
use App\Models\Powerlead_Directory_Manager;
use DateTime;
use DB;

class faxEmailReportController extends Controller
{
    public function showReport(){
        $data = $this->getData(date("Y-m-d", strtotime("-1 week")), date('Y-m-d', strtotime("+1 day")));

        $message = "from the past 7 days";

        return view('/admin/pages/faxEmailReport')->with('data', $data)->with('timeMessage', $message);
    }

    public function showReportTime(Request $request){
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d", strtotime("+1 day"));
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        $data = $this->getData($startTime, $endTime);

        $message = "from: " . $startTime . " to " . $endTime;

        return view('/admin/pages/faxEmailReport')->with('data', $data)->with('timeMessage', $message);

    }

    public function getData($startTime, $endTime){
        //gets the verified calls and faxes capcodes
        $capcodes = Capcode::where('capcode', 1103)->orWhere('capcode', 1104)->select('id')->get();
        $capcodeIds = [];
        foreach($capcodes as $capcode){
            $capcodeIds[] = "'".$capcode->id."'";
        }
        $capcodeIds = implode(',', $capcodeIds);

        //gets the total accounts and verifed accounts from the histories table
        $histories = DB::SELECT(DB::RAW("SELECT user_role AS 'role_user', agent_id AS 'id_agent', COUNT(*) AS TOTAL,
        (SELECT COUNT(*) FROM worked_history WHERE capcode in (".$capcodeIds.") AND agent_id = id_agent AND user_role = role_user) AS 'VERIFIED' 
        FROM worked_history where (created_at > '".$startTime."' and created_at < '".$endTime."') 
        AND (user_role = 'admin' or user_role = 'directory_agent' or user_role = 'powerlead_directory_manager' or user_role = 'powerlead')
        group by user_role, agent_id;"));

        $finalData = [];
        $userIds = [];
        $agentIds = [];
        $powerIds = [];
        $managerIds = [];
        foreach($histories as $history){
            $finalData[$history->role_user." ".$history->id_agent] = [
                'account' => $history->role_user."-".$history->id_agent,
                'name' => '',
                'worked' => $history->TOTAL,
                'verified' => $history->VERIFIED,
                'unverified' => $history->TOTAL - $history->VERIFIED
            ];

            if($history->role_user == "admin")
                $userIds[] = $history->id_agent;
            elseif($history->role_user == "directory_agent")
                $agentIds[] = $history->id_agent;
            elseif($history->role_user == "powerlead_directory_manager")
                $managerIds[] = $history->id_agent;
            elseif($history->role_user == "powerlead")
                $powerIds[] = $history->id_agent;  
        }

        //gets the needed names from the user, directory agent, powerlead or powerlead_directory_manager
        //for admin names
        if(!empty($userIds)){
            $users = User::select('user_id', 'first_name', 'last_name')->whereIn('user_id', $userIds)->get();

            foreach($users as $user){
                if($user != null)
                    $finalData["admin ".$user->user_id]['name'] = $user->first_name." ".$user->last_name;
            }
        }
        
        //for directory agent names
        if(!empty($agentIds)){
            $agents = Directory_Agent::select('user_id', 'directory_agent_id')->whereIn('directory_agent_id', $agentIds)->with('user_link')->get();

            foreach($agents as $user){
                if($user != null)
                    $finalData["directory_agent ".$user->directory_agent_id]['name'] = $user->user_link->first_name." ".$user->user_link->last_name;
            }
        }
        
        //for powerlead names
        if(!empty($powerIds)){
            $powerleads = Powerlead::select('user_id', 'id')->whereIn('id', $powerIds)->with('user_link')->get();

            foreach($powerleads as $user){
                if($user != null)
                    $finalData["powerlead ".$user->id]['name'] = $user->user_link->first_name." ".$user->user_link->last_name;
            }
        }
        //for manager names
        if(!empty($managerIds)){
            $managers = Powerlead_Directory_Manager::select('user_id', 'powerlead_directory_id')->whereIn('powerlead_directory_id', $managerIds)->with('user_link')->get();

            foreach($managers as $user){
                if($user != null)
                    $finalData["powerlead_directory_manager ".$user->powerlead_directory_id]['name'] = $user->user_link->first_name." ".$user->user_link->last_name;
            }
        }

        return $finalData;
    }
}