<?php

namespace App\Http\Controllers\Maintenance;

use App\Http\Controllers\Controller;
use DB;

class OldRockyExportController extends Controller
{
    public function ExportClosedAccounts()
    {
        $filename = '/home/rocky/public_html/rocky-sync/closed_accounts.csv';
        $fileDestination = '/public_html/contract/sync-outbound/closed_accounts.csv';
        $closed_accounts = DB::select(DB::raw(
            "SELECT inactive_accounts.ID, inactive_accounts.ADD_DATE, inactive_accounts.ADD_FILE, inactive_accounts.ADDED_BY, inactive_accounts.ACCT_CLIENT, inactive_accounts.TEAM_NAME, inactive_accounts.ACCT_AGENT, inactive_accounts.ACCT_CASE, inactive_accounts.ACCT_DUE_DATE, inactive_accounts.ACCT_SSN,
            inactive_accounts.ACCT_FIRST_NAME, inactive_accounts.ACCT_LAST_NAME,
            inactive_accounts.ACCT_AD1, inactive_accounts.ACCT_AD2,
            inactive_accounts.ACCT_CITY, inactive_accounts.ACCT_ST,
            inactive_accounts.ACCT_ZIP, inactive_accounts.ACCT_DOB,
            inactive_accounts.ACCT_ID, inactive_accounts.ACCT_SOURCE, 
            verified_hits.employer_name, verified_hits.employer_address_1, 
            verified_hits.employer_address_2, verified_hits.employer_city, 
            verified_hits.employer_state, verified_hits.employer_zip, 
            verified_hits.employer_phone, verified_hits.employer_fax,   
            verified_hits.employer_email, verified_hits.employer_title,
            verified_hits.verification_contact_name,
            verified_hits.verification_contact_title, 
            (SELECT capcode from capcodes WHERE inactive_accounts.CAPCODE = capcodes.id AND corporation_id = 2) as capcode,
            inactive_accounts.LAST_WORKED, inactive_accounts.LAST_EMPL_NAME,
            inactive_accounts.LAST_EMPL_ADDR, inactive_accounts.LAST_EMPL_PHONE,
            inactive_accounts.LAST_EMPL_EMAIL, inactive_accounts.LAST_EMPL_FAX,
            inactive_accounts.LAST_COMMENTS, inactive_accounts.TIME_ZONE, null as empty, inactive_accounts.DIRECTORY_LINK, inactive_accounts.LAST_COMMENTS, null as empty2, inactive_accounts.POESCORE, null as empty3, inactive_accounts.TIER, inactive_accounts.REMINDER 
            FROM inactive_accounts INNER JOIN verified_hits ON inactive_accounts.VERIFIED_HITS_ID = verified_hits.id WHERE inactive_accounts.CORPORATION_ID = 2"
        ));
        //$posts = Blog::all();

        // return $closed_accounts;
        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ADD_DATE,ADD_FILE,ADDED_BY,ACCT_CLIENT,ACCT_COE,ACCT_AGENT,' .
            'ACCT_CASE,ACCT_DUE_DATE,ACCT_SSN,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,' .
            'ACCT_DOB,ACCT_ID,ACCT_SOURCE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR,EMPL_FAX,EMPL_EMAIL,EMPL_TITLE,' .
            'EMPL_CONTACT,EMPL_CONTACT_TITLE,CAPCODE,LAST_WORKED,LAST_EMPL_NAME,LAST_EMPL_ADDR,LAST_EMPL_PHONE,LAST_EMPL_EMAIL,LAST_EMPL_FAX,' .
            'LAST_COMMENTS,TIME_ZONE,MISC,DIR_ID,WORK_COMMENTS,LAST_SEEN,POESCORE,EMPL_FILES,TIER,REMINDER';
        fwrite($file, $headerString);

        foreach ($closed_accounts as $account) {          
            $ADD_FILE = str_replace(',', '', $account->ADD_FILE);
            $ADDED_BY = str_replace(',', '', $account->ADDED_BY);
            $ACCT_CLIENT = str_replace(',', '', $account->ACCT_CLIENT);
            $TEAM_NAME = str_replace(',', '', $account->TEAM_NAME);
            $ACCT_CASE = str_replace(',', '', $account->ACCT_CASE);
            $ACCT_FIRST_NAME = str_replace(',', '', $account->ACCT_FIRST_NAME);
            $ACCT_LAST_NAME = str_replace(',', '', $account->ACCT_LAST_NAME);
            $ACCT_AD1 = str_replace(',', '', $account->ACCT_AD1);
            $ACCT_AD2 = str_replace(',', '', $account->ACCT_AD2);
            $ACCT_CITY = str_replace(',', '', $account->ACCT_CITY);
            $ACCT_ST = str_replace(',', '', $account->ACCT_ST);
            $ACCT_SOURCE = str_replace(',', '', $account->ACCT_SOURCE);
            $employer_name = str_replace(',', '', $account->employer_name);
            $employer_address_1 = str_replace(',', '', $account->employer_address_1);
            $employer_address_2 = str_replace(',', '', $account->employer_address_2);
            $employer_city = str_replace(',', '', $account->employer_city);
            $employer_state = str_replace(',', '', $account->employer_state);
            $employer_zip = str_replace(',', '', $account->employer_zip);
            $employer_phone = str_replace(',', '', $account->employer_phone);
            $employer_fax = str_replace(',', '', $account->employer_fax);
            $employer_email = str_replace(',', '', $account->employer_email);
            $employer_title = str_replace(',', '', $account->employer_title);
            $verification_contact_name = str_replace(',', '', $account->verification_contact_name);
            $verification_contact_title = str_replace(',', '', $account->verification_contact_title);
            $LAST_EMPL_NAME = str_replace(',', '', $account->LAST_EMPL_NAME);
            $LAST_EMPL_ADDR = str_replace(',', '', $account->LAST_EMPL_ADDR);
            $LAST_EMPL_PHONE = str_replace(',', '', $account->LAST_EMPL_PHONE);
            $LAST_EMPL_EMAIL = str_replace(',', '', $account->LAST_EMPL_EMAIL);
            $LAST_EMPL_FAX = str_replace(',', '', $account->LAST_EMPL_FAX);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $TIME_ZONE = str_replace(',', '', $account->TIME_ZONE);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $REMINDER = str_replace(',', '', $account->REMINDER);
            $rowString = "\r\n" .
                $account->ID . ',' .
                $account->ADD_DATE . ',' .
                $ADD_FILE . ',' .
                $ADDED_BY . ',' .
                $ACCT_CLIENT . ',' .
                $TEAM_NAME . ',' .
                $account->ACCT_AGENT . ',' .
                $ACCT_CASE . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $ACCT_FIRST_NAME . ',' .
                $ACCT_LAST_NAME . ',' .
                $ACCT_AD1 . ',' .
                $ACCT_AD2 . ',' .
                $ACCT_CITY . ',' .
                $ACCT_ST . ',' .
                $account->ACCT_ZIP . ',' .
                $account->ACCT_DOB . ',' .
                $account->ACCT_ID . ',' .
                $ACCT_SOURCE . ',' .
                $employer_name . ',' .
                $employer_address_1 . ',' .
                $employer_address_2 . ',' .
                $employer_city . ',' .
                $employer_state . ',' .
                $employer_zip . ',' .
                $employer_phone . ',' .
                $employer_fax . ',' .
                $employer_email . ',' .
                $employer_title . ',' .
                $verification_contact_name . ',' .
                $verification_contact_title . ',' .
                $account->capcode . ',' .
                $account->LAST_WORKED . ',' .
                $LAST_EMPL_NAME . ',' .
                $LAST_EMPL_ADDR . ',' .
                $LAST_EMPL_PHONE . ',' .
                $LAST_EMPL_EMAIL . ',' .
                $LAST_EMPL_FAX . ',' .
                $LAST_COMMENTS . ',' .
                $TIME_ZONE . ',' .
                $account->empty . ',' .
                $account->DIRECTORY_LINK . ',' .
                $LAST_COMMENTS . ',' .
                $account->empty2 . ',' .
                $account->POESCORE . ',' .
                $account->empty3 . ',' .
                $account->TIER . ',' .
                $REMINDER;
                fwrite($file, $rowString);

            //fputcsv($file, $account);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
//return ftp_nlist($conn_id, ".");
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }

        // close the connection
        ftp_close($conn_id);
    }

    public function ExportWorkedHistory()
    {
        $filename = '/home/rocky/public_html/rocky-sync/worked_history.csv';
        $fileDestination = '/public_html/contract/sync-outbound/worked_history.csv';
        
        $closed_accounts = DB::select(DB::raw(
            "SELECT active_account_id as 'UID', worked_history.created_at as 'ADD_DATE', 
            active_accounts.ACCT_CLIENT, active_accounts.TEAM_NAME AS ACCT_COE, 
            agent_id AS 'ACCT_AGENT', active_accounts.ACCT_CASE, 
            active_accounts.ACCT_DUE_DATE, active_accounts.ACCT_SSN, 
            active_accounts.ACCT_ID, active_accounts.ACCT_SOURCE, 
            active_accounts.EMPL_NAME, active_accounts.EMPL_ADDR1, 
            active_accounts.EMPL_ADDR2, active_accounts.EMPL_CITY, 
            active_accounts.EMPL_ST, active_accounts.EMPL_ZIP, 
            active_accounts.EMPL_PHONE1_NMBR, active_accounts.EMPL_FAX, 
            active_accounts.EMPL_EMAIL, active_accounts.EMPL_TITLE, 
            active_accounts.EMPL_CONTACT, active_accounts.EMPL_CONTACT_TITLE, 
            (SELECT capcode from capcodes WHERE worked_history.CAPCODE = capcodes.id AND corporation_id = 2) as CAPCODE, 
            notes as 'WORK_COMMENTS', active_accounts.POESCORE, active_accounts.EMPL_FILES 
            FROM worked_history INNER JOIN active_accounts ON worked_history.active_account_id = active_accounts.ID WHERE agent_id IN (6018, 6029) and worked_history.created_at > '2020-02-20 08:56:01' ORDER BY worked_history.created_at DESC;"
        ));
        //$posts = Blog::all();

        // return $closed_accounts;
        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ADD_DATE,ACCT_CLIENT,ACCT_COE,ACCT_AGENT,ACCT_CASE,ACCT_DUE_DATE,ACCT_SSN,ACCT_ID,ACCT_SOURCE,EMPL_NAME,'.
        'EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR,EMPL_FAX,EMPL_EMAIL,EMPL_TITLE,EMPL_CONTACT,EMPL_CONTACT_TITLE,CAPCODE,WORK_COMMENTS,POESCORE,EMPL_FILES';
        fwrite($file, $headerString);

        foreach ($closed_accounts as $account) {    
            $WORK_COMMENTS = trim(preg_replace('/\s\s+/', ' ', $account->WORK_COMMENTS));
            $WORK_COMMENTS = str_replace(',', '', $WORK_COMMENTS);      
            $rowString = "\r\n" .
                $account->UID . ',' .
                $account->ADD_DATE . ',' .
                str_replace(',', '', $account->ACCT_CLIENT) . ',' .
                str_replace(',', '', $account->ACCT_COE) . ',' .
                $account->ACCT_AGENT . ',' .
                str_replace(',', '', $account->ACCT_CASE) . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $account->ACCT_ID . ',' .
                str_replace(',', '', $account->ACCT_SOURCE) . ',' .
                str_replace(',', '', $account->EMPL_NAME) . ',' .
                str_replace(',', '', $account->EMPL_ADDR1) . ',' .
                str_replace(',', '', $account->EMPL_ADDR2) . ',' .
                str_replace(',', '', $account->EMPL_CITY) . ',' .
                str_replace(',', '', $account->EMPL_ST) . ',' .
                str_replace(',', '', $account->EMPL_ZIP) . ',' .
                str_replace(',', '', $account->EMPL_PHONE1_NMBR) . ',' .
                str_replace(',', '', $account->EMPL_FAX) . ',' .
                str_replace(',', '', $account->EMPL_EMAIL) . ',' .
                str_replace(',', '', $account->EMPL_TITLE) . ',' .
                str_replace(',', '', $account->EMPL_CONTACT) . ',' .
                str_replace(',', '', $account->EMPL_CONTACT_TITLE) . ',' .
                $account->CAPCODE . ',' .
                $WORK_COMMENTS . ',' .
                $account->POESCORE . ',' .
                str_replace(',', '', $account->EMPL_FILES);
                fwrite($file, $rowString);

            //fputcsv($file, $account);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
//return ftp_nlist($conn_id, ".");
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }

        // close the connection
        ftp_close($conn_id);
    }

    public function ExportActiveAccounts()
    {
        $filename = '/home/rocky/public_html/rocky-sync/active_accounts.csv';
        $fileDestination = '/public_html/contract/sync-outbound/active_accounts.csv';
        $closed_accounts = DB::select(DB::raw(
            "SELECT active_accounts.ID, active_accounts.ADD_DATE, active_accounts.ADD_FILE, active_accounts.ADDED_BY, active_accounts.ACCT_CLIENT, active_accounts.TEAM_NAME, active_accounts.ACCT_AGENT, active_accounts.ACCT_CASE, active_accounts.ACCT_DUE_DATE, active_accounts.ACCT_SSN,
            active_accounts.ACCT_FIRST_NAME, active_accounts.ACCT_LAST_NAME,
            active_accounts.ACCT_AD1, active_accounts.ACCT_AD2,
            active_accounts.ACCT_CITY, active_accounts.ACCT_ST,
            active_accounts.ACCT_ZIP, active_accounts.ACCT_DOB,
            active_accounts.ACCT_ID, active_accounts.ACCT_SOURCE, 
            active_accounts.EMPL_NAME, active_accounts.EMPL_ADDR1, 
            active_accounts.EMPL_ADDR2, active_accounts.EMPL_CITY, 
            active_accounts.EMPL_ST, active_accounts.EMPL_ZIP, 
            active_accounts.EMPL_PHONE1_NMBR, active_accounts.EMPL_FAX,   
            active_accounts.EMPL_EMAIL, active_accounts.EMPL_TITLE,
            active_accounts.EMPL_CONTACT,
            active_accounts.EMPL_CONTACT_TITLE, 
            (SELECT capcode from capcodes WHERE active_accounts.CAPCODE = capcodes.id AND corporation_id = 2) as capcode,
            active_accounts.LAST_WORKED, active_accounts.LAST_EMPL_NAME,
            active_accounts.LAST_EMPL_ADDR, active_accounts.LAST_EMPL_PHONE,
            active_accounts.LAST_EMPL_EMAIL, active_accounts.LAST_EMPL_FAX,
            active_accounts.LAST_COMMENTS, active_accounts.TIME_ZONE, null as empty, active_accounts.DIRECTORY_LINK, active_accounts.LAST_COMMENTS, null as empty2, active_accounts.POESCORE, null as empty3, active_accounts.TIER, active_accounts.REMINDER 
            FROM active_accounts WHERE active_accounts.CORPORATION_ID = 2 AND active_accounts.ACCT_AGENT IN (6018, 6029)"
        ));
        //$posts = Blog::all();

        // return $closed_accounts;
        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ADD_DATE,ADD_FILE,ADDED_BY,ACCT_CLIENT,ACCT_COE,ACCT_AGENT,' .
            'ACCT_CASE,ACCT_DUE_DATE,ACCT_SSN,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,' .
            'ACCT_DOB,ACCT_ID,ACCT_SOURCE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR,EMPL_FAX,EMPL_EMAIL,EMPL_TITLE,' .
            'EMPL_CONTACT,EMPL_CONTACT_TITLE,CAPCODE,LAST_WORKED,LAST_EMPL_NAME,LAST_EMPL_ADDR,LAST_EMPL_PHONE,LAST_EMPL_EMAIL,LAST_EMPL_FAX,' .
            'LAST_COMMENTS,TIME_ZONE,MISC,DIR_ID,WORK_COMMENTS,LAST_SEEN,POESCORE,EMPL_FILES,TIER,REMINDER';
        fwrite($file, $headerString);

        foreach ($closed_accounts as $account) {          
            $ADD_FILE = str_replace(',', '', $account->ADD_FILE);
            $ADDED_BY = str_replace(',', '', $account->ADDED_BY);
            $ACCT_CLIENT = str_replace(',', '', $account->ACCT_CLIENT);
            $TEAM_NAME = str_replace(',', '', $account->TEAM_NAME);
            $ACCT_CASE = str_replace(',', '', $account->ACCT_CASE);
            $ACCT_FIRST_NAME = str_replace(',', '', $account->ACCT_FIRST_NAME);
            $ACCT_LAST_NAME = str_replace(',', '', $account->ACCT_LAST_NAME);
            $ACCT_AD1 = str_replace(',', '', $account->ACCT_AD1);
            $ACCT_AD2 = str_replace(',', '', $account->ACCT_AD2);
            $ACCT_CITY = str_replace(',', '', $account->ACCT_CITY);
            $ACCT_ST = str_replace(',', '', $account->ACCT_ST);
            $ACCT_SOURCE = str_replace(',', '', $account->ACCT_SOURCE);
            $employer_name = str_replace(',', '', $account->EMPL_NAME);
            $employer_address_1 = str_replace(',', '', $account->EMPL_ADDR1);
            $employer_address_2 = str_replace(',', '', $account->EMPL_ADDR2);
            $employer_city = str_replace(',', '', $account->EMPL_CITY);
            $employer_state = str_replace(',', '', $account->EMPL_ST);
            $employer_zip = str_replace(',', '', $account->EMPL_ZIP);
            $employer_phone = str_replace(',', '', $account->EMPL_PHONE1_NMBR);
            $employer_fax = str_replace(',', '', $account->EMPL_FAX);
            $employer_email = str_replace(',', '', $account->EMPL_EMAIL);
            $employer_title = str_replace(',', '', $account->EMPL_TITLE);
            $verification_contact_name = str_replace(',', '', $account->EMPL_CONTACT);
            $verification_contact_title = str_replace(',', '', $account->EMPL_CONTACT_TITLE);
            $LAST_EMPL_NAME = str_replace(',', '', $account->LAST_EMPL_NAME);
            $LAST_EMPL_ADDR = str_replace(',', '', $account->LAST_EMPL_ADDR);
            $LAST_EMPL_PHONE = str_replace(',', '', $account->LAST_EMPL_PHONE);
            $LAST_EMPL_EMAIL = str_replace(',', '', $account->LAST_EMPL_EMAIL);
            $LAST_EMPL_FAX = str_replace(',', '', $account->LAST_EMPL_FAX);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $TIME_ZONE = str_replace(',', '', $account->TIME_ZONE);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $REMINDER = str_replace(',', '', $account->REMINDER);
            $rowString = "\r\n" .
                $account->ID . ',' .
                $account->ADD_DATE . ',' .
                $ADD_FILE . ',' .
                $ADDED_BY . ',' .
                $ACCT_CLIENT . ',' .
                $TEAM_NAME . ',' .
                $account->ACCT_AGENT . ',' .
                $ACCT_CASE . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $ACCT_FIRST_NAME . ',' .
                $ACCT_LAST_NAME . ',' .
                $ACCT_AD1 . ',' .
                $ACCT_AD2 . ',' .
                $ACCT_CITY . ',' .
                $ACCT_ST . ',' .
                $account->ACCT_ZIP . ',' .
                $account->ACCT_DOB . ',' .
                $account->ACCT_ID . ',' .
                $ACCT_SOURCE . ',' .
                $employer_name . ',' .
                $employer_address_1 . ',' .
                $employer_address_2 . ',' .
                $employer_city . ',' .
                $employer_state . ',' .
                $employer_zip . ',' .
                $employer_phone . ',' .
                $employer_fax . ',' .
                $employer_email . ',' .
                $employer_title . ',' .
                $verification_contact_name . ',' .
                $verification_contact_title . ',' .
                $account->capcode . ',' .
                $account->LAST_WORKED . ',' .
                $LAST_EMPL_NAME . ',' .
                $LAST_EMPL_ADDR . ',' .
                $LAST_EMPL_PHONE . ',' .
                $LAST_EMPL_EMAIL . ',' .
                $LAST_EMPL_FAX . ',' .
                $LAST_COMMENTS . ',' .
                $TIME_ZONE . ',' .
                $account->empty . ',' .
                $account->DIRECTORY_LINK . ',' .
                $LAST_COMMENTS . ',' .
                $account->empty2 . ',' .
                $account->POESCORE . ',' .
                $account->empty3 . ',' .
                $account->TIER . ',' .
                $REMINDER;
                fwrite($file, $rowString);

            //fputcsv($file, $account);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
//return ftp_nlist($conn_id, ".");
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }

        // close the connection
        ftp_close($conn_id);
    }
}
