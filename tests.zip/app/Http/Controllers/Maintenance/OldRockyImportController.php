<?php

namespace App\Http\Controllers\Maintenance;

use App\Http\Controllers\Controller;
use App\RNNMailer;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;
use PHPMailer\PHPMailer\PHPMailer;

class OldRockyImportController extends Controller
{
    public function ImportOldRocky(){

        $fileDestination = '/public_html/contract/sync/ACTIVE_ACCOUNTS_Special.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/ACTIVE_ACCOUNTS_Special.csv';
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        // return ftp_nlist($conn_id, "/public_html/contract/ACTIVE_ACCOUNTS_Special.csv");

        // upload a file
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        // return $file;
        // close the connection
        ftp_close($conn_id);

       $file = fopen($filename, "r");
       $line = fgets($file);

       return $this->uploadAAFile();
       return "done";

    }

    public function uploadAAFile(){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        $table_name = 'test_upload';

        // Assigning DB values
        // $server = '162.241.225.138';
        // $user = 'bbconsul_admin';
        // $pass = 'Mountain2073!';
        // $dbname = 'bbconsul_ROCKY_REBUILD';

        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');

        $file = '/home/rocky/public_html/rocky-sync/Maintence/ACTIVE_ACCOUNTS_Special.csv';
        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/ACTIVE_ACCOUNTS_Special.csv';
        // Setting up reading file that is uploaded
        $file = new \SplFileObject($file);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {
            if($rows == 0){
                foreach($row as $header)
                {
                        $headers[] = $header;
                }
            }
            $rows++;
        }

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $duplicate_key = '';
        $count = 0;
        $lastHead = '';
        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
              $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";
              if($head == 'MISC' || $head == 'WORK_COMMENTS' || $head == 'LAST_SEEN' || $head == 'REMINDER'){

              }else{
                    if($head == 'UID'){
                        $insert_statement = $insert_statement."ID, ";
                        $insert_statement_CSV =  $insert_statement_CSV."`$table_name`.`ID`, ";
                        $lastHead = 'ID';
                    }elseif($head == 'ACCT_COE'){
                        $insert_statement = $insert_statement."TEAM_NAME, ";
                        $insert_statement_CSV =  $insert_statement_CSV."`$table_name`.`TEAM_NAME`, ";
                        $lastHead = 'TEAM_NAME';
                        $duplicate_key = $duplicate_key."`active_accounts`.`TEAM_NAME`= `".$table_name."`.`TEAM_NAME`, ";
                    }elseif($head == 'DIR_ID'){
                        $insert_statement = $insert_statement."DIRECTORY_LINK, ";
                        $insert_statement_CSV =  $insert_statement_CSV."`$table_name`.`DIRECTORY_LINK`, ";
                        $lastHead = 'DIRECTORY_LINK';
                        $duplicate_key = $duplicate_key."`active_accounts`.`DIRECTORY_LINK`= `".$table_name."`.`DIRECTORY_LINK`, ";
                    }else{
                        $insert_statement = $insert_statement.$head.", ";
                        $insert_statement_CSV =  $insert_statement_CSV."`$table_name`.`".$head."`, ";
                        $lastHead = $head;
                        $duplicate_key = $duplicate_key."`active_accounts`.`".$head."`= `".$table_name."`.`".$head."`, ";
                    }
                }
        }
        $insert_statement_CSV = substr_replace($insert_statement_CSV,"",-2);
        $insert_statement = substr_replace($insert_statement,"",-2);
        $insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);
        $duplicate_key = substr_replace($duplicate_key,"",-2);
        // Dropping table if one previously existed
        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
        // Creating a temp table to upload CSV file
        $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));

        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
          PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));

        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);

        // Update ADD_DATE to right format
        DB::SELECT(DB::raw("UPDATE `$table_name` aa
        JOIN `$table_name` bb
        ON ( aa.UID = bb.UID )
        SET aa.ADD_DATE = (CONCAT(SUBSTRING(bb.ADD_DATE, 1, 4), '-', SUBSTRING(bb.ADD_DATE, 5, 2), '-', SUBSTRING(bb.ADD_DATE, 7, 2)))"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ADD_DATE = null WHERE ADD_DATE = '0--';"));

        // Update ACCT_DUE_DATE to right format
        DB::SELECT(DB::raw("UPDATE `$table_name` aa
        JOIN `$table_name` bb
        ON ( aa.UID = bb.UID )
        SET aa.ACCT_DUE_DATE = (CONCAT(SUBSTRING(bb.ACCT_DUE_DATE, 1, 4), '-', SUBSTRING(bb.ACCT_DUE_DATE, 5, 2), '-', SUBSTRING(bb.ACCT_DUE_DATE, 7, 2)))"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ACCT_DUE_DATE = null WHERE ACCT_DUE_DATE = '0--';"));

        // Update ACCT_DOB to right format
        DB::SELECT(DB::raw("UPDATE `$table_name` aa
        JOIN `$table_name` bb
        ON ( aa.UID = bb.UID )
        SET aa.ACCT_DOB = (CONCAT(SUBSTRING(bb.ACCT_DOB, 1, 4), '-', SUBSTRING(bb.ACCT_DOB, 5, 2), '-', SUBSTRING(bb.ACCT_DOB, 7, 2)))"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ACCT_DOB = null WHERE ACCT_DOB = '0--';"));

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP MISC'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP WORK_COMMENTS'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP LAST_SEEN'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP REMINDER'));

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE DIR_ID DIRECTORY_LINK VARCHAR(90);'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' Change UID ID VARCHAR( 90 );'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' Change ACCT_COE TEAM_NAME VARCHAR( 90 );'));

          DB::select( DB::raw("ALTER TABLE `$table_name`
            ADD COLUMN `CORPORATION_ID` varchar(45) NOT NULL DEFAULT 2 AFTER `$lastHead`;
            "));
          $lastHead = 'CORPORATION_ID';
          $insert_statement = $insert_statement.", ".$lastHead;
          $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$lastHead."`";

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `TEAM_ID` INT DEFAULT NULL AFTER `$lastHead`;
        "));
        $lastHead = 'TEAM_ID';
        $insert_statement = $insert_statement.", ".$lastHead;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$lastHead."`";

        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 5 WHERE ACCT_AGENT = '6018'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 5 WHERE ACCT_AGENT = '6029'"));

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `PINPOINT` INT NOT NULL DEFAULT 0 AFTER `$lastHead`;
        "));
        $lastHead = 'PINPOINT';
        $insert_statement = $insert_statement.", ".$lastHead;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$lastHead."`";

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `ON_HOLD` INT NOT NULL DEFAULT 0 AFTER `$lastHead`;
        "));
        $lastHead = 'ON_HOLD';
        $insert_statement = $insert_statement.", ".$lastHead;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$lastHead."`";

        DB::SELECT(DB::RAW("UPDATE `$table_name` SET PINPOINT = 1, ON_HOLD = 1, ACCT_AGENT = NULL WHERE ACCT_AGENT = 'OVERFLOWED'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ON_HOLD = 1, ACCT_AGENT = NULL WHERE ACCT_AGENT = 'SCOREHOLD'"));
        DB::SELECT(DB::RAW("DELETE FROM `$table_name` WHERE ACCT_AGENT = 'RECALLED'"));

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `BLOCKED_CHECK` INT DEFAULT 1 AFTER `$lastHead`;
        "));
        $lastHead = 'BLOCKED_CHECK';
        $insert_statement = $insert_statement.", ".$lastHead;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$lastHead."`";

      $capcodes = DB::SELECT( DB::RAW("SELECT DISTINCT(capcode) AS 'capcode' FROM `$table_name`;"));
      foreach($capcodes as $capcode){
        if($capcode->capcode == 0){
          DB::SELECT(DB::RAW("UPDATE `$table_name` SET capcode = NULL WHERE capcode = ".$capcode->capcode.";"));
        }else if($capcode->capcode == 2302){

        }
        else{
          $dbcapcode = DB::SELECT(DB::RAW("SELECT * FROM `capcodes` WHERE capcode = ".$capcode->capcode." AND CORPORATION_ID = 2;"));
          DB::SELECT(DB::RAW("UPDATE `$table_name` SET capcode = ".$dbcapcode[0]->id." WHERE capcode = ".$capcode->capcode.";"));
        }
      }
      DB::SELECT(DB::RAW("UPDATE `$table_name` SET LAST_WORKED = null WHERE LAST_WORKED = ''"));
                        // Inserting the columns from the CSV file that are requested into our database.
                        DB::select( DB::raw("INSERT INTO active_accounts
                        ($insert_statement)
                        SELECT
                    $insert_statement_CSV
                    FROM `$table_name` ON DUPLICATE KEY UPDATE $duplicate_key;"));

    DB::SELECT(DB::RAW("UPDATE active_accounts SET DIRECTORY_FLAG = 1 WHERE DIRECTORY_LINK IS NULL AND CORPORATION_ID = 2"));
    DB::SELECT(DB::RAW("UPDATE active_accounts SET DIRECTORY_FLAG = 1 WHERE DIRECTORY_LINK = '' AND CORPORATION_ID = 2"));
    DB::SELECT(DB::RAW("UPDATE active_accounts aa inner join powerlead_accounts pl ON pl.active_account_id = aa.ID SET aa.POWERLEAD_ID = pl.id;"));
    DB::SELECT(DB::RAW("UPDATE active_accounts SET POWERLEAD_ID = null WHERE POWERLEAD_ID = 0;"));
    DB::SELECT(DB::RAW("UPDATE active_accounts SET DIRECTORY_LINK = null WHERE DIRECTORY_LINK = 0;"));

    }

    public function ImportOldWorkedHistoryRocky(){
        $now = Carbon::now()->format('Y_m_d');
        $path = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/Maintence/'.$now.'');
        }
        $fileDestination = '/public_html/contract/sync/WORK_HISTORY.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'/WORK_HISTORY.csv';
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        // return ftp_nlist($conn_id, "/public_html/contract/ACTIVE_ACCOUNTS_Special.csv");

        // upload a file
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        // return $file;
        // close the connection
        ftp_close($conn_id);

       $file = fopen($filename, "r");
       $line = fgets($file);

       $this->uploadWorkedHistory();
       return "done";

    }

    public function uploadWorkedHistory(){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        $yesterday = Carbon::yesterday()->format('Y-m-d');
        $table_name = 'test_upload_work_history';

        // Assigning DB values
        // $server = '162.241.225.138';
        // $user = 'bbconsul_admin';
        // $pass = 'Mountain2073!';
        // $dbname = 'bbconsul_ROCKY_REBUILD';

        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        $now = Carbon::now()->format('Y_m_d');

        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'/WORK_HISTORY.csv';
        $file = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'/WORK_HISTORY.csv';

        // Setting up reading file that is uploaded
        $file = new \SplFileObject($file);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {
            if($rows == 0){
                foreach($row as $header)
                {
                        $headers[] = $header;
                }
            }
            $rows++;
        }

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $duplicate_key = '';
        $count = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
            if($head == 'WORK_COMMENTS' ){
                $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` text, ";
            }else{
                $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";
            }
        }
        $insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);
        $insert_statement = "active_account_id, created_at, agent_id, capcode, notes";
        $insert_statement_CSV = "`$table_name`.`active_account_id`, `$table_name`.`created_at`, `$table_name`.`agent_id`, `$table_name`.`capcode`, `$table_name`.`notes`";

        // Dropping table if one previously existed
        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
        // Creating a temp table to upload CSV file
        $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));

        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
          PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));

        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `user_role` varchar(45) NOT NULL DEFAULT '' AFTER `$head`;
        "));
        $head = 'user_role';
        $insert_statement = $insert_statement.", ".$head;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$head."`";

        $capcodes = DB::SELECT( DB::RAW("SELECT DISTINCT(capcode) AS 'capcode' FROM `$table_name` ;"));
        foreach($capcodes as $capcode){
          if($capcode->capcode == 0){
            if($capcode->capcode == ''){

            }else{
              DB::SELECT(DB::RAW("UPDATE `$table_name`  SET capcode = NULL WHERE capcode = ".$capcode->capcode.";"));
            }
          }else if($capcode->capcode == 2302 || $capcode->capcode == 1121 || $capcode->capcode == 5512){

          }
          else{
            $dbcapcode = DB::SELECT(DB::RAW("SELECT * FROM `capcodes` WHERE capcode = ".$capcode->capcode." AND corporation_id = 2;"));
            if($dbcapcode == null){
            }else{
              DB::SELECT(DB::RAW("UPDATE `$table_name` SET capcode = ".$dbcapcode[0]->id." WHERE capcode = ".$capcode->capcode.";"));
            }
          }
        }

        // DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ID'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_CLIENT'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_COE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_CASE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_DUE_DATE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_ID'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_SSN'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_SOURCE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_NAME'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_ADDR1'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_ADDR2'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_CITY'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_ST'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_ZIP'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_PHONE1_NMBR'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP WORK_AGENT'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_FAX'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_EMAIL'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_TITLE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_CONTACT'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_CONTACT_TITLE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP QUICK_DIAL'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP POESCORE'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP EMPL_FILES'));

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE UID active_account_id VARCHAR(90);'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE ADD_DATE created_at VARCHAR(90);'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE ACCT_AGENT agent_id VARCHAR(90);'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE CAPCODE capcode VARCHAR(90);'));
        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE WORK_COMMENTS notes text;'));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET user_role = 'agent' WHERE agent_id > 2999 and agent_id < 7000;"));
          // Inserting the columns from the CSV file that are requested into our database.
            DB::select( DB::raw('INSERT IGNORE INTO worked_history
                          ('.$insert_statement.')
                          SELECT
                      '.$insert_statement_CSV.'
                      FROM '.`$table_name`.'  WHERE created_at > "'.$yesterday.'"'));
    }

    public function checkMissingWorkHistory(){
        DB::SELECT(DB::RAW("UPDATE active_accounts aa SET aa.LAST_WORKED = (SELECT created_at from worked_history WHERE active_account_id = aa.ID ORDER BY created_at DESC LIMIT 1) WHERE CORPORATION_ID = 2"));

        $missingWHs = DB::SELECT(DB::RAW("SELECT aa.ID, wh.active_account_id FROM active_accounts aa LEFT JOIN worked_history wh ON aa.ID = wh.active_account_id WHERE CORPORATION_ID = 2 AND aa.CAPCODE is not null and aa.ACCT_AGENT = 6018 and wh.active_account_id is null"));
        $missingWHString = '';
        foreach($missingWHs as $missingWH){
            $missingWHString = $missingWHString.$missingWH->ID.' ';
        }

        $bodyString = "These Active Accounts have capcodes but don't have any work history attached to them. ".$missingWHString."";

        $mail = new RNNMailer(true);

        //Recipients
        $mail->AddAddress('PrateekG@rnngroup.com');

        // Content<p>{{  }}</p>
        $mail->createHeader('Missing Work Histories');
        $mail->MessageDate = date("M,d,Y h:i:s A");
        $mail->Subject = "Missing Work Histories";
        $mail->Body = $bodyString;

        // // Mail Send
        $mail->send();

        return $missingWHString;
    }
}
