<?php

namespace App\Http\Controllers\ExportReporting;

use App\Models\Agent;
use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\UserWorkHistory;
use App\ExportCalls;
use App\ExportDirCalls;
use App\ExportDirWorked;
use App\ExportDirVerifications;
use App\ExportVerifications;
use App\ExportAccountsWorked;
use App\ExportSDR;
use Storage;
use Mail;
use Excel;
use Carbon\Carbon;
use Config;
use App\Models\Capcode;
use App\Models\Inactive_Account;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Work_History;
use App\Models\Directory_Capcode;
use App\Models\Directory_Agent;
use App\RNNMailer;
use App\Models\Team;

class ImportController extends Controller
{
    public function generateReports($hours) {
        // $currentDay = "2020-03-01";
        // $upperBound = "2020-04-02";
        $currentDay = Carbon::now()->format('Y-m-d');
        $upperBound = Carbon::now()->addDay()->format('Y-m-d');
        $dataFormatted = [];


        //change to 2 on live, 6 for local
        $corprationId = 2;
        $callCode = Capcode::where('capcode', 2210)->where('corporation_id', $corprationId)->first()->id;

        $newData = DB::Select(DB::RAW("SELECT
            wh.agent_id AS ACCT_AGENT,
            notes,
            active_account_id,
            wh.capcode,
            HOUR(wh.CREATED_AT) AS HOUR,
            CONCAT(wh.agent_id,
                    '||',
                    notes,
                    '||',
                    active_account_id,
                    '||',
                    MONTH(wh.CREATED_AT),
                    '-',
                    DAY(wh.CREATED_AT),
                    '-',
                    YEAR(wh.CREATED_AT),
                    '-',
                    HOUR(wh.CREATED_AT)) AS GRP,
            wh.capcode = $callCode AS IS_CALL
        FROM
            worked_history as wh
        WHERE
            notes IS NOT NULL AND notes != ''
            AND wh.created_at BETWEEN DATE('".$currentDay."') AND DATE('".$upperBound."')
        GROUP BY GRP"));

        $capcodes = Capcode::where('type', 'verified')->select('id')->get();

        $verifiedCapcodes = [];
        foreach($capcodes as $capcode) {
            $verifiedCapcodes[] = $capcode->id;
        }

        $dontCountCapcodesCollection = Capcode::select('id')->whereIn('capcode', ['2208', '2209', '2210', '2211'])->get()->values();
        $dontCountCapcodes = [];
        foreach($dontCountCapcodesCollection as $capcode) {
            $dontCountCapcodes[] = $capcode->id;
        }

        $dataCollection = collect($newData);
        $uniqueAgents = $dataCollection->groupBy('ACCT_AGENT');

        $verified = Inactive_Account::whereIn('ACCT_AGENT', $uniqueAgents->keys())->where('LAST_WORKED', '>=', $currentDay)->where('LAST_WORKED', '<=', $upperBound)
        ->selectRaw("ACCT_AGENT, HOUR(LAST_WORKED) as hour")->whereIn('CAPCODE', $verifiedCapcodes)->get();

        $perHourData = [
            'workedBefore8' => 0,
            'callsBefore8' => 0,
            'hitsBefore8' => 0
        ];

        for ($i=8; $i < 19; $i++) {
            $perHourData = array_merge($perHourData, [
                'worked'.$i => 0,
                'calls'.$i => 0,
                'hits'.$i => 0
            ]);
        }


        $agentAccount = Agent::select('agent_id', 'team_id','user_id')->where('corporation_id', $corprationId)->with('user_link')->get();
        $teams = Team::select('team_id', 'name')->where('corporation_id', $corprationId)->get();

        foreach($uniqueAgents->keys() as $agent) { // O(k)
            $agentSpecificData = $dataCollection->where('ACCT_AGENT', $agent);
            $accountsWorkedCount = $agentSpecificData->whereNotIn('capcode', $dontCountCapcodes)->count();
            $verifiedHits = $verified->where('ACCT_AGENT', $agent);
            $verifiedHitsCount = $verifiedHits->count();
            $calls = $agentSpecificData->where('IS_CALL', 1);
            $callsCount = $calls->count();

            $agentUser = $agentAccount->where('agent_id', $agent)->first();
            if($agentUser != null){
                $name = $agentUser->user_link->first_name." ".$agentUser->user_link->last_name;
                $teamName = $teams->where('team_id', $agentUser->team_id)->first()->name ?? "N/A";
            }
            elseif(in_array($agent, [1904, 1902, 1901])){
                switch ($agent){
                    case 1904:
                        $name = "Hottie";
                        $teamName = "Bot";
                    break;
                    case 1902:
                        $name = "Dottie";
                        $teamName = "Bot";
                    break;
                    case 1901:
                        $name = "Bottie";
                        $teamName = "Bot";
                    break;
                }
            }
            else{
                $name = "N/A";
                $teamName = "N/A";
            }

            $dataFormatted[$agent] = [
                'coe' => $teamName,
                'agent_id' => $agent,
                'agent_name' => $name,
                'accounts_worked_count' => $accountsWorkedCount,
                'accounts_worked_per_hour' => round($accountsWorkedCount / $hours, 2),
                'verified_hits_count' => $verifiedHitsCount,
                'verified_hits_per_hour' => round($verifiedHitsCount / $hours, 2),
                'calls_count' => $callsCount,
                'calls_per_hour' => round($callsCount / $hours, 2),
            ];

            $dataFormatted[$agent] = array_merge($dataFormatted[$agent], $perHourData);
        }


        foreach($dataCollection as $account_worked) { // O(n)
            $agent = $account_worked->ACCT_AGENT;
            $hour = $account_worked->HOUR;
            $capcode = $account_worked->capcode;
            if ($hour > 18)
                continue;
            else {
                $key = $hour < 8 ? 'Before8' : $hour;
                if ($capcode != null && !in_array($capcode, $dontCountCapcodes))
                    $dataFormatted[$agent]['worked'.$key] += 1;
                if ($account_worked->IS_CALL == 1)
                    $dataFormatted[$agent]['calls'.$key] += 1;
            }
        }

        foreach ($verified as $hit) {
            $key = $hit->hour;
            if ($key <= 8)
                $key = 8;
            if ($key > 18)
                continue;
            $dataFormatted[$hit->ACCT_AGENT]['hits'.$key] += 1;
        }

        if (empty($dataFormatted))
            return "no data found";

        $collectionFormatted = collect($dataFormatted);
        $export = new ExportCalls($collectionFormatted);
        Excel::store($export, 'Calls_per_hour.xlsx');
        $export = new ExportVerifications($collectionFormatted);
        Excel::store($export, 'Verifications_per_hour.xlsx');
        $export = new ExportAccountsWorked($collectionFormatted);
        Excel::store($export, 'Worked_per_hour.xlsx');
    }

    public function sendExport($hours){
        $started = Carbon::now()->timestamp;
        ini_set('memory_limit', '2048M');
        if ($this->generateReports($hours) == "no data found")
            return "no data found";
        $fileName_1= storage_path().'/app/public/Calls_per_hour.xlsx';
        $fileName_2= storage_path().'/app/public/Verifications_per_hour.xlsx';
        $fileName_3= storage_path().'/app/public/Worked_per_hour.xlsx';

        $mail = new RNNMailer(true);

        //Recipients
        $mail->addAddress('Janettem@rnngroup.com');
        $mail->addAddress('euliciak@rnngroup.com');

        // Attachments
        $mail->addAttachment($fileName_1);         // Add attachments
        $mail->addAttachment($fileName_2);         // Add attachments
        $mail->addAttachment($fileName_3);         // Add attachments

        // Content<p>{{  }}</p>
        $date = date("M/d/Y h:i:s A");
        $mail->MessageDate = date("M,d,Y h:i:s A");
        $mail->Subject = 'ROCKY HOURLY BREAKDOWN (' . round($hours, 2) . ' HRS)';
        $mail->Body    = 'Attached are the reports for the hourly COE rep break down as of '.$date.'. Please note that these reports are based off of an 8:30AM EST start time so the averages each hour are calculated with an additional 0.5 hour offset to accomodate this.';

        //commented for testing
        $mail->send();
        unlink($fileName_1);
        unlink($fileName_2);
        unlink($fileName_3);

        $this->sendDirectoryExport($hours);

        $finished = Carbon::now()->timestamp;
        $timeElapsed = $finished - $started;
        return "mail sent in ${timeElapsed}s ... from ${started} to ${finished}";
    }

    public function sendDirectoryExport($hours) {
        if ($this->generateDirectoryReports($hours) == "no data found")
            return "no data found";
        $fileName_1= storage_path().'/app/public/Dir_Calls_per_hour.xlsx';
        $fileName_2= storage_path().'/app/public/Dir_Verifications_per_hour.xlsx';
        $fileName_3= storage_path().'/app/public/Dir_Worked_per_hour.xlsx';

        $mail = new RNNMailer(true);

        //Recipients
        $mail->addAddress('salmas@rnngroup.com');
        $mail->addAddress('souravp@rnngroup.com');
        $mail->addAddress('euliciak@rnngroup.com');

        // Attachments
        $mail->addAttachment($fileName_1);         // Add attachments
        $mail->addAttachment($fileName_2);         // Add attachments
        $mail->addAttachment($fileName_3);         // Add attachments

        // Content<p>{{  }}</p>
        $date = date("M/d/Y h:i:s A");
        $mail->MessageDate = date("M,d,Y h:i:s A");
        $mail->Subject = 'ROCKY DIRECTORY HOURLY BREAKDOWN (' . round($hours, 2) . ' HRS)';
        $mail->Body    = 'Attached are the reports for the hourly COE directory agent break down as of '.$date.'. Please note that these reports are based off of an 8:30AM EST start time so the averages each hour are calculated with an additional 0.5 hour offset to accomodate this.';

        $mail->send();

        unlink($fileName_1);
        unlink($fileName_2);
        unlink($fileName_3);
    }


    public function generateDirectoryReports($hours) {

        $currentDay = Carbon::now()->format('Y-m-d');
        $upperBound = Carbon::now()->addDay()->format('Y-m-d');

        //gets list of verified capcodes
        $capcodes = Directory_Capcode::select('capcode_id', 'type', 'capcode')->get();
        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->where('created_at', '<', $upperBound)->with('user_link')->get();

        //gets all accounts
        $activeAccounts = Directory_Active_Account::where('LAST_WORKED', '>', $currentDay)->where('LAST_WORKED', '<', $upperBound)
            ->selectRaw('directory_agent_id, capcode, HOUR(LAST_WORKED) as HOUR')->get();
        $inactiveAccounts = Directory_Inactive_Account::where('LAST_WORKED', '>', $currentDay)->where('LAST_WORKED', '<', $upperBound)
            ->selectRaw('directory_agent_id, capcode, HOUR(LAST_WORKED) as HOUR')->get();

        $callsMade = collect(DB::select(DB::raw("SELECT
            worker_id,
            verification_notes,
            directory_account_id,
            capcode,
            CREATED_AT,
            HOUR(CREATED_AT) AS HOUR,
            CONCAT(worker_id, '||', verification_notes, '||', directory_account_id, '||', MONTH(CREATED_AT), '-',
                     DAY(CREATED_AT), '-', YEAR(CREATED_AT), '-', HOUR(CREATED_AT)) AS GRP
            FROM
                directory_work_history
            WHERE
                verification_notes LIKE 'Made a call to:%'
                AND created_at BETWEEN DATE('".$currentDay."') AND DATE('".$upperBound."')
            GROUP BY GRP;")));

        $agentData = [];
        foreach ($agents as $agent) {
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $currentDay) && ($agent->user_link->is_deactivated == 1))
                continue;

            $perHourData = [
                'workedBefore8' => 0,
                'callsBefore8' => 0,
                'hitsBefore8' => 0
            ];
            for ($i=8; $i < 19; $i++) {
                $perHourData = array_merge($perHourData, [
                    'worked'.$i => 0,
                    'calls'.$i => 0,
                    'hits'.$i => 0
                ]);
            }

            $verified = 0;
            $worked = 0;
            $userActive = $activeAccounts->where('directory_agent_id', $agent->directory_agent_id);
            $userInactive = $inactiveAccounts->where('directory_agent_id', $agent->directory_agent_id);

            foreach ($userActive as $activeAccount) {
                if ($activeAccount->capcode != null) {
                    $type = $capcodes->where('capcode_id', $activeAccount->capcode)->first();

                    if ($type != null) {
                        if ($type->type == 'inconclusive') {
                            $worked++;
                            $perHourData['worked'.$activeAccount->HOUR] += 1;
                        }
                    }
                }
            }

            foreach ($userInactive as $inactiveAccount) {
                if ($inactiveAccount->capcode != null) {
                    $type = $capcodes->where('capcode_id', $inactiveAccount->capcode)->first();

                    if (($type != null)) {
                        $perHourData['worked'.$inactiveAccount->HOUR] += 1;
                        $worked++;
                        if ($type->type == 'verified') {
                            $verified = $verified + 1;
                            $perHourData['hits'.$inactiveAccount->HOUR] += 1;
                        }
                    }
                }
            }

            $agentCall = $callsMade->where('worker_id', $agent->directory_agent_id);
            $agentCallCount = $agentCall->count() ?? 0;

            foreach($agentCall as $account_worked) { // O(n)
                $hour = $account_worked->HOUR;
                if ($hour <= 18) {
                    $key = $hour < 8 ? 'Before8' : $hour;
                    $perHourData['calls'.$key] += 1;
                }
            }

            $agentData[$agent->directory_agent_id] = [
                'agent_name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'agent_id' => $agent->directory_agent_id,
                'accounts_worked_count' => $worked,
                'accounts_worked_per_hour' => $worked/$hours,
                'verified_hits_count' => $verified,
                'verified_hits_per_hour' => $verified/$hours,
                'calls_count' => $agentCallCount,
                'calls_per_hour' => $agentCallCount/$hours,
            ];

            $agentData[$agent->directory_agent_id] = array_merge($agentData[$agent->directory_agent_id], $perHourData);
        }

        $collectionFormatted = collect($agentData);
        $export = new ExportDirCalls($collectionFormatted);
        Excel::store($export, 'Dir_Calls_per_hour.xlsx');
        $export = new ExportDirVerifications($collectionFormatted);
        Excel::store($export, 'Dir_Verifications_per_hour.xlsx');
        $export = new ExportDirWorked($collectionFormatted);
        Excel::store($export, 'Dir_Worked_per_hour.xlsx');
    }
}
