<?php

namespace App\Http\Controllers\CorporateAdmin;

use App\Models\Active_Account;
use App\Models\Team;
use App\Models\Agent;
use App\Models\Corporate_Admin;
use App\Http\Controllers\Controller;
use App\Models\Distribution_Rules;
use Auth;
use DB;
use Illuminate\Http\Request;
use App\Jobs\ReleaseAccountsQueue;
use App\Jobs\RecallAccountsQueue;
use App\Models\Access_Levels;
use App\Models\Redistribution_Record;
use App\Traits\getIdCombinations;
use App\Traits\AccountDistrubution;
use App\Traits\GetOrderArray;
use App\Traits\TossAccounts;

class ManageTeamQueueController extends Controller
{
    use GetOrderArray, getIdCombinations, TossAccounts;

    public function showManageTeamQueues()
    {

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;

        $client_ids = Active_Account::select('ACCT_CLIENT')->where('corporation_id', $corporation_id)->whereNotNull('ACCT_CLIENT')->whereNotNull('TEAM_ID')->groupBy('ACCT_CLIENT')->get();
        $case_nums = Active_Account::select('ACCT_CASE')->where('corporation_id', $corporation_id)->whereNotNull('ACCT_CASE')->where('ON_HOLD', '1')->groupBy('ACCT_CASE')->get();
        $case_recall = Active_Account::select('ACCT_CASE')->where('corporation_id', $corporation_id)->whereNotNull('ACCT_CASE')->whereNotNull('TEAM_ID')->groupBy('ACCT_CASE')->get();

        $teams = DB::SELECT(DB::RAW("SELECT teams.team_id AS team, active_accounts.ACCT_CASE, teams.name,
        COUNT(IF( (ON_HOLD = 0 OR active_accounts.TEAM_ID = 10), 1, NULL)) AS Total_Active,
        COUNT(IF( (ON_HOLD = 0 OR active_accounts.TEAM_ID = 10) and LAST_WORKED IS NOT NULL AND LAST_WORKED != '', 1, NULL)) AS Working_On,
        COUNT(IF( (ON_HOLD = 0 OR active_accounts.TEAM_ID = 10) and (LAST_WORKED IS NULL OR LAST_WORKED = ''), 1, NULL)) AS Never_Worked,
        COUNT(IF( (ON_HOLD = 0 OR active_accounts.TEAM_ID = 10) AND (ACCT_AGENT IS NULL OR ACCT_AGENT=''), 1, NULL)) AS held,
        COUNT(IF( (ON_HOLD = 0 OR active_accounts.TEAM_ID = 10) AND ACCT_AGENT != '' AND ACCT_AGENT IS NOT NULL, 1, NULL)) AS assigned
        FROM teams  LEFT JOIN active_accounts ON teams.team_id = active_accounts.TEAM_ID
        WHERE teams.is_deactivated = 0 and teams.corporation_id = $corporation_id GROUP BY teams.team_id;"));

        $teamAccountData = [];
        foreach($teams as $team) {
            $teamAccountData[$team->team] = [
                'name' => $team->name,
                'heldCount' => $team->held,
                'assignedCount' => $team->assigned,
                'Never_Worked' => $team->Never_Worked,
                'Total_Active' => $team->Total_Active
            ];
        }

        $agentList = DB::SELECT(DB::RAW("SELECT agents.agent_id AS agent, agents.active AS active, agents.paused as paused, agents.team_id, active_accounts.ACCT_CASE, first_name, last_name,
        COUNT(DISTINCT active_accounts.ID) AS Total_Active, teams.name as team_name,
        COUNT(IF( LAST_WORKED IS NOT NULL AND LAST_WORKED != '', 1, NULL)) AS Working_On
        FROM users  LEFT JOIN agents ON users.user_id = agents.user_id LEFT JOIN
        active_accounts ON agents.agent_id = active_accounts.ACCT_AGENT
        LEFT JOIN teams ON agents.team_id = teams.team_id
        WHERE agents.corporation_id = $corporation_id AND users.is_deactivated = 0 and agents.active = 1 GROUP BY agents.agent_id;"));

        //if RNN, add the bots accounts to as they are stored differently 
        $bots = [];
        if($corporation_id == 2){
            $botIds = [1901, 1902, 1904];
            $botNames = ['Bottie', 'Dottie', 'Hottie'];
            $botAccounts = Active_Account::selectRaw("COUNT(DISTINCT active_accounts.ID) AS Total_Active,
            COUNT(IF( LAST_WORKED IS NOT NULL AND LAST_WORKED != '', 1, NULL)) AS Working_On,
            ACCT_AGENT")->whereIn('ACCT_AGENT', $botIds)->groupBy('ACCT_AGENT')->get();

            for($i = 0; $i < 3; $i++){
                $currentBot = $botAccounts->where('ACCT_AGENT', $botIds[$i])->first();
                $bots[] = [
                    'name' => $botNames[$i],
                    'agent_id' => $botIds[$i],
                    'team_name' => 'Bot',
                    'Total_Active' => $currentBot->Total_Active ?? 0,
                    'Working_On' => $currentBot->Working_On ?? 0,
                    'Never_Worked' => ($currentBot->Total_Active ?? 0) - ($currentBot->Working_On ?? 0),
                ];
            }
        }

        return view('corporateAdmin.pages.manageTeamQueues')->with('agents', $agentList)->with('case_nums', $case_nums)->with('bots', $bots)
        ->with('case_recall', $case_recall)->with('client_ids', $client_ids)->with('teams', $teams)->with('corporation_id', $corporation_id)->with('teamAccountData', $teamAccountData);
    }

    public function getAccountCases(Request $request)
    {
        $agent_id = $request->agent_id;
        $team_id = $request->team_id;
        $cases = Active_Account::select('ACCT_CASE')
            ->when($agent_id, function ($query, $agent_id) { return $query->where('ACCT_AGENT', $agent_id); })
            ->when($team_id, function ($query, $team_id) { return $query->where('TEAM_ID', $team_id); })
            ->whereNotNull('ACCT_CASE')
            ->get();
        $account_cases = array();
        foreach($cases as $key => $value)
        {
            if($value['ACCT_CASE'] != " ")
            {
                $account_cases[] = $value['ACCT_CASE'];
            }
        }

        echo json_encode($account_cases);
    }

    public function getAccountSources(Request $request)
    {
        $corporation_id = $request->corporation_id;
        $sources = Active_Account::select('ACCT_SOURCE')->where('corporation_id', $corporation_id)->whereNotNull('ACCT_SOURCE')->where('ACCT_SOURCE', '!=', '')->groupBy('ACCT_SOURCE')->get();
        $account_cases = array();
        foreach($sources as $key => $value)
        {
            if($value['ACCT_SOURCE'] != " " && $value['ACCT_SOURCE'] != null)
            {
                $account_cases[] = $value['ACCT_SOURCE'];
            }
        }

        echo json_encode($account_cases);
    }
    public function recallAccounts(request $request)
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $comments = "Recalled by client with";
        $count = 0;
        $source_code= $request->source_code;
        $case_number = $request->case_number;
        $client_id = $request->client_id;
        $score = $request->recall_score_select;

        if($source_code != null)
            $comments = $comments." Source Code,";
        else
            $source_code = null;

        if($case_number != null)
            $comments = $comments." Case Number,";
        else
            $case_number = null;

        if($client_id != null)
            $comments = $comments." Client ID,";
        else
            $client_id = null;

        if($score != null)
            $comments = $comments." Score.";
        else
            $score = null;

        $active_accounts = Active_Account::select('ID')
        ->where('CORPORATION_ID', $corporation_id)
        ->whereNotNull('TEAM_ID')
        ->when($source_code, function($query, $source_code){
            return $query->where('ACCT_SOURCE', $source_code);
        })
        ->when($case_number, function($query, $case_number){
            return $query->where('ACCT_CASE', $case_number);
        })
        ->when($client_id, function($query, $client_id){
            return $query->where('ACCT_CLIENT', $client_id);
        })
        ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
        ->limit(10001)->get();

        $active_accounts_size = count($active_accounts);
        // return $active_accounts_size;
        if($active_accounts->isEmpty() == true)
        {
            return back()->with('error', 'No Accounts found');

        }
        if($active_accounts_size > 10000)
        {
            $this->dispatch(new RecallAccountsQueue($corporation_id, $source_code, $case_number, $client_id, $score, $comments));
            return back()->with('message', 'Processing a large amount of accounts you can access them in a moment!');
        }

        $id_string = '';
        $id_count = 0;
        foreach($active_accounts as $data){
            if($id_count == 0){
                $id_string = '"'.$data->ID.'",';
                $id_count++;
            }
            else{
                $id_string = $id_string.' "'.$data->ID.'",';
            }
        }
        $id_string = substr_replace($id_string ,'', -1);
        DB::select(DB::raw("UPDATE active_accounts SET ACCT_AGENT = NULL, ON_HOLD = 1, LAST_COMMENTS = '$comments' WHERE ID IN($id_string);"));
        return back()->with('message', 'Put '.$active_accounts_size.' On Hold');

    }

    public function releaseAccounts(request $request)
    {
        $this->validate($request, [
            'recallOption' =>'in:case,tier,score'
        ]);

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $score = $request->score;
        $case_num = $request->case_num;
        $tier_value = $request->tier_value;
        $recallOption = $request->recallOption;
        $team_id = $request->team_id;
        if($recallOption == 'case')
        {
            $tier_value = null;
        }
        elseif($recallOption == 'score')
        {
            $case_num = null;
            $tier_value = null;
        }
        elseif($recallOption == 'tier')
        {
            $case_num = null;
        }

        $orderArray = $this->getOrderArray($corporation_id);
        $first = $orderArray[0];
        $second = $orderArray[1];
        $third = $orderArray[2];

        if($team_id == 'All'){
            $active_accounts = Active_Account::select('ID')
            ->where('ON_HOLD', 1)->where('CORPORATION_ID', $corporation_id)
            ->when($tier_value, function($query, $tier_value){
                return $query->where('TIER', '>=', $tier_value);
            })
            ->when($case_num, function($query, $case_num){
                return $query->where('ACCT_CASE', $case_num);
            })
            ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })
            ->when($third, function ($query, $third) {
                return $query->orderByRaw($third);
            })
            ->limit(15001)->get();
        }
        else{
            $active_accounts = Active_Account::select('ID')
            ->where('ON_HOLD', 1)->where('CORPORATION_ID', $corporation_id)->where('TEAM_ID', $team_id)
            ->when($tier_value, function($query, $tier_value){
                return $query->where('TIER', '>=', $tier_value);
            })
            ->when($case_num, function($query, $case_num){
                return $query->where('ACCT_CASE', $case_num);
            })
            ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })
            ->when($third, function ($query, $third) {
                return $query->orderByRaw($third);
            })
            ->limit(15001)->get();
        }

        $active_accounts_size = count($active_accounts);
        // return $active_accounts_size;
        if($active_accounts->isEmpty() == true)
        {
            return back()->with('error', 'No Accounts found');

        }
        if($active_accounts_size > 15000)
        {
            $this->dispatch(new ReleaseAccountsQueue($corporation_id, $recallOption, $case_num, $tier_value, $score, $team_id));
            return back()->with('message', 'Processing a large amount of accounts you can access them in a moment!');
        }

        $accountIds = "";
        foreach($active_accounts as $active_account){
            $accountIds = $accountIds.'"'.$active_account->ID.'",';
        }

        $accountIds =substr_replace($accountIds ,"", -1);
        DB::select( DB::raw('UPDATE `active_accounts` SET `ON_HOLD` = 0 WHERE `ID` IN ('.$accountIds.');'));

        return back()->with('success', $active_accounts_size.' Accounts Released');

    }


    public function tossAccounts(Request $request){
        //choses which type of toss to use
        if(in_array($request->toss_type, ['Agent to Agent', 'Team to Agent'])){
            $this->validate($request, [
                'send_to_agent' => 'required',
                'max_per_to' => 'max:11',
            ]);

            return $this->tossAgentAccounts($request);
        }
        else{
            $this->validate($request, [
                'send_to_team' => 'required',
                'max_per_to' => 'max:11',
            ]);

            return $this->tossTeamAccounts($request);
        }
    }

    use AccountDistrubution;
    public function redistributeAccounts(Request $request){
        // Added the ON_HOLD WHERE CLAUSE to accomdate RNN imports
        if($request->team_redistribute == 'all'){
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL, `TEAM_ID` = NULL
                WHERE `LAST_WORKED` IS NULL AND `CORPORATION_ID` = '.$request->corporationId.' AND ON_HOLD = 0;'));

            $this->TeamDistrubution($request->corporationId);
            $this->setAgentQueue($request->corporationId);
        }
        else{
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL
                WHERE `LAST_WORKED` IS NULL AND `TEAM_ID` = '.$request->team_redistribute.' AND ON_HOLD = 0;'));

            $this->setAgentQueueByTeam($request->team_redistribute);
        }

        // $this->validate($request, [
        //     'corporation_id',
        // ])
        $redistribution_record = new Redistribution_Record();
        $redistribution_record->corporation_id = $request->corporationId;
        $redistribution_record->team_id = $request->team_redistribute;
        $redistribution_record->save();

        return back()->with('success', 'Successfully Redistributed accounts');
    }
}
