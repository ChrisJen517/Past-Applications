<?php

namespace App\Http\Controllers\CorporateAdmin;

use App\Models\Active_Accounts_Mapping;
use App\Http\Controllers\Controller;
use Auth;
use Schema;
use Symfony\Component\HttpFoundation\Request;
use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use Carbon\Carbon;
use DB;
use App\Jobs\DirectoryNameMatchQueue;
use App\Jobs\DirectoryAccountMatchQueue;
use PDO;
use Config;


class DirectoryAgentSearchController extends Controller
{
    public function directoryAssign(){
 
        $this->dispatch(new DirectoryNameMatchQueue());

        $this->dispatch(new DirectoryAccountMatchQueue());
        
        return "done";
    }
}