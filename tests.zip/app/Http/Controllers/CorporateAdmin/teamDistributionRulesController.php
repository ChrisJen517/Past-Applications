<?php

namespace App\Http\Controllers\CorporateAdmin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Distribution_Rules;
use Auth;

class teamDistributionRulesController extends Controller
{
    public function viewCompanyRules(){
        $rules = Distribution_Rules::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->first();

        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;

        if($rules != null){
            //sets priorities for dropdowns
            $priority[] = $rules->priority;
            $priority[] = $rules->second_priority;
            $priority[] = $rules->third_priority;

            //sets value to checked if they were set as a priority
            if(in_array('ACCT_DUE_DATE', $priority))
                $preset[0] = 1;
            if(in_array('POESCORE', $priority))
                $preset[1] = 1;
            if(in_array('ACCT_SOURCE', $priority))
                $preset[2] = 1;
        }  
        else{
            $priority[] = "";
            $priority[] = "";
            $priority[] = "";
        }

        return view('corporateAdmin.pages.teamDistributionRules')->with('preset', $preset)->with('priority', $priority);
    }

    //sets the rules
    public function setCompanyRules(Request $request){
        $rules = Distribution_Rules::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->first();
        
        if($rules == null)
            $rules = new Distribution_Rules;
        
        $rules->corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        //sets the priorities based on the number checked
        if(count($request->checked) == 1){
            $rules->priority = $request->checked[0];
            $rules->second_priority = null;
            $rules->third_priority = null;
        }
        else {
            $rules->priority = $request->priority;

            if(count($request->checked) == 2){
                if($request->priority != $request->checked[0])
                    $rules->second_priority = $request->checked[0];
                else
                    $rules->second_priority = $request->checked[1];

                $rules->third_priority = null;
            }
            if(count($request->checked) == 3){
                $rules->second_priority = $request->prioritySecond;
                $priorities[] = $request->priority;
                $priorities[] = $request->prioritySecond;

                if(!in_array('POESCORE', $priorities))
                    $rules->third_priority = 'POESCORE';
                else if(!in_array('ACCT_DUE_DATE', $priorities))
                    $rules->third_priority = 'ACCT_DUE_DATE';
                else
                    $rules->third_priority = 'ACCT_SOURCE';
            }
        }
            
        $rules->save();

        return back()->with('success', 'Rules are set');
    }
}