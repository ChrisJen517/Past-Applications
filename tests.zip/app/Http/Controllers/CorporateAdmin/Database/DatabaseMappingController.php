<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Active_Accounts_Mapping;
use App\Http\Controllers\Controller;
use Auth;
use Schema;
use Symfony\Component\HttpFoundation\Request;

class DatabaseMappingController extends Controller
{
    public function showDatabaseMappingForm()
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $AAM = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();
        
        return view('corporateAdmin/pages/database/databaseMapping')->with('AAM', $AAM);
    }

    public function setDatabaseMapping(request $request)
    {
        $this->validate($request, [
            'ACCT_DUE_DATE' => 'required',
            'ACCT_SSN' => 'required',
            'ACCT_ID' => 'required',
        ]);

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $accountMapping = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();

        if ($accountMapping == null) {
            $accountMapping = new Active_Accounts_Mapping;
            $message = 'Mapping Added!';
        } else {
            $message = 'Mapping Updated';
        }  
            
        $accountMapping->ACCT_CLIENT = $request->ACCT_CLIENT;
        $accountMapping->CLIENT_PHONE = $request->ACCT_CLIENT_PHONE;
        $accountMapping->ACCT_AGENT = $request->ACCT_AGENT;
        $accountMapping->ACCT_DUE_DATE = $request->ACCT_DUE_DATE;
        $accountMapping->TEAM_ID = $request->TEAM_ID;
        $accountMapping->ACCT_CASE = $request->ACCT_CASE;
        $accountMapping->ACCT_SSN = $request->ACCT_SSN;
        $accountMapping->ACCT_FIRST_NAME = $request->ACCT_FIRST_NAME;
        $accountMapping->ACCT_LAST_NAME = $request->ACCT_LAST_NAME;
        $accountMapping->ACCT_AD1 = $request->ACCT_AD1;
        $accountMapping->ACCT_AD2 = $request->ACCT_AD2;
        $accountMapping->ACCT_CITY = $request->ACCT_CITY;
        $accountMapping->ACCT_ST = $request->ACCT_ST;
        $accountMapping->ACCT_ZIP = $request->ACCT_ZIP;
        $accountMapping->ACCT_DOB = $request->ACCT_DOB;
        $accountMapping->ACCT_ID = $request->ACCT_ID;
        $accountMapping->ACCT_SOURCE = $request->ACCT_SOURCE;
        $accountMapping->EMPL_NAME = $request->EMPL_NAME;
        $accountMapping->EMPL_ADDR1 = $request->EMPL_ADDR1;
        $accountMapping->EMPL_ADDR2 = $request->EMPL_ADDR2;
        $accountMapping->EMPL_CITY = $request->EMPL_CITY;
        $accountMapping->EMPL_ST = $request->EMPL_ST;
        $accountMapping->EMPL_ZIP = $request->EMPL_ZIP;
        $accountMapping->EMPL_HR_ADDR = $request->EMPL_HR_ADDR;
        $accountMapping->EMPL_PHONE1_NMBR = $request->EMPL_PHONE1_NMBR;
        $accountMapping->EMPL_PH_SOURCE = $request->EMPL_PH_SOURCE;
        $accountMapping->EMPL_FAX = $request->EMPL_FAX;
        $accountMapping->EMPL_EMAIL = $request->EMPL_EMAIL;
        $accountMapping->EMPL_TITLE = $request->EMPL_TITLE;
        $accountMapping->EMPL_CONTACT = $request->EMPL_CONTACT;
        $accountMapping->EMPL_CONTACT_TITLE = $request->EMPL_CONTACT_TITLE;
        $accountMapping->TIME_ZONE = $request->TIME_ZONE;
        $accountMapping->TEAM_RULE = $request->TEAM_RULE;
        $accountMapping->POESCORE = $request->POESCORE;
        $accountMapping->corporation_id = $corporation_id;
        $accountMapping->POWERLEAD_FLAG = $request->POWERLEAD_FLAG;
        $accountMapping->TIER = $request->TIER;
        $accountMapping->ACCESS_RULES = $request->ACCESS_RULES;
        $accountMapping->ACCT_TYPE = $request->ACCT_TYPE;
        $accountMapping->save();

        return redirect()->back()->with('message', $message);
    }

    public function checkCSVMapping(request $request)
    {

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $active_accounts_mapping = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();
        $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts_mapping');

        if ($active_accounts_mapping->ACCT_DUE_DATE == null
        || $active_accounts_mapping->ACCT_SSN == null 
        || $active_accounts_mapping->ACCT_ID == null) {
            return back()->with('error', 'File missing required headers. Please set up reupload database mapping form');
        }

        $file = new \SplFileObject($request->testMappingFile);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];

        // Grabbing names of the columns in the CSV file
        foreach ($file as $row) {
            foreach ($row as $header) {
                //removes hidden csv characters
                $headers[] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $header);
            }
            break;
        }

        $number_of_matched_columns = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach ($headers as $head) {
            foreach ($active_accounts_mapping_columns as $column) {
                if (strtoupper($active_accounts_mapping->$column) == strtoupper($head)) {
                    $number_of_matched_columns++;
                }
            }
        }

        // Checking if # of Database mapped columns are all on the CSV File
        $expected_col_number = 0;
        foreach ($active_accounts_mapping_columns as $column) {
            if ($active_accounts_mapping->$column != null) {
                $expected_col_number++;
            }
        }

        //removes the id, corporation id, created at, and updated at from the count
        $expected_col_number = $expected_col_number - 4;

        if ($expected_col_number != $number_of_matched_columns) {
            return redirect()->back()->with('error', 'More columns mapped than found on CSV, check database mapping.');
        } else {
            return redirect()->back()->with('message', 'Successfully Mapped CSV File Headers.');
        }

    }
}
