<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Access_Levels;
use Illuminate\Database\QueryException;
use App\Models\Corporation;
use App\Models\CSV_Upload;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Distribution_Rules;
use Auth;

class pastCSVController extends Controller
{
    public function showCSVUploads(){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $corporation = Corporation::where('corporation_id', $corporation_id)->select('corporation_id', 'name')->first();
        $csvs = CSV_Upload::where('corporation_id', $corporation_id)->orderBy('created_at', 'DESC')->get();
        $accessLevels = Access_Levels::select('shortcode')->where('corporation_id', $corporation_id)->get();

        $realCodes = [];
        foreach($accessLevels as $level){
            $realCodes[$level->shortcode] = $level->shortcode;
        }

        $uploads['accountUpload'] = [];
        $uploads['faxUpdate'] = [];
        foreach($csvs as $csv){
            $checks = explode( '|', $csv->required_to_download);

            $needed = "";
            foreach($checks as $check){
                if(array_key_exists($check, $realCodes))
                    $needed = $check.'|'.$needed;
            }

            $uploadType = $csv->upload_type ?? 'accountUpload';
            $uploads[$uploadType][] = [
                'id' => $csv->id,
                'date_upload' =>  date('m/d/Y h:i:s', strtotime($csv->created_at." +2 hours")),
                'status' => $csv->status,
                'method' => $csv->method,
                'number_of_records' => $csv->number_of_records,
                'required_to_download' => substr_replace($needed,"",-1),
                'file_path' => $csv->file_path,
                'failed_shortcodes' => $csv->failed_shortcodes,
            ];
        }
        return view('corporateAdmin.pages.database.pastCSVUploads')->with('uploads', $uploads)->with('companyName', $corporation->name);
    }

    public function downloadCSV(Request $request){
        $csvs = CSV_Upload::find($request->id);
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        if($csvs->corporation_id != $corporation_id){
            return redirect()->back()->with('error', 'Access Denied');
        }
        $accessLevels = Access_Levels::select('shortcode')->where('corporation_id', $corporation_id)->get();
        $realCodes = [];
        foreach($accessLevels as $level){
            $realCodes[$level->shortcode] = $level->shortcode;
        }

        $checks = explode( '|', $csvs->required_to_download);

        $needed = "";
        foreach($checks as $check){
            if(array_key_exists($check, $realCodes))
                $needed = $check.'|'.$needed;
        }
        $needed = substr_replace($needed,"",-1);
        $checks = explode( '|', $needed);
        
        $accessLevels = Access_Levels::wherein('shortcode', $checks)->select('id', 'shortcode')->get();
        $userLevels =  explode( ',', Auth::user()->has_access);
 
        $needed = [];
        foreach($accessLevels as $check){
            if(!in_array($check->id, $userLevels)){
                $needed[] = $check->id;
            }
        }
        if(!empty($needed)){
            $needed = $accessLevels->wherein('id',$needed);

            $levels = "";
            foreach($needed as $need){
                $levels = $need->shortcode.', '.$levels;
            }

            return back()->with('error', 'Missing the following access levels: '.substr_replace($levels, "", -2));
        }

        if (!file_exists($csvs->file_path))
            return back()->with('error', 'File not found');

        return response()->download($csvs->file_path, null, [
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
        ]);
    } 
}