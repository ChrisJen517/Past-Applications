<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Corporation;
use Auth;
use App\Models\Capcode;
use Illuminate\Validation\Rule;

class CapcodeManagementController extends Controller
{
    //list of required capcodes
    private $requiredCapcodes = array(
        '1103', '1104', '1111', '1112', //verified
        '2208', '2209', '2100', '2210', '2216', '2217', '2206', '2211', '2335', //inconclusive
        '6005', '6006', '6000', '4411', '4408', '5514' //unverified
    );

    public function showCapcodes()
    {
        $corporation = Auth::User()->corporation_corporate_admin_link;
        $capcodes = Capcode::where('corporation_id', $corporation->corporation_id)->get();
        return view('corporateAdmin.pages.database.capcodeManagement')->with('corporation', $corporation)->with('requiredCapcodes', $this->requiredCapcodes)->with('capcodes', $capcodes)->with('isAdmin', false);
    }

    public function addCapcode(Request $request)
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;

        if(in_array($request->capcode, $this->requiredCapcodes))
        {
            return back()->with('error', $request->capcode.' is a permanent capcode that cannot be duplicated');
        }

        $this->validate($request, [
            'capcode' => 'required',
            'name' => 'required|max:255',
            'type' => 'required|in:verified,unverified,inconclusive,pending_approval',
            'agent_access' => 'required|in:0,1'
        ]);

        //validates that it is actually one of the two options
        if(($request->account != null) && ($request->account != 'AWG7'))
            $request->account = null;

        if(Capcode::where('capcode', $request->capcode)->where('corporation_id', $corporation_id)->exists())
        {
            return redirect()->back()->with('error', 'This capcode is in use.');
        }

        $capcode = new Capcode();
        $capcode->capcode = $request->capcode;

        $capcode->name = $request->name;
        $capcode->description = $request->description;
        $capcode->type = $request->type;
        $capcode->agent_access = $request->agent_access;
        $capcode->capcode_type = $request->account == 'null' ? NULL : $request->account;
        $capcode->corporation_id = $request->corp_id;
        $capcode->save();

        return redirect()->back()->with('success', 'Capcode added successfully');
    }

    public function updateCapcode(Request $request)
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;

        if(in_array($request->capcode, $this->requiredCapcodes))
        {
            return back()->with('error', $request->capcode.' is a permanent capcode that cannot be duplicated');
        }

        $this->validate($request, [
            'capcode' => 'required',
            'name' => 'required|max:255',
            'type' => 'required|in:verified,unverified,inconclusive,pending_approval',
            'agent_access' => 'required|in:0,1'
        ]);

        //validates that it is actually one of the two options
        if(($request->account != null) && ($request->account != 'AWG7'))
            $request->account = null;

        if(Capcode::where('capcode', $request->capcode)->where('corporation_id', $corporation_id)->where('id', '!=', $request->capcode_id)->exists())
        {
            return redirect()->back()->with('error', 'This capcode is in use.');
        }

        $capcode = Capcode::where('id', $request->capcode_id)->first();
        $capcode->capcode = $request->capcode;
        $capcode->name = $request->name;
        $capcode->description = $request->description;
        $capcode->type = $request->type;
        $capcode->agent_access = $request->agent_access;
        $capcode->capcode_type = $request->account == 'null' ? NULL : $request->account;
        $capcode->save();

        return redirect()->back()->with('success', 'Capcode updated successfully');
    }

    public function archiveCapcode($id)
    {
        $capcode = Capcode::find($id);
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        if($capcode->corporation_id != $corporation_id){
            return redirect()->back()->with('error', 'Access Denied');
        }

        if(in_array($capcode->capcode, $this->requiredCapcodes))
        {
            return back()->with('error', $capcode->capcode.' is a permanent capcode and cannot be deleted');
        }

        $capcode->is_archived = ($capcode->is_archived == 0 ? 1 : 0);
        $capcode->save();

        return redirect()->back()->with('message', 'Capcode successfully ' . ($capcode->is_archived == 0 ? 'un' : '') . 'archived');
    }

}
