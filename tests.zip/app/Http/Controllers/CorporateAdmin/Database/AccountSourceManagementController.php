<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Account_Source;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AccountSourceManagementController extends Controller
{
    public function showAccountSourceManagement()
    {
        $corporation = Auth::User()->corporation_corporate_admin_link;
        $sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
        return view('corporateAdmin.pages.database.accountSourceManagement')->with('sources', $sources)->with('corporation', $corporation);
    }

    public function addAccountSource(Request $request)
    {
        $corporation = Auth::user()->corporation_corporate_admin_link;

        $this->validate($request, [
            'name' => 'required',
            'shortcode' => 'required',
        ]);

        if (strpos($request->shortcode, ',') !== false) {
            return redirect()->back()->with('error', 'Shortcodes can not contain a comma.');
        }

        if (Account_Source::where('shortcode', $request->shortcode)->where('corporation_id', $corporation->corporation_id)->exists()) {
            return redirect()->back()->with('error', 'This shortcode is in use.');
        }

        $max = Account_Source::where('corporation_id', $corporation->corporation_id)->orderBy('priority', 'desc')->first();
        if($max == null)
            $priority = 1;
        else
            $priority = $max->priority + 1;

        $account_source = new Account_Source();
        $account_source->name = $request->name;
        $account_source->description = $request->description;
        $account_source->shortcode = $request->shortcode;
        $account_source->priority = $priority;
        $account_source->corporation_id = $corporation->corporation_id;

        $account_source->save();

        return redirect()->back()->with('success', 'Account Updated Successfully');
    }

    public function updatePriority(Request $request)
    {
        $corporation = Auth::user()->corporation_corporate_admin_link;
        $shortcodes = $request->shortcodes;
        $orders = $request->orders;

        // Call the stored procedure to save the priority of the sources
        DB::statement('call SAVE_SOURCE_PRIORITY(?,?,?)', array(
            implode(',', $shortcodes) . ',',
            implode(',', $orders) . ',',
            $corporation->corporation_id
        ));
    }

    public function updateAccountSource(Request $request)
    {
        $corporation = Auth::user()->corporation_corporate_admin_link;

        if (strpos($request->shortcode, ',') !== false) {
            return redirect()->back()->with('error', 'Shortcodes can not contain a comma.');
        }

        if (Account_Source::where('shortcode', $request->shortcode)
        ->where('corporation_id', $corporation->corporation_id)
        ->where('account_source_id', '!=', $request->account_source_id)
        ->exists()) {
            return redirect()->back()->with('error', 'This shortcode is in use.');
        }
        $account_source = Account_Source::where('account_source_id', $request->account_source_id)->first();

        $account_source->name = $request->name;
        $account_source->description = $request->description;
        $account_source->shortcode = $request->shortcode;
        $account_source->save();

        return redirect()->back()->with('success', 'Account Source Updated Successfully');
    }


    public function deleteAccountSource($id)
    {
        $account_source = Account_Source::find($id);
        if($account_source->corporation_id != Auth::User()->corporation_corporate_admin_link->corporation_id){
            return redirect()->back()->with('error', 'Access Denied');
        }
        $account_source->delete();

        return redirect()->back()->with('message', 'Account Source Successfully Deleted');
    }

}
