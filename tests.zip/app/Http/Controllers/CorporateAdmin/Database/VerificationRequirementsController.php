<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Http\Controllers\Controller;
use App\Models\Verification_Requirements;
use Illuminate\Http\Request;
use Auth;

class VerificationRequirementsController extends Controller
{
    public function showRequirments(){
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $requirments = Verification_Requirements::where('corporation_id', $corporation_id)->first();

        if($requirments == null){
            $requirments = new Verification_Requirements();
            $requirments->corporation_id = $corporation_id;
            $requirments->save();
        }

        return view('corporateAdmin.pages.database.verificationRequirements')->with('requirments', $requirments);
    }

    public function updateRequirments(Request $request){
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $requirments = Verification_Requirements::where('corporation_id', $corporation_id)->first();
        
        if($requirments == null){
            $requirments = new Verification_Requirements();
            $requirments->corporation_id = $corporation_id;
        }
        
        $requirments->employer_type = $request->employer_type;
        $requirments->employer_name = $request->employer_name;
        $requirments->employer_phone = $request->employer_phone;
        $requirments->employer_address_1 = $request->employer_address_1;
        $requirments->employer_address_2 = $request->employer_address_2;
        $requirments->employer_city = $request->employer_city;
        $requirments->employer_state = $request->employer_state;
        $requirments->employer_zip = $request->employer_zip;
        $requirments->consumer_title = $request->consumer_title;
        $requirments->employer_fax = $request->employer_fax;
        $requirments->employer_email = $request->employer_email;
        $requirments->verification_mailing_address = $request->verification_mailing_address;
        $requirments->verification_contact_name = $request->verification_contact_name;
        $requirments->verification_contact_title = $request->verification_contact_title;
        $requirments->future_verifications = $request->future_verifications;
        $requirments->save();  

        return back()->with('success', 'Requirments Updated!');
    }

}