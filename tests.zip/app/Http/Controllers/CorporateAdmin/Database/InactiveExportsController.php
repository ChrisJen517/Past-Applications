<?php

namespace App\Http\Controllers\CorporateAdmin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Distribution_Rules;
use App\Models\Corporate_Settings;
use App\Models\Inactive_Account;
use App\Models\Corporation;


class InactiveExportsController extends Controller
{

   public function showPreviousExports()
   {
    //$previousExports = DB::select( DB::raw("SELECT * FROM "))
    return view('corporateAdmin/pages/database/previousExports');
   }

   public function export(Request $request)
   {
        $corporation_id = Corporate_Admin::where('user_id', '=', Auth::user()->user_id)->first()->corporation_id;
        $inactive = Inactive_Account::get()->where('Corporation_ID', '=', $corporation_id);

        
   }

    

}