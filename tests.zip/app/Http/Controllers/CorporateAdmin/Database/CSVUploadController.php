<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Access_Levels;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use PDO;
use Auth;
use Config;
use Schema;
use App\Models\Active_Accounts_Mapping;
use Illuminate\Database\QueryException;
use App\Jobs\TeamDistrubutionQueue;
use App\Jobs\PowerleadDistrubutonQueue;
use App\Jobs\DirectoryTeamDistributionQueue;
use App\Jobs\DirectoryAgentDistributionQueue;
use App\Models\Corporate_Settings;
use App\Traits\AccountDistrubution;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Settings;
use App\Models\Distribution_Rules;
use App\Models\Account_Source;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Models\CSV_Upload;
use Carbon\Carbon;
use App\Models\Team;
use App\Jobs\DirectoryAccountMatchQueue;
use App\Jobs\DirectoryNameMatchQueue;
use App\Jobs\AccountCheckBlockedQueue;
use App\Jobs\CheckWorkedSSN;
use App\Traits\getIdCombinations;

class CSVUploadController extends Controller
{
    use AccountDistrubution, getIdCombinations;
    
    public function showCSVUploads()
    {
        return view('corporateAdmin.pages.database.CSVUpload');
    }

    public function uploadAccounts(Request $request)
    {   
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
    
        $file = $request->file('accountUpload');
        $csvCheck = $this->checkCSV($file);
        if($csvCheck == false){
            return back()->with('error', 'One of your rows has more columns then your header row');
        }

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $corporation_name = Auth::User()->corporation_corporate_admin_link->name;
        $corporation_name_regex = preg_replace("/[^A-Za-z]/", '', $corporation_name);
        $table_name = $corporation_name_regex;
        $corporate_settings = Corporate_Settings::where('corporation_id', $corporation_id)->first();
        $powerlead_settings = Powerlead_Settings::first();
        $errorMessage = "";

        $fileNumber = CSV_Upload::max('id') + 1;
        $fileNumber = str_replace(" ","",$fileNumber.$corporation_name.date('Y-m-d').'.csv');
        $filePath = storage_path('app/public/CSVUploads/'.$corporation_id);
        $savePrevious = new CSV_Upload;
        $savePrevious->corporation_id = $corporation_id;
        $savePrevious->number_of_records = 0;
        $savePrevious->method = "Manual Upload";
        $savePrevious->file_path = $filePath.'/'.$fileNumber;
        $savePrevious->upload_type = 'accountUpload';

        //saves the file
        $file = $request->file('accountUpload');
        $download = $file->storeAs('CSVUploads/'.$corporation_id, $fileNumber);

        $active_accounts_mapping = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();
        if(empty($active_accounts_mapping)){
            $savePrevious->status = "failed";
            $savePrevious->save();

            return redirect()->back()->with('error', 'Your database mapping has not been set up. Please set up database mapping form.');
        }
        else if ($active_accounts_mapping->ACCT_DUE_DATE == null
         || $active_accounts_mapping->ACCT_SSN == null 
         || $active_accounts_mapping->ACCT_ID == null) {
            $savePrevious->status = "failed";
            $savePrevious->save();

            return back()->with('error', 'File missing required headers. Please re-upload database mapping form');
        }
        
        $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts_mapping');
        // Assigning DB values   
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        
        // Setting up reading file that is uploaded
        $file = new \SplFileObject($request->accountUpload);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {   
            if($rows == 0){
                foreach($row as $header)
                {   
                    //removes hidden csv characters
                    $headers[] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $header);
                }
            }
            $rows++;
        }
        $savePrevious->number_of_records = $rows - 2;

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $count = 0;
        $countHead = 0;
        $number_of_matched_columns = 0;
        $corp_drop_check = 0;
        $on_hold_drop_check = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
          
            if($head == $active_accounts_mapping->ACCT_DUE_DATE){
                $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` datetime, ";
            }else{
                $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";
            }
            
            if(strtolower($head) == 'corporation_id'){
                $corp_drop_check = 1;
            }
            elseif(strtolower($head) == 'on_hold'){
                $on_hold_drop_check = 1;
            }
            else
            {
                foreach($active_accounts_mapping_columns as $column)
                {
                    if(strtoupper($active_accounts_mapping->$column) == strtoupper($head))
                    {
                        if($count == 0)
                        {
                            $insert_statement = $column;
                            $insert_statement_CSV = "`$table_name`.`".$head."`";
                            $number_of_matched_columns++;
                            $count++;
                        }
                        else    
                        {
                            $insert_statement = $insert_statement.", ".$column;
                            $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$head."`";
                            $number_of_matched_columns++;
                        }
                    }
                }
            }
        }

        $insert_statement = $insert_statement.", corporation_id";
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`corporation_id`";
        $insert_statement = $insert_statement.", ON_HOLD";
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`ON_HOLD`";
        $insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);

        // Checking if # of Database mapped columns are all on the CSV File
        $expected_col_number = 0;
        foreach($active_accounts_mapping_columns as $column)
        {
            if($active_accounts_mapping->$column != null)
            {
                $expected_col_number++;
            }
        }
        // return $expected_col_number;
        $expected_col_number = $expected_col_number - 4;
        if($expected_col_number != $number_of_matched_columns)
        {
            $savePrevious->status = "failed";
            $savePrevious->save();

            return redirect()->back()->with('error', 'More columns mapped than found on CSV, check database mapping.');
        }    
        try {
            // Dropping table if one previously existed
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            // Creating a temp table to upload CSV file
            $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
                $insert_statement_temp_table);"));
            
            // Creating connection to database allowing whole file to be uploaded
            $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
                PDO::MYSQL_ATTR_LOCAL_INFILE => true,
            ));

            // Writing query to load file
            $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES", addslashes($request->accountUpload));
            // executing query on database 
            $conn->exec($query);
            $numberofAccounts = DB::select( DB::raw( "SELECT COUNT(1) AS 'COUNT' FROM `$table_name`"));

            if($numberofAccounts[0]->COUNT <= 0){
                return back()->with('error', 'Check CSV, Your CSV seem to be corrupt. Please open the CSV in Excel and re-save as .CSV');
            }
            //Checking for bad DUE_DATES Dates
            $due_dates = DB::select( DB::raw("SELECT DISTINCT `$active_accounts_mapping->ACCT_DUE_DATE` AS DUE_DATE FROM `$table_name` WHERE `$active_accounts_mapping->ACCT_DUE_DATE` = '0000-00-00';"));
            $count_due_dates = count($due_dates);
            $due_date_fail = false;
            if($count_due_dates > 0){
                if($active_accounts_mapping->ACCESS_RULES == '' || $active_accounts_mapping->ACCESS_RULES == null){
                    $due_date_fail = true;
                    $failedRows = DB::select( DB::raw("SELECT * FROM `$table_name` WHERE `$active_accounts_mapping->ACCT_DUE_DATE` = '0000-00-00';"));

                    if(!is_dir($filePath.'/failed'))
                    mkdir($filePath.'/failed');

                    $failedFile = fopen($filePath.'/failed/failed'.$fileNumber, 'x+');
                    fputcsv($failedFile, array_keys((array) $failedRows[0]));
                    
                    foreach($failedRows as $row){
                        fputcsv($failedFile, array_values((array) $row));
                    }

                    $savePrevious->failed_shortcodes = $filePath.'/failed/failed'.$fileNumber;
                    $savePrevious->status = "failed";
                    $savePrevious->save();

                    //deletes invalid codes from the table
                    $DeleteCodes = DB::SELECT( DB::RAW("DELETE FROM `$table_name` WHERE `$active_accounts_mapping->ACCT_DUE_DATE` = '0000-00-00';"));

                    $errorMessage = count($failedRows)." Accounts with DUE_DATE in wrong format or missing! All other accounts were uploaded. FORMAT = YYYY-MM-DD";
                }else{
                    $due_date_fail = true;
                }

            }  

            // Adding the column corporation_id
            if($corp_drop_check == 1){
                DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP corporation_id'));
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `corporation_id` BIGINT(20) NOT NULL DEFAULT $corporation_id AFTER `$head`;
                "));
                $head = "corporation_id";
            }
            else{
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `corporation_id` BIGINT(20) NOT NULL DEFAULT $corporation_id AFTER `$head`;
                "));
                $head = "corporation_id";    

            }

            if($on_hold_drop_check == 1){
                DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP on_hold'));
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `ON_HOLD` TINYINT(4) NOT NULL DEFAULT 1 AFTER `$head`;
                "));
                $head = "ON_HOLD";
            }
            else{
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `ON_HOLD` TINYINT(4) NOT NULL DEFAULT 1 AFTER `$head`;
                "));
                $head = "ON_HOLD";
            }
            if($active_accounts_mapping->ACCESS_RULES != ''){
                DB::select( DB::raw("UPDATE `$table_name` SET `$active_accounts_mapping->ACCESS_RULES` = REPLACE(`$active_accounts_mapping->ACCESS_RULES`, ' ', '');"));
                $corporateRules = Access_Levels::where('corporation_id', $corporation_id)->select('id', 'shortcode')->get();
                
                //makes sure there are rules to work with
                if($corporateRules->first() == null){
                    $savePrevious->status = "failed";
                    $savePrevious->save();

                    $errorMessage = "Access Levels not set for your corporation";
                    return redirect()->back()->with('error', $errorMessage);
                }

                //gets all the agents in the company that are still active AND have shortcodes, then gets the list of shortcode combinations they have
                $agents = Agent::where('corporation_id', $corporation_id)->select('user_id')->with('user_link')->get();
                $agentAccessLevels  = [];
                foreach($agents as $agent){
                    if(($agent->user_link->is_deactivated == 0) && ($agent->user_link->has_access != null) && ($agent->user_link->has_access != "")){
                        $array = explode(',',$agent->user_link->has_access);
                        $agentAccessLevels = $this->getIdCombinations($agentAccessLevels, $array);
                    }
                }
                DB::select( DB::raw("UPDATE `$table_name` SET `$active_accounts_mapping->ACCESS_RULES` = REPLACE(`$active_accounts_mapping->ACCESS_RULES`, ' ', '');"));
                DB::select( DB::raw("UPDATE `$table_name` SET `$active_accounts_mapping->ACCESS_RULES` = UPPER(`$active_accounts_mapping->ACCESS_RULES`);"));

                //gets all the distinct rules 
                $rules = DB::select( DB::raw("SELECT DISTINCT `$active_accounts_mapping->ACCESS_RULES` AS RULES FROM `$table_name` WHERE `$active_accounts_mapping->ACCESS_RULES` != '';"));

                //finds all cases that are not in the shortcodes
                $notFound = "";
                $invalidCodes = "";
                $noAgentCodeCombination = "";
                $allShorts = [];
                foreach($rules as $rule){
                    $newInvalid = false;
                    $checkIds = [];
                    $checks = explode( ',', $rule->RULES);

                    foreach($checks as $check){
                        $inCodes = $corporateRules->where('shortcode', $check)->first();

                        if($inCodes == null){
                            //if there is no code put it in the 
                            $newInvalid = true;
                            $notFound = $check.', '.$notFound;
                        }
                        else{
                            $checkIds[] = $inCodes->id;
                        }
                        if(!array_key_exists($check, $allShorts))
                            $allShorts[$check] = $check;     
                    }

                    //checks that the current shortcode combination exists for the agents
                    if(count($checkIds) != 0){
                        sort($checkIds);
                        if(!in_array(implode(",",$checkIds),$agentAccessLevels)){
                            $noAgentCode = "";
                            rsort($checkIds);
                            foreach($checkIds as $ids){
                                $noAgentCode = $corporateRules->where('id', $ids)->first()->shortcode.', '.$noAgentCode;
                            }
                            $noAgentCodeCombination = '"'.substr_replace($noAgentCode,"",-2).'", '.$noAgentCodeCombination;
                            
                            $newInvalid = true;
                        }
                    }

                    //if there is a shortcode that does not exist, adds it to the string
                    if($newInvalid){
                        $invalidCodes = '"'.$rule->RULES.'", '.$invalidCodes;
                    }
                }

                //gets all the required shortcodes for download into a string
                $required = "";
                foreach($allShorts as $shorts){
                    $required = $shorts.'|'.$required;
                }
                $savePrevious->required_to_download = substr_replace($required,"",-1);

                
                //if one is not in the csv gets all the rows that failed and puts them into a new csv 
                if(($notFound != "") || ($noAgentCodeCombination != "")){  
                    $invalidCodes = substr_replace($invalidCodes, "", -2);
                    if($due_date_fail == true){
                        $failedRows = DB::select( DB::raw("SELECT * FROM `$table_name` WHERE  `$active_accounts_mapping->ACCESS_RULES` IN  ($invalidCodes) OR `$active_accounts_mapping->ACCT_DUE_DATE` = '0000-00-00';"));
                    }else{
                        $failedRows = DB::select( DB::raw("SELECT * FROM `$table_name` WHERE  `$active_accounts_mapping->ACCESS_RULES` IN  ($invalidCodes);"));
                    }

                    if(!is_dir($filePath.'/failed'))
                        mkdir($filePath.'/failed');

                    $failedFile = fopen($filePath.'/failed/failed'.$fileNumber, 'x+');
                    fputcsv($failedFile, array_keys((array) $failedRows[0]));
                    
                    foreach($failedRows as $row){
                        fputcsv($failedFile, array_values((array) $row));
                    }

                    $savePrevious->failed_shortcodes = $filePath.'/failed/failed'.$fileNumber;
                    $savePrevious->status = "failed";
                    $savePrevious->save();

                    //deletes invalid codes from the table
                    if($due_date_fail == true){
                        $DeleteCodes = DB::SELECT( DB::RAW("DELETE FROM `$table_name` WHERE  `$active_accounts_mapping->ACCESS_RULES` IN  ($invalidCodes) OR `$active_accounts_mapping->ACCT_DUE_DATE` = '0000-00-00';"));
                        $errorMessage = count($failedRows)." DUE_DATE and shortcode(s) are not set or formated correctly!";
                    }else{
                        $DeleteCodes = DB::SELECT( DB::RAW("DELETE FROM `$table_name` WHERE  `$active_accounts_mapping->ACCESS_RULES` IN  ($invalidCodes);"));
                        $errorMessage = count($failedRows)." shortcode(s) are not set!";
                    }
                    //Adds the invalid codes to the error message, if any
                    if($notFound != ""){
                        $notFound = substr_replace($notFound, "", -2);
                        $errorMessage = $errorMessage." The following access levels are not found: ".$notFound.".";
                    }

                    //Adds which code combinations the agents are missing, if any
                    if($noAgentCodeCombination != ""){
                        $noAgentCodeCombination = substr_replace($noAgentCodeCombination, "", -2);
                        $errorMessage = $errorMessage." No active agents have access to the following combinations: ".$noAgentCodeCombination.".";
                    }

                    $errorMessage = $errorMessage." All other accounts were uploaded.";
                }
            }
            if($active_accounts_mapping->POESCORE != '')
            {
                DB::select(DB::raw("UPDATE `$table_name` SET `ON_HOLD` = 0 WHERE `$active_accounts_mapping->POESCORE` > ($corporate_settings->hold_accounts_below_score);")); 
            }
            
            //removes any accounts that are not a defined type
            if($active_accounts_mapping->ACCT_TYPE != '')
            {
                //sets all accounts to uppercase then checks for accounts that would not are not AWG7
                DB::select( DB::raw("UPDATE `$table_name` SET `$active_accounts_mapping->ACCT_TYPE` = UPPER(`$active_accounts_mapping->ACCT_TYPE`);"));

                //sets all non awg7 accounts to null, and adds to the error message to say all non empty rows were set to null
                $count = DB::select(DB::raw("SELECT COUNT(*) AS 'count' FROM `$table_name` WHERE `$active_accounts_mapping->ACCT_TYPE` != 'AWG7' AND `$active_accounts_mapping->ACCT_TYPE` != '';"));
                if($count[0]->count != 0){
                    $errorMessage = $errorMessage." ".$count[0]->count." Accounts of an undefined type found, set to basic account type.";
                }
                DB::select(DB::raw("UPDATE `$table_name` SET `$active_accounts_mapping->ACCT_TYPE` = NULL WHERE `$active_accounts_mapping->ACCT_TYPE` != 'AWG7';"));

                //adds the new rule to all the rows 
                if($active_accounts_mapping->ACCESS_RULES != ''){
                    //adds AWG7 to all Accounts that exist within the access rules                
                    DB::select(DB::raw("UPDATE `$table_name` 
                    SET `$active_accounts_mapping->ACCESS_RULES` = CONCAT(`$active_accounts_mapping->ACCESS_RULES`, ',AWG7') 
                    WHERE `$active_accounts_mapping->ACCESS_RULES` != '' AND `$active_accounts_mapping->ACCT_TYPE` = 'AWG7';"));
                }
                //if there is no mapping adds the column
                else{
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                        ADD COLUMN `TYPE_RULES_AWG7` VARCHAR(45) DEFAULT NULL AFTER `$head`;
                    "));
                    $head = "TYPE_RULES_AWG7";
                    $insert_statement = $insert_statement.", ACCESS_RULES";
                    $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`TYPE_RULES_AWG7`";
                    $active_accounts_mapping->ACCESS_RULES = "TYPE_RULES_AWG7";
                }
                //adds awg7 to the access rules that are null that have the type AWG7
                DB::select(DB::raw("UPDATE `$table_name` SET `$active_accounts_mapping->ACCESS_RULES` = 'AWG7' WHERE (`$active_accounts_mapping->ACCESS_RULES` is null OR `$active_accounts_mapping->ACCESS_RULES` = '') AND `$active_accounts_mapping->ACCT_TYPE` = 'AWG7';"));
            }
 
            if($corporate_settings->powerlead_active == 1){
                if($active_accounts_mapping->POWERLEAD_FLAG != ''){
                    DB::select(DB::raw("UPDATE `$table_name` SET `ON_HOLD` = $corporate_settings->power_hold WHERE `$active_accounts_mapping->POWERLEAD_FLAG` = 1;")); 
                }
                if($powerlead_settings->hold_accounts_automatically == 1)
                {
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                    ADD COLUMN `POWERLEAD_CAPCODE` TINYINT(4) NOT NULL DEFAULT 1 AFTER `$head`;
                    "));
                    $head = "POWERLEAD_CAPCODE";

                    DB::select(DB::raw("UPDATE `$table_name` SET `POWERLEAD_CAPCODE` = 1 WHERE `$active_accounts_mapping->POWERLEAD_FLAG` = 1;")); 

                    $insert_statement = $insert_statement.", POWERLEAD_CAPCODE";
                    $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`POWERLEAD_CAPCODE`";
                }
            }
            
            if($corporate_settings->directory_option == 1){
                if(($powerlead_settings->hold_accounts_automatically == 1) && ($corporate_settings->powerlead_active == 1)){
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                    ADD COLUMN `DIRECTORY_FLAG` TINYINT(4) NOT NULL DEFAULT 1 AFTER `$head`;
                    "));
                    $head = "DIRECTORY_FLAG";
                }
                else{
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                    ADD COLUMN `DIRECTORY_FLAG` TINYINT(4) NOT NULL DEFAULT 1 AFTER `$head`;
                    "));
                    $head = "DIRECTORY_FLAG";
                }

                $insert_statement = $insert_statement.", DIRECTORY_FLAG";
                $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`DIRECTORY_FLAG`";
            }

            //gets the old highest id
            $startSSNCheck = Active_Account::max('ID') + 1;

            // // Inserting the columns from the CSV file that are requested into our database.
            DB::select( DB::raw("INSERT IGNORE INTO active_accounts 
                            ($insert_statement)
                            SELECT 
                        $insert_statement_CSV
                        FROM `$table_name`"));
            
            // Dropping table after insert has happened
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            
            //gets the current highest id
            $endSSNCheck = Active_Account::max('ID');
        }
        catch(QueryException $e){
            $savePrevious->status = "failed";
            $savePrevious->save();

            $errorMessage = "Recheck Database Mapping and attempt to reupload, if not SQL Error".$e->errorInfo[1];
            return redirect()->back()->with('error', $errorMessage);
        }

        if($corporate_settings->powerlead_active == 1 && $powerlead_settings->hold_accounts_automatically == 0){
            $this->dispatch(new PowerleadDistrubutonQueue($corporation_id));
        }

        $this->dispatch(new DirectoryNameMatchQueue($corporation_id));
        $this->dispatch(new AccountCheckBlockedQueue($corporation_id));
        $this->dispatch(new TeamDistrubutionQueue($corporation_id));

        $this->dispatch(new CheckWorkedSSN($corporation_id, $startSSNCheck, $endSSNCheck));

        // creates needed directory team accounts
        if($corporate_settings->directory_option == 1){
            $this->dispatch(new DirectoryAgentDistributionQueue($corporation_id));
            $this->dispatch(new DirectoryAccountMatchQueue($corporation_id));
        }
        
        if( $errorMessage == ""){
            $savePrevious->status = "sucess";
            $savePrevious->save();
            return redirect()->back()->with('success', 'Accounts Uploaded Successfully');
        }
        else
            return redirect()->back()->with('error', $errorMessage);
    }

    public function uploadInactive(Request $request)
    { 
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
     
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $corporation_name = Auth::User()->corporation_corporate_admin_link->name;
        $corporation_name_regex = preg_replace("/[^A-Za-z]/", '', $corporation_name);
        $table_name = $corporation_name_regex."Inactive";

        // Assigning DB values   
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');

        $file = new \SplFileObject($request->uploadUnactive);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];

        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {   
            foreach($row as $header)
            {   
                $headers[] = $header;
            }
            break;
        }

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $count = 0;
        $countHead = 0;
        $number_of_matched_columns = 0;
        $header_check = false;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
            if($countHead == 0)
            {
                $insert_statement_temp_table = "`".$head."` VARCHAR( 90 ) ";
            }
            else
            {
                $insert_statement_temp_table = $insert_statement_temp_table.", `".$head."` VARCHAR( 90 ) ";
            }
            $countHead++;
            if($head == 'ssn_recall')
            {
                $header_check = TRUE;
            }

        }
        
        if($header_check == false)
        {
            return redirect()->back()->with('error', 'Make sure you have the correct column labeled ssn_recall');
        }

        try {
            // Dropping table if one previously existed
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            // Creating a temp table to upload CSV file
            $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
                $insert_statement_temp_table);"));
            
            // Creating connection to database allowing whole file to be uploaded
            $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
                PDO::MYSQL_ATTR_LOCAL_INFILE => true,
            ));

            // Writing query to load file
            $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($request->uploadUnactive));
            // executing query on database 
            $conn->exec($query);

            $newTable = DB::select(DB::RAW("SELECT ssn_recall FROM `$table_name`"));
            
            $ssn_count = 0;
            foreach($newTable as $data)
            {
                if($ssn_count == 0)
                {
                    $ssn_string = '"'.$data->ssn_recall.'",'; 
                    $ssn_count++;
                }
                else
                {
                    $ssn_string = $ssn_string.' "'.$data->ssn_recall.'",';
                }
            }
                    
            $ssn_string = substr_replace($ssn_string ,'', -1);
            
            // return $ssn_string;
            DB::select(DB::raw("CALL move_to_inactive('$ssn_string', $corporation_id);"));
        }
        catch(QueryException $e){
            $errorMessage = "Please check that your SSN column is named ssn_recall. Error ID:".$e->errorInfo[1];
            return redirect()->back()->with('error', $errorMessage);
        }

        return redirect()->back()->with('success', 'Accounts Moved to Inactive Successfully');
    }

    public function massUpdateCapcode(Request $request){
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
     
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $corporation_name = Auth::User()->corporation_corporate_admin_link->name;
        $corporation_name_regex = preg_replace("/[^A-Za-z]/", '', $corporation_name);
        $table_name = $corporation_name_regex."MassUpload";
        $corporationCapcodes = Capcode::select('capcode', 'id', 'type')->where('corporation_id', $corporation_id)->where('is_archived', 0)->get();

        // Assigning DB values   
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');

        $file = new \SplFileObject($request->uploadUpdate);
        $file->setFlags(\SplFileObject::READ_CSV);

        $fileNumber = CSV_Upload::max('id') + 1;
        $fileNumber = str_replace(" ","",$fileNumber.$corporation_name.date('Y-m-d').'.csv');
        $filePath = storage_path('app/public/CSVUploads/'.$corporation_id);
        $savePrevious = new CSV_Upload;
        $savePrevious->corporation_id = $corporation_id;
        $savePrevious->number_of_records = 0;
        $savePrevious->method = "Manual Upload";
        $savePrevious->file_path = $filePath.'/'.$fileNumber;
        $savePrevious->upload_type = 'faxUpdate';
        $savePrevious->status = "success";

        //saves the file
        $fileToDownload = $request->file('uploadUpdate');
        $download = $fileToDownload->storeAs('CSVUploads/'.$corporation_id, $fileNumber);

        try {
            // Dropping table if one previously existed
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            // Creating a temp table to upload CSV file
            $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
                `ACCT_ID` INT(12) , `capcode` VARCHAR( 90 ),
                CONSTRAINT acct_id_pk PRIMARY KEY (ACCT_ID));"));
            
            // Creating connection to database allowing whole file to be uploaded
            $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
                PDO::MYSQL_ATTR_LOCAL_INFILE => true,
            ));

            // Writing query to load file
            $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n'", addslashes($request->uploadUpdate));
            // executing query on database 
            $conn->exec($query);

            //gets the number of rows and the disinct capcodes
            $accounts = DB::SELECT( DB::RAW("SELECT distinct(capcode) as capcode from `$table_name`;"));
            $numberOfRecords = DB::SELECT( DB::RAW("SELECT count(*) as totalCount from `$table_name`;"));
            $savePrevious->number_of_records = $numberOfRecords[0]->totalCount;

            //gets all the capcodes into arrays by if they work or fail
            $updateByCapcode = [];
            $notSetCapcode = [];
            foreach($accounts as $account){
                if($corporationCapcodes->where('capcode', $account->capcode)->first() != null){
                    $updateByCapcode[] = $account->capcode;
                }
                else{
                    $notSetCapcode[] = $account->capcode;
                }
            }

            //more descriptive error message if no capcodes are set properly
            if(empty($updateByCapcode)){
                $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
                $savePrevious->status = "failed";
                $savePrevious->save();
                return redirect()->back()->with('error', "None of the ".$savePrevious->number_of_records." account id(s) could be set, as no capcodes on the csv are active in the system.");
            }

            $createHistory = "";
            $closedAccountsCount = 0;
            $updatedAccountsCount = 0;
            $updatedClosedAccounts = 0;

            //gets the list of account ids that would be needed for setting the histories
            $activesToBeUpdated = DB::SELECT(DB::RAW("SELECT active_accounts.ID as account_id, t2.capcode as history_capcode 
            FROM  `active_accounts` INNER JOIN `$table_name` t2 ON active_accounts.ACCT_ID = t2.ACCT_ID
            where `CORPORATION_ID` = ".$corporation_id." AND t2.capcode IN (".implode(',', $updateByCapcode).");"));
            
            $updateValues = $this->createMassHistory($activesToBeUpdated, $corporationCapcodes);
            $createHistory = $createHistory.$updateValues[0];
            $updatedAccountsCount = $updateValues[1];
            $closedAccountsCount = $updateValues[2];

            $inactivesToBeUpdated = DB::SELECT(DB::RAW("SELECT inactive_accounts.ID as account_id, t2.capcode as history_capcode 
            FROM  `inactive_accounts` INNER JOIN `$table_name` t2 ON inactive_accounts.ACCT_ID = t2.ACCT_ID
            where `CORPORATION_ID` = ".$corporation_id." AND t2.capcode IN (".implode(',', $updateByCapcode).");"));
            $updateValues = $this->createMassHistory($inactivesToBeUpdated, $corporationCapcodes);
            $updatedClosedAccounts = $updateValues[1];

            if($createHistory == '' || $updateValues[0] == '')
                $createHistory = $createHistory.$updateValues[0];
            else
                $createHistory = $createHistory.','.$updateValues[0];

            //sets up the final message to be shown to the user, and tells them how many if any failed
            $message = $updatedAccountsCount." total active accounts were updated of those ".$closedAccountsCount." accounts were moved to closed, and ".$updatedClosedAccounts." closed accounts were updated.";
            $messageType = "message"; 
            if(!empty($notSetCapcode)){
                $messageType = "error";
                $failedCodes = implode(',', $notSetCapcode);
                $failCount = DB::SELECT( DB::RAW("SELECT count(*) as fail from `$table_name` where capcode in (".$failedCodes.");"));

                $message = $message." But ".$failCount[0]->fail." account id(s) were not set because you were missing the following capcode(s): ".$failedCodes.".";

                $savePrevious->status = "failed";
            }
            
            //updates the accounts by the diffrent capcodes
            $inactiveCapcodeIds = [];
            foreach($updateByCapcode as $updateCapcode){
                $updateCapcode = $corporationCapcodes->where('capcode', $updateCapcode)->first();
                $activeAccounts = DB::SELECT( DB::RAW("UPDATE `active_accounts` 
                    INNER JOIN `$table_name` t2 ON active_accounts.ACCT_ID = t2.ACCT_ID
                    SET active_accounts.UPDATED_AT = NOW(), active_accounts.CAPCODE = ".$updateCapcode->id.",
                    active_accounts.LAST_WORKED = NOW() 
                    WHERE t2.capcode = ".$updateCapcode->capcode." AND `CORPORATION_ID` = ".$corporation_id.";"));

                $inactiveAccounts = DB::SELECT( DB::RAW("UPDATE `inactive_accounts` 
                    INNER JOIN `$table_name` t2 ON inactive_accounts.ACCT_ID = t2.ACCT_ID
                    SET inactive_accounts.UPDATED_AT = NOW(), inactive_accounts.CAPCODE = ".$updateCapcode->id.",
                    inactive_accounts.LAST_WORKED = NOW() 
                    WHERE t2.capcode = ".$updateCapcode->capcode." AND `CORPORATION_ID` = ".$corporation_id.";"));

                if($updateCapcode->type == 'verified' || $updateCapcode->type == 'unverified'){
                    $inactiveCapcodeIds[] = $updateCapcode->id;
                }
            }

            //moves needed accounts to closed
            if(!empty($inactiveCapcodeIds)){
                $inactiveCapcodeIds = implode(',', $inactiveCapcodeIds);
                DB::select(DB::raw('INSERT INTO `inactive_accounts` SELECT * FROM `active_accounts` 
                    WHERE `CAPCODE` IN ('.$inactiveCapcodeIds.') AND `CORPORATION_ID` = '.$corporation_id.';'));

                DB::select(DB::raw('DELETE FROM `active_accounts` 
                    WHERE `CAPCODE` IN ('.$inactiveCapcodeIds.') AND `CORPORATION_ID` = '.$corporation_id.';'));
            }

            $savePrevious->save();

            //creates the histories for the updated accounts
            DB::select(DB::raw("INSERT INTO `worked_history`(active_account_id, user_role, capcode, notes, agent_id, updated_at, created_at) VALUES ".$createHistory.";"));

            // Dropping table after all updates are done
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));

            return redirect()->back()->with($messageType, $message);
        }
        catch(QueryException $e){
            $errorMessage = "Oh no an error occured, check that you uploaded the correct file. Error ID:".$e->errorInfo[1];
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            $savePrevious->status = "failed";
            $savePrevious->save();
            return redirect()->back()->with('error', $errorMessage);  
        }
    }

    public function createMassHistory($accounts, $corporationCapcodes){
        //adds to an insert statement to give all active accounts a work history
        $createHistory = "";
        $closedAccountsCount = 0;
        $updatedAccountsCount = 0;
        foreach($accounts as $account){
            $updateCapcode = $corporationCapcodes->where('capcode', $account->history_capcode)->first();

            $createHistory = $createHistory." ('".$account->account_id."', 'AutoGenerated', '".$updateCapcode->id."', 
                'Account was updated in a mass update from fax uploads', '0', now(), now()),";

            $updatedAccountsCount++;
            if($updateCapcode->type == 'verified' || $updateCapcode->type == 'unverified'){
                $closedAccountsCount++;
            }
        }
        $createHistory = substr_replace($createHistory ,"", -1);

        $finalData[] = $createHistory;
        $finalData[] = $updatedAccountsCount;
        $finalData[] = $closedAccountsCount;
        return $finalData;
    }
        
    public function checkCSV($file){
        $row = 1;
        $header = 0;
        if (($handle = fopen($file, "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $num = count($data);
                if($row == 1){
                    $header = $num;
                }else{
                    if($header != $num){
                        return false;
                    }
                }
                $row++;
            }
            fclose($handle);
        }
        return true;
    }
}