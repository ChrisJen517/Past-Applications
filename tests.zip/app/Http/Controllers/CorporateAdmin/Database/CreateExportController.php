<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Previous_Export;
use Auth;
use Illuminate\Http\Request;
use DB;

class CreateExportController extends Controller
{
    public function showExportForm()
    {
        $corporationId = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporationId)->where('is_deactivated', 0)->get();
        $capcodes = Capcode::select('id', 'capcode', 'name')->where('corporation_id', $corporationId)->where('is_archived', 0)->get();

        return view('corporateAdmin.pages.database.createExport')->with('teams', $teams)->with('corprationId', $corporationId)->with('capcodes', $capcodes);
    }

    public function createExportCSV(Request $request)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;

        $filePath = storage_path('app/public/previousExports/' . $corporation_id . '/customExport' .date("Y_m_d_G_i_s").'.csv');

        $accountTable = $request->account_type;
        $whereStatement = "CORPORATION_ID = ".$corporation_id;

        if(!empty($request->capcodes))
            $whereStatement = $whereStatement." AND CAPCODE IN (".implode(',', $request->capcodes).")";
        if(!empty($request->scores))
            $whereStatement = $whereStatement." AND POESCORE IN (".implode(',', $request->scores).")";
        if(!empty($request->tier))
            $whereStatement = $whereStatement." AND TIER >= ".$request->tier;
        if(!empty($request->due_date))
            $whereStatement = $whereStatement." AND DATE(ACCT_DUE_DATE) >= '".$request->due_date."'";
        if($request->grab_held == 'grab_active')
            $whereStatement = $whereStatement." AND ON_HOLD = 0";
        elseif($request->grab_held == 'grab_held')
            $whereStatement = $whereStatement." AND ON_HOLD = 1";

        if(!empty($request->teams)){
            $whereStatement = $whereStatement." AND (";
            if(in_array(0, $request->teams)) //0 is the given number for team id is null on frontend
                $whereStatement = $whereStatement." TEAM_ID IS NULL OR";
            $whereStatement = $whereStatement." TEAM_ID IN (".implode(',', $request->teams).") )";
        }
        
        $accounts = DB::select(DB::raw(
            "SELECT 
            ACCT_CLIENT,
            ACCT_CASE,
            ACCT_SSN,
            ACCT_FIRST_NAME,
            ACCT_LAST_NAME,
            ACCT_AD1,
            ACCT_AD2,
            ACCT_CITY,
            ACCT_ST,
            ACCT_ZIP,
            ACCT_DOB,
            ACCT_ID,
            EMPL_NAME,
            EMPL_ADDR1,
            EMPL_ADDR2,
            EMPL_CITY,
            EMPL_ST,
            EMPL_ZIP,
            EMPL_PHONE1_NMBR
            FROM $accountTable
            where $whereStatement;"
        ));

        if (file_exists($filePath)) 
            unlink($filePath);
        if (!file_exists(storage_path('app/public/previousExports/' . $corporation_id))) {
            mkdir(storage_path('app/public/previousExports/' . $corporation_id), 0777, true);
        }
            
        $file = fopen($filePath, 'w+');
        $headerString = 'ACCT_CLIENT,ACCT_CASE,ACCT_SSN,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,ACCT_DOB,ACCT_ID,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR';
        fwrite($file, $headerString);

        foreach ($accounts as $account) {     
            $rowString = "\r\n";
            foreach( $account as $value ){
                $rowString = $rowString.str_replace(array("\n", "\r", ","), '', $value).',';
            }
            //may need to remove last comma?
            fwrite($file, $rowString);
        }

        if(in_array($request->hold_after, ['hold', 'pinpooint'])){
            if($request->hold_after == 'hold')
                $setStatement = 'ON_HOLD = 1';
            else
                $setStatement = 'ON_HOLD = 1, PINPOINT = 1';

            $accounts = DB::select(DB::raw(
                "UPDATE $accountTable SET $setStatement
                where $whereStatement;"
            ));
        }

        $prevExport = new Previous_Export();
        $prevExport->number_of_records = count($accounts);
        $prevExport->exported_by = Auth::user()->user_id;
        $prevExport->corporation_id = $corporation_id;
        $prevExport->file_name = 'customExport'.date("Y_m_d_G:i:s").'.csv';
        $prevExport->date_exported = date("Y-m-d G:i:s");
        $prevExport->save();

        return response()->download($filePath, null, [
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
        ]);
    }
}