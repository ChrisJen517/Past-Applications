<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Corporation;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use DB;
use DateTime;
use App\Models\User_Mapping;
use Config;
use PDO;
use App\Models\Access_Levels;
use App\Models\Team;
use App\User;
use App\Users_Test;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use PHPMailer\PHPMailer\PHPMailer;
use Storage;
use File;
use Schema;
use App\Jobs\AccountUploadAccountQueue;

class UploadAccountsController extends Controller
{
    public function uploadCsvOfAgents(request $request){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 

        $date = date("Y-m-d H:i:s");
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $user_mapping = User_Mapping::where('corporation_id', $corporation_id)->first();
        $user_mapping_mapping_columns = Schema::getColumnListing('users_mapping');
        // Setting Table_Name Based on corporation name to be dynamic
        $corporation_name = Auth::User()->corporation_corporate_admin_link->name;
        $corporation_name_regex = preg_replace("/[^A-Za-z]/", '', $corporation_name);
        $letter = chr(rand(65,90));
        $table_name = $corporation_name_regex."CAD".$letter;

        // Assigning DB values   
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');

        // Setting up reading file that is uploaded
        $file = new \SplFileObject($request->uploadAgents);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;

        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {   
            if($rows == 0){
                foreach($row as $header)
                {   
                    $headers[] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $header);
                }
            }
            $rows++;
        }

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        $has_access_true = 0; 
        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $count = 0;
        $countHead = 0;
        $number_of_matched_columns = 0;
        $corp_drop_check = 0;
        $on_hold_drop_check = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
            if($head == $user_mapping->has_access){
                $has_access_true = 1;
            }
            if($countHead == 0){
                $insert_statement_temp_table = "`".$head."` VARCHAR( 90 ) ";
            }
            else{
                $insert_statement_temp_table = $insert_statement_temp_table.", `".$head."` VARCHAR( 90 ) ";
            }
            $countHead++;
            
            if(strtolower($head) == 'corporation_id'){
                $corp_drop_check = 1;
            }
            else{
                foreach($user_mapping_mapping_columns as $column){
                    if($user_mapping->$column == $head){
                        if($count == 0){
                            $insert_statement = $column;
                            $insert_statement_CSV = "`$table_name`.`".$head."`";
                            $number_of_matched_columns++;
                            $count++;
                        }
                        else{
                            $insert_statement = $insert_statement.", ".$column;
                            $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$head."`";
                            $number_of_matched_columns++;
                        }
                    }
                }
            }
        }
        $insert_statement = $insert_statement.", corporation_id";
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`corporation_id`";

        // Checking if # of Database mapped columns are all on the CSV File
        $expected_col_number = 0;
        foreach($user_mapping_mapping_columns as $column){
            if($user_mapping->$column != null){
                $expected_col_number++;
            }
        }

        $expected_col_number = $expected_col_number - 4;
        if($expected_col_number != $number_of_matched_columns){
            return redirect()->back()->with('error', 'More columns mapped than found on CSV, check database mapping.');
        }    
        // Dropping table if one previously existed
        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
        
        // Creating a temp table to upload CSV file
        $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));
        
        // Creating connection to database allowing whole file to be uploaded
        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
            PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));

        // Writing query to load file
        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES", addslashes($request->uploadAgents));
        // executing query on database 
        $conn->exec($query);
        
        // Checking to see if any repeat emails are used on CSV
        $email_checks_on_csv = DB::SELECT( DB::RAW(" SELECT ".$user_mapping->email." AS 'email_check', COUNT(1) as email_count FROM `$table_name` GROUP BY ".$user_mapping->email." having email_count > 1;"));
        $count_of_email_check_csv = count($email_checks_on_csv);
        if($count_of_email_check_csv > 0){
            $bad_emails_message = '';
            foreach($email_checks_on_csv as $email_check_on_csv){
                $bad_emails_message = $bad_emails_message." ".$email_check_on_csv->email_check.",";
            }
            $bad_emails_message = substr_replace($bad_emails_message, "", -1);
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            return redirect()->back()->with('error', "Multiple of the same email used on CSV. These emails are used multiple times on CSV ".$bad_emails_message.".");
        }
        // Checking to see if any repeat emails are used in Users Table
        $email_checks = DB::SELECT( DB::RAW("SELECT (SELECT email FROM users WHERE users.email = `$table_name`.`".$user_mapping->email."`) AS 'email_check' FROM `$table_name`;"));
        $email_checks = collect($email_checks);
        $email_checks = $email_checks->where('email_check', '!=', null);
        $count_of_email_check = count($email_checks);
        if($count_of_email_check > 0){
            $bad_emails_message = '';
            foreach($email_checks as $email_check){
                $bad_emails_message = $bad_emails_message." ".$email_check->email_check.",";
            }
            $bad_emails_message = substr_replace($bad_emails_message, "", -1);
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            return redirect()->back()->with('error', "Must use emails that don't already have accounts. These emails are already in use ".$bad_emails_message.".");

        }
        // Adding the column corporation_id
        if($corp_drop_check == 1){
            DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP corporation_id'));
            DB::select( DB::raw("ALTER TABLE `$table_name` 
            ADD COLUMN `corporation_id` BIGINT(20) NOT NULL DEFAULT $corporation_id AFTER `$head`;
            "));
            $head = "corporation_id";
        }
        else{
            DB::select( DB::raw("ALTER TABLE `$table_name` 
            ADD COLUMN `corporation_id` BIGINT(20) NOT NULL DEFAULT $corporation_id AFTER `$head`;
            "));
            $head = "corporation_id";    
        }

        // Checking to see if any role set is not Agent or Manager
        $role_checks = DB::select( DB::raw("SELECT DISTINCT * FROM `$table_name` WHERE `".$user_mapping->role."` != 'manager' AND `".$user_mapping->role."` != 'agent'"));
        $count_of_role_check = count($role_checks);
        // If a bad role is set return back which are bad
        if($count_of_role_check > 0){
            $bad_roles_message = '';
            foreach($role_checks as $role_check){
                $bad_roles_message = $bad_roles_message." ".$role_check->role.",";
            }
            $bad_roles_message = substr_replace($bad_roles_message, "", -1);
            
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            return redirect()->back()->with('error', "Must use roles of manager or agent only. These roles can't be used ".$bad_roles_message.".");
        }
        
        // Making all team names and roles lowercase
        DB::select( DB::raw("UPDATE `$table_name` SET `$user_mapping->team_name` = LOWER(`$user_mapping->team_name`);"));
        DB::select( DB::raw("UPDATE `$table_name` SET `$user_mapping->role` = LOWER(`$user_mapping->role`);"));

        if($has_access_true == 1){
            //Remove extra spacing on shortcodes 
            DB::select( DB::raw("UPDATE `$table_name` SET `$user_mapping->has_access` = REPLACE(`$user_mapping->has_access`, ' ', '');"));
            //Grabbing Access Levels for corporation
            $access_levels = Access_Levels::where('corporation_id', $corporation_id)->get();
            $rules = DB::select( DB::raw("SELECT DISTINCT `$user_mapping->has_access` AS RULES FROM `$table_name` WHERE `$user_mapping->has_access` != '';"));
            // Swapping shortcodes with the ID
            foreach($rules as $rule){
                $has_access_update_string = '';
                $has_access_update_arrays = [];
                $count_has_access_start  = 0;
                $arrays = explode(',',$rule->RULES);
                if($arrays[0] == ''){
                    array_shift($arrays); 
                }
                
                foreach($arrays as $array){
                    $access_id = $access_levels->where('shortcode', $array)->first();
                    // If shortcode doesn't exist in the database return back, stating which shortcode it is
                    if($access_id == null){
                        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
                        return redirect()->back()->with('error', "Must use Shortcodes of Access Levels that are created in Access Levels. This Access Level doesn't exist ".$array.".");
                    } 
                    $has_access_update_arrays[] = $access_id->id;
                }       
                sort($has_access_update_arrays); 
                foreach($has_access_update_arrays as $has_access_update_array){
                    if($count_has_access_start == 0){
                        $has_access_update_string = "".$has_access_update_array;
                    }else{
                        $has_access_update_string = $has_access_update_string.",".$has_access_update_array;
                    }       
                    $count_has_access_start++;
                }
                DB::select( DB::raw("UPDATE `$table_name` SET `$user_mapping->has_access` = '".$has_access_update_string."' WHERE `$user_mapping->has_access` = '".$rule->RULES."'"));
            }
        }

        //Grabbing Teams for corporation
        $teams = Team::where('corporation_id', $corporation_id)->get();
        foreach($teams as $team){
            $team->name = strtolower($team->name);
        }
        $teams_csv = DB::select( DB::raw("SELECT DISTINCT `$user_mapping->team_name` AS team_name FROM `$table_name`"));
        
        // Swapping Team Names with IDs
        foreach($teams_csv as $team_csv){  
            $team_names_update_string = '';
            $team_id = $teams->where('name', $team_csv->team_name)->first();
            // If team name doesn't exist in the database return back, stating which team name it is
            if($team_id == null){
                $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
                return redirect()->back()->with('error', "Must use Team Names of Teams that currently exist as a Team. This Team Name doesn't exist ".$team_csv->team_name.".");
            }
            $team_names_update_string = $team_id->team_id; 
            DB::select( DB::raw("UPDATE `$table_name` SET `$user_mapping->team_name` = '".$team_names_update_string."' WHERE `$user_mapping->team_name` = '".$team_csv->team_name."'"));
        }

        DB::select( DB::raw("INSERT IGNORE INTO staging_accounts_upload 
                    ($insert_statement)
                    SELECT 
                $insert_statement_CSV
                FROM `$table_name`"));

        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));

        // Call Stored Procedure of moving accounts to users table and creating agent/manager links
        DB::select( DB::raw("Call user_upload_procedure('".$date."',".$corporation_id.");"));
        
        $this->dispatch(new AccountUploadAccountQueue());
        
        return redirect()->back()->with('success', 'Accounts Uploaded Successfully. It will take a few minutes to process them.');
    }

    public function csvAgentMapping(){
      
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $UM = User_Mapping::where('corporation_id', $corporation_id)->first();
        return view('corporateAdmin.pages.database.usersMapping')->with('UM', $UM);
    }

    public function setAgentMapping(request $request){
        $this->validate($request, [
            'email' => 'required|max:90',
            'role' => 'required|max:90',
            'first_name' => 'required|max:90',
            'last_name' => 'required|max:90',
            'phone_number' => 'required|max:90',
            'has_access' => 'max:45ks'
        ]);

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $UMCheck = User_Mapping::where('corporation_id', $corporation_id)->first();
        if ($UMCheck == null) {
            $UM = new User_Mapping;
            $UM->email = $request->email;
            $UM->role = $request->role;
            $UM->first_name = $request->first_name;
            $UM->last_name = $request->last_name;
            $UM->phone_number = $request->phone_number;
            $UM->has_access = $request->has_access;
            $UM->corporation_id = $corporation_id;
            $UM->team_name = $request->team_name;
            $UM->Save();

            return redirect()->back()->with('message', 'Mapping Added!');
        } else {
            $UMCheck->email = $request->email;
            $UMCheck->role = $request->role;
            $UMCheck->first_name = $request->first_name;
            $UMCheck->last_name = $request->last_name;
            $UMCheck->phone_number = $request->phone_number;
            $UMCheck->has_access = $request->has_access;
            $UMCheck->corporation_id = $corporation_id;
            $UMCheck->team_name = $request->team_name;
            $UMCheck->save();
            return redirect()->back()->with('message', 'Mapping Updated');
        }
    }

    public function checkCSVAccountsMapping(request $request)
    {

        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $user_mapping = User_Mapping::where('corporation_id', $corporation_id)->first();
        $user_mapping_mapping_columns = Schema::getColumnListing('users_mapping');

        $file = new \SplFileObject($request->testMappingFile);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];

        // Grabbing names of the columns in the CSV file
        foreach ($file as $row) {
            foreach ($row as $header) {
                $headers[] = preg_replace('/[\x00-\x1F\x80-\xFF]/', '', $header);
            }
            break;
        }

        $count = 0;
        $countHead = 0;
        $number_of_matched_columns = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach ($headers as $head) {
            foreach ($user_mapping_mapping_columns as $column) {
                if ($user_mapping->$column == $head) {
                    if ($count == 0) {
                        $number_of_matched_columns++;
                        $count++;
                    } else {

                        $number_of_matched_columns++;
                    }
                }
            }
        }

        // Checking if # of Database mapped columns are all on the CSV File
        $expected_col_number = 0;
        foreach ($user_mapping_mapping_columns as $column) {
            if ($user_mapping->$column != null) {
                $expected_col_number++;
            }
        }
        $expected_col_number = $expected_col_number - 4;
        if ($expected_col_number != $number_of_matched_columns) {
            return redirect()->back()->with('error', 'More columns mapped than found on CSV, check database mapping.');
        } else {
            return redirect()->back()->with('message', 'Successfully Mapped CSV File Headers.');
        }

    }
}