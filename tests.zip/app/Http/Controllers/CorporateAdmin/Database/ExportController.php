<?php

namespace App\Http\Controllers\CorporateAdmin\Database;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Models\Corporate_Admin;
use App\ExportQueue;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Previous_Export;
use Auth;
use DateTime;
use DB;
use Excel;
use Maatwebsite\Excel\Concerns\ToArray;
use Storage;
use App\Models\Corporate_Settings;

class ExportController extends Controller
{
    public function agentQueue($id)
    {
        $accessList = [];
        if (!empty(Auth::user()->has_access)) {
            $user_access = DB::Select(DB::Raw('Select shortcode from access_levels where id in(' . Auth::user()->has_access . ')'));

            foreach ($user_access as $access) {
                $accessList[] = strtoupper($access->shortcode);
            }
        }
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $capcodes = Capcode::select('id', 'capcode')->where('corporation_id', $corporation_id)->get();
       
        $accounts = Active_Account::select('ID','ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
            'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
            'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR',
            'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE',
            'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER', 'ACCESS_RULES')
            ->where('ACCT_AGENT', $id)
            ->get();
        $filteredAccounts = [];
        foreach($accounts as $account){
            if($account->ACCESS_RULES != null || $account->ACCESS_RULES != "")
            {
                $rule = explode(',', $account->ACCESS_RULES);
                foreach($rule as $r){
                    if(!in_array(strtoupper($r), $accessList))
                    {
                        continue;
                    }else{
                        $filteredAccounts[$account->ID] = $account;
                    }
                }
            }else{
                $filteredAccounts[$account->ID] = $account;
            }

            $account->CAPCODE = $capcodes->where('id', $account->CAPCODE)->first()->capcode ?? $account->CAPCODE;
        }
        
        
        return $filteredAccounts;
    }

    public function exportQueue($id)
    {
        if(in_array($id, [1901, 1902, 1904])){
            $corporation_id = 2;
        }
        else{
            $agent = Agent::findOrFail($id);
            $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
            if($agent->corporation_id != $corporation_id){
                return redirect()->back()->with('error', 'Access Denied');
            }
        }
        $export = new ExportQueue($this->agentQueue($id));
        $file = 'Agent_Queue' . '-' . $corporation_id . '.xlsx';
        return Excel::download($export, $file);
    }

    public function showPreviousExports()
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $exports = '';
        $exist = 'previousExports/' . $corporation_id;

        if(in_array($exist, Storage::directories('previousExports'))){
            $exports = scandir(storage_path('app/public/previousExports/' . $corporation_id));
            unset($exports[0]);
            unset($exports[1]);
        }
        return view('corporateAdmin/pages/database/previousExports')->with('exports', $exports)->with('corporation_id', $corporation_id);
    }

    public function exportInactive()
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);
        $corporate_setting = Corporate_Settings::where('corporation_id', $corporation_id)->first(); 
        $export_setting = explode(',',$corporate_setting->capcode_export);
        $accounts = Inactive_Account::select('ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
            'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
            'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR',
            'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE',
            'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER')
            ->where('CORPORATION_ID', $corporation_id)->where('EXPORTED', 0)
            ->when($export_setting, function ($query, $export_setting) {
                return $query->WhereIn('capcode', $export_setting);
            })->get();

        if (empty($accounts[0])) {
            return back()->with('error', 'No inactive accounts to export');
        }

        $accounts = $accounts->ToArray();
        DB::update("UPDATE inactive_accounts SET EXPORTED = 1 where CORPORATION_ID = $corporation_id AND EXPORTED = 0");
        $export = new ExportQueue($accounts);
        $dateTime = new DateTime();
        $timeStamp = $dateTime->getTimestamp();
        $date = date('m-d-Y');
        $file_name = 'Export' . '-' . $timeStamp . '-' . $date . '.csv';
        $file = 'previousExports/'.$corporation_id.'/'. $file_name;
        Excel::store($export, $file);

        $prevExport = new Previous_Export();
        $prevExport->number_of_records = count($accounts);
        $prevExport->exported_by = Auth::user()->user_id;
        $prevExport->corporation_id = $corporation_id;
        $prevExport->file_name = $file_name;
        $prevExport->date_exported = date("Y-m-d G:i:s", $timeStamp);
        $prevExport->save();

        return back()->with('success', 'Exported');

    }

    public function download($file)
    {
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        return response()->download(storage_path('app/public/previousExports/' . $corporation_id . '/' . $file));

    }
}
