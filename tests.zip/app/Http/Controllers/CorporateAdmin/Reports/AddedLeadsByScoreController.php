<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Team;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use App\Models\Inactive_Account;
use App\Models\Active_Account;
use Symfony\Component\HttpFoundation\Request;
use Illuminate\Support\Facades\DB;

class AddedLeadsByScoreController extends Controller
{
    public function showScoresAdded(Request $request){
        $teamId = $request->teamId ?? null;
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->get();

        $scores = $this->getData($corporation_id, $teamId);

        $teamName = $teams->where('team_id', $teamId)->first()->name ??  'All Teams';

        return view('corporateAdmin.pages.reports.addedLeadsByScore')->with('scores', $scores)->with('teamName', $teamName)->with('teams', $teams);
    }

    public function getData($corporation_id, $teamId){
        for($i = 0; $i <= 30; $i++) 
            $dates[] = date('Y-m-d', strtotime('-'. $i .' days'));

        $activeCounts = Active_Account::selectRaw('count(ID) as totalLeads, POESCORE, date(ADD_DATE)')
            ->whereRaw("ADD_DATE >= ".$dates[30])->where('corporation_id', $corporation_id)
            ->when($teamId, function ($query) use ($teamId){
                return $query->where('TEAM_ID', $teamId);
            })->groupBy('POESCORE')->groupBy('date(ADD_DATE)')->get();

        $inactiveCounts = Inactive_Account::selectRaw('count(ID) as totalLeads, POESCORE, date(ADD_DATE)')
            ->whereRaw("ADD_DATE >= ".$dates[30])->where('corporation_id', $corporation_id)
            ->when($teamId, function ($query) use ($teamId){
                return $query->where('TEAM_ID', $teamId);
            })->groupBy('POESCORE')->groupBy('date(ADD_DATE)')->get();
        
        $finalData = [];
        foreach($dates as $date){
            $activeDate = $activeCounts->where('date(ADD_DATE)', $date);
            $inactiveDate = $inactiveCounts->where('date(ADD_DATE)', $date);

            $total = 0;
            $byScore = [];
            for($i = 1; $i <= 10; $i++){
                $activeScore = $activeDate->where('POESCORE', $i)->first()->totalLeads ?? 0;
                $inactiveScore = $inactiveDate->where('POESCORE', $i)->first()->totalLeads ?? 0;
                $byScore[$i] = $activeScore + $inactiveScore;
                $total += $byScore[$i];
            }

            $finalData[$date] =[
                'total' => $total,
                'byScore' => $byScore,
                ];
        }

        return $finalData;
    }
}