<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Capcode;
use Illuminate\Http\Request;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Team;
use App\Traits\DateUtils;
use App\Models\Worked_History;
use Carbon\Carbon;
use DateTime;
use DB;

class SDRReportController extends Controller
{
    use DateUtils;

    public function showSDR(Request $request){
        if($request->from == null)
            $startTime = date("Y-m-d", strtotime("-1 week"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $endTime = date("Y-m-d");
        else
            $endTime = date('Y-m-d', strtotime($request->to));

        $message = "from ".$startTime." to ".$endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));
        $finalData = $this->getData( $startTime, $endTime);

        $teams = Team::where('corporation_id', Auth::user()->corporate_admin_link->corporation_id)->where('created_at', '<', $endTime)
        ->where(function($q) use ($startTime){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($startTime) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $startTime );}); })
        ->select('team_id', 'name')->get();

        return view('corporateAdmin.pages.reports.SDR')->with('agents', $finalData)->with('timeMessage', $message)->with('teams', $teams);
    }

    public function getData($from, $to){
        $corpAdmin = Auth::user()->corporate_admin_link;
        $agents = Agent::where('corporation_id', $corpAdmin->corporation_id)->where('created_at', '<', $to)->with('user_link')->select('agent_id','user_id', 'team_id')->get();
        $capcodes = Capcode::where('corporation_id', $corpAdmin->corporation_id)->where(function($q){
            $q->where('type', 'verified')->orWhere('capcode', 2210);})->select('id', 'capcode', 'type')->get();

        //if there are no agents returns an empty array
        if($agents->first() == null)
            return [];

        //gets the ids of the verified capcodes
        $verified = [];
        $verifiedCapcodes = $capcodes->where('type', 'verified');
        foreach($verifiedCapcodes as $capcode){
            $verified[] = $capcode->id;
        }
        $callCapcode = $capcodes->where('capcode', 2210)->first()->id;

        //sets up the final array
        $finalData = [];
        $agentIds = [];
        $userIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $finalData[$agent->agent_id] = [
                'agentId' => $agent->agent_id,
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'team_id' => $agent->team_id,
                'totalCalls' => 0,
                'totalWorked' => 0,
                'averageWork' => 0,
                'totalVerified' => 0,
                'daysWorked' => 0,
                'hoursWorked' => 0,
                'score1' => 0,
                'score2' => 0,
                'score3' => 0,
                'score4' => 0,
                'score5' => 0,
                'score6' => 0,
                'score7' => 0,
                'score8' => 0,
                'score9' => 0,
                'score10' => 0,
            ];

            $agentIds[] = $agent->agent_id;
            $userIds[] = $agent->user_link->user_id;

        }

        
        //gets all the agents accounts
        $active = Active_Account::select(DB::RAW('ACCT_AGENT, count(ID) as total'))
        ->whereIn('ACCT_AGENT', $agentIds)->whereDate('LAST_WORKED', '>=', $from)->whereDate('LAST_WORKED', '<=', $to)
        ->groupby('ACCT_AGENT')->get();

        $closed = Inactive_Account::select(DB::RAW('ACCT_AGENT, count(ID) as total'))
        ->whereIn('ACCT_AGENT', $agentIds)->whereDate('LAST_WORKED', '>=', $from)->whereDate('LAST_WORKED', '<=', $to)
        ->groupby('ACCT_AGENT')->get();

        $selectScores = "";
        for($i = 1; $i < 11; $i++){
            $selectScores = $selectScores."COUNT(IF(POESCORE = $i, 1, NULL)) as verified".$i.", ";
        }
        $verifieds = Inactive_Account::select(DB::RAW('ACCT_AGENT, '.$selectScores.' count(ID) as verifiedTotal, sum(WORK_ATTEMPTS) as work_count'))
        ->whereIn('CAPCODE', $verified)
        ->whereIn('ACCT_AGENT', $agentIds)->whereDate('LAST_WORKED', '>=', $from)->whereDate('LAST_WORKED', '<=', $to)
        ->groupby('ACCT_AGENT')->get();

        //if there are any accounts goes through and fills the array
        if(($active->first() != null) || ($closed->first() != null)){
            //lists all accounts to get the work history
            $callCounts = Worked_History::select(DB::RAW("agent_id, 
            COUNT(DISTINCT CONCAT(agent_id, '||', notes,
            '||', active_account_id, '||', MONTH(CREATED_AT),
            '-', DAY(CREATED_AT), '-', YEAR(CREATED_AT),
            '-', HOUR(CREATED_AT))) as calls"))
            ->where('created_at', '>', $from)->where('created_at', '<', $to)
            ->where('user_role', 'agent')->wherein('agent_id', $agentIds)->where('capcode', $callCapcode)
            ->groupby('agent_id')->get();

            foreach($agents as $agent){
                if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                    continue;

                $workedActive = $active->where('ACCT_AGENT', $agent->agent_id)->first()->total ?? 0;
                $workedClosed = $closed->where('ACCT_AGENT', $agent->agent_id)->first()->total ?? 0;
                $finalData[$agent->agent_id]['totalWorked'] = $workedActive + $workedClosed;

                $agentClosed = $verifieds->where('ACCT_AGENT', $agent->agent_id)->first();
                if(!empty($agentClosed) && !empty($agentClosed->verifiedTotal))
                    $finalData[$agent->agent_id]['averageWork'] = $agentClosed->work_count / $agentClosed->verifiedTotal;
                else
                    $finalData[$agent->agent_id]['averageWork'] = 0;

                $finalData[$agent->agent_id]['totalCalls'] = $callCounts->where('agent_id', $agent->agent_id)->first()->calls ?? 0;
                $finalData[$agent->agent_id]['totalVerified'] = $agentClosed->verifiedTotal ?? 0;
                $finalData[$agent->agent_id]['score1'] = $agentClosed->verified1 ?? 0;
                $finalData[$agent->agent_id]['score2'] = $agentClosed->verified2 ?? 0;
                $finalData[$agent->agent_id]['score3'] = $agentClosed->verified3 ?? 0;
                $finalData[$agent->agent_id]['score4'] = $agentClosed->verified4 ?? 0;
                $finalData[$agent->agent_id]['score5'] = $agentClosed->verified5 ?? 0;
                $finalData[$agent->agent_id]['score6'] = $agentClosed->verified6 ?? 0;
                $finalData[$agent->agent_id]['score7'] = $agentClosed->verified7 ?? 0;
                $finalData[$agent->agent_id]['score8'] = $agentClosed->verified8 ?? 0;
                $finalData[$agent->agent_id]['score9'] = $agentClosed->verified9 ?? 0;
                $finalData[$agent->agent_id]['score10'] = $agentClosed->verified10 ?? 0;

            }
        }

        //gets all of the log ins commented out due to activity log being removed
        // $activity = Activity_Log::whereIn('user_id', $userIds)->where('UPDATED_AT', '>', $from)->where('UPDATED_AT', '<', $to)->get();

        // //gets the time spent working per agent
        // foreach($agents as $agent){
        //     if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
        //         continue;

        //     $totalLogins = $activity->where('user_id', $agent->user_link->user_id);


        //     $hours = 0;
        //     $minutes = 0;
        //     $seconds = 0;
        //     foreach($totalLogins as $login){
        //         if($login->total_time != null){
        //             $hours = $hours + intval(date('H', strtotime($login->total_time)));
        //             $minutes = $minutes + intval(date('i', strtotime($login->total_time)));
        //             $seconds = $seconds + intval(date('s', strtotime($login->total_time)));
        //         }
        //     }
        //     $minutes = $minutes + ($seconds/60);
        //     $hours =  $hours + ($minutes/60);

        //     $finalData[$agent->agent_id]['daysWorked'] = count($totalLogins->groupby('date'));
        //     $finalData[$agent->agent_id]['hoursWorked'] = (int) $hours;

        // }

        $daysWorked = $this->getWorkingDays($from, $to);
        $daysWorked--;

        if(date("Y-m-d", strtotime($to." -1 day")) == date("Y-m-d")){
            $hoursWorked = $daysWorked * 8;

            $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
            $hoursSinceStart = $minutesSinceStart/60;
            if ($hoursSinceStart > 8 || $hoursSinceStart < 0)
                $hoursSinceStart = 8;

            $hoursWorked += $hoursSinceStart;
        }
        else{
            $hoursWorked = $daysWorked * 8;
        }

        $hoursWorked = round($hoursWorked, 2);

        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $from) && ($agent->user_link->is_deactivated == 1))
                continue;

            $finalData[$agent->agent_id]['daysWorked'] = $daysWorked;
            $finalData[$agent->agent_id]['hoursWorked'] = $hoursWorked;
        }

        return $finalData;
    }
}
