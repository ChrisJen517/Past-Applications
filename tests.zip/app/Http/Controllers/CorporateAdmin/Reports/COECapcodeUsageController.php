<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Capcode;
use App\Models\Team;
use Auth;
use App\Models\Active_Account;
use App\Models\Inactive_Account;


class COECapcodeUsageController extends Controller
{
    public function showCapcodeUsage()
    {
        $start_date = date('Y-m-d', strtotime('today'));
        $end_date = date('Y-m-d', strtotime('today'));
        $timeMessage = "From today";

        $results = $this->getData($start_date, $end_date);
        $teamTotalCounts = $results[0];
        $teamCapcodeUsage = $results[1];

        return view('corporateAdmin.pages.reports.capcodeUsageByCOE')
        ->with('teamTotalCounts', $teamTotalCounts)->with('teamCapcodeUsage', $teamCapcodeUsage)
        ->with('timeMessage', $timeMessage);
    }

    public function getDatedCOECapcodes(Request $request)
    {
        if($request->from == null)
            $start_date = '"'.date("Y-m-d", strtotime("-1 week")).'"';
        else
            $start_date = '"'.date('Y-m-d', strtotime($request->from)).'"';

        if($request->to == null)
            $end_date = '"'.date('Y-m-d', strtotime('today')).'"';
        else
            $end_date = '"'.date('Y-m-d', strtotime($request->to)).'"';

        $timeMessage = "From ".$start_date." to ".$end_date;
        
        $results = $this->getData($start_date, $end_date);
        $teamTotalCounts = $results[0];
        $teamCapcodeUsage = $results[1];

        return view('corporateAdmin.pages.reports.capcodeUsageByCOE')
        ->with('teamTotalCounts', $teamTotalCounts)->with('teamCapcodeUsage', $teamCapcodeUsage)
        ->with('timeMessage', $timeMessage);
    }

    public function getData($start_date, $end_date){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->get();

        $allCapcodes = Capcode::select('capcode', 'id', 'type')->where('corporation_id', $corporation_id)->where('type', '!=', 'pending_approval')->get(); 

        $activeAccounts = Active_Account::selectRaw('team_id, capcode, count(*) as total')
        ->where('corporation_id', $corporation_id)
        ->whereRaw('LAST_WORKED >= date('.$start_date.') and LAST_WORKED <= DATE_ADD('.$end_date.', INTERVAL 1 DAY)')
        ->groupBy('team_id')->groupBy('capcode')->get();

        $inactiveAccounts = Inactive_Account::selectRaw('team_id, capcode, count(*) as total')
        ->where('corporation_id', $corporation_id)
        ->whereRaw('LAST_WORKED >= date('.$start_date.') and LAST_WORKED <= DATE_ADD('.$end_date.', INTERVAL 1 DAY)')
        ->groupBy('team_id')->groupBy('capcode')->get();

        $teamCapcodeUsage['inconclusive'] = [];
        $teamCapcodeUsage['verified'] = [];
        $teamCapcodeUsage['unverified'] = [];

        foreach ($teams as $team) {
            if(($team->deactivate_date < $start_date) && ($team->is_deactivated == 1)){
                continue;
            }

            $teamTotalCounts['inconclusive'][$team->team_id] = 0;
            $teamTotalCounts['verified'][$team->team_id] = 0;
            $teamTotalCounts['unverified'][$team->team_id] = 0;

            $teamActive = $activeAccounts->where('team_id', $team->team_id);
            foreach($teamActive as $account){
                $capcode = $allCapcodes->where('id', $account->capcode)->first();
                $type = $capcode->type ?? '';

                if($type != ''){
                    $teamTotalCounts[$type][$team->team_id] += $account->total;
                    $teamCapcodeUsage[$type][] = [
                        'capcode' => $capcode->capcode,
                        'total' => $account->total,
                        'team_id' => $team->team_id,
                        'name' => $team->name
                    ];
                }
            }

            $teamInactive = $inactiveAccounts->where('team_id', $team->team_id);
            foreach($teamInactive as $account){
                $capcode = $allCapcodes->where('id', $account->capcode)->first();
                $type = $capcode->type ?? '';

                if($type != ''){
                    $teamTotalCounts[$type][$team->team_id] += $account->total;
                    $teamCapcodeUsage[$type][] = [
                        'capcode' => $capcode->capcode,
                        'total' => $account->total,
                        'team_id' => $team->team_id,
                        'name' => $team->name
                    ];
                }
            }
        }

        $results[] = $teamTotalCounts;
        $results[] = $teamCapcodeUsage;
        return $results;
    }

}
