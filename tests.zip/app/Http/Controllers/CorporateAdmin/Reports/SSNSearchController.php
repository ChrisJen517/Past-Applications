<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use Illuminate\Http\Request;
use Auth;
use DB;
use App\Traits\HasAccess;
use App\Http\Controllers\Controller;
use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use App\Models\Corporate_Settings;
use App\Models\Worked_History;
use App\Models\Agent;

class SSNSearchController extends Controller
{
    function searchAccounts(Request $request){

        if(!$request->has('search'))
            return view('corporateAdmin.pages.ssnSearch');
            
    }
}