<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Inactive_Account;
use App\Models\Team;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;
use Auth;
use DateTime;
use Carbon\Carbon;

class AverageWorkController extends Controller
{
    public function averageWork(){
        $finalData = $this->getData(new DateTime('today'), new DateTime('tomorrow'));

        $message = "from today";

        return view('corporateAdmin.pages.reports.averageWork')->with('average', $finalData)->with('timeMessage', $message);
    }

    public function averageWorkTime(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', strtotime($request->from));
            $endTime = date('Y-m-d', strtotime($request->from.' +1 day'));
        }

        $finalData = $this->getData( $startTime, $endTime);
        $message = "from ".$startTime;

        return view('corporateAdmin.pages.reports.averageWork')->with('average', $finalData)->with('timeMessage', $message);
    }


    public function getData($day, $dayAfter){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $agents = Agent::where('corporation_id', $corporation_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();

        if($agents->first() == null)
            return $finalData = null;

        //gets all accounts
        $activeAccounts = Active_Account::where('corporation_id', $corporation_id)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->where('ACCT_AGENT', '!=', null)->select('ACCT_AGENT')->get();
        $inactiveAccounts = Inactive_Account::where('corporation_id', $corporation_id)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->where('ACCT_AGENT', '!=', null)->select('CAPCODE', 'ACCT_AGENT')->get();

        $teams = Team::where('corporation_id', $corporation_id)->where('created_at', '<', $dayAfter)->select('team_id', 'name', 'deactivate_date', 'is_deactivated')->get();
        $teamData = [];
        foreach($teams as $team){
            if(($team->deactivate_date < $day) && ($team->is_deactivated == 1))
                continue;

            $teamData[$team->team_id] =[
                'name' => $team->name,
                'id' => $team->team_id,
                'worked' => 0,
                'average' => 0,
            ];

            $teamIds[] = $team->team_id;
        }

        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            if (!in_array($agent->team_id, $teamIds))
                continue;

            $worked = count($activeAccounts->where('ACCT_AGENT', $agent->agent_id)) + count($inactiveAccounts->where('ACCT_AGENT', $agent->agent_id));

            $dayParsed = Carbon::parse($day);
            if ($dayParsed->isToday()) {
                $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
                $hoursSinceStart = $minutesSinceStart/60;
                if ($hoursSinceStart > 8 || $hoursSinceStart < 0)
                    $hoursSinceStart = 8;
            } else
                $hoursSinceStart = 8;

            $average = $worked / $hoursSinceStart;


            $agentData[$agent->agent_id] =[
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'id' => $agent->agent_id,
                'teamName' => $teamData[$agent->team_id]['name'],
                'worked' => $worked,
                'average' => $average,
            ];

            $teamData[$agent->team_id]['worked'] += $worked;
            $teamData[$agent->team_id]['average'] += $average;

        }

        //removes teams that dont exist durring timeframe
        foreach($teams as $team){
            if((($team->deactivate_date < $day) && ($team->is_deactivated == 1)) || ($team->created_at > $dayAfter))
                unset($teamData[$team->team_id]);
        }

        $finalData[] = $agentData;
        $finalData[] = $teamData;

        return $finalData;
    }
}
