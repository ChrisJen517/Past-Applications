<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;

class ScoreReportController extends Controller
{
    /**
     * Gather the data and show the score report view.
     */
    public function showScoreReport() {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $latestDueDate = Carbon::now()->addWeeks(2)->format("Y-m-d");

        $data = Active_Account::selectRaw("teams.team_id AS team, teams.name, POESCORE, DATE(active_accounts.ACCT_DUE_DATE) as due_date,
        COUNT(IF(ON_HOLD = 0, 1, NULL)) AS Total_Active,
        COUNT(IF(ON_HOLD = 0 and LAST_WORKED IS NOT NULL AND LAST_WORKED != '' AND ACCT_AGENT is not NULL and ACCT_AGENT != '', 1, NULL)) AS Working_On,
        COUNT(IF(ON_HOLD = 0 and (ACCT_AGENT is NULL or ACCT_AGENT = ''), 1, NULL)) AS In_Queue,
        COUNT(IF(ON_HOLD = 0 and (LAST_WORKED IS NULL OR LAST_WORKED = '') AND ACCT_AGENT is not NULL and ACCT_AGENT != '', 1, NULL)) AS Never_Worked")
        ->leftJoin("teams", "teams.team_id", "=", "active_accounts.team_id")
        ->whereRaw("DATE(active_accounts.ACCT_DUE_DATE) <= '$latestDueDate' and teams.is_deactivated = 0 and teams.corporation_id = $corporation_id");

        $groupedByScore = $data->groupBy("POESCORE", "teams.team_id")->orderBy("POESCORE", "desc")->get();
        $groupedByDueDate = $data->groupBy("POESCORE", "due_date", "teams.team_id")->orderBy("due_date", "asc")->get();

        $teams = array_unique($groupedByDueDate->pluck("name")->toArray());

        return view('corporateAdmin.pages.reports.scoreReport')->with(compact("groupedByScore", "groupedByDueDate", "teams", "latestDueDate"));
    }

    public function tossToQueue($score, $name, $id, $due_date = null) {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $accountsUpdated = Active_Account::where('TEAM_ID', $id)->where('CORPORATION_ID', $corporation_id)->where('TEAM_NAME', $name)
        ->where('POESCORE', $score)->whereNotNull('ACCT_AGENT')->whereNull('LAST_WORKED')->where('ON_HOLD', 0)
        ->when(!empty($due_date), function ($query) use ($due_date) {
            return $query->whereRaw("DATE(ACCT_DUE_DATE) = '$due_date'");
        })->update(['ACCT_AGENT' => null]);

        return redirect()->back()->with("success", "$accountsUpdated accounts were successfully tossed to the queue!");
    }
}
