<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Inactive_Account;
use App\Models\Capcode;
use App\Models\Agent;
use App\Models\Team;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use DB;

class DailyBudgetPerformanceController extends Controller
{
    public function agentAtTime(Request $request){

        if($request->day == null){
            $time = date("Y-m-d");
            $message = "from today";
        }
        else{
            $time = date('Y-m-d', strtotime($request->day));
            $message = "from ".$time;
        }

        $data = $this->getAgentData($time);
        $array = array();

        $highestValue = 0;

        foreach($data as $item)
        {
            if($item['verified'] > $highestValue)
                $highestValue = $item['verified'];

            $array[$item['team_name']][] = array(
                $item['agent_name'],
                $item['verified'],
                $item['verified'],
                $item['daily_goal'],
                $item['daily_goal'],
            );
        }

        return view('corporateAdmin.pages.reports.dailyBudgetPerformanceAgent')->with('teams', $array)->with('highestValue', $highestValue)->with('timeMessage', $message);
    }


    public function getAgentData($time){
        $day_after = date('Y-m-d', strtotime($time.' + 1 day'));
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'verified')->get();
        $agents = Agent::where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', $day_after)->get();
        $teams = Team::where("corporation_id", $corporation_id)->get();

        $verifiedCapcodes = [];
        foreach($capcodes as $capcode){
            $verifiedCapcodes[] = $capcode->id;
        }

        $activeAgents = [];
        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $time) && ($agent->user_link->is_deactivated == 1))
                continue;
            $activeAgents[] = $agent->agent_id;
        }

        $verified_accounts = Inactive_Account::select('ACCT_AGENT')->whereIn('ACCT_AGENT', $activeAgents)->whereIn('CAPCODE', $verifiedCapcodes)
            ->where('LAST_WORKED', '>', $time)->where('LAST_WORKED', '<', $day_after)->get();

        $finalData = [];
        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $time) && ($agent->user_link->is_deactivated == 1))
                continue;

            $agent_verified_count = count($verified_accounts->where('ACCT_AGENT', $agent->agent_id));

            $finalData[] =[
                'agent_name' => $agent->user_link->first_name." ".$agent->user_link->last_name,
                'verified' => $agent_verified_count,
                'daily_goal' => $teams->where('team_id', $agent->team_id)->first()->team_goals,
                'team_name' => str_replace(" ", "_", $teams->where('team_id', $agent->team_id)->first()->name),
            ];
        }

        return $finalData;
    }

    public function teamAtTime(Request $request){

        if($request->day == null){
            $time = date("Y-m-d");
            $message = "from today";
        }
        else{
            $time = date('Y-m-d', strtotime($request->day));
            $message = "from ".$time;
        }

        $data = $this->getTeamData($time);
        $highestValue = 0;
        $array = [];
        foreach($data as $item)
        {
            if($item['verified'] > $highestValue)
                $highestValue = $item['verified'];

            $array[] = array(
                $item['team_name'],
                $item['verified'],
                $item['verified'],
                $item['team_goal'],
                $item['team_goal']
            );
        }

        return view('corporateAdmin.pages.reports.dailyBudgetPerformanceTeam')->with('array', $array)->with('timeMessage', $message)->with('highestValue', $highestValue);
    }


    public function getTeamData($time){
        $day_after = date('Y-m-d', strtotime($time.' + 1 day'));
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $agents = Agent::where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', $day_after)->get();
        $teams = Team::where("corporation_id", $corporation_id)->where('created_at', '<', $day_after)->get();
        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'verified')->get();

        //gets the capcodes and agent ids into an array for eloquent
        $verifiedCapcodes = [];
        foreach($capcodes as $capcode){
            $verifiedCapcodes[] = $capcode->id;
        }

        if($corporation_id == 2){
            $activeAgents = [1901,1902,1904];
            $agentCount[10] = 3;
        }
        else
            $activeAgents = [];

        $agentCount = [];
        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $time) && ($agent->user_link->is_deactivated == 1))
                continue;
            $activeAgents[] = $agent->agent_id;

            //gets the counts of agents for each team
            if(array_key_exists($agent->team_id, $agentCount))
                $agentCount[$agent->team_id]++;
            else
                $agentCount[$agent->team_id] = 1;
        }
        

        $verified_accounts = Inactive_Account::select('TEAM_ID')->whereIn('ACCT_AGENT', $activeAgents)->whereIn('CAPCODE', $verifiedCapcodes)
            ->where('LAST_WORKED', '>', $time)->where('LAST_WORKED', '<', $day_after)->get();

        //puts all of the data into one last array to be displayed
        $finalData = [];
        foreach($teams as $team){
            if(($team->deactivate_date < $time) && ($team->is_deactivated == 1))
                continue;

            $verified = count($verified_accounts->where('TEAM_ID', $team->team_id));

            if(!array_key_exists($team->team_id, $agentCount))
                $agentCount[$team->team_id] = 0;

            $finalData[] =[
                'team_name' => $team->name,
                'team_goal' => $team->team_goals * $agentCount[$team->team_id],
                'verified' => $verified,
            ];
        }

        return $finalData;
    }

}
