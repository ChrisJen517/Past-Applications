<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Worked_History;
use DB;

class ClosedAccountsByTeamController extends Controller 
{
    public function showClosed(Request $request)
    {
        if (count($request->all()) == 0) {
            $startTime = date("Y-m-d");
            $endTime = date("Y-m-d");
        } else {
            if ($request->from == null) {
                $startTime = date("Y-m-d", strtotime("-1 week"));
            } else {
                $startTime = date('Y-m-d', strtotime($request->from));
            }

            if ($request->to == null) {
                $endTime = date("Y-m-d");
            } else {
                $endTime = date('Y-m-d', strtotime($request->to));
            }
        }
        $corporation_Id = Auth::user()->corporate_admin_link->corporation_id;
        $timeMessage = 'From ' . $startTime . ' to ' . $endTime;

        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_Id)->where('is_deactivated', 0)->get();
        if($request->team_id == null){
            $selectedTeam['name'] = "All Teams";
            $selectedTeam['id'] = '';
            $team_id = null;
        }
        else{
            $team_id = $request->team_id;
            $selectedTeam['name'] = $teams->where('team_id', $team_id)->first()->name;
            $selectedTeam['id'] = $teams->where('team_id', $team_id)->first()->team_id;
        }

        $endTime = date("Y-m-d", strtotime($endTime . " +1 day"));

        $capcodes = Capcode::where('corporation_id', $corporation_Id)->get();

        //gets the account type and the needed capcodes depending on section
        switch($request->accountType){
            case 'Active':
                $accountType = 'Active';
            break; 
            case 'Inactive':
                $neededCodes = [];
                $accountType = 'Inactive';
            break; 
            case 'Unverified':
                $unverifiedCapcodes = $capcodes->where('type', 'unverified');
                foreach ($unverifiedCapcodes as $capcode) {
                    $neededCodes[] = $capcode->id;
                }
                $accountType = 'Unverified';
            break; 
            case 'Worked':
                $accountType = 'Worked';
                foreach ($capcodes as $capcode) {
                    $neededCodes[] = $capcode->id;
                }
            break; 
            default:
                $verifiedCapcodes = $capcodes->where('type', 'verified');
                foreach ($verifiedCapcodes as $capcode) {
                    $neededCodes[] = $capcode->id;
                }
                $accountType = 'Verified';
            break;
        }

        if(in_array($accountType, ['Verified', 'Inactive', 'Unverified'])){
            $accounts = Inactive_Account::
            select('CAPCODE', 'ACCT_DUE_DATE', 'ACCT_AGENT', 'TEAM_NAME', 'LAST_WORKED', 'ACCT_SSN', 'ACCT_CASE', 'ACCT_LAST_NAME', 'ACCT_FIRST_NAME', 'ID', 'ACCT_ID', 'EMPL_NAME', 'CLIENT_NAME', 'CLIENT_PHONE', 'ACCESS_RULES')
            ->when($accountType == 'Verified', function($q) { $q->addSelect(DB::Raw('(SELECT employer_phone from verified_hits where inactive_accounts.VERIFIED_HITS_ID = verified_hits.id) AS verifiedPhone'));})
            ->where("LAST_WORKED", ">", $startTime)
            ->where("LAST_WORKED", "<", $endTime)
            ->where("CORPORATION_ID", $corporation_Id)
            ->where('ON_HOLD', '!=', 1)
            ->when($team_id, function($q) use ($team_id) { $q->where('team_id', $team_id);})
            ->when(!empty($neededCodes), function($q) use ($neededCodes) { $q->whereIn('CAPCODE', $neededCodes);})
            ->orderBy('last_worked', 'DESC')->limit(1000)->get();
        }
        elseif($accountType == 'Worked'){
            $accounts = Worked_History::
            where("created_at", ">", $startTime)
            ->where("created_at", "<", $endTime)
            ->when($team_id, function($q) use ($team_id) { 
                $q->whereRaw('active_account_id in (Select ID from active_accounts where TEAM_ID = '.$team_id.')')
                ->orWhereRAW('active_account_id in (Select ID from inactive_accounts where TEAM_ID = '.$team_id.')');
            })
            ->whereIn('CAPCODE', $neededCodes)
            ->orderBy('created_at', 'DESC')->limit(1000)->get();
        }
        else{   
            $accounts = Active_Account::
                select('CAPCODE', 'ACCT_DUE_DATE', 'ACCT_AGENT', 'TEAM_NAME', 'LAST_WORKED', 'ACCT_SSN', 'ACCT_CASE', 'ACCT_LAST_NAME', 'ACCT_FIRST_NAME', 'ID', 'ACCT_ID', 'EMPL_NAME', 'CLIENT_NAME', 'CLIENT_PHONE', 'ACCESS_RULES')
                ->where("LAST_WORKED", ">", $startTime)
                ->where("LAST_WORKED", "<", $endTime)
                ->where("CORPORATION_ID", $corporation_Id)
                ->where('ON_HOLD', '!=', 1)
                ->when($team_id, function($q) use ($team_id) { $q->where('team_id', $team_id);})
                ->orderBy('last_worked', 'DESC')->limit(1000)->get();
        }

        return view('corporateAdmin.pages.reports.closedAccountsByTeam')
            ->with('accounts', $accounts)->with('accountType', $accountType)
            ->with('capcodes', $capcodes)
            ->with('teams', $teams)->with('selectedTeam', $selectedTeam)
            ->with('timeMessage', $timeMessage);
    }
}