<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Agent;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Traits\DateUtils;
use App\Models\Worked_History;
use Carbon\Carbon;
use Carbon\CarbonPeriod;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class WorkStatsController extends Controller
{
    use DateUtils;

    public function showAverageAccountsWorked(Request $request) {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        if($request->to == null)
            $endDate = Carbon::now()->format('Y-m-d');
        else
            $endDate = Carbon::parse($request->to)->format('Y-m-d');

        if($request->from == null)
            $startDate = Carbon::parse($endDate)->startOfWeek(Carbon::MONDAY)->format('Y-m-d');
        else
            $startDate = Carbon::parse($request->from)->format('Y-m-d');

        $diffInDays = Carbon::parse($startDate)->diffInDays(Carbon::parse($endDate));
        if ($diffInDays > 7)
            return redirect()->back()->with('error', 'You may not choose a date range wider than a week.');

        $dayPeriod = CarbonPeriod::create($startDate, $endDate);
        $dayPeriodArray = [];
        foreach ($dayPeriod as $day) {
            $dayPeriodArray[] = $day->format("Y-m-d");
        }

        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->get();
        $teamIds = $teams->pluck('team_id')->toArray();
        $teamsImploded = implode(',', $teamIds);

        $monthsDisplay = [];
        $monthsQuery = [];
        for ($i = 0; $i < 3; $i++) {
            $time = Carbon::now()->subMonths($i);
            $monthsDisplay[] = $time->format('M Y');
            $monthsQuery[] = $time->format('Y-m');
        }

        $monthsImploded = implode("','", $monthsQuery);
        $monthsImploded = "'" . $monthsImploded . "'";

        $agents = Agent::select('agent_id', 'user_id', 'team_id')->with('user_link')->where('corporation_id', $corporation_id)->get();
        $agentIds = [];

        foreach($agents as $agent) {
            $user = $agent->user_link;
            if (($user->is_deactivated == 1 && Carbon::parse($user->deactivate_date)->isBefore($startDate)) || ($agent->created_at >= $endDate))
                continue;

            $agentIds[] = $agent->agent_id;
        }

        $agentIdsImploded = implode(',', $agentIds);

        $dailyQuery = Worked_History::selectRaw('count(*) as total, DATE(CREATED_AT) as day, agent_id')
        ->whereRaw("agent_id in ($agentIdsImploded) and DATE(CREATED_AT) >= DATE('$startDate') and DATE(CREATED_AT) <= DATE('$endDate')")
        ->groupBy('agent_id', 'day')->get();

        $monthlyQuery = Worked_History::selectRaw("count(*) as total, DATE_FORMAT(CREATED_AT, '%Y-%m') as month, agent_id")
        ->whereRaw("agent_id in ($agentIdsImploded) and DATE_FORMAT(CREATED_AT, '%Y-%m') in ($monthsImploded)")
        ->groupBy('agent_id', 'month')->get();

        $dailyData = [];
        $monthlyData = [];
        $dailyTeamData = [];
        $monthlyTeamData = [];

        foreach ($teams as $team) {
            $teamId = $team->team_id;
            $teamName = $team->name;

            if ($teamName == "BOT")
                continue;

            $agentsInTeam = $agents->where('team_id', $teamId);
            $agentIdsInTeam = $agentsInTeam->pluck('agent_id')->toArray();

            $dailyTeamIsolated = $dailyQuery->whereIn('agent_id', $agentIdsInTeam);
            $monthlyTeamIsolated = $monthlyQuery->whereIn('agent_id', $agentIdsInTeam);

            if (!array_key_exists($teamName, $dailyTeamData)) {
                $tempArray = [];
                foreach($dayPeriod as $day) {
                    $dayFormatted = $day->format('Y-m-d');
                    $tempArray[$dayFormatted] = 0;
                }
                $dailyTeamData[$teamName] = $tempArray;

                $tempArray = [];
                foreach($monthsQuery as $month) {
                    $tempArray[$month] = 0;
                }
                $monthlyTeamData[$teamName] = $tempArray;
            }

            foreach ($dailyTeamIsolated as $dayData) {
                $dailyTeamData[$teamName][$dayData->day] += $dayData->total;
            }

            foreach ($monthlyTeamIsolated as $monthData) {
                $monthlyTeamData[$teamName][$monthData->month] += $monthData->total;
            }
        }

        foreach($monthlyTeamData as $teamName => $data) {
            foreach($data as $month => $value) {
                $monthParsed = Carbon::parse($month);
                if ($monthParsed->format('Y-m') == Carbon::now()->format('Y-m'))
                    $daysInMonth = $this->getWorkingDays(Carbon::now()->firstOfMonth()->format('Y-m-d'), Carbon::now()->format('Y-m-d'));
                else
                    $daysInMonth = $this->getWorkingDays($monthParsed->firstOfMonth()->format('Y-m-d'), $monthParsed->endOfMonth()->format('Y-m-d'));

                // Should never happen but stopping division by 0 just in case
                if ($daysInMonth == 0)
                    continue;

                $monthlyTeamData[$teamName][$month] = number_format(round($value / $daysInMonth, 2), 2);
            }
        }

        foreach ($agents as $agent) {
            $agentId = $agent->agent_id;

            $dailyAgentIsolated = $dailyQuery->where('agent_id', $agentId);
            $monthlyAgentIsolated = $monthlyQuery->where('agent_id', $agentId);

            if (!array_key_exists($agentId, $dailyData)) {
                $tempArray = [];
                $tempArray['agent_id'] = $agentId;
                $tempArray['name'] = $agent->user_link->first_name . ' ' . $agent->user_link->last_name;
                foreach($dayPeriod as $day) {
                    $dayFormatted = $day->format('Y-m-d');
                    $tempArray[$dayFormatted] = 0;
                }
                $dailyData[$agentId] = $tempArray;

                $tempArray = [];
                $tempArray['agent_id'] = $agentId;
                $tempArray['name'] = $agent->user_link->first_name . ' ' . $agent->user_link->last_name;
                $tempMonths = [];
                foreach($monthsQuery as $month) {
                    $tempMonths[$month] = 0;
                }
                $tempArray['months'] = $tempMonths;
                $monthlyData[$agentId] = $tempArray;
            }

            foreach ($dailyAgentIsolated as $dayData) {
                $dailyData[$agentId][$dayData->day] += $dayData->total;
            }

            foreach ($monthlyAgentIsolated as $monthData) {
                $monthlyData[$agentId]['months'][$monthData->month] += $monthData->total;
            }
        }

        foreach($monthlyData as $agentId => $data) {
            foreach($data['months'] as $month => $value) {
                $monthParsed = Carbon::parse($month);
                if ($monthParsed->format('Y-m') == Carbon::now()->format('Y-m'))
                    $daysInMonth = $this->getWorkingDays(Carbon::now()->firstOfMonth()->format('Y-m-d'), Carbon::now()->format('Y-m-d'));
                else
                    $daysInMonth = $this->getWorkingDays($monthParsed->firstOfMonth()->format('Y-m-d'), $monthParsed->endOfMonth()->format('Y-m-d'));

                // Should never happen but stopping division by 0 just in case
                if ($daysInMonth == 0)
                    continue;

                $monthlyData[$agentId]['months'][$month] = number_format(round($value / $daysInMonth, 2), 2);
            }
        }

        return view('corporateAdmin.pages.reports.averageAccountsWorked')
        ->with(compact("dailyData", "monthlyData", "dailyTeamData", "monthlyTeamData", "dayPeriodArray", "monthsDisplay", "monthsQuery"));
    }

}
