<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Access_Levels;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Worked_History;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Str;

class AWG7AgentPerformanceController extends Controller
{
    public function showAWG7AgentPerformance(Request $request) {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        
        $hasEndDate = false;
        if($request->to == null)
            $endDate = Carbon::now()->format('Y-m-d');
        else {
            $endDate = Carbon::parse($request->to)->format('Y-m-d');
            $hasEndDate = true;
        }

        if($request->from == null) {
            if ($hasEndDate)
                $startDate = Carbon::parse($endDate)->startOfWeek(Carbon::MONDAY)->format('Y-m-d');
            else
                $startDate = Carbon::now()->format('Y-m-d');
        }
        else
            $startDate = Carbon::parse($request->from)->format('Y-m-d');


        $startDateFormatted = Carbon::parse($startDate)->format('m-d-Y');
        $endDateFormatted = Carbon::parse($endDate)->format('m-d-Y');
        if ($startDateFormatted == $endDateFormatted) {
            if ($startDateFormatted == Carbon::now()->format('m-d-Y'))
                $timeString = "today";
            else
                $timeString = $startDateFormatted;
        } else 
            $timeString = "$startDateFormatted to $endDateFormatted";

        $accessLevel = Access_Levels::select('id')->where('corporation_id', $corporation_id)->where('shortcode', 'AWG7')->first();
        $callCapcode = Capcode::select('id')->where('corporation_id', $corporation_id)->where('capcode', 2210)->first();

        $agents = Agent::select('agent_id', 'user_id', 'team_id')->with('user_link')->where('corporation_id', $corporation_id)->get();
        $agentIds = [];
        foreach($agents as $agent) {
            $user = $agent->user_link;
            // * User is deactivated
            if (($user->is_deactivated == 1 && Carbon::parse($user->deactivate_date)->isBefore($startDate)) || ($agent->created_at >= $endDate))
                continue;
            // * User has no access rules
            if (empty($user->has_access))
                continue;
            // * User has access rules, but not AWG7
            if (is_array($user->has_access)) {
                if (!in_array($accessLevel->id, $user->has_access))
                    continue;
            }
            // * User has an access rule, but not AWG7
            else if (!Str::contains($user->has_access, $accessLevel->id))
                continue;

            $agentIds[] = $agent->agent_id;
        }
        $agentIdsImploded = implode(',', $agentIds);

        $verifiedCapcodes = Capcode::select('id')->where('corporation_id', 2)->where('type', 'verified')->get();
        $verifiedCapcodeIds = $verifiedCapcodes->pluck('id')->toArray();
        $verifiedCapcodesImploded = implode(',', $verifiedCapcodeIds);

        $unverifiedCapcodes = Capcode::select('id')->where('corporation_id', 2)->where('type', 'unverified')->get();
        $unverifiedCapcodeIds = $unverifiedCapcodes->pluck('id')->toArray();
        $unverifiedCapcodesImploded = implode(',', $unverifiedCapcodeIds);

        $activeAccounts = Active_Account::selectRaw("COUNT(IF(LAST_WORKED IS NULL, 1, NULL)) as unworked, COUNT(IF(WORK_REMINDER IS NOT NULL, 1, NULL)) as followup, ACCT_AGENT")
        ->whereRaw("ACCT_AGENT IN ($agentIdsImploded) AND ACCESS_RULES LIKE '%AWG7%' AND corporation_id = $corporation_id AND DATE(CREATED_AT) >= DATE('$startDate') AND DATE(CREATED_AT) <= DATE('$endDate')")
        ->groupBy('ACCT_AGENT')->get();

        $closedAccounts = Inactive_Account::selectRaw("COUNT(*) as total, COUNT(IF(capcode in ($verifiedCapcodesImploded), 1, NULL)) as verified, COUNT(IF(capcode in ($unverifiedCapcodesImploded), 1, NULL)) as unverified, ACCT_AGENT")
        ->whereRaw("ACCT_AGENT IN ($agentIdsImploded) AND ACCESS_RULES LIKE '%AWG7%' AND corporation_id = $corporation_id AND DATE(CREATED_AT) >= DATE('$startDate') AND DATE(CREATED_AT) <= DATE('$endDate')")
        ->groupBy('ACCT_AGENT')->get();

        $workedHistoryActive = Worked_History::from("worked_history as wh")
        ->selectRaw("COUNT(IF(wh.capcode = $callCapcode->id, 1, NULL)) as calls, agent_id")
        ->join('active_accounts as aa', 'aa.ID', '=', 'wh.active_account_id')
        ->whereRaw("agent_id IN ($agentIdsImploded) AND aa.ACCESS_RULES LIKE '%AWG7%' AND DATE(wh.CREATED_AT) >= DATE('$startDate') AND DATE(wh.CREATED_AT) <= DATE('$endDate')")
        ->groupBy('agent_id')->get();

        $workedHistoryInactive = Worked_History::from("worked_history as wh")
        ->selectRaw("COUNT(IF(wh.capcode = $callCapcode->id, 1, NULL)) as calls, agent_id")
        ->join('inactive_accounts as ia', 'ia.ID', '=', 'wh.active_account_id')
        ->whereRaw("agent_id IN ($agentIdsImploded) AND ia.ACCESS_RULES LIKE '%AWG7%' AND DATE(wh.CREATED_AT) >= DATE('$startDate') AND DATE(wh.CREATED_AT) <= DATE('$endDate')")
        ->groupBy('agent_id')->get();

        $data = [];
        foreach ($agentIds as $agentId) {
            $user = $agents->where('agent_id', $agentId)->first()->user_link;
            $activeAccountAgentData = $activeAccounts->where('ACCT_AGENT', $agentId)->first();
            $closedAccountAgentData = $closedAccounts->where('ACCT_AGENT', $agentId)->first();
            $activeWHAgentData = $workedHistoryActive->where('agent_id', $agentId)->first();
            $inactiveWHAgentData = $workedHistoryInactive->where('agent_id', $agentId)->first();

            $name = $user->first_name . ' ' . $user->last_name;
            $unworked = $activeAccountAgentData->unworked ?? 0;
            $followup = $activeAccountAgentData->followup ?? 0;
            $totalCalls = ($activeWHAgentData->calls ?? 0) + ($inactiveWHAgentData->calls ?? 0);
            $totalClosed = $closedAccountAgentData->total ?? 0;
            $verifiedAccounts = $closedAccountAgentData->verified ?? 0;
            $unverifiedAccounts = $closedAccountAgentData->unverified ?? 0;

            $data[] = [
                'agent_id' => $agentId,
                'name' => $name,
                'unworked' => $unworked,
                'followup' => $followup,
                'calls' => $totalCalls,
                'closed' => $totalClosed,
                'green' => $verifiedAccounts,
                'red' => $unverifiedAccounts
            ];
        }

        return view('corporateAdmin.pages.reports.AWG7AgentPerformance')->with(compact("data", "timeString"));
    }
}
