<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Models\Team;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Request;
use Auth;

class AgentCapcodeUsageController extends Controller
{
    public function showCapcodeUsage()
    {
        $start_date = date('Y-m-d', strtotime('today'));
        $end_date = date('Y-m-d', strtotime('today'));

        $teams = Team::where('corporation_id', Auth::user()->corporate_admin_link->corporation_id)->where('created_at', '<', $end_date)
        ->where(function($q) use ($start_date){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($start_date) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $start_date );}); })
        ->select('team_id', 'name')->get();

        $start_date = '"'.$start_date.'"';
        $end_date = '"'.$end_date.'"';

        $results = $this->getData($start_date, $end_date);
        $agentTotalCounts = $results[0];
        $agentCapcodeUsage = $results[1];

        $timeMessage = "From today";
        
        return view('corporateAdmin.pages.reports.capcodeUsageByAgent')
        ->with('agentTotalCounts', $agentTotalCounts)->with('agentCapcodeUsage', $agentCapcodeUsage)
        ->with('timeMessage', $timeMessage)->with('teams', $teams);
    }

    public function getDatedverifiedCapcodes(Request $request)
    {
        if($request->from == null)
            $start_date = date("Y-m-d", strtotime("-1 week"));
        else
            $start_date = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $end_date = date('Y-m-d', strtotime('today'));
        else
            $end_date = date('Y-m-d', strtotime($request->to));


        $teams = Team::where('corporation_id', Auth::user()->corporate_admin_link->corporation_id)->where('created_at', '<', $end_date)
            ->where(function($q) use ($start_date){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($start_date) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $start_date );}); })
            ->select('team_id', 'name')->get();

        $timeMessage = "From ".$start_date." to ".$end_date;
        $start_date = '"'.$start_date.'"';
        $end_date = '"'.$end_date.'"';
            
        $results = $this->getData($start_date, $end_date);
        $agentTotalCounts = $results[0];
        $agentCapcodeUsage = $results[1];
        
        return view('corporateAdmin.pages.reports.capcodeUsageByAgent')
        ->with('agentTotalCounts', $agentTotalCounts)->with('agentCapcodeUsage', $agentCapcodeUsage)
        ->with('timeMessage', $timeMessage)->with('teams', $teams);
    }

    public function getData($start_date, $end_date){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $agents = Agent::select()->where('corporation_id', $corporation_id)->get();

        $allCapcodes = Capcode::select('capcode', 'id', 'type')->where('corporation_id', $corporation_id)->where('type', '!=', 'pending_approval')->get(); 

        $activeAccounts = Active_Account::selectRaw('acct_agent, team_id, capcode, count(*) as total')
        ->where('corporation_id', $corporation_id)
        ->whereRaw('LAST_WORKED >= date('.$start_date.') and LAST_WORKED <= DATE_ADD('.$end_date.', INTERVAL 1 DAY)')
        ->groupBy('acct_agent')->groupBy('capcode')->get();

        $inactiveAccounts = Inactive_Account::selectRaw('acct_agent, team_id, capcode, count(*) as total')
        ->where('corporation_id', $corporation_id)
        ->whereRaw('LAST_WORKED >= date('.$start_date.') and LAST_WORKED <= DATE_ADD('.$end_date.', INTERVAL 1 DAY)')
        ->groupBy('acct_agent')->groupBy('capcode')->get();

        $agentCapcodeUsage['inconclusive'] = [];
        $agentCapcodeUsage['verified'] = [];
        $agentCapcodeUsage['unverified'] = [];

        foreach ($agents as $agent) {
            if(($agent->user_link->deactivate_date < $start_date) && ($agent->user_link->is_deactivated == 1)){
                continue;
            }

            $agentTotalCounts['inconclusive'][$agent->agent_id] = 0;
            $agentTotalCounts['verified'][$agent->agent_id] = 0;
            $agentTotalCounts['unverified'][$agent->agent_id] = 0;

            $agentActive = $activeAccounts->where('acct_agent', $agent->agent_id);
            foreach($agentActive as $account){
                $capcode = $allCapcodes->where('id', $account->capcode)->first();
                $type = $capcode->type ?? '';

                if($type != ''){
                    $agentTotalCounts[$type][$agent->agent_id] += $account->total;
                    $agentCapcodeUsage[$type][] = [
                        'capcode' => $capcode->capcode,
                        'total' => $account->total,
                        'team_id' => $agent->team_id,
                        'agent_id' => $agent->agent_id,
                        'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name
                    ];
                }
            }

            $agentInactive = $inactiveAccounts->where('acct_agent', $agent->agent_id);
            foreach($agentInactive as $account){
                $capcode = $allCapcodes->where('id', $account->capcode)->first();
                $type = $capcode->type ?? '';

                if($type != ''){
                    $agentTotalCounts[$type][$agent->agent_id] += $account->total;
                    $agentCapcodeUsage[$type][] = [
                        'capcode' => $capcode->capcode,
                        'total' => $account->total,
                        'team_id' => $agent->team_id,
                        'agent_id' => $agent->agent_id,
                        'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name
                    ];
                }
            }
        }

        $results[] = $agentTotalCounts;
        $results[] = $agentCapcodeUsage;
        return $results;
    }

}
