<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\User;
use Auth;
use DateTime;
use DB;
use Illuminate\Http\Request;

class ClientPerformanceController extends Controller
{
    public function clientPerformance()
    {
        $finalData = $this->getData(date("Y-m-d", strtotime("-1 week")), new DateTime('tomorrow'));

        $message = "from the past 7 days";

        return view('corporateAdmin.pages.reports.clientPerformance')->with('sources', $finalData)->with('timeMessage', $message);
    }

    public function clientPerformanceTime(Request $request)
    {
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }
        $message = "from: " . $startTime . " to " . $endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $finalData = $this->getData($startTime, $endTime);

        return view('corporateAdmin.pages.reports.clientPerformance')->with('sources', $finalData)->with('timeMessage', $message);
    }

    public function getData($startTime, $endTime)
    {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        //gets list of capcodes
        $capcodes = Capcode::where('corporation_id', $corporation_id)->select('capcode', 'id', 'type')->get();

        //gets all accounts
        $activeAccounts = Active_Account::where('corporation_id', $corporation_id)
        ->where(function ($query) use ($startTime, $endTime) {
            $query->where('LAST_WORKED', '>', $startTime);
            $query->where('LAST_WORKED', '<', $endTime);
            $query->orwhere('LAST_WORKED', null);
        })->SELECT(DB::raw('count(*) as count, CAPCODE, ACCT_SOURCE, ACCT_CLIENT, CLIENT_NAME'))
        ->groupBy('ACCT_SOURCE', 'ACCT_CLIENT', 'CAPCODE')->get();

        $sources = $activeAccounts->groupby('ACCT_SOURCE');

        $finalData = [];
        //gets all the current account metrics
        foreach ($sources as $source) {
            $clients = $source->groupby('ACCT_CLIENT');

            foreach ($clients as $client) {
                //resetes counters
                $unworked = 0;
                $inconclusive = 0;

                //for each capcode gets the type and adds it's count
                foreach ($client as $capcode) {

                    if ($capcode->CAPCODE == null) {
                        $unworked = $unworked + $capcode->count;
                    } else {

                        if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {

                            if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                                $type = $capcodes->where('id', $capcode->CAPCODE)->first()->type;
                            } else {
                                $type = 'N/A';
                            }
                        } else {

                            if (!empty($capcodes->where('capcode', $capcode->CAPCODE)->first())) {
                                $type = $capcodes->where('capcode', $capcode->CAPCODE)->first()->type;
                            } else {
                                $type = 'N/A';
                            }
                        }
                        if ($type == 'inconclusive') {
                            $inconclusive = $inconclusive + $capcode->count;
                        }

                    }
                }

                //stores the accounts in the array
                $finalData[$source[0]->ACCT_SOURCE . $client[0]->ACCT_CLIENT] = [
                    'source' => $client[0]->ACCT_SOURCE,
                    'client' => $client[0]->ACCT_CLIENT,
                    'name' => $client[0]->CLIENT_NAME,
                    'unworked' => $unworked,
                    'verified' => 0,
                    'unverified' => 0,
                    'inconclusive' => $inconclusive,
                ];
            }
        }

        //gets the inactive accounts
        $inactiveAccounts = Inactive_Account::where('corporation_id', $corporation_id)->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime)
            ->SELECT(DB::raw('count(*) as count, CAPCODE, ACCT_SOURCE, ACCT_CLIENT'))->groupBy('ACCT_SOURCE', 'ACCT_CLIENT', 'CAPCODE')->get();
        $sources = $inactiveAccounts->groupby('ACCT_SOURCE');

        foreach ($sources as $source) {
            $clients = $source->groupby('ACCT_CLIENT');
            foreach ($clients as $client) {
                //resetes counters
                $unworked = 0;
                $inconclusive = 0;
                //makes sure this source exists in final data
                if (!array_key_exists($client[0]->ACCT_SOURCE . $client[0]->ACCT_CLIENT, $finalData)) {
                    $finalData[$client[0]->ACCT_SOURCE . $client[0]->ACCT_CLIENT] = [
                        'source' => $client[0]->ACCT_SOURCE,
                        'client' => $client[0]->ACCT_CLIENT,
                        'name' => $client[0]->CLIENT_NAME,
                        'unworked' => 0,
                        'verified' => 0,
                        'unverified' => 0,
                        'inconclusive' => 0,
                    ];
                }

                //return $finalData[$client[0]->ACCT_SOURCE.$client[0]->ACCT_CLIENT]['unverified'];

                //for each capcode gets the type and adds it's count
                foreach ($client as $capcode) {
                    if ($capcode->CAPCODE != null) {
                        if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                            if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                                $type = $capcodes->where('id', $capcode->CAPCODE)->first()->type;
                            } else {
                                $type = 'N/A';
                            }
                        } else {
                            if (!empty($capcodes->where('capcode', $capcode->CAPCODE)->first())) {
                                $type = $capcodes->where('capcode', $capcode->CAPCODE)->first()->type;
                            } else {
                                $type = 'N/A';
                            }
                        }
                        if ($type == 'unverified') {
                            $finalData[$client[0]->ACCT_SOURCE . $client[0]->ACCT_CLIENT]['unverified'] += $capcode->count;
                        } else if ($type == 'verified') {
                            $finalData[$client[0]->ACCT_SOURCE . $client[0]->ACCT_CLIENT]['verified'] += $capcode->count;
                        }

                    }
                }
            }
        }

        return $finalData;
    }
}