<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use App\Models\Agent;
use DateTime;
use DB;
use Illuminate\Http\Request;

class SourcePerformanceReportController extends Controller
{
    public $months = array('January','February','March','April','May',
        'June','July ','August','September','October','November','December',
    );

    public function sourcePerformance($workedOnly){
        $minMonth = date('m', strtotime('- 5 months'));
        $thisMonth = date('m');
        $startToEnd = [
            'start' => $minMonth,
            'end' => $thisMonth
        ];
        $sources = $this->getData($workedOnly);

        return view('corporateAdmin.pages.reports.sourcePerformanceReport')
        ->with('sources', $sources)->with('months', $this->months)->with('startToEnd', $startToEnd);
    }

    public function getData($workedOnly){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $startDate = date('Y-m-01', strtotime(' - 5 months'));
        $minMonth = date('m', strtotime('- 5 months'));
        $thisMonth = date('m');

        $activeCounts = Active_Account::selectRaw('count(ID) as totalLeads, ACCT_SOURCE, MONTH(ADD_DATE)')->where('corporation_id', $corporation_id)
            ->whereRaw("ADD_DATE >= $startDate")
            ->when($workedOnly == 'worked', function ($query){
                return $query->whereNotNull('LAST_WORKED');
            })->groupBy('ACCT_SOURCE')->groupBy('MONTH(ADD_DATE)')->get();

        $inactiveCounts = Inactive_Account::selectRaw('count(inactive_accounts.ID) as totalLeads, ACCT_SOURCE, COUNT(IF(capcodes.type = "verified",1,NULL)) AS verified, MONTH(ADD_DATE)')
            ->leftJoin('capcodes', function ($join) {
                $join->on('inactive_accounts.CAPCODE', '=', 'capcodes.id');
            })->when($workedOnly == 'worked', function ($query){
                return $query->whereNotNull('LAST_WORKED');
            })->where('inactive_accounts.corporation_id', $corporation_id)->whereRaw("ADD_DATE >= $startDate")->groupBy('ACCT_SOURCE')->groupBy('MONTH(ADD_DATE)')->get();

        $activeCounts = $activeCounts->groupBy('ACCT_SOURCE');
        $inactiveCounts = $inactiveCounts->groupBy('ACCT_SOURCE');

        $finalData = [];
        foreach($activeCounts as $source => $months){
            for($i = $minMonth; $i <= $thisMonth; $i++){
                $finalData[$source][$i] = [
                    'total' => $months->where('MONTH(ADD_DATE)', $i)->first()->totalLeads ?? 0,
                    'verified' => 0
                ];
            }
        }

        foreach($inactiveCounts as $source => $months){
            if(!key_exists($source, $finalData)){
                $finalData[$source] = [];
            }
            for($i = $minMonth; $i <= $thisMonth; $i++){
                if(key_exists($i, $finalData[$source])){
                    $finalData[$source][$i]['total'] += $months->where('MONTH(ADD_DATE)', $i)->first()->totalLeads ?? 0;
                    $finalData[$source][$i]['verified'] += $months->where('MONTH(ADD_DATE)', $i)->first()->verified ?? 0;
                }
                else{
                    $finalData[$source][$i] = [
                        'total' => $months->where('MONTH(ADD_DATE)', $i)->first()->totalLeads ?? 0,
                        'verified' => $months->where('MONTH(ADD_DATE)', $i)->first()->verified ?? 0
                    ];
                }
            }
        }

        return $finalData;
    }
}