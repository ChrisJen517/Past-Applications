<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Traits\DateUtils;
use App\Models\Capcode;
use App\Models\Team;
use App\Models\Agent;
use App\Models\Corporate_Admin;
use App\Models\Manager;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Worked_History;
use Auth;
use DB;

class FaxReportByTeamController extends Controller
{
    use DateUtils;

    public function showReport(Request $request){
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        $timeMessage = 'From ' . $startTime . ' to ' . $endTime;
        $endTime = date("Y-m-d", strtotime($endTime . " +1 day"));

        $faxInfo = $this->getData($startTime,$endTime);

        return view('corporateAdmin.pages.reports.faxReportByTeam')->with('faxInfo', $faxInfo)->with('timeMessage', $timeMessage);
    }

    public function getData($startTime, $endTime){
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $capcodes = Capcode::select('capcode', 'id', 'type')->where('corporation_id', $corporation_id)->whereIn('capcode', [6000, 4411, 4408, 2216, 2211, 2209, 1111, 1103])->get();
        $agents = Agent::where('corporation_id', $corporation_id)->where('created_at', '<', $endTime)->with('user_link')->select('agent_id', 'user_id', 'team_id')->get();
        $managers = Manager::where('corporation_id', $corporation_id)->where('created_at', '<', $endTime)->with('user_link')->select('manager_id', 'user_id', 'team_id')->get();
        $corporateAdmins = Corporate_Admin::where('corporation_id', $corporation_id)->where('created_at', '<', $endTime)->with('user_link')->select('corporate_admin_id', 'user_id')->get();
        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->where('created_at', '<', $endTime)
        ->where(function($q) use ($startTime){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($startTime) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $startTime );}); })->get();

        $sent = [];
        $verified = [];
        $recieved = [];
        $allFaxes = [];
        foreach($capcodes as $capcode){
            if($capcode->type == 'inconclusive')
                $sent[] = $capcode->id;
            else{
                $recieved[] = $capcode->id;
                if($capcode->type == 'verified')
                    $verified[] = $capcode->id;
            }
            $allFaxes[] = $capcode->id;
        }
        $verified = implode(',', $verified);
        $recieved = implode(',', $recieved);
        $sent = implode(',', $sent);

        $userIds = [];
        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $userIds[] = $agent->agent_id;
        }
        foreach($managers as $manager){
            if(($manager->user_link->deactivate_date < $startTime) && ($manager->user_link->is_deactivated == 1))
                continue;

            $userIds[] = $manager->manager_id;
        }

        foreach($corporateAdmins as $admin) {
            if(($admin->user_link->deactivate_date < $startTime) && ($admin->user_link->is_deactivated == 1))
                continue;

            $userIds[] = $admin->corporate_admin_id;
        }

        if($corporation_id == 2){
            $userIds[] = 1901;
            $userIds[] = 1902;
            $userIds[] = 1904;
        }

        $workHistory = Worked_History::selectRaw('agent_id,
        COUNT(IF(capcode in ('.$recieved.'), 1, NULL) ) as "recived",
        COUNT(IF(capcode in ('.$verified.'), 1, NULL) ) as "verified"')
        ->whereIn('capcode', $allFaxes)
        ->where(function($query) use ($userIds) {
            $query->whereIn('agent_id', $userIds)
            ->orWhere('user_role', 'admin');
        })
        ->where('created_at', '>', $startTime)->where('created_at', '<', $endTime)
        ->groupBy('agent_id')->get();

        $sentHistory = Worked_History::selectRaw('agent_id,
        COUNT(DISTINCT(active_account_id) ) as "sent"')
        ->whereRaw('capcode in ('.$sent.')')
        ->where(function($query) use ($userIds) {
            $query->whereIn('agent_id', $userIds)
            ->orWhere('user_role', 'admin');
        })
        ->where('created_at', '>', $startTime)->where('created_at', '<', $endTime)->where('active_account_id', '!=', null)
        ->groupBy('agent_id')->get();

        $daysWorked = $this->getWorkingDays($startTime, $endTime);
        $daysWorked--;

        $finalData = [];
        foreach($teams as $team){
            $finalData[$team->team_id] = [
                'name' => $team->name,
                'sent' => 0,
                'recieved' => 0,
                'verified' => 0,
                'daysWorked' => $daysWorked
            ];

            if($team->team_id == 10){
                $bots = [1901, 1902, 1904];
                foreach($bots as $bot){
                    $agentHistory = $workHistory->where('agent_id', $bot)->first();
                    $agentSentHistory = $sentHistory->where('agent_id', $bot)->first();

                    $finalData[$team->team_id]['sent'] += $agentSentHistory->sent ?? 0;
                    $finalData[$team->team_id]['recieved'] += $agentHistory->recived ?? 0;
                    $finalData[$team->team_id]['verified'] += $agentHistory->verified ?? 0;
                }
                continue;
            }

            $teamAgents = $agents->where('team_id', $team->team_id);
            $teamManagers = $managers->where('team_id', $team->team_id);

            foreach($teamAgents as $agent){
                if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                    continue;

                $agentHistory = $workHistory->where('agent_id', $agent->agent_id)->first();
                $agentSentHistory = $sentHistory->where('agent_id', $agent->agent_id)->first();

                $finalData[$team->team_id]['sent'] += $agentSentHistory->sent ?? 0;
                $finalData[$team->team_id]['recieved'] += $agentHistory->recived ?? 0;
                $finalData[$team->team_id]['verified'] += $agentHistory->verified ?? 0;
            }
            foreach($teamManagers as $manager){
                if(($manager->user_link->deactivate_date < $startTime) && ($manager->user_link->is_deactivated == 1))
                    continue;

                $managerHistory = $workHistory->where('agent_id', $manager->manager_id)->first();
                $managerSentHistory = $sentHistory->where('agent_id', $manager->manager_id)->first();

                $finalData[$team->team_id]['sent'] += $managerSentHistory->sent ?? 0;
                $finalData[$team->team_id]['recieved'] += $managerHistory->recived ?? 0;
                $finalData[$team->team_id]['verified'] += $managerHistory->verified ?? 0;
            }
        }

        return $finalData;
    }
}
