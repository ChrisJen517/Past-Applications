<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Account_Source;
use App\Http\Controllers\Controller;
use Auth;
use Illuminate\Http\Request;
use App\Models\Team;
use App\Models\Agent;
use DB;
use App\Traits\getIdCombinations;
use App\Jobs\TeamDistrubutionQueue;

class AccessRulesTableController extends Controller
{
    use getIdCombinations;
    public function getAccessRuleBreakdown(){
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $agents = Agent::where('corporation_id', $corporation_id)->with('user_link')->get();
        $teams =  Team::select('team_id','name')->where('is_deactivated', 0)->where('corporation_id', $corporation_id)->get();
        $team_rules = DB::SELECT(DB::RAW("SELECT team_id as 'teamid', (SELECT GROUP_CONCAT(distinct(has_access))  from users inner join agents on users.user_id = agents.user_id WHERE agents.team_id = teamid order by has_access) AS 'rule_team' FROM agents WHERE corporation_id = ".$corporation_id." GROUP BY team_id;
        "));
        $query_builder = "SELECT DISTINCT(ACCESS_RULES) AS 'RULES', COUNT(ID) AS 'COUNTs', (SELECT GROUP_CONCAT(id ORDER BY id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) and CORPORATION_ID = ".$corporation_id.") AS 'shortcode_id'";
        $count = 0; 
        foreach($teams as $team){
            $query_builder = $query_builder.", (SELECT count(ID) from active_accounts where ACCESS_RULES = RULES and CORPORATION_ID = ".$corporation_id." and TEAM_ID = ".$team->team_id.") AS 'COUNT_".$team->team_id."', 
        (0) AS 'ID_".$team->team_id."',
            (SELECT count(ID) from active_accounts where ACCESS_RULES = RULES and CORPORATION_ID = ".$corporation_id." and TEAM_ID = ".$team->team_id." AND ACCT_AGENT IS NOT NULL) AS 'AGENTCOUNT_".$team->team_id."'";
        $count++;
        }        
        $query_builder = $query_builder." FROM `active_accounts` WHERE `corporation_id` = ".$corporation_id." AND `TEAM_ID` IS NOT NULL AND ACCESS_RULES IS NOT NULL AND ACCESS_RULES != '' GROUP BY `ACCESS_RULES` ORDER BY COUNTs DESC";
        $available_counts = DB::SELECT(DB::RAW($query_builder));
        foreach($team_rules as $team){
            $array = explode(',',$team->rule_team);
            sort($array);
            if($array[0] == '')
            {
                array_shift($array); 
            }
            $array = collect($array);
            $array = $array->unique()->toArray();
            $teamAccessLevelsSet = [];
            $teamAccessLevels[$team->teamid] = $this->getIdCombinations($teamAccessLevelsSet, $array);
        
            $teamAccessLevels[$team->teamid] = collect($teamAccessLevels[$team->teamid]);
            
            $agents_by_team = $agents->where('team_id', $team->teamid);
            foreach($agents_by_team as $agent_by_team){
                $rule_array = explode(',',$agent_by_team->user_link->has_access);
                sort($rule_array);
                if($rule_array[0] == '')
                {
                    array_shift($rule_array); 
                }
                $rule_array = collect($rule_array);
                $rule_array = $rule_array->unique()->toArray();
                $agentAccessSet = [];
                $agentAccessLevels[$agent_by_team->agent_id] = $this->getIdCombinations($agentAccessSet, $rule_array);
                $agentAccessLevels[$agent_by_team->agent_id] = collect($agentAccessLevels[$agent_by_team->agent_id]);
            }
        }

        foreach($available_counts as $available_count){
            if($available_count->RULES == '' || $available_count->RULES == NULL){

                foreach($team_rules as $team){
                    $count_team_term = "ID_".$team->teamid;
                    if(property_exists($available_count, $count_team_term))
                        $available_count->$count_team_term = 1;
                }

            }else{
                foreach($team_rules as $team){

                    $count_team_term = "ID_".$team->teamid;
        
                    if($teamAccessLevels[$team->teamid]->contains($available_count->shortcode_id))
                    {
                        $agents_by_team = $agents->where('team_id', $team->teamid);
                        foreach($agents_by_team as $agent_by_team){
                            if( ($agentAccessLevels[$agent_by_team->agent_id]->contains($available_count->shortcode_id)) && (property_exists($available_count, $count_team_term)) ){
                                $available_count->$count_team_term++;
                            }
                        }
                    }
                }
            }
        }

        return view('corporateAdmin.pages.reports.accessRulesBreakdown')->with('datas', $available_counts)->with('teams', $teams);
    }
}