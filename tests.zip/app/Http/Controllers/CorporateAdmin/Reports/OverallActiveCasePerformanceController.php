<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Http\Controllers\Controller;
use Auth;
use DB;

class OverallActiveCasePerformanceController extends Controller
{
    public function overallActiveCasePerformance()
    {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $activeAccounts = Active_Account::SELECT(DB::RAW('active_accounts.ACCT_CASE, active_accounts.ACCT_DUE_DATE,
            COUNT(active_accounts.ID) AS active,
            COUNT(IF(active_accounts.LAST_WORKED IS NULL, 1, NULL)) AS unworked,
            COUNT(IF(active_accounts.LAST_WORKED IS NOT NULL, 1, NULL)) AS worked
            '))
            ->where('CORPORATION_ID', $corporation_id)
            ->whereNotNull('ACCT_CASE')
            ->groupBy('ACCT_CASE')
            ->get();


        $finalData = [];
        foreach ($activeAccounts as $case) {
            $duedate = $case->ACCT_DUE_DATE ?? '';
            if($duedate != '')
                $duedate = date("Y-m-d", strtotime($duedate));

            $finalData[$case->ACCT_CASE] = [
                'due_date' => $duedate,
                'id' => $case->ACCT_CASE,
                'active' => $case->active,
                'unworked' => $case->unworked,
                'worked' => $case->worked,
            ];
        }
        
        return view('corporateAdmin.pages.reports.overallActiveCasePerformance')->with('data', $finalData);
    }
}
