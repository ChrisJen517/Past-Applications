<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\ExportQueue;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Team;
use Auth;
use DB;
use Excel;

class CasePerformanceByTeamController extends Controller
{
    public function teamCases(){
        $finalData = $this->getData();

        return view('corporateAdmin.pages.reports.casePerformanceByTeam')->with('teams', $finalData);
    }

    public function getData(){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->get();

        $activeAccounts = Active_Account::SELECT(DB::RAW('
            active_accounts.TEAM_ID,
            active_accounts.ACCT_CASE, 
            active_accounts.ACCT_DUE_DATE,
            COUNT(active_accounts.ID) AS active,
            COUNT(IF(active_accounts.LAST_WORKED IS NULL, 1, NULL)) AS unworked
            '))
            ->where('CORPORATION_ID', $corporation_id)
            ->whereNotNull('ACCT_CASE')
            ->groupBy('ACCT_CASE')
            ->groupBy('TEAM_ID')
            ->get();

        $inactiveAccounts = Inactive_Account::SELECT(DB::RAW('
            inactive_accounts.TEAM_ID,
            inactive_accounts.ACCT_CASE, 
            inactive_accounts.ACCT_DUE_DATE,
            COUNT(inactive_accounts.ID) AS closed,
            COUNT(IF(capcodes.type = "verified", 1, NULL)) AS verified,
            COUNT(IF(capcodes.type = "unverified", 1, NULL)) AS unverified
            '))
            ->leftJoin('capcodes', function ($join) {
                $join->on('inactive_accounts.CAPCODE', '=', 'capcodes.id');
            })
            ->where('inactive_accounts.CORPORATION_ID', $corporation_id)
            ->whereNotNull('ACCT_CASE')
            ->groupBy('ACCT_CASE')
            ->groupBy('TEAM_ID')
            ->get();

        $finalData = [];
        foreach($teams as $team){
            $teamActives = $activeAccounts->where('TEAM_ID', $team->team_id);
            $teamInactives = $inactiveAccounts->where('TEAM_ID', $team->team_id);
            if(empty($teamActives) && empty($teamInactives))
                continue;

            //sets the team
            $finalData[] = [
                'team' => $team->name,
                'teamId' => $team->team_id,
                'cases' => $this->getCasesCount($teamActives, $teamInactives),
            ];
        }

        return $finalData;
    }

    //orders the cases and gets the proper counts
    public function getCasesCount($activeAccounts, $inactiveAccounts){
        $cases = [];
        //gets the counts of the active accounts
        foreach($activeAccounts as $active){
            $cases[$active->ACCT_CASE] = [
                'case' => $active->ACCT_CASE,
                'duedate' => $active->ACCT_DUE_DATE,
                'unworked' => $active->unworked,
                'active' => $active->active,
                'verified' => 0,
                'unverified' => 0,
                'closed' => 0
            ];
        }
        //gets the inactive accounts
        foreach($inactiveAccounts as $inactive){
            if(array_key_exists($inactive->ACCT_CASE, $cases)){
                $cases[$inactive->ACCT_CASE]['verified'] += $inactive->verified;
                $cases[$inactive->ACCT_CASE]['unverified'] += $inactive->unverified;
                $cases[$inactive->ACCT_CASE]['closed'] += $inactive->closed;
            }
            else{
                $cases[$inactive->ACCT_CASE] = [
                    'case' => $inactive->ACCT_CASE,
                    'duedate' => $active->ACCT_DUE_DATE,
                    'unworked' => 0,
                    'active' => 0,
                    'verified' => $inactive->verified,
                    'unverified' => $inactive->unverified,
                    'closed' => $inactive->closed
                ];
            }
        }
        return $cases;
    }

    //exports the accounts as an excel
    public function getTeamExport($teamId, $case){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $team = Team::select('team_id', 'name', 'corporation_id')->where('corporation_id', $corporation_id)->where('team_id', $teamId)->where('is_deactivated', 0)->first();

        if(empty($team))
            return back()->with('error', 'That team is not an active team in your corporation');

        $export = new ExportQueue($this->teamQueue($teamId, $case));
        $file = 'Case_performance_for:'.$team->name . '-' . $case . '.xlsx';
        return Excel::download($export, $file);
    }

    //gets the accounts put into a proper array
    public function teamQueue($teamId, $case){
        $accessList = [];
        if (!empty(Auth::user()->has_access)) {
            $user_access = DB::Select(DB::Raw('Select shortcode from access_levels where id in(' . Auth::user()->has_access . ')'));

            foreach ($user_access as $access) {
                $accessList[] = strtoupper($access->shortcode);
            }
        }
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $capcodes = Capcode::select('id', 'capcode')->where('corporation_id', $corporation_id)->get();
       
        $accounts = Active_Account::select('ID','ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
            'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
            'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR',
            'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE',
            'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER', 'ACCESS_RULES')
            ->where('TEAM_ID', $teamId)->where('ACCT_CASE', $case)
            ->get();
        $filteredAccounts = $this->filterAccounts($accounts, $accessList, $capcodes);

        $accounts = Inactive_Account::select('ID','ADD_DATE', 'ADD_FILE', 'ADDED_BY', 'ACCT_CLIENT', 'TEAM_NAME', 'TEAM_ID', 'ACCT_AGENT', 'ACCT_CASE', 'ACCT_DUE_DATE',
            'ACCT_SSN', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'ACCT_AD1', 'ACCT_AD2', 'ACCT_CITY', 'ACCT_ST', 'ACCT_ZIP', 'ACCT_DOB',
            'ACCT_ID', 'ACCT_SOURCE', 'EMPL_NAME', 'EMPL_ADDR1', 'EMPL_ADDR2', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_HR_ADDR',
            'EMPL_PHONE1_NMBR', 'EMPL_PH_SOURCE', 'EMPL_FAX', 'EMPL_EMAIL', 'EMPL_TITLE', 'EMPL_CONTACT', 'EMPL_CONTACT_TITLE', 'CAPCODE',
            'LAST_WORKED', 'LAST_COMMENTS', 'TIME_ZONE', 'TEAM_RULE', 'POESCORE', 'EMPL_FILES', 'SECOND_CASE', 'REMINDER', 'ON_HOLD', 'TIER', 'ACCESS_RULES')
            ->where('TEAM_ID', $teamId)->where('ACCT_CASE', $case)
            ->get();
        
        $filteredAccounts = array_merge($filteredAccounts, $this->filterAccounts($accounts, $accessList, $capcodes));
        return $filteredAccounts;
    }

    //filters the accounts to remove those the user lacks access to
    public function filterAccounts($accounts, $accessList, $capcodes){
        $filteredAccounts = [];
        foreach($accounts as $account){
            $account->CAPCODE = $capcodes->where('id', $account->CAPCODE)->first()->capcode ?? $account->CAPCODE;
            if($account->ACCESS_RULES != null || $account->ACCESS_RULES != "")
            {
                $rule = explode(',', $account->ACCESS_RULES);
                foreach($rule as $r){
                    if(!in_array(strtoupper($r), $accessList))
                    {
                        continue;
                    }else{
                        $filteredAccounts[$account->ID] = $account;
                    }
                }
            }else{
                $filteredAccounts[$account->ID] = $account;
            }
        }
        return $filteredAccounts;
    }
}