<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Worked_History;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class TiersWorkedController extends Controller
{

    public function showSixMonthReport() {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $monthsDisplay = [];
        $monthsQuery = [];
        for ($i = 0; $i < 6; $i++) {
            $time = Carbon::now()->startOfMonth()->subMonths($i);
            $monthsDisplay[] = $time->format('M Y');
            $monthsQuery[] = $time->format('Y-m');
        }

        $monthsImploded = implode("','", $monthsQuery);
        $monthsImploded = "'" . $monthsImploded . "'";

        $selectStatement = "";
        for ($i = 1; $i <= 5; $i++) {
            $selectStatement .= "COUNT(IF(PINPOINT=0 AND TIER=$i, 1, NULL)) as WORKED_TIER_$i,
                                COUNT(IF(PINPOINT=1 AND TIER=$i, 1, NULL)) as OVERFLOW_TIER_$i,";
        }
        $selectStatement .= "DATE_FORMAT(CREATED_AT, '%Y-%m') as grp";

        $inactiveData = Inactive_Account::selectRaw($selectStatement)
        ->whereRaw("DATE_FORMAT(CREATED_AT, '%Y-%m') in ($monthsImploded) AND capcode is not NULL and corporation_id = $corporation_id")
        ->groupBy(DB::raw("DATE_FORMAT(CREATED_AT, '%Y-%m')"))
        ->orderBy('CREATED_AT')->get();

        $data = [];
        foreach($monthsQuery as $month) {
            if (empty($data[$month])) {
                $data[$month] = [
                    'WORKED_TIER_1' => 0,
                    'OVERFLOW_TIER_1' => 0,
                    'WORKED_TIER_2' => 0,
                    'OVERFLOW_TIER_2' => 0,
                    'WORKED_TIER_3' => 0,
                    'OVERFLOW_TIER_3' => 0,
                    'WORKED_TIER_4' => 0,
                    'OVERFLOW_TIER_4' => 0,
                    'WORKED_TIER_5' => 0,
                    'OVERFLOW_TIER_5' => 0,
                ];

                $inactiveTemp = $inactiveData->where('grp', $month)->first();

                foreach($data[$month] as $key => $value) {
                    if (!empty($inactiveTemp->$key))
                        $data[$month][$key] += $inactiveTemp->$key;
                }
            }
        }

        return view('corporateAdmin.pages.reports.tiersWorkedSixMonths')->with(compact("monthsDisplay", "monthsQuery", "data"));
    }

}
