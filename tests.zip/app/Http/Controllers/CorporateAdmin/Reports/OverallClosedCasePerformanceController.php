<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use Illuminate\Http\Request;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use DB;

class OverallClosedCasePerformanceController extends Controller
{
    public function overallClosedCasePerformance(Request $request)
    {
        if($request->from == null)
            $startTime = date("Y-m-d", strtotime("-1 week"));
        else
            $startTime = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $endTime = date("Y-m-d");
        else
            $endTime = date('Y-m-d', strtotime($request->to));

        $message = "from ".$startTime." to ".$endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $companyCapcodes = Capcode::where('corporation_id', $corporation_id)->get();
        $verifieds = $companyCapcodes->where('type', 'verified');
        $unverifieds = $companyCapcodes->where('type', 'unverified');
        $inconclusives = $companyCapcodes->where('type', 'inconclusive');
 
        $verifiedArray = array();
        $unverifiedArray = array();
        $inconclusiveArray = array();
        foreach ($verifieds as $verified) {
            $verifiedArray[] = $verified->id;
        }
        $verifiedArray = (implode(", ", $verifiedArray));
        foreach ($unverifieds as $unverified) {
            $unverifiedArray[] = $unverified->id;
        }
        $unverifiedArray = (implode(", ", $unverifiedArray));
        foreach ($inconclusives as $inconclusive) {
            $inconclusiveArray[] = $inconclusive->id;
        }
        $inconclusiveArray = (implode(", ", $inconclusiveArray));

   
        $inactiveAccounts = Inactive_Account::SELECT(DB::RAW('ACCT_CASE, ACCT_DUE_DATE,
            COUNT(IF(inactive_accounts.CAPCODE IN (' . $verifiedArray . '), 1, NULL)) AS verified,
            COUNT(IF(inactive_accounts.CAPCODE IN (' . $unverifiedArray . '),1,null)) AS unverified,
            COUNT(IF(inactive_accounts.CAPCODE IN (' . $inconclusiveArray . '),1,null)) AS inconclusive,
            COUNT(IF(inactive_accounts.CAPCODE IS NOT NULL, 1, NULL)) AS closed'))
            ->where('CORPORATION_ID', $corporation_id)
            ->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime)
            ->groupBy('ACCT_CASE')
            ->get();

        $finalData = [];
        foreach ($inactiveAccounts as $case) {
            $duedate = $case->ACCT_DUE_DATE ?? '';
            if($duedate != '')
                $duedate = date("Y-m-d", strtotime($duedate));

            $finalData[$case->ACCT_CASE] = [
                'due_date' => $duedate,
                'id' => $case->ACCT_CASE,
                'closed' => $case->closed,
                'verified' => $case->verified,
                'unverified' => $case->unverified,
                'inconclusive' => $case->inconclusive,
            ];
        }
        
        return view('corporateAdmin.pages.reports.overallClosedCasePerformance')->with('data', $finalData)->with('timeMessage', $message);
    }
}