<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Capcode;
use App\Models\Inactive_Account;
use App\Traits\DateUtils;
use App\Models\Worked_History;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;
use Carbon\CarbonPeriod;

class HitsByTeamController extends Controller
{
    use DateUtils;

    public function dailyHits(Request $request)
    {
        $day = $request->day;

        if ($day == null)
            $day = Carbon::now()->format('Y-m-d');
        else
            $day = Carbon::parse($day)->format('Y-m-d');

        $hitData = $this->getData($day, $day);

        $teamsCount = count($hitData->data);

        return view('corporateAdmin.pages.reports.dailyHitsByTeam')
            ->with('data', $hitData->data)->with('totalData', $hitData->totalData)
            ->with('timeMessage', $hitData->timeMessage)->with('teamsCount', $teamsCount);
    }

    public function dailyTeamReport()
    {
        $corporationId = Auth::user()->corporate_admin_link->corporation_id;
        $yesterday = Carbon::yesterday()->format('Y-m-d');
        $yesterdayData = $this->getData($yesterday, $yesterday);

        $today = Carbon::now()->format('Y-m-d');
        $todayData = $this->getData($today, $today);

        return view('corporateAdmin.pages.reports.dailyTeamReport')
            ->with('yesterdayData', $yesterdayData->data)->with('yesterdayTotal', $yesterdayData->totalData)->with('yesterday', $yesterday)->with('yesterdayCallCount', $yesterdayData->agentCallCount)
            ->with('todayData', $todayData->data)->with('todayTotal', $todayData->totalData)->with('today', $today)->with('todayCallCount', $todayData->agentCallCount)
            ->with('corporationId', $corporationId);
    }

    public function monthlyHits(Request $request)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);
        $month = $request->month;

        if ($month != null) {
            $parsed = Carbon::parse($month);
            $startDay = $parsed->format('Y-m-01');
            if ($parsed->format('Y-m') == Carbon::now()->format('Y-m'))
                $endDay = Carbon::now()->format('Y-m-d');
            else
                $endDay = $parsed->endOfMonth()->format('Y-m-d');
        } else {
            $startDay = Carbon::now()->format('Y-m-01');
            $endDay = Carbon::now()->format('Y-m-d');
        }

        $dayDifference = $this->getWorkingDays($startDay, $endDay);

        $hitData = $this->getData($startDay, $endDay);

        $teamsCount = count($hitData->data);

        return view('corporateAdmin.pages.reports.monthlyHitsByTeam')->with('data', $hitData->data)->with('totalData', $hitData->totalData)->with('timeMessage', $hitData->timeMessage)->with('dayDifference', $dayDifference)->with('teamsCount', $teamsCount);
    }

    public function verifiedHitsMonthlySpreadByTeam(Request $request)
    {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::select('name', 'deactivate_date', 'team_id', 'is_deactivated')->where('created_at', '<', Carbon::now()->addDay())->where('corporation_id', $corporation_id)->orderBy('team_id', 'ASC')->get();

        if ($request->from == null && $request->to == null) {
            $startDay = Carbon::now()->firstOfMonth()->subMonths(5);
            $endDay = Carbon::now()->lastOfMonth();
        } else if ($request->from != null && $request->to == null) {
            $startDay = Carbon::parse($request->from)->firstOfMonth();
            $endDay = Carbon::parse($startDay)->lastOfMonth();
        } else if ($request->from == null && $request->to != null) {
            $endDay = Carbon::parse($request->to)->lastOfMonth();
            $startDay = Carbon::parse($endDay)->firstOfMonth();
        } else {
            $startDay = Carbon::parse($request->from)->firstOfMonth();
            $endDay = Carbon::parse($request->to)->lastOfMonth();
        }

        if ($endDay->diffInMonths($startDay) > 12) {
            $endDay = Carbon::parse($request->from)->addMonths(11)->lastOfMonth();
            $months = $this->getPeriodListFromDate($startDay, '1 month', $endDay, 'M Y', 12);
        } else if ($endDay->diffInMonths($startDay) >= 1) {
            $months = $this->getPeriodListFromDate($startDay, '1 month', $endDay, 'M Y', 12);
        } else
            $months = array(Carbon::parse($startDay)->format('M Y'));


        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'verified')->get();
        $verifiedCapcodes = [];
        foreach ($capcodes as $capcode) {
            $verifiedCapcodes[] = $capcode->id;
        }

        $agents = Agent::select('user_id', 'agent_id', 'team_id')->where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', Carbon::now()->addDay())->get();
        $corporationAgents = [];
        foreach ($agents as $agent) {
            if (($agent->user_link->deactivate_date < $startDay) && ($agent->user_link->is_deactivated == 1))
                continue;
            $corporationAgents[] = $agent->agent_id;
        }

        if ($corporation_id == 2) {
            $corporationAgents[] = 1901;
            $corporationAgents[] = 1902;
            $corporationAgents[] = 1904;
        }

        $verifiedHits = Inactive_Account::select(DB::RAW("count(*) as total, DATE_FORMAT(LAST_WORKED, '%b %Y') as grp, team_id"))
            ->whereIn('CAPCODE', $verifiedCapcodes)
            ->whereIn('ACCT_AGENT', $corporationAgents)
            ->where('LAST_WORKED', '>', $startDay)
            ->where('LAST_WORKED', '<', $endDay)
            ->orderBy(DB::RAW("YEAR(LAST_WORKED), MONTH(LAST_WORKED)"), "DESC")
            ->groupBy(DB::RAW("YEAR(LAST_WORKED), MONTH(LAST_WORKED), team_id"))->get();

        $data = $this->getDataSpread($teams, $startDay, $verifiedHits);

        return view('corporateAdmin.pages.reports.verifiedHitsByTeamMonthlySplit')->with('widths', 80 / count($months))->with('data', $data->arrangedData)->with('months', $months)->with('totals', $data->totals)->with('totalVerified', $data->totalVerifiedCount);
    }

    public function thirtyDaysVerifiedHits()
    {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::select('name', 'deactivate_date', 'team_id', 'is_deactivated')->where('created_at', '<', Carbon::now()->addDay())->where('corporation_id', $corporation_id)->orderBy('team_id', 'ASC')->get();

        $startDay = Carbon::now()->subMonths(1);
        $days = $this->getPeriodListFromDate($startDay, '1 day', Carbon::now(), 'm/d', 31);

        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'verified')->get();
        $verifiedCapcodes = [];
        foreach ($capcodes as $capcode) {
            $verifiedCapcodes[] = $capcode->id;
        }

        $agents = Agent::select('user_id', 'agent_id', 'team_id')->where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', Carbon::now()->addDay())->get();
        $corporationAgents = [];
        foreach ($agents as $agent) {
            if (($agent->user_link->deactivate_date < $startDay) && ($agent->user_link->is_deactivated == 1))
                continue;
            $corporationAgents[] = $agent->agent_id;
        }

        if ($corporation_id == 2) {
            $corporationAgents[] = 1901;
            $corporationAgents[] = 1902;
            $corporationAgents[] = 1904;
        }

        $verifiedHits = Inactive_Account::select(DB::RAW("count(*) as total, DATE_FORMAT(LAST_WORKED, '%m/%d') as grp, team_id"))
            ->whereIn('CAPCODE', $verifiedCapcodes)
            ->whereIn('ACCT_AGENT', $corporationAgents)
            ->where('LAST_WORKED', '>', $startDay)
            ->where('LAST_WORKED', '<', Carbon::now()->addDay())
            ->orderBy(DB::RAW("MONTH(LAST_WORKED), DAY(LAST_WORKED)"), "DESC")
            ->groupBy(DB::RAW("DAY(LAST_WORKED), MONTH(LAST_WORKED), team_id"))->get();

        $data = $this->getDataSpread($teams, $startDay, $verifiedHits);
        return view('corporateAdmin.pages.reports.verifiedHitsByTeamDailySplit')->with('data', $data->arrangedData)->with('amountOfGroups', count($verifiedHits))->with('days', $days)->with('totals', $data->totals)->with('totalVerified', $data->totalVerifiedCount);
    }

    public function getDataSpread($teams, $startDay, $verifiedHits)
    {
        foreach ($teams as $team) {
            if (($team->deactivate_date < $startDay) && ($team->is_deactivated == 1))
                continue;
            $teamHits = $verifiedHits->where('team_id', $team->team_id);
            $data[] = [
                'name' => $team->name,
                'hits' => $teamHits
            ];
        }

        $arrangedData = [];
        $totals = [];
        $totalVerifiedCount = 0.0;
        foreach ($data as $dataPoint) {
            $teamName = $dataPoint['name'];
            $hits = $dataPoint['hits'];
            foreach ($hits as $hit) {
                $arrangedData[$teamName][$hit->grp] = $hit->total;

                if (empty($totals[$hit->grp]))
                    $totals[$hit->grp] = $hit->total;
                else
                    $totals[$hit->grp] += $hit->total;

                $totalVerifiedCount += $hit->total;
            }
            $arrangedData[$teamName]['name'] = $teamName;
        }

        $returnObject = new \stdClass;
        $returnObject->totalVerifiedCount = $totalVerifiedCount;
        $returnObject->totals = $totals;
        $returnObject->arrangedData = $arrangedData;
        return $returnObject;
    }

    public function getData($startDay, $endDay)
    {
        if ($startDay == $endDay)
            $timeMessage = 'on ' . $startDay;
        else
            $timeMessage = 'from ' . $startDay . ' to ' . $endDay;

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::select('name', 'deactivate_date', 'team_id', 'is_deactivated')
            ->where('created_at', '<', Carbon::parse($endDay)->addDay())
            ->where('corporation_id', $corporation_id)->orderBy('team_id', 'ASC')->get();

        $agents = Agent::select('user_id', 'agent_id', 'team_id')->where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', Carbon::parse($endDay)->addDay())->get();
        $corporationAgents = [];
        foreach ($agents as $agent) {
            if (($agent->user_link->deactivate_date < $startDay) && ($agent->user_link->is_deactivated == 1))
                continue;
            $corporationAgents[] = $agent->agent_id;
        }

        if ($corporation_id == 2) {
            $corporationAgents[] = 1901;
            $corporationAgents[] = 1902;
            $corporationAgents[] = 1904;
        }

        $data = [];
        $totalVerified = 0.0;
        $totalAgents = 0.0;
        $totalAccountsWorked = 0.0;
        $totalHitsPerAgent = 0.0;
        $totalAverage = 0;

        $verifiedHitsQuery = Inactive_Account::select(DB::RAW('count(*) as total, team_id'))
            ->join('capcodes', 'inactive_accounts.capcode', '=', 'capcodes.id')
            ->where('type', 'verified')
            ->whereIn('ACCT_AGENT', $corporationAgents)
            ->where('LAST_WORKED', '>', $startDay)
            ->where('LAST_WORKED', '<', date($endDay . '+1 day'))
            ->groupBy('team_id')->get();

        $agentCallCount = [];
        foreach ($teams as $team) {
            if (($team->deactivate_date < $startDay) && ($team->is_deactivated == 1))
                continue;

            $verifiedHits = $verifiedHitsQuery->where('team_id', $team->team_id)->first();

            if (empty($verifiedHits)) {
                $verifiedHits = new \stdClass;
                $verifiedHits->total = 0;
            }

            $agentsOnTeam = $agents->where('team_id', $team->team_id);
            if ($team->team_id == 10) {
                $agentsOnTeam = [1901, 1902, 1904];
            } else {
                $agentsOnTeam = $agentsOnTeam->map->only('agent_id')->toArray();
            }

            $callCapcode = Capcode::select('id')->where('corporation_id', $corporation_id)->where('capcode', '2210')->first()->id;
            $workedHistory = Worked_History::select('active_account_id', 'agent_id', 'created_at', 'capcode')->whereIn('agent_id', $agentsOnTeam)
                ->where('created_at', '>', $startDay)
                ->where('created_at', '<', date($endDay . '+1 day'));

            $multiCallWorkHistory = $workedHistory->get();
            $workedHistory = $workedHistory->groupBy('active_account_id')->get();

            $mappedAccountIds = $workedHistory->map->only('active_account_id');
            $inactiveScores = Inactive_Account::select(DB::raw('avg(POESCORE) as score'))->whereIn('ID', $mappedAccountIds)->first();
            $activeScores = Active_Account::select(DB::raw('avg(POESCORE) as score'))->whereIn('ID', $mappedAccountIds)->first();
            $workedHistoryCount = $workedHistory->count();

            $activeAgentsByDay = $workedHistory->map->only('agent_id', 'created_at')
                ->groupBy(function ($date) {
                    return Carbon::parse($date['created_at'])->format('m-d-Y'); // ? Groups by day so that I can get an accurate count of daily active agents
                })->unique();

            $agentCount = 0;
            $agentsSeen = [];
            foreach ($activeAgentsByDay as $day) {
                foreach ($day as $entry) {
                    $agentId = $entry['agent_id'];
                    if (in_array($agentId, $agentsSeen)) continue;
                    else {
                        $agentsSeen[] = $agentId;

                        $agent = $agents->where('agent_id', $agentId)->first();
                        if (empty($agent))
                            continue;

                        $agentCallCount[] = [
                            'id' => $agentId,
                            'team' => $teams->where('team_id', $agent->team_id)->first()->name,
                            'name' => $agent->user_link->first_name . ' ' . $agent->user_link->last_name,
                            'dials' => $multiCallWorkHistory->where('agent_id', $agentId)->where('capcode', $callCapcode)->count()
                        ];
                        $agentCount++;
                    }
                }
                $agentsSeen = []; // Clear the array of seen agents after that day has been iterated.
            }

            if ($agentCount > 0)
                $totalHitsPerAgent += ($verifiedHits->total / $agentCount);

            $totalVerified += $verifiedHits->total;
            $totalAgents += $agentCount;
            $totalAccountsWorked += $workedHistoryCount;

            $averageScore = $inactiveScores->score + $activeScores->score;
            if ($inactiveScores->score != 0 &&  $activeScores->score != 0)
                $averageScore /= 2;
            if (empty($averageScore))
                $averageScore = 0;

            if ($totalAverage == 0)
                $totalAverage = $averageScore;
            else if ($averageScore != 0)
                $totalAverage = ($totalAverage + $averageScore) / 2;

            $data[] = [
                'name' => $team->name,
                'verified' => $verifiedHits->total,
                'worked' => $workedHistoryCount,
                'agents' => $agentCount,
                'averageScore' => round($averageScore, 0)
            ];
        }

        $totalData = [
            'verified' => $totalVerified,
            'worked' => $totalAccountsWorked,
            'agents' => $totalAgents,
            'hitsPerAgent' => $totalHitsPerAgent,
            'averageScore' => round($totalAverage, 0)
        ];

        $returnObject = new \stdClass;
        $returnObject->data = $data;
        $returnObject->totalData = $totalData;
        $returnObject->timeMessage = $timeMessage;
        $returnObject->agentCallCount = $agentCallCount;

        return $returnObject;
    }

    public function getPeriodListFromDate(Carbon $start, $interval, Carbon $end, $format, $maxAmount)
    {
        foreach (CarbonPeriod::create($start, $interval, $end) as $period) {
            $periods[] = $period->format($format);
        }
        $months = array_slice($periods, 0, $maxAmount);
        return $months;
    }
}
