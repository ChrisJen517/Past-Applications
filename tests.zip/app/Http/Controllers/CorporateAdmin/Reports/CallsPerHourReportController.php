<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Account_Source;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Distribution_Rules;
use App\Models\Team;
use App\User;
use Auth;
use DB;
use DateTime;
use App\Models\Activity_Log;
use App\Models\Worked_History;
use Carbon\Carbon;

class CallsPerHourReportController extends Controller
{
    public function callsPerHour(){
        $finalData = $this->getData( date('Y-m-d', strtotime('today')), date('Y-m-d', strtotime('tomorrow')));

        $message = "from today";

        return view('corporateAdmin.pages.reports.callsPerHourReporting')->with('calls', $finalData)->with('timeMessage', $message);
    }

    public function callsPerHourTime(Request $request){
        if($request->from == null){
            $startTime = date('Y-m-d', strtotime('today'));
            $endTime = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $startTime = date('Y-m-d', strtotime($request->from));
            $endTime = date('Y-m-d', strtotime($request->from.' +1 day'));
        }

        $finalData = $this->getData( $startTime, $endTime);
        $message = "from ".$startTime;

        return view('corporateAdmin.pages.reports.callsPerHourReporting')->with('calls', $finalData)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $agents = Agent::where('corporation_id', $corporation_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();

        $callCode = Capcode::where('corporation_id', $corporation_id)->where('capcode', 2210)->first()->id;

        if($agents->first() == null)
            return $finalData = null;

        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $userIds[] = $agent->user_link->user_id;
            $agentIds[] = $agent->agent_id;
        }

        //gets all accounts in the time frame that have an agent
        $history = Worked_History::whereIn('agent_id', $agentIds)->where('created_at', '>', $day)
        ->where('created_at', '<', $dayAfter)->where('user_role', 'agent')->where('capcode', $callCode )->select('agent_id')->get();

        $teams = Team::where('corporation_id', $corporation_id)->where('created_at', '<', $dayAfter)->select('team_id', 'name', 'deactivate_date', 'is_deactivated')->get();
        $teamData = [];
        foreach($teams as $team){
            if(($team->deactivate_date < $day) && ($team->is_deactivated == 1))
                continue;

            $teamData[$team->team_id] =[
                'name' => $team->name,
                'id' => $team->team_id,
                'callPerHour' => 0,
            ];

            $teamIds[] = $team->team_id;
        }
        //*******CODE IS COMMENTED OUT UNTIL ACTIVITY LOGS ISSUE IS FIXED ***************/


        //gets all of the log ins
        // $activity = Activity_Log::whereIn('user_id', $userIds)->where('UPDATED_AT', '>', $day)->where('UPDATED_AT', '<', $dayAfter)->get();

        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            if (!in_array($agent->team_id, $teamIds))
                continue;

        //     $totalLogins = $activity->where('user_id', $agent->user_link->user_id);

        //     $hours = 0;
        //     $minutes = 0;
        //     $seconds = 0;
        //     foreach($totalLogins as $login){
        //         if($login->total_time != null){
        //             $hours = $hours + intval(date('H', strtotime($login->total_time)));
        //             $minutes = $minutes + intval(date('i', strtotime($login->total_time)));
        //             $seconds = $seconds + intval(date('s', strtotime($login->total_time)));
        //         }
        //     }
        //     $minutes = $minutes + ($seconds/60);
        //     $hours =  $hours + ($minutes/60);

            $CallPerHour = count($history->where('agent_id', $agent->agent_id));

        //     if($hours != 0)
            $dayParsed = Carbon::parse($day);
            if ($dayParsed->isToday()) {
                $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
                $hoursSinceStart = $minutesSinceStart/60;
                if ($hoursSinceStart > 8 || $hoursSinceStart < 0)
                    $hoursSinceStart = 8;
            } else
                $hoursSinceStart = 8;

            if($hoursSinceStart != 0)
                $CallPerHour = round($CallPerHour / $hoursSinceStart, 2);
            else
                $CallPerHour = 0;

            $agentData[$agent->agent_id] =[
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'id' => $agent->agent_id,
                'teamName' => $teamData[$agent->team_id]['name'],
                'callPerHour' => $CallPerHour,
            ];
            $teamData[$agent->team_id]['callPerHour'] += $CallPerHour;
        }

        $finalData[] = $agentData;
        $finalData[] = $teamData;

        return $finalData;
    }
}
