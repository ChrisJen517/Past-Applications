<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Team;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Worked_History;
use Auth;

class AgentReportingController extends Controller
{
    public function agentReport(){
        $day = date('Y-m-d', strtotime('today'));
        $dayAfter = date('Y-m-d', strtotime('tomorrow'));
        $finalData = $this->getData($day, $dayAfter);

        $message = "from today";

        $teams = Team::where('corporation_id', Auth::user()->corporate_admin_link->corporation_id)->where('created_at', '<', $dayAfter)
        ->where(function($q) use ($day){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($day) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $day );}); })
        ->select('team_id', 'name')->get();
        
        return view('corporateAdmin.pages.reports.agentReporting')->with('agents', $finalData)->with('timeMessage', $message)->with('teams', $teams);
    }

    public function agentReportTime(Request $request){
        if($request->from == null){
            $day = date('Y-m-d', strtotime('today'));
            $dayAfter = date('Y-m-d', strtotime('tomorrow'));
        }
        else{
            $day = date('Y-m-d', strtotime($request->from));
            $dayAfter = date('Y-m-d', strtotime($request->from.' +1 day'));
        }

        $teams = Team::where('corporation_id', Auth::user()->corporate_admin_link->corporation_id)->where('created_at', '<', $dayAfter)
        ->where(function($q) use ($day){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($day) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $day );}); })
        ->select('team_id', 'name')->get();

        $finalData = $this->getData( $day, $dayAfter);
        $message = "from ".$day;
        
        return view('corporateAdmin.pages.reports.agentReporting')->with('agents', $finalData)->with('timeMessage', $message)->with('teams', $teams);
    }


    public function getData($day, $dayAfter){
        //gets list of verified capcodes
        $capcodes = Capcode::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)
        ->where('type', 'verified')->select('capcode', 'id')->get();

        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        $agents = Agent::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->where('created_at', '<', $dayAfter)->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();
        $teams = Team::where('corporation_id', Auth::user()->corporate_admin_link->corporation_id)->where('created_at', '<', $dayAfter)
        ->where(function($q) use ($day){ $q->where('is_deactivated', 0)->orwhere(function($q) use ($day) { $q->where('is_deactivated', 1)->where('deactivate_date', '>', $day );}); })
        ->select('team_id', 'name')->get();

        if($agents->first() == null)
            return $finalData = null;

        $agentArray = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;
            $agentArray[] = $agent->agent_id;
        }

        //gets the number of unique accounts worked for an agent
        $uniquesWorked = Worked_History::selectRaw('count(DISTINCT active_account_id) as work_count, agent_id')->whereIn('agent_id', $agentArray)->where('created_at', '>', $day)->where('created_at', '<', $dayAfter)
        ->groupBy('agent_id')->get();

        //gets the accounts closed by an agent
        $inactiveAccounts = Inactive_Account::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)
        ->where('ACCT_AGENT', '!=', null)->where('CAPCODE', '!=', null)->select('CAPCODE', 'ACCT_AGENT')->get();

        $finalData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;

            $worked = $uniquesWorked->where('agent_id', $agent->agent_id)->first()->work_count ?? 0;

            $verified = count($inactiveAccounts->wherein('CAPCODE', $codes)->where('ACCT_AGENT', $agent->agent_id));
            $teamName = $teams->where('team_id', $agent->team_id)->first()->name ?? '';

            $finalData[$agent->agent_id] =[
                'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                'id' => $agent->agent_id,
                'teamName' => $teamName,
                'unique' => $worked,
                'verified' => $verified,
            ];
        }

        return $finalData;
    }
}