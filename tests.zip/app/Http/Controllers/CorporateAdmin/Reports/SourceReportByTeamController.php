<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use App\Models\Team;
use Illuminate\Http\Request;

class SourceReportByTeamController extends Controller
{
    public function sourceReport(Request $request){
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        $message = "from " . $startTime . " to " . $endTime;
        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));
        $finalData = $this->getData($startTime, $endTime);

        return view('corporateAdmin.pages.reports.sourceReportByTeam')->with('sources', $finalData)->with('timeMessage', $message);
    }

    public function getData($startTime, $endTime){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $teams = Team::where('corporation_id', $corporation_id)->where('created_at', '<', $endTime)->get();
        $neededTeams = [];
        foreach($teams as $team){
            if(($team->deactivate_date < $startTime) && ($team->is_deactivated == 1))
                continue;
            $neededTeams[] = $team->team_id;
        }

        $activeAccounts = Active_Account::
            selectRaw('count(IF(type = "inconclusive",1,null)) as inconclusive, count(IF(LAST_WORKED is null,1,null)) as unworked, ACCT_SOURCE, TEAM_ID, TEAM_NAME')
            ->where('active_accounts.corporation_id', $corporation_id)
            ->where(function ($q) use ($startTime, $endTime) {
                $q->whereRaw('(LAST_WORKED > "'.$startTime.'" AND LAST_WORKED < "'.$endTime.'")');
                $q->orwhere('LAST_WORKED', null);
            })->leftJoin('capcodes', function ($join) {
                $join->on('active_accounts.CAPCODE', '=', 'capcodes.id');
            })->groupBy('ACCT_SOURCE', 'TEAM_ID')->get();

        $inactiveAccounts = Inactive_Account::
            selectRaw('count(IF(type = "inconclusive",1,null)) as inconclusive, count(IF(type = "unverified",1,null)) as unverified, count(IF(type = "verified",1,null)) as verified, ACCT_SOURCE, TEAM_ID, TEAM_NAME')
            ->where('inactive_accounts.corporation_id', $corporation_id)
            ->where(function ($q) use ($startTime, $endTime) {
                $q->whereRaw('(LAST_WORKED > "'.$startTime.'" AND LAST_WORKED < "'.$endTime.'")');
                $q->orwhere('LAST_WORKED', null);
            })->leftJoin('capcodes', function ($join) {
                $join->on('inactive_accounts.CAPCODE', '=', 'capcodes.id');
            })->groupBy('ACCT_SOURCE', 'TEAM_ID')->get();

        $finalData = [];
        foreach($neededTeams as $team){
            //gets all accounts for the team, if none skips the team
            $teamActives = $activeAccounts->where('TEAM_ID', $team);
            $teamInactives = $inactiveAccounts->where('TEAM_ID', $team);
            if(empty($teamActives) && empty($teamInactives))
                continue;

            $name = $teamActives->first()->TEAM_NAME ?? $teamInactives->first()->TEAM_NAME ?? 'N/A';

            //sets the team
            $finalData[] = [
                'team' => $name,
                'sources' => $this->getSourcesCount($teamActives, $teamInactives),
            ];
        }

        //gets no team assigned 
        $teamActives = $activeAccounts->where('TEAM_ID', null);
        $teamInactives = $inactiveAccounts->where('TEAM_ID', null);
        if(!empty($teamActives) && !empty($teamInactives)){
            $finalData[] = [
                'team' => 'Unassigned',
                'sources' => $this->getSourcesCount($teamActives, $teamInactives),
            ];
        }

        return $finalData;
    }

    //orders the sources and gets the proper counts
    public function getSourcesCount($activeAccounts, $inactiveAccounts){
        $sources = [];
        //gets the counts of the active accounts
        foreach($activeAccounts as $active){
            $sources[$active->ACCT_SOURCE] = [
                'source' => $active->ACCT_SOURCE,
                'unworked' => $active->unworked,
                'inconclusive' => $active->inconclusive,
                'verified' => 0,
                'unverified' => 0
            ];
        }
        //gets the inactive accounts
        foreach($inactiveAccounts as $inactive){
            if(array_key_exists($inactive->ACCT_SOURCE, $sources)){
                $sources[$inactive->ACCT_SOURCE]['verified'] += $inactive->verified;
                $sources[$inactive->ACCT_SOURCE]['unverified'] += $inactive->unverified;
                $sources[$inactive->ACCT_SOURCE]['inconclusive'] += $inactive->inconclusive;
            }
            else{
                $sources[$inactive->ACCT_SOURCE] = [
                    'source' => $inactive->ACCT_SOURCE,
                    'unworked' => 0,
                    'inconclusive' => $inactive->inconclusive,
                    'verified' => $inactive->verified,
                    'unverified' => $inactive->unverified
                ];
            }
        }
        return $sources;
    }
}