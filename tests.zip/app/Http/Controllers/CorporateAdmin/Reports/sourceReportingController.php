<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use DateTime;
use DB;
use Illuminate\Http\Request;

class sourceReportingController extends Controller
{
    public function sourceReport()
    {
        $finalData = $this->getData(date("Y-m-d", strtotime("-1 week")), new DateTime('tomorrow'));

        $message = "from the past 7 days";

        return view('corporateAdmin.pages.reports.sourceReporting')->with('sources', $finalData)->with('timeMessage', $message);
    }

    public function sourceReportTime(Request $request)
    {
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        $message = "from " . $startTime . " to " . $endTime;

        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));

        $finalData = $this->getData($startTime, $endTime);
        

        return view('corporateAdmin.pages.reports.sourceReporting')->with('sources', $finalData)->with('timeMessage', $message);
    }

    public function getData($startTime, $endTime)
    {
        //gets list of capcodes
        $capcodes = Capcode::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->select('capcode', 'id', 'type')->get();

        //gets all accounts
        $activeAccounts = Active_Account::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)
            ->where(function ($q) use ($startTime, $endTime) {
                $q->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime);
                $q->orwhere('LAST_WORKED', null);
            })->SELECT(DB::raw('count(*) as count, CAPCODE, ACCT_SOURCE'))->groupBy('ACCT_SOURCE', 'CAPCODE')->get();
        $sources = $activeAccounts->groupby('ACCT_SOURCE');

        $finalData = [];
        //gets all the current account metrics
        foreach ($sources as $source) {
            if ($source[0]->ACCT_SOURCE == null) {
                $source[0]->ACCT_SOURCE = "No Source";
            }

            //resets counters
            $unworked = 0;
            $inconclusive = 0;

            //for each capcode gets the type and adds it's count
            foreach ($source as $capcode) {

                if ($capcode->CAPCODE == null) {
                    $unworked = $unworked + $capcode->count;
                } else {

                    if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                        if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                            $type = $capcodes->where('id', $capcode->CAPCODE)->first()->type;
                        } else {
                            $type = 'N/A';
                        }

                    } else {
                        if (!empty($capcodes->where('capcode', $capcode->CAPCODE)->first())) {
                            $type = $capcodes->where('capcode', $capcode->CAPCODE)->first()->type;
                        } else {
                            $type = 'N/A';
                        }

                    }

                    if ($type == 'inconclusive') {
                        $inconclusive = $inconclusive + $capcode->count;
                    }

                }
            }

            //stores the accounts in the array
            $finalData[$source[0]->ACCT_SOURCE] = [
                'source' => $source[0]->ACCT_SOURCE,
                'unworked' => $unworked,
                'verified' => 0,
                'unverified' => 0,
                'inconclusive' => $inconclusive,
            ];
        }

        //gets the inactive accounts
        $inactiveAccounts = Inactive_Account::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)
            ->where(function ($q) use ($startTime, $endTime) {
                $q->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime);
            })->SELECT(DB::raw('count(*) as count, CAPCODE, ACCT_SOURCE'))->groupBy('ACCT_SOURCE', 'CAPCODE')->get();
        $sources = $inactiveAccounts->groupby('ACCT_SOURCE');

        foreach ($sources as $source) {
            if ($source[0]->ACCT_SOURCE == null) {
                $source[0]->ACCT_SOURCE = "No Source";
            }

            //makes sure this source exists in final data
            if (!array_key_exists($source[0]->ACCT_SOURCE, $finalData)) {
                $finalData[$source[0]->ACCT_SOURCE] = [
                    'source' => $source[0]->ACCT_SOURCE,
                    'unworked' => 0,
                    'verified' => 0,
                    'unverified' => 0,
                    'inconclusive' => 0,
                ];
            }

            //for each capcode gets the type and adds it's count
            foreach ($source as $capcode) {
                if ($capcode->CAPCODE != null) {
                    $type = 'unverified';
                    if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                        if (!empty($capcodes->where('id', $capcode->CAPCODE)->first())) {
                            $type = $capcodes->where('id', $capcode->CAPCODE)->first()->type;
                        } else {
                            $type = 'N/A';
                        }

                    } else {
                        if (!empty($capcodes->where('capcode', $capcode->CAPCODE)->first())) {
                            $type = $capcodes->where('capcode', $capcode->CAPCODE)->first()->type;
                        } else {
                            $type = 'N/A';
                        }
                    }

                    if ($type == 'unverified') {
                        $finalData[$source[0]->ACCT_SOURCE]['unverified'] = $finalData[$source[0]->ACCT_SOURCE]['unverified'] + $capcode->count;
                    } else if ($type == 'verified') {
                        $finalData[$source[0]->ACCT_SOURCE]['verified'] = $finalData[$source[0]->ACCT_SOURCE]['verified'] + $capcode->count;
                    }

                }
            }
        }

        return $finalData;
    }
}
