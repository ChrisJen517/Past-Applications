<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Team;
use Auth;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Traits\DateUtils;
use App\User;

class MtdReportingController extends Controller
{
    use DateUtils;

    public function showMtd(){
        $corporateAdmin = Auth::user()->corporate_admin_link;

        $start = date('Y-m-01');
        $end =  date("Y-m-d");
        $message = "from ".$start." to ".$end;

        $reportData = $this->getData($corporateAdmin, $start, date('Y-m-d' , strtotime($end.' +1 day')));
        $daysWorked = $this->getWorkingDays($start, $end);

        $agentData = $reportData[0];
        $teamData = $reportData[1];

        return view('corporateAdmin.pages.reports.mtdReporting')->with('teamData', $teamData)->with('agentData', $agentData)->with('daysWorked', $daysWorked)->with('timeMessage', $message);
    }


    public function getData($corporateAdmin, $startTime, $endTime){

        $startTime = date('Y-m-d H:i:s', strtotime($startTime));
        $endTime = date('Y-m-d H:i:s', strtotime($endTime));

        $agents = Agent::where('corporation_id', $corporateAdmin->corporation_id)->with('user_link')->select('agent_id','user_id', 'team_id', 'corporation_id', 'created_at')->get();
        
        $teams = Team::where('corporation_id', $corporateAdmin->corporation_id)->where('created_at', '<', $endTime)->select('team_goals', 'team_id', 'name', 'deactivate_date', 'is_deactivated')->get();
        $capcodes = Capcode::where('corporation_id', $corporateAdmin->corporation_id)->where('type', 'verified')->select('id')->get();
        $agentData = [];
        $teamData = [];
        //gets the user and agent ids as a list
        $userIds = [];
        $agentIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $userIds[] = $agent->user_id;
            $agentIds[] = $agent->agent_id;
        }

        //gets all capcodes into an array
        $codes = [];
        foreach($capcodes as $capcode){
            $codes[] = $capcode->id;
        }

        foreach($teams as $team){
            $teamData[$team->team_id] = [
                'name' => $team->name,
                'goal' =>  $team->team_goals,
                'verified' => 0,
                'agents' => 0,
            ];
        }


        //gets all of the agents worked accounts and
        $accounts = Inactive_Account::wherein('ACCT_AGENT', $agentIds)->wherein('CAPCODE', $codes)
        ->select('ACCT_AGENT', 'CAPCODE')->where('LAST_WORKED', '>', $startTime)->where('LAST_WORKED', '<', $endTime)->get();
        $users = User::wherein('user_id', $userIds)->select('first_name', 'last_name', 'user_id')->get();
        
        $agentData = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;

            $name = $users->where('user_id', $agent->user_id)->first();

            $verified = count($accounts->wherein('ACCT_AGENT', $agent->agent_id));

            $agentData[$agent->agent_id] = [
                'id' => $agent->agent_id,
                'name' => $name->first_name.' '.$name->last_name,
                'teamName' => $teamData[$agent->team_id]['name'],
                'goal' => $teamData[$agent->team_id]['goal'],
                'verified' => $verified,
            ];

            $teamData[$agent->team_id]['verified'] += $verified;
            $teamData[$agent->team_id]['agents']++;
        }

        //removes teams that dont exist durring timeframe
        foreach($teams as $team){
            if( ($team->deactivate_date < $startTime) && ($team->is_deactivated == 1))
                unset($teamData[$team->team_id]);
        }

        if(!isset($teamData))
            $teamData = [];

        $reportData[] = $agentData;
        $reportData[] = $teamData;

        return $reportData;
    }
}
