<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Account_Source;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Distribution_Rules;
use App\Models\Team;
use App\User;
use Auth;
use DB;
use App\Models\Activity_Log;
use Carbon\Carbon;

class AverageVerificationsController extends Controller
{
    public function averageVerifications(Request $request){
        if($request->from == null){
            $time = date('Y-m-d');
            $message = "From today";
        }
        else{
            $time = date('Y-m-d', strtotime($request->from));
            $message = "From ".$time;
        }

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $agents = Agent::where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', $time)->get();
        $teams = Team::where("corporation_id", $corporation_id)->get();

        $agentData = $this->getAgentData( $time, $corporation_id);

        //if the company has no agents
        if($agentData == 'empty')
            return view('corporateAdmin.pages.reports.averageVerifications')->with('agentData', null)->with('teamData', null);

        $agentArray = array();
        $teamArray = array();
        foreach($agentData as $item)
        {
            $teamName = $teams->where('team_id', $item->team_id)->first()->name ?? '';
            $agentArray[$item->ACCT_AGENT] =[ 
                'name' => $item->agent_name,
                'id' => $item->ACCT_AGENT,
                'teamName' => $teamName,
                'verifications' => $item->verifiedPerHour
            ];

            if(!array_key_exists($item->team_id, $teamArray)){
                $teamArray[$item->team_id] = array(
                    'name' => $teamName,
                    'id' => $item->team_id,
                    'verifications' => $item->verifiedPerHour
                );
            }
            else{
                $teamArray[$item->team_id]['verifications'] = $teamArray[$item->team_id]['verifications'] + $item->verifiedPerHour;
            }
        }

        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $time) && ($agent->user_link->is_deactivated == 1))
                continue;

            if(!array_key_exists($agent->agent_id, $agentArray)){
                $teamName = $teams->where('team_id', $agent->team_id)->first()->name ?? '';
                $agentArray[$agent->agent_id] = array(
                    'name' => $agent->user_link->first_name.' '.$agent->user_link->last_name,
                    'id' => $agent->agent_id,
                    'teamName' => $teamName,
                    'verifications' => '0.00'
                );
            }
        }

        foreach($teams as $team){
            if(!array_key_exists($team->team_id, $teamArray)){
                
                $teamArray[$team->team_id] = array(
                    'name' => $team->name,
                    'id' => $team->team_id,
                    'verifications' => '0.00'
                );
            }
        }

        //removes teams that dont exist durring timeframe
        foreach($teams as $team){
            if((($team->deactivate_date < $time) && ($team->is_deactivated == 1)) || ($team->created_at > date('Y-m-d', strtotime($time.' + 1 day'))))
                unset($teamArray[$team->team_id]);
        }

        if(!isset($teamArray))
            $teamArray = [];

        return view('corporateAdmin.pages.reports.averageVerifications')->with('agentData', $agentArray)->with('teamData', $teamArray)->with('timeMessage', $message);
    }

    public function getAgentData($day, $corporation_id){


        $data = DB::select( DB::raw("SELECT ACCT_AGENT, COUNT(if( CAPCODE IN (SELECT id FROM capcodes WHERE type = 'verified'), 1, null)) as verifiedPerHour
        FROM inactive_accounts
         where CORPORATION_ID = $corporation_id
         AND ACCT_AGENT IS NOT NULL
         AND ACCT_AGENT IN (SELECT agent_id from agents where user_id is not null)
         AND date(LAST_WORKED) = date('$day')
           GROUP BY ACCT_AGENT;"));
        
        $agents = Agent::where('corporation_id', $corporation_id)->where('created_at', '<', date('Y-m-d', strtotime($day.' + 1 day')))->with('user_link')->select('user_id', 'agent_id', 'team_id')->get();

        $userIds = [];
        foreach($agents as $agent){
            //if the agent was deactivated before the report skips them
            if(($agent->user_link->deactivate_date < $day) && ($agent->user_link->is_deactivated == 1))
                continue;
            if(empty($agent->user_link))
                continue;

            $userIds[] = $agent->user_link->user_id;
        }
        if(empty($userIds))
            return 'empty';


            //*******CODE IS COMMENTED OUT UNTIL ACTIVITY LOGS ISSUE IS FIXED ***************/

        //gets all of the log ins
        // $activity = Activity_Log::whereIn('user_id', $userIds)->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', date('Y-m-d',strtotime($day.' +1 day')))->get();



        foreach($data as $item)
        {


            $agent = $agents->where('agent_id', $item->ACCT_AGENT)->first();
            $item->agent_name = $agent->user_link->first_name." ".$agent->user_link->last_name;
            $item->team_id = $agent->team_id;

            // $totalLogins = $activity->where('user_id', $agent->user_link->user_id);


            // $hours = 0;
            // $minutes = 0;
            // $seconds = 0;
            // foreach($totalLogins as $login){
            //     if($login->total_time != null){
            //         $hours = $hours + intval(date('H', strtotime($login->total_time)));
            //         $minutes = $minutes + intval(date('i', strtotime($login->total_time)));
            //         $seconds = $seconds + intval(date('s', strtotime($login->total_time)));
            //     }
            // }
            // $minutes = $minutes + ($seconds/60);
            // $hours =  $hours + ($minutes/60);

            // if($hours != 0 )
            $dayParsed = Carbon::parse($day);
            if ($dayParsed->isToday()) {
                $minutesSinceStart = Carbon::now()->diffInMinutes(Carbon::now()->format('Y-m-d 08:30:00'));
                $hoursSinceStart = $minutesSinceStart/60;
                if ($hoursSinceStart > 8 || $hoursSinceStart < 0)
                    $hoursSinceStart = 8;
            } else
                $hoursSinceStart = 8;

            $item->verifiedPerHour = round($item->verifiedPerHour / $hoursSinceStart, 2);
            // else
            //     $item->verifiedPerHour = round($item->verifiedPerHour/1,2);
        }
        // dd($data);
        return $data;
    }
}
