<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Team;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ScoresWorkedController extends Controller
{

    public function showWorkedByScore() {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $latestDate = Carbon::now()->format('Y-m') . '-01'; // MTD

        $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->get();
        $teamIds = $teams->pluck('team_id')->toArray();
        $teamsImploded = implode(',', $teamIds);

        $verifiedCapcodes = Capcode::select('id')->where('corporation_id', $corporation_id)->where('type', 'verified')->where('is_archived', 0)->get();
        $verifiedCapcodeIds = $verifiedCapcodes->pluck('id')->toArray();
        $verifiedCapcodesImploded = implode(',', $verifiedCapcodeIds);

        $activeData = collect(DB::select(DB::raw(
            "SELECT count(*) as worked,
            aa.TEAM_ID,
            aa.POESCORE
            FROM worked_history wh
            INNER JOIN active_accounts aa on aa.ID = wh.active_account_id
            WHERE aa.TEAM_ID is not NULL AND DATE(wh.created_at) >= DATE('$latestDate') AND corporation_id = $corporation_id AND aa.TEAM_ID in ($teamsImploded)
            GROUP BY aa.TEAM_ID, aa.POESCORE;"
        )));

        $inactiveData = collect(DB::select(DB::raw(
            "SELECT count(*) as worked,
            aa.TEAM_ID,
            aa.POESCORE,
            COUNT(IF(wh.capcode in ($verifiedCapcodesImploded), 1, NULL)) as verified
            FROM worked_history wh
            INNER JOIN inactive_accounts aa on aa.ID = wh.active_account_id
            WHERE aa.TEAM_ID is not NULL AND DATE(wh.created_at) >= DATE('$latestDate') AND corporation_id = $corporation_id AND aa.TEAM_ID in ($teamsImploded)
            GROUP BY aa.TEAM_ID, aa.POESCORE;"
        )));

        $count = 0;
        $finalData = [];
        foreach($teams as $team) {
            $teamId = $team->team_id;
            $teamName = $team->name;

            if ($teamName == 'BOT')
                continue;

            $activeTeamData = $activeData->where('TEAM_ID', $teamId);
            $inactiveTeamData = $inactiveData->where('TEAM_ID', $teamId);
            $finalData[$count]['name'] = $teamName;
            for ($i = 1; $i <= 10; $i++) {
                $activeScoreData = $activeTeamData->where('POESCORE', $i)->first();
                $inactiveScoreData = $inactiveTeamData->where('POESCORE', $i)->first();

                $worked = 0;
                if (!empty($activeScoreData) || !empty($inactiveScoreData)) {
                    if (!empty($activeScoreData))
                        $worked += $activeScoreData->worked;
                    if (!empty($inactiveScoreData))
                        $worked += $inactiveScoreData->worked;
                }

                $finalData[$count]['SCORE_'.$i] = $worked;

                if ($worked > 0 && !empty($inactiveScoreData)) {
                    $verified = $inactiveScoreData->verified;
                    $verifiedPercent = round(($verified / $worked) * 100, 2);

                    $finalData[$count]['VERIFIED%_'.$i] = number_format((float) $verifiedPercent, 2, '.', '') . '%';
                } else
                    $finalData[$count]['VERIFIED%_'.$i] = '0.00%';
            }

            $count++;
        }
        return view('corporateAdmin.pages.reports.workedByScoreMTD')->with(compact('finalData'));
    }

}
