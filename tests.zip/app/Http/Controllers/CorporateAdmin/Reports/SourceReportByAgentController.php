<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use App\Models\Agent;
use DateTime;
use DB;
use Illuminate\Http\Request;

class SourceReportByAgentController extends Controller
{
    public function sourceReport(Request $request){
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }

        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        $message = "from " . $startTime . " to " . $endTime;
        $endTime = date("Y-m-d", strtotime($endTime." +1 day"));
        $finalData = $this->getData($startTime, $endTime);

        return view('corporateAdmin.pages.reports.sourceReportByAgent')->with('sources', $finalData)->with('timeMessage', $message);
    }

    public function getData($startTime, $endTime){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $agents = Agent::where('corporation_id', $corporation_id)->where('created_at', '<', $endTime)->with('user_link')->get();
        if($corporation_id == 2)
            $neededAgents = [1901,1902,1904];
        else
            $neededAgents = [];
        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $startTime) && ($agent->user_link->is_deactivated == 1))
                continue;
            $neededAgents[] = $agent->agent_id;
        }

        $activeAccounts = Active_Account::
            selectRaw('count(IF(type = "inconclusive",1,null)) as inconclusive, count(IF(LAST_WORKED is null,1,null)) as unworked, ACCT_SOURCE, ACCT_AGENT')
            ->where('active_accounts.corporation_id', $corporation_id)
            ->where(function ($q) use ($startTime, $endTime) {
                $q->whereRaw('(LAST_WORKED > "'.$startTime.'" AND LAST_WORKED < "'.$endTime.'")');
                $q->orwhere('LAST_WORKED', null);
            })->leftJoin('capcodes', function ($join) {
                $join->on('active_accounts.CAPCODE', '=', 'capcodes.id');
            })->groupBy('ACCT_SOURCE', 'ACCT_AGENT')->get();

        $inactiveAccounts = Inactive_Account::
            selectRaw('count(IF(type = "inconclusive",1,null)) as inconclusive, count(IF(type = "unverified",1,null)) as unverified, count(IF(type = "verified",1,null)) as verified, ACCT_SOURCE, ACCT_AGENT')
            ->where('inactive_accounts.corporation_id', $corporation_id)
            ->where(function ($q) use ($startTime, $endTime) {
                $q->whereRaw('(LAST_WORKED > "'.$startTime.'" AND LAST_WORKED < "'.$endTime.'")');
                $q->orwhere('LAST_WORKED', null);
            })->leftJoin('capcodes', function ($join) {
                $join->on('inactive_accounts.CAPCODE', '=', 'capcodes.id');
            })->groupBy('ACCT_SOURCE', 'ACCT_AGENT')->get();

        $finalData = [];
        foreach($neededAgents as $agent){
            //gets all accounts for the agent, if none skips the agent
            $agentActives = $activeAccounts->where('ACCT_AGENT', $agent);
            $agentInactives = $inactiveAccounts->where('ACCT_AGENT', $agent);
            if(empty($agentActives) && empty($agentInactives))
                continue;
            
            //catches the name of bottie, dottie, hottie, or other agents
            switch ($agent){
                case 1901:
                    $name = 'Bottie';
                break;
                case 1902:
                    $name = 'Dottie';
                break;
                case 1904:
                    $name = 'Hottie';
                break;
                default:
                    $agentName = $agents->where('agent_id', $agent)->first();
                    if(empty($agentName))
                        $name = 'N/A';
                    else
                        $name = $agentName->user_link->first_name.' '.$agentName->user_link->last_name;
                break;
            }

            $finalData[] = [
                'agent' => $agent.': '.$name,
                'sources' => $this->getSourcesCount($agentActives, $agentInactives),
            ];
        }

        //gets no agent assigned 
        $agentActives = $activeAccounts->where('ACCT_AGENT', null);
        $agentInactives = $inactiveAccounts->where('ACCT_AGENT', null);
        if(!empty($agentActives) && !empty($agentInactives)){
            $finalData[] = [
                'agent' => 'Unassigned',
                'sources' => $this->getSourcesCount($agentActives, $agentInactives),
            ];
        }

        return $finalData;
    }

    //orders the sources and gets the proper counts
    public function getSourcesCount($activeAccounts, $inactiveAccounts){
        $sources = [];
        //gets the counts of the active accounts
        foreach($activeAccounts as $active){
            $sources[$active->ACCT_SOURCE] = [
                'source' => $active->ACCT_SOURCE,
                'unworked' => $active->unworked,
                'inconclusive' => $active->inconclusive,
                'verified' => 0,
                'unverified' => 0
            ];
        }
        //gets the inactive accounts
        foreach($inactiveAccounts as $inactive){
            if(array_key_exists($inactive->ACCT_SOURCE, $sources)){
                $sources[$inactive->ACCT_SOURCE]['verified'] += $inactive->verified;
                $sources[$inactive->ACCT_SOURCE]['unverified'] += $inactive->unverified;
                $sources[$inactive->ACCT_SOURCE]['inconclusive'] += $inactive->inconclusive;
            }
            else{
                $sources[$inactive->ACCT_SOURCE] = [
                    'source' => $inactive->ACCT_SOURCE,
                    'unworked' => 0,
                    'inconclusive' => $inactive->inconclusive,
                    'verified' => $inactive->verified,
                    'unverified' => $inactive->unverified
                ];
            }
        }
        return $sources;
    }
}