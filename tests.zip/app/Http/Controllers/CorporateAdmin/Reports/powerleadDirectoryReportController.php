<?php
namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Acct_Case;
use App\Models\Active_Account;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Capcode;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Powerlead_Accounts;
use Auth;
use DB;
use Illuminate\Http\Request;

use function PHPSTORM_META\type;

class powerleadDirectoryReportController extends Controller
{
    public function powerleadDirectoryReport(){
        $corporationId = Auth::User()->corporation_corporate_admin_link->corporation_id;

        $from = date('Y-m-d', strtotime('first day of this months'));
        $to = date('Y-m-d', strtotime('+1 day'));

        $finaldata = $this->getData($from, $to, $corporationId);

        $message = "For This Month";

        return view('corporateAdmin.pages.reports.powerleadDirectoryReport')->with('teams', $finaldata[0])->with('months', $finaldata[1])->with('timeMessage', $message);
    }

    public function powerleadDirectoryReportTime(Request $request){
        if($request->from == null)
            $from = date("Y-m-d", strtotime("-1 week"));
        else
            $from = date('Y-m-d', strtotime($request->from));

        if($request->to == null)
            $to = date("Y-m-d", strtotime("+1 day"));
        else
            $to = date('Y-m-d', strtotime($request->to));

        $corporationId = Auth::User()->corporation_corporate_admin_link->corporation_id;

        $finaldata = $this->getData($from, $to, $corporationId);

        $message = "from ".$from." to ".$to;

        return view('corporateAdmin.pages.reports.powerleadDirectoryReport')->with('teams', $finaldata[0])->with('months', $finaldata[1])->with('timeMessage', $message);
    }

    public function getData($from, $to, $corporationId){
        //the start and end dates of the six months
        $dates[] = date('Y-m-d', strtotime('first day of this months - 5 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 4 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 3 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 2 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months - 1 months'));
        $dates[] = date('Y-m-d', strtotime('first day of this months'));
        $dates[] = date('Y-m-d', strtotime('+1 day'));

        for($i = 0; $i < 6; $i++){
            $monthData [date('m',strtotime($dates[$i]))] = array(
                'name' => date('F', strtotime($dates[$i])),
                'directory' => 0,
                'powerlead' => 0,
            );
        }

        //gets the firectory verified codes
        $codes = Directory_Capcode::where('type', 'verified')->select('capcode_id', 'capcode')->get();
        $verified = [];
        foreach($codes as $code){
            $verified[] = "'".$code->capcode_id."'";
        }
        $verified = implode(',',$verified);
        
        $directoryActive = DB::SELECT(DB::RAW("SELECT COUNT(DISTINCT(directory_account_id)) as 'count', MONTH(directory_inactive_accounts.created_at) AS 'month' FROM directory_inactive_accounts 
        INNER JOIN active_accounts ON directory_inactive_accounts.directory_account_id = active_accounts.DIRECTORY_LINK 
        WHERE active_accounts.CORPORATION_ID = $corporationId AND directory_inactive_accounts.CREATED_AT > '$dates[0]' AND directory_inactive_accounts.CREATED_AT < '$dates[6]'
        AND directory_inactive_accounts.capcode in ($verified) GROUP BY MONTH(directory_inactive_accounts.created_at);"));

        $directoryInactive = DB::SELECT(DB::RAW("SELECT COUNT(DISTINCT(directory_account_id)) as 'count', MONTH(directory_inactive_accounts.created_at) AS 'month' FROM directory_inactive_accounts 
        INNER JOIN inactive_accounts ON directory_inactive_accounts.directory_account_id = inactive_accounts.DIRECTORY_LINK 
        WHERE inactive_accounts.CORPORATION_ID = $corporationId AND directory_inactive_accounts.CREATED_AT > '$dates[0]' AND directory_inactive_accounts.CREATED_AT < '$dates[6]'
        AND directory_inactive_accounts.capcode in ($verified) GROUP BY MONTH(directory_inactive_accounts.created_at);"));
        
        //gets the needed powerlead accounts
        $powerleadActiveAccounts = DB::SELECT(DB::RAW("SELECT count(ID) as 'count', MONTH(created_at) as 'month' from active_accounts 
        where POWERLEAD_CAPCODE = 5 and CREATED_AT > '$dates[0]' AND CREATED_AT < '$dates[6]' AND active_accounts.CORPORATION_ID = $corporationId group by MONTH(created_at)"));

        $powerleadInactiveAccounts = DB::SELECT(DB::RAW("SELECT count(ID) as 'count', MONTH(created_at) as 'month' from inactive_accounts 
        where POWERLEAD_CAPCODE = 5 and CREATED_AT > '$dates[0]' AND CREATED_AT < '$dates[6]' AND inactive_accounts.CORPORATION_ID = $corporationId group by MONTH(created_at)"));

        //return date('m',"0".$directory[0]->month);
        foreach($directoryActive as $month){
            if($month->month > 9)
                $monthData[$month->month]['directory'] = $month->count;
            else
                $monthData["0".$month->month]['directory'] = $month->count;
        }
        foreach($directoryInactive as $month){
            if($month->month > 9)
                $monthData[$month->month]['directory'] = $monthData[$month->month]['directory'] + $month->count;
            else
                $monthData["0".$month->month]['directory'] = $monthData["0".$month->month]['directory'] + $month->count;
        }

        foreach($powerleadActiveAccounts as $month){
            if($month->month > 9)
                $monthData[$month->month]['powerlead'] = $month->count;
            else
                $monthData["0".$month->month]['powerlead'] = $month->count;
        }
        foreach($powerleadInactiveAccounts as $month){
            if($month->month > 9)
                $monthData[$month->month]['powerlead'] = $monthData[$month->month]['powerlead'] + $month->count;
            else
                $monthData["0".$month->month]['powerlead'] = $monthData["0".$month->month]['powerlead'] + $month->count;
        }
        
        $directoryActive = DB::SELECT(DB::RAW("SELECT COUNT(DISTINCT(directory_account_id)) as 'count' FROM directory_inactive_accounts 
        INNER JOIN active_accounts ON directory_inactive_accounts.directory_account_id = active_accounts.DIRECTORY_LINK
        WHERE active_accounts.CORPORATION_ID = $corporationId AND directory_inactive_accounts.CREATED_AT > '$from' AND directory_inactive_accounts.CREATED_AT < '$to' 
        AND directory_inactive_accounts.capcode in ($verified);"));

        $directoryInactive = DB::SELECT(DB::RAW("SELECT COUNT(DISTINCT(directory_account_id)) as 'count' FROM directory_inactive_accounts 
        INNER JOIN inactive_accounts ON directory_inactive_accounts.directory_account_id = inactive_accounts.DIRECTORY_LINK
        WHERE inactive_accounts.CORPORATION_ID = $corporationId AND directory_inactive_accounts.CREATED_AT > '$from' AND directory_inactive_accounts.CREATED_AT < '$to' 
        AND directory_inactive_accounts.capcode in ($verified);"));

        $powerleadActiveAccounts = DB::SELECT(DB::RAW("SELECT count(ID) as 'count' from active_accounts 
        where POWERLEAD_CAPCODE = 5 and CREATED_AT > '$from' AND CREATED_AT < '$to' AND active_accounts.CORPORATION_ID = $corporationId;"));

        $powerleadInactiveAccounts = DB::SELECT(DB::RAW("SELECT count(ID) as 'count' from inactive_accounts 
        where POWERLEAD_CAPCODE = 5 and CREATED_AT > '$from' AND CREATED_AT < '$to' AND inactive_accounts.CORPORATION_ID = $corporationId;"));

        $teamData[] =[
            'name' => 'directory',
            'closed' => $directoryActive[0]->count + $directoryInactive[0]->count
        ]; 
        $teamData[] =[
            'name' => 'Powerlead',
            'closed' => $powerleadActiveAccounts[0]->count + $powerleadInactiveAccounts[0]->count
        ]; 

        $finaldata[] = $teamData;
        $finaldata[] = $monthData;
        return $finaldata;
    }
}