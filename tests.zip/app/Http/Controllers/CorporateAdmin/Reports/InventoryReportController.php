<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Capcode;
use App\Models\Inactive_Account;
use App\Models\Worked_History;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class InventoryReportController extends Controller
{
    public function showInventoryReport()
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;

        $finalData = $this->getData($corporation_id)[0];
        $teams = $this->getData($corporation_id)[1];

        return view('corporateAdmin.pages.reports.inventoryReport')->with('finalData', $finalData)->with('teams', $teams)->with('teamCount', sizeof($finalData));
    }

    public function getData($corporation_id)
    {
        $finalData = [];
        $teams = [];
        $seven_days = date('Y-m-d', strtotime('-7 weekdays'));

        $query = DB::SELECT(DB::RAW("SELECT active_accounts.TEAM_ID,
                COUNT(IF(LAST_WORKED IS NULL, 1, NULL)) AS UNWORKED,
                COUNT(IF(ON_HOLD = 1, 1, NULL)) AS IN_QUEUE,
                COUNT(*) AS LEADS,
                COUNT(IF(LAST_WORKED >= DATE('$seven_days'), 1, NULL))/7 AS AVG_SEVEN_DAYS,
                SUM(WORK_ATTEMPTS)/COUNT(IF(WORK_ATTEMPTS IS NOT NULL AND WORK_ATTEMPTS > 0, 1, NULL)) AS AVG_WORKED,
                teams.name
                FROM active_accounts INNER JOIN teams ON active_accounts.TEAM_ID = teams.TEAM_ID
                AND active_accounts.CORPORATION_ID = $corporation_id
                WHERE active_accounts.TEAM_ID IS NOT NULL AND teams.is_deactivated != 1
                GROUP BY active_accounts.TEAM_ID;"));


        foreach($query as $data){

            $verified_data = collect(DB::SELECT(DB::RAW("SELECT
                COUNT(IF(cap.type = 'verified' AND MONTH(LAST_WORKED) = MONTH(CURDATE()) AND YEAR(LAST_WORKED) = YEAR(CURDATE()), 1, NULL)) AS HITS,
                AVG(WORK_ATTEMPTS) AS AVG_WORKED,
                COUNT(IF(LAST_WORKED >= DATE('$seven_days') AND cap.type IN ('verified', 'unverified'), 1, NULL))/7 AS AVG_TEAM_CLOSED,
                COUNT(IF(LAST_WORKED >= DATE('$seven_days'), 1, NULL))/7 AS AVG_SEVEN_DAYS
                FROM inactive_accounts ia INNER JOIN  capcodes cap ON ia.CAPCODE = cap.id
                WHERE TEAM_ID = $data->TEAM_ID;")))->first();

            $daily_total_seven_days = ($data->AVG_SEVEN_DAYS + $verified_data->AVG_SEVEN_DAYS)/2;
            if($daily_total_seven_days == 0)
                $daily_total_seven_days = 1;
            $agent_count = Agent::where('team_id', $data->TEAM_ID)->count();
            if($agent_count == 0)
                $agent_count = 1;

            $finalData[] = [
                'agents' => $agent_count,
                'hits' => $verified_data->HITS,
                'unworked_pl' => '',
                'unworked_team' => $data->UNWORKED,
                'queue' => $data->IN_QUEUE,
                'leads' => $data->LEADS,
                'avg_worked_per_account' => round($daily_total_seven_days),
                'days_inventory' => round($data->LEADS/$daily_total_seven_days),
                'avg_worked' => round(($data->AVG_WORKED + $verified_data->AVG_WORKED )/2, 2),
                'days_inventory_avg' => '',
                'avg' => round($verified_data->AVG_TEAM_CLOSED),
                'avg_per_agent' => round($verified_data->AVG_TEAM_CLOSED/$agent_count, 2)

            ];

            $teams[] = [
                'name' => $data->name
            ];
        }
        return [$finalData, $teams];
    }

}
