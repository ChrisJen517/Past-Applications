<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Acct_Case;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use DB;
use function PHPSTORM_META\type;

class LeadsByClientAndScoreController extends Controller
{
    public function showReport(){
        $data = $this->getData();
        $unworkedCases = $data[0];
        $totals = $data[1];
        $namesArray = $data[2];

        return view('corporateAdmin.pages.reports.leadsByClientAndScores')->with('unworkedCases', $unworkedCases)->with('totals', $totals)->with('namesArray', $namesArray);
    }

    public function getData(){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $namesArray = array('N/A', 'ones', 'twos', 'threes', 'fours', 'fives', 'sixs', 'sevens', 'eights', 'nines', 'tens');

        $unworkedStatement = "SELECT MAX(TIER) AS highest_tier, ";

        $selectStatement = "COUNT(IF(POESCORE > 5, 1, NULL)) as six_and_up, 
        COUNT(IF(POESCORE < 6, 1, NULL)) as five_and_below, ";
        for($i = 1; $i < 11; $i++){
            $selectStatement = $selectStatement."COUNT(IF(POESCORE = $i, 1, NULL)) as ".$namesArray[$i].", ";
        }
        $unworkedStatement = $unworkedStatement.$selectStatement;
        $totalStatement = "SELECT ".$selectStatement;
        
        $unworkedStatement = $unworkedStatement."CLIENT_NAME 
        From active_accounts
        WHERE (LAST_WORKED IS NULL OR LAST_WORKED = '') AND CORPORATION_ID = $corporation_id AND CLIENT_NAME IS NOT NULL
        GROUP BY CLIENT_NAME";

        $totalStatement = $totalStatement."CLIENT_NAME 
        From active_accounts
        WHERE (LAST_WORKED IS NULL OR LAST_WORKED = '') AND CORPORATION_ID = $corporation_id AND CLIENT_NAME IS NOT NULL";
        
        $unworkedCases = DB::select( DB::raw($unworkedStatement));
        $totals = DB::select( DB::raw($totalStatement));

        return [$unworkedCases, $totals, $namesArray];
    }
}