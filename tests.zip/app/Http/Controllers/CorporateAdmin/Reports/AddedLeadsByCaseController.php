<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Acct_Case;
use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\Http\Controllers\Controller;
use Auth;
use DB;

class AddedLeadsByCaseController extends Controller
{
    public function showCasesAdded(){
        $cases = $this->getData();

        return view('corporateAdmin.pages.reports.leadsAddedByCase')->with('cases', $cases);
    }

    public function getData(){
        $startDate = date('Y-m-d', strtotime('-15 days'));
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $namesArray = array('N/A', 'ones', 'twos', 'threes', 'fours', 'fives', 'sixs', 'sevens', 'eights', 'nines', 'tens');

        //sets the select statement to get each scores count
        $selectStatement = "";
        for($i = 1; $i < 11; $i++){
            $selectStatement = $selectStatement."COUNT(IF(POESCORE = $i, 1, NULL)) as ".$namesArray[$i].", ";
        }
        $selectStatement = $selectStatement." COUNT(ID) AS total, date(ADD_DATE) as ADD_DATE, ACCT_CASE, CLIENT_NAME";
        
        //gets all cases from the two tables, getting the past 15 days of data
        $activeCases = Active_Account::selectRaw($selectStatement)
            ->where('CORPORATION_ID', $corporation_id)->where('ACCT_CASE', '!=', null)->where('ADD_DATE', '>', $startDate)
            ->groupBy('ADD_DATE')->groupBy('ACCT_CASE')->get();
        $inactiveCases = Inactive_Account::selectRaw($selectStatement)
            ->where('CORPORATION_ID', $corporation_id)->where('ACCT_CASE', '!=', null)->where('ADD_DATE', '>', $startDate)
            ->groupBy('ADD_DATE')->groupBy('ACCT_CASE')->get();

        //further groups by cases for looping
        $activeCases = $activeCases->groupBy('ACCT_CASE');
        $inactiveCases = $inactiveCases->groupBy('ACCT_CASE');

        //adds each cases added for each day
        $finalData = [];
        foreach($activeCases as $case => $days){
            foreach($days as $day){
                $finalData[$case][$day->ADD_DATE]['Total'] = $day->total;
                $finalData[$case][$day->ADD_DATE]['Name'] = $day->CLIENT_NAME;
                for($i = 1; $i < 11; $i++){
                    $finalData[$case][$day->ADD_DATE][$i] = $day->{$namesArray[$i]};
                }
            }
        }

        //adds each cases added for each day, checks added to assure the cases exist in the array
        foreach($inactiveCases as $case => $days){
            if(!key_exists($case, $finalData)){
                $finalData[$case] = [];
            }
            foreach($days as $day){
                if(key_exists($i, $finalData[$case])){
                    $finalData[$case][$day->ADD_DATE]['Total'] += $day->total;
                    for($i = 1; $i < 11; $i++){
                        $finalData[$case][$day->ADD_DATE][$i] += $day->{$namesArray[$i]};
                    }
                }
                else{
                    $finalData[$case][$day->ADD_DATE]['Name'] = $day->CLIENT_NAME;
                    $finalData[$case][$day->ADD_DATE]['Total'] = $day->total;
                    for($i = 1; $i < 11; $i++){
                        $finalData[$case][$day->ADD_DATE][$i] = $day->{$namesArray[$i]};
                    }
                }
            }
        }

        return $finalData;
    }
}