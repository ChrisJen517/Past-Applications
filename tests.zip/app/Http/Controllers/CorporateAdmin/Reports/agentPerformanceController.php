<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Capcode;
use App\Models\Inactive_Account;
use App\Models\Worked_History;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class AgentPerformanceController extends Controller
{
    public function showAgentPerformance()
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;

        $finalData = $this->getData($corporation_id)[0];
        $agents = $this->getData($corporation_id)[1];
        $dates = $this->getData($corporation_id)[2];
        
        return view('corporateAdmin.pages.reports.agentPerformance')->with('finalData', $finalData)->with('dates', $dates)->with('agents', $agents);
    }

    public function getData($corporation_id)
    {
        $finalData = [];

        $now = Carbon::now();
        $weekStartDate = $now->startOfWeek()->format('Y-m-d');
        $startDate = $weekStartDate;
        $curDate = date('Y-m-d');
        $dates = [];
        while($startDate != $curDate){
            $dates[] = $startDate;
            $startDate = date("Y-m-d", strtotime($startDate." +1 day"));
        }
        $dates[] = $curDate;

        
        $query = DB::SELECT(DB::RAW("SELECT agent_id,
                COUNT(*) AS total,
                COUNT(DISTINCT active_account_id) AS unique_worked,
                DATE(wh.created_at) AS date_worked
                FROM worked_history wh INNER JOIN capcodes ON wh.capcode = capcodes.id
                WHERE  DATE(wh.created_at) >= '$weekStartDate'
                AND agent_id IS NOT NULL AND agent_id > 0
                GROUP BY DATE(wh.created_at), agent_id
                ORDER BY DATE(wh.created_at), agent_id;"));

        $verified_data = collect(DB::SELECT(DB::RAW("SELECT ACCT_AGENT,
                COUNT(IF(cap.type = 'verified', 1, NULL)) AS HITS,
                DATE(LAST_WORKED)
                FROM inactive_accounts ia INNER JOIN  capcodes cap ON ia.CAPCODE = cap.id
                WHERE  DATE(LAST_WORKED) >= '$weekStartDate' AND ia.CORPORATION_ID = $corporation_id
                AND ACCT_AGENT IS NOT NULL GROUP BY ACCT_AGENT, DATE(LAST_WORKED);")));

        $agents = Agent::where('corporation_id', $corporation_id)->with('user_link')->with('team_link')->get();

        foreach($query as $data){
            $hits = 0;
            $agentData = $verified_data->where('ACCT_AGENT', $data->agent_id)->where('DATE(LAST_WORKED)', $data->date_worked)->first();
            if($agentData != NULL)
                $hits = $agentData->HITS;
            
            $finalData[$data->agent_id][$data->date_worked] = [
                "agent_id" => $data->agent_id,
                "total" => $data->total,
                "unique" => $data->unique_worked,
                "verified" => $hits
            ];
        }


        
        return [$finalData, $agents, $dates];
    }
    
}