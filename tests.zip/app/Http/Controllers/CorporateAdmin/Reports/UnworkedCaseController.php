<?php

namespace App\Http\Controllers\CorporateAdmin\Reports;

use App\Models\Acct_Case;
use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use DB;
use function PHPSTORM_META\type;

class UnworkedCaseController extends Controller
{
    public function unworkedCase(){
        $data = $this->getData();
        $unworkedCases = $data[0];
        $totals = $data[1];

        return view('corporateAdmin.pages.reports.unworkedCase')->with('unworkedCases', $unworkedCases)->with('totals', $totals);
    }

    public function getData(){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $namesArray = array('N/A', 'ones', 'twos', 'threes', 'fours', 'fives', 'sixs', 'sevens', 'eights', 'nines', 'tens');

        $unworkedStatement = "SELECT ACCT_CASE, MAX(TIER) AS highest_tier, ACCT_DUE_DATE, ACCESS_RULES, ";

        $selectStatement = "COUNT(IF(POESCORE > 5, 1, NULL)) as six_and_up, 
        COUNT(IF(POESCORE < 6, 1, NULL)) as five_and_below, ";
        for($i = 1; $i < 11; $i++){
            $selectStatement = $selectStatement."COUNT(IF(POESCORE = $i, 1, NULL)) as ".$namesArray[$i].", ";
        }
        $unworkedStatement = $unworkedStatement.$selectStatement;
        $totalStatement = "SELECT ".$selectStatement;
        
        $unworkedStatement = $unworkedStatement."CLIENT_NAME 
        From active_accounts
        WHERE (LAST_WORKED IS NULL OR LAST_WORKED = '') AND CORPORATION_ID = $corporation_id
        GROUP BY ACCT_CASE";

        $totalStatement = $totalStatement."CLIENT_NAME 
        From active_accounts
        WHERE (LAST_WORKED IS NULL OR LAST_WORKED = '') AND CORPORATION_ID = $corporation_id";
        
        $unworkedCases = DB::select( DB::raw($unworkedStatement));
        $totals = DB::select( DB::raw($totalStatement));

        return [$unworkedCases, $totals];
    }

    public function inDepthCaseReport($case){
        if($case == null)
            return back()->with('error', 'Pick a valid case');

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $agents = Agent::where('corporation_id', $corporation_id)->with('user_link')->select('agent_id', 'user_id')->get();

        $caseAgent = DB::select( DB::raw("SELECT ACCT_AGENT AS currentQueue, COUNT(ID) AS totalAccounts, 
        COUNT(IF((LAST_WORKED IS NULL OR LAST_WORKED = ''), 1, NULL)) AS unworked, POESCORE
        FROM active_accounts WHERE CORPORATION_ID = $corporation_id AND ACCT_CASE = $case AND ACCT_AGENT is not null GROUP BY ACCT_AGENT, POESCORE"));

        $caseTeam = DB::select( DB::raw("SELECT TEAM_NAME AS currentQueue, COUNT(ID) AS totalAccounts, 
        COUNT(IF((LAST_WORKED IS NULL OR LAST_WORKED = ''), 1, NULL)) AS unworked, POESCORE
        FROM active_accounts WHERE CORPORATION_ID = $corporation_id AND ACCT_CASE = $case AND ACCT_AGENT is null AND TEAM_ID is not null GROUP BY TEAM_ID, POESCORE"));

        $allCaseQueue = [];
        foreach($caseAgent as $current){
            $agent = $agents->where('agent_id', $current->currentQueue)->first();
            if(!empty($agent))
                $name = $agent->user_link->first_name." ".$agent->user_link->last_name;
            else
                $name = "";
            $current->currentQueue = "Agent: ".$current->currentQueue."- ".$name;
            $allCaseQueue[] = $current;
        }
        foreach($caseTeam as $current){
            $current->currentQueue = "Team: ".$current->currentQueue." Account Queue";
            $allCaseQueue[] = $current;
        }

        return view('corporateAdmin.pages.reports.inDepthCaseReport')->with('allCaseQueue', $allCaseQueue)->with('case', $case);
    }
}