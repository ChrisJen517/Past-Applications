<?php

namespace App\Http\Controllers\CorporateAdmin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\Capcode;
use App\Models\Directory_Capcode;
use Auth;
use App\Models\Corporation;

class BillingReports extends Controller
{
    public function seeBilling(){
        return view('corporateAdmin.pages.billing.billingReport');
    }

    public function seeInvoice(){
        return view('corporateAdmin.pages.billing.invoiceReport');
    }
}