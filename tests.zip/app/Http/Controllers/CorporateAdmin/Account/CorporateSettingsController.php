<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Capcode;
use App\Models\Corporate_Settings;
use App\Models\Distribution_Rules;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Team_Distribution_Rules;
use Auth;
use DateTime;
use Illuminate\Http\Request;

class CorporateSettingsController extends Controller
{
    public function showCorporateSettings()
    {
        $rules = Distribution_Rules::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->first();
        $capcodes = Capcode::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->get();
        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;

        if ($rules != null) {
            //sets priorities for dropdowns
            $priority[] = $rules->priority;
            $priority[] = $rules->second_priority;
            $priority[] = $rules->third_priority;

            //sets value to checked if they were set as a priority
            if (in_array('ACCT_DUE_DATE', $priority)) {
                $preset[0] = 1;
            }

            if (in_array('POESCORE', $priority)) {
                $preset[1] = 1;
            }

            if (in_array('ACCT_SOURCE', $priority)) {
                $preset[2] = 1;
            }

        } else {
            $priority[] = "";
            $priority[] = "";
            $priority[] = "";
        }

        $corporate_settings = Corporate_Settings::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->first();
        $export_setting = explode(',', $corporate_settings->capcode_export);
        $export_time = date("G:i", strtotime($corporate_settings->export_time));
        return view('corporateAdmin/pages/account/corporateSettings')->with('export_time', $export_time)->with('corporate_settings', $corporate_settings)->with('preset', $preset)->with('priority', $priority)->with('capcodes', $capcodes)->with('export_setting', $export_setting);
    }

    public function updateCorporateSettings(request $request)
    {
        $this->validate($request, [
            'below_score' => 'in:10,9,8,7,6,5,4,3,2,1,0',
            'exportFrequency' => 'in:daily,weekly,biWeekly,monthly',
            'directory_option' => 'in:0,1',
            'rnn_scoring' => 'in:0,1',
            'power_hold' => 'in:0,1',
            'web_crawler' => 'in:0,1',
            'show_client' => 'in:0,1',
            'checked.*' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'priority' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'prioritySecond' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'sender_email_name' => 'required',
        ]);

        $rules = Distribution_Rules::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->first();

        if ($rules == null) {
            $rules = new Distribution_Rules;
            $rules->corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        }

        //sets the priorities based on the number checked
        if (count($request->checked) == 1) {
            $rules->priority = $request->checked[0];
            $rules->second_priority = null;
            $rules->third_priority = null;
        } else {
            $rules->priority = $request->priority;

            if (count($request->checked) == 2) {
                if ($request->priority != $request->checked[0]) {
                    $rules->second_priority = $request->checked[0];
                } else {
                    $rules->second_priority = $request->checked[1];
                }

                $rules->third_priority = null;
            }
            else if (count($request->checked) == 3) {
                $rules->second_priority = $request->prioritySecond;
                $priorities[] = $request->priority;
                $priorities[] = $request->prioritySecond;

                if (!in_array('POESCORE', $priorities)) {
                    $rules->third_priority = 'POESCORE';
                } else if (!in_array('ACCT_DUE_DATE', $priorities)) {
                    $rules->third_priority = 'ACCT_DUE_DATE';
                } else {
                    $rules->third_priority = 'ACCT_SOURCE';
                }

            }
        }

        $rules->save();

        //if the priorities change, updates all of the teams
        if($request->updateTeams == 1){
            $this->setAllTeamsPriority($rules->priority, $rules->second_priority, $rules->third_priority);
        }

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $corporate_settings = Corporate_Settings::where('corporation_id', $corporation_id)->first();

        if ($request->fax_upload != null) {
            $extension = pathinfo($_FILES['fax_upload']['name'], PATHINFO_EXTENSION);

            //saves the file
            $file = $request->file('fax_upload');
            $download = $file->storeAs('templates', $corporation_id . '_fax_template.' . $extension);

            $corporate_settings->fax_path = 'templates/' . $corporation_id . '_fax_template.' . $extension;
        }

        if ($request->email_upload != null) {
            $extension = pathinfo($_FILES['email_upload']['name'], PATHINFO_EXTENSION);

            //saves the file
            $file = $request->file('email_upload');
            $download = $file->storeAs('templates', $corporation_id . '_email_template.' . $extension);

            $corporate_settings->email_path = 'templates/' . $corporation_id . '_email_template.' . $extension;
        }

        $capcode_export_save = '';
        if ($request->capcodes_export != '') {
            foreach ($request->capcodes_export as $capcode_export) {
                if (Capcode::where('corporation_id', $corporation_id)->where('id', $capcode_export)->doesntExist()) {
                    return back()->with('error', 'Capcode does not exist');
                }
                $capcode_export_save = $capcode_export_save . $capcode_export . ",";
            }
            $capcode_export_save = substr_replace($capcode_export_save, "", -1);
            $corporate_settings->capcode_export = $capcode_export_save;
        }

        // * Disabled temporarily until we figure out a way to add more subdomains to sendgrid
        // if (!empty($request->sender_email_address)) {
        //     $corporate_settings->sender_email_address = $request->sender_email_address;
        // }

        if (!empty($request->sender_email_name)) {
            $corporate_settings->sender_email_name = $request->sender_email_name;
        }

        // $corporate_settings->hold_accounts_automatically = $request->hold_accounts;
        $corporate_settings->hold_accounts_below_score = $request->below_score;
        $corporate_settings->export_frequency = $request->exportFrequency;
        $corporate_settings->directory_option = $request->directory_option;
        $corporate_settings->rnn_scoring = $request->rnn_scoring;
        $corporate_settings->power_hold = $request->power_hold;
        $corporate_settings->web_crawler = $request->web_crawler;
        $corporate_settings->show_client = $request->show_client;
        $corporate_settings->export_time = date("Y-m-d G:i:s", DateTime::createFromFormat("G:i", $request->exportTime)->getTimeStamp());
        $corporate_settings->save();

        return redirect()->back()->with('success', 'Corporate Settings Updated');
    }

    public function downloadTemplate($type)
    {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $corporate_settings = Corporate_Settings::where('corporation_id', $corporation_id)->first();

        if ($type == 'Fax') {
            $filepath = $corporate_settings->fax_path;
        } else {
            $filepath = $corporate_settings->email_path;
        }

        if ($filepath == null) {
            return back()->with('error', "No template has been saved");
        } else {
            return response()->download(storage_path('app/public/' . $filepath), null, [
                'Cache-Control' => 'no-cache, no-store, must-revalidate',
                'Pragma' => 'no-cache',
            ]);
        }
    }

    public function setAllTeamsPriority($first, $second, $third){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $teams = Team::select('team_id')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->get();

        $teamIds = [];
        foreach($teams as $team){
            $teamIds[] = $team->team_id;
        }

        $eachTeamRules = Team_Distribution_Rules::whereIn('team_id', $teamIds)->get();

        foreach($teams as $team){
            $thisTeamRules = $eachTeamRules->where('team_id', $team->team_id)->first();

            if($thisTeamRules == null){
                $thisTeamRules = new Team_Distribution_Rules;
                $thisTeamRules->team_id = $team->team_id;
            }

            $thisTeamRules->priority = $first;
            $thisTeamRules->second_priority = $second;
            $thisTeamRules->third_priority = $third;

            $thisTeamRules->save();
        }
    }

}
