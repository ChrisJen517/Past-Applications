<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Capcode;
use App\Models\Report_Rotations;
use App\Http\Controllers\Controller;
use App\Models\Team;
use Auth;
use DateTime;
use Illuminate\Http\Request;

class ReportRotationController extends Controller
{
    public function manageRotation($id = null){
        if($id != null){
            $view = 'admin.pages.reportRotationAdmin';
        }
        else{
            $id = Auth::user()->corporation_corporate_admin_link->corporation_id;
            $view = 'corporateAdmin.pages.account.reportRotation';
        }

        $teams = Team::where('corporation_id', $id)
        ->where('is_deactivated', 0)->select('name', 'team_id')->get();
        
        return view($view)->with('teams', $teams);
    }

    public function teamRotation(Request $request){
        if(Auth::user()->role == "corporate_admin"){
            $team = Team::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)
            ->where('team_id', $request->id)->select('team_id')->first();

            if($team == null){
                echo json_encode("failed");
                return;
            }
        }

        $rotation = Report_Rotations::where('team_id', $request->id)->get();

        if($rotation->first() == null){
            $rotation = new Report_Rotations();
            $rotation->team_id = $request->id;
            $rotation->save();
            $list = [];
        }
        else{
            $rotation = $rotation->first();
            $list = $rotation->rotation;
            if(($list != null) && ($list != ''))
                $list = explode(',', $list);
            else
                $list = [];
        }

        echo json_encode($list);
    }

    public function updateRotation(Request $request){
        if(Auth::user()->role == "corporate_admin"){
            $team = Team::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)
            ->where('team_id', $request->id)->select('team_id')->first();

            if($team == null){
                echo json_encode("failed");
                return;
            }
        }

        $rotation = Report_Rotations::where('team_id', $request->id)->first();

        if($request->inList == null || empty($request->inList))
            $list = null;
        else
            $list = implode(',', $request->inList);


        if($rotation == null){
            $rotation = new Report_Rotations();
            $rotation->team_id = $request->id;
        }

        $rotation->rotation = $list;
        $rotation->save();

        echo json_encode("success");
    }
}