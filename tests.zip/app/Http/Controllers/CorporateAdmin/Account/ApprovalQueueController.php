<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Active_Account;
use App\Models\Capcode;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;

class ApprovalQueueController extends Controller
{
    public function showApprovalQueue($teamId = null)
    {
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'pending_approval')->get();
        $approvals = [];

        foreach($capcodes as $capcode) {
            $approvals[] = $capcode->id;
        }

        $accounts = Active_Account::whereIn('CAPCODE', $approvals)
        ->where('CORPORATION_ID', $corporation_id)
        ->when(!empty($teamId), function ($query) use ($teamId) {
            return $query->where('team_id', $teamId);
        })
        ->get();

        return view('corporateAdmin.pages.account.approvalQueue')->with('accounts', $accounts)->with('teamId', $teamId);
    }
}
