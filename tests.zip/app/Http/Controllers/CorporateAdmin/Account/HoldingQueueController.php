<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Agent;
use App\Models\Corporate_Admin;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\Active_Account;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Traits\AccountDistrubution;
use App\Models\Redistribution_Record;

class HoldingQueueController extends Controller
{
    use AccountDistrubution;

    public function showHoldingQueue()
    {
        $corporation = Corporate_Admin::where("user_id", "=", Auth::user()->user_id)->get()->first();

        $teams = Team::select('name', 'team_id')->where('corporation_id', $corporation->corporation_id)->where('is_deactivated', 0)->get();
        $teamIds = array_column($teams->all(), 'team_id');

        $teamAccountQuery = DB::SELECT(DB::RAW("SELECT
        aa.TEAM_ID as TEAM_ID,
        COUNT(IF(aa.ON_HOLD = 0 AND (aa.ACCT_AGENT IS NULL OR aa.ACCT_AGENT=''), 1, NULL)) AS held,
        COUNT(IF(aa.ON_HOLD = 0 AND aa.ACCT_AGENT <> '' AND aa.ACCT_AGENT IS NOT NULL, 1, NULL)) AS assigned
        FROM
            active_accounts as aa
        WHERE
            aa.TEAM_ID IN (".implode(',', $teamIds).")
        GROUP BY TEAM_ID;"));

        $teamAccountData = [];
        foreach($teamAccountQuery as $team) {
            $teamName = $teams->where('team_id', $team->TEAM_ID)->first()->name;
            $teamAccountData[$team->TEAM_ID] = [
                'name' => $teamName,
                'heldCount' => $team->held,
                'assignedCount' => $team->assigned
            ];
        }

        $namesArray = array('N/A', 'ones', 'twos', 'threes', 'fours', 'fives', 'sixs', 'sevens', 'eights', 'nines', 'tens');
        $selectStatment = "SELECT TEAM_ID, (SELECT t.name FROM teams t WHERE t.TEAM_ID = aa.TEAM_ID) AS TEAM_NAME,";
        for($i = 1; $i < 11; $i++){
            $selectStatment = $selectStatment." COUNT(IF(aa.POESCORE = $i AND aa.ON_HOLD = 1 AND PINPOINT != 1 AND (ACCT_AGENT NOT IN (7720, 2001) OR ACCT_AGENT is null), 1, NULL)) AS ".$namesArray[$i]."OnHold,";
            $selectStatment = $selectStatment." COUNT(IF(aa.POESCORE = $i AND aa.ON_HOLD = 1 AND PINPOINT = 1, 1, NULL)) AS ".$namesArray[$i]."OverFlow,";
            $selectStatment = $selectStatment." COUNT(IF(aa.POESCORE = $i AND aa.ON_HOLD = 0, 1, NULL)) AS ".$namesArray[$i]."Active,";
            $selectStatment = $selectStatment." COUNT(IF(aa.POESCORE = $i AND aa.ON_HOLD = 0 AND LAST_WORKED IS NULL, 1, NULL)) AS ".$namesArray[$i]."Unworked,";
            // $selectStatment = $selectStatment." COUNT(IF(aa.POESCORE = $i AND aa.ON_HOLD = 1 AND aa.powerlead_capcode IN ('1', '2', '3'), 1, NULL)) AS ".$namesArray[$i]."Power,";
        }
        $selectStatment = $selectStatment." COUNT(IF(aa.LAST_WORKED IS NULL AND aa.ON_HOLD = 0, 1, NULL))AS unworked
        FROM active_accounts aa
        WHERE CORPORATION_ID = $corporation->corporation_id
        AND (TEAM_ID IN (".implode(',', $teamIds)."))
        GROUP BY TEAM_ID";

        $teams = DB::select( DB::raw($selectStatment));
        $allAccounts = DB::SELECT( DB::RAW("SELECT scores.score AS 'SCORE',
         (SELECT COUNT(1) FROM active_accounts WHERE ON_HOLD = 1 and POESCORE = SCORE AND CORPORATION_ID = $corporation->corporation_id) AS 'TOTAL_ACCOUNTS_ON_HOLD',
         (SELECT COUNT(1) FROM active_accounts WHERE POESCORE = SCORE AND CORPORATION_ID = $corporation->corporation_id) AS 'TOTAL_ACCOUNTS',
         (SELECT COUNT(1) FROM active_accounts WHERE ON_HOLD = 0 AND POESCORE = SCORE AND CORPORATION_ID = $corporation->corporation_id) AS 'TOTAL_ACCOUNTS_ACTIVE',
         (SELECT COUNT(1) FROM active_accounts WHERE PINPOINT = 1 AND ON_HOLD = 1 AND POESCORE = SCORE AND CORPORATION_ID = $corporation->corporation_id) AS 'TOTAL_ACCOUNTS_AT_PINPOINT'
         FROM scores GROUP BY score ORDER BY score DESC;"));
        return view('corporateAdmin/pages/account/holdingQueue')->with('teams', $teams)->with('corporation', $corporation)
        ->with('allAccounts', $allAccounts)->with('namesArray', $namesArray)->with('teamAccountData', $teamAccountData);
    }

    public function holdActiveScore($id, $score, $all){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $updateStatement = "UPDATE `active_accounts` SET `ACCT_AGENT` = NULL, `ON_HOLD` = 1  WHERE ";
        //sets which team they are assigned to
        if($id == 0){
            $team_name = 'Not Assigned';
            $updateStatement = $updateStatement."`TEAM_ID` is null ";
        }else{
            $team = Team::find($id);
            $team_name = $team->name;
            $updateStatement = $updateStatement."`TEAM_ID` = $id ";
        }

        //sets if they want unworked or not
        $workedWording = "";
        if($all == 0){
            $workedWording = "unworked ";
            $updateStatement = $updateStatement."AND LAST_WORKED is null ";
        }

        $updateStatement = $updateStatement.'AND POESCORE = '.$score.' AND CORPORATION_ID ='.$corporation_id.';';
        DB::select( DB::raw($updateStatement));

        return back()->with('message', 'Put on hold all '.$workedWording.'accounts with a Score of '.$score.' and a Team of '.$team_name.' that were on hold because of score.');
    }

    public function releaseScoreHeldAccounts($id, $score){
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        if($id == 0){
            $team_name = 'Not Assigned';
            DB::select( DB::raw('UPDATE `active_accounts` SET `ON_HOLD` = 0  WHERE `TEAM_ID` is null AND ON_HOLD = 1 AND POESCORE = '.$score.' AND CORPORATION_ID ='.$corporation_id.' AND ACCT_AGENT = NULL AND PINPOINT = 0;'));
        }else{
            $team = Team::find($id);
            $team_name = $team->name;
            DB::select( DB::raw('UPDATE `active_accounts` SET `ON_HOLD` = 0  WHERE `TEAM_ID` = '.$id.' AND ON_HOLD = 1 AND POESCORE = '.$score.' AND CORPORATION_ID ='.$corporation_id.' AND ACCT_AGENT = NULL AND PINPOINT = 0;'));
        }
        return back()->with('message', 'Released all accounts that were on hold with a Score of '.$score.' and a Team of '.$team_name.'.');
    }

    // currently removed, may possibly bring back so not deleted
    // public function releasePower($id, $score){
    //     $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
    //     if($id == 0){
    //         $team_name = 'Not Assigned';
    //         DB::select( DB::raw('UPDATE `active_accounts` SET `ON_HOLD` = 0  WHERE `TEAM_ID` is null AND ON_HOLD = 1 AND POESCORE = '.$score.' AND CORPORATION_ID ='.$corporation_id.' AND powerlead_capcode IN ("1", "2", "3");'));
    //     }else{
    //         $team = Team::find($id);
    //         $team_name = $team->name;
    //         DB::select( DB::raw('UPDATE `active_accounts` SET `ON_HOLD` = 0  WHERE `TEAM_ID` = '.$id.' AND ON_HOLD = 1 AND POESCORE = '.$score.' AND CORPORATION_ID ='.$corporation_id.' AND powerlead_capcode IN ("1", "2", "3");'));
    //     }
    //     return back()->with('message', 'Released all accounts that were on hold with a Score of '.$score.' and a Team of '.$team_name.' that were held by powerlead team.');
    // }

    public function shuffle($id){

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $team = Team::find($id);
        $agents = $this->getAgents($team->team_id);
        DB::select( DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL  WHERE `TEAM_ID` = '.$id.' AND CORPORATION_ID ='.$corporation_id.' AND LAST_WORKED IS NULL AND `ACCT_AGENT` IN ('.$agents.');'));

        $this->setAgentQueueByTeam($id);

        $redistribution_record = new Redistribution_Record();
        $redistribution_record->corporation_id = $corporation_id;
        $redistribution_record->team_id = $id;
        $redistribution_record->save();

        return back()->with('message', 'Redistrubuted all accounts of Agents on Team: '.$team->name.'.');
    }

    public function getAgents($team_id)
    {

        $agents = Agent::where('team_id', $team_id)->get();
        $agentList = '';
        foreach ($agents as $agent) {
            $agentList = $agentList . ' "' . $agent->agent_id . '",';
        }
        $agentList = substr_replace($agentList, '', -1);

        return $agentList;
    }

    public function seeAccounts($id, $score){

        if($id == 0){
            $team_name = 'Not Assigned';
        }else{
            $team = Team::find($id);
            $team_name = $team->name;
        }

        return view('corporateAdmin/pages/account/seeAccounts')->with('teamId', $id)->with('teamName', $team_name)->with('score', $score);
    }

    public function getAccountTable(Request $request)
    {
        $columns = array(
            0 =>'ACCT_DUE_DATE',
            1 =>'LAST_WORKED',
            2 =>'ACCT_AGENT',
            3 =>'ACCT_SSN',
            4 =>'ACCT_CASE',
            5 =>'ACCT_CONSUMER_NAME',
            6 =>'ACCT_ID',
            7 =>'EMPL_NAME',
            8 =>'ACCT_SOURCE',
            9 =>'CAPCODE'
        );

        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;
        $teamId = $request->input('teamId');
        $score = $request->input('score');

        $totalData = Active_Account::where('TEAM_ID', $teamId)->where('POESCORE', $score)->count();

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        $query = "SELECT
        `ACCT_DUE_DATE`,
        IF(`LAST_WORKED` IS NOT NULL AND `LAST_WORKED` <> '', `LAST_WORKED`, 'New Account') AS LAST_WORKED,
        `ACCT_AGENT`,
        `ACCT_CASE`,
        `ACCT_SSN`,
        CONCAT(`ACCT_FIRST_NAME`, ' ', `ACCT_LAST_NAME`) AS ACCT_CONSUMER_NAME,
        `ACCT_ID`,
        `EMPL_NAME`,
        `ACCT_SOURCE`,
        `CAPCODE` AS capcodeid,
        (SELECT capcode FROM capcodes WHERE id = capcodeid) AS capcode,
        `ID`
        FROM `active_accounts`
        WHERE
        CORPORATION_ID = '".$corporation_id."'
        AND POESCORE = ".$score."";

        if($teamId == 0)
            $query = $query." AND TEAM_ID is not null";
        else
            $query = $query." AND TEAM_ID = ".$teamId;

        if (!empty($request->input('search.value'))){
            $search = $request->input('search.value');

            $query = $query." AND (ACCT_DUE_DATE LIKE '%".$search."%'
            or LAST_WORKED LIKE '%".$search."%'
            or ACCT_AGENT LIKE '%".$search."%'
            or ACCT_CASE LIKE '%".$search."%'
            or ACCT_SSN LIKE '%".$search."%'
            or ACCT_ID LIKE '%".$search."%'
            or CONCAT(`ACCT_FIRST_NAME`, ' ', `ACCT_LAST_NAME`) LIKE '%".$search."%'
            or EMPL_NAME LIKE '%".$search."%'
            or ACCT_SOURCE LIKE '%".$search."%'
            or CAPCODE = (SELECT id from capcodes where capcodes.capcode LIKE '%".$search."%' and capcodes.corporation_id = '".$corporation_id."' limit 1))";
        }

        $query = $query." ORDER BY ".$order." ".$dir."
        limit ".$limit."
        offset ".$start.";";

        $allAccounts = DB::select($query);

        $totalFiltered = $totalData;

        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"            => $allAccounts
        );

        echo json_encode($json_data);
    }
}
