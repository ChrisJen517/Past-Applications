<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\CorporateAdmin;
use App\Models\Corporation;
use App\Models\Corporate_Settings;
use App\Http\Controllers\Controller;
use App\Models\FTP;
use Symfony\Component\HttpFoundation\Request;
use Auth;
use DB;
use PDO;
use Config;
use Schema;
use App\Models\Active_Accounts_Mapping;
use Illuminate\Database\QueryException;
use App\Jobs\TeamDistrubutionQueue;
use App\Jobs\PowerleadDistrubutonQueue;
use App\Jobs\DirectoryTeamDistributionQueue;
use App\Jobs\DirectoryAgentDistributionQueue;
use App\Models\Powerlead_Settings;
use App\Models\CSV_Upload;
use App\Models\Access_Levels;
use App\Models\Agent;
use App\Traits\getIdCombinations;

class FTPFileDropController extends Controller
{
    use getIdCombinations;
    
    //loads the main ftp page
    public function fileDropPage(){
        $corporate_admin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
        $FTP = FTP::where('corporation_id', $corporate_admin->corporation_id)->first();

        if($FTP == NULL){
            $FTP = new FTP();
            $FTP->corporation_id = $corporate_admin->corporation_id;
            $FTP->save();
        }

        return view('corporateAdmin.pages.account.FTPFileDrop')->with('FTP', $FTP);
    }

    //edits or creates a new FTP setting for the company
    public function FTPSettings(Request $request){        
        $corporate_admin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
        $FTP = FTP::where('corporation_id', $corporate_admin->corporation_id)->first();

        if($FTP == NULL)
            $FTP = new FTP();

        $FTP->host = $request->host;
        $FTP->port = $request->port;
        $FTP->corporation_id = $corporate_admin->corporation_id;
        $FTP->password = $request->password;
        $FTP->username = $request->username;
        $FTP->save();

        //checks login information
        $message = $this->checkLogin($FTP);
        if($message == "success")
            $message = "FTP has been updated";

        echo json_encode($message);
        return;
    }

    public function testLogin(Request $request){
        //checks login information
        $message = $this->checkLogin($request);
        if($message != "success"){
            echo json_encode($message);
        }
        else{
            echo json_encode("FTP connection is successful");
        }
    }

    public function getFolders(){
        $corporate_admin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
        $FTP = FTP::where('corporation_id', $corporate_admin->corporation_id)->first();

        //checks to see if it can login, if not returns an error
        $message = $this->checkLogin($FTP);
        if($message != "success"){
            echo json_encode($message);
            return;
        }
        else{
            //logs in
            $conn_id = ftp_connect($FTP->host, $FTP->port, 90);
            ftp_login($conn_id, $FTP->username, $FTP->password);

            //gets a list of everything in the directory
            ftp_pasv($conn_id,true);
            $fileList = ftp_nlist($conn_id, "/");

            //makes sure there is something in the 
            if(count($fileList) < 1){
                echo json_encode('Directory does not exist or is completely empty'); 
                return;
            }

            //gets just the documents
            foreach($fileList as $file){
                if(ftp_size($conn_id, $file) == -1)
                    $directories[] = $file;
            }

            //makes sure the folders exist
            if(isset($directories)){
                echo json_encode($directories);
                return;
            }
            else{
                echo json_encode("No Folders in the directory");
                return;
            }
        }
    }

    public function FTPDownloadAll(){
        $corporations = Corporation::get();

        foreach($corporations as $corporation){
            $this->FTPDownload($corporation);
        }
    }

    public function FTPDownload($corporation){
        $FTP = FTP::where('corporation_id', $corporation->corporation_id)->first();

        //makes sure the corporation's ftp exists
        if($FTP == NULL)
            return;

        //checks login information and that folder is set properly
        $message = $this->checkFolderLocation($FTP, $FTP->folder);
        if($message != 'Folder would work')
            return;

        //see if they have mapping set up
        $active_accounts_mapping = Active_Accounts_Mapping::where('corporation_id', $corporation->corporation_id)->first();
        if($active_accounts_mapping == NULL)
            return;

        //logs in
        $conn_id = ftp_connect($FTP->host, $FTP->port, 90);
        ftp_login($conn_id, $FTP->username, $FTP->password);

        //gets a list of everything in the directory
        ftp_pasv($conn_id,true);
        $fileList = ftp_nlist($conn_id,$FTP->folder);
        
        //checks that the folder isnt empty
        if(count($fileList) < 1)
            return; 

        //gets a list of just the files and not the folders
        $original_directory = ftp_pwd($conn_id);
        ftp_chdir($conn_id, $FTP->folder);
        foreach($fileList as $file){
            if(ftp_size($conn_id, $file) != -1)
                $newFiles[] = $file;
        }
        ftp_chdir($conn_id,$original_directory);

        //if there is at least one file, starts the download and moving process
        if(isset($newFiles)){    
            
            //makes sure the company has a folder on our server, if not makes one
            if (!is_dir(storage_path('FTP')))
                mkdir(storage_path('FTP'));      

            //checks if the directory has a folder upload_complete, if not makes one
            if (@ftp_chdir($conn_id, $FTP->folder.'/upload_complete'))
                ftp_chdir($conn_id,$original_directory);
            else
                ftp_mkdir ($conn_id, $FTP->folder.'/upload_complete');
            
            //for each file, dowloads them then moves them to upload_complete
            foreach($newFiles as $filename){
                if(pathinfo($filename, PATHINFO_EXTENSION) == 'csv'){
                    $fileNumber = CSV_Upload::max('id') + 1;
                    $fileNumber = str_replace(" ","",$fileNumber.$corporation->name.date('Y-m-d').'.csv');
                    $filePath = storage_path('app/public/CSVUploads/'.$corporation->corporation_id.'/'.$fileNumber);
                    $download = ftp_get($conn_id, $filePath, $FTP->folder.'/'.$filename, FTP_BINARY);

                    //adds to the database and only moves it if they can download it properly
                    $accountUpload = $this->accountUpload($filePath ,$corporation, $fileNumber);
                    if($accountUpload == 'success') 
                        $moveDir = ftp_rename($conn_id, $FTP->folder.'/'.$filename, $FTP->folder.'/upload_complete'.'/'.$filename);

                }
            }
        }
        return;
    }

    //checks to make sure the login information is valid
    public function checkLogin($FTP){
        if($FTP == NULL)
            return "FTP is not set for your company";

        //checks host and port
        $conn_id = @ftp_connect($FTP->host, $FTP->port, 90);
        if(!$conn_id)
            return "FTP could not connect, check Host and port before trying again"; 

        //checks username and password
        if(!@ftp_login($conn_id, $FTP->username, $FTP->password))
            return "FTP could not connect, username or password is incorrect";

        return "success";
    }

    //request called to simply see if the folder would work
    public function checkFolder(Request $request){
        $corporate_admin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
        $FTP = FTP::where('corporation_id', $corporate_admin->corporation_id)->first();

        echo json_encode($this->checkFolderLocation($FTP, $request->lowest_folder));
        return;
    }

    //sets the folder after it is checked
    public function setFolder(Request $request){
        $corporate_admin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
        $FTP = FTP::where('corporation_id', $corporate_admin->corporation_id)->first();

        $message = $this->checkFolderLocation($FTP, $request->lowest_folder);

        if($message != 'Folder would work'){
            echo json_encode($message);
            return;
        }
        else{
            $corporate_admin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
            $FTP = FTP::where('corporation_id', $corporate_admin->corporation_id)->first();

            $FTP->folder = $request->lowest_folder;
            $FTP->save();

            echo json_encode('Folder Set');
            return;
        }
    }

    public function checkFolderLocation($FTP, $folder){
        //checks to see if it can login, if not returns an error
        $message = $this->checkLogin($FTP);
        if($message != "success"){
            return $message;
        }
        else{
            //logs in
            $conn_id = ftp_connect($FTP->host, $FTP->port, 90);
            ftp_login($conn_id, $FTP->username, $FTP->password);
            ftp_pasv($conn_id,true);

            //makes sure folder is set
            if($folder == NULL)
                return 'Folder not set';

            //tests for the folder's existance
            if (@ftp_chdir($conn_id, $folder)){
                return 'Folder would work';
            }
            else{
                return'Folder not found';
            }
        }
    }

    public function accountUpload($filePath, $corporation, $fileNumber)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
     
        $corporation_id = $corporation->corporation_id;
        $corporation_name = $corporation->name;
        $corporation_name_regex = preg_replace("/[^A-Za-z]/", '', $corporation_name);
        $table_name = $corporation_name_regex;
        $corporate_settings = Corporate_Settings::where('corporation_id', $corporation_id)->first();
        $powerlead_settings = Powerlead_Settings::first();

        $savePrevious = new CSV_Upload;
        $savePrevious->corporation_id = $corporation_id;
        $savePrevious->date_upload = date('Y-m-d');
        $savePrevious->number_of_records = 0;
        $savePrevious->method = "FTP Upload";
        $savePrevious->file_path = $filePath;

        $active_accounts_mapping = Active_Accounts_Mapping::where('corporation_id', $corporation_id)->first();
        if(empty($active_accounts_mapping)){
            $savePrevious->status = "failed";
            $savePrevious->save();

            return;
        }
        else if ($active_accounts_mapping->ACCT_DUE_DATE == null
         || $active_accounts_mapping->ACCT_SSN == null 
         || $active_accounts_mapping->ACCT_ID == null) {
            $savePrevious->status = "failed";
            $savePrevious->save();

            return;
        }
        
        $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts_mapping');
        // Assigning DB values   
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        
        $file = new \SplFileObject($filePath);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;

        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {   
            if($rows == 0){
                foreach($row as $header)
                {   
                        $headers[] = $header;
                }
            }
            $rows++;
        }

        $savePrevious->number_of_records = $rows - 2;

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $count = 0;
        $countHead = 0;
        $number_of_matched_columns = 0;
        $corp_drop_check = 0;
        $on_hold_drop_check = 0;

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
                if($countHead == 0)
                {
                    $insert_statement_temp_table = "`".$head."` VARCHAR( 90 ) ";
                }
                else
                {
                    $insert_statement_temp_table = $insert_statement_temp_table.", `".$head."` VARCHAR( 90 ) ";
                }
                $countHead++;
            if(strtolower($head) == 'corporation_id'){
                $corp_drop_check = 1;
            }
            elseif(strtolower($head) == 'on_hold'){
                $on_hold_drop_check = 1;
            }
            else
            {
                foreach($active_accounts_mapping_columns as $column)
                {
                    if($active_accounts_mapping->$column == $head)
                    {
                        if($count == 0)
                        {
                            $insert_statement = $column;
                            $insert_statement_CSV = "`$table_name`.`".$head."`";
                            $number_of_matched_columns++;
                            $count++;
                        }
                        else    
                        {
                            $insert_statement = $insert_statement.", ".$column;
                            $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$head."`";
                            $number_of_matched_columns++;
                        }
                    }
                }
            }
        }
        $insert_statement = $insert_statement.", corporation_id";
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`corporation_id`";
        $insert_statement = $insert_statement.", ON_HOLD";
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`ON_HOLD`";

        // Checking if # of Database mapped columns are all on the CSV File
        $expected_col_number = 0;
        foreach($active_accounts_mapping_columns as $column)
        {
            if($active_accounts_mapping->$column != null)
            {
                $expected_col_number++;
            }
        }
        // return $expected_col_number;
        $expected_col_number = $expected_col_number - 4;
        if($expected_col_number != $number_of_matched_columns)
        {
            $savePrevious->status = "failed";
            $savePrevious->save();

            return;
        }     
        try {
            // Dropping table if one previously existed
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            // Creating a temp table to upload CSV file
             $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
                $insert_statement_temp_table);"));
            
            // Creating connection to database allowing whole file to be uploaded
            $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
                PDO::MYSQL_ATTR_LOCAL_INFILE => true,
            ));

            // Writing query to load file
            $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\r\n' IGNORE 1 LINES", addslashes($filePath));
            // executing query on database 
            $conn->exec($query);

            // Adding the column corporation_id
            if($corp_drop_check == 1){
                DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP corporation_id'));
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `corporation_id` BIGINT(20) NOT NULL DEFAULT $corporation_id AFTER `$head`;
                "));
            }
            else{
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `corporation_id` BIGINT(20) NOT NULL DEFAULT $corporation_id AFTER `$head`;
                "));    
            }

            if($on_hold_drop_check == 1){
                DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP on_hold'));
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `ON_HOLD` TINYINT(4) NOT NULL DEFAULT 1 AFTER `corporation_id`;
                "));
            }
            else{
                DB::select( DB::raw("ALTER TABLE `$table_name` 
                ADD COLUMN `ON_HOLD` TINYINT(4) NOT NULL DEFAULT 1 AFTER `corporation_id`;
                "));
            }
            if($active_accounts_mapping->ACCESS_RULES != ''){
                $corporateRules = Access_Levels::where('corporation_id', $corporation_id)->select('shortcode')->get();
                
                //makes sure there are rules to work with
                if($corporateRules->first() == null){
                    $savePrevious->status = "failed";
                    $savePrevious->save();

                    $errorMessage = "Access Levels not set for your corporation";
                    return redirect()->back()->with('error', $errorMessage);
                }

                //gets all the agents in the company that are still active AND have shortcodes, then gets the list of shortcode combinations they have
                $agents = Agent::where('corporation_id', $corporation_id)->select('user_id')->with('user_link')->get();
                $agentAccessLevels  = [];
                foreach($agents as $agent){
                    if(($agent->user_link->is_deactivated == 0) && ($agent->user_link->has_access != null) && ($agent->user_link->has_access != "")){
                        $array = explode(',',$agent->user_link->has_access);
                        $agentAccessLevels = $this->getIdCombinations($agentAccessLevels, $array);
                    }
                }

                //gets all the distinct rules 
                $rules = DB::select( DB::raw("SELECT DISTINCT `$active_accounts_mapping->ACCESS_RULES` AS RULES FROM `$table_name` WHERE `$active_accounts_mapping->ACCESS_RULES` != '';"));

                //finds all cases that are not in the shortcodes
                $notFound = "";
                $invalidCodes = "";
                $noAgentCodeCombination = "";
                $allShorts = [];
                foreach($rules as $rule){
                    $newInvalid = false;
                    $checkIds = [];

                    //gets the rules into an array
                    if(strpos($rule->RULES, ' '))
                        $checks = str_replace(" ","",$rule->RULES);
                    else
                        $checks = $rule->RULES;
                    $checks = explode( ',', $checks);

                    foreach($checks as $check){
                        $inCodes = $corporateRules->where('shortcode', $check)->first();

                        if($inCodes == null){
                            //if there is no code put it in the 
                            $newInvalid = true;
                            $notFound = $check.', '.$notFound;
                        }
                        else{
                            $checkIds[] = $inCodes->id;
                        }
                        if(!array_key_exists($check, $allShorts))
                            $allShorts[$check] = $check;     
                    }

                    //checks that the current shortcode combination exists for the agents
                    if(count($checkIds) != 0){
                        sort($checkIds);
                        if(!in_array(implode(",",$checkIds),$agentAccessLevels)){
                            $noAgentCode = "";
                            rsort($checkIds);
                            foreach($checkIds as $ids){
                                $noAgentCode = $corporateRules->where('id', $ids)->first()->shortcode.', '.$noAgentCode;
                            }
                            $noAgentCodeCombination = '"'.substr_replace($noAgentCode,"",-2).'", '.$noAgentCodeCombination;
                            
                            $newInvalid = true;
                        }
                    }

                    if($newInvalid){
                        $invalidCodes = '"'.$rule->RULES.'", '.$invalidCodes;
                    }
                }

                //gets all the required shortcodes into a string
                $required = "";
                foreach($allShorts as $shorts){
                    $required = $shorts.'|'.$required;
                }
                $savePrevious->required_to_download = substr_replace($required,"",-1);

                //if one is not in the csv gets all the rows that failed and puts them into a new csv 
                if($notFound != ""){
                    $notFound = substr_replace($notFound, "", -2);
                    $invalidCodes = substr_replace($invalidCodes, "", -2);

                    $failedRows = DB::select( DB::raw("SELECT * FROM `$table_name` WHERE  `$active_accounts_mapping->ACCESS_RULES` IN  ($invalidCodes);"));

                    if(!is_dir(storage_path('app/public/CSVUploads/'.$corporation_id).'/failed'))
                        mkdir(storage_path('app/public/CSVUploads/'.$corporation_id).'/failed');

                    $failedFile = fopen(storage_path('app/public/CSVUploads/'.$corporation_id).'/failed/failed'.$fileNumber, 'x+');
                    fputcsv($failedFile, array_keys((array) $failedRows[0]));
                    
                    foreach($failedRows as $row){
                        fputcsv($failedFile, array_values((array) $row));
                    }

                    $savePrevious->failed_shortcodes = $filePath.'/failed/failed'.$fileNumber;
                    $savePrevious->status = "failed";
                    $savePrevious->save();

                    //drops table after it failed
                    $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));

                    return;
                }
                //if all shortcodes exist but there are any an agent cannot work
                else if($noAgentCodeCombination != ""){
                    $noAgentCodeCombination = substr_replace($noAgentCodeCombination, "", -2);
                    $invalidCodes = substr_replace($invalidCodes, "", -2);

                    $failedRows = DB::select( DB::raw("SELECT * FROM `$table_name` WHERE  `$active_accounts_mapping->ACCESS_RULES` IN  ($invalidCodes);"));

                    if(!is_dir($filePath.'/failed'))
                        mkdir($filePath.'/failed');

                    $failedFile = fopen($filePath.'/failed/failed'.$fileNumber, 'x+');
                    fputcsv($failedFile, array_keys((array) $failedRows[0]));
                    
                    foreach($failedRows as $row){
                        fputcsv($failedFile, array_values((array) $row));
                    }

                    $savePrevious->failed_shortcodes = $filePath.'/failed/failed'.$fileNumber;
                    $savePrevious->status = "failed";
                    $savePrevious->save();

                    //drops table after it failed
                    $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));

                    $errorMessage = count($failedRows)." shortcode(s) are not set, no active agents have access to the following combinations: ".$noAgentCodeCombination;
                    return redirect()->back()->with('error', $errorMessage);
                }
                
            }
            if($active_accounts_mapping->POESCORE != '')
            {
                DB::select(DB::raw("UPDATE `$table_name` SET `ON_HOLD` = 0 WHERE `$active_accounts_mapping->POESCORE` > ($corporate_settings->hold_accounts_below_score);")); 
            }
        
            if($corporate_settings->powerlead_active == 1){
       
                if($active_accounts_mapping->POWERLEAD_FLAG != ''){
                    DB::select(DB::raw("UPDATE `$table_name` SET `ON_HOLD` = $corporate_settings->power_hold WHERE `$active_accounts_mapping->POWERLEAD_FLAG` = 1;")); 
                }
                if($powerlead_settings->hold_accounts_automatically == 1)
                {
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                    ADD COLUMN `POWERLEAD_CAPCODE` TINYINT(4) NOT NULL DEFAULT NULL AFTER `ON_HOLD`;
                    "));
    
                    DB::select(DB::raw("UPDATE `$table_name` SET `POWERLEAD_CAPCODE` = 1 WHERE `$active_accounts_mapping->POWERLEAD_FLAG` = 1;")); 
    
                    $insert_statement = $insert_statement.", POWERLEAD_CAPCODE";
                    $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`POWERLEAD_CAPCODE`";
                }
            }
            if($corporate_settings->directory_option == 1){
                if(($powerlead_settings->hold_accounts_automatically == 1) && ($corporate_settings->powerlead_active == 1)){
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                    ADD COLUMN `DIRECTORY_FLAG` TINYINT(4) NOT NULL DEFAULT 1 AFTER `POWERLEAD_CAPCODE`;
                    "));
                }
                else{
                    DB::select( DB::raw("ALTER TABLE `$table_name` 
                    ADD COLUMN `DIRECTORY_FLAG` TINYINT(4) NOT NULL DEFAULT 1 AFTER `ON_HOLD`;
                    "));
                }
    
                $insert_statement = $insert_statement.", DIRECTORY_FLAG";
                $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`DIRECTORY_FLAG`";
            }
        
            // Inserting the columns from the CSV file that are requested into our database.
            DB::select( DB::raw("INSERT IGNORE INTO active_accounts 
                            ($insert_statement)
                            SELECT 
                        $insert_statement_CSV
                        FROM `$table_name`"));
        

            // Dropping table after insert has happened
            $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
            }
            catch(QueryException $e){
                $savePrevious->status = "failed";
                $savePrevious->save();

                return;
            }

        // Auto Hold Accounts 
        if($corporate_settings->hold_accounts_automatically == 0)
        {
            $this->dispatch(new TeamDistrubutionQueue($corporation_id));
        }
        if($corporate_settings->powerlead_active == 1 && $powerlead_settings->hold_accounts_automatically == 0){
            $this->dispatch(new PowerleadDistrubutonQueue($corporation_id));
        }

        //creates needed directory team accounts
        if($corporate_settings->directory_option == 1){
            //$this->dispatch(new DirectoryTeamDistributionQueue($corporation_id));
            $this->dispatch(new DirectoryAgentDistributionQueue($corporation_id));
        }

        $savePrevious->status = "sucess";
        $savePrevious->save();
        return 'success';
    }
}