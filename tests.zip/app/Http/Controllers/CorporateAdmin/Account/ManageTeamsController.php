<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Agent;
use App\Models\Corporate_Admin;
use App\Models\Distribution_Rules;
use App\Http\Controllers\Controller;
use App\Models\Manager;
use App\Models\Team;
use App\Models\Team_Distribution_Rules;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class ManageTeamsController extends Controller
{
    public function showManageTeams()
    {
        $corporate_admin = Auth::user()->corporation_corporate_admin_link;

        $teams = Team::where('corporation_id', '=', $corporate_admin->corporation_id)->get();

        return view('corporateAdmin.pages.account.manageTeams.dashboard')->with('teams', $teams)->with('corporate_admin', $corporate_admin);
    }

    public function addTeam(Request $request)
    {
        $this->validate($request, [
            'teamName' => 'required|max:90'
        ]);
        if (Team::where('name', '=', $request->teamName)->where('corporation_id', '=', $request->corporation_id)->doesntExist()) {
            $this->validate($request, [
                'teamName' => 'required',
            ]);
            $team = new Team;
            $team->name = $request->teamName;
            $team->corporation_id = $request->corporation_id;
            $team->max_accounts = 50;
            $team->max_attempts = 5;
            $team->team_goals = 8;
            $team->save();

            $rules = Distribution_Rules::where('corporation_id', $request->corporation_id)->first();
            if ($rules != null) {
                $team_distribution_rules = new Team_Distribution_Rules;
                $team_distribution_rules->priority = $rules->priority;
                $team_distribution_rules->second_priority = $rules->second_priority;
                $team_distribution_rules->third_priority = $rules->third_priority;
                $team_distribution_rules->team_id = $team->team_id;
                $team_distribution_rules->save();
            } else {
                $team_distribution_rules = new Team_Distribution_Rules;
                $team_distribution_rules->priority = 'ACCT_DUE_DATE';
                $team_distribution_rules->second_priority = 'POESCORE';
                $team_distribution_rules->team_id = $team->team_id;
                $team_distribution_rules->save();
            }

            return back()->with('message', 'Team Created');

        } else {
            return back()->with('error', 'Team Name Already Exists');
        }
    }

    public function updateTeam(Request $request)
    {
        $this->validate($request, [
            'name' => 'required|max:90',
            'max_accounts' => 'max:11',
            'max_attempts' => 'max:11',
            'checked.*' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'priority' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
            'prioritySecond' => 'in:ACCT_DUE_DATE,POESCORE,ACCT_SOURCE',
        ]);
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;

        $team = Team::where('team_id', $request->teamId)->where('corporation_id', $corporation_id)->first();
        if(empty($team)){
            return back()->with('error', 'Incorrect Team');
        }
        $team->name = $request->name;
        $team->max_accounts = $request->max_accounts;
        $team->max_attempts = $request->max_attempts;
        $team->team_goals = $request->team_goals;
        $team->Save();

        $rules = Team_Distribution_Rules::where('team_id', $team->team_id)->first();

        if($rules == null)
            $rules = new Team_Distribution_Rules;

        $rules->team_id = $team->team_id;

        //sets the priorities based on the number checked
        if(count($request->checked) == 1){
            $rules->priority = $request->checked[0];
            $rules->second_priority = null;
            $rules->third_priority = null;
        }
        else {
            $rules->priority = $request->priority;

            if(count($request->checked) == 2){
                if($request->priority != $request->checked[0])
                    $rules->second_priority = $request->checked[0];
                else
                    $rules->second_priority = $request->checked[1];

                $rules->third_priority = null;
            }
            if(count($request->checked) == 3){
                $rules->second_priority = $request->prioritySecond;
                $priorities[] = $request->priority;
                $priorities[] = $request->prioritySecond;

                if(!in_array('POESCORE', $priorities))
                    $rules->third_priority = 'POESCORE';
                else if(!in_array('ACCT_DUE_DATE', $priorities))
                    $rules->third_priority = 'ACCT_DUE_DATE';
                else
                    $rules->third_priority = 'ACCT_SOURCE';
            }
        }

        $rules->save();

        return back()->with('message', 'Team Updated');
    }

    public function editUsers($teamId)
    {

        $rules = Team_Distribution_Rules::where('team_id', $teamId)->first();

        //initalizes an array for what is set
        $preset[] = 0;
        $preset[] = 0;
        $preset[] = 0;

        if($rules != null){
            //sets priorities for dropdowns
            $priority[] = $rules->priority;
            $priority[] = $rules->second_priority;
            $priority[] = $rules->third_priority;

            //sets value to checked if they were set as a priority
            if(in_array('ACCT_DUE_DATE', $priority))
                $preset[0] = 1;
            if(in_array('POESCORE', $priority))
                $preset[1] = 1;
            if(in_array('ACCT_SOURCE', $priority))
                $preset[2] = 1;
        }
        else{
            $priority[] = "";
            $priority[] = "";
            $priority[] = "";
        }

        $corporate_admin = Auth::user()->corporation_corporate_admin_link;

        $team = Team::where('team_id', $teamId)->with('user_agent_link')->with('user_manager_link')->firstOrFail();

        $users = User::selectRaw('users.user_id, users.first_name, users.last_name, users.email, users.role, users.is_deactivated, users.active')
        ->leftJoin('agents', function ($join) {
            $join->on('agents.user_id', '=', 'users.user_id');
        })
        ->leftJoin('managers', function ($join) {
            $join->on('managers.user_id', '=', 'users.user_id');
        })->whereRaw('(agents.team_id = '.$teamId.' or managers.team_id = '.$teamId.')')->get(); 

        $teams = Team::where('corporation_id', $team->corporation_id)->get();


        //check that user has access to the team
        if ($team->corporation_id != $corporate_admin->corporation_id) {
            return back()->with('error', 'Access Denied. This Team Is Outside Of Your Company Scope');
        }
        return view('corporateAdmin.pages.account.manageTeams.editUsers')->with('users', $users)->with('team', $team)->with('teams', $teams)->with('preset', $preset)->with('priority', $priority);
    }

    public function updateUserTeam($userId, $teamId)
    {

        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $team = Team::findOrFail($teamId);
        if($corporation_id != $team->corporation_id){
            return back()->with('error', 'Incorrect team');
        }
        if (Agent::where('user_id', $userId)->where('corporation_id', $corporation_id)->exists()) {
            $agent = Agent::where('user_id', $userId)->first();
            $agent->team_id = $teamId;
            $agent->save();

            //removes the Agents accounts and moves worked accounts to the new team
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `LAST_WORKED` IS NULL AND `ACCT_AGENT` = '.$agent->agent_id.';'));
            DB::select(DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = '.$teamId.' WHERE `LAST_WORKED` IS NOT NULL AND `ACCT_AGENT` = '.$agent->agent_id.';'));

            return back()->with('message', 'User Updated to Team Successfully');
        }

        $manager = Manager::where('user_id', $userId)->where('corporation_id', $corporation_id)->firstOrFail();
        $manager->team_id = $teamId;
        $manager->save();

        return back()->with('message', 'User Updated to Team Successfully');
    }

    public function deactivateTeam($id)
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $team = Team::where('team_id', $id)->where('corporation_id', $corporation_id)->with('agent_link')->with('manager_link')->first();
        if(empty($team)){
            return back()->with('error', 'Incorrect team');
        }
        if (count($team->agent_link) > 0 || count($team->manager_link) > 0) {
            $userIds = [];

            foreach($team->agent_link as $agent) {
                $user = $agent->user_link;
                $userIds[] = $user->user_id;
            }

            foreach($team->manager_link as $manager) {
                $user = $manager->user_link;
                $userIds[] = $user->user_id;
            }

            if (!empty($userIds)) {
                $userIds = implode(',', $userIds);
                DB::select(DB::raw('UPDATE `users` SET `active` = 0, `is_deactivated` = 1, `deactivate_date`=NOW() WHERE `user_id` IN ('.$userIds.');'));
            }
        }


        //removes the teams accounts
        DB::select(DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = NULL, `TEAM_NAME` = NULL WHERE `TEAM_ID` = '.$team->team_id.';'));

        $team->is_deactivated = 1;
        $team->deactivate_date = Carbon::now();
        $team->save();

        return back()->with('message', $team->name . ' has been successfully deactivated.');
    }

    public function reactivateTeam($id)
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $team = Team::where('team_id', $id)->where('corporation_id', $corporation_id)->with('agent_link')->with('manager_link')->first();
        if(empty($team)){
            return back()->with('error', 'Incorrect team');
        }

        $team->is_deactivated = 0;
        $team->deactivate_date = null;
        $team->save();

        return back()->with('message', $team->name . ' has been successfully reactivated.');
    }

    public function sendUsertoEdit($agentId){
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $teamId = Agent::where('user_id', $agentId)->select('team_id')->where('corporation_id', $corporation_id)->first();
        if (empty($teamId)) {
            $teamId = Manager::where('user_id', $agentId)->select('team_id')->where('corporation_id', $corporation_id)->first();
        }
        if (empty($teamId)) {
            return back()->with('error', 'Incorrect User');
        }
        $teamId = $teamId->team_id;
        return $this->editUsers($teamId);
    }
}
