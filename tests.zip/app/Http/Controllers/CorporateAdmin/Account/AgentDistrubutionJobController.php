<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Corporation;
use App\Http\Controllers\Controller;
use App\Models\FTP;
use Symfony\Component\HttpFoundation\Request;
use Auth;
use Illuminate\Database\QueryException;
use App\Traits\AccountDistrubution;

class AgentDistrubutionJobController extends Controller
{
    use AccountDistrubution;
    public function distributeAccounts($id){
        $this->setAgentQueue($id);
        return "True";

    }
}
