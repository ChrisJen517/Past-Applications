<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Capcode;
use App\Models\Corporate_Admin;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Illuminate\Http\Request;
use App\Models\Team;
use Auth;
use DB;

class OverWorkedAccountQueueController extends Controller
{

    function showOverWorkedTable(){
        $corporation = Corporate_Admin::where("user_id", "=", Auth::user()->user_id)->get()->first();
        $overWorkedCapcode = Capcode::where('corporation_id', $corporation->corporation_id)->where('capcode', 2335)->first()->id;

        $activeTeams = Team::select('team_id')->where('corporation_id',$corporation->corporation_id)->where('is_deactivated', 0)->get();
        $activeTeamIds = [];
        foreach($activeTeams as $team){
            $activeTeamIds[] = "'".$team->team_id."'";
        }
        $activeTeamIds = implode(",", $activeTeamIds);

        $namesArray = array('N/A', 'ones', 'twos', 'threes', 'fours', 'fives', 'sixs', 'sevens', 'eights', 'nines', 'tens');
        $selectStatment = "SELECT TEAM_ID, (SELECT t.name FROM teams t WHERE t.TEAM_ID = inactives.TEAM_ID) AS TEAM_NAME,";
        for($i = 1; $i < 11; $i++){
            $selectStatment = $selectStatment." COUNT(IF(inactives.POESCORE = $i, 1, NULL)) AS ".$namesArray[$i]."OverWorkedTotal,";
            $selectStatment = $selectStatment." COUNT(IF(inactives.POESCORE = $i AND inactives.TIMES_OVERWORKED = 0, 1, NULL)) AS ".$namesArray[$i]."OverWorkedFirst,";
            $selectStatment = $selectStatment." COUNT(IF(inactives.POESCORE = $i AND inactives.TIMES_OVERWORKED > 0 , 1, NULL)) AS ".$namesArray[$i]."OverWorkedBefore,";
        }
        $selectStatment = substr($selectStatment, 0, -1);
        $selectStatment = $selectStatment."
        FROM inactive_accounts inactives 
        WHERE CORPORATION_ID = $corporation->corporation_id
        AND inactives.CAPCODE = $overWorkedCapcode
        AND Date(ACCT_DUE_DATE) >= curdate() 
        AND TEAM_ID IN ($activeTeamIds) 
        GROUP BY TEAM_ID";

        $teams = DB::select( DB::raw($selectStatment));

        return view('corporateAdmin/pages/account/overworkedAccountQueue')->with('teams', $teams)->with('namesArray', $namesArray);
    }

    public function releaseOverWorked(Request $request){
        //gets the needed capcode and corporation id
        $corporation = Corporate_Admin::where("user_id", "=", Auth::user()->user_id)->get()->first();
        $overWorkedCapcode = Capcode::where('corporation_id', $corporation->corporation_id)->where('capcode', 2335)->first()->id;

        //the where statement of the update and insert statements
        if(!empty($request->id)){
            $whereStatement = "WHERE ID = $request->id AND CORPORATION_ID = $corporation->corporation_id";
            $message = 'Overworked account: '.$request->id.' was released.';
        }
        else{
            $TeamName = Team::select('name')->find($request->teamIdRelease)->name ?? '';
            $whereStatement = "WHERE POESCORE = $request->scoreRelease AND TEAM_ID = $request->teamIdRelease AND CORPORATION_ID = $corporation->corporation_id AND CAPCODE = $overWorkedCapcode AND ACCT_DUE_DATE >= NOW()";
            $message = 'Overworked accounts of score: '.$request->scoreRelease.' and on team: '.$TeamName.' were released.';
        }

        //adds in a check for times overworked being 0
        if($request->firstOnly == 1)
            $whereStatement = $whereStatement." AND TIMES_OVERWORKED = 0";

        //controls the removal of agents from the update statement
        $removeAgents = "";
        if($request->keepAgent == 0){
            $removeAgents = ", ACCT_AGENT = NULL, TEAM_ID = NULL ";
        }
        
        //moves the accounts
        DB::select( DB::raw("INSERT INTO `active_accounts`
        SELECT * FROM `inactive_accounts`".$whereStatement.";"));

        //clears the accounts
        DB::select( DB::raw("DELETE from `inactive_accounts`".$whereStatement.";"));

        //removes the work attempts, the capcode, and possibly the agents from the selected accounts
        DB::select( DB::raw("UPDATE active_accounts SET WORK_ATTEMPTS = 0, ON_HOLD = 0, CAPCODE = NULL, UPDATED_AT = NOW(), TIMES_OVERWORKED = TIMES_OVERWORKED + 1 ".$removeAgents.$whereStatement.";"));

        return back()->with('message', $message);
    }

    public function showTeamsScore($team, $score){
        $team = Team::find($team);
        $corporationId = Auth::user()->corporate_admin_link->corporation_id;
        $overWorkedCapcode = Capcode::where('corporation_id', $corporationId)->where('capcode', 2335)->first()->id;

        $accounts = Inactive_Account::selectRaw("id as overWorkedId, acct_agent, acct_due_date, ACCT_CASE, EMPL_ST, acct_id, EMPL_NAME, EMPL_PHONE1_NMBR,
        POESCORE,
        (select notes from worked_history where CAPCODE != $overWorkedCapcode and active_account_id = overWorkedId and user_role = 'agent' order by created_at desc limit 1) as last_note,
        (select capcodes.capcode from worked_history inner join capcodes on worked_history.capcode = capcodes.id where capcodes.capcode != 2335 and user_role = 'agent' and active_account_id = overWorkedId order by worked_history.created_at desc limit 1) as last_capcode,
        last_worked,
        TIMES_OVERWORKED")
        ->where('team_id', $team->team_id)
        ->when($score != 'all', function ($query) use ($score) {
            return $query->where('POESCORE', $score);
        })
        ->where('CAPCODE', $overWorkedCapcode)
        ->whereRaw('Date(ACCT_DUE_DATE) >= curdate()')
        ->get();

        return view('corporateAdmin/pages/account/overworkedTeamScore')->with('team', $team)->with('accounts', $accounts)->with('score', $score);
    }
}