<?php

namespace App\Http\Controllers\CorporateAdmin\Account;

use App\Models\Access_Levels;
use App\Models\Agent;
use App\Models\CorporateAdmin;
use App\Models\Corporate_Admin;
use App\Models\Corporation;
use App\Http\Controllers\Controller;
use App\Models\Manager;
use App\Models\old_passwords;
use App\RNNMailer;
use App\Traits\AccountDistrubution;
use App\User;
use App\Models\Team;
use Auth;
use Carbon\Carbon;
use Config;
use DB;
use File;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use PHPMailer\PHPMailer\PHPMailer;
use App\Traits\MangeRoleAccounts;
use Storage;
use Illuminate\Support\Facades\Log;


class manageUsersController extends Controller
{
    use AccountDistrubution, MangeRoleAccounts;

    private $notAllowedIds = array(
        '1901', '1902', '1904', '3333', '9999'
    );

    public function manageUsers()
    {
        $corporateAdmin = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
        $corporationName = Corporation::select('name')->where('corporation_id', $corporateAdmin->corporation_id)->first()->name ?? '';
        $users = User::selectRaw('users.user_id, users.first_name, users.last_name, users.email, users.role, users.role_list, users.has_access, users.is_deactivated, users.active, managers.team_id as manager_team, agents.team_id as agent_team, users.role_list')
        ->leftJoin('agents', function ($join) {
            $join->on('agents.user_id', '=', 'users.user_id');
        })
        ->leftJoin('managers', function ($join) {
            $join->on('managers.user_id', '=', 'users.user_id');
        })->whereRaw('(agents.corporation_id = '.$corporateAdmin->corporation_id.' or managers.corporation_id = '.$corporateAdmin->corporation_id.') AND (users.role_list NOT LIKE "%admin%" or users.role_list is null)')->get();
        $teams = Team::where('corporation_id', $corporateAdmin->corporation_id)->get();
        $access_levels = Access_Levels::where('corporation_id', $corporateAdmin->corporation_id)->get();
        $user_levels = explode(',', Auth::user()->has_access);
        return view('corporateAdmin.pages.account.manageUsers')->with('users', $users)->with('teams', $teams)->with('access_levels', $access_levels)->with('user_levels', $user_levels)->with('corporationName', $corporationName);
    }

    public function addUser(Request $request)
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $team = Team::findOrFail($request->team_id);
        if($team->corporation_id != $corporation_id){
            return back()->with('error', 'Incorrect Team Selection');
        }

        $this->validate($request, [
            'first_name' => 'required|max:90',
            'last_name' => 'required|max:90',
            'team_id' => 'required|max:20',
            'email' => 'required|unique:users|max:90',
            'role' => 'required|in:manager,agent',
        ]);

        $role_list = $request->input('role_list');
        if($role_list == null){
            $role_list = [];
        }
        if(!in_array($request->input('role'), $role_list))
            $role_list[] = $request->input('role');
        $role_list = implode(',', $role_list);

        if(!empty($request->agent_id)) {
            if(Agent::where('agent_id', $request->agent_id)->where('user_id', '!=', $request->idName)->exists() || in_array($request->agent_id, $this->notAllowedIds))
                return back()->with('error', "Agent ID is already in use");
        }

        switch($request->input('role')) {
            case 'manager':
                $new_account = new Manager();
                $new_account->corporation_id = $corporation_id;
                $new_account->team_id = $request->input('team_id');
                break;
            case 'agent':
                $new_account = new Agent();
                $new_account->corporation_id = $corporation_id;
                $new_account->team_id = $request->input('team_id');

                if($request->agent_id != '') {
                    if(!empty(Agent::find($request->agent_id)) || in_array($request->agent_id, $this->notAllowedIds))
                        return back()->with('error', "Agent ID is already in use");
                    $new_account->agent_id = $request->agent_id;
                }
                break;
        }

        $user = new User();

        $user->email = $request->email;
        $token = rand(100000000000, 999999999999);
        //$user->password = bcrypt("Password1!");
        $user->password = bcrypt($token);
        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;
        $user->role = $request->role;
        $user->password_valid = 0;
        $user->active = 1;
        $user->role_list = $role_list;
        $user->save();


        if($new_account != null) {
            $new_account->user_id = $user->user_id;
            $new_account->save();
        }
        $this->AddRoleAccounts($user, $corporation_id, $request->team_id, $request->agent_id);

        $path = '/home/rocky/public_html/ProfilePictures/'.$user->user_id.'';
        $env = Config::get('app.env');
        if ($env != 'prod') {
            $path = public_path('ProfilePictures/'.$user->user_id.'');
        }
        if (!file_exists($path)) {
            mkdir($path);
        }
        $file = File::get(public_path('ProfilePictures/baseAvatar.png'));
        File::put(public_path('ProfilePictures/' . $user->user_id . '/avatar.png'), $file);

        $mail = new RNNMailer(true, $user);

        //Recipients
        $mail->addAddress($request->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $request->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        $success = ucfirst($user->role) . ' Created!';
        return redirect('corporateAdmin/manageUsers')->with("success", $success);
    }

    public function blockAgent($id)
    {
        $User = User::with('agent_link')->find($id);
        if($User->user_id == Auth::user()->user_id)
            return back()->with('error', 'You cannot block yourself');

        if ($User->role == 'agent') {
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = null WHERE ACCT_AGENT = ' . $User->agent_link->agent_id . ';'));
        }

        $User->active = 0;
        $User->save();

        $this->deactivateRoles($User, explode(',', $User->role_list));
        return redirect()->back()->with('message', 'Agent Blocked');
    }

    public function unblockAgent($id)
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;
        $User = User::with('agent_link')->find($id);
        $User->active = 1;
        $User->save();
        if ($User->role == 'agent') {
            $message = $this->redistributeToAgent($User->agent_link->agent_id);
        } else {
            $message = 'Manager Unblocked';
        }

        //reactives all their roles
        $this->AddRoleAccounts($User, $corporation_id, null, null);
        return redirect()->back()->with('message', $message);
    }

    public function pauseAgent($agentId, $willPause) {
        $agent = Agent::where('agent_id', $agentId)->first();
        if (empty($agent)) {
            $data[] = 'Invalid agent.';
            $data[] = "error";
            return response()->json($data);
        }

        $agent->paused = $willPause ? 1 : 0;
        $agent->save();

        return response()->json('Successfully ' . ($willPause ? "" : "un") . "paused the agent's queue.");
    }

    public function deleteAgent($id)
    {

        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;

        $user = User::find($id);

        if (empty($user)) {
            return back()->with('error', 'Incorrect User');
        } else if($user == Auth::user()) {
            return back()->with('error', 'You cannot delete yourself');
        }

        if ($user->role == 'agent') {
            $agent = Agent::where('user_id', $user->user_id)->firstOrFail();
            if ($agent->corporation_id != $corporation_id) {
                return back()->with('error', 'Incorrect User');
            }
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = ' . $user->agent_link->agent_id . ';'));
        } else if ($user->role == 'manager') {
            $manager = Manager::where('user_id', $user->user_id)->firstOrFail();
            if ($manager->corporation_id != $corporation_id) {
                return back()->with('error', 'Incorrect User');
            }
        } else if ($user->role == 'corporate_admin') {
            $corporate_admin = Corporate_Admin::where('user_id', $user->user_id)->firstOrFail();
            if ($corporate_admin->corporation_id != $corporation_id) {
                return back()->with('error', 'Incorrect User');
            }
        } else if ($user->role != 'agent' && $user->role != 'manager' && $user->role != 'corporate_admin') {
            return back()->with('error', 'Incorrect User');
        }
        $user->active = 0;
        $user->is_deactivated = 1;
        $user->deactivate_date = Carbon::now();
        $user->save();

        $this->deactivateRoles($user, explode(',', $user->role_list));
        return redirect()->back()->with('message', 'User Deactivated');
    }

    public function reactivateAgent($id, $team_id)
    {

        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;

        $user = User::find($id);

        if (empty($user)) {
            return back()->with('error', 'Incorrect User');
        }

        switch($user->role) {
            case 'agent':
                $role_profile = Agent::where('user_id', $user->user_id)->firstOrFail();
                if ($role_profile->corporation_id != $corporation_id)
                    return back()->with('error', 'Incorrect User');
                break;

            case 'manager':
                $role_profile = Manager::where('user_id', $user->user_id)->firstOrFail();
                if ($role_profile->corporation_id != $corporation_id)
                    return back()->with('error', 'Incorrect User');
                break;

            default:
                return back()->with('error', 'Incorrect User');
        }

        if($team_id != $role_profile->team_id && $role_profile->team_id != NULL){
            $role_profile->team_id = $team_id;
            $role_profile->save();
        }
        if(Team::where('team_id', $team_id)->exists()) {
            $team = Team::find($team_id);
            $team->is_deactivated = 0;
            $team->save();
        }
        $user->active = 1;
        $user->is_deactivated = 0;
        $user->deactivate_date = NULL;
        $user->save();

        //reactives all their roles
        $this->AddRoleAccounts($user, $corporation_id, null);
        return redirect()->back()->with('message', 'User Reactivated');
    }


    public function updateUser(Request $request)
    {
        $this->validate($request, [
            'first_name' => 'required:max:90',
            'last_name' => 'required:max:90',
            'password' => 'max:90',
            'c_password' => 'same:password',
        ]);
        $list = '';
        if ($request->exists('accessLevels') && !empty($request->accessLevels)) {
            foreach ($request->accessLevels as $access) {
                $list = $list . $access . ',';
            }
        }
        $list = substr_replace($list, '', -1);

        $user = User::findOrFail($request->idName);

        $role_list = $request->input('role_list');
        if($role_list == null){
            $role_list = [];
        }
        $role_list = implode(',', $role_list);
        $old_role_list = $user->role_list;
        $user->role_list = $role_list;

        $user->first_name = $request->first_name;
        $user->last_name = $request->last_name;

        //if agent has their accounts changed removes them
        $redistribute = false;
        if (($user->has_access != $list) && ($user->role == 'agent')) {
            $redistribute = true;
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = ' . $user->agent_link->agent_id . ';'));
        }

        $user->has_access = $list;

        if ($request->newPassword != null) {
            $date = Carbon::now()->subDays(365)->format('Y-m-d');
            $passwordHistories = $user->passwordHistories()->where("created_at", '>', $date)->get();
            foreach ($passwordHistories as $passwordHistory) {
                echo $passwordHistory->password;
                if (Hash::check($request->get('newPassword'), $passwordHistory->password)) {
                    // The passwords matches
                    return redirect()->back()->with("error", "Your new password can not be same as any of your recent passwords. Please choose a new password.");
                }
            }

            $oldPassword = new old_passwords();
            $oldPassword->password = $user->password;
            $oldPassword->user_id = $request->idName;
            $oldPassword->save();
            $user->password = bcrypt($request->input('newPassword'));
        }

        if($old_role_list != $role_list){
            switch ($user->role){
                case "manager":
                    $manager = Manager::select('corporation_id', 'team_id')->where('user_id', $user->user_id)->first();
                    $corporationId = $manager->corporation_id;
                    $teamId = $manager->team_id;
                break;
                case "agent":
                    $agent = Agent::select('corporation_id', 'team_id')->where('user_id', $user->user_id)->first();
                    $corporationId = $agent->corporation_id;
                    $teamId = $agent->team_id;
                break;
            }
            $this->AddRoleAccounts($user, $corporationId, $teamId);

            //checks to see if there are any missing roles
            $old_role_list = explode(',', $old_role_list);
            $role_list = explode(',', $role_list);
            $missing_roles = [];
            foreach($old_role_list as $old_role){
                if(!in_array($old_role, $role_list))
                    $missing_roles[] = $old_role;
            }
            //deactivates any missing roles
            if(!empty($missing_roles)){
                $this->deactivateRoles($user, $missing_roles);
            }
            if(in_array($user->role, $missing_roles))
                $user->role = $role_list[0];
        }

        $user->save();

        //if the account is removed, redistribute
        if ($redistribute) {
            $this->redistributeToAgent($user->agent_link->agent_id);
        }

        return redirect()->back()->with("success", "Agent Updated");
    }

    public function getAccessIds(Request $request)
    {

        $shortcodes = $request->titles;
        $access_levels = Access_Levels::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->get();
        $accessIds = [];
        foreach ($access_levels as $access) {
            if (in_array($access->shortcode, $shortcodes)) {
                $accessIds[] = $access->id;
            }
        }

        echo json_encode($accessIds);

    }

    public function sendPasswordReset($id)
    {
        $corporation_id = Auth::user()->corporate_admin_link->corporation_id;

        $User = User::find($id);
        if (empty($User)) {
            return back()->with('error', 'Incorrect User');
        }
        if ($User->role == 'agent') {
            $agent = Agent::where('user_id', $User->user_id)->firstOrFail();
            if ($agent->corporation_id != $corporation_id) {
                return back()->with('error', 'Incorrect User');
            }
        } else if ($User->role == 'manager') {
            $manager = Manager::where('user_id', $User->user_id)->firstOrFail();
            if ($manager->corporation_id != $corporation_id) {
                return back()->with('error', 'Incorrect User');
            }
        } else if ($User->role == 'corporate_admin') {
            $corporate_admin = Corporate_Admin::where('user_id', $User->user_id)->firstOrFail();
            if ($corporate_admin->corporation_id != $corporation_id) {
                return back()->with('error', 'Incorrect User');
            }
        } else if ($User->role != 'agent' && $User->role != 'manager' && $User->role != 'corporate_admin') {
            return back()->with('error', 'Incorrect User');
        }

        $oldPassword = new old_passwords();
        $oldPassword->password = $User->password;
        $oldPassword->user_id = $User->user_id;
        $oldPassword->save();
        $token = rand(100000000000, 999999999999);
        $User->password = bcrypt($token);
        $User->password_valid = 0;
        $User->save();

        $mail = new RNNMailer(true, $User);

        //Recipients
        $mail->addAddress($User->email);

        // Content<p>{{  }}</p>
        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "Account Login for RockySkipTracing";
        $mail->Body = "Your Account Name is $User->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

        // Mail Send
        $mail->send();

        return redirect()->back()->with('message', 'Password Reset');

        Log::debug("Password reset for: ".$User->first_name." ".$User->last_name." By: ".Auth::user()->first_name." ".Auth::user()->last_name);

    }
}
