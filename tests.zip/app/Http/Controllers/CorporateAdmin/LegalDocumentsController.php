<?php
namespace App\Http\Controllers\CorporateAdmin;

use App\Models\Acct_Case;
use App\Models\Active_Account;
use App\Models\Directory_Inactive_Account;
use App\Models\Corporation;
use Carbon\Carbon;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Legal_Document;
use App\Models\Powerlead_Accounts;
use Auth;
use DB;
use Illuminate\Http\Request;

use function PHPSTORM_META\type;

class LegalDocumentsController extends Controller
{
    public function seeDocuments(){
        $user = Auth::user();

        $documents = Legal_Document::where('user_id', $user->user_id)->get();

        return view('corporateAdmin.pages.legalDocuments')->with('documents', $documents)->with('name', $user->first_name." ".$user->last_name);
    }

    public function uploadDocument(Request $request){
        //gets the uploaded files extension
        $extension = pathinfo($_FILES['fileUpload']['name'], PATHINFO_EXTENSION);

        //adds a name based on if the user entered one or the files name
        if($request->file_name != null)
            $name = $request->file_name;
        else 
            $name = $_FILES['fileUpload']['name'];

        //makes sure file name has an extension
        $nameType = pathinfo($name , PATHINFO_EXTENSION);
        if($nameType == null)
            $name = $name.".".$extension;
        

        $user_id = Auth::user()->user_id;

        $filepath = 'legalFiles/'.$user_id.'/'.$name;

        //saves the file
        $file = $request->file('fileUpload');
        $download = $file->storeAs('legalFiles/'.$user_id, $name);

        $document = new Legal_Document();
        $document->name = $name;
        $document->type = $extension;
        $document->file_path = $filepath; 
        $document->description = $request->description;
        $document->user_id = $user_id;
        $document->save();

        return back()->with('success', 'Document Uploaded!');
    }

    public function editDocument(Request $request){
        $document = Legal_Document::where('document_id', $request->id_edit)->first();
        $user_id = Auth::user()->user_id;      
        
        //if a new document is uploaded
        if($request->file_upload_edit != null){
            $extension = pathinfo($_FILES['file_upload_edit']['name'], PATHINFO_EXTENSION);

            if($request->file_name_edit != null)
                $name = $request->file_name_edit;
            else 
                $name = $_FILES['file_upload_edit']['name'];

            $nameType = pathinfo($name , PATHINFO_EXTENSION);

            if($nameType == null)
                $name = $name.".".$extension;
            

            //saves the file
            $filepath = 'legalFiles/'.$user_id.'/'.$name;

            $file = $request->file('file_upload_edit');
            $download = $file->storeAs('legalFiles/'.$user_id, $name);

            $document->file_path = $filepath; 
        }
        else{
            $extension = pathinfo($document->file_path, PATHINFO_EXTENSION);

            //if the user chose to rename the document
            if(($request->file_name_edit != null) && ($request->file_name_edit != $document->name)){
                $name = $request->file_name_edit;
                $nameType = pathinfo($name , PATHINFO_EXTENSION);

                if($nameType == null)
                    $name = $name.".".$extension;

                //renames the document
                $filepath = 'legalFiles/'.$user_id.'/'.$name;
                rename(storage_path('app/public/'.$document->file_path), storage_path('app/public/'.$filepath));
                $document->file_path = $filepath; 
            }
            else
                $name = $document->name;
        }

        $document->name = $name;
        $document->type = $extension;
        $document->user_id = $user_id;
        $document->description = $request->description_edit;
        $document->save();

        return back()->with('success', 'Document Edited!');
    }

    //downloads the users document
    public function downloadDocument(Request $request){
        $file_path = Legal_Document::where('document_id', $request->id)->first()->file_path;

        return response()->download(storage_path('app/public/'.$file_path), null, [
            'Cache-Control' => 'no-cache, no-store, must-revalidate',
            'Pragma' => 'no-cache',
        ]);
    }

    //deletes the document if the user has access
    public function deleteDocument($id){
        $document = Legal_Document::where('document_id', $id)->where('user_id', Auth::user()->user_id)->first();

        if($document == null)
            return back()->with('error', 'document does not exist or you do not have access!');

        unlink(storage_path('app/public/'.$document->file_path));

        $document->delete();


        return back()->with('success', 'Document Deleted!');
    }
}