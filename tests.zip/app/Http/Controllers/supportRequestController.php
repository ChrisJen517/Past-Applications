<?php

namespace App\Http\Controllers;

use App\Models\Message;
use App\Models\Message_Thread;
use Illuminate\Http\Request;
use Auth;

class supportRequestController extends Controller
{
    public function allContact(){
        $role = Auth::user()->role;
        if(($role != 'manager') && ($role != 'corporate_admin') && ($role != 'powerlead_directory_manager'))
            return back()->with('error', "Not allowed for agents");

        //gets the most recent thread's id
        $mostRecent = Message_Thread::where('user_id', Auth::user()->user_id)->orderByDesc("updated_at")->first();

        if($mostRecent == NULL)
            return view('manageContactUs.clientSide.allContact')->with('startID', -1)->with('startTime', -1);

        return view('manageContactUs.clientSide.allContact')->with('startID', $mostRecent->thread_id)->with('startTime', $mostRecent->updated_at);
    }

    public function allMessages($id){
        //loads all messages of the thread
        $title = Message_Thread::where('thread_id', $id)->first();
        
        //only updates it if the last read message was an admin message
        if($title->answer_admin == 1){
            $title->answer_admin = 2;
            $title->save();
        }

        $messages = Message::where('thread_id', $id)->get();

        return view('manageContactUs.clientSide.messages')->with('messages', $messages)->with('title', $title->title);
    }

    public function allThreads(){
        //gets the thread ids belonging to the user
        $threads = Message_Thread::where('user_id', Auth::user()->user_id)->orderByDesc("updated_at")->get();

        return view('manageContactUs.clientSide.threads')->with('help', $threads);
    }

    public function findThread($search){
        //gets the thread ids belonging to the user
        $threads = Message_Thread::where('user_id', Auth::user()->user_id)->where('title','like','%'.$search.'%')->get();

        return view('manageContactUs.clientSide.threads')->with('help', $threads);
    }

    public function newRequest(Request $request){
        $this->validate($request, [
            'supportRequestTitle' => 'required|max:50',
            'supportRequestMessage' => 'required|max:250',
        ]);
        //creates the new thread
        $date = date('Y-m-d H:i:s');
        $thread = new Message_Thread();
        $thread->user_id = $request->supportRequestUserId;
        $thread->title = $request->supportRequestTitle;
        $thread->answer_admin = 0;
        $thread->created_at = $date;
        $thread->updated_at = $date;
        $thread->save();

        //creates a new message for the new thread
        $message = new Message();
        $message->user_id = $request->supportRequestUserId;
        $message->message = $request->supportRequestMessage;
        $message->role = 'client';
        $message->thread_id = $thread->thread_id;
        $message->save();

        return back()->with('success', 'Request sent to an admin');
    }

    //the funtion for allowing the user to send a response
    public function respondRequest(Request $request){
        $this->validate($request, [
            'message' => 'required|max:250'
        ]); 
        //saves the message
        $message = new Message();
        $message->user_id = $request->userId;
        $message->message = $request->message;
        $message->role = 'client';
        $message->thread_id = $request->thread_id;
        $message->save();

        //updates the thread updated at
        $thread = Message_Thread::find($request->thread_id);
        $thread->answer_admin = 0;
        $thread->updated_at= $message->created_at;
        $thread->save();
    }

    public function recentTime(){
        //returns the most recent message from one of the users threads
        echo Message_Thread::where('user_id', Auth::user()->user_id)->where('answer_admin', 1)->orderByDesc("updated_at")->first();
    }

    public function numberOfMessages(){
        echo Message_Thread::where('user_id', Auth::user()->user_id)->where('answer_admin', 1)->count();
    }
}