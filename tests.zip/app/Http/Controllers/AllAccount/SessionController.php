<?php

namespace App\Http\Controllers\AllAccount;

use App\Models\Activity_Log;
use App\Http\Controllers\Controller;
use Carbon\Carbon;
use DateTime;
use Illuminate\Http\Request;

class SessionController extends Controller
{
    public function updateSession(Request $request)
    {

        $last_activity = date('Y-m-d H:i:s', $request->time);
        
        session('lastActivityTime', $request->time);

        $log = Activity_Log::find(session('key'));

        $log->last_activity = $last_activity;
        $log->save();

    }

    public function checkLogout()
    {
        
        $logs = Activity_Log::whereNull('logout')->whereNotNull('login')->whereNotNull('last_activity')->get();

        foreach ($logs as $log) {
            $end = new Carbon();
            $start = new Carbon($log->last_activity);
            $timeDiff = $start->diffInHours($end) . '0:' . $start->diff($end)->format('%I:%S');
            if ($timeDiff >= "00:44:00") {
                $log->logout = $log->last_activity;
                $login = new Carbon($log->login);
                $logout = new Carbon($log->logout);
                $total = $login->diffInHours($logout) . ':' . $login->diff($logout)->format('%I:%S');
                $log->total_time = $total;
                $log->save();
            }
        }

        return back()->with('success', 'updated logout');
    }
}
