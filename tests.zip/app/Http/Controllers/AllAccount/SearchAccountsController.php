<?php

namespace App\Http\Controllers\AllAccount;

use Illuminate\Http\Request;
use App\Traits\HasAccess;
use App\Http\Controllers\Controller;
use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\Models\Capcode;
use App\Models\Corporate_Settings;
use App\Models\Worked_History;
use App\Models\Agent;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class SearchAccountsController extends Controller
{
    function searchAccounts(Request $request)
    {
        //finds the historys with distinct accounts up to the first 1,000 orderd by most recent first
        $historyIds = [];
        $user = Auth::user();
        $role = $user->role;
        $link = null;

        if (!empty($request->keywords)) {
            switch ($role) {
                case "agent":
                    $link = $user->agent_link;
                break;
                case "manager":
                    $link = $user->manager_link;
                break;
                case "corporate_admin":
                    $link = $user->corporate_admin_link;
                break;
            }

            $corporation_id = $link->corporation_id;
            $keywords = $request->keywords;

            $activeQuery = "SELECT DISTINCT(worked_history.active_account_id), worked_history.created_at FROM worked_history
            INNER JOIN active_accounts ON worked_history.active_account_id = active_accounts.ID
            WHERE active_accounts.ON_HOLD = 0 AND worked_history.notes like '%$keywords%'" . (!empty($link) ? " AND active_accounts.CORPORATION_ID = $corporation_id" : "");

            $inactiveQuery = "SELECT DISTINCT(worked_history.active_account_id), worked_history.created_at FROM worked_history
            INNER JOIN inactive_accounts ON worked_history.active_account_id = inactive_accounts.ID
            WHERE inactive_accounts.ON_HOLD = 0 AND worked_history.notes like '%$keywords%'" . (!empty($link) ? " AND inactive_accounts.CORPORATION_ID = $corporation_id" : "");

            $workedHistory = DB::select(DB::raw("SELECT * FROM ($activeQuery UNION $inactiveQuery ORDER BY created_at DESC) AS workHistory group by active_account_id ORDER BY created_at DESC LIMIT 1000"));

            foreach ($workedHistory as $history)
                $historyIds[] = $history->active_account_id;

            if (empty($historyIds))
                $historyIds[] = 0;
        }

        $searchFunction = function ($q) use ($request, $historyIds, $user) {
            if ($user->role == 'agent')
                $q->where('CORPORATION_ID', $user->agent_link->corporation_id);
            else if ($user->role == 'manager')
                $q->where('CORPORATION_ID', $user->manager_link->corporation_id);
            else if ($user->role == 'corporate_admin')
                $q->where('CORPORATION_ID', $user->corporate_admin_link->corporation_id);
            else if ($request->corporation_id != null)
                $q->where('CORPORATION_ID', 'like', '%' . $request->corporation_id . '%');

            if ($request->unique_Id != null)
                $q->where('ID', $request->unique_Id);
            if ($request->first_name != null)
                $q->where('ACCT_FIRST_NAME', 'like', '%' . $request->first_name . '%');
            if ($request->last_name != null)
                $q->where('ACCT_LAST_NAME', 'like', '%' . $request->last_name . '%');
            if ($request->employer_name != null)
                $q->where('EMPL_NAME', 'like', '%' . $request->employer_name . '%');
            if ($request->agent_que != null)
                $q->where('ACCT_AGENT', $request->agent_que);
            if ($request->SSN != null) {
                $SSN = str_replace('-', '', $request->SSN);
                $q->where('ACCT_SSN', 'like', '%' . $SSN . '%');
            }
            if ($request->account_id != null)
                $q->where('ACCT_ID', $request->account_id);
            if ($request->case_num != null)
                $q->where('ACCT_CASE', $request->case_num);
            if ($request->client_name != null)
                $q->where('CLIENT_NAME', 'like', '%' . $request->client_name . '%');
            if ($request->corporation_id != null)
                $q->where('CORPORATION_ID', 'like', '%' . $request->corporation_id . '%');
            if (!empty($historyIds))
                $q->whereIn('ID', $historyIds);
        };

        //gets active accounts
        $activeAccounts = Active_Account::where($searchFunction)
        ->when(empty($historyIds), function ($q) {
            $q->limit(500);
        })->get();

        //gets inactive accounts
        if ($request->agent_que == null) {
            $inactiveAccounts = Inactive_Account::where($searchFunction)
            ->when(empty($historyIds), function ($q) {
                $q->limit(500);
            })->get();
        } else
        $inactiveAccounts = null;

        //gets corporations capcode
        $capcode = null;
        $show = 1;
        $agents = '';
        switch ($role) {
            case "admin":
                $capcode = Capcode::get();
            break;
            case "agent":
                $capcode = Capcode::where('CORPORATION_ID', $user->agent_link->corporation_id)->get();
                $show = Corporate_Settings::where('corporation_id', $user->agent_link->corporation_id)->select('show_client')->first();

                if ($show != null)
                    $show = $show->show_client;
                else
                    $show = 0;
            break;
            case "manager":
                $capcode = Capcode::where('CORPORATION_ID', $user->manager_link->corporation_id)->get();

                $agents = $this->getAgents($user->manager_link->team_id, $role);
                $agents = DB::SELECT(DB::RAW("SELECT agents.agent_id AS agent, first_name, last_name
                        FROM users  LEFT JOIN agents ON users.user_id = agents.user_id
                        WHERE agents.agent_id IN ($agents) AND users.is_deactivated = 0 GROUP BY agents.agent_id;"));
            break;
            case "corporate_admin":
                $capcode = Capcode::where('CORPORATION_ID', $user->corporate_admin_link->corporation_id)->get();

                $agents = $this->getAgents($user->corporate_admin_link->corporation_id, $role);
                $agents = DB::SELECT(DB::RAW("SELECT agents.agent_id AS agent, first_name, last_name, teams.name AS team_name
                        FROM users  LEFT JOIN agents ON users.user_id = agents.user_id
                        LEFT JOIN teams ON agents.team_id = teams.team_id
                        WHERE agents.agent_id IN ($agents) AND users.is_deactivated = 0 GROUP BY agents.agent_id ORDER BY team_name ASC;"));
            break;
        }

        $accessList = [];
        if (!empty($user->has_access)) {
            $user_access = DB::Select(DB::Raw('Select shortcode from access_levels where id in(' . $user->has_access . ')'));

            foreach ($user_access as $access) {
                $accessList[] = strtoupper($access->shortcode);
            }
        }

        $accountTypes = [$activeAccounts, $inactiveAccounts];

        return view('allAccount/searchResults')
        ->with('capcode', $capcode)->with('accessList', $accessList)->with('show', $show)
        ->with('agents', $agents)->with('accountTypes', $accountTypes);
    }

    public function getAgents($id, $role)
    {
        switch ($role) {
            case "corporate_admin":
                $agents = Agent::where('corporation_id', $id)->get();
            break;
            case "manager":
                $agents = Agent::where('team_id', $id)->get();
            break;
        }

        $agentList = '';
        foreach ($agents as $agent)
            $agentList = $agentList . ' "' . $agent->agent_id . '",';

        $agentList = substr_replace($agentList, '', -1);

        if ($agentList == '')
            $agentList = '0';

        return $agentList;
    }

    use HasAccess;
    public function changeAgent(Request $request)
    {
        $user = Auth::user();

        $account = Active_Account::where("ID", $request->account)->get()->first();
        if (empty($account))
            $account = Inactive_Account::where("ID", $request->account)->get()->first();


        if (in_array($request->agent, [1901, 1902, 1904])) {
            $reassign_capcode = Capcode::where('capcode', '2100')->where('corporation_id', $account->CORPORATION_ID)->first();
            $history = new Worked_History;
            $history->capcode = $reassign_capcode->id ?? 2100;
            $history->active_account_id = $account->ID;
            $history->agent_id = $user->user_id;
            $history->user_role = $user->role;
            $history->notes = "Account assigned from " . $account->ACCT_AGENT . " to " . $request->agent . ". " . $request->reason . ".";
            $history->save();

            $account->TEAM_ID = 10;
            $account->ACCT_AGENT = $request->agent;
            $account->save();

            $response_array['status'] = 'success';
            return json_encode($response_array);
        }

        $original_agent = Agent::find($account->ACCT_AGENT);
        $new_agent = Agent::find($request->agent);
        $can_work = $this->checkAgentAccess($account->ID, $new_agent->agent_id);

        if (!$can_work) {
            $response_array['status'] = 'Agent does not have the access level for this account!';
            return json_encode($response_array);
        }

        if (empty($original_agent)) {
            $original_agent = "no assigned agent";
        } else {
            if ($original_agent->agent_id == $new_agent->agent_id) {
                $response_array['status'] = 'That agent is already assigned to this account!';
                return json_encode($response_array);
            }
            $original_agent = $original_agent->user_link->first_name . ' ' . $original_agent->user_link->last_name;
        }

        if ($user->role == 'manager') {
            if ($user->manager_link->team_id != $new_agent->team_id) {
                $response_array['status'] = 'Error, you tried to assign an agent that is not on your team!';
                return json_encode($response_array);
            }
            $account->ACCT_AGENT = $request->agent;
            $account->save();
        } else if ($user->role == 'corporate_admin') {
            if ($new_agent->corporation_id != $user->corporate_admin_link->corporation_id) {
                $response_array['status'] = 'Error, you tried to assign an agent that is not in your corporation!';
                return json_encode($response_array);
            }
            $account->TEAM_ID = $new_agent->team_id;
            $account->ACCT_AGENT = $request->agent;
            $account->save();
        } else {
            $response_array['status'] = 'Error, you can not reassign this agent!';
            return json_encode($response_array);
        }

        $new_agent = $new_agent->user_link->first_name . ' ' . $new_agent->user_link->last_name;

        $reassign_capcode = Capcode::where('capcode', '2100')->where('corporation_id', $account->CORPORATION_ID)->first();
        $history = new Worked_History;
        $history->capcode = $reassign_capcode->id ?? 2100;
        $history->active_account_id = $account->ID;
        $history->agent_id = $user->user_id;
        $history->user_role = $user->role;
        $history->notes = "Account assigned from " . $original_agent . " to " . $new_agent . ". " . $request->reason . ".";
        $history->save();

        $response_array['status'] = 'success';
        return json_encode($response_array);
    }
}
