<?php

namespace App\Http\Controllers\AllAccount;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CreateController extends Controller
{
    public function showCreate()
    {
        return view('create');
    }
}
