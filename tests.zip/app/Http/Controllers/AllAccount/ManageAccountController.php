<?php

namespace App\Http\Controllers\AllAccount;

use Illuminate\Http\Request;
use Auth;
use DB;
use File;
use Storage;
use App\Models\Corporate_Api;
use App\User;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use App\Models\old_passwords;
use Carbon\Carbon;
use App\Traits\CheckPassword;

class ManageAccountController extends Controller
{
    
    use CheckPassword;
    public function showAccountSettings()
    { 
        return view('allAccount/accountSettings');  
    }

    public function getApiInfo(Request $request){
        
        $this->validate($request, [
            'apiPassword' => 'required|max:191'
        ]);

        if((Hash::check($request->apiPassword, Auth::user()->password))){
            $apiInfo = Corporate_Api::where('corporation_id', Auth::user()->corporation_corporate_admin_link->corporation_id)->first();
            
            if($apiInfo != null){
                $apiPassword = $apiInfo->UP;
                $apiUser = User::where('user_id', $apiInfo->user_id)->where('is_deactivated', 0)->first();
                $api[] = [$apiUser->email]; 
                $api[] = [$apiPassword];
            }
            else{
                $api[] = ['failed'];
                $api[] = [ 'Api not set'];
            }
        }
        else{
            $api[] = ['failed'];
            $api[] = ['Email or password incorrect'];
        }
        
        echo json_encode($api);
        return;
    }

    public function updateAccount(Request $request)
    {              
        $this->validate($request, [
            'first_name'=> 'required|max:90',
            'last_name'=> 'required|max:90',
            'email'=> 'required|max:90',
            'newPassword' => 'max:32',
            'avatar' => 'image'
        ]);

        if(!empty($request->avatar)){
            $fileName = $request->file('avatar')->getClientOriginalName();
            $file = $request->file('avatar');
            $fileExtension = $request->file('avatar')->getClientOriginalExtension();

            //Declare Storage, and save accordingly
            $file->storeAs('/'.Auth::user()->user_id,'avatar.png', ['disk' => 'profile_pictures']);
        }


        $user = Auth::user();
        $user->first_name = $request->input('first_name');
        $user->last_name = $request->input('last_name');
        $user->open_new_tab = $request->input('open_new_tab');
        if($request->input('newPassword') != ''){

            if(!$this->CheckPassword($request->input('newPassword')))
                return back()->with('error', 'Password does not meet requirments!');
            
            if($request->input('newPassword') != $request->input('c_password'))
                return back()->with('error', 'Passwords do not match!');


            $date = Carbon::now()->subDays(365)->format('Y-m-d');
            $passwordHistories = $user->passwordHistories()->where("created_at", '>', $date)->get();
            foreach($passwordHistories as $passwordHistory){
                //echo $passwordHistory->password;
                if (Hash::check($request->get('newPassword'), $passwordHistory->password)) {
                    // The passwords matches
                    return redirect()->back()->with("error","Your new password can not be same as any of your recent passwords. Please choose a new password.");
                }
            }
            
            $oldPassword = new old_passwords();
            $oldPassword->password = $user->password;
            $oldPassword->user_id = $user->user_id;
            $oldPassword->save(); 
            $user->password = bcrypt($request->input('newPassword'));
        }

        if($request->role != null){
            $role_list = explode(",", $user->role_list);
            if(in_array($request->role, $role_list))
                $user->role = $request->role;
            else
                return redirect()->back()->with('error', 'You do not have access to this account type');
        }

        if($user->background_color != $request->background_color)
            $user->background_color = $request->background_color;

        $user->save();
 
        return redirect()->back()->with('message', 'Account Updated');
    }

    public function checkEmail(Request $request)
    {
        $email = $request->email;

        $user = User::where('email', $email)->doesntExist();

        echo json_encode($user);
    }
}