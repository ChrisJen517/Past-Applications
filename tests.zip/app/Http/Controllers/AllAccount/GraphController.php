<?php

namespace App\Http\Controllers\AllAccount;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use DB;
use App\Models\Agent;
use App\Models\Team;
use Auth;

class GraphController extends Controller
{
    public function agentAtTime(Request $request){

        if($request->day == null){
            $time = date("Y-m-d");
            $message = "from today";
        }
        else{
            $time = date('Y-m-d', strtotime($request->day));
            $message = "from ".$time;
        }

        $data = $this->getAgentData($time);
        $array = array();

        $highestValue = 0;

        foreach($data as $item)
        {
            if($item['verified'] > $highestValue)
                $highestValue = $item['verified'];

            $array[] = array(
                $item['agent_name'],
                $item['verified'],
                $item['verified'],
                $item['daily_goal'],
                $item['daily_goal']
            );
        }

        

        return view('allAccount.reports.dailyBudgetPerformanceAgent')->with('array', $array)->with('highestValue', $highestValue)->with('timeMessage', $message);
    }

    

    public function getAgentData($time){
        
        $corporation_id = Auth::user()->corporation_corporate_admin_link->corporation_id;

        $data = DB::select( DB::raw("SELECT ACCT_AGENT, count(if( CAPCODE IN (SELECT id FROM capcodes WHERE type = 'verified'), 1, null)) as verified
         FROM bbconsul_ROCKY_REBUILD.inactive_accounts
          where CORPORATION_ID = $corporation_id
           AND DAY(UPDATED_AT) = DAY('$time')
            GROUP BY ACCT_AGENT;"));

        $agents = Agent::where("corporation_id", $corporation_id)->with('user_link')->where('created_at', '<', date('Y-m-d', strtotime($time.' + 1 day')))->get();
        $teams = Team::where("corporation_id", $corporation_id)->get();
        $agents = collect($agents);
        $teams = collect($teams);

        $verifieds = [];
        foreach($data as $item){
            $verifieds[$item->ACCT_AGENT] = $item->verified;
        }

        $finalData = [];
        foreach($agents as $agent){
            if(($agent->user_link->deactivate_date < $time) && ($agent->user_link->is_deactivated == 1))
                continue;

            if(array_key_exists( $agent->agent_id, $verifieds))
                $verified = $verifieds[$agent->agent_id];
            else
                $verified = 0;

            $finalData[] =[
                'agent_name' => $agent->user_link->first_name." ".$agent->user_link->last_name,
                'verified' => $verified,
                'daily_goal' => $teams->where('team_id', $agent->team_id)->first()->team_goals,
            ]; 
        }

        return $finalData;
    }
}
