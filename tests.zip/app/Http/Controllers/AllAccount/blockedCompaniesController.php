<?php

namespace App\Http\Controllers\AllAccount;

use App\Models\CorporateAdmin;
use App\Models\Agent;
use App\Models\Manager;
use App\Models\Blocked_Company;
use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Request;
use Auth;
use App\Models\Active_Account;
use App\Models\Capcode;
use App\Models\Inactive_Account;
use DB;
class blockedCompaniesController extends Controller
{
    //gets the blocked list
    public function tableOfBlockedComapnies(){
        $corporation_id = $this->getCorporationId();

        //prevents admin accounts from running into an issue
        if($corporation_id == 'fail')
            return redirect('/')->with('error', 'No corporation id');

        $blockedCompanies = Blocked_Company::where('corporation_id', $corporation_id)->with('user_link')->get();
        
        return view('allAccount.blockedTable')->with('blockedCompanies', $blockedCompanies)->with('corporation_id', $corporation_id);
    }

    public function addBlockedCompany(Request $request){

        $this->validate($request, [
            'company_name' => 'max:60',
            'fax_number' => 'max:45',
            'phone_number' => 'max:45',
            'extension' => 'max:45',
            'email' => 'max:90',
            'SSN' => 'max:45',

        ]);

        $blockedCompany = new Blocked_Company;
        if (Auth::user()->role == 'manager') {
            if($request->type == 'company_name')
                return back()->with('error', 'Only corporate admins may block a company by name');
                
            $corporation_id = Auth::User()->manager_link->corporation_id;
        } else if (Auth::user()->role == 'corporate_admin') {
            $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        }
        $blockedCompany->type = $request->type;
        $blockedCompany->corporation_id = $corporation_id;
        $blockedCompany->user_id = Auth::User()->user_id;

        if($request->type == 'company_name'){
            $this->validate($request, [
                'company_name' => 'required|unique:blocked_companies',
            ]);
            $blockedCompany->company_name = $request->company_name;
            $blockedCompany->phone_number = $request->phone_number;
            $blockedCompany->fax_number = $request->fax_number;
            $blockedCompany->email = strtolower($request->email);
            
            $namematch = $request->company_name;
            $namematch = str_ireplace(array('incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $namematch);
            $wordCount = str_word_count($namematch);
            if ($wordCount > 3) {
                $namematch = $this->trim_text($namematch, 2);
            }
            $namematch = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $namematch));
            $blockedCompany->namematch = $namematch;
            if (strlen($namematch) <= 7) {
                $active_matched =  Active_Account::where('NAME_MATCH', $namematch)->first();
            }else{
                $namematchlike = "%{$namematch}%";
                $active_matched = Active_Account::where('NAME_MATCH', 'LIKE', $namematchlike)->first();
            }
            $blockedCompany->save();
            if(empty($active_matched) == false){
                DB::select( DB::raw("Call move_to_inactive_blocked_company('".$namematch."',".$corporation_id.", 6005);"));
                return redirect('/blockedCompany')->with('success', 'Removed Accounts with Company '.$request->company_name.'.');
            }
            return redirect('/blockedCompany')->with('success', 'Added '.$request->company_name.' as a blocked Company.');            
        }elseif($request->type == 'email'){
            $this->validate($request, [
                'email' => 'required|unique:blocked_companies',
            ]);
            $blockedCompany->email = strtolower($request->email);
        }elseif($request->type == 'fax'){
            $this->validate($request, [
                'fax_number' => 'required|unique:blocked_companies',

            ]);
            $blockedCompany->fax_number = $request->fax_number; 
        }elseif($request->type == 'ssn'){
            $this->validate($request, [
                'SSN' => 'required|unique:blocked_companies',
            ]);
            $blockedCompany->SSN = $request->SSN;
            $blockedCompany->save();
            $active_accounts = Active_Account::where('ACCT_SSN', $request->SSN)->first();
            if(empty($active_accounts) == false){
                DB::select( DB::raw("Call move_to_inactive_blocked('".$request->SSN."',".$corporation_id.", 6006);"));
                return redirect('/blockedCompany')->with('success', 'Removed Accounts with SSN '.$request->SSN.'.');
            }
            return redirect('/blockedCompany')->with('success', 'Added '.$request->SSN.' as a blocked SSN.');
        }elseif($request->type == 'phone_number'){
            $this->validate($request, [
                'phone_number' => 'required|unique:blocked_companies',

            ]);
            $blockedCompany->phone_number = $request->phone_number;
            $blockedCompany->extension = $request->extension;
        }
        $blockedCompany->save();

        return redirect('/blockedCompany')->with('success', 'Company blocked');
    }

    public function editBlockedCompany(Request $request){
        
        $this->validate($request, [
            'fax_number' => 'max:45',
            'phone_number' => 'max:45',
            'extension' => 'max:45',
            'email' => 'max:90',
        ]);
        $blockedCompany = Blocked_Company::find($request->blocked_id);
        $blockedCompany->user_id = Auth::User()->user_id;
        if($blockedCompany->type == 'company_name'){
            $blockedCompany->company_name = $request->company_name;
            $blockedCompany->phone_number = $request->phone_number;
            $blockedCompany->fax_number = $request->fax_number;
            $blockedCompany->email = strtolower($request->email);
        }elseif($blockedCompany->type == 'email'){
            $blockedCompany->email = strtolower($request->email);
        }elseif($blockedCompany->type == 'fax'){
            $blockedCompany->fax_number = $request->fax_number;
        }elseif($blockedCompany->type == 'ssn'){
            $blockedCompany->SSN = $request->SSN;
        }elseif($blockedCompany->type == 'phone_number'){
            $blockedCompany->phone_number = $request->phone_number;
            $blockedCompany->extension = $request->extension;
        }
        
        return redirect('/blockedCompany')->with('success', 'Company blocked');
    }

    public function removeBlockedCompany($id){
        $blockedCompanies = Blocked_Company::where('blocked_company_id', $id)->where('corporation_id', $this->getCorporationId())->first();
        
        if($blockedCompanies == null)
            return redirect('/blockedCompany')->with('error', 'Company not found!');

        $blockedCompanies->delete();
        return redirect('/blockedCompany')->with('success', 'Company Removed');
    }

    //gets the corporation of the user or sends a fail in response to an admin
    public function getCorporationId(){
        $user = Auth::user();
        if($user->role == 'agent'){
            $corporation = Agent::where('user_id', Auth::user()->user_id)->first();
            return $corporation->corporation_id;
        }
        else if($user->role == 'manager'){
            $corporation = Manager::where('user_id', Auth::user()->user_id)->first();
            return $corporation->corporation_id;
        }
        else if($user->role == 'corporate_admin'){
            $corporation = CorporateAdmin::where('user_id', Auth::user()->user_id)->first();
            return $corporation->corporation_id;
        }
        else
            return 'fail';
    }

    public function trim_text($text, $count)
    {
        $text = str_replace("  ", " ", $text);
        $string = explode(" ", $text);
        $trimed = '';
        for ($wordCounter = 0; $wordCounter <= $count; $wordCounter++) {
            $trimed = $trimed . $string[$wordCounter];
            if ($wordCounter < $count) {$trimed = $trimed . " ";}
        }
        $trimed = trim($trimed);
        return $trimed;
    }
}