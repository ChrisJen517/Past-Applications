<?php

namespace App\Http\Controllers\DirectoryAgent;

use Illuminate\Http\Request;
use Auth;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Capcode;
use App\Http\Controllers\Controller;
use DateTime;
use Illuminate\Support\Facades\Cookie;

class todaysReminderController extends Controller
{
    public function allReminders(){
        $current = new DateTime('today');
        $tommorow = new DateTime('tomorrow');

        $today = Directory_Active_Account::where('directory_agent_id', Auth::user()->directory_agent_link->directory_agent_id)->where('work_reminder', '>', $current)->where('work_reminder', '<', $tommorow)->get();

        $future = Directory_Active_Account::where('directory_agent_id', Auth::user()->directory_agent_link->directory_agent_id)->where('work_reminder', '>', $tommorow)->get();

        $capcodes = Directory_Capcode::get();

        return view('directoryAgent.pages.todaysReminders')->with('today', $today)->with('future', $future)->with('capcodes', $capcodes);
    }
}