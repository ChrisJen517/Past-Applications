<?php

namespace App\Http\Controllers\DirectoryAgent;

use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Carbon\Carbon;
use Auth;
use DB;
use Illuminate\Http\Request;
use \stdClass;

class AccountController extends Controller
{
    public function showNewActiveAccounts()
    {
        //Grabs all new active account for this user.
        $directory_agent_id = Directory_Agent::where('user_id', Auth::user()->user_id)->select('directory_agent_id')->first()->directory_agent_id;
        $capcodes = Directory_Capcode::get();
        $newAccounts = Directory_Active_Account::where('directory_agent_id', $directory_agent_id)->where(function ($q) {$q->where('LAST_WORKED', "")->orwhere('LAST_WORKED', null);})->orderby('created_at')->orderby('last_worked')->get();
        return view('directoryAgent.pages.activeAccounts')->with('newAccounts', $newAccounts)->with('capcodes', $capcodes)->with('type', "New Active Accounts");
    }

    public function showWorkedActiveAccounts()
    {
        //Grabs all worked active account for this user.
        $directory_agent_id = Directory_Agent::where('user_id', Auth::user()->user_id)->select('directory_agent_id')->first()->directory_agent_id;
        $workedAccounts = Directory_Active_Account::where('directory_agent_id', $directory_agent_id)->where('LAST_WORKED', '!=', null)
            ->where('LAST_WORKED', '!=', '')
            ->where(function ($q) {$q->where('work_reminder','<', now())->orwhere('work_reminder', null);})
            ->orderby('created_at')->orderby('last_worked')->get();
        $capcodes = Directory_Capcode::get();

        //breaks the data into the two seperate types for the two tables
        $today = date('Y-m-d');
        $currentAccounts = $workedAccounts->where('last_worked', '<', $today);
        $workedAccounts = $workedAccounts->where('last_worked', '>', $today);

        return view('directoryAgent.pages.workedAccounts')->with('currentAccounts', $currentAccounts)->with('workedAccounts', $workedAccounts)
        ->with('capcodes', $capcodes)->with('type', "Worked Active Accounts");
    }

    public function showAllActiveAccounts()
    {
        //Grabs all active account for this user.
        $directory_agent_id = Directory_Agent::where('user_id', Auth::user()->user_id)->select('directory_agent_id')->first()->directory_agent_id;
        $allAccounts = Directory_Active_Account::where('directory_agent_id', $directory_agent_id)
        ->where(function ($q) {$q->where('work_reminder','<', now())->orwhere('work_reminder', null);})
        ->orderby('created_at')->orderby('last_worked')->get();
        $capcodes = Directory_Capcode::get();
        return view('directoryAgent.pages.activeAccounts')->with('newAccounts', $allAccounts)->with('capcodes', $capcodes)->with('type', "All Active Accounts");
    }

    public function showClosed(Request $request)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);
        $useTime = true;
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
            $useTime = false;
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }
        if ($request->to == null) {
            $endTime = date("Y-m-d", strtotime("+1 day"));
            $useTime = false;
        } else {
            $endTime = date('Y-m-d', strtotime($request->to." +1 day"));
        }
            //    return [$endTime, $startTime];
        $directory_agent_id = Directory_Agent::where('user_id', Auth::user()->user_id)->select('directory_agent_id')->first()->directory_agent_id;
        $verifiedCapcodes = Directory_Capcode::where('type', 'verified')->get();
        $unverifiedCapcodes = Directory_Capcode::where('type', 'unverified')->get();
        $inconclusiveCapcodes = Directory_Capcode::where('type', 'inconclusive')->get();

        $verifiedCodes = [];
        foreach ($verifiedCapcodes as $capcode) {
            $verifiedCodes[] = $capcode->capcode_id;
        }
        $unverifiedCodes = [];
        foreach ($unverifiedCapcodes as $capcode) {
            $unverifiedCodes[] = $capcode->capcode_id;
        }
        $inconclusiveCodes = [];
        foreach ($inconclusiveCapcodes as $capcode) {
            $inconclusiveCodes[] = $capcode->capcode_id;
        }

        $verifiedClosed = Directory_Inactive_Account::where('directory_agent_id', $directory_agent_id)
            ->whereRaw('capcode in(select capcode_id from directory_capcodes where type = "verified")')
            ->where("last_worked", ">", $startTime)->where("last_worked", "<", $endTime)
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();
        $unverifiedClosed = Directory_Inactive_Account::where('directory_agent_id', $directory_agent_id)
            ->whereRaw('capcode in(select capcode_id from directory_capcodes where type = "unverified")')
            ->where("last_worked", ">", $startTime)->where("last_worked", "<", $endTime)
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();
        $inconclusiveClosed = Directory_Inactive_Account::where('directory_agent_id', $directory_agent_id)
            ->whereRaw('capcode in(select capcode_id from directory_capcodes where type = "inconclusive")')
            ->where("last_worked", ">", $startTime)->where("last_worked", "<", $endTime)
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();

        $verifiedCount = count($verifiedClosed);
        $unverifiedCount = count($unverifiedClosed);
        $inconclusiveCount = count($inconclusiveClosed);

        $endTime = Carbon::parse($endTime)->subDay(1)->format('m/d/Y');
        $startTime = Carbon::parse($startTime)->format('m/d/Y');

        return view('directoryAgent.pages.inactiveAccounts')->with('verifiedClosed', $verifiedClosed)->with('verifiedCapcodes', $verifiedCapcodes)
        ->with('unverifiedClosed', $unverifiedClosed)->with('unverifiedCapcodes', $unverifiedCapcodes)
        ->with('inconclusiveClosed', $inconclusiveClosed)->with('inconclusiveCapcodes', $inconclusiveCapcodes)
        ->with('verifiedMessage', "Showing latest ".$verifiedCount." accounts")
        ->with('unverifiedMessage', "Showing latest ".$unverifiedCount." accounts")
        ->with('inconclusiveMessage', "Showing latest ".$inconclusiveCount." accounts")
        ->with('startTime', $startTime)
        ->with('endTime', $endTime);
    }

    public function searchAccounts(Request $request)
    {
        if($request->type == 'directory'){
            if($request->directory_agent_id != null) {
                $capcode = Directory_Capcode::get();
                $activeAccounts = Directory_Active_Account::where('directory_agent_id', $request->directory_agent_id)
                ->where(function ($q) use ($request) {
                    if ($request->name != null) {
                        $q->where(function ($q) use ($request) {
                            $q->where('aka', 'like', '%' . $request->name . '%');
                            $q->orwhere('employer_name', 'like', '%' . $request->name . '%');
                        });
                    }
                    if ($request->phone != null) {
                        $q->where(function ($q) use ($request) {
                            $q->where('direct_phone','like', '%'.$request->phone.'%')
                            ->orWhere('empl_org_phone','like', '%'.$request->phone.'%')
                            ->orWhere('verification_phone','like', '%'.$request->phone.'%');
                        });
                    }
                    if($request->directory_account_id != null) {
                        $q->where('directory_account_id', $request->directory_account_id);
                    }
                })
                ->get();
                return view('directoryAgent.pages.searchResults')->with('activeAccounts', $activeAccounts)->with('inactiveAccounts', [])->with('capcode', $capcode);
            }

            $activeAccounts = Directory_Active_Account::where(function ($q) use ($request) {
                if ($request->name != null) {
                    $q->where(function ($q) use ($request) {
                        $q->where('aka', 'like', '%' . $request->name . '%');
                        $q->orwhere('employer_name', 'like', '%' . $request->name . '%');
                    });
                }
                if ($request->phone != null) {
                    $q->where(function ($q) use ($request) {
                        $q->where('direct_phone','like', '%'.$request->phone.'%')
                        ->orWhere('empl_org_phone','like', '%'.$request->phone.'%')
                        ->orWhere('verification_phone','like', '%'.$request->phone.'%');
                    });
                }
                if($request->directory_account_id != null) {
                    $q->where('directory_account_id', $request->directory_account_id);
                }
            })->orderBy('last_worked', 'DESC')->paginate(100);

            $inactiveAccounts = Directory_Inactive_Account::where(function ($q) use ($request) {
                if ($request->name != null) {
                    $q->where('aka', 'like', '%' . $request->name . '%');
                    $q->orwhere('employer_name', 'like', '%' . $request->name . '%');
                }
                if ($request->phone != null) {
                    $q->where(function ($q) use ($request) {
                        $q->where('direct_phone','like', '%'.$request->phone.'%')
                        ->orWhere('empl_org_phone','like', '%'.$request->phone.'%')
                        ->orWhere('verification_phone','like', '%'.$request->phone.'%');
                    });
                }
                if($request->directory_account_id != null) {
                    $q->where('directory_account_id', $request->directory_account_id);
                }
                if($request->directory_agent_id != null) {
                    $q->where('directory_agent_id', $request->directory_agent_id);
                }
            })->orderBy('last_worked', 'DESC')->paginate(100);

            $capcode = Directory_Capcode::get();

            return view('directoryAgent.pages.searchResults')->with('activeAccounts', $activeAccounts)->with('inactiveAccounts', $inactiveAccounts)->with('capcode', $capcode);
        }
        elseif($request->type == 'rocky'){

            $activeAccounts = Active_Account::select('ID','ACCT_DUE_DATE', 'LAST_WORKED', 'ACCT_CASE', 'CLIENT_NAME', 'EMPL_NAME', 'ACCT_ID', 'CLIENT_PHONE')->where(function($q) use ($request) {
                if($request->employer_name != null)
                    $q->where('EMPL_NAME', 'like','%'.$request->employer_name.'%');
                if($request->account_id != null)
                    $q->where('ACCT_ID', $request->account_id);
                if($request->unique_id != null)
                    $q->where('ID', $request->unique_id);
                if($request->case_num != null)
                    $q->where('ACCT_CASE', $request->case_num);
                if($request->client_name != null)
                    $q->where('CLIENT_NAME', 'like','%'.$request->client_name.'%');
            })->paginate(500);

            //gets inactive accounts
            if($request->agent_que == null){
                $inactiveAccounts = Inactive_Account::select('ID','ACCT_DUE_DATE', 'LAST_WORKED', 'ACCT_CASE', 'CLIENT_NAME', 'EMPL_NAME', 'ACCT_ID', 'CLIENT_PHONE')->where(function($q) use ($request) {
                    if($request->employer_name != null)
                        $q->where('EMPL_NAME', 'like','%'.$request->employer_name.'%');
                    if($request->account_id != null)
                        $q->where('ACCT_ID', $request->account_id);
                    if($request->unique_id != null)
                        $q->where('ID', $request->unique_id);
                    if($request->case_num != null)
                        $q->where('ACCT_CASE', $request->case_num);
                    if($request->client_name != null)
                        $q->where('CLIENT_NAME', 'like','%'.$request->client_name.'%');
                })->paginate(500);
            }
            else
                $inactiveAccounts = null;
            return view('directoryAgent.pages.searchResultsRocky')->with('activeAccounts', $activeAccounts)->with('inactiveAccounts', $inactiveAccounts);


        }
    }

    public function addDirectory(Request $request)
    {
        $this->validate($request, [
            'employer_name' => 'required',
        ]);

        //Check if Directory active account exists already
        $data = $this->checkNameMatch($request->employer_name);
        $directory = $data->directory;
        $status = $data->status;
        $accountType = $data->accountType;

        if (Active_Account::where('NAME_MATCH', $directory->name_match)->exists()) {
            $account = Active_Account::where('NAME_MATCH')->first();
            $account->DIRECTORY_LINK = $directory->directory_account_id;
            $account->save();
        }

        //Redirects to new or already created directory account
        if (Auth::user()->role == 'directory_agent') {
            $directory->directory_agent_id = Auth::user()->directory_agent_link->directory_agent_id;
            $directory->save();
            return redirect('/directory_agent/WorkAccount/' . $directory->directory_account_id . '?type=' . $accountType)->with('message', ($status == 'found' ? 'Directory name matched, displaying that entry.' : 'New directory created.'));
        } else
            return redirect('/admin/directory/WorkAccount/' . $directory->directory_account_id . '?type=' . $accountType)->with('message', ($status == 'found' ? 'Directory name matched, displaying that entry.' : 'New directory created.'));
    }

    public function checkNameMatch($name)
    {

        $empmatchname = $name;
        $empmatchname = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $empmatchname);
        $empmatchname = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));
        $empnamelike = "%{$empmatchname}%";

        $data = new \stdClass;
        $data->directory = null;
        $data->status = 'found';

        if (strlen($empmatchname) <= 7) {
            if(Directory_Inactive_Account::where('name_match', $empmatchname)->exists()){
                $directory = Directory_Inactive_Account::where('name_match', $empmatchname)->first();
                $data->directory = $directory;
                $data->accountType = 'inactive';
                return $data;
            }
            else if (Directory_Active_Account::where('name_match', $empmatchname)->exists()) {
                $directory = Directory_Active_Account::where('name_match', $empmatchname)->first();
                $data->directory = $directory;
                $data->accountType = 'active';
                return $data;
            }
        }else{
            if(Directory_Inactive_Account::where('name_match', 'LIKE', $empnamelike)->orWhere('aka_name_match', 'LIKE', $empnamelike)->exists()){

                $directory = Directory_Inactive_Account::where('name_match', 'LIKE', $empnamelike)
                ->orWhere('aka_name_match', 'LIKE', $empnamelike)->first();
                $data->directory = $directory;
                $data->accountType = 'inactive';
                return $data;
            }
            else if (Directory_Active_Account::where('name_match', 'LIKE', $empnamelike)->orWhere('aka_name_match', 'LIKE', $empnamelike)->exists()) {
                $directory = Directory_Active_Account::where('name_match', 'LIKE', $empnamelike)->orWhere('aka_name_match', 'LIKE', $empnamelike)->first();
                $data->directory = $directory;
                $data->accountType = 'active';
                return $data;
            }
        }

        $directory = new Directory_Active_Account();
        $directory->employer_name = $name;
        $directory->name_match = $empmatchname;
        $directory->fresh_flag = 1;
        $directory->live_flag = 0;
        $directory->save();

        $data->directory = $directory;
        $data->accountType = '';
        $data->status = 'created';
        return $data;
    }

    public function trim_text($text, $count)
    {
        $text = str_replace("  ", " ", $text);
        $string = explode(" ", $text);
        $trimed = '';
        for ($wordCounter = 0; $wordCounter <= $count; $wordCounter++) {
            $trimed = $trimed . $string[$wordCounter];
            if ($wordCounter < $count) {$trimed = $trimed . " ";}
        }
        $trimed = trim($trimed);
        return $trimed;
    }
}
