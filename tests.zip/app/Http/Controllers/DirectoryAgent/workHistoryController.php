<?php

namespace App\Http\Controllers\DirectoryAgent;

use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Setting;
use App\Models\Directory_Work_History;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Powerlead_Directory_Manager;
use App\Traits\Autobot;
use Auth;
use Illuminate\Support\Facades\Log;
use Schema;
use Symfony\Component\HttpFoundation\Request;

class workHistoryController extends Controller
{
    use Autobot;

    public function workForm(Request $request, $account_id = null, $message = null){
        if($account_id == null)
            $account_id = $request->accountId;

        return $this->getWorkForm($account_id, $request->type);
    }

    public function getWorkForm($account_id, $type){
        $account = Directory_Active_Account::where('directory_account_id', $account_id)->first();
        if ($account == null)
            $account = Directory_Inactive_Account::where('directory_account_id', $account_id)->first();

        $capcodes = Directory_Capcode::orderBy("capcode", "asc")->where('is_archived', '0')->get();
        $callCode = $capcodes->where('capcode', 2225)->first()->capcode_id ?? 2225;
        $capcodes = $capcodes->whereNotIn('capcode', [2225]);

        if($account->live_flag == 1)
            $max = Directory_Setting::first()->live_max_attempts;
        else
            $max = Directory_Setting::first()->max_attempts;

        $history = Directory_Work_History::where('directory_account_id', $account_id)
            ->with('directory_capcode_link')
            ->with('user_directory_agent_link')
            ->orderByDesc("updated_at", "desc")
            ->get();
        if(Auth::user()->role == 'directory_agent')
            $history = $history->where('capcode', '!=', $callCode);

        $attempts = Directory_Work_History::where('directory_account_id', $account_id)
            ->where('worker_role', 'directory_agent')
            ->where('capcode', '!=', $callCode)
            ->select("directory_agent_id")
            ->count();

        $agents = Directory_Agent::select('directory_agent_id', 'user_id')->with('user_link')->get();

        return view('directoryAgent/pages/workForm')->with('account', $account)->with('capcodes', $capcodes)->with('history', $history)
            ->with('max', $max)->with("attempts", $attempts)->with('agents', $agents)->with('type', $type);
    }

    public function updateDirectoryAccount(Request $request){
        $capcode = Directory_Capcode::select('capcode_id', 'capcode', 'type', 'profile_type')->where('capcode_id', $request->capcode)->first();
        $account = Directory_Active_Account::where('directory_account_id', $request->directory_account_id)->first();
        $accountType = 'active';
        if ($account == null) {
            $account = Directory_Inactive_Account::where('directory_account_id', $request->directory_account_id)->first();
            $accountType = 'closed';
        }

        if($accountType == 'closed' && $capcode->type == 'inconclusive' && Auth::user()->role == 'directory_agent')
            return redirect('/directory_agent/newActiveAccounts')->with('error', 'That account was already closed, sent back to avoid overwritting data.');

        //return $request;
        $aka_name_match = $this->setUpAka($request->company_aliases);
        if (Directory_Active_Account::where('aka_name_match', $aka_name_match)->exists() || Directory_Inactive_Account::where('aka_name_match', $aka_name_match)->exists() || $aka_name_match == "")
            $aka_name_match = null;

        $history = new Directory_Work_History;
        $history->directory_account_id = $request->directory_account_id;
        $history->worker_role = Auth::user()->role;
        $history->worker_id = Auth::user()->getRoleId();
        $history->capcode = $request->capcode;
        $history->scheduled_call = $request->time;
        $history->verification_notes = $request->verification_notes;
        $history->work_notes = $request->work_notes;
        $history->save();

        $user = Auth::user();
        $oldCapcode = Directory_Capcode::select('capcode')->where('capcode_id', $account->capcode)->first();
        if (empty($oldCapcode))
            Log::debug('User ID: ' . $user->user_id . ' (' . $user->first_name . ' ' . $user->last_name . ') has saved directory account '. $request->directory_account_id .' on the form, changing capcode from unworked to ' . $capcode->capcode);
        else
            Log::debug('User ID: ' . $user->user_id . ' (' . $user->first_name . ' ' . $user->last_name . ') has saved directory account '. $request->directory_account_id .' on the form, changing capcode from ' . $oldCapcode->capcode . ' to ' . $capcode->capcode);

        //takes the broken aliases and combineds them into a single string
        $request->aka = implode('|', $request->company_aliases);
        //breaks apart adress fields not a single string
        $request->address = implode('|', $request->address);
        $request->city = implode('|', $request->city);
        $request->state = implode('|', $request->state);
        $request->zip = implode('|', $request->zip);

        //updates all fields in the directory account
        $active_accounts_mapping_columns = Schema::getColumnListing('directory_active_accounts');
        for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
            $item = strval($active_accounts_mapping_columns[$i]);
            if(!in_array($item, ['created_at', 'updated_at', 'work_reminder', 'directory_agent_id', 'employer_name', 'live_flag', 'due_date', 'time_zone', 'phone_verified', 'fresh_flag', 'agent_id'])){
                $account->$item = $request->$item ?? null;
            }
        }

        //fields with unique varriables to fill out
        $account->aka_name_match = $aka_name_match;
        $account->last_worked = $history->created_at;
        if($request->time != null)
            $account->work_reminder = $request->time;
        $account->save();

        //checks if the account needs to be closed
        if ($this->checkForClose($request->directory_account_id, $capcode, $accountType)) {
            $this->closeAccount($request->directory_account_id);
            $message = "Successfully closed the account!";

            if($account->live_flag == 1)
                $this->moveLiveAccounts($request->directory_account_id, $capcode);
        }
        else
            $message = "Successfully saved the account!";

        if ($request->submit != 'Save') {
            $agent = Directory_Agent::where('user_id', Auth::user()->user_id)->select('directory_agent_id')->first();

            if(Directory_Active_Account::where('directory_account_id', '!=', $request->directory_account_id)->where('directory_agent_id', $agent->directory_agent_id)->whereNotNull('work_reminder')->whereRaw('DATE(work_reminder) <= CURDATE()')->where('time_zone', $account->time_zone)->exists()){
                $account = Directory_Active_Account::where('directory_account_id', '!=', $request->directory_account_id)->where('directory_agent_id', $agent->directory_agent_id)->whereNotNull('work_reminder')->whereRaw('DATE(work_reminder) <= CURDATE()')->orderBy('work_reminder', 'ASC')->where('time_zone', $account->time_zone)->first();
                $account->work_reminder = null;
                $account->save();
            }else{
                $account = Directory_Active_Account::select('directory_account_id')
                ->where('directory_account_id', '!=', $request->directory_account_id)
                ->where('directory_agent_id', $agent->directory_agent_id)->where('time_zone', $account->time_zone)
                ->where(function ($q) use ($request) {
                    if($request->type == null)
                        $q->where('last_worked', null)->orWhere('last_worked', '');
                    else
                        $q->where('last_worked', '!=', null)->where('last_worked', '!=', '')->whereRaw('last_worked < CURDATE()');
                })
                ->where(function ($q) {
                    $q->whereRaw('DATE(work_reminder) <= CURDATE()')
                    ->orwhere('work_reminder', null);
                })
                ->orderby('created_at')->orderby('last_worked')->first();
            }

            if(empty($account))
                return redirect('/directory_agent/newActiveAccounts')->with('error', 'No more accounts of selected timezone in the queue');

            $message = $message." Moved to next account in the queue.";
        }

        if (Auth::user()->role == 'directory_agent')
            return redirect('/directory_agent/WorkAccount/' . $account->directory_account_id . '?type=' . $request->type)->with('success', $message);
        else
            return redirect('/admin/directory/WorkAccount/'. $account->directory_account_id . '?type=' . $request->type)->with('success', $message);
    }

    public function checkForClose($accountId, $capcode, $accountType){
        //if the account is already closed, just return false
        if($accountType == "closed")
            return false;
        elseif(in_array($capcode->type, ['verified', 'unverified']))
            return true;

        //what is needed to check for max attempts
        $callCode = Directory_Capcode::where('capcode', 2225)->first()->capcode_id ?? 2225;
        $attempts = Directory_Work_History::where('directory_account_id', $accountId)
            ->where('worker_role', 'directory_agent')
            ->select("directory_agent_id")
            ->where('capcode', '!=', $callCode)
            ->count();

        if(Directory_Active_Account::where('directory_account_id', $accountId)->where('live_flag', 1)->exists())
            $max = Directory_Setting::first()->live_max_attempts;
        else
            $max = Directory_Setting::first()->max_attempts;

        if(($attempts > $max) && (!in_array(Auth::user()->role, ['admin', 'powerlead_directory_manager']))){
            //if the account hits max attempts, update the capcode to the overworked capcode
            $account = Directory_Active_Account::where('directory_account_id', $accountId)->first();
            $account->capcode = Directory_Capcode::where('capcode', 2224)->first()->capcode_id;
            $account->save();
            return true;
        }

        //if it does not meet any condtions, returns false
        return false;
    }

    //closes the account after its finished
    public function closeAccount($accountId){
        $active = Directory_Active_Account::where('directory_account_id', $accountId)->first();
        $closed = new Directory_Inactive_Account;

        $active_accounts_mapping_columns = Schema::getColumnListing('directory_active_accounts');
        for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
            $item = strval($active_accounts_mapping_columns[$i]);
            if (!in_array($item, ['created_at', 'updated_at', 'live_flag', 'due_date'])) 
                $closed->$item = $active->$item;
        }

        $closed->save();
        $active->delete();
    }

    //moves the accounts based
    public function moveLiveAccounts($accountId, $capcode){
        $directory_account = Directory_Inactive_Account::where('directory_account_id', $accountId)->first();
        $coe_account = Active_Account::where('DIRECTORY_LINK', $accountId)->first();
        if (empty($coe_account))
            return;

        $date = date("Y-m-d H:i:s");

        //moves to coe, unverified or phone verified
        if(in_array($capcode->type, ["unverified", 'inconclusive']) || $capcode->profile_type == 'phone_other_profile'){
            $coe_account->ON_HOLD = 0;
            $coe_account->save();
        }
        //moves to IVR
        elseif($capcode->profile_type == 'ivr_profile'){
            $coe_account->ON_HOLD = 0;

            //adds IVR to access rules
            $accessRules = $coe_account->ACCESS_RULES ?? '';
            $accessRules = explode(',', $accessRules);
            $accessRules[] = 'IVR';
            $coe_account->ACCESS_RULES = implode(',', $accessRules);
        }
        //moves to Bottie or Dottie
        else{
            $coe_account->TEAM_ID = 10;
            $coe_account->TEAM_NAME = "BOT";
            if($capcode->profile_type == 'fax_profile') {
                if (!empty($directory_account->verification_fax))
                    $this->sendBottyAutoFax($directory_account->verification_fax, $directory_account->employer_name, $coe_account, 0, $date, 1901, 'live_directory');
            } else {
                if (!empty($directory_account->verification_email))
                    $this->sendDottyAutoEmail($directory_account->verification_email, $directory_account->employer_name, $coe_account, 0, $date, 1902, 0, 'live_directory');
            }
        }
        $coe_account->save();
    }

    public function setUpAka($akas){
        $aka_name_match = "";

        foreach ($akas as $aka) {
            $aka = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $aka);
            $wordCount = str_word_count($aka);
            if ($wordCount > 3) {
                $aka = $this->trim_text($aka, 2);
            }
            $aka = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $aka));
            $aka_name_match = $aka_name_match . $aka . ",";
        }

        $aka_name_match = substr_replace($aka_name_match, "", -1);

        return $aka_name_match;
    }

    public function trim_text($text, $count){

        $text = str_replace("  ", " ", $text);
        $string = explode(" ", $text);
        $trimed = '';
        for ($wordCounter = 0; $wordCounter <= $count; $wordCounter++) {
            $trimed = $trimed . $string[$wordCounter];
            if ($wordCounter < $count)
                $trimed = $trimed . " ";
        }
        $trimed = trim($trimed);
        return $trimed;
    }

    //a caller for all auto buttons/ctrl+shift+c to add to the history
    public function autoCall(Request $request){
        $callcode = Directory_Capcode::where('capcode', 2225)->first()->capcode_id;

        $history = new Directory_Work_History;
        $history->directory_account_id = $request->directory_account_id;
        $history->worker_role = Auth::user()->role;
        $history->worker_id = Auth::user()->getRoleId();
        $history->capcode = $callcode;
        $history->verification_notes = "Made a call to: ".$request->phoneNumber;
        $history->save();

        $user = Auth::user();
        Log::debug('User ID: ' . $user->user_id . ' (' . $user->first_name . ' ' . $user->last_name . ') has made an auto-call for directory account '. $request->directory_account_id);
        return;
    }

    public function deleteDirectoryAccount(Request $request){
        //return $request->type;
        if ($request->type == 'inactive') 
            Directory_Inactive_Account::where('directory_account_id', $request->accountId)->delete();
        else if ($request->type == 'active')
            Directory_Active_Account::where('directory_account_id', $request->accountId)->delete();
        return "complete";
    }
}