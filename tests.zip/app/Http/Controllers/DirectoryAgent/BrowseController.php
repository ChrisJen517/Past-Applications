<?php

namespace App\Http\Controllers\DirectoryAgent;

use App\Models\Directory_Active_Account;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Http\Controllers\Controller;
use DataTables;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use DB;

class BrowseController extends Controller
{
    public function browseAccounts()
    {
        return view('admin.pages.directory.browseDirectory');
    }

    public function browseAgentAccounts()
    {
        return view('directoryAgent.pages.browseDirectory');
    }

    public function getDirectoryTable(Request $request)
    {
        $columns = array(
            0 => 'directory_account_id',
            1 => 'employer_name',
            2 => 'direct_phone',
            3 => 'last_worked',
            4 => 'aka',
            5 => 'capcode',
        );
        $totalDirectoryActive = Directory_Active_Account::count();
        $totalDirectoryInactive = Directory_Inactive_Account::count();
        $totalData = $totalDirectoryActive + $totalDirectoryInactive;

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        if (empty($request->input('search.value'))) {
            $allAccounts = DB::select("SELECT `directory_account_id`, 
            `employer_name`,
            'active' AS type,
            `direct_phone`, 
            `empl_org_phone`,
            `last_worked`, 
            `aka`,
            `capcode` as capcodeid
             , (SELECT capcode  from directory_capcodes where capcode_id = capcodeid) as capcode from `directory_active_accounts`
             union
             select `directory_account_id`, 
             `employer_name`,  
             'inactive' AS type,
             `direct_phone`, 
             `empl_org_phone`,
             `last_worked`, 
             `aka`,
            `capcode` as capcodeid
            , (SELECT capcode  from directory_capcodes where capcodeid = capcode_id) as capcode from `directory_inactive_accounts`
            order by ".$order." ".$dir." 
            limit ".$limit." 
            offset ".$start." 
            ");
            $totalFiltered = $totalData;
        } else {
            $search = $request->input('search.value');

            $allAccounts = DB::select("SELECT `directory_account_id`, 
            `employer_name`, 
            'active' AS type,
            `direct_phone`, 
            `last_worked`, 
            `empl_org_phone`,
            `aka`,
            `capcode` as capcodeid, 
            (SELECT capcode  from directory_capcodes where capcode_id = capcodeid) as capcode 
            from `directory_active_accounts`
            where directory_account_id = ".$search."
            or employer_name LIKE '%".$search."%'
            or direct_phone LIKE '%".$search."%'
            or empl_org_phone LIKE '%".$search."%'
            or last_worked LIKE '%".$search."%'
            or aka LIKE '%".$search."%'
            or capcode LIKE '%".$search."%'
            union 
            select `directory_account_id`, 
            `employer_name`, 
            'inactive' AS type,
            `direct_phone`,
            `empl_org_phone`, 
            `last_worked`, 
            `aka`,
            `capcode` as capcodeid
            , (SELECT capcode  from directory_capcodes where capcodeid = capcode_id) as capcode 
            from `directory_inactive_accounts`
            where directory_account_id = ".$search."
            or employer_name LIKE '%".$search."%'
            or direct_phone LIKE '%".$search."%'
            or empl_org_phone LIKE '%".$search."%'
            or last_worked LIKE '%".$search."%'
            or aka LIKE '%".$search."%'
            or capcode LIKE '%".$search."%'
            order by ".$order." ".$dir." 
            limit ".$limit." 
            offset ".$start." 
            ");

            $totalFiltered = $totalData;
        }

        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data"            => $allAccounts
        );

        echo json_encode($json_data);
        /*
        ini_set('memory_limit', '1024M');

        $active_directories = Directory_Active_Account::select('directory_account_id', 'employer_name', 'direct_phone', 'last_worked', 'aka', 'capcode')->get();
        $inactive_directories = Directory_Inactive_Account::select('directory_account_id', 'employer_name', 'direct_phone', 'last_worked', 'aka', 'capcode')->get();
        $capcodes = Directory_Capcode::select('capcode_id', 'capcode')->get();
        $role = Auth::user()->role;
        $count = 0;
        $collection = collect();
        foreach ($active_directories as $active) {
            if($active->capcode != null){
                $capcodeID = $capcodes->where('capcode_id', $active->capcode)->first();
                if($capcodeID == null)
                    $capcode = $active->capcode;
                else
                    $capcode = $capcodeID->capcode;
            }
            else
                $capcode = null;

            if ($count == 0) {

                $collection = collect(
                    [
                        ['role' => $role ,'directory_account_id' => $active->directory_account_id, 'type' => 'active', 'employer_name' => $active->employer_name, 'direct_phone' => $active->direct_phone, 'last_worked' => $active->last_worked, 'aka' => $active->aka, 'capcode' => $capcode],
                    ]
                );
            } else {

                $collection->push(
                    ['role' => $role , 'directory_account_id' => $active->directory_account_id, 'type' => 'active', 'employer_name' => $active->employer_name, 'direct_phone' => $active->direct_phone, 'last_worked' => $active->last_worked, 'aka' => $active->aka, 'capcode' => $capcode],
                );
            }

            $count++;
        }
        foreach ($inactive_directories as $inactive) {
            $capcodeID = $capcodes->where('capcode_id', $inactive->capcode)->first();
            if($capcodeID == null)
                $capcode = $inactive->capcode;
            else
                $capcode = $capcodeID->capcode;

            if ($count == 0) {

                $collection = collect(
                    [
                        ['role' => $role , 'directory_account_id' => $inactive->directory_account_id, 'type' => 'inactive', 'employer_name' => $inactive->employer_name, 'direct_phone' => $inactive->direct_phone, 'last_worked' => $inactive->last_worked, 'aka' => $inactive->aka, 'capcode' => $capcode],
                    ]
                );
            } else {

                $collection->push(
                    ['role' => $role , 'directory_account_id' => $inactive->directory_account_id, 'type' => 'inactive', 'employer_name' => $inactive->employer_name, 'direct_phone' => $inactive->direct_phone, 'last_worked' => $inactive->last_worked, 'aka' => $inactive->aka, 'capcode' => $capcode],
                );
            }

            $count++;
        }

        return DataTables::of($collection)->make(true);
        */
    }
}
