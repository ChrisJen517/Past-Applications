<?php

namespace App\Http\Controllers\Agent;

use App\Models\Active_Account;
use App\Models\Active_Account_Files;
use App\Models\Agent;
use App\Models\AWG7_Phone_Numbers;
use App\Models\Blocked_Company;
use App\Models\Capcode;
use App\Models\Corporate_Settings;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Work_History;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Powerlead_Accounts;
use App\RNNMailer;
use App\Models\Team;
use App\Traits\HasAccess;
use App\Models\Verification_Requirements;
use App\Models\Verified_Hit;
use App\Models\web_crawler;
use App\Models\Worked_History;
use Auth;
use Carbon\Carbon;
use Config;
use DB;
use Illuminate\Http\Request;
use Schema;
use App\Traits\SetFaxEmail;
use App\Traits\GetOrderArray;

class RockyController extends Controller
{
    use GetOrderArray, HasAccess, SetFaxEmail;

    public function showRockyAccountUpdate(Request $request){
        return $this->getRockyForm($request->accountId, $request->type, $request->timeZoneQueue);
    }

    public function getRockyForm($accountId, $type, $timeZoneQueue){
        $userRole = Auth::user()->role;
        //assures the user can access the account
        if ($this->checkAccess($accountId) == false && $userRole != 'directory_agent')
            return back()->with('error', "Access Denied");
        
        //gets the account
        $account = $this->findAccount($accountId);
        if ($type != 'worked' || $account['type'] == 'inactive')
            $type = $account['type'];
        $account = $account['account'];

        //assures the account exists
        if ($account == null)
            return back()->with('error', 'Account not found!');

        //assures the user should have access to this account
        if (!$this->checkMatchingCorporation($account->CORPORATION_ID))
            return back()->with('error', 'That account is not in your corporation');

        //gets if agents should show the client info
        $show = 1;
        if ($userRole == 'agent')
            $show = Corporate_Settings::where('corporation_id', $account->CORPORATION_ID)->select('show_client')->first()->show_client ?? 0;
        
        $requirments = Verification_Requirements::where('corporation_id', $account->CORPORATION_ID)->first();

        //if an agent works an account for the first time
        $allAccountIds = $this->getAllAccessIds($account->ACCT_SSN, $account->CORPORATION_ID, $type);
        if (in_array($type, ['active','worked']) && $userRole == 'agent') {
            if ($account->ACCT_AGENT == Auth::user()->agent_link->agent_id) {
                foreach ($allAccountIds as $rule) {
                    $allIds[] = "'" . $rule . "'";
                }
                $allIds = implode(',', $allIds);

                if ($account->VERIFIED_HITS_ID)
                    DB::select(DB::raw('UPDATE `active_accounts` SET `VERIFIED_HITS_ID` = ' . $account->VERIFIED_HITS_ID . ', `ACCT_AGENT` = ' . Auth::user()->agent_link->agent_id . ', `TEAM_ID` = ' . Auth::user()->agent_link->team_id . ' WHERE LAST_WORKED is NULL and ID IN (' . $allIds . ');'));
                else
                    DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = ' . Auth::user()->agent_link->agent_id . ', `TEAM_ID` = ' . Auth::user()->agent_link->team_id . ' WHERE  LAST_WORKED is NULL and ID IN (' . $allIds . ');'));
            }
        }

        $numbers[] = preg_replace('/[^0-9]/', '', $account->EMPL_PHONE1_NMBR);
        $faxes[] = preg_replace('/[^0-9]/', '', $account->EMPL_FAX);
        $emails[] = $account->emails;
        $directory = [];
        $powerlead = [];

        //Check to see if Directory Lead exists and assign values if true
        if (!empty($account->DIRECTORY_LINK)) {
            if (Directory_Active_Account::where('directory_account_id', $account->DIRECTORY_LINK)->exists())
                $directory = Directory_Active_Account::find($account->DIRECTORY_LINK);
            else
                $directory = Directory_Inactive_Account::find($account->DIRECTORY_LINK);

            if (!empty($directory)) {
                $numbers[] = preg_replace('/[^0-9]/', '', $directory->direct_phone);
                $numbers[] = preg_replace('/[^0-9]/', '', $directory->verification_phone);
                $faxes[] = preg_replace('/[^0-9]/', '', $directory->verification_fax);
                $emails[] = $directory->verification_email;
            }
        }

        //Check for multiple addresses associated with directory account, handle display in blade view
        $directoryAddresses = [];
        $directoryCities = [];
        $directoryStates = [];
        $directoryZips = [];
        if (!empty($directory->address) || !empty($directory->city) || !empty($directory->state) || !empty($directory->zip)) {
            $directoryAddresses = explode('|', $directory->address);
            $directoryCities = explode('|', $directory->city);
            $directoryStates = explode('|', $directory->state);
            $directoryZips = explode('|', $directory->zip);
        }
        $directoryRows = max([count($directoryAddresses), count($directoryCities), count($directoryStates), count($directoryZips)]);

        //Check to see if Powerlead exists and assign values if true
        if (!empty($account->POWERLEAD_ID)) {
            $powerlead = Powerlead_Accounts::find($account->POWERLEAD_ID);
            if($powerlead != null){
                $numbers[] = preg_replace('/[^0-9]/', '', $powerlead->local_phone);
                $numbers[] = preg_replace('/[^0-9]/', '', $powerlead->main_phone);
                $faxes[] = preg_replace('/[^0-9]/', '', $powerlead->fax);
                $emails[] = $powerlead->email;
            }
        }

        $web_crawler = [];
        if (!empty($account->WEB_CRAWLER_ID)) {
            $web_crawler = Web_Crawler::find($account->WEB_CRAWLER_ID);
            $numbers[] = preg_replace('/[^0-9]/', '', $web_crawler->company_phone);
            $emails[] = $web_crawler->company_email;
        }

        $blockedCompanies = [];
        $blockedNumbers = [];
        $blockedFaxes = [];
        $blockedEmails = [];
        $blockedCompanies = Blocked_Company::where('corporation_id', $account->CORPORATION_ID)->get();
        //checked for blocked contacts and add them to lists to be handled in blade view
        foreach ($blockedCompanies as $company) {
            if (!empty($company->phone_number) && ((!empty($company->ext) && in_array(preg_replace('/[^0-9]/', '', $company->phone_number . $company->ext), $numbers)) || (!empty($company->phone_number) && in_array(preg_replace('/[^0-9]/', '', $company->phone_number), $numbers)))){
                $blockedNumbers[] = preg_replace('/[^0-9]/', '', $company->phone_number . $company->ext);
            }
            if (!empty($company->fax_number) && in_array(preg_replace('/[^0-9]/', '', $company->fax_number), $faxes)) {
                $blockedFaxes[] = preg_replace('/[^0-9]/', '', $company->fax_number);
            }
            if (!empty($company->email) && in_array($company->email, $emails)) {
                $blockedEmails[] = $company->email;
            }
        }

        //adds in the needed capcodes/ phone numbers for AWG7 type accounts
        if ($account->ACCT_TYPE != "AWG7") {
            $capcodes = Capcode::where('corporation_id', $account->CORPORATION_ID)
            ->when($userRole == 'agent', function ($query){
                return $query->where('agent_access', 1);
            })->where('is_archived', '=', '0')->orderBy('capcode', 'asc')->get();
            $phoneNumbers = [];
        } else {
            $capcodes = Capcode::where('corporation_id', $account->CORPORATION_ID)->where('capcode_type', "AWG7")->where('is_archived', '=', '0')->orderBy('capcode', 'asc')->get();
            $phoneNumbers = AWG7_Phone_Numbers::where('account_id', $account->ID)->get();
        }

        //gets the history for all of the accounts that share an agent
        if ($type == 'inactive') {
            $ssn = Inactive_Account::SELECT('ID', 'POESCORE', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->where('ACCT_AGENT', $account->ACCT_AGENT)->get();
        } else {
            $ssn = Active_Account::SELECT('ID', 'POESCORE', 'ACCESS_RULES', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->where('ACCT_AGENT', $account->ACCT_AGENT)->get();
        }
        foreach ($ssn as $id) {
            $ids[] = $id->ID;
        }
        $history = Worked_History::whereIn('active_account_id', $ids)
        ->with('capcode_link')
        ->when(!in_array($userRole,['corporate_admin', 'manager', 'admin']), function ($query){
            return $query->where('capcode', '!=', -1);
        })
        ->orderByDesc("created_at", "desc")
        ->get();
        
        $count = $account->WORK_ATTEMPTS ?? 0;
        $max = Team::select('max_attempts')->where('team_id', $account->TEAM_ID)->first()->max_attempts ?? 5;

        $verified_hit = [];
        $active_account_files = [];
        if (!empty($account->VERIFIED_HITS_ID)) {
            $verified_hit = Verified_Hit::find($account->VERIFIED_HITS_ID);
            $active_account_files = Active_Account_Files::where('verified_hits_id', $account->VERIFIED_HITS_ID)->get();
        }

        if (strlen($account->ACCT_SSN) < 9)
            $account->ACCT_SSN = str_pad($account->ACCT_SSN, 9, '0', STR_PAD_LEFT);

        if(in_array($userRole, ['admin', 'manager', 'corporate_admin']))
            $agents = Agent::where('corporation_id', $account->CORPORATION_ID)->with('user_link')->get();
        else
            $agents = [];

        return view('agents.pages.formRocky')->with('account', $account)->with('capcodes', $capcodes)
            ->with('directory', $directory)->with('powerlead', $powerlead)->with('history', $history)->with('ssns', $ssn)->with('account_ssn', $account->ID)
            ->with('account_id', $accountId)->with('count', $count)->with('type', $type)->with('max_attempts', $max)
            ->with('directoryRows', $directoryRows)->with('directoryAddresses', $directoryAddresses)->with('phoneNumbers', $phoneNumbers)->with('web_crawler', $web_crawler)
            ->with('directoryCities', $directoryCities)->with('directoryStates', $directoryStates)->with('directoryZips', $directoryZips)
            ->with('blocked_numbers', $blockedNumbers)->with('blocked_emails', $blockedEmails)->with('blocked_faxes', $blockedFaxes)->with('blockedCompanies', $blockedCompanies)
            ->with('show', $show)->with('verified_hit', $verified_hit)->with('active_account_files', $active_account_files)->with('requirments', $requirments)
            ->with('minutes', '00')->with('seconds', '00')->with('agents', $agents)->with('timeZoneQueue', $timeZoneQueue);
    }


    //creates a history to add to the table
    public function addHistory($accountId, $timeSpent, $capcodeId, $note, $scheduledCall, $user)
    {
        $history = new Worked_History;
        $history->active_account_id = $accountId;
        $history->user_role = $user[0];
        $history->agent_id = $user[1];
        $history->time_spent = $timeSpent;
        $history->capcode = $capcodeId;
        $history->notes = strip_tags($note);
        $history->scheduled_call =  $scheduledCall;
        $history->save();
        return $history;
    }

    //gets the next account according to the rules
    public function openNext($account_id, $type, $timeZone)
    {
        $agent_id = Auth::user()->agent_link->agent_id;
        $corporation_id = Auth::user()->agent_link->corporation_id;
        $team_id = Agent::select('team_id')->where('agent_id', $agent_id)->first();

        //gets the order of the accounts
        $orderArray = $this->getOrderArray($corporation_id, $team_id->team_id);
        $firstPriority = $orderArray[0];
        $secondPriority = $orderArray[1];
        $thirdPriority = $orderArray[2];

        //check for capcodes pending approval and only show them in bottom table
        $capcodes = Capcode::where('corporation_id', $corporation_id)->where('type', 'pending_approval')->get();
        $pending = [];
        foreach ($capcodes as $capcode) {
            $pending[] = $capcode->id;
        }

        //variable to compare exact time against
        $now = Carbon::now()->toDateTimeString();
        $three_business_days = date('Y-m-d', strtotime('-3 weekdays'));

        //check if work reminder exists and is past due
        $account = Active_Account::where('ACCT_AGENT', $agent_id)->where('ID', '!=', $account_id)->whereNotNull('WORK_REMINDER')->where('WORK_REMINDER', '!=', '')->where('WORK_REMINDER', '<', $now)->whereNotIn('CAPCODE', $pending)->orderBy('WORK_REMINDER', 'ASC')->first();
        if (!empty($account)) {  
            $account->WORK_REMINDER = null;
            $account->save();
        } else {
            //or choose the next account in the queue
            $account = Active_Account::select('ID')
                ->where('ACCT_AGENT', $agent_id)
                ->where('ID', '!=', $account_id)
                ->when($pending, function ($query, $pending) {
                    return $query->whereRAW('(CAPCODE not in ('.implode(',', $pending).') or CAPCODE IS NULL)');
                })->when($timeZone, function ($query, $timeZone) {
                    return $query->where('TIME_ZONE',$timeZone);
                })->when($firstPriority, function ($query, $firstPriority) {
                    return $query->orderByRaw($firstPriority);
                })->when($secondPriority, function ($query, $secondPriority) {
                    return $query->orderByRaw($secondPriority);
                })->when($thirdPriority, function ($query, $thirdPriority) {
                    return $query->orderByRaw($thirdPriority);
                })->where(function($query) use ($type, $three_business_days){
                    //grabs either the worked or unworked based on queue
                    if($type == "worked")
                        return $query->whereRAW('(date(LAST_CALL) < CURDATE() OR LAST_CALL IS NULL) AND (date(LAST_FAX_EMAIL) <= ' . $three_business_days . ' OR LAST_FAX_EMAIL IS NULL) AND date(LAST_WORKED) != CURDATE()');
                    else
                        return $query->whereRAW('(LAST_WORKED is NULL or LAST_WORKED = "")');
                })->first();
        }

        if (empty($account)) {
            if($timeZone == null || $timeZone == '')
                $timeZone = "All";
            if($type == '' || $type == null)
                $type = "Unworked";
            $message = 'No more accounts of type: ' . $type . ' at timezone: '.$timeZone.' available to work at this time';
            return redirect('/agent/newActiveAccounts')->with('message', $message);
        }
        return $this->getRockyForm($account->ID, $type, $timeZone);
    }

    //saves the history for the auto call, fax and email
    public function autoButtons(Request $request){
        $account = $this->findAccount($request->id);
        if ($account['type'] != 'inactive')
            $active = 1;
        else
            $active = 0;
        $account = $account['account'];

        $autos = Capcode::whereIn('capcode', [2210, 2209, 2208])->where('corporation_id', $account->CORPORATION_ID)->get();

        if ($request->phone) {
            $capcode = $autos->where('capcode', 2210)->first()->id;
            $account->LAST_CALL = Carbon::now();
            $account->save();
        } else if ($request->fax) {
            //makes sure that company name was filled out
            if ($request->company_name == '') {
                echo json_encode([]);
                return;
            }
            $this->setFaxHistory($account, $request->fax, $request->company_name, $request->fullSSN, $active);
            $capcode = $autos->where('capcode', 2209)->first()->id;
            $account->LAST_FAX_EMAIL = Carbon::now();
            $account->save();
        } else if ($request->email) {
            $capcode = $autos->where('capcode', 2208)->first()->id;
            $account->LAST_FAX_EMAIL = Carbon::now();
            $account->save();
        }

        $history = $this->addHistory($request->id, null, $capcode, $request->note, null, [Auth::user()->role, Auth::user()->getRoleId()]);

        $account->capcode = $history->capcode;
        $account->last_worked = Carbon::now()->toDateTimeString();
        if ($active == 1){ 
            if (in_array($account->POWERLEAD_CAPCODE, [1,2,3])) 
                $account->POWERLEAD_CAPCODE = 7;

            $powerAccount = Powerlead_Accounts::where('active_account_id', $account->ID)->first();
            if ($powerAccount != null) {
                if ($powerAccount->verified == null) {
                    $powerAccount->verified = 0;
                    $powerAccount->save();
                }
            }
        }
        $account->save();

        $capcode = Capcode::where('id', $capcode)->first()->capcode;
        $historyArray = array(
            'active_account_id' => $history->active_account_id,
            'agent_id' => $history->agent_id,
            'date' => $history->updated_at,
            'capcode' => $capcode,
            'notes' => $history->notes,
            'time' => $history->scheduled_call,
        );
        if (Auth::user()->role != 'agent')
            $historyArray['admin'] = true;

        echo json_encode($historyArray);
    }

    public function updateAccount(Request $request)
    {
        $this->validate($request, [
            'empl_name_verified' => 'max:90',
            'empl_ph_nmbr_verified' => 'max:90',
            'empl_city_verified' => 'max:90',
            'empl_zip_verified' => 'max:90',
            'empl_title_verified' => 'max:90',
            'empl_fax_verified' => 'max:90',
            'empl_email_verified' => 'max:90',
            'empl_verification_mailing_address_verified' => 'max:90',
            'empl_contact_verified' => 'max:90',
            'empl_contact_title_verified' => 'max:90',
            'future_third_party' => 'max:90',
            'future_phone' => 'max:90',
            'future_fax' => 'max:90',
            'future_email' => 'max:90',
            'future_auto_phone' => 'max:90',
        ]);

        $capcode = Capcode::where('id', $request->verified_capcode)->where('corporation_id', $request->corporation_id)->first();

        $account = $this->findAccount($request->account_id)['account'];

        //if admin choses to change the agent
        if($request->agent_selector != null){
            if($request->agent_selector == "remove")
                $account->ACCT_AGENT = null;
            else
                $account->ACCT_AGENT = $request->agent_selector;
        }

        if ($capcode->type == 'verified') {
            if (!$this->filledRequired($request)) {
                $failed['failed'] = true;
                echo json_encode($failed);
                return;
            }
            $verified_file = $this->addVerifiedHit($request, $account->VERIFIED_HITS_ID, $capcode->type);
        }

        if (!empty($account->DIRECTORY_LINK)) {
            $this->updateDirectoryAccount($request);
        } else {
            if (in_array($capcode->capcode, [1103, 1104, 1111, 1112])) {
                $name = $account->EMPL_NAME;
                $empmatchname = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $name);
                $empmatchname = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));

                // Directory account w/ name match exists
                if (!empty($checkNameMatch = Directory_Active_Account::where('name_match', $empmatchname)->first())) {
                    $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
                } else if (!empty($checkNameMatch = Directory_Inactive_Account::where('name_match', $empmatchname)->first())) {
                    $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
                } else {
                    $directoryAccount = new Directory_Active_Account();
                    $directoryAccount->live_flag = 0;
                    $directoryAccount->fresh_flag = 1;
                    $directoryAccount->employer_name = $name;
                    $directoryAccount->name_match = $empmatchname;
                    $directoryAccount->address = $account->EMPL_ADDR1;
                    $directoryAccount->city = $account->EMPL_CITY;
                    $directoryAccount->state = $account->EMPL_ST;
                    $directoryAccount->zip = $account->EMPL_ZIP;
                    $directoryAccount->direct_phone = $account->EMPL_PHONE1_NMBR;
                    $directoryAccount->save();

                    $account->DIRECTORY_LINK = $directoryAccount->directory_account_id;
                }
            }
        }

        $verified_hit = $this->addVerifiedHit($request, $account->VERIFIED_HITS_ID, $capcode->type);
        $account->VERIFIED_HITS_ID = $verified_hit->id;
        if ($request->verified_file)
            $active_account_file = $this->saveFile($request, $account->VERIFIED_HITS_ID);

        if ($request->is_attempt == 1 && Auth::user()->role == 'agent') {
            if (empty($account->WORK_ATTEMPTS))
                $account->WORK_ATTEMPTS = 1;
            else
                $account->WORK_ATTEMPTS += 1;
        }

        $account->LAST_WORKED = Carbon::now()->toDateTimeString();
        if (!empty($request->time))
            $account->WORK_REMINDER = $request->time;
        if (in_array($account->POWERLEAD_CAPCODE, [1,2,3]))
            $account->POWERLEAD_CAPCODE = 7;

        $powerAccount = Powerlead_Accounts::where('active_account_id', $account->ID)->first();
        if ($powerAccount != null) {
            if ($powerAccount->verified == null) {
                $powerAccount->verified = 0;
                $powerAccount->save();
            }
        }

        $account->CAPCODE = $request->verified_capcode;
        $account->save();

        if (Auth::user()->role != 'agent') {
            $request->request->add(['admin' => 'admin']);
            $reached_max_attempts = false;
        } else
            $reached_max_attempts = $this->checkTotalAttempts($request);


        $history = $this->addHistory($account->ID, $request->seconds_spent, $capcode->id, $request->note, $request->time, [Auth::user()->role, Auth::user()->getRoleId()]);

        if (($capcode->type == 'verified' || $capcode->type == 'unverified') && $request->type != 'inactive') {
            //add a parameter to tell clientside to close account
            $request->request->add(['closed' => 'closed']);
            $this->inactivateAccount($request);

            $closed = 'to close';
        } elseif ($reached_max_attempts == true && $request->is_attempt == 1 && $request->type != 'inactive') {
            //sets the capcode to overworked
            $account->CAPCODE = Capcode::where('capcode', 2335)->where('corporation_id', $account->CORPORATION_ID)->first()->id ?? 2335;
            $account->save();

            $this->addHistory($account->ID, 0, $account->CAPCODE, "Account hit max attempts, was last worked by Agent: " . Auth::user()->agent_link->agent_id . ".", null, ['Auto Generated', 0]);

            //add a parameter to tell clientside to close account
            $request->request->add(['closed' => 'closed']);
            $this->inactivateAccount($request);

            $closed = 'to close';
        } elseif ($request->type == 'inactive')
            $closed = 'closed';
        else
            $closed = 'active';

        //adds to all SSNs if there are multiple, called here since all routes go here
        $this->updateAllSSN($request, $account, $closed);

        if ($request->open_next == 1)
            return $this->openNext($request, $request->type, $request->timeZoneQueue);
        else{
            $historyArray = array(
                'agent_id' => $history->agent_id,
                'date' => $history->updated_at,
                'capcode' => $capcode->capcode,
                'notes' => $history->notes,
                'time' => $history->scheduled_call,
                'count' => $account->WORK_ATTEMPTS,
            );
            if($request->closed)
                $historyArray['closed'] = $request->closed;
            if ($request->admin) 
                $historyArray[$request->admin] = $request->admin;
            if (isset($active_account_file)) {
                $historyArray['filename'] = $verified_file->name;
                $historyArray['filepath'] = $verified_file->file_path;
                $historyArray['fileid'] = $verified_file->id;
            }
            echo json_encode($historyArray);
        }
    }

    //increases the work attempts if the user leaves the page without saving
    public function increaseWorkAttempts(Request $request){
        $account = $this->findAccount($request->account_id)['account'];
        if(empty($account) || Auth::user()->role != 'agent')
            return;

        $account->LAST_WORKED = date('Y-m-d H:i:s');
        $account->WORK_ATTEMPTS++;
        $account->save();

        $current_capcode = Capcode::find($account->CAPCODE);

        // Account is overworked only if it's at max attempts and has an inconclusive capcode and it is active
        if ($this->checkTotalAttempts($request) && $current_capcode->type == 'inconclusive' && $account['type'] != 'inactive'){
            //sets the capcode to overworked
            $overworked = Capcode::where('capcode', 2335)->where('corporation_id', $account->CORPORATION_ID)->first();
            if ($overworked != null) {
                $account->CAPCODE = $overworked->id;
                $request->verified_capcode = $overworked->id;
                $account->save();
            }
            $overworked = $overworked->id ?? 2335;
            $this->addHistory($account->ID, 0, $overworked, "Account hit max attempts, was last worked by " . Auth::user()->role . ": " . Auth::user()->agent_link->agent_id . ".", null, ['Auto Generated', 0]);

            //add a parameter to tell clientside to close account
            $request->request->add(['closed' => 'closed']);
            $request->request->add(['overWorked' => true]);

            $this->inactivateAccount($request);

            //adds to all SSNs if there are multiple, called here since all routes go here
            $this->updateAllSSN($request, $account, 'to close');
        }
    }

    //checks if all the accounts have hit max, if so returns true
    public function checkTotalAttempts($request){
        $account = $this->findAccount($request->account_id);
        $type = $account['type'];
        $account = $account['account'];
        if ($type == 'inactive')
            return false;

        $allAccountIds = $this->getAllAccessIds($account->ACCT_SSN, $account->CORPORATION_ID, $type);
        $ssns = Active_Account::SELECT('ID', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->get();
        $attemptCounter = 0;

        foreach ($ssns as $ssn) {
            if ($ssn->WORK_ATTEMPTS >= $request->max_attempts_total)
                $attemptCounter++;
        }
          
        if ($attemptCounter >= count($ssns)) 
            return true;
        
        return false;
    }

    public function inactivateAccount(Request $request){
        $active = Active_Account::find($request->account_id);
        if (in_array($active->POWERLEAD_CAPCODE, [1,2,3])) {
            $active->POWERLEAD_CAPCODE = 7;
            $active->save();
        }
        
        $inactive = new Inactive_Account;
        $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts');
        for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
            $item = strval($active_accounts_mapping_columns[$i]);
            if (!in_array($item, ['CREATED_AT','UPDATED_AT']))
                $inactive->$item = $active->$item;
        }

        if ($inactive->DIRECTORY_FLAG == null)
            $inactive->DIRECTORY_FLAG = 0;

        $inactive->save();
        $active->delete();
    }

    //If future verification is updated in Directory Lead form, update capcode and assign new agent
    public function updateDirectoryAccount(Request $request){
        $futureCapcode = Directory_Capcode::where('capcode', 1119)->first();
        if (empty($request->future_verification_third_party) && empty($request->future_verification_phone) && empty($request->future_verification_email) && empty($request->future_verification_fax) && empty($request->future_verification_auto_phone))
            return;
        
        $account = Directory_Inactive_Account::where('directory_account_id', $request->directory_account_id)->first();
        if (empty($account)){
            $account = Directory_Active_Account::where('directory_account_id', $request->directory_account_id)->first();
            if (empty($account))
                return;
            else
                $inactive = new Directory_Inactive_Account();
        }

        $history = new Directory_Work_History;
        $history->directory_account_id = $request->directory_account_id;
        $history->capcode = $futureCapcode->capcode_id;
        $history->verification_notes = $futureCapcode->description;
        $history->worker_role = Auth::user()->role;
        $history->worker_id = Auth::user()->getRoleId();
        $history->save();

        $account->future_verification_third_party = $request->future_verification_third_party;
        $account->future_verification_phone = $request->future_verification_phone;
        $account->future_verification_email = $request->future_verification_email;
        $account->future_verification_fax = $request->future_verification_fax;
        $account->future_verification_auto_phone = $request->future_verification_auto_phone;
        $account->capcode = $futureCapcode;
        if (Auth::user()->role == 'agent') {
            $account->agent_id = Auth::user()->agent_link->agent_id;
            $account->directory_agent_id = null;
        }
        elseif(Auth::user()->role == 'directory_agent') {
            $account->directory_agent_id == Auth::user()->directory_agent_link->directory_agent_id;
            $account->agent_id = null;
        }
        $account->save();

        if(isset($inactive)){
            $active_accounts_mapping_columns = Schema::getColumnListing('directory_active_accounts');
            for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
                $item = strval($active_accounts_mapping_columns[$i]);
                if (!in_array($item, ['created_at', 'updated_at', 'live_flag', 'due_date']))
                    $inactive->$item = $account->$item;
            }
            $inactive->save();
            $account->delete();
        }
    }

    public function getSSNAccount(request $request){
        //updates the additonal data found
        if (Active_Account::where('ID', $request->lastId)->exists())
            Active_Account::where('ID', $request->lastId)->update(['LAST_EMPL_NAME' => $request->emplName, 'LAST_EMPL_ADDR' => $request->emplAddr, 'LAST_EMPL_PHONE' => $request->emplPhone, 'LAST_EMPL_EMAIL' => $request->emplEmail, 'LAST_EMPL_FAX' => $request->emplFax]);
        else
            Inactive_Account::where('ID', $request->lastId)->update(['LAST_EMPL_NAME' => $request->emplName, 'LAST_EMPL_ADDR' => $request->emplAddr, 'LAST_EMPL_PHONE' => $request->emplPhone, 'LAST_EMPL_EMAIL' => $request->emplEmail, 'LAST_EMPL_FAX' => $request->emplFax]);

        //makes sure the user has access to the account
        $checkAccess = $this->checkAccess($request->id);
        if ($checkAccess == false) {
            $account = [];
            $check = false;
        } else {
            $check = true;

            //checks if the account exists in active, if not moves to inactive
            $account = Active_Account::SELECT('ID', 'POWERLEAD_ID', 'CORPORATION_ID', 'DIRECTORY_LINK', 'WEB_CRAWLER_ID', 'ACCT_DOB', 'ACCT_ST', 'ACCT_CITY', 'ACCT_AD1', 'ACCT_ZIP', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'CLIENT_NAME', 'CLIENT_PHONE', 'ACCT_ID')->find($request->id);
            if ($account == null) {
                $account = Inactive_Account::SELECT('ID', 'POWERLEAD_ID', 'CORPORATION_ID', 'DIRECTORY_LINK', 'WEB_CRAWLER_ID', 'ACCT_DOB', 'ACCT_ST', 'ACCT_CITY', 'ACCT_AD1', 'ACCT_ZIP', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'CLIENT_NAME', 'CLIENT_PHONE', 'ACCT_ID')->find($request->id);
            }
            $corporation_id = $account->CORPORATION_ID ?? null;

            //if account is not in either, returns false
            if ($account == null || !$this->checkMatchingCorporation($corporation_id)) {
                $account = [];
                $check = false;
            }
        }
        echo json_encode(array($account, $check));
    }

    public function getLeadData(request $request){
        if ($request->id == null) {
            echo json_encode(array([], null, null, null));
            return;
        }

        if (Active_Account::where('ID', $request->id)->exists())
            $AA = Active_Account::SELECT('EMPL_NAME', 'EMPL_ADDR1', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_PHONE1_NMBR', 'EMPL_FAX', 'EMPL_EMAIL', 'LAST_EMPL_NAME', 'LAST_EMPL_ADDR', 'LAST_EMPL_PHONE', 'LAST_EMPL_EMAIL', 'LAST_EMPL_FAX', 'CORPORATION_ID', 'WORK_ATTEMPTS')->find($request->id);
        else 
            $AA = Inactive_Account::SELECT('EMPL_NAME', 'EMPL_ADDR1', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_PHONE1_NMBR', 'EMPL_FAX', 'EMPL_EMAIL', 'LAST_EMPL_NAME', 'LAST_EMPL_ADDR', 'LAST_EMPL_PHONE', 'LAST_EMPL_EMAIL', 'LAST_EMPL_FAX', 'CORPORATION_ID', 'WORK_ATTEMPTS')->find($request->id);
        
        $fax = $AA->EMPL_FAX ?? null;
        $fax = preg_replace('/[^0-9]/', '', $fax);
        $blocked = $this->checkBlocked($AA->EMPL_PHONE1_NMBR ?? null, null, $fax, $AA->EMPL_EMAIL ?? null, $AA->CORPORATION_ID);
        echo json_encode(array($AA, $blocked['phone1'], $blocked['email'], $blocked['fax']));
    }
    
    public function getWebCrawlerData(request $request){
        $WC = Web_Crawler::SELECT('ID', 'company_name', 'company_website', 'employee_count', 'company_industry', 'company_address', 'company_city', 'company_state', 'company_zip', 'company_phone', 'company_email', 'company_linked_in', 'company_country')->find($request->id);
        $blocked = $this->checkBlocked($WC->company_phone ?? null, null, null, $WC->company_email ?? null, $request->corpId);
        echo json_encode(array($WC, $blocked['phone1'], $blocked['email']));
    }

    public function getDirectoryData(request $request){
        //Check to see if Directory Lead exists and assign values if true
        if (!empty(Directory_Active_Account::find($request->id)))
            $directory = Directory_Active_Account::find($request->id);
        else
            $directory = Directory_Inactive_Account::find($request->id);

        //Check for multiple addresses associated with directory account, handle display in blade view
        $directoryAddresses = [];
        $directoryCities = [];
        $directoryStates = [];
        $directoryZips = [];
        if (!empty($directory->address) || !empty($directory->city) || !empty($directory->state) || !empty($directory->zip)) {
            $directoryAddresses = explode('|', $directory->address);
            $directoryCities = explode('|', $directory->city);
            $directoryStates = explode('|', $directory->state);
            $directoryZips = explode('|', $directory->zip);
        }
        $directoryRows = max ([count($directoryAddresses), count($directoryCities), count($directoryStates), count($directoryZips)]);

        $fax = $directory->verification_fax ?? null;
        $fax = preg_replace('/[^0-9]/', '', $fax);
        $blocked = $this->checkBlocked($directory->verification_phone ?? null, $directory->direct_phone ?? null, $fax, $directory->verification_email ?? null, $request->corpId);

        echo json_encode(array($directory, $directoryRows, $directoryAddresses, $directoryCities, $directoryStates, $directoryZips, $blocked['phone1'], $blocked['phone2'], $blocked['email'], $blocked['fax']));
    }

    //checks if the phone numbers,fax numbers, or email is blocked for all the get data functions
    public function checkBlocked($phone1, $phone2, $fax, $email, $corpId){
        $blocked = [
            'phone1' => false,
            'phone2' => false,
            'fax' => false,
            'email' => false
        ];

        if (Blocked_Company::where('phone_number', $phone1)->where('corporation_id', $corpId)->exists())
            $blocked['phone1'] = true;
        if (Blocked_Company::where('phone_number', $phone2)->where('corporation_id', $corpId)->exists())
            $blocked['phone2'] = true;
        if (Blocked_Company::where('fax_number', $fax)->where('corporation_id', $corpId)->exists())
            $blocked['fax'] = true;
        if (Blocked_Company::where('email', $email)->where('corporation_id', $corpId)->exists())
            $blocked['email'] = true;
        return $blocked;
    }

    public function formatEmailData(Request $request){
        $this->validate($request, [
            'acct_type' => 'in:inactive,worked,active',
            'email' => 'email',
        ]);

        $account = "";
        if ($request->acct_type == 'inactive')
            $account = Inactive_Account::find($request->email_acct_id);
        else
            $account = Active_Account::find($request->email_acct_id);
        
        if ($request->fullSSN == "1")
            $ssn = $this->formatSSN($account->ACCT_SSN);
        else {
            $ssn = $this->formatSSN($account->ACCT_SSN);
            $ssn = 'xxx-xx-' . substr($ssn, -4);
        }

        $this->setUpEmail($account, $request->email, $request->company_name, $ssn);
    }

    private function formatSSN($ssn){
        if(strlen($ssn) < 9)
            $ssn = str_pad($ssn, 9, '0', STR_PAD_LEFT);

        if (preg_match("#^\d{3}-?\d{2}-?\d{4}$#", $ssn))
            return preg_replace("#^(\d{3})-?(\d{2})-?(\d{4})$#", "$1-$2-$3", $ssn);
        else 
            return $ssn;
    }

    public function setUpAka($akas){
        $aka_name_match = "";
        foreach ($akas as $aka) {
            $aka = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $aka);
            $wordCount = str_word_count($aka);
            if ($wordCount > 3) {
                $aka = $this->trim_text($aka, 2);
            }
            $aka = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $aka));
            $aka_name_match = $aka_name_match . $aka . ",";
        }

        return substr_replace($aka_name_match, "", -1);
    }

    public function addVerifiedHit(Request $request, $id, $capcode_type){
        $verified_hit = Verified_Hit::findOrNew($id);
        $verified_hit->employer_type = $request->verified_employer_type;
        $verified_hit->employer_name = $request->empl_name_verified;
        $verified_hit->employer_phone = $request->empl_ph_nmbr_verified;
        $verified_hit->employer_address_1 = $request->empl_addr1_verified;
        $verified_hit->employer_address_2 = $request->empl_addr2_verified;
        $verified_hit->employer_city = $request->empl_city_verified;
        $verified_hit->employer_state = $request->empl_st_verified;
        $verified_hit->employer_zip = $request->empl_zip_verified;
        $verified_hit->employer_name = $request->empl_name_verified;
        $verified_hit->employer_fax = $request->empl_fax_verified;
        $verified_hit->employer_email = $request->empl_email_verified;
        $verified_hit->employer_title = $request->empl_title_verified;
        $verified_hit->verification_mailing_address = $request->empl_verification_mailing_address_verified;
        $verified_hit->verification_contact_name = $request->empl_contact_verified;
        $verified_hit->verification_contact_title = $request->empl_contact_title_verified;
        $verified_hit->future_verification_third_party = $request->future_third_party;
        $verified_hit->future_verification_phone = $request->future_phone;
        $verified_hit->future_verification_fax = $request->future_fax;
        $verified_hit->future_verification_email = $request->future_email;
        $verified_hit->future_verification_auto_phone = $request->future_auto_phone;
        $verified_hit->capcode = $request->capcode_id;
        $verified_hit->capcode_type = $capcode_type;
        if (Auth::user()->role == 'agent') 
            $verified_hit->agent_id = Auth::user()->agent_link->agent_id;
        if (Auth::user()->role == 'directory_agent') 
            $verified_hit->directory_agent_id = Auth::user()->directory_agent_link->directory_agent_id;
        $verified_hit->save();

        return $verified_hit;
    }

    public function updateAllSSN(Request $request, $account, $closed){
        if ($closed == 'closed')
            $ssn = Inactive_Account::SELECT('ID')->where('ACCT_SSN', $account->ACCT_SSN)->where('CORPORATION_ID', $account->CORPORATION_ID)->count();
        else 
            $ssn = Active_Account::SELECT('ID')->where('ACCT_SSN', $account->ACCT_SSN)->where('CORPORATION_ID', $account->CORPORATION_ID)->count();

        //if there is only one ssn, ends the function
        if (($ssn == 1 && $closed != 1) || ($ssn == 0 && $closed == 1))
            return;

        //appends to the statement based on what fields were updated
        $setStatement = "";
        if ($request->verified_capcode)
            $setStatement = $setStatement . " `CAPCODE` = '" . $account->CAPCODE . "',";

        $setStatement = $setStatement . " `VERIFIED_HITS_ID` = '" . $account->VERIFIED_HITS_ID . "',";

        //sets all the last calls and emails/faxes
        $setStatement = $setStatement . " `LAST_CALL` = '" . $account->LAST_CALL . "',";
        $setStatement = $setStatement . " `LAST_FAX_EMAIL` = '" . $account->LAST_EMAIL_FAX . "',";

        //removes the extra comma at the end of a statement
        $setStatement = $setStatement . " `LAST_WORKED` =  now() ";

        switch ($closed) {
            //accounts are just updated
            case 'active':
                DB::select(DB::raw('UPDATE `active_accounts` SET '. $setStatement .' WHERE `CORPORATION_ID` = '. $account->CORPORATION_ID .' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));
            break;
            //accounts are moved to inactive accounts
            case 'to close':
                DB::select(DB::raw('UPDATE `active_accounts` SET ' . $setStatement . ' WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                DB::select(DB::raw('INSERT INTO `inactive_accounts` SELECT * FROM `active_accounts` WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                DB::select(DB::raw('DELETE FROM `active_accounts` WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));
            break;
            //inactive account is updated
            case 'closed':
                DB::select(DB::raw('UPDATE `inactive_accounts` SET ' . $setStatement . ' WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));
            break;
        }
    }

    //backend check that needed fields are filled
    public function filledRequired(Request $request){
        $requirments = Verification_Requirements::where('corporation_id', $request->corporation_id)->first();
        $requiredFields = ['employer_type' => 'verified_employer_type', 'employer_name' => 'empl_name_verified', 'employer_phone' => 'empl_ph_nmbr_verified', 'employer_address_1' => 'empl_addr1_verified',
        'employer_address_2' => 'empl_addr2_verified', 'employer_city' => 'empl_city_verified', 'employer_state' => 'empl_st_verified', 'employer_zip' => 'empl_zip_verified', 'consumer_title' => 'empl_title_verified',
        'employer_fax' => 'empl_fax_verified', 'employer_email' => 'empl_email_verified', 'verification_mailing_address' => 'empl_verification_mailing_address_verified', 
        'verification_contact_name' => 'empl_contact_verified', 'verification_contact_title' => 'empl_contact_title_verified', 'future_verifications' => 'future_verification'];

        foreach($requiredFields as $required => $field){
            if (($requirments->{$required} == 1) && (str_replace(' ', '', $request->{$field}) == ""))
                return false;
        }
        return true;
    }

    public function uploadFileActive(request $request){
        if ($request->type == 'inactive')
            $account = Inactive_Account::find($request->account_id);
        else
            $account = Active_Account::find($request->account_id);

        $verified_hit = Verified_Hit::findOrNew($account->VERIFIED_HITS_ID);

        if (Auth::user()->role == 'agent')
            $verified_hit->agent_id = Auth::user()->agent_link->agent_id;
        if (Auth::user()->role == 'directory_agent') 
            $verified_hit->directory_agent_id = Auth::user()->directory_agent_link->directory_agent_id;

        $verified_hit->save();

        $account->VERIFIED_HITS_ID = $verified_hit->id;
        $account->save();

        $active_account_file = $this->saveFile($request, $account->VERIFIED_HITS_ID);

        $fileArray = array(
            'filename' => $active_account_file->name,
            'fileid' => $active_account_file->id,
        );
        echo json_encode($fileArray);
    }

    public function saveFile($request, $verifiedHitId){
        $date = date('F_j_Y_h-i-s_A');
        $filePath = storage_path('app/public/verified_files/' . $request->corporation_id . '/' . $verifiedHitId);

        if (!empty($request->file('verified_file')))
            $verified_file = $request->file('verified_file')->getClientOriginalName();

        $filename = pathinfo($verified_file, PATHINFO_FILENAME);
        $extension = pathinfo($verified_file, PATHINFO_EXTENSION);

        $request->file('verified_file')->move($filePath, $filename . '_' . $date . '.' . $extension);
        $file_path = 'verified_files/' . $request->corporation_id . '/' . $verifiedHitId . '/' . $filename . '_' . $date . '.' . $extension;

        $active_account_file = new Active_Account_Files;
        $active_account_file->name = $verified_file;
        $active_account_file->file_path = $file_path;
        $active_account_file->user_id = Auth::user()->user_id;
        $active_account_file->verified_hits_id = $verifiedHitId;
        $active_account_file->save();
        return $active_account_file;
    }

    //downloads the file for the active account
    public function downloadActiveAccount($id){
        $active_file = Active_Account_Files::find($id);
        return response()->download(storage_path('app/public/' . $active_file->file_path));
    }

    public function deleteActiveAccountFile($id){
        $active_file = Active_Account_Files::find($id);
        $active_file->delete();
    }

    public function updateAALastInfo(Request $request){
        if (Active_Account::where('ID', $request->lastId)->exists())
            $account = Active_Account::where('ID', $request->lastId);
        else 
            $account = Inactive_Account::where('ID', $request->lastId);      
        $account->update(['LAST_EMPL_NAME' => $request->emplName, 'LAST_EMPL_ADDR' => $request->emplAddr, 'LAST_EMPL_PHONE' => $request->emplPhone, 'LAST_EMPL_EMAIL' => $request->emplEmail, 'LAST_EMPL_FAX' => $request->emplFax]);
    }

    public function sendEmailVerification(Request $request){
        $mail = new RNNMailer(true);
        $mail->createHeader('Invalid Email');
        $mail->MessageDate = date("M,d,Y h:i:s A");
        $mail->Subject = "Invalid Email";
        $mail->Body = "This is the email trying to be sent " . $request->email;
        $mail->send();
    }

    //gets the account by the id 
    public function findAccount($accountId){
        $account = Active_Account::where('ID', $accountId)->first();
        $type = 'active';
        if ($account == null) {
            $account = Inactive_Account::where('ID', $accountId)->first();
            $type = 'inactive';
        }
        return ['type' => $type, 'account' => $account];
    }

    //assures user should have access to the account, (admin, directory, powerlead) will always have access
    public function checkMatchingCorporation($accountCorporation){
        switch (Auth::user()->role){
            case 'agent':
                $checkCorporation = Auth::user()->agent_link->corporation_id;
            break;
            case 'manager':
                $checkCorporation = Auth::user()->manager_link->corporation_id;
            break;
            case 'corporate_admin':
                $checkCorporation = Auth::user()->corporate_admin_link->corporation_id;
            break;
            default:
                return true;
            break;
        }
        if($checkCorporation == $accountCorporation)
            return true;
        else
            return false;
    }
}