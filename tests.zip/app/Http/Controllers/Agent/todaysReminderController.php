<?php

namespace App\Http\Controllers\Agent;

use Illuminate\Http\Request;
use Auth;
use App\Models\Active_Account;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use DateTime;
use Illuminate\Support\Facades\Cookie;

class todaysReminderController extends Controller
{
    public function allReminders(){
        $current = new DateTime('today');
        $tommorow = new DateTime('tomorrow');

        $corporationId = Auth::user()->agent_link->corporation_id;

        $today = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)->where('WORK_REMINDER', '>', $current)
        ->where('WORK_REMINDER', '<', $tommorow)->where('CORPORATION_ID', $corporationId)->get();

        $future = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)->where('WORK_REMINDER', '>',$tommorow)
        ->where('CORPORATION_ID', $corporationId)->get();

        $capcodes = Capcode::where('corporation_id', $corporationId)->get();

        return view('agents.pages.todaysReminders')->with('today', $today)->with('future', $future)->with('capcodes', $capcodes);
    }
}