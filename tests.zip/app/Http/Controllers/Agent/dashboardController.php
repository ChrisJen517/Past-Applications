<?php

namespace App\Http\Controllers\Agent;
use App\Http\Controllers\Controller;

class dashboardController extends Controller
{
    public function formRocky()
    {
        return view('/agents/formRocky');
    }

}
