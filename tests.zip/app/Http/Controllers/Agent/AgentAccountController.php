<?php

namespace App\Http\Controllers\Agent;

use App\Models\Active_Account;
use App\Models\Capcode;
use App\Models\Corporate_Settings;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use Auth;
use Illuminate\Http\Request;
use App\Traits\GetOrderArray;

class AgentAccountController extends Controller
{
    use GetOrderArray;

    public function showNewActiveAccounts()
    {
        if (Auth::user()->role == 'agent') {
            $show = Corporate_Settings::where('corporation_id', Auth::user()->agent_link->corporation_id)->select('show_client')->first();

            if ($show != null) {
                $show = $show->show_client;
            } else {
                $show = 0;
            }

        } else {
            $show = 1;
        }

        $orderArray = $this->getOrderArray(Auth::user()->agent_link->corporation_id, Auth::user()->agent_link->team_id);

        $firstPriority = $orderArray[0];
        $secondPriority = $orderArray[1];
        $thirdPriority = $orderArray[2];

        $MTDCount = $this->getMTDCount();

        //Grabs all new active account for this user.
        $newAccounts = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where('CORPORATION_ID', Auth::user()->agent_link->corporation_id)
            ->where('ON_HOLD', '!=', 1)
            ->when($firstPriority, function ($query, $firstPriority) {
                return $query->orderByRaw($firstPriority);
            })
            ->when($secondPriority, function ($query, $secondPriority) {
                return $query->orderByRaw($secondPriority);
            })
            ->when($thirdPriority, function ($query, $thirdPriority) {
                return $query->orderByRaw($thirdPriority);
            })
            ->where(function ($q) {$q->where('LAST_WORKED', "''")->orwhere('LAST_WORKED', null);})->get();

            //variable used to compare time page is opened for check redistribution button
            $page_open_time = date('Y-m-d H:i:s', time());
            
        return view('agents.pages.newActiveAccounts')->with('newAccounts', $newAccounts)
        ->with('show', $show)->with('MTDCount', $MTDCount)->with('page_open_time', $page_open_time);
    }

    public function showWorkedActiveAccounts()
    {
        if (Auth::user()->role == 'agent') {
            $show = Corporate_Settings::where('corporation_id', Auth::user()->agent_link->corporation_id)->select('show_client')->first();

            if ($show != null) {
                $show = $show->show_client;
            } else {
                $show = 0;
            }

        } else {
            $show = 1;
        }

        $orderArray = $this->getOrderArray(Auth::user()->agent_link->corporation_id, Auth::user()->agent_link->team_id);

        $firstPriority = $orderArray[0];
        $secondPriority = $orderArray[1];
        $thirdPriority = $orderArray[2];

        //check for capcodes pending approval and only show them in bottom table
        $capcodes = Capcode::where('corporation_id', Auth::user()->agent_link->corporation_id)->where('type', 'pending_approval')->get();
        $pending = [];
        foreach ($capcodes as $capcode) {
            $pending[] = $capcode->id;
        }

        $three_business_days = date('Y-m-d', strtotime('-3 weekdays'));

        //gets the accoutns that are currently ready to be worked
        $accounts = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where('CORPORATION_ID', Auth::user()->agent_link->corporation_id)
            ->whereRAW('((date(LAST_CALL) < curdate() or LAST_CALL IS NULL)
             and ((`LAST_FAX_EMAIL` IS NULL) or (DATE(`LAST_FAX_EMAIL`) <= DATE("'.$three_business_days.'")))
             and (date(last_worked) != curdate())
            )	
            and (CAPCODE IS NULL OR CAPCODE NOT IN ('.implode(', ', $pending).'))')
            ->where('ON_HOLD', '!=', 1)
            ->where('LAST_WORKED', '!=', '""')
            ->where('LAST_WORKED', '!=', null)
            ->with('active_capcode_link')
            ->when($firstPriority, function ($query, $firstPriority) {
                return $query->orderByRaw($firstPriority);
            })
            ->when($secondPriority, function ($query, $secondPriority) {
                return $query->orderByRaw($secondPriority);
            })
            ->when($thirdPriority, function ($query, $thirdPriority) {
                return $query->orderByRaw($thirdPriority);
            })
            ->get();

        //gets the accounts that have been worked today, have been faxed/emailed in the past 3 days, or called in the past 24 hours
        $workedAccounts = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where('CORPORATION_ID', Auth::user()->agent_link->corporation_id)
            ->whereRAW('(`LAST_CALL` IS NOT NULL AND DATE(`LAST_CALL` > SUBDATE(CURDATE(), 1))
                OR (`LAST_FAX_EMAIL` IS NOT NULL AND DATE(`LAST_FAX_EMAIL`) > DATE("'. $three_business_days .'"))
                OR (DATE(LAST_WORKED) = CURDATE()))')
            ->when($firstPriority, function ($query, $firstPriority) {
                return $query->orderByRaw($firstPriority);
            })
            ->when($secondPriority, function ($query, $secondPriority) {
                return $query->orderByRaw($secondPriority);
            })
            ->when($thirdPriority, function ($query, $thirdPriority) {
                return $query->orderByRaw($thirdPriority);
            })
            ->where('ON_HOLD', '!=', 1)
            ->where('LAST_WORKED', '!=', null)
            ->where('LAST_WORKED', '!=', '""')
            ->with('active_capcode_link')
            ->get();

        $MTDCount = $this->getMTDCount();

        //variable used to compare time page is opened for check redistribution button
        $page_open_time = date('Y-m-d H:i:s', time());


        return view('agents.pages.workedActiveAccounts')->with('newAccounts', $accounts)->with('show', $show)
        ->with('workedAccounts', $workedAccounts)->with('MTDCount', $MTDCount)->with('page_open_time', $page_open_time);
    }

    public function showAllActiveAccounts()
    {
        if (Auth::user()->role == 'agent') {
            $show = Corporate_Settings::where('corporation_id', Auth::user()->agent_link->corporation_id)->select('show_client')->first();

            if ($show != null) {
                $show = $show->show_client;
            } else {
                $show = 0;
            }

        } else {
            $show = 1;
        }

        $MTDCount = $this->getMTDCount();

        $orderArray = $this->getOrderArray(Auth::user()->agent_link->corporation_id, Auth::user()->agent_link->team_id);

        $firstPriority = $orderArray[0];
        $secondPriority = $orderArray[1];
        $thirdPriority = $orderArray[2];

        $capcodes = Capcode::where('corporation_id', Auth::user()->agent_link->corporation_id)->where('type', 'pending_approval')->get();
        $pending = [];
        foreach ($capcodes as $capcode) {
            $pending[] = $capcode->id;
        }

        //Grabs all active account for this user.
        $allAccounts = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where('CORPORATION_ID', Auth::user()->agent_link->corporation_id)
            ->when($firstPriority, function ($query, $firstPriority) {
                return $query->orderByRaw($firstPriority);
            })
            ->when($secondPriority, function ($query, $secondPriority) {
                return $query->orderByRaw($secondPriority);
            })
            ->when($thirdPriority, function ($query, $thirdPriority) {
                return $query->orderByRaw($thirdPriority);
            })
            ->when($pending, function ($q, $pending) {
                return $q->whereNotIn('CAPCODE', $pending)->orWhere('CAPCODE', NULL);
            })
            ->where('ACCT_AGENT', Auth::user()->agent_link->agent_id)->where('CORPORATION_ID', Auth::user()->agent_link->corporation_id)
            ->where('ON_HOLD', '!=', 1)->get();


            //variable used to compare time page is opened for check redistribution button
            $page_open_time = date('Y-m-d H:i:s', time());


        return view('agents.pages.allActiveAccounts')->with('newAccounts', $allAccounts)
        ->with('show', $show)->with('MTDCount', $MTDCount)->with('page_open_time', $page_open_time);
    }

    public function showClosed(Request $request)
    {
        if($request->changeDate == NULL){
            $startTime = date("Y-m-d");
            $endTime = date("Y-m-d", strtotime("+1 day"));
        } else { 
            if ($request->from == null) {
                $startTime = date("Y-m-d", strtotime("-1 week"));
            } else {
                $startTime = date('Y-m-d', strtotime($request->from));
            }

            if ($request->to == null) {
                $endTime = date("Y-m-d");
            } else {
                $endTime = date('Y-m-d', strtotime($request->to));
            }
        }

        $endTime = date("Y-m-d", strtotime($endTime . " +1 day"));

        if (Auth::user()->role == 'agent') {
            $show = Corporate_Settings::where('corporation_id', Auth::user()->agent_link->corporation_id)->select('show_client')->first();

            if ($show != null) {
                $show = $show->show_client;
            } else {
                $show = 0;
            }

        } else {
            $show = 1;
        }

        $verifiedCapcodes = Capcode::where('corporation_id', Auth::user()->agent_link->corporation_id)->where('type', 'verified')->get();

        $unverifiedCapcodes = Capcode::where('corporation_id', Auth::user()->agent_link->corporation_id)->where('type', '!=', 'verified')->get();

        foreach ($verifiedCapcodes as $capcode) {
            $verifiedCodes[] = $capcode->id;
        }

        $unverifiedCodes = [2210, 2209, 2208];
        foreach ($unverifiedCapcodes as $capcode) {
            $unverifiedCodes[] = $capcode->id;
        }

        $verifiedClosed = Inactive_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where("LAST_WORKED", ">", $startTime)
            ->where("LAST_WORKED", "<", $endTime)
            ->where('ON_HOLD', '!=', 1)
            ->with('inactive_capcode_link')
            ->whereIn('CAPCODE', $verifiedCodes)
            ->orderBy('last_worked', 'DESC')->get();

        $unverifiedClosed = Inactive_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where("LAST_WORKED", ">", $startTime)
            ->where("LAST_WORKED", "<", $endTime)
            ->where('ON_HOLD', '!=', 1)
            ->whereIn('CAPCODE', $unverifiedCodes)
            ->with('inactive_capcode_link')
            ->orderBy('last_worked', 'DESC')->get();

        $MTDCount = $this->getMTDCount();

        return view('agents.pages.inactiveAccounts')->with('verifiedClosed', $verifiedClosed)
            ->with('unverifiedClosed', $unverifiedClosed)
            ->with('verifiedCapcodes', $verifiedCapcodes)->with('unverifiedCapcodes', $unverifiedCapcodes)
            ->with('show', $show)
            ->with('MTDCount', $MTDCount);
    }

    public function showOverworkedAccounts(){
        $overworked = Capcode::select('id')->where('capcode', 2335)->where('corporation_id', Auth::user()->agent_link->corporation_id)->first();
        $overworked = $overworked->id ?? 2335;

        $show = Corporate_Settings::where('corporation_id', Auth::user()->agent_link->corporation_id)->select('show_client')->first();

        if ($show != null) {
            $show = $show->show_client;
        } else {
            $show = 0;
        }

        $overworkedAccounts = Inactive_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)
            ->where('ON_HOLD', '!=', 1)
            ->with('inactive_capcode_link')
            ->where('CAPCODE', $overworked)
            ->whereRaw('ACCT_DUE_DATE > now()')
            ->orderBy('last_worked', 'DESC')->get();

        $MTDCount = $this->getMTDCount();

        return view('agents.pages.overworkedAccounts')
            ->with('overworkedAccounts', $overworkedAccounts)
            ->with('show', $show)
            ->with('MTDCount', $MTDCount);
    }

    public function showActiveAccountsAfterClose()
    {
        if (Auth::user()->role == 'agent') {
            $show = Corporate_Settings::where('corporation_id', Auth::user()->agent_link->corporation_id)->select('show_client')->first();

            if ($show != null) {
                $show = $show->show_client;
            } else {
                $show = 0;
            }

        } else {
            $show = 1;
        }
        $MTDCount = $this->getMTDCount();
        $newAccounts = Active_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)->where('ON_HOLD', '!=', 1)->where(function ($q) {$q->where('LAST_WORKED', "")->orwhere('LAST_WORKED', null);})->get();

        return view('agents.pages.newActiveAccounts')->with('newAccounts', $newAccounts)->with('success', 'Account has been moved to close')->with('show', $show)->with('MTDCount', $MTDCount);
    }

    //gets the count of the agents work for the month
    public function getMTDCount()
    {
        $firstOfMonth = date('Y-m-d', strtotime('first day of this months'));

        $verifiedCapcodes = Capcode::select('id')->where('corporation_id', Auth::user()->agent_link->corporation_id)->where('type', 'verified')->get();
        foreach ($verifiedCapcodes as $capcode) {
            $verifiedCodes[] = $capcode->id;
        }
        if (empty($verifiedCodes)) {
            return 0;
        }

        $countOfVerifed = Inactive_Account::where('ACCT_AGENT', Auth::user()->agent_link->agent_id)->whereIN('CAPCODE', $verifiedCodes)->where('LAST_WORKED', '>=', $firstOfMonth)->count();
        return $countOfVerifed;
    }
}