<?php

namespace App\Http\Controllers\Agent;
use App\Http\Controllers\Controller;
use App\Models\Redistribution_Record;
use Auth;
use Illuminate\Http\Request;

class CheckRedistributionController extends Controller
{

    public function checkRedistributions(Request $request)
    {
        if($request->page_open_time == null){
            echo json_encode('true');
            return;
        }
            
        $corporation_id = Auth::user()->corporation_agent_link->corporation_id;
        $team_id = Auth::user()->agent_link->team_id;

        if(!empty(Redistribution_Record::where('corporation_id', $corporation_id)
        ->whereRAW('(team_id = '.$team_id.' OR team_id = 0)')
        ->where('created_at', '>', $request->page_open_time)
        ->orderBy('created_at', 'DESC')->first()))
        {
            echo json_encode('true');
        }
        else{
            echo json_encode('false');
        }
    }
}
