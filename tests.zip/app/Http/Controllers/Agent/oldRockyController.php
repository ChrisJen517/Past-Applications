<?php

namespace App\Http\Controllers\Agent;

use App\Models\Account_Source;
use App\Models\Active_Account;
use App\Models\Active_Account_Files;
use App\Models\Agent;
use App\Models\AWG7_Phone_Numbers;
use App\Models\Blocked_Company;
use App\Models\Capcode;
use App\Models\Corporate_Settings;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Capcode;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Work_History;
use App\Models\Fax_Queue;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Directory_Manager;
use App\RNNMailer;
use App\Models\Team;
use App\Models\Team_Distribution_Rules;
use App\Traits\HasAccess;
use App\Models\Verification_Requirements;
use App\Models\Verified_Hit;
use App\Models\web_crawler;
use App\Models\Worked_History;
use Auth;
use Carbon\Carbon;
use Config;
use DB;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use Schema;
use App\Traits\SetFaxEmail;
use App\Traits\GetOrderArray;
use Illuminate\Support\Facades\Log;

class oldRockyController extends Controller
{
    use GetOrderArray;
    use HasAccess;
    use SetFaxEmail;
    public function showRockyAccountUpdate(Request $request)
    {
        return $this->getRockyForm($request->accountId, $request->type, $request->timeZoneQueue);
    }

    public function getRockyForm($accountId, $type, $timeZoneQueue)
    {
        if (Auth::user()->role != 'directory_agent') {
            $checkAccess = $this->checkAccess($accountId);
            if ($checkAccess == false) {
                return back()->with('error', "Access Denied");
            }
        }
        $numbers = [];
        $faxes = [];
        $emails = [];
        //if sent an inactive account uses a diffrent table
        if ($type == 'inactive') {
            $account = Inactive_Account::where('ID', $accountId)->first();
            $type = 'inactive';
        } else if ($type == 'worked') {
            $account = Active_Account::where('ID', $accountId)->whereNotNull('LAST_WORKED')->where('LAST_WORKED', '!=', '')->first();
            $type = 'worked';
        } else {
            $account = Active_Account::where('ID', $accountId)->first();
            $type = 'active';
            if ($account == null) {
                $account = Inactive_Account::where('ID', $accountId)->first();
                $type = 'inactive';
            }
        }

        if ($account == null) {
            return back()->with('error', 'Account not found!');
        }

        if ((Auth::user()->role == 'agent') || (Auth::user()->role == 'manager') || (Auth::user()->role == 'corporate_admin')) {
            if (Auth::user()->role == 'agent') {
                // if($type == 'inactive')
                //     return back()->with('error', 'Account has already been closed.');
                $checkCorporation = Auth::user()->agent_link->corporation_id;
            } elseif (Auth::user()->role == 'manager') {
                $checkCorporation = Auth::user()->manager_link->corporation_id;
            } elseif (Auth::user()->role == 'corporate_admin') {
                $checkCorporation = Auth::user()->corporate_admin_link->corporation_id;
            }

            if ($account->CORPORATION_ID != $checkCorporation) {
                return back()->with('error', 'That account is not in your corporation');
            }

        }

        if (Auth::user()->role == 'agent') {
            $show = Corporate_Settings::where('corporation_id', $account->CORPORATION_ID)->select('show_client')->first();

            if ($show != null) {
                $show = $show->show_client;
            } else {
                $show = 0;
            }

        } else {
            $show = 1;
        }

        $requirments = Verification_Requirements::where('corporation_id', $account->CORPORATION_ID)->first();

        //if an agent works an account for the first time
        if ($type == 'active' || $type == 'worked') {
            if (Auth::user()->role == 'agent' && $account->ACCT_AGENT == Auth::user()->agent_link->agent_id) {
                $allAccountIds = $this->getAllAccessIds($account->ACCT_SSN, $account->CORPORATION_ID, $type);

                $allIds = [];
                foreach ($allAccountIds as $rule) {
                    $allIds[] = "'" . $rule . "'";
                }
                $allIds = implode(',', $allIds);

                if ($account->VERIFIED_HITS_ID) {
                    DB::select(DB::raw('UPDATE `active_accounts` SET `VERIFIED_HITS_ID` = ' . $account->VERIFIED_HITS_ID . ', `ACCT_AGENT` = ' . Auth::user()->agent_link->agent_id . ', `TEAM_ID` = ' . Auth::user()->agent_link->team_id . ' WHERE LAST_WORKED is NULL and ID IN (' . $allIds . ');'));
                } else {
                    DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = ' . Auth::user()->agent_link->agent_id . ', `TEAM_ID` = ' . Auth::user()->agent_link->team_id . ' WHERE  LAST_WORKED is NULL and ID IN (' . $allIds . ');'));
                }

            }
        }

        $numbers[] = preg_replace('/[^0-9]/', '', $account->EMPL_PHONE1_NMBR);
        $faxes[] = preg_replace('/[^0-9]/', '', $account->EMPL_FAX);
        $emails[] = $account->emails;
        $directory = [];
        $powerlead = [];

        //Check to see if Directory Lead exists and assign values if true
        if (!empty($account->DIRECTORY_LINK)) {
            if (!empty(Directory_Active_Account::find($account->DIRECTORY_LINK))) {
                $directory = Directory_Active_Account::find($account->DIRECTORY_LINK);
            } else {
                $directory = Directory_Inactive_Account::find($account->DIRECTORY_LINK);
            }
            if (!empty($directory)) {
                $numbers[] = preg_replace('/[^0-9]/', '', $directory->direct_phone);
                $numbers[] = preg_replace('/[^0-9]/', '', $directory->verification_phone);
                $faxes[] = preg_replace('/[^0-9]/', '', $directory->verification_fax);
                $emails[] = $directory->verification_email;
            }
        }

        //Check for multiple addresses associated with directory account, handle display in blade view
        $directoryRows = 0;
        $directoryAddresses = [];
        $directoryCities = [];
        $directoryStates = [];
        $directoryZips = [];
        if (!empty($directory->address) || !empty($directory->city) || !empty($directory->state) || !empty($directory->zip)) {
            $directoryRows = 1;
            $directoryAddresses = explode('|', $directory->address);
            $directoryCities = explode('|', $directory->city);
            $directoryStates = explode('|', $directory->state);
            $directoryZips = explode('|', $directory->zip);
            if (count($directoryAddresses) > $directoryRows) {
                $directoryRows = count($directoryAddresses);
            }
            if (count($directoryCities) > $directoryRows) {
                $directoryRows = count($directoryCities);
            }
            if (count($directoryStates) > $directoryRows) {
                $directoryRows = count($directoryStates);
            }
            if (count($directoryZips) > $directoryRows) {
                $directoryRows = count($directoryZips);
            }
        }

        //Check to see if Powerlead exists and assign values if true
        if (!empty($account->POWERLEAD_ID)) {
            $powerlead = Powerlead_Accounts::find($account->POWERLEAD_ID);
            if($powerlead != null){
                $numbers[] = preg_replace('/[^0-9]/', '', $powerlead->local_phone);
                $numbers[] = preg_replace('/[^0-9]/', '', $powerlead->main_phone);
                $faxes[] = preg_replace('/[^0-9]/', '', $powerlead->fax);
                $emails[] = $powerlead->email;
            }
        }

        $blockedNumbers = [];
        $blockedFaxes = [];
        $blockedEmails = [];
        $web_crawler = [];
        if (!empty($account->WEB_CRAWLER_ID)) {
            $web_crawler = Web_Crawler::find($account->WEB_CRAWLER_ID);
            $numbers[] = preg_replace('/[^0-9]/', '', $web_crawler->company_phone);
            $emails[] = $web_crawler->company_email;
        }
        $blockedCompanies = [];
        $blockedCompanies = Blocked_Company::where('corporation_id', $account->CORPORATION_ID)->get();
        //checked for blocked contacts and add them to lists to be handled in blade view
        foreach ($blockedCompanies as $company) {
            if (!empty($company->phone_number) && !empty($company->ext) && in_array(preg_replace('/[^0-9]/', '', $company->phone_number . $company->ext), $numbers)) {
                $blockedNumbers[] = preg_replace('/[^0-9]/', '', $company->phone_number . $company->ext);
            } else if (!empty($company->phone_number) && in_array(preg_replace('/[^0-9]/', '', $company->phone_number), $numbers)) {
                $blockedNumbers[] = preg_replace('/[^0-9]/', '', $company->phone_number);
            }
            if (!empty($company->fax_number) && in_array(preg_replace('/[^0-9]/', '', $company->fax_number), $faxes)) {
                $blockedFaxes[] = preg_replace('/[^0-9]/', '', $company->fax_number);
            }
            if (!empty($company->email) && in_array($company->email, $emails)) {
                $blockedEmails[] = $company->email;
            }
        }

        //adds in the needed capcodes/ phone numbers for AWG7 type accounts
        if ($account->ACCT_TYPE != "AWG7") {
            //check if agent has access to the capcode
            if (Auth::user()->role == 'agent') {
                $capcodes = Capcode::where('corporation_id', $account->CORPORATION_ID)->where('agent_access', 1)->where('is_archived', '=', '0')->orderBy('capcode', 'asc')->get();
            } else {
                $capcodes = Capcode::where('corporation_id', $account->CORPORATION_ID)->whereNotIn('capcode', ['2208', '2209', '2210'])->where('is_archived', '=', '0')->orderBy('capcode', 'asc')->get();
            }
            $phoneNumbers = [];
        } else {
            $capcodes = Capcode::where('corporation_id', $account->CORPORATION_ID)->where('capcode_type', "AWG7")->where('is_archived', '=', '0')->orderBy('capcode', 'asc')->get();
            $phoneNumbers = AWG7_Phone_Numbers::where('account_id', $account->ID)->get();
        }

        $allAccountIds = $this->getAllAccessIds($account->ACCT_SSN, $account->CORPORATION_ID, $type);

        if ($type == 'inactive') {
            $ssn = Inactive_Account::SELECT('ID', 'POESCORE', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->where('ACCT_AGENT', $account->ACCT_AGENT)->get();
        } else {
            $ssn = Active_Account::SELECT('ID', 'POESCORE', 'ACCESS_RULES', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->where('ACCT_AGENT', $account->ACCT_AGENT)->get();
        }

        if (count($ssn) == 1) {
            if (Auth::user()->role == 'corporate_admin' || Auth::user()->role == 'manager' || Auth::user()->role == 'admin') {
                $history = Worked_History::where('active_account_id', $accountId)
                    ->with('capcode_link')
                    ->orderByDesc("created_at", "desc")
                    ->get();
            } else {
                $history = Worked_History::where('active_account_id', $accountId)
                    ->where('capcode', '!=', -1)
                    ->with('capcode_link')
                    ->orderByDesc("created_at", "desc")
                    ->get();
            }

        } else {
            $ids = [];
            foreach ($ssn as $id) {
                $ids[] = $id->ID;
            }
            if (Auth::user()->role == 'corporate_admin' || Auth::user()->role == 'manager' || Auth::user()->role == 'admin') {
                $history = Worked_History::whereIn('active_account_id', $ids)
                    ->with('capcode_link')
                    ->orderByDesc("created_at", "desc")
                    ->get();
            } else {
                $history = Worked_History::whereIn('active_account_id', $ids)
                    ->where('capcode', '!=', -1)
                    ->with('capcode_link')
                    ->orderByDesc("created_at", "desc")
                    ->get();
            }

        }

        $count = $account->WORK_ATTEMPTS;
        if ($count == null || $count == '') {
            $count = 0;
        }

        if ($account->ACCT_AGENT > 0) {
            $team_id = Agent::select('team_id')->where('agent_id', $account->ACCT_AGENT)->first();
            if ($team_id != null) {
                $max = Team::select('max_attempts')->where('team_id', $team_id->team_id)->first()->max_attempts;
            } else {
                $max = 5;
            }

        } else {
            $max = 5;
        }
        $web_crawler = [];
        if (!empty($account->WEB_CRAWLER_ID)) {
            $web_crawler = Web_Crawler::find($account->WEB_CRAWLER_ID);
        }
        $verified_hit = [];
        $active_account_files = [];
        if (!empty($account->VERIFIED_HITS_ID)) {
            $verified_hit = Verified_Hit::find($account->VERIFIED_HITS_ID);
            $active_account_files = Active_Account_Files::where('verified_hits_id', $account->VERIFIED_HITS_ID)->get();
        }

        if (strlen($account->ACCT_SSN) < 9) {
            $account->ACCT_SSN = str_pad($account->ACCT_SSN, 9, '0', STR_PAD_LEFT);
        }

        if(in_array(Auth::user()->role, ['admin', 'manager', 'corporate_admin'])){
            $agents = Agent::where('corporation_id', $account->CORPORATION_ID)->with('user_link')->get();
        }
        else{
            $agents = [];
        }

        // dd($account);
        return view('agents.pages.formRocky')->with('account', $account)->with('capcodes', $capcodes)
            ->with('directory', $directory)->with('powerlead', $powerlead)->with('history', $history)->with('ssns', $ssn)->with('account_ssn', $account->ID)
            ->with('account_id', $accountId)->with('count', $count)->with('type', $type)->with('max_attempts', $max)
            ->with('directoryRows', $directoryRows)->with('directoryAddresses', $directoryAddresses)->with('phoneNumbers', $phoneNumbers)->with('web_crawler', $web_crawler)
            ->with('directoryCities', $directoryCities)->with('directoryStates', $directoryStates)->with('directoryZips', $directoryZips)
            ->with('blocked_numbers', $blockedNumbers)->with('blocked_emails', $blockedEmails)->with('blocked_faxes', $blockedFaxes)->with('blockedCompanies', $blockedCompanies)
            ->with('show', $show)->with('verified_hit', $verified_hit)->with('active_account_files', $active_account_files)->with('requirments', $requirments)
            ->with('minutes', '00')->with('seconds', '00')->with('agents', $agents)->with('timeZoneQueue', $timeZoneQueue);
    }

    public function addHistory(Request $request)
    {
        $history = new Worked_History;

        $history->active_account_id = $request->account_id;
        $history->user_role = Auth::user()->role;
        if (Auth::user()->role == 'agent') {
            $history->agent_id = Auth::user()->agent_link->agent_id;
        } else if (Auth::user()->role == 'manager') {
            $history->agent_id = Auth::user()->manager_link->manager_id;
        } else if (Auth::user()->role == 'corporate_admin') {
            $history->agent_id = Auth::user()->corporate_admin_link->corporate_admin_id;
        } else if (Auth::user()->role == 'admin') {
            $history->agent_id = Auth::user()->user_id;
        } else if (Auth::user()->role == 'directory_agent') {
            $history->agent_id = Auth::user()->directory_agent_link->directory_agent_id;
        }
        $history->time_spent = $request->seconds_spent;
        $history->capcode = $request->verified_capcode;
        $history->notes = strip_tags($request->note);
        if (!empty($request->time)) {
            $history->scheduled_call = $request->time;
        }
        $history->save();

        if ($request->type == 'inactive') {
            $type = 'inactive';
            $account = Inactive_Account::find($request->account_id);
        } else if ($request->closed) {
            if ($request->type == 'worked') {
                $type = 'worked';
            } else {
                $type = 'active';
            }

            $account = Inactive_Account::find($request->account_id);
        } else if ($request->type == 'worked') {
            $type = 'worked';
            $account = Active_Account::find($request->account_id);
        } else {
            $type = 'active';
            $account = Active_Account::find($request->account_id);
        }

        $total = $account->TOTAL_TIME_SPENT + $request->seconds_spent;
        $account->TOTAL_TIME_SPENT = $total;
        $account->save();
        $current_capcode = Capcode::find($account->CAPCODE);
        if ($request->overWorked == true && $current_capcode->type == 'inconclusive') {
            $overHistory = new Worked_History;
            $overHistory->user_role = "Auto generation";
            $overHistory->active_account_id = $request->account_id;
            $overHistory->agent_id = 0;

            $overworked = Capcode::where('capcode', 2335)->where('corporation_id', $account->CORPORATION_ID)->first();
            $overHistory->capcode = $overworked->id ?? 2335;

            $overHistory->created_at = date('Y-m-d H:i:s', strtotime($history->created_at . ' + 1 second'));
            $overHistory->notes = "Account hit max attempts, was last worked by " . Auth::user()->role . ": " . $history->agent_id . ".";
            $overHistory->save();
        }

        $capcode = Capcode::where('id', $request->verified_capcode)->first()->capcode;
        $count = $account->WORK_ATTEMPTS;
        //check if 'save and open next' button clicked
        if ($request->open_next == 1) {
            return $this->openNext($history->active_account_id, $type, $request->timeZoneQueue);
        }

        if ($request->closed) {
            $historyArray = array(
                'agent_id' => $history->agent_id,
                'date' => $history->updated_at,
                'capcode' => $capcode,
                'notes' => $history->notes,
                'time' => $history->scheduled_call,
                'closed' => $request->closed,
                'count' => $count,
            );
        } else {
            if ($request->verified_file) {
                $verified_file = Active_Account_Files::where('verified_hits_id', $account->VERIFIED_HITS_ID)->latest()->first();
                $historyArray = array(
                    'agent_id' => $history->agent_id,
                    'date' => $history->updated_at,
                    'capcode' => $capcode,
                    'notes' => $history->notes,
                    'time' => $history->scheduled_call,
                    'filename' => $verified_file->name,
                    'filepath' => $verified_file->file_path,
                    'fileid' => $verified_file->id,
                    'count' => $count,

                );
            } else {
                $historyArray = array(
                    'agent_id' => $history->agent_id,
                    'date' => $history->updated_at,
                    'capcode' => $capcode,
                    'notes' => $history->notes,
                    'time' => $history->scheduled_call,
                    'count' => $count,

                );
            }
        }
        if ($request->admin) {
            $historyArray[$request->admin] = $request->admin;
        }
        echo json_encode($historyArray);
    }

    public function openNext($account_id, $type, $timeZone)
    {
        $agent_id = Auth::user()->agent_link->agent_id;
        $corporation_id = Auth::user()->agent_link->corporation_id;

        $team_id = Agent::select('team_id')->where('agent_id', $agent_id)->first();
        if (Team_Distribution_Rules::where('team_id', $team_id->team_id)->exists()) {
            $orderArray = $this->getOrderArray($corporation_id, $team_id->team_id);
            $firstPriority = $orderArray[0];
            $secondPriority = $orderArray[1];
            $thirdPriority = $orderArray[2];

            //check for capcodes pending approval and only show them in bottom table
            $capcodes = Capcode::where('corporation_id', Auth::user()->agent_link->corporation_id)->where('type', 'pending_approval')->get();
            $pending = [];
            foreach ($capcodes as $capcode) {
                $pending[] = $capcode->id;
            }

            //variable to compare exact time against
            $now = Carbon::now()->toDateTimeString();

            $three_business_days = date('Y-m-d', strtotime('-3 weekdays'));

            //check if work reminder exists and is past due
            if (!empty(Active_Account::where('ACCT_AGENT', $agent_id)->where('ID', '!=', $account_id)->whereNotNull('WORK_REMINDER')->where('WORK_REMINDER', '!=', '')->where('WORK_REMINDER', '<', $now)->whereNotIn('CAPCODE', $pending)->orderBy('WORK_REMINDER', 'ASC')->first())) {
                $account = Active_Account::where('ACCT_AGENT', $agent_id)->where('ID', '!=', $account_id)->whereNotNull('WORK_REMINDER')->where('WORK_REMINDER', '!=', '')->where('WORK_REMINDER', '<', $now)->whereNotIn('CAPCODE', $pending)->orderBy('WORK_REMINDER', 'ASC')->first();
                $account->WORK_REMINDER = null;
                $account->save();
            } else {
                //or choose the next account in the queue
                $account = Active_Account::select('ID')
                    ->where('ACCT_AGENT', $agent_id)
                    ->where('ID', '!=', $account_id)
                    ->when($pending, function ($query, $pending) {
                        $pending = implode(',', $pending);
                        return $query->whereRAW('(CAPCODE not in ('.$pending.') or CAPCODE IS NULL)');
                    })
                    ->when($timeZone, function ($query, $timeZone) {
                        return $query->where('TIME_ZONE',$timeZone);
                    })
                    ->when($firstPriority, function ($query, $firstPriority) {
                        return $query->orderByRaw($firstPriority);
                    })
                    ->when($secondPriority, function ($query, $secondPriority) {
                        return $query->orderByRaw($secondPriority);
                    })
                    ->when($thirdPriority, function ($query, $thirdPriority) {
                        return $query->orderByRaw($thirdPriority);
                    })
                    ->where(function($query) use ($type, $three_business_days){
                        //grabs either the worked or unworked based on queue
                        if($type == "worked"){
                            return $query->whereRAW('(date(LAST_CALL) < CURDATE() OR LAST_CALL IS NULL)')
                            ->whereRAW('(date(LAST_FAX_EMAIL) <= ' . $three_business_days . ' OR LAST_FAX_EMAIL IS NULL)')
                            ->whereRAW('date(LAST_WORKED) != CURDATE()');
                        }
                        else
                            return $query->whereRAW('(LAST_WORKED is NULL or LAST_WORKED = "")');
                    })
                    ->first();
            }

            if (empty($account)) {
                if($timeZone == null || $timeZone == '')
                    $timeZone = "All";
                if($type == '' || $type == null)
                    $type = "Unworked";
                $message = 'No more accounts of type: ' . $type . ' at timezone: '.$timeZone.' available to work at this time';
                return redirect('/agent/newActiveAccounts')->with('message', $message);
            }
            return $this->getRockyForm($account->ID, $type, $timeZone);
        }
    }

    public function incrementHistory(Request $request)
    {
        $history = new Worked_History();
        if (Auth::user()->role == 'agent') {
            $history->agent_id = Auth::user()->agent_link->agent_id;
        } else if (Auth::user()->role == 'manager') {
            $history->agent_id = Auth::user()->manager_link->manager_id;
        } else if (Auth::user()->role == 'corporate_admin') {
            $history->agent_id = Auth::user()->corporate_admin_link->corporate_admin_id;
        } else if (Auth::user()->role == 'admin') {
            $history->agent_id = Auth::user()->user_id;
        }

        //get correct account
        if (!empty(Active_Account::find($request->id))) {
            $account = Active_Account::find($request->id);
            $active = 1;
        } else if (!empty(Inactive_Account::find($request->id))) {
            $account = Inactive_Account::find($request->id);
            $active = 0;
        }

        $history->user_role = Auth::user()->role;
        $history->active_account_id = $request->id;
        $history->notes = strip_tags($request->note);

        $corporation_id = $account->CORPORATION_ID;

        $autos = Capcode::whereIn('capcode', [2210, 2209, 2208])->where('corporation_id', $corporation_id)->get();

        if ($request->phone) {

            $history->capcode = $autos->where('capcode', 2210)->first()->id;

            $account->LAST_CALL = Carbon::now();
            $account->save();
        } else if ($request->fax) {
            //makes sure that company name was filled out
            if ($request->company_name == '') {
                echo json_encode([]);
                return;
            }

            $this->setFaxHistory($account, $request->fax, $request->company_name, $request->fullSSN, $active);
            $history->capcode = $autos->where('capcode', 2209)->first()->id;

            $account->LAST_FAX_EMAIL = Carbon::now();
            $account->save();
        } else if ($request->email) {

            $history->capcode = $autos->where('capcode', 2208)->first()->id;

            $account->LAST_FAX_EMAIL = Carbon::now();
            $account->save();

        }

        $history->save();

        if ($request->type == 'inactive') {
            $account->capcode = $history->capcode;
            $account->last_worked = Carbon::now()->toDateTimeString();
            $account->save();
        } else {

            $account->capcode = $history->capcode;
            if (($account->POWERLEAD_CAPCODE == 1) || ($account->POWERLEAD_CAPCODE == 2) || ($account->POWERLEAD_CAPCODE == 3)) {
                $account->POWERLEAD_CAPCODE = 7;
            }
            $account->last_worked = Carbon::now()->toDateTimeString();
            $account->save();

            $powerAccount = Powerlead_Accounts::where('active_account_id', $account->ID)->first();
            if ($powerAccount != null) {
                if ($powerAccount->verified == null) {
                    $powerAccount->verified = 0;
                    $powerAccount->save();
                }
            }

        }

        $capcode = Capcode::where('id', $history->capcode)->first()->capcode;

        $historyArray = array(
            'active_account_id' => $history->active_account_id,
            'agent_id' => $history->agent_id,
            'date' => $history->updated_at,
            'capcode' => $capcode,
            'notes' => $history->notes,
            'time' => $history->scheduled_call,
        );
        if (Auth::user()->role != 'agent') {
            $historyArray['admin'] = true;
        }

        echo json_encode($historyArray);
    }

    //increases the work attempts if the user leaves the page without saving
    public function increaseWorkAttempts(Request $request)
    {
        if (Auth::user()->role != 'agent') {
            return;
        }

        //get correct account
        $type = "";
        if (!empty(Active_Account::find($request->account_id))) {
            $account = Active_Account::find($request->account_id);
            $type = "active";
        } else if (!empty(Inactive_Account::find($request->account_id))) {
            $account = Inactive_Account::find($request->account_id);
            $type = "inactive";
        } else {
            return;
        }

        $account->LAST_WORKED = date('Y-m-d H:i:s');
        $account->WORK_ATTEMPTS++;
        $account->save();

        $reached_max_attempts = $this->checkTotalAttempts($request);
        $current_capcode = Capcode::find($account->CAPCODE);

        // Account is overworked only if it's at max attempts and has an inconclusive capcode and it is active
        if ($reached_max_attempts && $current_capcode->type == 'inconclusive' && $type != 'inactive')
         {
            //sets the capcode to overworked
            $overworked = Capcode::where('capcode', 2335)->where('corporation_id', $account->CORPORATION_ID)->first();
            if ($overworked != null) {
                $account->CAPCODE = $overworked->id;
                $request->verified_capcode = $overworked->id;
                $account->save();
            }

            $overHistory = new Worked_History;
            $overHistory->user_role = "Auto generation";
            $overHistory->active_account_id = $account->ID;
            $overHistory->agent_id = 0;
            if ($overworked != null) {
                $overHistory->capcode = $overworked->id;
            } else {
                $overHistory->capcode = 2335;
            }

            $overHistory->created_at = date('Y-m-d H:i:s');
            $overHistory->notes = "Account hit max attempts, was last worked by " . Auth::user()->role . ": " . Auth::user()->agent_link->agent_id . ".";
            $overHistory->save();

            //add a parameter to tell clientside to close account
            $request->request->add(['closed' => 'closed']);
            $request->request->add(['overWorked' => true]);

            //add a parameter to tell clientside if admin account
            if (Auth::user()->role != 'agent') {
                $request->request->add(['admin' => 'admin']);
            }

            $this->inactivateAccount($request);

            $closed = 1;
            //adds to all SSNs if there are multiple, called here since all routes go here
            $this->updateAllSSN($request, $account, $closed);
        }
        return;
    }

    public function updateAccount(Request $request)
    {
        $this->validate($request, [
            'empl_name_verified' => 'max:90',
            'empl_ph_nmbr_verified' => 'max:90',
            'empl_city_verified' => 'max:90',
            'empl_zip_verified' => 'max:90',
            'empl_title_verified' => 'max:90',
            'empl_fax_verified' => 'max:90',
            'empl_email_verified' => 'max:90',
            'empl_verification_mailing_address_verified' => 'max:90',
            'empl_contact_verified' => 'max:90',
            'empl_contact_title_verified' => 'max:90',
            'future_third_party' => 'max:90',
            'future_phone' => 'max:90',
            'future_fax' => 'max:90',
            'future_email' => 'max:90',
            'future_auto_phone' => 'max:90',
        ]);

        $capcode = Capcode::where('id', $request->verified_capcode)->where('corporation_id', $request->corporation_id)->first();
        $capcode_type = $capcode->type;

        $account = Active_Account::find($request->account_id);

        if ($account == null) {
            $request->type = 'inactive';
            $account = Inactive_Account::find($request->account_id);
        }

        //if admin choses to change the agent
        if($request->agent_selector != null){
            if($request->agent_selector == "remove")
                $account->ACCT_AGENT = null;
            else
                $account->ACCT_AGENT = $request->agent_selector;
        }

        if ($capcode_type == 'verified') {
            if (!$this->filledRequired($request)) {
                $failed['failed'] = true;
                echo json_encode($failed);
                return;
            }

            $this->addVerifiedHit($request, $account->VERIFIED_HITS_ID, $capcode_type);
        }

        if (!empty($account->DIRECTORY_LINK)) {
            $this->updateDirectoryAccount($request);
        } else {
            if (in_array($capcode->capcode, [1103, 1104, 1111, 1112])) {
                $name = $account->EMPL_NAME;
                $empmatchname = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $name);
                $empmatchname = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));

                // Directory account w/ name match exists
                if (!empty($checkNameMatch = Directory_Active_Account::where('name_match', $empmatchname)->first())) {
                    $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
                } else if (!empty($checkNameMatch = Directory_Inactive_Account::where('name_match', $empmatchname)->first())) {
                    $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
                } else {
                    $directoryAccount = new Directory_Active_Account();
                    $directoryAccount->live_flag = 0;
                    $directoryAccount->fresh_flag = 1;
                    $directoryAccount->employer_name = $name;
                    $directoryAccount->name_match = $empmatchname;
                    $directoryAccount->address = $account->EMPL_ADDR1;
                    $directoryAccount->city = $account->EMPL_CITY;
                    $directoryAccount->state = $account->EMPL_ST;
                    $directoryAccount->zip = $account->EMPL_ZIP;
                    $directoryAccount->direct_phone = $account->EMPL_PHONE1_NMBR;
                    $directoryAccount->save();

                    $account->DIRECTORY_LINK = $directoryAccount->directory_account_id;
                }
            }
        }

        //add a parameter to tell clientside if admin account
        if (Auth::user()->role != 'agent') {
            $request->request->add(['admin' => 'admin']);
        }

        $verified_hit = $this->addVerifiedHit($request, $account->VERIFIED_HITS_ID, $capcode_type);

        $account->VERIFIED_HITS_ID = $verified_hit->id;
        $verified_id = $verified_hit->id;
        if ($request->verified_file) {
            $date = date('F_j_Y_h-i-s_A');
            $filePath = storage_path('app/public/verified_files/' . $request->corporation_id . '/' . $verified_hit->id);

            if (!empty($request->file('verified_file'))) {
                $verified_file = $request->file('verified_file')->getClientOriginalName();
            }

            $filename = pathinfo($verified_file, PATHINFO_FILENAME);
            $extension = pathinfo($verified_file, PATHINFO_EXTENSION);

            $request->file('verified_file')->move($filePath, $filename . '_' . $date . '.' . $extension);
            $file_path = 'verified_files/' . $request->corporation_id . '/' . $verified_hit->id . '/' . $filename . '_' . $date . '.' . $extension;

            $active_account_file = new Active_Account_Files;
            $active_account_file->name = $verified_file;
            $active_account_file->file_path = $file_path;
            $active_account_file->user_id = Auth::user()->user_id;
            $active_account_file->verified_hits_id = $verified_hit->id;
            $active_account_file->save();
        }

        if ($request->is_attempt == 1 && Auth::user()->role == 'agent') {
            if (empty($account->WORK_ATTEMPTS)) {
                $account->WORK_ATTEMPTS = 1;
            } else {
                $account->WORK_ATTEMPTS += 1;
            }
        }
        $account->LAST_WORKED = Carbon::now()->toDateTimeString();
        if (!empty($request->time)) {
            $account->WORK_REMINDER = $request->time;
        }
        if (($account->POWERLEAD_CAPCODE == 1) || ($account->POWERLEAD_CAPCODE == 2) || ($account->POWERLEAD_CAPCODE == 3)) {
            $account->POWERLEAD_CAPCODE = 7;
        }

        $powerAccount = Powerlead_Accounts::where('active_account_id', $account->ID)->first();
        if ($powerAccount != null) {
            if ($powerAccount->verified == null) {
                $powerAccount->verified = 0;
                $powerAccount->save();
            }
        }

        if ($request->verified_capcode) {
            $account->CAPCODE = $request->verified_capcode;
        }

        $account->save();

        if (Auth::user()->role != 'agent') {
            $reached_max_attempts = false;
        } else {
            $reached_max_attempts = $this->checkTotalAttempts($request);
        }

        if (($capcode_type == 'verified' || $capcode_type == 'unverified') && $request->type != 'inactive') {
            //add a parameter to tell clientside to close account
            $request->request->add(['closed' => 'closed']);

            //add a parameter to tell clientside if admin account
            if (Auth::user()->role != 'agent') {
                $request->request->add(['admin' => 'admin']);
            }

            $this->inactivateAccount($request);

            $closed = 1;
        } elseif ($reached_max_attempts == true && $request->is_attempt == 1 && $request->type != 'inactive' && $capcode_type == 'inconclusive') {
            //sets the capcode to overworked
            $overworked = Capcode::where('capcode', 2335)->where('corporation_id', $account->CORPORATION_ID)->first();
            if ($overworked != null) {
                $account->CAPCODE = $overworked->id;
                $account->save();
            }

            //add a parameter to tell clientside to close account
            $request->request->add(['closed' => 'closed']);
            $request->request->add(['overWorked' => true]);

            //add a parameter to tell clientside if admin account
            if (Auth::user()->role != 'agent') {
                $request->request->add(['admin' => 'admin']);
            }

            $this->inactivateAccount($request);

            $closed = 1;
        } elseif ($request->type == 'inactive') {
            $closed = 2;
        } else {
            $closed = 0;
        }

        //adds to all SSNs if there are multiple, called here since all routes go here
        $this->updateAllSSN($request, $account, $closed);

        if ($request->open_next == 1) {

            return $this->addHistory($request);
        }
        $this->addHistory($request);

    }

    public function checkTotalAttempts($request)
    {
        $reached_max_attempts = false;

        if ($request->type == 'inactive') {
            $account = Inactive_Account::where('ID', $request->account_id)->first();
        } else if ($request->type == 'worked') {
            $account = Active_Account::where('ID', $request->account_id)->whereNotNull('LAST_WORKED')->where('LAST_WORKED', '!=', '')->first();
        } else {
            $account = Active_Account::where('ID', $request->account_id)->first();
            if ($account == null) {
                $account = Inactive_Account::where('ID', $request->account_id)->first();
                $request->type = 'inactive';
            }
        }

        $allAccountIds = $this->getAllAccessIds($account->ACCT_SSN, $account->CORPORATION_ID, $request->type);

        if ($request->type == 'inactive') {
            $ssns = Inactive_Account::SELECT('ID', 'POESCORE', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->get();
        } else {
            $ssns = Active_Account::SELECT('ID', 'POESCORE', 'ACCESS_RULES', 'WORK_ATTEMPTS')->whereIn('ID', $allAccountIds)->get();
        }

        $attemptCounter = 0;
        $ssnCounter = 0;

        foreach ($ssns as $ssn) {
            if ($ssn->WORK_ATTEMPTS >= $request->max_attempts_total) {
                $attemptCounter++;
            }
            $ssnCounter++;
        }

        if ($attemptCounter >= $ssnCounter) {
            $reached_max_attempts = true;
        }

        return $reached_max_attempts;
    }

    public function inactivateAccount(Request $request)
    {
        if ($request->max_attempt_close) {
            $active = Active_Account::find($request->inactivate_id);
            if (!empty($active->POWERLEAD_CAPCODE)) {
                if (($active->POWERLEAD_CAPCODE == 1) || ($active->POWERLEAD_CAPCODE == 2) || ($active->POWERLEAD_CAPCODE == 3)) {
                    $active->POWERLEAD_CAPCODE = 7;
                    $active->save();
                }
                $powerAccount = Powerlead_Accounts::where('active_account_id', $active->ID)->first();
                if ($powerAccount != null) {
                    if ($powerAccount->verified == null) {
                        $powerAccount->verified = 0;
                        $powerAccount->save();
                    }
                }
            }

            $inactive = new Inactive_Account;
            $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts');
            for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
                $item = strval($active_accounts_mapping_columns[$i]);
                if ($item != 'CREATED_AT' && $item != 'UPDATED_AT') {
                    $inactive->$item = $active->$item;
                }
            }

            if ($inactive->DIRECTORY_FLAG == null) {
                $inactive->DIRECTORY_FLAG = 0;
            }

            $inactive->save();
            $active->delete();

            return redirect('/agent/newActiveAccounts')->with('message', 'Account has been moved to closed');
        } else {
            $active = Active_Account::find($request->account_id);

            if (($active->POWERLEAD_CAPCODE == 1) || ($active->POWERLEAD_CAPCODE == 2) || ($active->POWERLEAD_CAPCODE == 3)) {
                $active->POWERLEAD_CAPCODE = 7;
                $active->save();

                $powerAccount = Powerlead_Accounts::where('active_account_id', $active->ID)->first();
                if ($powerAccount != null) {
                    if ($powerAccount->verified == null) {
                        $powerAccount->verified = 0;
                        $powerAccount->save();
                    }
                }
            }

            $inactive = new Inactive_Account;
            $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts');
            for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
                $item = strval($active_accounts_mapping_columns[$i]);
                if ($item != 'CREATED_AT' && $item != 'UPDATED_AT') {
                    $inactive->$item = $active->$item;
                }
            }

            if ($inactive->DIRECTORY_FLAG == null) {
                $inactive->DIRECTORY_FLAG = 0;
            }

            $inactive->save();
            $active->delete();
        }
    }

    public function updateDirectoryAccount(Request $request)
    {
        $hasFutureVerification = 'false';
        $futureCapcode = Directory_Capcode::where('capcode', 1119)->first()->capcode_id;

        // ! These don't exist anymore?
        if (!empty($request->future_verification_third_party) || !empty($request->future_verification_phone) || !empty($request->future_verification_email) || !empty($request->future_verification_fax) || !empty($request->future_verification_auto_phone)) {
            $hasFutureVerification = 'true';
        }
        //If future verification is updated in Directory Lead form, update capcode and assign new agent
        if ($hasFutureVerification == 'true') {
            $history = new Directory_Work_History;
            $history->directory_account_id = $request->directory_account_id;
            $history->capcode = $futureCapcode;
            $history->verification_notes = Directory_Capcode::where('capcode', 1119)->first()->description;
            $history->worker_role = Auth::user()->role;
            //update account to credit agent, not if admin
            if (Auth::user()->role == 'agent') {
                $history->worker_id = Agent::where('user_id', Auth::user()->user_id)->first()->agent_id;
            } else if (Auth::user()->role == 'manager') {
                $history->worker_id = Auth::user()->manager_link->manager_id;
            } else if (Auth::user()->role == 'corporate_admin') {
                $history->worker_id = Auth::user()->corporate_admin_link->corporate_admin_id;
            } else if (Auth::user()->role == 'admin') {
                $history->worker_id = Auth::user()->user_id;
            } else if (Auth::user()->role == 'powerlead_directory_manager') {
                $history->worker_id = Powerlead_Directory_Manager::where('user_id', Auth::user()->user_id)->first()->powerlead_directory_id;
            } else if (Auth::user()->role == 'directory_agent') {
                $history->worker_id = Auth::user()->directory_agent_link->directory_agent_id;
            }

            $user = Auth::user();
            Log::debug('User ID: ' . $user->user_id . ' (' . $user->first_name . ' ' . $user->last_name . ') has saved a coe account and updated the corresponding directory account.');
            $history->save();
        }

        //If inactive directory account and future verification not set, update and re-assign agent
        if (!empty(Directory_Inactive_Account::where('directory_account_id', $request->directory_account_id)->first())) {
            $account = Directory_Inactive_Account::where('directory_account_id', $request->directory_account_id)->first();
            if (empty($account->future_verification_third_party) && empty($account->future_verification_email) && empty($account->future_verification_phone) && empty($account->future_verification_fax) && empty($account->future_verification_auto_phone)) {
                if ($hasFutureVerification == 'true') {
                    $account->future_verification_third_party = $request->future_verification_third_party;
                    $account->future_verification_phone = $request->future_verification_phone;
                    $account->future_verification_email = $request->future_verification_email;
                    $account->future_verification_fax = $request->future_verification_fax;
                    $account->future_verification_auto_phone = $request->future_verification_auto_phone;
                    $account->capcode = $futureCapcode;
                    if (Auth::user()->role == 'agent') {
                        $account->agent_id = Auth::user()->agent_link->agent_id;
                        $account->directory_agent_id = null;
                    }
                    if (Auth::user()->role == 'directory_agent') {
                        $account->directory_agent_id == Auth::user()->directory_agent_link->directory_agent_id;
                        $account->agent_id = null;
                    }
                }
            }
        }

        //If active directory account and future verification not set, move to inactive account, update and re-assign agent
        if (!empty(Directory_Active_Account::where('directory_account_id', $request->directory_account_id)->first())) {
            $account = Directory_Active_Account::where('directory_account_id', $request->directory_account_id)->first();
            if (empty($account->future_verification_third_party) && empty($account->future_verification_email) && empty($account->future_verification_phone) && empty($account->future_verification_fax) && empty($account->future_verification_auto_phone)) {
                if ($hasFutureVerification == 'true') {
                    $inactive = new Directory_Inactive_Account();
                    $inactive->directory_account_id = $account->directory_account_id;
                    $inactive->capcode = $futureCapcode;
                    $inactive->direct_phone = $account->direct_phone;
                    $inactive->contact_email = $account->contact_email;
                    $inactive->verification_phone = $account->verification_phone;
                    $inactive->verification_fax = $account->verification_fax;
                    $inactive->third_party_name = $account->third_party_name;
                    $inactive->third_party_account_number = $account->third_party_account_number;
                    $inactive->company_website = $account->company_website;
                    $inactive->verification_contact = $account->verification_contact;
                    $inactive->verification_contact_title = $account->verification_contact_title;
                    $inactive->verification_mailing_adress = $account->verification_mailing_adress;
                    $inactive->verification_notes = $account->verification_notes;
                    $inactive->total_employees = $account->total_employees;
                    $inactive->aka = $account->aka;
                    $inactive->employer_type = $account->employer_type;
                    $inactive->last_worked = Carbon::now()->toDateTimeString();
                    $inactive->employer_name = $account->employer_name;
                    $inactive->address = $account->address;
                    $inactive->city = $account->city;
                    $inactive->state = $account->state;
                    $inactive->zip = $account->zip;
                    $inactive->name_match = $account->name_match;
                    $inactive->aka_name_match = $account->aka_name_match;
                    $inactive->future_verification_third_party = $request->future_verification_third_party;
                    $inactive->future_verification_phone = $request->future_verification_phone;
                    $inactive->future_verification_email = $request->future_verification_email;
                    $inactive->future_verification_fax = $request->future_verification_fax;
                    $inactive->future_verification_auto_phone = $request->future_verification_auto_phone;
                    if (Auth::user()->role == 'agent') {
                        $inactive->agent_id = Auth::user()->agent_link->agent_id;
                        $inactive->directory_agent_id = null;
                    }
                    if (Auth::user()->role == 'directory_agent') {
                        $inactive->directory_agent_id = Auth::user()->directory_agent_link->directory_agent_id;
                        $inactive->agent_id = null;
                    }
                    $inactive->save();
                    $account->delete();
                }
            }
        }
    }

    public function getSSNAccount(request $request)
    {
        //updates the additonal data found
        if (Active_Account::where('ID', $request->lastId)->exists()) {
            Active_Account::where('ID', $request->lastId)->update(['LAST_EMPL_NAME' => $request->emplName, 'LAST_EMPL_ADDR' => $request->emplAddr, 'LAST_EMPL_PHONE' => $request->emplPhone, 'LAST_EMPL_EMAIL' => $request->emplEmail, 'LAST_EMPL_FAX' => $request->emplFax]);
        } else {
            Inactive_Account::where('ID', $request->lastId)->update(['LAST_EMPL_NAME' => $request->emplName, 'LAST_EMPL_ADDR' => $request->emplAddr, 'LAST_EMPL_PHONE' => $request->emplPhone, 'LAST_EMPL_EMAIL' => $request->emplEmail, 'LAST_EMPL_FAX' => $request->emplFax]);
        }

        //makes sure the user has access to the account
        $checkAccess = $this->checkAccess($request->id);
        if ($checkAccess == false) {
            $AA = [];
            $check = false;
        } else {
            $check = true;

            $AA = Active_Account::SELECT('ID', 'POWERLEAD_ID', 'CORPORATION_ID', 'DIRECTORY_LINK', 'WEB_CRAWLER_ID', 'ACCT_DOB', 'ACCT_ST', 'ACCT_CITY', 'ACCT_AD1', 'ACCT_ZIP', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'CLIENT_NAME', 'CLIENT_PHONE', 'ACCT_ID')->find($request->id);

            //checks if the account exists in active, if not moves to inactive
            if ($AA == null) {
                $AA = Inactive_Account::SELECT('ID', 'POWERLEAD_ID', 'CORPORATION_ID', 'DIRECTORY_LINK', 'WEB_CRAWLER_ID', 'ACCT_DOB', 'ACCT_ST', 'ACCT_CITY', 'ACCT_AD1', 'ACCT_ZIP', 'ACCT_FIRST_NAME', 'ACCT_LAST_NAME', 'CLIENT_NAME', 'CLIENT_PHONE', 'ACCT_ID')->find($request->id);
            }

            //if account is not in either, returns false
            if ($AA == null) {
                $AA = [];
                $check = false;
            } else {
                //checks that the account is owned by the corporation
                if ((Auth::user()->role == 'agent') || (Auth::user()->role == 'manager') || (Auth::user()->role == 'corporate_admin')) {
                    if (Auth::user()->role == 'agent') {
                        $checkCorporation = Auth::user()->agent_link->corporation_id;
                    } elseif (Auth::user()->role == 'manager') {
                        $checkCorporation = Auth::user()->manager_link->corporation_id;
                    } elseif (Auth::user()->role == 'corporate_admin') {
                        $checkCorporation = Auth::user()->corporate_admin_link->corporation_id;
                    }

                    if ($AA->CORPORATION_ID != $checkCorporation) {
                        $AA = [];
                        $check = false;
                    }
                }
            }
        }
        echo json_encode(array($AA, $check));
    }

    public function getLeadData(request $request)
    {
        if ($request->id == null) {
            echo json_encode(array([], null, null, null));
            return;
        }

        if (Active_Account::where('ID', $request->id)->exists()) {
            $AA = Active_Account::SELECT('EMPL_NAME', 'EMPL_ADDR1', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_PHONE1_NMBR', 'EMPL_FAX', 'EMPL_EMAIL', 'LAST_EMPL_NAME', 'LAST_EMPL_ADDR', 'LAST_EMPL_PHONE', 'LAST_EMPL_EMAIL', 'LAST_EMPL_FAX', 'CORPORATION_ID', 'WORK_ATTEMPTS')->find($request->id);
        } else {
            $AA = Inactive_Account::SELECT('EMPL_NAME', 'EMPL_ADDR1', 'EMPL_CITY', 'EMPL_ST', 'EMPL_ZIP', 'EMPL_PHONE1_NMBR', 'EMPL_FAX', 'EMPL_EMAIL', 'LAST_EMPL_NAME', 'LAST_EMPL_ADDR', 'LAST_EMPL_PHONE', 'LAST_EMPL_EMAIL', 'LAST_EMPL_FAX', 'CORPORATION_ID', 'WORK_ATTEMPTS')->find($request->id);
        }

        $fax = $AA->EMPL_FAX ?? null;
        $fax = preg_replace('/[^0-9]/', '', $fax);
        $blocked = $this->checkBlocked($AA->EMPL_PHONE1_NMBR ?? null, null, $fax, $AA->EMPL_EMAIL ?? null, $AA->CORPORATION_ID);
        $fax = $blocked['fax'];
        $email = $blocked['email'];
        $phone = $blocked['phone1'];

        echo json_encode(array($AA, $phone, $email, $fax));
    }
    public function getWebCrawlerData(request $request)
    {
        $WC = Web_Crawler::SELECT('ID', 'company_name', 'company_website', 'employee_count', 'company_industry', 'company_address', 'company_city', 'company_state', 'company_zip', 'company_phone', 'company_email', 'company_linked_in', 'company_country')->find($request->id);

        $blocked = $this->checkBlocked($WC->company_phone ?? null, null, null, $WC->company_email ?? null, $request->corpId);
        $email = $blocked['email'];
        $phone = $blocked['phone1'];

        echo json_encode(array($WC, $phone, $email));
    }
    public function getDirectoryData(request $request)
    {
        //Check to see if Directory Lead exists and assign values if true
        if (!empty(Directory_Active_Account::find($request->id))) {
            $directory = Directory_Active_Account::find($request->id);
        } else {
            $directory = Directory_Inactive_Account::find($request->id);
        }

        //Check for multiple addresses associated with directory account, handle display in blade view
        $directoryRows = 0;
        $directoryAddresses = [];
        $directoryCities = [];
        $directoryStates = [];
        $directoryZips = [];
        if (!empty($directory->address) || !empty($directory->city) || !empty($directory->state) || !empty($directory->zip)) {
            $directoryRows = 1;
            $directoryAddresses = explode('|', $directory->address);
            $directoryCities = explode('|', $directory->city);
            $directoryStates = explode('|', $directory->state);
            $directoryZips = explode('|', $directory->zip);
            if (count($directoryAddresses) > $directoryRows) {
                $directoryRows = count($directoryAddresses);
            }
            if (count($directoryCities) > $directoryRows) {
                $directoryRows = count($directoryCities);
            }
            if (count($directoryStates) > $directoryRows) {
                $directoryRows = count($directoryStates);
            }
            if (count($directoryZips) > $directoryRows) {
                $directoryRows = count($directoryZips);
            }
        }

        $fax = $directory->verification_fax ?? null;
        $fax = preg_replace('/[^0-9]/', '', $fax);
        $blocked = $this->checkBlocked($directory->verification_phone ?? null, $directory->direct_phone ?? null, $fax, $directory->verification_email ?? null, $request->corpId);
        $fax = $blocked['fax'];
        $email = $blocked['email'];
        $phone1 = $blocked['phone1'];
        $phone2 = $blocked['phone2'];

        echo json_encode(array($directory, $directoryRows, $directoryAddresses, $directoryCities, $directoryStates, $directoryZips, $phone1, $phone2, $email, $fax));
    }
    public function getPowerLeadData(request $request)
    {
        $PL = Powerlead_Accounts::SELECT('ID', 'employer_name', 'employer_address', 'employer_city', 'employer_state', 'employer_zip', 'main_phone', 'fax', 'email', 'website', 'local_address')->find($request->id);

        $fax = $PL->fax ?? null;
        $fax = preg_replace('/[^0-9]/', '', $fax);
        $blocked = $this->checkBlocked($PL->main_phone ?? null, null, $fax, $PL->email ?? null, $request->corpId);
        $fax = $blocked['fax'];
        $email = $blocked['email'];
        $phone = $blocked['phone1'];

        echo json_encode(array($PL, $phone, $email, $fax));
    }

    //checks if the phone numbers,fax numbers, or email is blocked for all the get data functions
    public function checkBlocked($phone1, $phone2, $fax, $email, $corpId){
        $blocked = [
            'phone1' => false,
            'phone2' => false,
            'fax' => false,
            'email' => false
        ];

        if (Blocked_Company::where('phone_number', $phone1)->where('corporation_id', $corpId)->exists())
            $blocked['phone1'] = true;
        if (Blocked_Company::where('phone_number', $phone2)->where('corporation_id', $corpId)->exists())
            $blocked['phone2'] = true;
        if (Blocked_Company::where('fax_number', $fax)->where('corporation_id', $corpId)->exists())
            $blocked['fax'] = true;
        if (Blocked_Company::where('email', $email)->where('corporation_id', $corpId)->exists())
            $blocked['email'] = true;

        return $blocked;
    }

    public function formatEmailData(Request $request)
    {
        $this->validate($request, [
            'acct_type' => 'in:inactive,worked,active',
            'email' => 'email',
        ]);
        $company_name = $request->company_name;
        $email = $request->email;

        $account = "";
        if ($request->acct_type == 'inactive') {
            $account = Inactive_Account::find($request->email_acct_id);
        } else {
            $account = Active_Account::find($request->email_acct_id);
        }

        if ($request->fullSSN == "1") {
            $ssn = $this->formatSSN($account->ACCT_SSN);
        } else {
            $ssn = $this->formatSSN($account->ACCT_SSN);
            $ssn = 'xxx-xx-' . substr($ssn, -4);
        }

        $this->setUpEmail($account, $email, $company_name, $ssn);
    }

    private function formatSSN($ssn)
    {
        if(strlen($ssn) < 9){
            $ssn = str_pad($ssn, 9, '0', STR_PAD_LEFT);
        }

        if (preg_match("#^\d{3}-?\d{2}-?\d{4}$#", $ssn)) {
            return preg_replace("#^(\d{3})-?(\d{2})-?(\d{4})$#", "$1-$2-$3", $ssn);
        } else {
            $LCIRROR = 'Cannot format SSN';
        }

    }

    public function setUpAka($akas)
    {
        $aka_name_match = "";

        foreach ($akas as $aka) {
            $aka = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $aka);
            $wordCount = str_word_count($aka);
            if ($wordCount > 3) {
                $aka = $this->trim_text($aka, 2);
            }
            $aka = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $aka));
            $aka_name_match = $aka_name_match . $aka . ",";
        }

        $aka_name_match = substr_replace($aka_name_match, "", -1);

        return $aka_name_match;
    }

    public function addVerifiedHit(Request $request, $id, $capcode_type)
    {
        $verified_hit = Verified_Hit::findOrNew($id);
        $verified_hit->employer_type = $request->verified_employer_type;
        $verified_hit->employer_name = $request->empl_name_verified;
        $verified_hit->employer_phone = $request->empl_ph_nmbr_verified;
        $verified_hit->employer_address_1 = $request->empl_addr1_verified;
        $verified_hit->employer_address_2 = $request->empl_addr2_verified;
        $verified_hit->employer_city = $request->empl_city_verified;
        $verified_hit->employer_state = $request->empl_st_verified;
        $verified_hit->employer_zip = $request->empl_zip_verified;
        $verified_hit->employer_name = $request->empl_name_verified;
        $verified_hit->employer_fax = $request->empl_fax_verified;
        $verified_hit->employer_email = $request->empl_email_verified;
        $verified_hit->employer_title = $request->empl_title_verified;
        $verified_hit->verification_mailing_address = $request->empl_verification_mailing_address_verified;
        $verified_hit->verification_contact_name = $request->empl_contact_verified;
        $verified_hit->verification_contact_title = $request->empl_contact_title_verified;
        $verified_hit->future_verification_third_party = $request->future_third_party;
        $verified_hit->future_verification_phone = $request->future_phone;
        $verified_hit->future_verification_fax = $request->future_fax;
        $verified_hit->future_verification_email = $request->future_email;
        $verified_hit->future_verification_auto_phone = $request->future_auto_phone;
        $verified_hit->capcode = $request->capcode_id;
        $verified_hit->capcode_type = $capcode_type;
        if (Auth::user()->role == 'agent') {
            $verified_hit->agent_id = Auth::user()->agent_link->agent_id;
        }
        if (Auth::user()->role == 'directory_agent') {
            $verified_hit->directory_agent_id = Auth::user()->directory_agent_link->directory_agent_id;
        }
        $verified_hit->save();

        return $verified_hit;

    }

    public function updateAllSSN(Request $request, $account, $closed)
    {
        if ($closed == 2) {
            $ssn = Inactive_Account::SELECT('ID')->where('ACCT_SSN', $account->ACCT_SSN)->where('CORPORATION_ID', $account->CORPORATION_ID)->count();
        } else {
            $ssn = Active_Account::SELECT('ID')->where('ACCT_SSN', $account->ACCT_SSN)->where('CORPORATION_ID', $account->CORPORATION_ID)->count();
        }

        //if there is only one ssn, ends the function
        if (($ssn == 1 && $closed != 1) || ($ssn == 0 && $closed == 1)) {
            return;
        }

        $setStatement = "";

        //appends to the statement based on what fields were updated
        if ($request->verified_capcode) {
            $setStatement = $setStatement . " `CAPCODE` = '" . $account->CAPCODE . "',";
        }
        $setStatement = $setStatement . " `VERIFIED_HITS_ID` = '" . $account->VERIFIED_HITS_ID . "',";

        //sets all the last calls and emails/faxes
        $setStatement = $setStatement . " `LAST_CALL` = '" . $account->LAST_CALL . "',";
        $setStatement = $setStatement . " `LAST_FAX_EMAIL` = '" . $account->LAST_EMAIL_FAX . "',";

        //removes the extra comma at the end of a statement
        $setStatement = $setStatement . " `LAST_WORKED` =  now() ";

        switch ($closed) {
            //accounts are just updated
            case 0:
                DB::select(DB::raw('UPDATE `active_accounts`
                    SET ' . $setStatement . '
                     WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                break;
            //accounts are moved to inactive accounts
            case 1:
                DB::select(DB::raw('UPDATE `active_accounts`
                    SET ' . $setStatement . '
                     WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                DB::select(DB::raw('INSERT INTO `inactive_accounts`
                    SELECT * FROM `active_accounts`
                    WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                DB::select(DB::raw('DELETE FROM `active_accounts`
                     WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                break;
            //inactive account is updated
            case 2:
                DB::select(DB::raw('UPDATE `inactive_accounts`
                    SET ' . $setStatement . '
                     WHERE `CORPORATION_ID` = ' . $account->CORPORATION_ID . ' AND ACCT_SSN = ' . $account->ACCT_SSN . ';'));

                break;
        }

        return;
    }

    //backend check that needed fields are filled
    public function filledRequired(Request $request)
    {
        $requirments = Verification_Requirements::where('corporation_id', $request->corporation_id)->first();

        if (($requirments->employer_type == 1) && (str_replace(' ', '', $request->verified_employer_type) == "")) {
            return false;
        }

        if (($requirments->employer_name == 1) && (str_replace(' ', '', $request->empl_name_verified) == "")) {
            return false;
        }

        if (($requirments->employer_phone == 1) && (str_replace(' ', '', $request->empl_ph_nmbr_verified) == "")) {
            return false;
        }

        if (($requirments->employer_address_1 == 1) && (str_replace(' ', '', $request->empl_addr1_verified) == "")) {
            return false;
        }

        if (($requirments->employer_address_2 == 1) && (str_replace(' ', '', $request->empl_addr2_verified) == "")) {
            return false;
        }

        if (($requirments->employer_city == 1) && (str_replace(' ', '', $request->empl_city_verified) == "")) {
            return false;
        }

        if (($requirments->employer_state == 1) && (str_replace(' ', '', $request->empl_st_verified) == "")) {
            return false;
        }

        if (($requirments->employer_zip == 1) && (str_replace(' ', '', $request->empl_zip_verified) == "")) {
            return false;
        }

        if (($requirments->consumer_title == 1) && (str_replace(' ', '', $request->empl_title_verified) == "")) {
            return false;
        }

        if (($requirments->employer_fax == 1) && (str_replace(' ', '', $request->empl_fax_verified) == "")) {
            return false;
        }

        if (($requirments->employer_email == 1) && (str_replace(' ', '', $request->empl_email_verified) == "")) {
            return false;
        }

        if (($requirments->verification_mailing_address == 1) && (str_replace(' ', '', $request->empl_verification_mailing_address_verified) == "")) {
            return false;
        }

        if (($requirments->verification_contact_name == 1) && (str_replace(' ', '', $request->empl_contact_verified) == "")) {
            return false;
        }

        if (($requirments->verification_contact_title == 1) && (str_replace(' ', '', $request->empl_contact_title_verified) == "")) {
            return false;
        }

        if (($requirments->future_verifications == 1) && (str_replace(' ', '', $request->future_verification) == "")) {
            return false;
        }

        return true;
    }

    public function uploadFileActive(request $request)
    {
        if ($request->type == 'inactive') {
            $account = Inactive_Account::find($request->account_id);
        } else {
            $account = Active_Account::find($request->account_id);
        }

        $verified_hit = Verified_Hit::findOrNew($account->VERIFIED_HITS_ID);

        if (Auth::user()->role == 'agent') {
            $verified_hit->agent_id = Auth::user()->agent_link->agent_id;
        }
        if (Auth::user()->role == 'directory_agent') {
            $verified_hit->directory_agent_id = Auth::user()->directory_agent_link->directory_agent_id;
        }
        $verified_hit->save();

        $account->VERIFIED_HITS_ID = $verified_hit->id;
        $account->save();

        $date = date('F_j_Y_h-i-s_A');
        $filePath = storage_path('app/public/verified_files/' . $request->corporation_id . '/' . $verified_hit->id);

        if (!empty($request->file('verified_file'))) {
            $verified_file = $request->file('verified_file')->getClientOriginalName();
        }
        $filename = pathinfo($verified_file, PATHINFO_FILENAME);
        $extension = pathinfo($verified_file, PATHINFO_EXTENSION);

        $request->file('verified_file')->move($filePath, $filename . '_' . $date . '.' . $extension);
        $file_path = 'verified_files/' . $request->corporation_id . '/' . $verified_hit->id . '/' . $filename . '_' . $date . '.' . $extension;

        $active_account_file = new Active_Account_Files;
        $active_account_file->name = $verified_file;
        $active_account_file->file_path = $file_path;
        $active_account_file->user_id = Auth::user()->user_id;
        $active_account_file->verified_hits_id = $verified_hit->id;
        $active_account_file->save();

        $fileArray = array(
            'filename' => $verified_file,
            'fileid' => $active_account_file->id,
        );
        echo json_encode($fileArray);

    }
    public function downloadActiveAccount($id)
    {
        $active_file = Active_Account_Files::find($id);

        return response()->download(storage_path('app/public/' . $active_file->file_path));
    }

    public function deleteActiveAccountFile($id)
    {
        $active_file = Active_Account_Files::find($id);
        $active_file->delete();
    }

    public function updateAALastInfo(Request $request)
    {
        if (Active_Account::where('ID', $request->lastId)->exists()) {
            $account = Active_Account::where('ID', $request->lastId);
        } else {
            $account = Inactive_Account::where('ID', $request->lastId);
        }
        $account->update(['LAST_EMPL_NAME' => $request->emplName, 'LAST_EMPL_ADDR' => $request->emplAddr, 'LAST_EMPL_PHONE' => $request->emplPhone, 'LAST_EMPL_EMAIL' => $request->emplEmail, 'LAST_EMPL_FAX' => $request->emplFax]);
    }

    public function sendEmailVerification(Request $request)
    {
        $mail = new RNNMailer(true);

        // Content<p>{{  }}</p>
        $mail->createHeader('Invalid Email');
        $mail->MessageDate = date("M,d,Y h:i:s A");
        $mail->Subject = "Invalid Email";
        $mail->Body = "This is the email trying to be sent " . $request->email;

        // Mail Send
        $mail->send();
    }

}
