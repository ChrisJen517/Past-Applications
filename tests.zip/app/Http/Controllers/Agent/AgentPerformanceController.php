<?php

namespace App\Http\Controllers\Agent;

use App\Models\Active_Account;
use App\Models\Agent;
use App\Models\Capcode;
use App\Http\Controllers\Controller;
use App\Models\Inactive_Account;
use App\User;
use App\Models\Worked_History;
use Auth;
use DateTime;
use Illuminate\Http\Request;

class AgentPerformanceController extends Controller
{
    public function seeReport()
    {
        $data = $this->getData(date("Y-m-d", strtotime("today")), date("Y-m-d", strtotime('tomorrow')));
        $callsMade = $this->callsMade(date("Y-m-d", strtotime("today")), date("Y-m-d", strtotime('tomorrow')));
        
        $message = "for the current day.";

        return view('/agents/pages/agentPerformance')
        ->with('agentPerformance', $data[0])->with('capcodeUse', $data[1])
        ->with('timeMessage', $message)->with('callsMade', $callsMade);
    }

    public function seeReportTime(Request $request)
    {
        //gets the date range
        if ($request->from == null) {
            $startTime = date("Y-m-d", strtotime("-1 week"));
        } else {
            $startTime = date('Y-m-d', strtotime($request->from));
        }
        if ($request->to == null) {
            $endTime = date("Y-m-d");
        } else {
            $endTime = date('Y-m-d', strtotime($request->to));
        }

        //gets the message displayed on the form
        $message = "from: " . $startTime . " to " . $endTime;

        //sets the endtime to the start of the next day
        $endTime = date('Y-m-d', strtotime($endTime." +1 day"));

        $data = $this->getData($startTime, $endTime);
        $callsMade = $this->callsMade($startTime, $endTime);

        //return $data[0];
        return view('/agents/pages/agentPerformance')
        ->with('agentPerformance', $data[0])->with('capcodeUse', $data[1])
        ->with('callsMade', $callsMade)->with('timeMessage', $message);
    }

    public function getData($day, $dayAfter)
    {
        //gets user information
        $userAgent = Auth::user()->agent_link;
        $userAgentId = $userAgent->agent_id;
        $corporationId = $userAgent->corporation_id;

        $agents = Agent::where('corporation_id', $corporationId)->select('agent_id', 'user_id')->with('user_link')->get();

        //gets all of the agents into an array
        $agentIds = [];
        foreach($agents as $agent){
            $agentIds[] = $agent->agent_id;
        }

        //gets all accounts
        $activeAccounts = Active_Account::selectRaw('`ACCT_AGENT`, `capcodes`.`capcode`, count(`active_accounts`.`ID`) as totalUses, `capcodes`.`type`')
            ->leftJoin('capcodes', function ($join) {
                $join->on('active_accounts.CAPCODE', '=', 'capcodes.id');
            })->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)->whereIn('ACCT_AGENT', $agentIds)
            ->groupBy('ACCT_AGENT')->groupBy('CAPCODE')->get();
        $inactiveAccounts = Inactive_Account::selectRaw('`ACCT_AGENT`, `capcodes`.`capcode`, count(`inactive_accounts`.`ID`) as totalUses, `capcodes`.`type`')
            ->leftJoin('capcodes', function ($join) {
                $join->on('inactive_accounts.CAPCODE', '=', 'capcodes.id');
            })->where('LAST_WORKED', '>', $day)->where('LAST_WORKED', '<', $dayAfter)->whereIn('ACCT_AGENT', $agentIds)
            ->groupBy('ACCT_AGENT')->groupBy('CAPCODE')->get();

        //gets the current users totals
        $agentActive = $activeAccounts->where('ACCT_AGENT', $userAgentId);
        $agentInactive = $inactiveAccounts->where('ACCT_AGENT', $userAgentId);
        $agentData[] = $this->getAgentData($userAgent, $agentActive, $agentInactive);
        $capcodeUse = $this->getCapcodeUse($agentActive, $agentInactive);

        //gets the totals for all other agents
        $agents = $agents->where('agent_id', '!=', $userAgentId);
        foreach($agents as $agent){
            $agentActive = $activeAccounts->where('ACCT_AGENT', $agent->agent_id);
            $agentInactive = $inactiveAccounts->where('ACCT_AGENT', $agent->agent_id);

            if($agentActive->first() == null && $agentInactive->first() == null){
                continue;
            }

            $agentData[] = $this->getAgentData($agent, $agentActive, $agentInactive);
        }

        $finalData[] = $agentData;
        $finalData[] = $capcodeUse;
        return $finalData;
    }

    public function getCapcodeUse($agentActive, $agentInactive){
        $capcodeUse = [];
        foreach($agentActive as $active){
            $capcodeUse[$active->capcode] = [
                'capcode' => $active->capcode,
                'count' => $active->totalUses,
                'type' => $active->type
            ];
        }
        foreach($agentInactive as $inactive){
            if(!array_key_exists($inactive->capcode, $capcodeUse)){
                $capcodeUse[$inactive->capcode] = [
                    'capcode' => $inactive->capcode,
                    'count' => $inactive->totalUses,
                    'type' => $inactive->type
                ];
            }
            else
                $capcodeUse[$inactive->capcode]['count'] += $inactive->totalUses;
        }
        return $capcodeUse;
    }

    public function getAgentData($agent, $agentActive, $agentInactive){
        $inconclusive = $this->getSum($agentActive->where('type', 'inconclusive'), $agentInactive->where('type', 'inconclusive'));
        $unverified = $this->getSum($agentActive->where('type', 'unverified'), $agentInactive->where('type', 'unverified'));
        $pending = $this->getSum($agentActive->where('type', 'pending'), $agentInactive->where('type', 'pending'));
        $verified = $this->getSum($agentActive->where('type', 'verified'), $agentInactive->where('type', 'verified'));

        return [
            'name' => $agent->user_link->first_name . ' ' . $agent->user_link->last_name,
            'id' => $agent->agent_id,
            'inconclusive' => $inconclusive,
            'unverified' => $unverified,
            'pending_approval' => $pending,
            'verified' => $verified,
        ];
    }

    public function getSum($actives, $inactives){
        $sum = 0;
        foreach($actives as $active)
            $sum += $active->totalUses;
        foreach($inactives as $inactive)
            $sum += $inactive->totalUses;
        return $sum;
    }

    public function callsMade($first, $last){
        $agent = Auth::user()->agent_link;
        $callCode = Capcode::where("capcode", 2210)->where('corporation_id', $agent->corporation_id)->first();

        $allAgents = Agent::where('corporation_id', $agent->corporation_id)->with('user_link')->get();
        //gets all of the agents into an array
        $agentIds = [];
        foreach($allAgents as $agent){
            $agentIds[] = $agent->agent_id;
        }

        $callsMadeAll = Worked_History::where('created_at', '>', $first)->where('created_at', '<', $last)
        ->whereIn('agent_id', $agentIds)->where('capcode', $callCode->id)
        ->selectRaw('agent_id, count(*) as callsMade')->groupby('agent_id')
        ->get();

        $callData = [];
        foreach($callsMadeAll as $callsMade){
            $callCount = $callsMade->callsMade;
            $currentAgent = $allAgents->where('agent_id', $callsMade->agent_id)->first();

            if($currentAgent->first() == null)
                continue;

            $name = $currentAgent->user_link->first_name." ".$currentAgent->user_link->last_name;
            $callData[] = [
                $name,
                $callCount,
            ];
        }

        return $callData;
    }
}