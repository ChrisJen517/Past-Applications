<?php

namespace App\Http\Controllers\ConsumerTracing;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ConsumerTracingWorkFormController extends Controller
{
    public function workNow(){
        return view('consumerTracing.workForm');
    }
}