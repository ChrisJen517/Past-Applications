<?php

namespace App\Http\Controllers\ConsumerTracing;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ConsumerTracingManageAccountsController extends Controller
{
    public function manageAccounts(){
        return view('consumerTracing.accountManagement');
    }
}