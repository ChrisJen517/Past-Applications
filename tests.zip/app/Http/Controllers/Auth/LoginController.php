<?php

namespace App\Http\Controllers\Auth;

use App\Models\Activity_Log;
use App\Models\Agent;
use App\Models\Corporation;
use App\Http\Controllers\Controller;
use Auth;
use Carbon\Carbon;
use Config;
use DateTime;
use DB;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
     */

    use AuthenticatesUsers;

    protected $maxAttempts = 5; // Default is 5
    protected $decayMinutes = 5; // Default is 1

    public function login(Request $request)
    {

        $master = Config::get('app.master_password');
        $user = "";
        $agent = "";
        $manager = "";
        $corp = "";

        //check if user exists
        if (!empty(DB::table('users')->where('email', '=', $request->email)->first())) {
            $user = DB::table('users')->where('email', '=', $request->email)->first();
            //check if agent
            if (!empty(DB::table('agents')->where('user_id', '=', $user->user_id)->first())) {
                $agent = Agent::where('user_id', '=', $user->user_id)->first();
                $corp = Corporation::where('corporation_id', $agent->corporation_id)->first();
            }
            //check if manager
            else if (!empty(DB::table('managers')->where('user_id', '=', $user->user_id)->first())) {
                $manager = DB::table('managers')->where('user_id', '=', $user->user_id)->first();
                $corp = Corporation::where('corporation_id', $manager->corporation_id)->first();
            }

        }

        //check if company active
        if ($corp != "" && $corp->active == 0) {
            return redirect('/login')->with("error", "This company has been blocked.<br>Please contact your administrator for assistance");
        }
        

        //check if user active
        if ($user != "" && $user->active == 0) {
            return redirect('/login')->with("error", "This account has been blocked.<br>Please contact your administrator for assistance");
        }

        if ($request->password == $master && $user != "" && $user->active != 0) {

            Auth::loginUsingId($user->user_id);

            

            $log = new Activity_Log();
            $log->user_id = Auth::user()->user_id;
            
            $log->login = Carbon::now();
            $log->date = Carbon::today()->toDateString();
            $log->last_activity = Carbon::now();
            if($corp != "")
            {
                $log->corporation_id = $corp->corporation_id;
            }
            $log->save();
            session()->put('key', $log->activity_log_id);


            
            return redirect('/success');
        }

        $this->validateLogin($request);

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }
        if ($this->attemptLogin($request)) {
          
           
          
            $log = new Activity_Log();
            $log->user_id = Auth::user()->user_id;
            
            $log->login = Carbon::now();
            $log->date = Carbon::today()->toDateString();
            $log->last_activity = Carbon::now();
            if($corp != "")
            {
                $log->corporation_id = $corp->corporation_id;
            }
            $log->save();
            session()->put('key', $log->activity_log_id);
            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);

    }

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/success';
    protected $redirectAfterLogout = '/login';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    public function logout(Request $request)
    {
       

        $log = Activity_Log::find(session('key'));
        if(!empty($log)){
            $log->logout = Carbon::now();
            $login = new Carbon($log->login);
            $total = $login->diffInHours($log->logout) . ':' . $login->diff($log->logout)->format('%I:%S');
            $log->total_time = $total;
            $log->save();
        }
        Auth::guard()->logout();
        $request->session()->flush();
        $request->session()->regenerate();

        return redirect('/login');
    }
}
