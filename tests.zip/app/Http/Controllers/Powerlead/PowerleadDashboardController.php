<?php

namespace App\Http\Controllers\Powerlead;


use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Request;
use Auth;
use App\User;
use App\Models\Active_Account;
use App\Models\Powerlead_Settings;

class PowerleadDashboardController extends Controller
{
    public function dashboard()
    {
        $user = User::find(Auth::user()->user_id);
        $powerlead_settings = Powerlead_Settings::first();
        $first = $powerlead_settings->priority;
        $second = $powerlead_settings->second_priority;
        $active_account = Active_Account::where('POWERLEAD_CAPCODE', 3)->whereNotNull('POWERLEAD_ID')
        ->where('powerlead_agent_id',$user->powerlead_link->id)
        ->when($first, function ($query, $first) {
            return $query->orderByRaw($first);
        })
        ->when($second, function ($query, $second) {
            return $query->orderByRaw($second);
        })->get();

        return view('/powerlead/pages/dashboard')->with('active_accounts', $active_account);
    }
}