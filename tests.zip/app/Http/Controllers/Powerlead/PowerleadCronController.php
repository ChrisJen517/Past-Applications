<?php

namespace App\Http\Controllers\Powerlead;


use App\Http\Controllers\Controller;
use Symfony\Component\HttpFoundation\Request;
use Auth;
use App\Models\Active_Account;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Work_History;
use App\Models\Powerlead;
use App\User;
use DB;
use Carbon\Carbon;
use App\Models\Powerlead_Settings;

class PowerleadCronController extends Controller
{
    public function refillQueue(){

        $powerlead_agents = Powerlead::with('user_link')->get();
        $powerlead_settings = Powerlead_Settings::first();
        $accounts_to_assign = 0;
        $agent_count = 0;
        $powerlead_agents_info = [];
        $break = 0;
        foreach($powerlead_agents as $powerlead_agent){
                if($powerlead_agent->user_link->active == 1){           
                $agent_count++;
                $queued_accounts = Active_Account::where('POWERLEAD_CAPCODE', 3)->where('POWERLEAD_AGENT_ID', $powerlead_agent->id)->get();
                $accounts_to_assign_per_agent = $powerlead_settings->max_accounts - count($queued_accounts);
                $powerlead_agents_info[] = array(
                    "AGENT_ID" => $powerlead_agent->id,
                    "NUMBER_OF_ACCOUNTS" => count($queued_accounts),
                    "AA_IDS" => ''
                );
                
                $accounts_to_assign = $accounts_to_assign + $accounts_to_assign_per_agent;
                if($accounts_to_assign < 0){
                    $accounts_to_assign = 0;
                }
            }
        }

        if($accounts_to_assign > 500){
            $accounts_to_assign = 500;
        }
        
        if($accounts_to_assign > 0){
            do{
            
                $first = $powerlead_settings->priority;
                $second = $powerlead_settings->second_priority;
            
                $active_accounts = Active_Account::where('POWERLEAD_FLAG', 1)->where('POWERLEAD_CAPCODE', 2)
                ->when($first, function ($query, $first) {
                    return $query->orderByRaw($first);
                })
                ->when($second, function ($query, $second) {
                    return $query->orderByRaw($second);
                })->limit($accounts_to_assign)->get();

                // Mass Update
                $numberOfAgents = $agent_count;
                $agentNumber = 0;
                $checkedAll = 0;
                if(count($active_accounts) < 500){
                    $break = 1;
                }

                foreach($active_accounts as $active_account){
                    startTeam:
                    if ($powerlead_agents_info[$agentNumber]["NUMBER_OF_ACCOUNTS"] >= $powerlead_settings->max_accounts) {
                        $checkedAll++;
                        if ($checkedAll == $numberOfAgents) {
                            break;
                        }

                        $agentNumber++;
                        if ($agentNumber == $numberOfAgents) {
                            $agentNumber = 0;
                        }

                        goto startTeam;
                    } else {
                        $checkedAll = 0;
                    }

                    $powerlead_agents_info[$agentNumber]["AA_IDS"] = $powerlead_agents_info[$agentNumber]["AA_IDS"].'"' . $active_account->ID . '",';
                    $powerlead_agents_info[$agentNumber]["NUMBER_OF_ACCOUNTS"]++;
                    
                    $agentNumber++;
                    if ($agentNumber == $numberOfAgents) {
                        $agentNumber = 0;
                    }
                }
                
                //updates the database
                foreach($powerlead_agents_info as $powerlead_agent) {
                    if ($powerlead_agent["AA_IDS"] != "") {
                        $powerlead_agent["AA_IDS"] = substr_replace($powerlead_agent["AA_IDS"], "", -1);
                        DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_AGENT_ID` = '.$powerlead_agent["AGENT_ID"].', POWERLEAD_CAPCODE = 3 WHERE `ID` IN ('.$powerlead_agent["AA_IDS"].');'));
                    }
                }

                // Loop Active_accounts to assign powerlead account id
                foreach($active_accounts as $active_account){
                    $active_account_input = Active_Account::find($active_account->ID);
                    if($active_account_input->POWERLEAD_ID != null){
                        $powerlead_account = Powerlead_Accounts::find($active_account_input->POWERLEAD_ID);
                    }else{
                        $powerlead_account = new Powerlead_Accounts;    
                    }
                    $powerlead_account->powerlead_agent_id = $active_account_input->POWERLEAD_AGENT_ID;
                    $powerlead_account->active_account_id  = $active_account_input->ID;
                    $powerlead_account->save();
                    
                    $active_account_input->POWERLEAD_ID = $powerlead_account->id;
                    $active_account_input->save();
                }
                if($break == 0){
                $powerlead_agents = Powerlead::with('user_link')->get();
                $accounts_to_assign = 0;
                $agent_count = 0;
                $powerlead_agents_info = [];
        
                foreach($powerlead_agents as $powerlead_agent){
                        if($powerlead_agent->user_link->active == 1){           
                        $agent_count++;
                        $queued_accounts = Active_Account::where('POWERLEAD_CAPCODE', 3)->where('POWERLEAD_AGENT_ID', $powerlead_agent->id)->get();
                        $accounts_to_assign_per_agent = $powerlead_settings->max_accounts - count($queued_accounts);
                        $powerlead_agents_info[] = array(
                            "AGENT_ID" => $powerlead_agent->id,
                            "NUMBER_OF_ACCOUNTS" => count($queued_accounts),
                            "AA_IDS" => ''
                        );
                        
                        $accounts_to_assign = $accounts_to_assign + $accounts_to_assign_per_agent;
                        if($accounts_to_assign < 0){
                            $accounts_to_assign = 0;
                        }
                    }
                }
                if($accounts_to_assign > 500){
                    $accounts_to_assign = 500;
                }elseif($accounts_to_assign <= 0){
                    $break = 1;
                }
            }
            }while($break == 0);
        }
    }
}