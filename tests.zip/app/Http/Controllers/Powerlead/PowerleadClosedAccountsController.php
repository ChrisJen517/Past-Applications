<?php

namespace App\Http\Controllers\Powerlead;


use App\Http\Controllers\Controller;
use App\Models\Powerlead_Accounts;
use App\User;
use Auth;
use Carbon\Carbon;
use Illuminate\Http\Request;

class PowerleadClosedAccountsController extends Controller
{
    public function getClosedAccounts(Request $request)
    {
        $start_date = $request->start_date;
        $end_date = $request->end_date;

        if (empty($start_date))
            $start_date = Carbon::now()->format('Y-m-d');
        else
            $start_date = Carbon::parse($start_date)->format('Y-m-d');

        if (empty($end_date))
            $end_date = Carbon::now()->format('Y-m-d');
        else
            $end_date = Carbon::parse($end_date)->format('Y-m-d');

        if (empty($request->start_date) && empty($request->end_date))
            $timeMessage = 'From today';
        elseif ($start_date == $end_date)
            $timeMessage = 'From ' . $start_date;
        else
            $timeMessage = 'From ' . $start_date . ' to ' . $end_date;

        $user = User::find(Auth::user()->user_id);
        $history = Powerlead_Accounts::
        selectRaw('powerlead_accounts.id as id, powerlead_accounts.local_phone, powerlead_accounts.email, powerlead_accounts.fax, verified,
            powerlead_accounts.local_address, powerlead_accounts.main_phone, powerlead_accounts.powerlead_agent_id, active_accounts.EMPL_NAME as active_name, inactive_accounts.EMPL_NAME as inactive_name')
        ->leftJoin('active_accounts', function ($join) {
            $join->on('active_accounts.POWERLEAD_ID', '=', 'powerlead_accounts.id');
        })
        ->leftJoin('inactive_accounts', function ($join) {
            $join->on('inactive_accounts.POWERLEAD_ID', '=', 'powerlead_accounts.id');
        })
        ->where('powerlead_accounts.powerlead_agent_id', $user->powerlead_link->id)->whereNotNull('verified')->whereDate('powerlead_accounts.updated_at', '>=', $start_date)->whereDate('powerlead_accounts.updated_at', '<=', $end_date)->get();

        $startDateFormatted = Carbon::parse($start_date)->format('m/d/Y');
        $endDateFormatted = Carbon::parse($end_date)->format('m/d/Y');
        return view('/powerlead/pages/powerClosedAccounts')->with('historys', $history)->with('start_date', $startDateFormatted)->with('end_date', $endDateFormatted)->with('timeMessage', $timeMessage);
    }

}