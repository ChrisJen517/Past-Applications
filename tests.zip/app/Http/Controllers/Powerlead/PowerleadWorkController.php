<?php

namespace App\Http\Controllers\Powerlead;

use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\Http\Controllers\Controller;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Settings;
use App\Models\Worked_History;
use App\User;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use App\Models\Corporate_Settings;
use App\Models\Capcode;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Inactive_Account;
use App\Traits\Autobot;
use Config;
use App\Traits\SetFaxEmail;

class PowerleadWorkController extends Controller
{
    use Autobot;

    public function form()
    {

        $user = User::find(Auth::user()->user_id);
        $powerlead_settings = Powerlead_Settings::first();
        $first = $powerlead_settings->priority;
        $second = $powerlead_settings->second_priority;
        $active_account = Active_Account::where('POWERLEAD_CAPCODE', 3)->whereNotNull('POWERLEAD_ID')
            ->where('powerlead_agent_id', $user->powerlead_link->id)
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })->first();
        if (empty($active_account)) {
            return redirect()->route('powerleadDashboard')->with('error', 'You currently have no accounts assigned to you!');

        }
        $power_account = Powerlead_Accounts::find($active_account->POWERLEAD_ID);

        return view('/powerlead/pages/form')->with('active_account', $active_account)->with('power_account', $power_account)->with('agent_id', $user->powerlead_link->id)->with('minutes', '00')->with('seconds', '00');
    }

    public function powerAcctDetails($id){
        $user = Auth::user();

        $power_account = Powerlead_Accounts::find($id);

        if($power_account == null)
            return back()->with('error', 'Account Not Found');

        $active_account = Active_Account::find($power_account->active_account_id);

        if ($active_account == null || empty($active_account)) {
            $active_account = Inactive_Account::find($power_account->active_account_id);
            if($active_account == null)
            {
                $active_account = new \stdClass;
                $active_account->ID = "Not found, some information may be missing";
                $active_account->ACCT_FIRST_NAME = null;
                $active_account->ACCT_LAST_NAME = null;
                $active_account->ACCT_CITY = null;
                $active_account->ACCT_ST = null;
                $active_account->ACCT_ZIP = null;
                $active_account->EMPL_PHONE1_NMBR =  $power_account->main_phone;
                $active_account->EMPL_NAME = $power_account->employer_name;
                $active_account->EMPL_ADDR1 = $power_account->employer_address;
                $active_account->EMPL_CITY = NULL;
                $active_account->EMPL_ST = NULL;
                $active_account->EMPL_ZIP = NULL;

            }
        }

        $time = $power_account->timespent;
        $minutes = ''.intdiv($time,60);
        $seconds = ''.$time%60;
        if(strlen($seconds) < 2)
            $seconds = '0'.$seconds;
        if(strlen($minutes) < 2)
            $minutes = '0'.$minutes;

        return view('/powerlead/pages/form')->with('active_account', $active_account)->with('power_account', $power_account)->with('agent_id', $user->powerlead_link->id)->with('minutes', $minutes)->with('seconds', $seconds);
    }

    public function linkLeadData(request $request)
    {
        $user = User::find(Auth::user()->user_id);
        $power_account = Powerlead_Accounts::find($request->powerlead_id);
        $active_account = Active_Account::where('POWERLEAD_ID', $request->powerlead_id)->first();
        if (empty($active_account))
            $active_account = Inactive_Account::where('POWERLEAD_ID', $request->powerlead_id)->first();

        $date = date("Y-m-d H:i:s");

        $power_account->local_phone = preg_replace('/[^A-Za-z0-9\-]/', '', $request->local_phone);
        $power_account->employer_name = $request->employer_name;
        $power_account->local_address = $request->local_address;
        $power_account->website = $request->website;
        $power_account->main_phone = preg_replace('/[^A-Za-z0-9\-]/', '', $request->main_phone);
        $power_account->employer_address = $request->employer_address;
        $power_account->timespent = $request->seconds_spent;

        $agent_id = null;
        if ($user->role != 'admin' && $user->role != 'powerlead_directory_manager') {
            $agent_id = $user->powerlead_link->id;
            $power_account->powerlead_agent_id = $agent_id;
            $active_account->POWERLEAD_AGENT_ID = $user->powerlead_link->id;
        }

        if ($request->not_found_button == "Not_Found") {
            $power_account->verified = 0;
            $power_account->save();
            $active_account->POWERLEAD_CAPCODE = 6;
            // * Verify this with Eulicia
            $active_account->PINPOINT = 1;
            $active_account->ON_HOLD = 1;
            $active_account->ACCT_AGENT = null;
            $active_account->save();
            return redirect()->route('powerleadForm')->with('success', 'Account Updated');
        }

        $fax = 0;
        $email = 0;
        if ($request->website != '') {
            $domain = $request->website;
            $pos = null;
            if (($pos = stripos($domain, 'www.')) !== FALSE) {
                $domain = substr($domain, $pos+4);
            } else if (($pos = stripos($domain, '://')) !== FALSE) {
                $domain = substr($domain, $pos+3);
            }
            $data = $this->hottyDomainSearch($domain);
            if ($data->found == 1) {
                $email = 1;
                $prefix = $data->prefix;
                $emailAddress = $prefix . '@' . $domain;
                $power_account->email = $emailAddress;
                $this->sendDottyAutoEmail($emailAddress, $request->employer_name, $active_account, 0, $date, $agent_id, 1, 'powerlead');
            }
        }

        if ($email == 0) {
            if($request->fax != '') {
                $fax = 1;
                $power_account->fax = preg_replace('/[^A-Za-z0-9\-]/', '', $request->fax);
                $this->sendBottyAutoFax($request->fax, $request->employer_name, $active_account, $email, $date, $agent_id, 'powerlead');
            }

            if($request->email != '') {
                $email = 1;
                $power_account->email = $request->email;
                $this->sendDottyAutoEmail($request->email, $request->employer_name, $active_account, $fax, $date, $agent_id, 0, 'powerlead');
            }
        }

        if ($email != 1 && $fax != 1)
            $this->sendToDirectoryLiveQueue($power_account, $active_account);

        $power_account->verified = 1;
        $power_account->save();
        $active_account->ON_HOLD = 1;
        $active_account->POWERLEAD_CAPCODE = 5;
        $active_account->save();
        return redirect()->route('powerleadForm')->with('success', 'Account Found');
    }

    private function sendToDirectoryLiveQueue($power_account, $active_account) {
        $name = $power_account->employer_name;
        $empmatchname = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $name);
        $empmatchname = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));

        // Directory account w/ name match exists (this should never happen, but just to be safe...)
        if (!empty($checkNameMatch = Directory_Active_Account::where('name_match', $empmatchname)->first())) {
            $active_account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
            $active_account->save();
            return;
        } else if (!empty($checkNameMatch = Directory_Inactive_Account::where('name_match', $empmatchname)->first())) {
            $active_account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
            $active_account->ON_HOLD = 0;
            $active_account->save();
            return;
        }

        $directoryAccount = new Directory_Active_Account();
        $directoryAccount->live_flag = 1;
        $directoryAccount->fresh_flag = 1;
        $directoryAccount->due_date = date('Y-m-d h:i:s', strtotime("+3 weekdays"));
        $directoryAccount->employer_name = $name;
        $directoryAccount->name_match = $empmatchname;

        $directoryAccount->empl_org_phone = $power_account->main_phone;
        $directoryAccount->direct_phone = $power_account->local_phone;
        $directoryAccount->company_website = $power_account->website;
        $directoryAccount->address = $power_account->local_address ?? $power_account->employer_address;

        $directoryAccount->save();

        $active_account->DIRECTORY_LINK = $directoryAccount->directory_account_id;
    }

    public function powerleadSearchAccount(request $request)
    {
        $user = User::find(Auth::user()->user_id);
        if($user->role == 'powerlead')
            $agent_id = $user->powerlead_link->id;
        else
            $agent_id = $request->powerlead_agent_id;
        $employer_name = $request->powerlead_employer_name;
        $powerlead_id = $request->powerlead_id;
        $rocky_id = $request->rocky_id;

        $accounts = Powerlead_Accounts::
            selectRaw('powerlead_accounts.id as powerlead_id, powerlead_accounts.active_account_id as account_id, active_accounts.EMPL_NAME as active_name, inactive_accounts.EMPL_NAME as inactive_name')
            ->when($agent_id, function ($query, $agent_id) {
                return $query->where('powerlead_accounts.powerlead_agent_id', $agent_id);
            })
            ->when($employer_name, function ($query, $employer_name) {
                return $query->whereRaw('(active_accounts.EMPL_NAME like "%'.$employer_name.'%" OR inactive_accounts.EMPL_NAME like "%'.$employer_name.'%")');
            })
            ->when($powerlead_id, function ($query, $powerlead_id) {
                return $query->where('powerlead_accounts.id', $powerlead_id);
            })
            ->when($rocky_id, function ($query, $rocky_id) {
                return $query->where('powerlead_accounts.active_account_id', $rocky_id);
            })
            ->leftJoin('active_accounts', function ($join) {
                $join->on('powerlead_accounts.id', '=', 'active_accounts.POWERLEAD_ID');
            })
            ->leftJoin('inactive_accounts', function ($join) {
                $join->on('powerlead_accounts.id', '=', 'inactive_accounts.POWERLEAD_ID');
            })
            ->limit(10000)->get();

        return view('/powerlead/pages/searchResults')->with('accounts', $accounts);
    }
}