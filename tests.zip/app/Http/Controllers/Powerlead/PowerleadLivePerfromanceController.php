<?php

namespace App\Http\Controllers\Powerlead;


use App\Http\Controllers\Controller;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\User;
use Auth;
use Carbon\Carbon;
use DB;
use Illuminate\Http\Request;

class PowerleadLivePerfromanceController extends Controller
{
    public function getLivePeformanceReport(Request $request)
    {
        if($request->end_date == null)
            $end_date = date("Y-m-d");
        else
            $end_date = date('Y-m-d', strtotime($request->end_date));
            
        if($request->start_date == null)
            $start_date = $end_date;
        else
            $start_date = date('Y-m-d', strtotime($request->start_date));
        
        if($end_date != $start_date)
            $timeMessage = "from ".$start_date." to ".$end_date;
        else
            $timeMessage = "from ".$start_date;

        $user = User::find(Auth::user()->user_id);

        $work_historys = Powerlead_Accounts::selectRaw("powerlead_agent_id AS AGENT_ID, COUNT(ID) AS TOTAL_WORKED, SUM(timespent)/COUNT(ID) AS AVERAGE_TIME, SUM(timespent) TOTAL_TIME,
        COUNT(IF(verified = 1,1,NULL)) AS 'TOTAL_VERIFIED'")
        ->whereRaw("updated_at >= DATE('$start_date') AND updated_at <= DATE_ADD('$end_date', INTERVAL 1 DAY) AND verified is not null AND POWERLEAD_AGENT_ID IS NOT NULL")
        ->groupBy('powerlead_agent_id')->get();

        $agents = Powerlead::select('id', 'user_id')->whereRaw("date(created_at) <= '$end_date'")->with('user_link')->get();

        $livePerformance = [];
        $work_history = $work_historys->where('AGENT_ID', $user->powerlead_link->id)->first();
        
        //if the agent has no history create a blank history
        if($work_history == null){
            $livePerformance[] = array(
                "AGENT_ID" => $user->powerlead_link->id,
                "AGENT_NAME" => $user->first_name . " " . $user->last_name,
                "TOTAL_WORKED" => 0,
                "AVERAGE_TIME_SPENT" => '0:00',
                "TOTAL_TIME" => '00:00:00',
                "UNVERIFIED" => 0,
                "VERIFIED" => 0,
                "AVERAGE_VERIFIED" => "0%",
                "AVERAGE_NOT_FOUND" => "0%",
            );
        }
        //otherwise just fill in the history data
        else{
            $average_time_spent = $this->getAverageTime($work_history->AVERAGE_TIME);
            $totalTime = $this->getTotalTime($work_history->TOTAL_TIME);

            $average_verified = $work_history->TOTAL_VERIFIED / $work_history->TOTAL_WORKED;
            $average_verified = round(100 * $average_verified, 0). "%";
            $unverified = $work_history->TOTAL_WORKED - $work_history->TOTAL_VERIFIED;
            $average_not_found = round(100 * $unverified / $work_history->TOTAL_WORKED, 0)."%";

            $fullPowerleadName = $user->first_name." ".$user->last_name;

            //sets data for the graph
            $livePerformance[] = array(
                "AGENT_ID" => $work_history->AGENT_ID,
                "AGENT_NAME" => $fullPowerleadName,
                "TOTAL_WORKED" => $work_history->TOTAL_WORKED,
                "AVERAGE_TIME_SPENT" => $average_time_spent,
                "TOTAL_TIME" => $totalTime,
                "UNVERIFIED" => $unverified,
                "VERIFIED" => $work_history->TOTAL_VERIFIED,
                "AVERAGE_VERIFIED" => $average_verified,
                "AVERAGE_NOT_FOUND" => $average_not_found,
            );
        }
        
        $chart_livePerformance = [];
        if (!empty($work_historys)) {
            foreach ($work_historys as $work_history) {
                $power_agent = $agents->where('id', $work_history->AGENT_ID)->first(); 
                if (!empty($power_agent)) {
                    $unverified = $work_history->TOTAL_WORKED - $work_history->TOTAL_VERIFIED;
                    $chart_livePerformance[] = array(
                        $power_agent->user_link->first_name . " " . $power_agent->user_link->last_name,
                        $unverified,
                        $unverified,
                        $work_history->TOTAL_VERIFIED,
                        $work_history->TOTAL_VERIFIED,
                    );
                }
            }
        }

        $startDateFormatted = Carbon::parse($start_date)->format('m/d/Y');
        $endDateFormatted = Carbon::parse($end_date)->format('m/d/Y');
        return view('/powerlead/pages/livePeformanceReport')->with('livePerformances', $livePerformance)->with('start_date', $startDateFormatted)->with('end_date', $endDateFormatted)->with('timeMessage', $timeMessage)->with('chart_livePerformance', $chart_livePerformance);
    }

    public function getAverageTime($timeSeconds){
        $average_time_spent_minutes = (int) ($timeSeconds/60);
        $average_time_spent_seconds =  (int) ($timeSeconds%60);
        if ($average_time_spent_seconds < 10)
            $average_time_spent_seconds = "0" . $average_time_spent_seconds;
        return $average_time_spent_minutes . ":" . $average_time_spent_seconds;
    }

    public function getTotalTime($timeSeconds){
        $times = [];
        $times[] = (int) ($timeSeconds % 60);
        $times[] = (int) (($timeSeconds/60)%60);
        $times[] = (int) (($timeSeconds/60)/60);
        for($i = 0; $i < 3; $i++){
            if($times[$i] < 10)
                $times[$i] = "0".$times[$i];
        }
        return $times[2].":".$times[1].":".$times[0];
    }
}