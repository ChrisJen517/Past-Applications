<?php

namespace App\Http\Middleware;

use Auth;
use Closure;

class CheckCorporationId
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        
        if ($request->hasAny('corporation_id')) {
            if (Auth::user()->role == 'corporate_admin') {
                if ($request->corporation_id != Auth::User()->corporate_admin_link->corporation_id) {
                    abort(403, 'Unauthorized action.');
                }
            }
            else if (Auth::user()->role == 'manager') {
                if ($request->corporation_id != Auth::User()->manager_link->corporation_id) {
                    abort(403, 'Unauthorized action.');
                }
            }
            else if (Auth::user()->role == 'directory_agent') {
                if ($request->corporation_id != Auth::User()->directory_agent_link->corporation_id) {
                    abort(403, 'Unauthorized action.');
                }
            }
            else if (Auth::user()->role == 'agent') {
                if ($request->corporation_id != Auth::User()->agent_link->corporation_id) {
                    abort(403, 'Unauthorized action.');
                }
            }
            else if (Auth::user()->role == 'powerlead') {
                if ($request->corporation_id != Auth::User()->powerlead_link->corporation_id) {
                    abort(403, 'Unauthorized action.');
                }
            }
            
            else if (Auth::user()->role == 'powerlead_directory_manager') {
                if ($request->corporation_id != Auth::User()->powerlead_link->corporation_id) {
                    abort(403, 'Unauthorized action.');
                }
            }
        }
        return $next($request);
    }
}
