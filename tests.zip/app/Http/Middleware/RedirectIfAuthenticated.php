<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::guard($guard)->check()) 
        {

            if(Auth::user()->valid_password == 0)
                return redirect('/changePassword');
            else if(strtolower(Auth::user()->role) == 'admin')
            {   
                if((strtotime(Auth::user()->updated_at)-strtotime(date('Y-m-d')))/86400 == 55)
                    return redirect('/index')->with('message', 'Your password will expire in 5 days.');
                return redirect('/index');
            }
            else if(strtolower(Auth::user()->role) == 'agent')
            {
                if((strtotime(Auth::user()->updated_at)-strtotime(date('Y-m-d')))/86400 == 55)
                    return redirect('/indexAgent')->with('message', 'Your password will expire in 5 days.');
                return redirect('/indexAgent');
            }
            else if(strtolower(Auth::user()->role) == 'vendor')
            {
                if((strtotime(Auth::user()->updated_at)-strtotime(date('Y-m-d')))/86400 == 55)
                    return redirect('/indexVendor')->with('message', 'Your password will expire in 5 days.');
                return redirect('/indexVendor');
           
            }
        }

        return $next($request);
    }
}
