<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\AgentDistribution::class,
        Commands\DirectoryDistribution::class,
        Commands\RockyImportActiveAccounts::class,
        Commands\RockyImportWorkedHistory::class,
        Commands\ClearWorkedHistory::class,
        Commands\RockyExportClosedAccounts::class,
        Commands\RockyExportWorkHistory::class,
        Commands\RockyExportActiveAccounts::class,
        Commands\RockyExportWorkedHistoryUpdate::class,
        Commands\RockyImportClosedAccounts::class,
        Commands\RockyExportClosedAccountsUpdate::class,
        Commands\RockyExportActiveAccountsUpdate::class,
        Commands\RockyImportClosedAccountsMorning::class,
        Commands\RockyImportDirAccounts::class,
        Commands\RockyImportPowerlead::class,
        Commands\RemovePastDue::class,
        Commands\RockyExportHourlyBreakdown::class,
        Commands\PowerleadCreateAccounts::class,
        Commands\SendNewBottieDottieFaxes::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        /////////////////////////////////////////////
        //MORNING IMPORTS////////////////////////////
        /////////////////////////////////////////////
        // $schedule->command('command:RockyImportDirAccounts')
        //     ->weekdays()
        //     ->dailyAt('8:11')
        //     ->timezone('America/New_York');

        // $schedule->command('command:RockyImportPowerlead')
        //     ->weekdays()
        //     ->dailyAt('8:13')
        //     ->timezone('America/New_York');

        $schedule->command('command:RockyImportActiveAccounts')
            ->weekdays()
            ->dailyAt('8:15')
            ->timezone('America/New_York');

        $schedule->command('command:RockyImportClosedAccountsMorning')
            ->weekdays()
            ->dailyAt('8:18')
            ->timezone('America/New_York');

        $schedule->command('command:RockyImportWorkedHistory')
            ->weekdays()
            ->dailyAt('8:20')
            ->timezone('America/New_York');

        $schedule->command('command:PowerleadCreateAccounts')
            ->weekdays()
            ->everyFiveMinutes()
            ->timezone('America/New_York');

        // $schedule->command('command:SendNewBottieDottieFaxes')
        //     ->weekdays()
        //     ->dailyAt('18:45')
        //     ->timezone('America/New_York');

        $schedule->command('command:RockyImportActiveAccountsWaterfall')
            ->everyFiveMinutes()
            ->timezone('America/New_York');


        /////////////////////////////////////////////
        //RECURRING IMPORTS//////////////////////////
        /////////////////////////////////////////////
        // $schedule->command('command:RockyImportClosedAccounts')
        //     ->weekdays()
        //     ->everyFifteenMinutes()
        //     ->timezone('America/New_York')
        //     ->between('9:15', '19:00');



        /////////////////////////////////////////////
        //DAILY EXPORTS//////////////////////////////
        /////////////////////////////////////////////
        $schedule->command('command:RockyExportClosedAccounts')
            ->weekdays()
            ->dailyAt('21:00')
            ->timezone('America/New_York');

        $schedule->command('command:RockyExportWorkHistory')
            ->weekdays()
            ->dailyAt('21:05')
            ->timezone('America/New_York');

        $schedule->command('command:RockyExportActiveAccounts')
            ->weekdays()
            ->dailyAt('21:10')
            ->timezone('America/New_York');



        /////////////////////////////////////////////
        //RECURRING EXPORTS//////////////////////////
        /////////////////////////////////////////////
        $schedule->command('command:RockyExportWorkedHistoryUpdate')
            ->weekdays()
            ->everyFifteenMinutes()
            ->timezone('America/New_York')
            ->between('8:43', '19:00');

        $schedule->command('command:RockyExportClosedAccountsUpdate')
            ->weekdays()
            ->everyFifteenMinutes()
            ->timezone('America/New_York')
            ->between('8:43', '19:00');

        $schedule->command('command:RockyExportActiveAccountsUpdate')
            ->weekdays()
            ->everyFifteenMinutes()
            ->timezone('America/New_York')
            ->between('8:43', '19:00');



        /////////////////////////////////////////////
        //REPORTING EXPORTS//////////////////////////
        /////////////////////////////////////////////
        // $schedule->command('command:RockyExportHourlyBreakdown')
        //     ->weekdays()
        //     ->hourly()
        //     ->timezone('America/New_York')
        //     ->between('9:00', '19:00');



        /////////////////////////////////////////////
        //NIGHTLY JOBS///////////////////////////////
        /////////////////////////////////////////////
        $schedule->command('command:RemovePastDue')
            ->weekdays()
            ->dailyAt('23:50')
            ->timezone('America/New_York');

        $schedule->command('command:RemoveDirectoryPassDue')
            ->weekdays()
            ->dailyAt('23:50')
            ->timezone('America/New_York');

        /////////////////////////////////////////////
        //MORNING JOBS///////////////////////////////
        /////////////////////////////////////////////
        $schedule->command('command:UnblockNearDueDateAccounts')
            ->weekdays()
            ->dailyAt('7:45')
            ->timezone('America/New_York');

        $schedule->command('command:BottieAndDottieRemoval')
            ->weekdays()
            ->dailyAt('8:00')
            ->timezone('America/New_York');

        /////////////////////////////////////////////
        //JOBS //////////////////////////////////////
        /////////////////////////////////////////////
        $schedule->command('command:Send_Fax')
            ->weekdays()
            ->everyMinute()
            ->timezone('America/New_York');

        $schedule->command('command:AgentDistribution')
            ->weekdays()
            ->everyFiveMinutes()
            ->timezone('America/New_York');

        $schedule->command('command:DirectoryDistribution')
            ->weekdays()
            ->everyFifteenMinutes()
            ->timezone('America/New_York')
            ->between('9:15', '19:00');
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
