<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Config;
use App\Jobs\RemovePastDueJobQueue;
use App\Models\Corporation;
use Illuminate\Foundation\Bus\Dispatchable;

class RemovePastDue extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RemovePastDue';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Remove Past Due Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->removePastDue();
    }

    public function removePastDue(){
        $corporations = Corporation::get();
        foreach($corporations as $corporation){
            RemovePastDueJobQueue::dispatch($corporation->corporation_id);
            
        }
        RemovePastDueJobQueue::dispatch(2);
    }
}
