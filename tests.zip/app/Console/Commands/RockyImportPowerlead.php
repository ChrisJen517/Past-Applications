<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyImportPowerlead extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyImportPowerlead';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Powerlead Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->ImportOldRocky();
        $this->uploadAAFile();
    }
    public function ImportOldRocky(){
        $nowStart = Carbon::now()->format('Y_m_d');
        $path = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'');
        }
        $fileDestination = '/public_html/contract/sync/PL_LAST30.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/PL_LAST30.csv';
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        // return ftp_nlist($conn_id, "/public_html/contract/ACTIVE_ACCOUNTS_Special.csv");

        // upload a file
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        // return $file;
        // close the connection
        ftp_close($conn_id);

       $file = fopen($filename, "r");
       $line = fgets($file);

    }

    public function uploadAAFile(){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        $table_name = 'powerlead_account_upload';

        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        $nowStart = Carbon::now()->format('Y_m_d');
        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/PL_LAST30.csv';
        // Setting up reading file that is uploaded
        $file = new \SplFileObject($fileName);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {
            if($rows == 0){
                foreach($row as $header)
                {
                        $headers[] = $header;
                }
            }
        break;
        }

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $duplicate_key = '';
        $count = 0;
        $lastHead = '';
        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
              $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";
        }

        $insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);

        // Dropping table if one previously existed
        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
        // Creating a temp table to upload CSV file
        $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));

        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
          PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));

        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);
        $insert_statement = "active_account_id, powerlead_agent_id, employer_name, local_phone, local_address, website, main_phone, employer_address, fax, email, verified, updated_at, timespent";
        $insert_statement_CSV = "`$table_name`.`active_account_id`, `$table_name`.`powerlead_agent_id`, `$table_name`.`employer_name`, `$table_name`.`local_phone`, `$table_name`.`local_address`, `$table_name`.`website`, `$table_name`.`main_phone`, `$table_name`.`employer_address`, `$table_name`.`fax`, `$table_name`.`email`, `$table_name`.`verified`, `$table_name`.`updated_at`, `$table_name`.`timespent`";

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' CHANGE UID active_account_id VARCHAR(90),
            CHANGE PL_AGENT powerlead_agent_id VARCHAR(90),
            CHANGE EMPL_NAME employer_name VARCHAR(90),
            CHANGE LOCAL_PHONE local_phone VARCHAR(90),
            CHANGE ADDR_LEAD local_address VARCHAR(90),
            CHANGE EMPL_WEBSITE website VARCHAR(90),
            CHANGE PHONE_CORP main_phone VARCHAR(90),
            CHANGE ADDR_CORP employer_address VARCHAR(90),
            CHANGE EMPL_FAX fax VARCHAR(90),
            CHANGE EMPL_EMAIL email VARCHAR(90),
            CHANGE CAPCODE verified VARCHAR(90),
            CHANGE LAST_UPDATE updated_at VARCHAR(90),
            CHANGE SECONDS_WORKED timespent VARCHAR(90),
            DROP PHONE_TYPE,
            DROP ADD_TYPE,
            DROP POESCORE;'));

        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET verified = 0 WHERE verified != 111"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET verified = 1 WHERE verified = 111"));

        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 549 WHERE powerlead_agent_id = 517;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 547 WHERE powerlead_agent_id = 513;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 553 WHERE powerlead_agent_id = 520;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 524 WHERE powerlead_agent_id = 524;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 552 WHERE powerlead_agent_id = 512;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 529 WHERE powerlead_agent_id = 518;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 528 WHERE powerlead_agent_id = 522;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 546 WHERE powerlead_agent_id = 523;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 548 WHERE powerlead_agent_id = 529;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 527 WHERE powerlead_agent_id = 514;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 523 WHERE powerlead_agent_id = 515;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 526 WHERE powerlead_agent_id = 530;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 551 WHERE powerlead_agent_id = 526;"));
        DB::SELECT(DB::RAW("UPDATE ".$table_name." SET powerlead_agent_id = 525 WHERE powerlead_agent_id = 532;"));

        // Inserting the columns from the CSV file that are requested into our database.
        DB::select( DB::raw("INSERT IGNORE INTO powerlead_accounts
                    ($insert_statement)
                    SELECT
                $insert_statement_CSV
                FROM `$table_name`"));
    }

}
