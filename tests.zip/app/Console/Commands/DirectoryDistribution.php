<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Traits\DirectoryAgentAccounts;
use App\Models\Directory_Setting;

class DirectoryDistribution extends Command
{
    use DirectoryAgentAccounts;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:DirectoryDistribution';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Distribute Directory Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $settings = Directory_Setting::first();

        //if redistribute is turned off
        if($settings->redistribute_accounts == 0)
            return;
        $this->distributeDirectory();
    }
}