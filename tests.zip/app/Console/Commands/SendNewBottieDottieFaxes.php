<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use App\Traits\Autobot;
use Config;

class SendNewBottieDottieFaxes extends Command
{
    use Autobot;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:SendNewBottieDottieFaxes';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send New Faxes and Emails';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $new_accounts = DB::SELECT(DB::RAW("SELECT * FROM active_accounts WHERE DATE(CREATED_AT) = CURDATE() ORDER BY CREATED_AT;"));
        $date = date('Y-m-d H:i:s');
        foreach($new_accounts as $account)
        {
            if($account->ACCT_AGENT == 1901 && $account->CREATED_AT >= date('Y-m-d')){
                $this->sendBottyAutoFax($account->EMPL_FAX, $account->EMPL_NAME, $account, 0, $date, 1901, 'import');
            } 
            else if($account->ACCT_AGENT == 1902 && $account->CREATED_AT >= date('Y-m-d')){
                $this->sendDottyAutoEmail($account->EMPL_EMAIL, $account->EMPL_NAME, $account, 0, $date, 1902, 0, 'import');
            }
        }
    }
}