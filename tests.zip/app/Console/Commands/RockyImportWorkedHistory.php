<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyImportWorkedHistory extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyImportWorkedHistory';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Worked History';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        //$this->ImportOldWorkedHistoryRocky();
        $this->uploadWorkedHistory();
    }


    public function ImportOldWorkedHistoryRocky(){
        $now = Carbon::now()->format('Y_m_d');
        $path = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/Maintence/'.$now.'');
        }
        $fileDestination = '/public_html/contract/sync/WORK_HISTORY.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'/WORK_HISTORY.csv';
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        // return ftp_nlist($conn_id, "/public_html/contract/ACTIVE_ACCOUNTS_Special.csv");

        // upload a file
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        // return $file;
        // close the connection
        ftp_close($conn_id);

       $file = fopen($filename, "r");
       $line = fgets($file);

    }

    public function uploadWorkedHistory(){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        $yesterday = Carbon::yesterday()->format('Y-m-d');
        $table_name = 'test_upload_work_history';

        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        $now = Carbon::now()->format('Y_m_d');

        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/'.$now.'/WORK_HISTORY.csv';
        // $fileName = public_path('WORK_HISTORY.csv');

        // Setting up reading file that is uploaded
        $file = new \SplFileObject($fileName);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {
            if($rows == 0){
                foreach($row as $header)
                {
                        $headers[] = $header;
                }
            }
            break;
        }

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';

        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
            if($head == 'WORK_COMMENTS' ){
                $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` text, ";
            }else{
                $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";
            }
        }
        $insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);
        $insert_statement = "ALT_ID, created_at, agent_id, capcode, notes";
        $insert_statement_CSV = "`$table_name`.`ALT_ID`, `$table_name`.`created_at`, `$table_name`.`agent_id`, `$table_name`.`capcode`, `$table_name`.`notes`";

        // Dropping table if one previously existed
        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));

        // Creating a temp table to upload CSV file
        $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));

        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
          PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));

        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `user_role` varchar(45) NOT NULL DEFAULT '' AFTER `$head`;
        "));
        $head = 'user_role';
        $insert_statement = $insert_statement.", ".$head;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$head."`";

        DB::select( DB::raw("ALTER TABLE `$table_name`
        ADD COLUMN `old_rocky` INT(11) NOT NULL DEFAULT 1 AFTER `$head`;
        "));
        $head = 'old_rocky';
        $insert_statement = $insert_statement.", ".$head;
        $insert_statement_CSV = $insert_statement_CSV.", `$table_name`.`".$head."`";

        DB::select( DB::raw("CREATE INDEX CAPCODE_INDEX ON `$table_name` (capcode);"));

        DB::SELECT(DB::RAW("UPDATE `$table_name`  SET capcode = NULL WHERE capcode = 0 or capcode = '';"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` TT INNER JOIN capcodes CT ON TT.capcode = CT.capcode SET TT.capcode = CT.id;"));

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP ACCT_CLIENT,
            DROP ACCT_COE, DROP ACCT_CASE, DROP ACCT_DUE_DATE, DROP ACCT_ID,
            DROP ACCT_SSN, DROP ACCT_SOURCE, DROP EMPL_NAME, DROP EMPL_ADDR1,
            DROP EMPL_ADDR2, DROP EMPL_CITY, DROP EMPL_ST, DROP EMPL_ZIP,
            DROP EMPL_PHONE1_NMBR, DROP WORK_AGENT, DROP EMPL_FAX,
            DROP EMPL_EMAIL, DROP EMPL_TITLE, DROP EMPL_CONTACT,
            DROP EMPL_CONTACT_TITLE, DROP QUICK_DIAL, DROP POESCORE, DROP EMPL_FILES,
            CHANGE UID ALT_ID VARCHAR(90),
            CHANGE ADD_DATE created_at VARCHAR(90),
            CHANGE ACCT_AGENT agent_id VARCHAR(90),
            CHANGE CAPCODE capcode VARCHAR(90),
            CHANGE WORK_COMMENTS notes text'));

        DB::select( DB::raw("CREATE INDEX JOIN_INDEX ON `$table_name` (created_at, agent_id, capcode);"));

        DB::SELECT(DB::RAW("UPDATE `$table_name` SET user_role = 'agent' WHERE agent_id > 2999 and agent_id < 7000;"));
        DB::SELECT(DB::RAW("DELETE tn.* FROM `$table_name` tn INNER JOIN `worked_history` wh ON wh.active_account_id=tn.ALT_ID WHERE wh.created_at=tn.created_at;"));

        DB::select( DB::raw("ALTER TABLE `$table_name` ADD `id` INT NOT NULL AUTO_INCREMENT PRIMARY KEY;"));

        $duplicates = DB::SELECT(DB::RAW("SELECT a.id
                            FROM $table_name a
                            JOIN (SELECT ALT_ID, notes, created_at, capcode, agent_id, updated_at
                            FROM worked_history
                            GROUP BY ALT_ID, created_at
                            ) b
                            ON a.ALT_ID = b.ALT_ID
                            AND a.created_at = b.created_at
                            AND a.capcode = b.capcode
                            AND a.created_at != b.updated_at
                            ORDER BY a.ALT_ID;"));

        $this->removeDuplicates($duplicates, $table_name);

        $duplicates = DB::SELECT(DB::RAW("SELECT a.id
                            FROM $table_name a
                            JOIN worked_history b
                            ON a.created_at = b.created_at
                            AND a.agent_id = b.agent_id
                            AND a.capcode = b.capcode
                            where a.agent_id not in (1901, 1902, 1904);"));

        $this->removeDuplicates($duplicates, $table_name);

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP id'));

        // Inserting the columns from the CSV file that are requested into our database.
        DB::select( DB::raw('INSERT IGNORE INTO worked_history
                        ('.$insert_statement.')
                        SELECT
                    '.$insert_statement_CSV.'
                    FROM `'.$table_name.'`'));

        DB::SELECT(DB::RAW("UPDATE worked_history wh INNER JOIN active_accounts aa ON wh.ALT_ID = aa.ALT_ID SET wh.active_account_id = aa.ID WHERE wh.active_account_id is null"));
        DB::SELECT(DB::RAW("UPDATE worked_history wh INNER JOIN inactive_accounts aa ON wh.ALT_ID = aa.ALT_ID SET wh.active_account_id = aa.ID WHERE wh.active_account_id is null"));
        DB::SELECT(DB::RAW("UPDATE `active_accounts` aa set aa.LAST_WORKED = null where (select count(*) from worked_history wh where aa.ID = wh.active_account_id and wh.agent_id not in (1901,1902,1904)) = 0 and LAST_WORKED IS NOT NULL AND TEAM_ID != 10;"));
    }


    public function removeDuplicates($duplicates, $table_name){
        if(!empty($duplicates))
        {
            $to_delete = [];
            foreach($duplicates as $account) {
                $to_delete[] = $account->id;
            }

            if(!empty($to_delete))
                DB::SELECT(DB::RAW("DELETE FROM $table_name WHERE id IN (".implode(', ', $to_delete).");"));
        }
    }
}
