<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Fax_Queue;
use DB;
use App\Jobs\TeamDistrubutionQueue;
use Storage;
use Dompdf\Dompdf;
use Config;

class UnblockNearDueDateAccounts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:UnblockNearDueDateAccounts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send faxes from rocky agents';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->unblockAccounts();
    }

    public function unblockAccounts()
    {
        $weekFromToday = date('Y-m-d', strtotime('+7 days'));

        DB::SELECT(DB::RAW("UPDATE active_accounts SET ON_HOLD = 0 WHERE 
            ON_HOLD = 1 AND (PINPOINT = 0 OR PINPOINT IS NULL) AND CORPORATION_ID = 2 AND ACCT_DUE_DATE <= '$weekFromToday';"));
    }
}