<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use PHPMailer\PHPMailer\PHPMailer;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyExportWorkHistory extends Command
{
        /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyExportWorkHistory';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export Worked History';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->ExportWorkedHistory();
    }

    public function ExportWorkedHistory()
    {
        $filename = '/home/rocky/public_html/rocky-sync/worked_history.csv';
        $fileDestination = '/public_html/contract/sync-outbound/worked_history.csv';
        $date = Carbon::now()->subDays(2)->format('Y-m-d h:i:s');

         DB::SELECT(DB::RAW("
         UPDATE worked_history wh inner join active_accounts aa ON aa.ID = wh.active_account_id SET wh.ALT_ID = aa.ALT_ID WHERE aa.ALT_ID NOT IN (3581581,3621203,3667884,3667762,3665499,3666078,3656111,3617402,3567537,3657537,3662782,3661223,3628991,3589450,3663090,3664968,3667852,3646042,3645701,3625221,3632155 ,3658627,3631362,3605400,3636746,3640818,3604228,3660086,3666181,3621403,3622027,3632795,3621370,3621524,3622510,3609899,3620274,3662650,3589335,3638304,3619617,3633073,3661256,3661759,3619007,3669615,3669600,3666873,3672997);"));
         DB::SELECT(DB::RAW("
         UPDATE worked_history wh inner join inactive_accounts aa ON aa.ID = wh.active_account_id SET wh.ALT_ID = aa.ALT_ID WHERE aa.ALT_ID NOT IN (3581581,3621203,3667884,3667762,3665499,3666078,3656111,3617402,3567537,3657537,3662782,3661223,3628991,3589450,3663090,3664968,3667852,3646042,3645701,3625221,3632155 ,3658627,3631362,3605400,3636746,3640818,3604228,3660086,3666181,3621403,3622027,3632795,3621370,3621524,3622510,3609899,3620274,3662650,3589335,3638304,3619617,3633073,3661256,3661759,3619007,3669615,3669600,3666873,3672997);
         "));

        $closed_accounts = DB::select(DB::raw(
            "SELECT worked_history.ALT_ID as 'UID', worked_history.created_at as 'ADD_DATE', 
            active_accounts.ACCT_CLIENT, active_accounts.TEAM_NAME AS ACCT_COE, 
            active_accounts.ACCT_AGENT, active_accounts.ACCT_CASE, 
            active_accounts.ACCT_DUE_DATE, active_accounts.ACCT_SSN, 
            active_accounts.ACCT_ID, active_accounts.ACCT_SOURCE, 
            active_accounts.EMPL_NAME, active_accounts.EMPL_ADDR1, 
            active_accounts.EMPL_ADDR2, active_accounts.EMPL_CITY, 
            active_accounts.EMPL_ST, active_accounts.EMPL_ZIP, 
            active_accounts.EMPL_PHONE1_NMBR, active_accounts.EMPL_FAX, 
            active_accounts.EMPL_EMAIL, active_accounts.EMPL_TITLE, 
            active_accounts.EMPL_CONTACT, active_accounts.EMPL_CONTACT_TITLE, 
            (SELECT capcode from capcodes WHERE worked_history.CAPCODE = capcodes.id AND corporation_id = 2) as CAPCODE, 
            notes as 'WORK_COMMENTS', active_accounts.POESCORE, active_accounts.EMPL_FILES, worked_history.agent_id  
            FROM worked_history INNER JOIN active_accounts ON worked_history.active_account_id = active_accounts.ID WHERE CORPORATION_ID = 2 AND DATE(worked_history.created_at) > '$date' AND worked_history.agent_id != 0  ORDER BY worked_history.created_at ASC;"
        ));

        $closed_inactive_accounts = DB::select(DB::RAW("SELECT worked_history.ALT_ID as 'UID', worked_history.created_at as 'ADD_DATE', 
        inactive_accounts.ACCT_CLIENT, inactive_accounts.TEAM_NAME AS ACCT_COE, 
        inactive_accounts.ACCT_AGENT, inactive_accounts.ACCT_CASE, 
        inactive_accounts.ACCT_DUE_DATE, inactive_accounts.ACCT_SSN, 
        inactive_accounts.ACCT_ID, inactive_accounts.ACCT_SOURCE, 
        inactive_accounts.EMPL_NAME, inactive_accounts.EMPL_ADDR1, 
        inactive_accounts.EMPL_ADDR2, inactive_accounts.EMPL_CITY, 
        inactive_accounts.EMPL_ST, inactive_accounts.EMPL_ZIP, 
        inactive_accounts.EMPL_PHONE1_NMBR, inactive_accounts.EMPL_FAX, 
        inactive_accounts.EMPL_EMAIL, inactive_accounts.EMPL_TITLE, 
        inactive_accounts.EMPL_CONTACT, inactive_accounts.EMPL_CONTACT_TITLE, 
        (SELECT capcode from capcodes WHERE worked_history.CAPCODE = capcodes.id AND corporation_id = 2) as CAPCODE, 
        notes as 'WORK_COMMENTS', inactive_accounts.POESCORE, inactive_accounts.EMPL_FILES, worked_history.agent_id
        FROM worked_history INNER JOIN inactive_accounts ON worked_history.active_account_id = inactive_accounts.ID WHERE CORPORATION_ID = 2 AND DATE(worked_history.created_at) > '$date' AND worked_history.agent_id != 0  ORDER BY worked_history.created_at ASC;"));

        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ADD_DATE,ACCT_CLIENT,ACCT_COE,ACCT_AGENT,ACCT_CASE,ACCT_DUE_DATE,ACCT_SSN,ACCT_ID,ACCT_SOURCE,EMPL_NAME,'.
        'EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR,EMPL_FAX,EMPL_EMAIL,EMPL_TITLE,EMPL_CONTACT,EMPL_CONTACT_TITLE,CAPCODE,WORK_COMMENTS,POESCORE,EMPL_FILES,WORK_AGENT';
        fwrite($file, $headerString);

        foreach ($closed_accounts as $account) {    
            $WORK_COMMENTS = trim(preg_replace('/\s\s+/', ' ', $account->WORK_COMMENTS));
            $WORK_COMMENTS = str_replace(',', '', $WORK_COMMENTS);      
            $rowString = "\r\n" .
                $account->UID . ',' .
                $account->ADD_DATE . ',' .
                str_replace(',', '', $account->ACCT_CLIENT) . ',' .
                str_replace(',', '', $account->ACCT_COE) . ',' .
                $account->ACCT_AGENT . ',' .
                str_replace(',', '', $account->ACCT_CASE) . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $account->ACCT_ID . ',' .
                str_replace(',', '', $account->ACCT_SOURCE) . ',' .
                str_replace(',', '', $account->EMPL_NAME) . ',' .
                str_replace(',', '', $account->EMPL_ADDR1) . ',' .
                str_replace(',', '', $account->EMPL_ADDR2) . ',' .
                str_replace(',', '', $account->EMPL_CITY) . ',' .
                str_replace(',', '', $account->EMPL_ST) . ',' .
                str_replace(',', '', $account->EMPL_ZIP) . ',' .
                str_replace(',', '', $account->EMPL_PHONE1_NMBR) . ',' .
                str_replace(',', '', $account->EMPL_FAX) . ',' .
                str_replace(',', '', $account->EMPL_EMAIL) . ',' .
                str_replace(',', '', $account->EMPL_TITLE) . ',' .
                str_replace(',', '', $account->EMPL_CONTACT) . ',' .
                str_replace(',', '', $account->EMPL_CONTACT_TITLE) . ',' .
                $account->CAPCODE . ',' .
                $WORK_COMMENTS . ',' .
                $account->POESCORE . ',' .
                str_replace(',', '', $account->EMPL_FILES). ','.
                $account->agent_id;
                fwrite($file, $rowString);
            //fputcsv($file, $account);
        }

        foreach ($closed_inactive_accounts as $account) {    
            $WORK_COMMENTS = trim(preg_replace('/\s\s+/', ' ', $account->WORK_COMMENTS));
            $WORK_COMMENTS = str_replace(',', '', $WORK_COMMENTS);      
            $rowString = "\r\n" .
                $account->UID . ',' .
                $account->ADD_DATE . ',' .
                str_replace(',', '', $account->ACCT_CLIENT) . ',' .
                str_replace(',', '', $account->ACCT_COE) . ',' .
                $account->ACCT_AGENT . ',' .
                str_replace(',', '', $account->ACCT_CASE) . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $account->ACCT_ID . ',' .
                str_replace(',', '', $account->ACCT_SOURCE) . ',' .
                str_replace(',', '', $account->EMPL_NAME) . ',' .
                str_replace(',', '', $account->EMPL_ADDR1) . ',' .
                str_replace(',', '', $account->EMPL_ADDR2) . ',' .
                str_replace(',', '', $account->EMPL_CITY) . ',' .
                str_replace(',', '', $account->EMPL_ST) . ',' .
                str_replace(',', '', $account->EMPL_ZIP) . ',' .
                str_replace(',', '', $account->EMPL_PHONE1_NMBR) . ',' .
                str_replace(',', '', $account->EMPL_FAX) . ',' .
                str_replace(',', '', $account->EMPL_EMAIL) . ',' .
                str_replace(',', '', $account->EMPL_TITLE) . ',' .
                str_replace(',', '', $account->EMPL_CONTACT) . ',' .
                str_replace(',', '', $account->EMPL_CONTACT_TITLE) . ',' .
                $account->CAPCODE . ',' .
                $WORK_COMMENTS . ',' .
                $account->POESCORE . ',' .
                str_replace(',', '', $account->EMPL_FILES).','.
                $account->agent_id;
                fwrite($file, $rowString);
            //fputcsv($file, $account);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
//return ftp_nlist($conn_id, ".");
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }

        // close the connection
        ftp_close($conn_id);
    }
}
