<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Traits\AccountDistrubution;
use PHPMailer\PHPMailer\PHPMailer;
use Config;

class AgentDistribution extends Command
{
    use AccountDistrubution;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:AgentDistribution';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Distribute Agent Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->setAgentQueueByTeam(5);
        //$this->setAgentQueueByTeam(9);
        //$this->setAgentQueueByTeam(8);
        //$this->setAgentQueueByTeam(11);
    }
}
