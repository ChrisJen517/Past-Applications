<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use PHPMailer\PHPMailer\PHPMailer;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyExportClosedAccountsUpdate extends Command
{
        /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyExportClosedAccountsUpdate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export Closed Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->ExportClosedAccounts();
    }

    public function ExportClosedAccounts()
    {
        $nowStart = Carbon::now()->format('Y_m_d');
        $now = Carbon::now()->format('Y_m_d_h_i');

        $path = '/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'');
        }
        $path = '/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'/'.$now.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'/'.$now.'');
        }
        $filename = '/home/rocky/public_html/rocky-sync/closed_accounts.csv';
        $fileDestination = '/public_html/contract/real-time-outbound/closed_accounts.csv';
        $fileDestination2 = '/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'/'.$now.'/closed_accounts.csv';

        $now = Carbon::now();
        $now = $now->format('Y-m-d');

        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ADD_DATE,ADD_FILE,ADDED_BY,ACCT_CLIENT,ACCT_COE,ACCT_AGENT,' .
            'ACCT_CASE,ACCT_DUE_DATE,ACCT_SSN,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,' .
            'ACCT_DOB,ACCT_ID,ACCT_SOURCE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR,EMPL_FAX,EMPL_EMAIL,EMPL_TITLE,' .
            'EMPL_CONTACT,EMPL_CONTACT_TITLE,CAPCODE,LAST_WORKED,LAST_EMPL_NAME,LAST_EMPL_ADDR,LAST_EMPL_PHONE,LAST_EMPL_EMAIL,LAST_EMPL_FAX,' .
            'LAST_COMMENTS,TIME_ZONE,MISC,DIR_ID,WORK_COMMENTS,LAST_SEEN,POESCORE,EMPL_FILES,TIER,REMINDER';
        fwrite($file, $headerString);

        $closed_accounts = DB::select(DB::raw(
            "SELECT inactive_accounts.ALT_ID, inactive_accounts.ADD_DATE, inactive_accounts.ADD_FILE, inactive_accounts.ADDED_BY, inactive_accounts.ACCT_CLIENT, inactive_accounts.TEAM_NAME, inactive_accounts.ACCT_AGENT, inactive_accounts.ACCT_CASE, inactive_accounts.ACCT_DUE_DATE, inactive_accounts.ACCT_SSN,
            inactive_accounts.ACCT_FIRST_NAME, inactive_accounts.ACCT_LAST_NAME,
            inactive_accounts.ACCT_AD1, inactive_accounts.ACCT_AD2,
            inactive_accounts.ACCT_CITY, inactive_accounts.ACCT_ST,
            inactive_accounts.ACCT_ZIP, inactive_accounts.ACCT_DOB,
            inactive_accounts.ACCT_ID, inactive_accounts.ACCT_SOURCE, 
            verified_hits.employer_name, verified_hits.employer_address_1, 
            verified_hits.employer_address_2, verified_hits.employer_city, 
            verified_hits.employer_state, verified_hits.employer_zip, 
            verified_hits.employer_phone, verified_hits.employer_fax,   
            verified_hits.employer_email, verified_hits.employer_title,
            verified_hits.verification_contact_name,
            verified_hits.verification_contact_title,
            verified_hits.future_verification_phone, verified_hits.future_verification_auto_phone,
            verified_hits.future_verification_fax, verified_hits.future_verification_email,
            (SELECT capcode from capcodes WHERE inactive_accounts.CAPCODE = capcodes.id AND corporation_id = 2) as capcode,
            inactive_accounts.LAST_WORKED, inactive_accounts.LAST_EMPL_NAME,
            inactive_accounts.LAST_EMPL_ADDR, inactive_accounts.LAST_EMPL_PHONE,
            inactive_accounts.LAST_EMPL_EMAIL, inactive_accounts.LAST_EMPL_FAX,
            inactive_accounts.LAST_COMMENTS, inactive_accounts.TIME_ZONE, null as empty, inactive_accounts.DIRECTORY_ALT_LINK, inactive_accounts.LAST_COMMENTS, null as empty2, inactive_accounts.POESCORE, null as empty3, inactive_accounts.TIER, inactive_accounts.REMINDER 
            FROM inactive_accounts INNER JOIN verified_hits ON inactive_accounts.VERIFIED_HITS_ID = verified_hits.id WHERE inactive_accounts.CORPORATION_ID = 2 AND DATE(LAST_WORKED) = '$now' AND inactive_accounts.CAPCODE IN (SELECT id from capcodes where `type` = 'verified');"
        ));

        $this->addAccountsToCSV($closed_accounts, $file);

        $closed_accounts = DB::select(DB::raw(
            "SELECT inactive_accounts.ALT_ID, inactive_accounts.ADD_DATE, inactive_accounts.ADD_FILE, inactive_accounts.ADDED_BY, inactive_accounts.ACCT_CLIENT, inactive_accounts.TEAM_NAME, inactive_accounts.ACCT_AGENT, inactive_accounts.ACCT_CASE, inactive_accounts.ACCT_DUE_DATE, inactive_accounts.ACCT_SSN,
            inactive_accounts.ACCT_FIRST_NAME, inactive_accounts.ACCT_LAST_NAME,
            inactive_accounts.ACCT_AD1, inactive_accounts.ACCT_AD2,
            inactive_accounts.ACCT_CITY, inactive_accounts.ACCT_ST,
            inactive_accounts.ACCT_ZIP, inactive_accounts.ACCT_DOB,
            inactive_accounts.ACCT_ID, inactive_accounts.ACCT_SOURCE, 
            inactive_accounts.EMPL_NAME AS employer_name, inactive_accounts.EMPL_ADDR1 AS employer_address_1, 
            inactive_accounts.EMPL_ADDR2 AS employer_address_2, inactive_accounts.EMPL_CITY AS employer_city, 
            inactive_accounts.EMPL_ST AS employer_state, inactive_accounts.EMPL_ZIP AS employer_zip, 
            inactive_accounts.EMPL_PHONE1_NMBR AS employer_phone, inactive_accounts.EMPL_FAX AS employer_fax,   
            inactive_accounts.EMPL_EMAIL AS employer_email, inactive_accounts.EMPL_TITLE AS employer_title,
            inactive_accounts.EMPL_CONTACT AS verification_contact_name,
            inactive_accounts.EMPL_CONTACT_TITLE AS verification_contact_title,
            '' AS future_verification_phone, '' AS future_verification_auto_phone,
            '' AS future_verification_fax, '' AS future_verification_email,
            (SELECT capcode from capcodes WHERE inactive_accounts.CAPCODE = capcodes.id AND corporation_id = 2) as capcode,
            inactive_accounts.LAST_WORKED, inactive_accounts.LAST_EMPL_NAME,
            inactive_accounts.LAST_EMPL_ADDR, inactive_accounts.LAST_EMPL_PHONE,
            inactive_accounts.LAST_EMPL_EMAIL, inactive_accounts.LAST_EMPL_FAX,
            inactive_accounts.LAST_COMMENTS, inactive_accounts.TIME_ZONE, null as empty, inactive_accounts.DIRECTORY_ALT_LINK, inactive_accounts.LAST_COMMENTS, null as empty2, inactive_accounts.POESCORE, null as empty3, inactive_accounts.TIER, inactive_accounts.REMINDER 
            FROM inactive_accounts  WHERE inactive_accounts.CORPORATION_ID = 2 AND DATE(LAST_WORKED) = '$now' AND inactive_accounts.CAPCODE NOT IN (SELECT id from capcodes where `type` = 'verified');"
        ));

        $this->addAccountsToCSV($closed_accounts, $file);


        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
            
        if(copy($filename, $fileDestination2)) {
            echo "It worked!!!";
          }
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }

        // close the connection
        ftp_close($conn_id);
    }

    public function addAccountsToCSV($closed_accounts, $file){
        foreach ($closed_accounts as $account) {

            //add future verification auto phone first
            if($account->future_verification_auto_phone == null || $account->future_verification_auto_phone == ''){
                if($account->future_verification_phone == null || $account->future_verification_phone == ''){
                    $employer_phone = str_replace(',', '', $account->employer_phone);
                }else{
                    $employer_phone = str_replace(',', '', $account->future_verification_phone);
                }   
            }else{
                $employer_phone = str_replace(',', '', $account->future_verification_auto_phone);
            }

            if($account->future_verification_fax == null || $account->future_verification_fax == ''){
                $employer_fax = str_replace(',', '', $account->employer_fax);
            }else{
                $employer_fax = str_replace(',', '', $account->future_verification_fax);
            }

            if($account->future_verification_email == null || $account->future_verification_email == ''){
                $employer_email = str_replace(',', '', $account->employer_email);
            }else{
                $employer_email = str_replace(',', '', $account->future_verification_email);
            }

            //prior future options first
            $ADD_FILE = str_replace(',', '', $account->ADD_FILE);
            $ADDED_BY = str_replace(',', '', $account->ADDED_BY);
            $ACCT_CLIENT = str_replace(',', '', $account->ACCT_CLIENT);
            $TEAM_NAME = str_replace(',', '', $account->TEAM_NAME);
            $ACCT_CASE = str_replace(',', '', $account->ACCT_CASE);
            $ACCT_FIRST_NAME = str_replace(',', '', $account->ACCT_FIRST_NAME);
            $ACCT_LAST_NAME = str_replace(',', '', $account->ACCT_LAST_NAME);
            $ACCT_AD1 = str_replace(',', '', $account->ACCT_AD1);
            $ACCT_AD2 = str_replace(',', '', $account->ACCT_AD2);
            $ACCT_CITY = str_replace(',', '', $account->ACCT_CITY);
            $ACCT_ST = str_replace(',', '', $account->ACCT_ST);
            $ACCT_SOURCE = str_replace(',', '', $account->ACCT_SOURCE);
            $employer_name = str_replace(',', '', $account->employer_name);
            $employer_address_1 = str_replace(',', '', $account->employer_address_1);
            $employer_address_2 = str_replace(',', '', $account->employer_address_2);
            $employer_city = str_replace(',', '', $account->employer_city);
            $employer_state = str_replace(',', '', $account->employer_state);
            $employer_zip = str_replace(',', '', $account->employer_zip);
            $employer_title = str_replace(',', '', $account->employer_title);
            $verification_contact_name = str_replace(',', '', $account->verification_contact_name);
            $verification_contact_title = str_replace(',', '', $account->verification_contact_title);
            $LAST_EMPL_NAME = str_replace(',', '', $account->LAST_EMPL_NAME);
            $LAST_EMPL_ADDR = str_replace(',', '', $account->LAST_EMPL_ADDR);
            $LAST_EMPL_PHONE = str_replace(',', '', $account->LAST_EMPL_PHONE);
            $LAST_EMPL_EMAIL = str_replace(',', '', $account->LAST_EMPL_EMAIL);
            $LAST_EMPL_FAX = str_replace(',', '', $account->LAST_EMPL_FAX);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $TIME_ZONE = str_replace(',', '', $account->TIME_ZONE);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $REMINDER = str_replace(',', '', $account->REMINDER);
            $rowString = "\r\n" .
                $account->ALT_ID . ',' .
                $account->ADD_DATE . ',' .
                $ADD_FILE . ',' .
                $ADDED_BY . ',' .
                $ACCT_CLIENT . ',' .
                $TEAM_NAME . ',' .
                $account->ACCT_AGENT . ',' .
                $ACCT_CASE . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $ACCT_FIRST_NAME . ',' .
                $ACCT_LAST_NAME . ',' .
                $ACCT_AD1 . ',' .
                $ACCT_AD2 . ',' .
                $ACCT_CITY . ',' .
                $ACCT_ST . ',' .
                $account->ACCT_ZIP . ',' .
                $account->ACCT_DOB . ',' .
                $account->ACCT_ID . ',' .
                $ACCT_SOURCE . ',' .
                $employer_name . ',' .
                $employer_address_1 . ',' .
                $employer_address_2 . ',' .
                $employer_city . ',' .
                $employer_state . ',' .
                $employer_zip . ',' .
                $employer_phone . ',' .
                $employer_fax . ',' .
                $employer_email . ',' .
                $employer_title . ',' .
                $verification_contact_name . ',' .
                $verification_contact_title . ',' .
                $account->capcode . ',' .
                $account->LAST_WORKED . ',' .
                $LAST_EMPL_NAME . ',' .
                $LAST_EMPL_ADDR . ',' .
                $LAST_EMPL_PHONE . ',' .
                $LAST_EMPL_EMAIL . ',' .
                $LAST_EMPL_FAX . ',' .
                $LAST_COMMENTS . ',' .
                $TIME_ZONE . ',' .
                $account->empty . ',' .
                $account->DIRECTORY_ALT_LINK . ',' .
                $LAST_COMMENTS . ',' .
                $account->empty2 . ',' .
                $account->POESCORE . ',' .
                $account->empty3 . ',' .
                $account->TIER . ',' .
                $REMINDER;
                fwrite($file, $rowString);
        }
    }
}
