<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyImportDirAccounts extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyImportDirAccounts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Directory Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {   
        $this->ImportOldRocky();
        $this->uploadAAFile();
    }
    public function ImportOldRocky(){
        $nowStart = Carbon::now()->format('Y_m_d');
        $now = Carbon::now()->format('Y_m_d_h_i');
        $path = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'');
        }
        $fileDestination = '/public_html/contract/sync/EMPL_DIR_EXPORT.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/EMPL_DIR_EXPORT.csv';
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        // return ftp_nlist($conn_id, "/public_html/contract/ACTIVE_ACCOUNTS_Special.csv");

        // upload a file
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        // return $file;
        // close the connection
        ftp_close($conn_id);

       $file = fopen($filename, "r");
       $line = fgets($file);
        
    }

    public function uploadAAFile(){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 

        $table_name = 'directory_account_upload';
  
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        $nowStart = Carbon::now()->format('Y_m_d');
        $now = Carbon::now()->format('Y_m_d_h_i');
        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/EMPL_DIR_EXPORT.csv';
        // Setting up reading file that is uploaded
        $file = new \SplFileObject($fileName);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {   
            if($rows == 0){
                foreach($row as $header)
                {   
                        $headers[] = $header;
                }
            }
        break;
        }

        $insert_statement_temp_table = '';
        $insert_statement = '';
        $insert_statement_CSV ='';
        $duplicate_key = '';
        $count = 0;
        $lastHead = '';
        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
        {
              $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";           
        }
        $insert_statement_temp_table = $insert_statement_temp_table."`last_worked` VARCHAR( 90 )";

        //$insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);

        // Dropping table if one previously existed
        $DropStart = DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
        // Creating a temp table to upload CSV file
        $data = DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));
  
        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
          PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));
  
        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);
        $insert_statement = "dir_alt_id, directory_agent_id, employer_name, address, empl_address_2, city, state, zip, empl_org_phone, employer_type, total_employees, direct_phone, verification_phone, verification_fax, verification_email, third_party_name, third_party_account_number, company_website, verification_contact, verification_contact_title, verification_mailing_adress, verification_notes, work_notes, capcode, last_worked";
        $insert_statement_CSV = "`$table_name`.`dir_alt_id`, `$table_name`.`directory_agent_id`, `$table_name`.`employer_name`, `$table_name`.`address`, `$table_name`.`empl_address_2`, `$table_name`.`city`, `$table_name`.`state`, `$table_name`.`zip`, `$table_name`.`empl_org_phone`, `$table_name`.`employer_type`, `$table_name`.`total_employees`, `$table_name`.`direct_phone`, `$table_name`.`verification_phone`, `$table_name`.`verification_fax`, `$table_name`.`verification_email`, `$table_name`.`third_party_name`, `$table_name`.`third_party_account_number`, `$table_name`.`company_website`, `$table_name`.`verification_contact`, `$table_name`.`verification_contact_title`, `$table_name`.`verification_mailing_adress`, `$table_name`.`verification_notes`, `$table_name`.`work_notes`, `$table_name`.`capcode`, `$table_name`.`last_worked`";

        DB::SELECT(DB::RAW("ALTER TABLE $table_name CHANGE DIR_ID dir_alt_id VARCHAR(90),
            CHANGE ACCT_AGENT directory_agent_id VARCHAR(90),
            CHANGE EMPL_NAME employer_name VARCHAR(90),
            CHANGE EMPL_ADDR1 address VARCHAR(90),
            CHANGE EMPL_ADDR2 empl_address_2 text,
            CHANGE EMPL_CITY city VARCHAR(90),
            CHANGE EMPL_STATE state VARCHAR(90),
            CHANGE EMPL_ZIP zip VARCHAR(90),
            CHANGE EMPL_ORG_PHONE empl_org_phone VARCHAR(90),
            CHANGE EMPL_TYPE employer_type text,
            CHANGE EMPL_TOTAL_EMP total_employees VARCHAR(90),
            CHANGE DIRECT_PHONE direct_phone VARCHAR(90),
            CHANGE VER_PHONE verification_phone VARCHAR(90),
            CHANGE VER_FAX verification_fax VARCHAR(90),
            CHANGE VER_EMAIL verification_email text,
            CHANGE VER_3RD_PARTY_NAME third_party_name VARCHAR(90),
            CHANGE VER_3RD_PARTY_NUMBER third_party_account_number text,
            CHANGE `URL` company_website VARCHAR(90),
            CHANGE VER_CONTACT verification_contact text,
            CHANGE VER_CONTACT_TITLE verification_contact_title VARCHAR(90),
            CHANGE VER_ADDRESS verification_mailing_adress text,
            CHANGE VER_NOTES verification_notes VARCHAR(90),
            CHANGE WORK_NOTES work_notes text,
            CHANGE CAPCODE capcode VARCHAR(90);"));

        DB::select( DB::raw("CREATE INDEX capcode_INDEX ON `$table_name` (capcode);"));

        //removes zero or blank as rocky does not use null, and sets the capcode to it's id on the table
        DB::SELECT(DB::RAW("UPDATE $table_name SET capcode = NULL WHERE capcode = 0 OR capcode = '';"));  
        DB::SELECT(DB::RAW("UPDATE $table_name TT INNER JOIN directory_capcodes DC ON DC.capcode = TT.capcode SET TT.capcode = DC.capcode_id WHERE TT.capcode NOT IN (1119, 1120);"));    


        DB::SELECT(DB::RAW("DELETE $table_name FROM $table_name INNER JOIN directory_inactive_accounts ON $table_name.dir_alt_id = directory_inactive_accounts.dir_alt_id WHERE $table_name.dir_alt_id = directory_inactive_accounts.dir_alt_id;"));


        // Inserting the columns from the CSV file that are requested into our database.
        DB::select( DB::raw('INSERT IGNORE INTO directory_active_accounts 
                ('.$insert_statement.')
                SELECT 
            '.$insert_statement_CSV.'
            FROM `'.$table_name.'`'));


        //remove long insert to check if it 
        DB::SELECT(DB::RAW("INSERT IGNORE INTO `directory_inactive_accounts` (SELECT * FROM directory_active_accounts WHERE dir_alt_id IN ((SELECT dir_alt_id FROM $table_name)));"));

        DB::SELECT(DB::RAW("UPDATE `directory_active_accounts` set last_worked = null WHERE last_worked = '0000-00-00 00:00:00' OR last_worked = ''"));

        DB::SELECT(DB::RAW("DELETE directory_active_accounts FROM directory_active_accounts INNER JOIN $table_name ON directory_active_accounts.dir_alt_id = $table_name.dir_alt_id WHERE directory_active_accounts.dir_alt_id = $table_name.dir_alt_id;"));
    }
    
}