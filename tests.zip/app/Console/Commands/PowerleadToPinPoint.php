<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Jobs\PowerleadCreateAccountsQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Config;
use App\Models\Active_Account;
use App\Models\Inactive_Account;
use DB;
use App\Traits\WriteToLog;
use App\Models\Powerlead_Settings;

class PowerleadToPinpoint extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:PowerleadToPinpoint';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Creates a new csv to upload to be set to pinpoint';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //12 minutes

        $startDate = date('Y-m-d', strtotime('-1 week'));
        $dueDate = date('Y-m-d', strtotime('+2 weeks'));
        $filename = '/home/rocky/public_html/rocky-sync/to_pinpoint_export.csv';
        $fileDestination = '/public_html/contract/sync-outbound/to_pinpoint_export.csv';
        $corporation_id = 2;

        if (file_exists($filename)) 
            unlink($filename);
            
        $file = fopen($filename, 'w+');
        $headerString = 'ACCT_CLIENT,ACCT_CASE,ACCT_SSN,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,ACCT_DOB,ACCT_ID,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR';
        fwrite($file, $headerString);

        $accounts = DB::select(DB::raw("SELECT ACCT_CLIENT, ACCT_CASE, ACCT_SSN, ACCT_FIRST_NAME, ACCT_LAST_NAME, ACCT_AD1, ACCT_AD2, ACCT_CITY, 
            ACCT_ST, ACCT_ZIP, ACCT_DOB, ACCT_ID, EMPL_NAME, EMPL_ADDR1, EMPL_ADDR2, EMPL_CITY, EMPL_ST, EMPL_ZIP, EMPL_PHONE1_NMBR FROM active_accounts
            inner join powerlead_accounts on active_accounts.POWERLEAD_ID = powerlead_accounts.id
            where powerlead_accounts.updated_at >= '$startDate' and DATE(ACCT_DUE_DATE) <= '$dueDate' and pinpoint = 1 and powerlead_accounts.verified = 0"));

        foreach ($accounts as $account) {  
            $rowString = "\r\n";
            foreach( $account as $value ){
                $rowString = $rowString.str_replace(array("\n", "\r", ","), '', $value).',';
            }
            fwrite($file, $rowString);
        }

        $accounts = DB::select(DB::raw("SELECT ACCT_CLIENT, ACCT_CASE, ACCT_SSN, ACCT_FIRST_NAME, ACCT_LAST_NAME, ACCT_AD1, ACCT_AD2, ACCT_CITY, 
            ACCT_ST, ACCT_ZIP, ACCT_DOB, ACCT_ID, EMPL_NAME, EMPL_ADDR1, EMPL_ADDR2, EMPL_CITY, EMPL_ST, EMPL_ZIP, EMPL_PHONE1_NMBR FROM inactive_accounts
            inner join powerlead_accounts on inactive_accounts.POWERLEAD_ID = powerlead_accounts.id
            where powerlead_accounts.updated_at >= '$startDate' and DATE(ACCT_DUE_DATE) <= '$dueDate' and pinpoint = 1 and powerlead_accounts.verified = 0"));

        foreach ($accounts as $account) {     
            $rowString = "\r\n";
            foreach( $account as $value ){
                $rowString = $rowString.str_replace(array("\n", "\r", ","), '', $value).',';
            }
            fwrite($file, $rowString);
        }

        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);

        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }
        echo "\nSuccessfully Exported\n";
        // close the connection
        ftp_close($conn_id);
    }
}