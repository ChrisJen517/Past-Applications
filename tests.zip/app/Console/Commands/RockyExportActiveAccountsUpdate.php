<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyExportActiveAccountsUpdate extends Command
{
        /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyExportActiveAccountsUpdate';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export Active Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->ExportActiveAccounts();
    }

    public function ExportActiveAccounts()
    {
        $nowStart = Carbon::now()->format('Y_m_d');
        $now = Carbon::now()->format('Y_m_d_h_i');

        $path = '/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'');
        }
        $path = '/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'/'.$now.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'/'.$now.'');
        }
        $filename = '/home/rocky/public_html/rocky-sync/active_accounts.csv';
        $fileDestination = '/public_html/contract/real-time-outbound/active_accounts.csv';
        $fileDestination2 = '/home/rocky/public_html/rocky-sync/exports/'.$nowStart.'/'.$now.'/active_accounts.csv';

        $now = Carbon::now();
        $now = $now->subMinutes(15);
        $now = $now->format('Y-m-d h:i:s');

        $closed_accounts = DB::select(DB::raw(
            "SELECT active_accounts.ALT_ID, active_accounts.ADD_DATE, active_accounts.ADD_FILE, active_accounts.ADDED_BY, active_accounts.ACCT_CLIENT, active_accounts.TEAM_NAME, active_accounts.ACCT_AGENT, active_accounts.ACCT_CASE, active_accounts.ACCT_DUE_DATE, active_accounts.ACCT_SSN,
            active_accounts.ACCT_FIRST_NAME, active_accounts.ACCT_LAST_NAME,
            active_accounts.ACCT_AD1, active_accounts.ACCT_AD2,
            active_accounts.ACCT_CITY, active_accounts.ACCT_ST,
            active_accounts.ACCT_ZIP, active_accounts.ACCT_DOB,
            active_accounts.ACCT_ID, active_accounts.ACCT_SOURCE, 
            active_accounts.EMPL_NAME, active_accounts.EMPL_ADDR1, 
            active_accounts.EMPL_ADDR2, active_accounts.EMPL_CITY, 
            active_accounts.EMPL_ST, active_accounts.EMPL_ZIP, 
            active_accounts.EMPL_PHONE1_NMBR, active_accounts.EMPL_FAX,   
            active_accounts.EMPL_EMAIL, active_accounts.EMPL_TITLE,
            active_accounts.EMPL_CONTACT, active_accounts.ON_HOLD,
            active_accounts.EMPL_CONTACT_TITLE, 
            (SELECT capcode from capcodes WHERE active_accounts.CAPCODE = capcodes.id AND corporation_id = 2) as capcode,
            active_accounts.LAST_WORKED, active_accounts.LAST_EMPL_NAME,
            active_accounts.LAST_EMPL_ADDR, active_accounts.LAST_EMPL_PHONE,
            active_accounts.LAST_EMPL_EMAIL, active_accounts.LAST_EMPL_FAX,
            active_accounts.LAST_COMMENTS, active_accounts.TIME_ZONE, null as empty, active_accounts.DIRECTORY_ALT_LINK, active_accounts.LAST_COMMENTS, null as empty2, active_accounts.POESCORE, null as empty3, active_accounts.TIER, active_accounts.REMINDER, active_accounts.PINPOINT, active_accounts.ON_HOLD
            FROM active_accounts WHERE active_accounts.CORPORATION_ID = 2"
        ));

        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ADD_DATE,ADD_FILE,ADDED_BY,ACCT_CLIENT,ACCT_COE,ACCT_AGENT,' .
            'ACCT_CASE,ACCT_DUE_DATE,ACCT_SSN,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,' .
            'ACCT_DOB,ACCT_ID,ACCT_SOURCE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_NMBR,EMPL_FAX,EMPL_EMAIL,EMPL_TITLE,' .
            'EMPL_CONTACT,EMPL_CONTACT_TITLE,CAPCODE,LAST_WORKED,LAST_EMPL_NAME,LAST_EMPL_ADDR,LAST_EMPL_PHONE,LAST_EMPL_EMAIL,LAST_EMPL_FAX,' .
            'LAST_COMMENTS,TIME_ZONE,MISC,DIR_ID,WORK_COMMENTS,LAST_SEEN,POESCORE,EMPL_FILES,TIER,REMINDER';
        fwrite($file, $headerString);

        foreach ($closed_accounts as $account) {          
            
            if($account->PINPOINT == 1){
                $ACCT_AGENT = 'OVERFLOWED';
            }elseif($account->ACCT_AGENT == 9999){
                $ACCT_AGENT = 'SCOREHOLD';
            }elseif($account->ACCT_AGENT == 3333){
                $ACCT_AGENT = 'RECALLED';
            }elseif(($account->ACCT_AGENT == '' || $account->ACCT_AGENT == null) && $account->ON_HOLD == 0){
                $ACCT_AGENT = '7783';
            }else{
                $ACCT_AGENT = $account->ACCT_AGENT;
            }
            $ADD_FILE = str_replace(',', '', $account->ADD_FILE);
            $ADDED_BY = str_replace(',', '', $account->ADDED_BY);
            $ACCT_CLIENT = str_replace(',', '', $account->ACCT_CLIENT);
            $TEAM_NAME = str_replace(',', '', $account->TEAM_NAME);
            $ACCT_CASE = str_replace(',', '', $account->ACCT_CASE);
            $ACCT_FIRST_NAME = str_replace(',', '', $account->ACCT_FIRST_NAME);
            $ACCT_LAST_NAME = str_replace(',', '', $account->ACCT_LAST_NAME);
            $ACCT_AD1 = str_replace(',', '', $account->ACCT_AD1);
            $ACCT_AD2 = str_replace(',', '', $account->ACCT_AD2);
            $ACCT_CITY = str_replace(',', '', $account->ACCT_CITY);
            $ACCT_ST = str_replace(',', '', $account->ACCT_ST);
            $ACCT_SOURCE = str_replace(',', '', $account->ACCT_SOURCE);
            $employer_name = str_replace(',', '', $account->EMPL_NAME);
            $employer_address_1 = str_replace(',', '', $account->EMPL_ADDR1);
            $employer_address_2 = str_replace(',', '', $account->EMPL_ADDR2);
            $employer_city = str_replace(',', '', $account->EMPL_CITY);
            $employer_state = str_replace(',', '', $account->EMPL_ST);
            $employer_zip = str_replace(',', '', $account->EMPL_ZIP);
            $employer_phone = str_replace(',', '', $account->EMPL_PHONE1_NMBR);
            $employer_fax = str_replace(',', '', $account->EMPL_FAX);
            $employer_email = str_replace(',', '', $account->EMPL_EMAIL);
            $employer_title = str_replace(',', '', $account->EMPL_TITLE);
            $verification_contact_name = str_replace(',', '', $account->EMPL_CONTACT);
            $verification_contact_title = str_replace(',', '', $account->EMPL_CONTACT_TITLE);
            $LAST_EMPL_NAME = str_replace(',', '', $account->LAST_EMPL_NAME);
            $LAST_EMPL_ADDR = str_replace(',', '', $account->LAST_EMPL_ADDR);
            $LAST_EMPL_PHONE = str_replace(',', '', $account->LAST_EMPL_PHONE);
            $LAST_EMPL_EMAIL = str_replace(',', '', $account->LAST_EMPL_EMAIL);
            $LAST_EMPL_FAX = str_replace(',', '', $account->LAST_EMPL_FAX);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $TIME_ZONE = str_replace(',', '', $account->TIME_ZONE);
            $LAST_COMMENTS = str_replace(',', '', $account->LAST_COMMENTS);
            $REMINDER = str_replace(',', '', $account->REMINDER);
            $rowString = "\r\n" .
                $account->ALT_ID . ',' .
                $account->ADD_DATE . ',' .
                $ADD_FILE . ',' .
                $ADDED_BY . ',' .
                $ACCT_CLIENT . ',' .
                $TEAM_NAME . ',' .
                $ACCT_AGENT . ',' .
                $ACCT_CASE . ',' .
                $account->ACCT_DUE_DATE . ',' .
                $account->ACCT_SSN . ',' .
                $ACCT_FIRST_NAME . ',' .
                $ACCT_LAST_NAME . ',' .
                $ACCT_AD1 . ',' .
                $ACCT_AD2 . ',' .
                $ACCT_CITY . ',' .
                $ACCT_ST . ',' .
                $account->ACCT_ZIP . ',' .
                $account->ACCT_DOB . ',' .
                $account->ACCT_ID . ',' .
                $ACCT_SOURCE . ',' .
                $employer_name . ',' .
                $employer_address_1 . ',' .
                $employer_address_2 . ',' .
                $employer_city . ',' .
                $employer_state . ',' .
                $employer_zip . ',' .
                $employer_phone . ',' .
                $employer_fax . ',' .
                $employer_email . ',' .
                $employer_title . ',' .
                $verification_contact_name . ',' .
                $verification_contact_title . ',' .
                $account->capcode . ',' .
                $account->LAST_WORKED . ',' .
                $LAST_EMPL_NAME . ',' .
                $LAST_EMPL_ADDR . ',' .
                $LAST_EMPL_PHONE . ',' .
                $LAST_EMPL_EMAIL . ',' .
                $LAST_EMPL_FAX . ',' .
                $LAST_COMMENTS . ',' .
                $TIME_ZONE . ',' .
                $account->empty . ',' .
                $account->DIRECTORY_ALT_LINK . ',' .
                $LAST_COMMENTS . ',' .
                $account->empty2 . ',' .
                $account->POESCORE . ',' .
                $account->empty3 . ',' .
                $account->TIER . ',' .
                $REMINDER;
                fwrite($file, $rowString);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);


        if(copy($filename, $fileDestination2)) {
            echo "It worked!!!";
          }
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }

        // close the connection
        ftp_close($conn_id);
    }

}
