<?php

namespace App\Console\Commands;

use App\Http\Controllers\ExportReporting\ImportController;
use Illuminate\Console\Command;
use Carbon\Carbon;

class RockyExportHourlyBreakdown extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyExportHourlyBreakdown';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export the hourly breakdown by COE and send an email.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $minutes = Carbon::now()->diffInMinutes(Carbon::parse(Carbon::now()->format("Y-m-d") . ' 08:30:00'));
        $hours = $minutes/60;
        $controller = new ImportController();
        $controller->sendExport($hours);
    }
}
