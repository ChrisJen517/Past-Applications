<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Jobs\PowerleadCreateAccountsQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Config;
use App\Models\Active_Account;
use DB;
use App\Traits\WriteToLog;
use App\Models\Powerlead_Settings;

class PowerleadCreateAccounts extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:PowerleadCreateAccounts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Create new Powerlead accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $neededPowerleadAccounts = Active_Account::select('ID', 'POESCORE')
            ->where('POWERLEAD_FLAG', 1)->whereNull('POWERLEAD_ID')
            ->orderBy('CREATED_AT')
            ->limit('1000')
            ->get();

        $startTime = date('Y-m-d h:i:s');

        $numberOfAccounts = count($neededPowerleadAccounts);

        if($numberOfAccounts == 0){
            return;
        }

        $newAccountsStatement = "";
        foreach($neededPowerleadAccounts as $account){
            $newAccountsStatement = $newAccountsStatement." ('".$account->ID."', '".$startTime."', '".$startTime."'),";
        }
        $newAccountsStatement = substr_replace($newAccountsStatement ,"", -1);

        DB::select(DB::raw("INSERT INTO `powerlead_accounts` (active_account_id, updated_at, created_at) VALUES ".$newAccountsStatement.";"));

        DB::SELECT( DB::RAW("UPDATE `active_accounts` 
                    INNER JOIN `powerlead_accounts` PLA ON active_accounts.ID = PLA.active_account_id
                    SET active_accounts.UPDATED_AT = '".$startTime."', active_accounts.POWERLEAD_ID = PLA.id,
                    active_accounts.POWERLEAD_CAPCODE = 2
                    WHERE PLA.created_at = '".$startTime."';"));

        $powerlead_settings = Powerlead_Settings::first();

        DB::SELECT( DB::RAW("UPDATE `active_accounts` 
            INNER JOIN `powerlead_accounts` PLA ON active_accounts.ID = PLA.active_account_id
            SET active_accounts.POWERLEAD_CAPCODE = 1
            WHERE PLA.created_at = '".$startTime."' AND POESCORE < ".$powerlead_settings->hold_accounts_below_score.";"));
    }
}