<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\Fax_Queue;
use DB;
use App\Jobs\TeamDistrubutionQueue;
use Storage;
use Dompdf\Dompdf;
use Config;

class Send_Fax extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:Send_Fax';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send faxes from rocky agents';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->setUpFax();
    }

    public function setUpFax()
    {
        $fax_account = '';
        if(!empty(Fax_Queue::where('sent', 0)->orderBy('created_at', 'ASC')->first())){
            $fax_account = Fax_Queue::where('sent', 0)->orderBy('created_at', 'ASC')->first();
        }else{
            return;
        }

        $ssn = $fax_account->ACCT_SSN;
        $question = 'Contact for Verifying Employment';
        $body = 'We are reaching out today to ask for your help to verify employment on the individual below, or direct us to the appropriate contact. Thank you in advance for your time.';

        $first_name = ucfirst($fax_account->ACCT_FIRST_NAME);
        $last_name = ucfirst($fax_account->ACCT_LAST_NAME);
        $full_name = $first_name . ' ' . $last_name;
        $full_name = strtolower($full_name);
        $full_name = ucwords($full_name);

        $employer_name = '';

        if (!empty($fax_account->EMPL_NAME)) {
            $employer_name = $fax_account->EMPL_NAME;
        }

        $AGENT_ID = '';
        if (!empty($fax_account->AGENT_ID)) {
            $AGENT_ID = " - ".$fax_account->AGENT_ID;
        }

        $acct_id = '';
        if (!empty($fax_account->account_id)) {
            $acct_id = $fax_account->account_id;
        }

        $to_fax = '1' . $fax_account->EMPL_FAX . '@nextivafax.com';

        $recipient = $employer_name;
        $recipient_fax = $fax_account->EMPL_FAX;
        $availableFaxNumbers = ['678-609-7024', '678-819-2829', '678-826-0103', '770-336-6632', '470-552-2824', '770-741-0982'];
        $availableFaxLine = ['employmentverification1@rnngroup.com', 'employmentverification2@rnngroup.com', 'employmentverification3@rnngroup.com',
            'respond@rnngroup.com', 'response@rnngroup.com', 'employmentverification@rnngroup.com'];
        $currentFax = rand(0, count($availableFaxNumbers) - 1);
        $from = "RNN Verification Department";
        $from_fax = $availableFaxNumbers[$currentFax];
        $date = date("m-d-Y");
        $ref = $acct_id . '-' . $AGENT_ID;

        $addr = $fax_account->EMPL_ADDR1 . ' ' . $fax_account->EMPL_ADDR2 . ' ' . $fax_account->EMPL_PHONE1_NMBR . ' ' . $fax_account->EMPL_ST . ' ' . $fax_account->EMPL_ZIP;
        $addr = preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $addr);

        $html = "
	<table border='1' style='width: 100%;' cellpadding='4'>
		<tr>
			<td class='first-column' rowspan='5' style='width: 45%; text-align: center;'>
				<p style='font-size: 20px; word-wrap: break-word;'>REQUEST FOR EMPLOYMENT VERIFICATION<br><br>RNN GROUP INC.</p>
				<p align='center'><img src=".public_path('inc5000.png')." /></p>
			</td>
			<td>
				To: $recipient <br>
				Fax number: $recipient_fax
			</td>
		</tr>
		<tr>
			<td>
				From: $from <br>
				Fax number: $from_fax
			</td>
		</tr>
		<tr>
			<td>
				Date: $date
			</td>
		</tr>
		<tr>
			<td>
					Regarding: Employment Verification for $full_name<br>
					Reference #: $ref
			</td>
		</tr>
		<tr>
			<td>
				<p>
				<span style='font-size: 18px; line-height:35px;'><strong>Verification Response Options:</strong></span><br>
				<u>Website</u>: https://verify.rnngroup.com <br/> <u>Fax</u>: $from_fax <br><u>Email</u>: response@rnngroup.com<br><u>Phone</u>: 470-205-4014
				</p>
			</td>
		</tr>
		<tr>
			<td colspan='2'>
				<span class='body' style='font-size: 15px;'>
					$body Please note, <b>no salary or wage information is needed.</b>

				<br/>
				<br/>
				Employee Name:<b> $full_name</b>
				<br>
				<br>";
		if(substr($ssn, 0, 1) == 'x')
            $html = $html."Employee SSN (Last 4): <strong>" . $ssn . "</strong>";
        else
            $html = $html."Employee SSN: <strong>" . $ssn . "</strong>";
        $html = $html."<br>
				<table border='1' style='margin:10px' cellpadding='5' align='center'>
					<tr align='center'><th>Verification Question</th><th>Response</th></tr>
					<tr><td><b>$question </b>(if unable to respond below)</td><td>&nbsp;</td></tr>
					<tr><td><b>This individual is currently employed by your company?</b></td><td>&nbsp;</td></tr>
					<tr><td><b>Does this employee work over 30 hours per week?</b></td><td>&nbsp;</td></tr>
					<tr><td><b>Your Name and Title:</b></td><td>&nbsp;</td></tr>
					<tr><td><b>Name of Company Correct?</b></td><td>$employer_name</td></tr>
					<tr><td><b>Is this the correct company address </b>(please update if no)</td><td>$addr</td></tr>
				</table>

				</span>
				<p style='margin-bottom: 10px;'>
					For other inquiries, please email response@rnngroup.com
				</p>


			</td>
		</tr>
    </table>";

        //generate the pdf
        $dompdf = new Dompdf();

        $dompdf->loadHtml($html);
        $dompdf->setPaper('letter', 'portrait');
        $dompdf->render();
        $output = $dompdf->output();
        $file_name = $fax_account->id . '.pdf';
        Storage::put('/fax_template/' . $file_name, $output);

        $faxPdf = Storage::get('/fax_template/' . $file_name);

        //environment check
        $env = Config::get('app.env');
        if($env == 'prod'){
            return $this->sendFaxEmail($to_fax, $file_name, $faxPdf, $fax_account, $availableFaxLine[$currentFax]);
        }
    }

    public function sendFaxEmail($to_fax, $file_name, $faxPdf, $fax_account, $fromEmail)
    {
        $user = 'rnnitsupport';
        $pass = 'RNNsg332@@#';
        $request = 'https://api.sendgrid.com/api/mail.send.json';
        $header = 'Verification of employment request. ATTN: Human Resource';
        $params = array(
            'api_user' => $user,
            'api_key' => $pass,
            'to' => $to_fax,
            'subject' => 'Employment Verification',
            'html' => $header,
            'text' => $header,
            'from' => $fromEmail,
            'files[' . $file_name . ']' => '@' . $faxPdf,
        );

        // Generate curl request
        $session = curl_init($request);
        // Tell curl to use HTTP POST
        curl_setopt($session, CURLOPT_POST, true);
        // Tell curl that this is the body of the POST
        curl_setopt($session, CURLOPT_POSTFIELDS, $params);
        // Tell curl not to return headers, but do return the response
        curl_setopt($session, CURLOPT_HEADER, false);
        curl_setopt($session, CURLOPT_RETURNTRANSFER, true);

        // obtain response
        $response = curl_exec($session);
        curl_close($session);

        $fax_account->sent = 1;
        $fax_account->save();

    }
}
