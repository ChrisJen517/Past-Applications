<?php

namespace App\Console\Commands;

use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Inactive_Account;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Config;
use DB;

class BottieAndDottieRemoval extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:BottieAndDottieRemoval';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Removes accounts pass 72 hours from bottie and dottie';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $removedate = date('Y-m-d', strtotime('-3 weekdays'));

        // Send accounts that came from the directory to the COE agents
        DB::SELECT(DB::RAW("UPDATE active_accounts SET ACCT_AGENT = NULL, TEAM_ID = 5, TEAM_NAME='5C', ON_HOLD = 0 where CORPORATION_ID = 2 and ACCT_AGENT in (1901, 1902, 1904) AND DATE(LAST_WORKED) <= '$removedate' AND DIRECTORY_LINK IS NOT NULL AND LAST_WORKED IS NOT NULL;"));

        // Send accounts that did not come from the directory to the live directory queue
        $accounts = Active_Account::selectRaw('active_accounts.ID, active_accounts.EMPL_NAME, active_accounts.EMPL_ADDR1, EMPL_CITY, EMPL_ST, EMPL_ZIP, EMPL_PHONE1_NMBR, ON_HOLD, TEAM_ID, TEAM_NAME, ACCT_AGENT, DIRECTORY_LINK, local_phone, local_address')
        ->leftJoin('powerlead_accounts', function ($join) {
            $join->on('powerlead_accounts.active_account_id', '=', 'active_accounts.ID');
        })
        ->whereRaw("active_accounts.CORPORATION_ID = 2 and active_accounts.ACCT_AGENT in (1901, 1902, 1904) AND DATE(active_accounts.LAST_WORKED) <= '$removedate' AND active_accounts.DIRECTORY_LINK IS NULL AND active_accounts.LAST_WORKED IS NOT NULL")->get();
        foreach($accounts as $account) {
            $this->sendToDirectoryLiveQueue($account);
            $account->TEAM_ID = null;
            $account->TEAM_NAME = null;
            $account->ACCT_AGENT = null;
            $account->save();
        }
    }

    private function sendToDirectoryLiveQueue($account) {
        if(empty($account->NAME_MATCH)){
            $name = $account->EMPL_NAME;
            $empmatchname = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $name);
            $empmatchname = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));
            $account->NAME_MATCH = $empmatchname;
        }
        else{
            $empmatchname = $account->NAME_MATCH;
        }

        // Directory account w/ name match exists
        if (!empty($checkNameMatch = Directory_Active_Account::where('name_match', $empmatchname)->first())) {
            $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
            return;
        } else if (!empty($checkNameMatch = Directory_Inactive_Account::where('name_match', $empmatchname)->first())) {
            $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
            $account->ON_HOLD = 0;
            return;
        }

        $directoryAccount = new Directory_Active_Account();
        $directoryAccount->live_flag = 1;
        $directoryAccount->fresh_flag = 1;
        $directoryAccount->due_date = date('Y-m-d h:i:s', strtotime("+3 weekdays"));
        $directoryAccount->employer_name = $name;
        $directoryAccount->name_match = $empmatchname;
        $directoryAccount->address = $account->EMPL_ADDR1 ?? $account->local_address;
        $directoryAccount->city = $account->EMPL_CITY;
        $directoryAccount->state = $account->EMPL_ST;
        $directoryAccount->zip = $account->EMPL_ZIP;
        $directoryAccount->direct_phone = $account->EMPL_PHONE1_NMBR ?? $account->local_phone;
        $directoryAccount->save();
        $account->ON_HOLD = 1;
        $account->DIRECTORY_LINK = $directoryAccount->directory_account_id;
    }
}