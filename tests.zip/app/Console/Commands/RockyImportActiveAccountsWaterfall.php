<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class RockyImportActiveAccountsWaterfall extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyImportActiveAccountsWaterfall';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send accounts through the waterfall';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $table_name = "test_upload";

        /**
         * If there are accounts left in the waterfall, begin the process
         * of running them through our current databases and placing them
         * accordingly.
         */
        $count = DB::select(DB::raw("SELECT COUNT(*) as accounts FROM $table_name"));
        if ($count[0]->accounts > 0) {
            $this->waterfall($table_name);

            $this->takeOffHold();

            $this->reassignFromAgent();
        }
    }


    public function waterFall($table_name)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720);
        ini_set('default_socket_timeout', 12000);

        $waterfall_table = "waterfall_table";

        /**
         * Grab coe capcodes that will be used to grab specific accounts
         * later on (botty, dotty, fax, and email sent capcodes)
         */
        $email_sent = DB::select(DB::raw("SELECT id FROM capcodes WHERE capcode = 2216 AND corporation_id = 2"));
        $fax_sent = DB::select(DB::raw("SELECT id FROM capcodes WHERE capcode = 2217 AND corporation_id = 2"));
        $bot_coe_codes = DB::select(DB::raw("SELECT id FROM capcodes WHERE capcode IN (1103, 4408, 4411) AND corporation_id = 2;"));
        $dot_coe_codes = DB::select(DB::raw("SELECT id FROM capcodes WHERE capcode IN (1104, 6000) AND corporation_id = 2;"));
        foreach ($bot_coe_codes as $code)
            $bot_coe_list[] = $code->id;
        foreach ($dot_coe_codes as $code)
            $dot_coe_list[] = $code->id;

        /**
         * Grab directory capcodes that will be used to grab specific accounts
         * later on (botty, dotty, coe, and ivr capcodes)
         */
        $coe_dir_codes = DB::select(DB::raw("SELECT capcode_id FROM directory_capcodes WHERE profile_type NOT IN ('fax_profile', 'email_profile', 'ivr_profile') AND type = 'verified';"));
        $IVR_dir_codes = DB::select(DB::raw("SELECT capcode_id FROM directory_capcodes WHERE profile_type = 'ivr_profile';"));
        $bot_dir_codes = DB::select(DB::raw("SELECT capcode_id FROM directory_capcodes WHERE profile_type = 'fax_profile';"));
        $dot_dir_codes = DB::select(DB::raw("SELECT capcode_id FROM directory_capcodes WHERE profile_type = 'email_profile';"));
        foreach ($coe_dir_codes as $code)
            $coe_dir_list[] = $code->capcode_id;
        foreach ($IVR_dir_codes as $code)
            $IVR_dir_list[] = $code->capcode_id;

        /**
         * Grab the schema for the active account upload temporary table
         * and specifically grab all of the column names
         */
        $getColumns = DB::select(DB::raw("SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'test_upload'"));

        /**
         * Iterate through the columns in the active account upload temporary table
         * and create a table creation string and ways to select all columns for later
         */
        $columns = '';
        $columns_csv = '';
        $table_creation = '';
        foreach ($getColumns as $nextColumn) {
            $table_creation = $table_creation . "`" . $nextColumn->COLUMN_NAME . "` VARCHAR( 90 ), ";
            $columns = $columns . $nextColumn->COLUMN_NAME . ", ";
            $columns_csv = $columns_csv . "`$waterfall_table`.`$nextColumn->COLUMN_NAME`, ";
        }
        $table_creation = substr_replace($table_creation, "", -2);
        $columns = substr_replace($columns, "", -2);
        $columns_csv = substr_replace($columns_csv, "", -2);

        // Drop and re-create the waterfall temporary table
        DB::select(DB::raw("DROP TABLE IF EXISTS `$waterfall_table`"));
        DB::select(DB::raw("CREATE TABLE `$waterfall_table` ($table_creation);"));
        DB::select(DB::raw("ALTER TABLE $waterfall_table CONVERT TO CHARACTER SET utf8 COLLATE utf8_unicode_ci;"));

        // Index the temporary table to make future queries more efficient
        DB::select(DB::raw("CREATE INDEX EMPL_NAME_INDEX ON `$waterfall_table` (EMPL_NAME);"));
        DB::select(DB::raw("CREATE INDEX NAME_MATCH_INDEX ON `$waterfall_table` (NAME_MATCH);"));
        DB::select(DB::raw("CREATE INDEX CAPCODE_INDEX ON `$waterfall_table` (CAPCODE);"));
        DB::select(DB::raw("CREATE INDEX ACCT_AGENT_INDEX ON `$waterfall_table` (ACCT_AGENT);"));

        /**
         * Move the values from the active account upload temporary table into
         * the waterfall temporary table
         */
        DB::select(DB::raw("INSERT INTO $waterfall_table
                ($columns)
                SELECT *
                FROM $table_name LIMIT 500"));

        // Set the name match for all of the accounts in the waterfall temporary table
        $this->createNameMatch($waterfall_table);

        /**
         *  BEGIN WATERFALL DATABASE CHECKS
         */

        // A closed account is found with a fax number
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN inactive_accounts ON inactive_accounts.NAME_MATCH = $waterfall_table.NAME_MATCH
            SET $waterfall_table.ACCT_AGENT = 1901, $waterfall_table.TEAM_ID = 10, $waterfall_table.TEAM_NAME = 'BOT', $waterfall_table.EMPL_FAX = inactive_accounts.EMPL_FAX,
            $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.POWERLEAD_FLAG = 0, $waterfall_table.LAST_WORKED = NOW(), $waterfall_table.CAPCODE = " . $fax_sent[0]->id . "
            WHERE inactive_accounts.CAPCODE in (" . implode(',', $bot_coe_list) . ");"));

        // A closed account is found with an email address
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN inactive_accounts ON inactive_accounts.NAME_MATCH = $waterfall_table.NAME_MATCH
            SET $waterfall_table.ACCT_AGENT = 1902, $waterfall_table.TEAM_ID = 10, $waterfall_table.TEAM_NAME = 'BOT', $waterfall_table.EMPL_EMAIL = inactive_accounts.EMPL_EMAIL,
            $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.POWERLEAD_FLAG = 0, $waterfall_table.LAST_WORKED = NOW(), $waterfall_table.CAPCODE = " . $email_sent[0]->id . "
            WHERE inactive_accounts.CAPCODE in (" . implode(',', $dot_coe_list) . ");"));

        // A directory closed account is found with a fax number
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN directory_inactive_accounts ON directory_inactive_accounts.NAME_MATCH = $waterfall_table.NAME_MATCH
            SET $waterfall_table.ACCT_AGENT = 1901, $waterfall_table.TEAM_ID = 10, $waterfall_table.TEAM_NAME = 'BOT', $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.POWERLEAD_FLAG = 0,
            $waterfall_table.EMPL_FAX = directory_inactive_accounts.verification_fax, $waterfall_table.DIRECTORY_LINK = directory_inactive_accounts.directory_account_id, $waterfall_table.LAST_WORKED = NOW(),
            $waterfall_table.CAPCODE = " . $fax_sent[0]->id . "
            WHERE directory_inactive_accounts.capcode in (" . $bot_dir_codes[0]->capcode_id . ");"));

        // A directory closed account is found with an email address
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN directory_inactive_accounts ON directory_inactive_accounts.NAME_MATCH = $waterfall_table.NAME_MATCH
            SET $waterfall_table.ACCT_AGENT = 1902, $waterfall_table.TEAM_ID = 10, $waterfall_table.TEAM_NAME = 'BOT', $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.POWERLEAD_FLAG = 0,
            $waterfall_table.EMPL_EMAIL = directory_inactive_accounts.verification_email, $waterfall_table.DIRECTORY_LINK = directory_inactive_accounts.directory_account_id, $waterfall_table.LAST_WORKED = NOW(),
            $waterfall_table.CAPCODE = " . $email_sent[0]->id . "
            WHERE directory_inactive_accounts.capcode in (" . $dot_dir_codes[0]->capcode_id . ");"));

        // Verified account found in directory closed not by a bot (send to coe)
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN directory_inactive_accounts ON directory_inactive_accounts.NAME_MATCH = $waterfall_table.NAME_MATCH
            SET $waterfall_table.ON_HOLD = 0, $waterfall_table.POWERLEAD_FLAG = 0, $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.DIRECTORY_LINK = directory_inactive_accounts.directory_account_id
            WHERE directory_inactive_accounts.capcode in (" . implode(',', $coe_dir_list) . ");"));

        // Verified by IVR
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN directory_inactive_accounts ON directory_inactive_accounts.NAME_MATCH = $waterfall_table.NAME_MATCH
            SET $waterfall_table.ACCESS_RULES = 'IVR', $waterfall_table.ON_HOLD = 0, $waterfall_table.ACCT_AGENT = null,
            $waterfall_table.POWERLEAD_FLAG = 0, $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.DIRECTORY_LINK = directory_inactive_accounts.directory_account_id
            WHERE directory_inactive_accounts.capcode in (" . implode(',', $IVR_dir_list) . ");"));

        // COE contacts fax number found
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN coe_contacts ON coe_contacts.EMPL_NAME COLLATE utf8_general_ci = $waterfall_table.EMPL_NAME COLLATE utf8_general_ci
            SET $waterfall_table.EMPL_FAX = coe_contacts.Fax_Number, $waterfall_table.ACCT_AGENT = 1901, $waterfall_table.TEAM_ID = 10, $waterfall_table.TEAM_NAME = 'BOT',
            $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.POWERLEAD_FLAG = 0, $waterfall_table.LAST_WORKED = NOW(), $waterfall_table.CAPCODE = " . $fax_sent[0]->id . "
            WHERE coe_contacts.Fax_Number IS NOT NULL AND coe_contacts.Fax_Number != '';"));

        // COE contacts email address found
        DB::select(DB::raw("UPDATE $waterfall_table INNER JOIN coe_contacts ON coe_contacts.EMPL_NAME COLLATE utf8_general_ci = $waterfall_table.EMPL_NAME COLLATE utf8_general_ci
            SET $waterfall_table.EMPL_EMAIL = coe_contacts.Email_address, $waterfall_table.ACCT_AGENT = 1902, $waterfall_table.TEAM_ID = 10, $waterfall_table.TEAM_NAME = 'BOT',
            $waterfall_table.DIRECTORY_FLAG = 0, $waterfall_table.POWERLEAD_FLAG = 0, $waterfall_table.LAST_WORKED = NOW(), $waterfall_table.CAPCODE = " . $email_sent[0]->id . "
            WHERE coe_contacts.Email_address IS NOT NULL AND coe_contacts.Email_address != '';"));

        /**
         *  END WATERFALL DATABASE CHECKS
         */

        // Make ALT_ID an INT(11) and index it on the temporary table
        DB::select(DB::raw("ALTER TABLE waterfall_table MODIFY COLUMN ALT_ID INT(11);"));
        DB::select(DB::raw("CREATE INDEX ALT_ID_INDEX ON waterfall_table (ALT_ID);"));

        /**
         * Run a series of update statements on the temporary table to complete the
         * waterfall process and finish filling in the information that we need
         * before moving the accounts into the active_accounts table
         */
        DB::select(DB::raw("DELETE FROM $waterfall_table WHERE ALT_ID IN (SELECT ALT_ID FROM inactive_accounts WHERE CORPORATION_ID = 2);"));
        DB::select(DB::raw("UPDATE $waterfall_table wt INNER JOIN directory_inactive_accounts da ON wt.DIRECTORY_ALT_LINK = da.dir_alt_id SET DIRECTORY_LINK = da.directory_account_id WHERE wt.DIRECTORY_ALT_LINK IS NOT NULL AND wt.DIRECTORY_LINK is null AND CORPORATION_ID = 2"));
        DB::select(DB::raw("UPDATE $waterfall_table SET DIRECTORY_FLAG = 1 WHERE (DIRECTORY_LINK IS NULL OR DIRECTORY_LINK = '') AND CORPORATION_ID = 2"));
        DB::select(DB::raw("UPDATE $waterfall_table SET TEAM_ID = 5, TEAM_NAME = '5C', ACCT_AGENT = null where TEAM_ID NOT IN (5,10,9) OR TEAM_ID IS NULL OR TEAM_ID = '';"));
        DB::select(DB::raw("UPDATE $waterfall_table SET TEAM_ID = null WHERE TEAM_ID IN (5,10) AND CORPORATION_ID != 2;"));

        // Import the accounts that have been run through the waterfall into the active_accounts table
        DB::select(DB::raw("INSERT IGNORE INTO active_accounts
        ($columns)
        SELECT
        $columns_csv
        FROM `$waterfall_table`;"));

        /**
         * Run a series of update statements on the active_accounts table to complete the
         * waterfall process and finish filling in the information that we need
         * after moving the accounts into the active_accounts table
         */
        DB::select(DB::raw("UPDATE active_accounts aa inner join powerlead_accounts pl ON pl.active_account_id = aa.ALT_ID SET aa.POWERLEAD_ID = pl.id;"));
        DB::select(DB::raw("UPDATE powerlead_accounts pl inner join active_accounts aa ON pl.id = aa.POWERLEAD_ID set pl.active_account_id = aa.id;"));
        DB::select(DB::raw("UPDATE active_accounts SET POWERLEAD_ID = null WHERE POWERLEAD_ID = 0 AND corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts SET POWERLEAD_FLAG = 1, ON_HOLD = 1 WHERE POWERLEAD_ID IS NULL AND ACCT_AGENT IS NULL AND DIRECTORY_LINK IS NULL AND corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts set CLIENT_NAME = null where CLIENT_NAME = '' AND corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_NAME = pl.client_name where pl.client_name IS NOT NULL AND pl.client_name != '' AND aa.corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_PHONE = pl.coephone where pl.coephone IS NOT NULL AND pl.coephone != '' AND aa.corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_NAME = pl.name WHERE aa.ACCT_CLIENT is not null and aa.CLIENT_NAME is null AND aa.corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_PHONE = pl.phone WHERE aa.ACCT_CLIENT is not null and aa.CLIENT_PHONE is null AND aa.corporation_id = 2;"));
        DB::select(DB::raw("UPDATE active_accounts aa SET aa.LAST_WORKED = NULL WHERE (SELECT count(*) FROM worked_history wh WHERE aa.ID = wh.active_account_id AND wh.agent_id NOT IN (1901,1902,1904)) = 0 AND LAST_WORKED IS NOT NULL AND TEAM_ID != 10 AND aa.corporation_id = 2;"));

        // Remove the accounts run through the waterfall from the temporary table
        DB::select(DB::raw("DELETE FROM $table_name LIMIT 500"));
    }

    public function takeOffHold()
    {
        DB::select(DB::raw("UPDATE active_accounts aa INNER JOIN waterfall_table ua ON aa.ALT_ID = ua.ALT_ID SET aa.ACCT_AGENT = null, aa.TEAM_ID = 5, aa.TEAM_NAME = ua.TEAM_NAME AND aa.ON_HOLD = 0 WHERE ua.ACCT_AGENT NOT IN (1901, 1902, 3333, 9999, 7720) and aa.ACCT_AGENT IN (1901, 1902, 1904, 9999) AND ua.TEAM_NAME = '5C'"));
        DB::select(DB::raw("UPDATE active_accounts aa INNER JOIN waterfall_table ua ON aa.ALT_ID = ua.ALT_ID SET aa.ACCT_AGENT = null, aa.TEAM_ID = 9, aa.TEAM_NAME = ua.TEAM_NAME AND aa.ON_HOLD = 0 WHERE ua.ACCT_AGENT NOT IN (1901, 1902, 3333, 9999, 7720) and aa.ACCT_AGENT IN (1901, 1902, 1904, 9999) AND ua.TEAM_NAME = 'ATL'"));
        DB::select(DB::raw("UPDATE active_accounts aa INNER JOIN waterfall_table ua ON aa.ALT_ID = ua.ALT_ID SET aa.ACCT_AGENT = null, aa.TEAM_ID = 8, aa.TEAM_NAME = ua.TEAM_NAME AND aa.ON_HOLD = 0 WHERE ua.ACCT_AGENT NOT IN (1901, 1902, 3333, 9999, 7720) and aa.ACCT_AGENT IN (1901, 1902, 1904, 9999) AND ua.TEAM_NAME = 'COL'"));
        DB::select(DB::raw("UPDATE active_accounts aa INNER JOIN waterfall_table ua ON aa.ALT_ID = ua.ALT_ID SET aa.ACCT_AGENT = null, aa.TEAM_ID = 11, aa.TEAM_NAME = ua.TEAM_NAME AND aa.ON_HOLD = 0 WHERE ua.ACCT_AGENT NOT IN (1901, 1902, 3333, 9999, 7720) and aa.ACCT_AGENT IN (1901, 1902, 1904, 9999) AND ua.TEAM_NAME = 'EBC'"));
    }

    public function reassignFromAgent()
    {
        DB::select(DB::raw("UPDATE active_accounts aa INNER JOIN waterfall_table ua ON aa.ALT_ID = ua.ALT_ID SET aa.ACCT_AGENT = 3333 AND aa.ON_HOLD = 1 WHERE ua.ACCT_AGENT = 3333 and aa.ACCT_AGENT != 3333"));
        DB::select(DB::raw("UPDATE active_accounts aa INNER JOIN waterfall_table ua ON aa.ALT_ID = ua.ALT_ID SET aa.ACCT_AGENT = 9999 AND aa.ON_HOLD = 1 WHERE ua.ACCT_AGENT = 9999 and aa.ACCT_AGENT != 9999"));
    }

    public function createNameMatch($waterfall_table)
    {
        //removes the needed titles and sets it to lowercase
        $companyType = ['"incorporated"', '"corporation"', '"llc"', '"ltd"', '"llp"', '"s-corp"', '"inc"', '"corp"'];
        $removeCompanyType = "LOWER(EMPL_NAME)";
        foreach ($companyType as $type) {
            $removeCompanyType = "REPLACE(" . $removeCompanyType . ", " . $type . ", '')";
        }
        DB::select(DB::raw("UPDATE $waterfall_table Set NAME_MATCH = " . $removeCompanyType . ";"));

        //removes the special characters
        $specialCharaters = ["'" . '"' . "'", '"' . "'" . '"', '"!"', '"@"', '"#"', '"$"', '"%"', '"^"', '"&"', '"*"', '"("', '")"', '"{"', '"["', '"}"', '"]"', '"|"', '";"', '":"', '"<"', '","', '"."', '">"', '"?"', '"/"', '"-"', '"_"', '"="', '"+"', '"`"', '"~"', '" "'];
        $removeSpecialCharaters = "REPLACE(NAME_MATCH, '/', '')";
        foreach ($specialCharaters as $character) {
            $removeSpecialCharaters = "REPLACE(" . $removeSpecialCharaters . ", " . $character . ", '')";
        }
        DB::select(DB::raw("UPDATE $waterfall_table Set NAME_MATCH = " . $removeSpecialCharaters . ";"));
    }
}
