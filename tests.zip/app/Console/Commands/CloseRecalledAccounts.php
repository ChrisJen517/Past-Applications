<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Config;
use App\Jobs\RemovePastDueJobQueue;
use App\Models\Corporation;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Inactive_Account;
use Schema;
use App\Models\Active_Account;

class CloseRecalledAccounts extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:CloseRecalledAccounts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Close Recalled Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->closeAccounts();
        $this->closeMaxWorkAccounts();
    }

    public function closeAccounts(){
        echo "Starting Command:";
        $accountToClose = Active_Account::select('ID')->where('ACCT_AGENT',3333)->limit(5000)->get();
        foreach ($accountToClose as $account)
        {
            $active = Active_Account::find($account->ID);
            $inactive = new Inactive_Account;
            $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts');
            for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
                $item = strval($active_accounts_mapping_columns[$i]);
                if ($item != 'CREATED_AT' && $item != 'UPDATED_AT') {
                    $inactive->$item = $active->$item;
                }
            }

            if ($inactive->DIRECTORY_FLAG == null) {
                $inactive->DIRECTORY_FLAG = 0;
            }
            $inactive->CAPCODE = 459;
            $inactive->save();
            $active->delete();
            echo "Successfully Closed.";
        }
         



            
    }
    public function closeMaxWorkAccounts(){
        echo "Starting Command:";
        $accountToClose = Active_Account::select('ID')->where('ACCT_AGENT',2001)->limit(5000)->get();
        foreach ($accountToClose as $account)
        {
            $active = Active_Account::find($account->ID);
            $inactive = new Inactive_Account;
            $active_accounts_mapping_columns = Schema::getColumnListing('active_accounts');
            for ($i = 0; $i < count($active_accounts_mapping_columns); $i++) {
                $item = strval($active_accounts_mapping_columns[$i]);
                if ($item != 'CREATED_AT' && $item != 'UPDATED_AT') {
                    $inactive->$item = $active->$item;
                }
            }

            if ($inactive->DIRECTORY_FLAG == null) {
                $inactive->DIRECTORY_FLAG = 0;
            }
            $inactive->CAPCODE = 364;
            $inactive->save();
            $active->delete();
            echo "Successfully Closed.";
        }
         



            
    }
}
