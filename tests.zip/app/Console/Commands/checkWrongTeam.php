<?php

namespace App\Console\Commands;

use App\RNNMailer;
use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use PHPMailer\PHPMailer\PHPMailer;
use Carbon\Carbon;

class checkWrongTeam extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:checkWrongTeam';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Checks if team assignment is wrong';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->checkWrongTeam();
    }

    public function checkWrongTeam(){
        $wrongTeams = DB::SELECT(DB::RAW("SELECT aa.ID FROM active_accounts WHERE TEAM_NAME = '5C' AND TEAM_ID != 5"));
        $wrongTeamsString = '';
        foreach($missingWHs as $missingWH){
            $wrongTeamsString = $wrongTeamsString.$missingWH->ID.' ';
        }

        if($wrongTeamString != ''){
            $bodyString = "These Active Accounts have are set to TEAM_NAME 5C and not TEAM ID 5. ".$wrongTeamsString."";
            $mail = new RNNMailer(true);
            $mail->createHeader('Missing Work Histories');
            $mail->MessageDate = date("M,d,Y h:i:s A");
            $mail->Subject = "Team Name and Team ID missmatch for 5C";
            $mail->Body = $bodyString;
            $mail->send();
        }
    }
}
