<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyExportDirectoryActiveAccounts extends Command
{
        /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyExportDirectoryActiveAccounts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Export Directory Active Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->ExportActiveAccounts();
    }

    public function ExportActiveAccounts()
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
        $filename = '/home/rocky/public_html/rocky-sync/dir_active_accounts.csv';
        $fileDestination = '/public_html/contract/sync-outbound/dir_active_accounts.csv';
         echo "Beginning Export\n";
        $accounts = DB::select(DB::raw(
            "SELECT 
            dir_alt_id,
            directory_agent_id,
            employer_name,
            address,
            empl_address_2,
            city,
            state,
            zip,
            empl_org_phone,
            employer_type,
            total_employees,
            direct_phone,
            verification_phone,
            verification_fax,
            verification_email,
            third_party_name,
            third_party_account_number,
            company_website,
            verification_contact,
            verification_contact_title,
            verification_mailing_adress,
            verification_notes,
            work_notes,
            (SELECT capcode from directory_capcodes WHERE directory_active_accounts.capcode = directory_capcodes.capcode_id) as capcode,
            last_worked,
            fresh_flag,
            live_flag,
            phone_verified
            FROM directory_active_accounts;"
        ));

        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'UID,ACCT_AGENT,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_STATE,EMPL_ZIP,EMPL_ORG_PHONE,EMPL_TYPE,EMPL_TOTAL_EMP,DIRECT_PHONE,VER_PHONE,VER_FAX,VER_EMAIL,VER_3RD_PARTY_NAME,VER_3RD_PARTY_NUMBER,URL,VER_CONTACT,VER_CONTACT_TITLE,VER_ADDRESS,VER_NOTES,WORK_NOTES,CAPCODE,LAST_WORKED,FRESH_QUEUE,LIVE_QUEUE,PHONE_VERIFICATION';
        fwrite($file, $headerString);

        foreach ($accounts as $account) {     
            $rowString = "\r\n" .
            str_replace(array("\n", "\r", ","), '', $account->dir_alt_id). ',' .
            str_replace(array("\n", "\r", ","), '', $account->directory_agent_id). ',' .
            str_replace(array("\n", "\r", ","), '', $account->employer_name). ',' .
            str_replace(array("\n", "\r", ","), '', $account->address). ',' .
            str_replace(array("\n", "\r", ","), '', $account->empl_address_2). ',' .
            str_replace(array("\n", "\r", ","), '', $account->city). ',' .
            str_replace(array("\n", "\r", ","), '', $account->state). ',' .
            str_replace(array("\n", "\r", ","), '', $account->zip). ',' .
            str_replace(array("\n", "\r", ","), '', $account->empl_org_phone). ',' .
            str_replace(array("\n", "\r", ","), '', $account->employer_type). ',' .
            str_replace(array("\n", "\r", ","), '', $account->total_employees). ',' .
            str_replace(array("\n", "\r", ","), '', $account->direct_phone). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_phone). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_fax). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_email). ',' .
            str_replace(array("\n", "\r", ","), '', $account->third_party_name). ',' .
            str_replace(array("\n", "\r", ","), '', $account->third_party_account_number). ',' .
            str_replace(array("\n", "\r", ","), '', $account->company_website). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_contact). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_contact_title). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_mailing_adress). ',' .
            str_replace(array("\n", "\r", ","), '', $account->verification_notes). ',' .
            str_replace(array("\n", "\r", ","), '', $account->work_notes). ',' .
            str_replace(array("\n", "\r", ","), '', $account->capcode). ',' .
            str_replace(array("\n", "\r", ","), '', $account->last_worked). ',' .
            str_replace(array("\n", "\r", ","), '', $account->fresh_flag). ',' .
            str_replace(array("\n", "\r", ","), '', $account->live_flag). ',' .
            str_replace(array("\n", "\r", ","), '', $account->phone_verified);
            fwrite($file, $rowString);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);

        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $file\n";
        } else {
            echo "There was a problem while uploading $file\n";
        }
    echo "\nSuccessfully Exported\n";
        // close the connection
        ftp_close($conn_id);
    }
}
