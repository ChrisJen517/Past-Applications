<?php

namespace App\Console\Commands;

use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Inactive_Account;
use Illuminate\Console\Command;
use DB;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Support\Facades\Storage;
use PDO;
use Auth;
use Config;
use Schema;
use Carbon\Carbon;

class RockyImportClosedAccountsMorning extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyImportClosedAccountsMorning';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Closed Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->ImportOldRocky();
        $this->uploadAAFile();
        $this->movetoInactive();
        // $this->removeFromActiveAccount();
    }
    public function ImportOldRocky(){
        $nowStart = Carbon::now()->format('Y_m_d');
        $now = Carbon::now()->format('Y_m_d_h_i');
        $path = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/'.$now.'';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/'.$now.'');
        }
        $fileDestination = '/public_html/contract/sync/CLOSED_ACCOUNTS.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/CLOSED_ACCOUNTS.csv';
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        // return ftp_nlist($conn_id, "/public_html/contract/ACTIVE_ACCOUNTS_Special.csv");

        // upload a file
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        // return $file;
        // close the connection
        ftp_close($conn_id);

       $file = fopen($filename, "r");
       $line = fgets($file);

    }

    public function uploadAAFile(){

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        $table_name = 'closed_account_upload_large';

        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        $nowStart = Carbon::now()->format('Y_m_d');
        $now = Carbon::now()->format('Y_m_d_h_i');
        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/'.$nowStart.'/CLOSED_ACCOUNTS.csv';
        // Setting up reading file that is uploaded
        $file = new \SplFileObject($fileName);
        $file->setFlags(\SplFileObject::READ_CSV);
        $headers = [];
        $rows = 0;
        // Grabbing names of the columns in the CSV file
        foreach($file as $row)
        {
            if($rows == 0){
                foreach($row as $header)
                {
                        $headers[] = $header;
                }
            }
            break;
        }

        $insert_statement_temp_table =  '';
        //Building Insert Statements of CSV TEMP Table ON Active_Accounts Table and CSV Temp Table
        foreach($headers as $head)
            $insert_statement_temp_table = $insert_statement_temp_table."`".$head."` VARCHAR( 90 ), ";
        
        $insert_statement_temp_table = substr_replace($insert_statement_temp_table,"",-2);

        // Dropping table if one previously existed
        DB::SELECT( DB::RAW("DROP TABLE IF EXISTS `$table_name`"));
        // Creating a temp table to upload CSV file
        DB::select( DB::raw("CREATE TABLE`$table_name` (
            $insert_statement_temp_table);"));

        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
          PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));

        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);

        // Update ADD_DATE to right format
        DB::SELECT(DB::raw("UPDATE `$table_name`
        SET ADD_DATE = STR_TO_DATE(ADD_DATE,'%Y%m%d')"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ADD_DATE = null WHERE ADD_DATE = '0--';"));

        // Update ACCT_DUE_DATE to right format
        DB::SELECT(DB::raw("UPDATE `$table_name`
        SET ACCT_DUE_DATE = STR_TO_DATE(ACCT_DUE_DATE,'%Y%m%d')"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ACCT_DUE_DATE = null WHERE ACCT_DUE_DATE = '0--';"));

        // Update ACCT_DOB to right format
        DB::SELECT(DB::raw("UPDATE `$table_name`
        SET ACCT_DOB = STR_TO_DATE(ACCT_DOB,'%Y%m%d')"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ACCT_DOB = null WHERE ACCT_DOB = '0--';"));

        DB::SELECT(DB::RAW('ALTER TABLE '.$table_name.' DROP MISC,  DROP WORK_COMMENTS,  DROP REMINDER, DROP LAST_SEEN,
        CHANGE DIR_ID DIRECTORY_ALT_LINK VARCHAR(90), CHANGE UID ALT_ID VARCHAR( 90 ), CHANGE ACCT_COE TEAM_NAME VARCHAR( 90 ),
        ADD COLUMN `CORPORATION_ID` varchar(45) NOT NULL DEFAULT 2, ADD COLUMN `TEAM_ID` INT DEFAULT NULL, 
        ADD COLUMN `PINPOINT` INT NOT NULL DEFAULT 0, ADD COLUMN `ON_HOLD` INT NOT NULL DEFAULT 0,
        ADD COLUMN `BLOCKED_CHECK` INT DEFAULT 1,
        ADD COLUMN `CLIENT_NAME` VARCHAR(90) DEFAULT NULL, ADD COLUMN `CLIENT_PHONE` VARCHAR(90) DEFAULT NULL ;'));

        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 5 WHERE TEAM_NAME = '5C'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 9 WHERE TEAM_NAME = 'ATL'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 8 WHERE TEAM_NAME = 'COL'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 11 WHERE TEAM_NAME = 'EBC'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET TEAM_ID = 10 WHERE TEAM_NAME = 'BOT'"));

        //********SHOULD SCOREHOLD BE SET TO 9999??************
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET PINPOINT = 1, ON_HOLD = 1, ACCT_AGENT = NULL WHERE ACCT_AGENT = 'OVERFLOWED'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ON_HOLD = 1, ACCT_AGENT = NULL WHERE ACCT_AGENT = 'SCOREHOLD'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET ON_HOLD = 1, ACCT_AGENT = 3333 WHERE ACCT_AGENT = 'RECALLED'"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET capcode = NULL WHERE capcode = 0;"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` INNER JOIN capcodes on `$table_name`.capcode = capcodes.capcode SET `$table_name`.capcode = capcodes.id WHERE `$table_name`.capcode != 2302;"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` SET LAST_WORKED = null WHERE LAST_WORKED = ''"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_NAME = pl.client_name, aa.CLIENT_PHONE = pl.coephone;"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_NAME = pl.name WHERE aa.ACCT_CLIENT is not null and aa.CLIENT_NAME is null;"));
        DB::SELECT(DB::RAW("UPDATE `$table_name` aa inner join rnnwusers pl ON pl.id = aa.ACCT_CLIENT SET aa.CLIENT_PHONE = pl.phone WHERE aa.ACCT_CLIENT is not null and aa.CLIENT_PHONE is null;"));

        $getColumns = DB::SELECT(DB::RAW("SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_NAME = N'closed_account_upload'"));
        $columns = '';
        $columns_csv = '';  
        $duplicate_key = '';
        foreach($getColumns as $nextColumn){
            $duplicate_key = $duplicate_key."`active_accounts`.`".$nextColumn->COLUMN_NAME."`= `".$table_name."`.`".$nextColumn->COLUMN_NAME."`, ";
            $columns = $columns.$nextColumn->COLUMN_NAME.", ";
            $columns_csv = $columns_csv."`$table_name`.`$nextColumn->COLUMN_NAME`, ";

        }
        $duplicate_key = substr_replace($duplicate_key,"",-2);
        $columns = substr_replace($columns,"",-2);
        $columns_csv = substr_replace($columns_csv,"",-2);

        DB::select( DB::raw("INSERT INTO active_accounts
            ($columns)
            SELECT
            $columns_csv
            FROM `$table_name` ON DUPLICATE KEY UPDATE $duplicate_key;"));
            
        DB::SELECT(DB::RAW("UPDATE active_accounts aa INNER JOIN directory_inactive_accounts da ON aa.DIRECTORY_ALT_LINK = da.dir_alt_id SET DIRECTORY_LINK = da.directory_account_id WHERE aa.DIRECTORY_ALT_LINK IS NOT NULL AND aa.DIRECTORY_LINK is null AND CORPORATION_ID = 2"));
        DB::SELECT(DB::RAW("UPDATE active_accounts SET DIRECTORY_FLAG = 1 WHERE (DIRECTORY_LINK IS NULL OR DIRECTORY_LINK = '') AND CORPORATION_ID = 2"));
        DB::SELECT(DB::RAW("UPDATE active_accounts aa inner join powerlead_accounts pl ON pl.active_account_id = aa.ALT_ID SET aa.POWERLEAD_ID = pl.id;"));
        DB::SELECT(DB::RAW("UPDATE active_accounts SET POWERLEAD_ID = null WHERE POWERLEAD_ID = 0;"));
    }

    public function movetoInactive(){

        $table_name = 'closed_account_upload_large';

        $closedByBot = Active_Account::whereRaw("ALT_ID IN ((SELECT ALT_ID FROM $table_name)) and ACCT_AGENT in (1901, 1902, 1904) and DIRECTORY_LINK is NULL;");
        foreach($closedByBot as $account) {
            $this->sendToDirectoryQueue($account);
        }

        DB::Select(DB::raw("INSERT INTO inactive_accounts
        (SELECT * from `active_accounts` WHERE ALT_ID IN ((SELECT ALT_ID FROM $table_name))) ON DUPLICATE KEY UPDATE
        inactive_accounts.ADD_DATE = active_accounts.ADD_DATE,
        inactive_accounts.ADD_FILE = active_accounts.ADD_FILE,
        inactive_accounts.ADDED_BY = active_accounts.ADDED_BY,
        inactive_accounts.ACCT_CLIENT = active_accounts.ACCT_CLIENT,
        inactive_accounts.TEAM_NAME = active_accounts.TEAM_NAME,
        inactive_accounts.TEAM_ID = active_accounts.TEAM_ID,
        inactive_accounts.ACCT_CASE = active_accounts.ACCT_CASE,
        inactive_accounts.ACCT_DUE_DATE = active_accounts.ACCT_DUE_DATE,
        inactive_accounts.ACCT_SSN = active_accounts.ACCT_SSN,
        inactive_accounts.ACCT_FIRST_NAME = active_accounts.ACCT_FIRST_NAME,
        inactive_accounts.ACCT_LAST_NAME = active_accounts.ACCT_LAST_NAME,
        inactive_accounts.ACCT_AD1 = active_accounts.ACCT_AD1,
        inactive_accounts.ACCT_AD2 = active_accounts.ACCT_AD2,
        inactive_accounts.ACCT_CITY = active_accounts.ACCT_CITY,
        inactive_accounts.ACCT_ST = active_accounts.ACCT_ST,
        inactive_accounts.ACCT_ZIP = active_accounts.ACCT_ZIP,
        inactive_accounts.ACCT_DOB = active_accounts.ACCT_DOB,
        inactive_accounts.ACCT_ID = active_accounts.ACCT_ID,
        inactive_accounts.ACCT_SOURCE = active_accounts.ACCT_SOURCE,
        inactive_accounts.EMPL_NAME = active_accounts.EMPL_NAME,
        inactive_accounts.EMPL_ADDR1 = active_accounts.EMPL_ADDR1,
        inactive_accounts.EMPL_ADDR2 = active_accounts.EMPL_ADDR2,
        inactive_accounts.EMPL_CITY = active_accounts.EMPL_CITY,
        inactive_accounts.EMPL_ST = active_accounts.EMPL_ST,
        inactive_accounts.EMPL_ZIP = active_accounts.EMPL_ZIP,
        inactive_accounts.EMPL_HR_ADDR = active_accounts.EMPL_HR_ADDR,
        inactive_accounts.EMPL_PHONE1_NMBR = active_accounts.EMPL_PHONE1_NMBR,
        inactive_accounts.EMPL_PH_SOURCE = active_accounts.EMPL_PH_SOURCE,
        inactive_accounts.EMPL_FAX = active_accounts.EMPL_FAX,
        inactive_accounts.EMPL_EMAIL = active_accounts.EMPL_EMAIL,
        inactive_accounts.EMPL_TITLE = active_accounts.EMPL_TITLE,
        inactive_accounts.EMPL_CONTACT = active_accounts.EMPL_CONTACT,
        inactive_accounts.EMPL_CONTACT_TITLE = active_accounts.EMPL_CONTACT_TITLE,
        inactive_accounts.LAST_COMMENTS = active_accounts.LAST_COMMENTS,
        inactive_accounts.TIME_ZONE = active_accounts.TIME_ZONE,
        inactive_accounts.TEAM_RULE = active_accounts.TEAM_RULE,
        inactive_accounts.POESCORE = active_accounts.POESCORE,
        inactive_accounts.EMPL_FILES = active_accounts.EMPL_FILES,
        inactive_accounts.SECOND_CASE = active_accounts.SECOND_CASE,
        inactive_accounts.REMINDER = active_accounts.REMINDER,
        inactive_accounts.CORPORATION_ID = active_accounts.CORPORATION_ID,
        inactive_accounts.UPDATED_AT = active_accounts.UPDATED_AT,
        inactive_accounts.ON_HOLD = active_accounts.ON_HOLD,
        inactive_accounts.TIER = active_accounts.TIER,
        inactive_accounts.EXPORTED = active_accounts.EXPORTED,
        inactive_accounts.SPECIAL_RULES = active_accounts.SPECIAL_RULES,
        inactive_accounts.WORK_REMINDER = active_accounts.WORK_REMINDER,
        inactive_accounts.URL = active_accounts.URL,
        inactive_accounts.CLIENT_NAME = active_accounts.CLIENT_NAME,
        inactive_accounts.CLIENT_PHONE = active_accounts.CLIENT_PHONE,
        inactive_accounts.POWERLEAD_ID = active_accounts.POWERLEAD_ID,
        inactive_accounts.POWERLEAD_AGENT_ID = active_accounts.POWERLEAD_AGENT_ID,
        inactive_accounts.POWERLEAD_CAPCODE = active_accounts.POWERLEAD_CAPCODE,
        inactive_accounts.CAPCODE = active_accounts.CAPCODE,
        inactive_accounts.POWERLEAD_FLAG = active_accounts.POWERLEAD_FLAG,
        inactive_accounts.DIRECTORY_LINK = active_accounts.DIRECTORY_LINK,
        inactive_accounts.DIRECTORY_FLAG = active_accounts.DIRECTORY_FLAG,
        inactive_accounts.ACCESS_RULES = active_accounts.ACCESS_RULES,
        inactive_accounts.BLOCKED_CHECK = active_accounts.BLOCKED_CHECK,
        inactive_accounts.POWERLEAD_EMAIL = active_accounts.POWERLEAD_EMAIL,
        inactive_accounts.POWERLEAD_FAX = active_accounts.POWERLEAD_FAX,
        inactive_accounts.ACCT_TYPE = active_accounts.ACCT_TYPE,
        inactive_accounts.PINPOINT = active_accounts.PINPOINT,
        inactive_accounts.ALT_ID = active_accounts.ALT_ID,
        inactive_accounts.DIRECTORY_ALT_LINK = active_accounts.DIRECTORY_ALT_LINK;"));

        DB::SELECT(DB::RAW("DELETE FROM active_accounts WHERE ALT_ID IN ((SELECT ALT_ID FROM $table_name))"));

    }

    private function sendToDirectoryQueue($account) {
        $name = $account->EMPL_NAME;
        $empmatchname = str_ireplace(array('  incorporation', ' inc', ' llc', ' ltd', ' llp', ' s-corp', ' corp', ' corporation'), '', $name);
        $empmatchname = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));

        // Directory account w/ name match exists
        if (!empty($checkNameMatch = Directory_Active_Account::where('name_match', $empmatchname)->first())) {
            $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
            $account->save();
            return;
        } else if (!empty($checkNameMatch = Directory_Inactive_Account::where('name_match', $empmatchname)->first())) {
            $account->DIRECTORY_LINK = $checkNameMatch->directory_account_id;
            $account->ON_HOLD = 0;
            $account->save();
            return;
        }


        $directoryAccount = new Directory_Active_Account();
        $directoryAccount->live_flag = 0;
        $directoryAccount->fresh_flag = 1;
        $directoryAccount->employer_name = $name;
        $directoryAccount->name_match = $empmatchname;
        $directoryAccount->address = $account->EMPL_ADDR1;
        $directoryAccount->city = $account->EMPL_CITY;
        $directoryAccount->state = $account->EMPL_ST;
        $directoryAccount->zip = $account->EMPL_ZIP;
        $directoryAccount->direct_phone = $account->EMPL_PHONE1_NMBR;
        $directoryAccount->save();
        $account->DIRECTORY_LINK = $directoryAccount->directory_account_id;
        $account->save();
    }
}