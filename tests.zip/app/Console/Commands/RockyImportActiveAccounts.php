<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;
use App\Traits\Autobot;
use PDO;
use Illuminate\Support\Facades\Config;
use Carbon\Carbon;

class RockyImportActiveAccounts extends Command
{
    use Autobot;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:RockyImportActiveAccounts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Active Accounts';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $time = Carbon::now()->format('Y_m_d h:m:s');
        echo $time . "command started \n";

        $this->ImportOldRocky();
        $time = Carbon::now()->format('Y_m_d h:m:s');
        echo $time . "importing old rocky done \n";

        $this->loadTempTable();
        $time = Carbon::now()->format('Y_m_d h:m:s');
        echo $time . "upload AA done \n";

        $time = Carbon::now()->format('Y_m_d h:m:s');
        echo $time . "command finished \n";
    }

    public function ImportOldRocky()
    {
        /**
         * Create the directory for our usage on the Apollo FTP server and
         * prepare for the import of data from the old rocky
         */
        $now = Carbon::now()->format('Y_m_d');
        $path = '/home/rocky/public_html/rocky-sync/Maintence/' . $now . '';
        if (!file_exists($path)) {
            mkdir('/home/rocky/public_html/rocky-sync/Maintence/' . $now . '');
        }
        $fileDestination = '/public_html/contract/sync/ACTIVE_ACCOUNTS_Special.csv';
        $filename = '/home/rocky/public_html/rocky-sync/Maintence/' . $now . '/ACTIVE_ACCOUNTS_Special.csv';

        /**
         * Connect to the Contract Portal FTP server we use to pass data from
         * Apollo to the old rocky and vice versa
         */
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);
        ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);

        /**
         * Get the import from the ftp and read its content, also closes the
         * FTP connection
         */
        if (ftp_get($conn_id, $filename, $fileDestination, FTP_BINARY)) {
            echo "successfully uploaded \n";
        } else {
            echo "There was a problem while uploading \n";
        }
        ftp_close($conn_id);

        $file = fopen($filename, "r");
        $line = fgets($file);
    }

    public function loadTempTable()
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720);
        ini_set('default_socket_timeout', 6000);

        // Set up credentials for the MySQL server to use and the table name
        $table_name = 'test_upload';
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');
        $now = Carbon::now()->format('Y_m_d');

        // Read the CSV data into the $file variable
        $fileName = '/home/rocky/public_html/rocky-sync/Maintence/' . $now . '/ACTIVE_ACCOUNTS_Special.csv';
        $file = new \SplFileObject($fileName);
        $file->setFlags(\SplFileObject::READ_CSV);

        /**
         * Grab an array of the headers in the import
         * (could not directly find a good way to only get the first row, so
         * break out of the loop after the first row)
         */
        $headers = [];
        foreach ($file as $row) {
            foreach ($row as $header) {
                $headers[] = $header;
            }
            break;
        }

        // Generate an insert statement based on the headers of the CSV file
        $insert_statement_temp_table = '';
        foreach ($headers as $head) {
            $insert_statement_temp_table = $insert_statement_temp_table . "`" . $head . "` VARCHAR( 90 ), ";
        }
        $insert_statement_temp_table = substr_replace($insert_statement_temp_table, "", -2);
        $lastHead = 'TIER';

        /**
         * Drop the temporary table if it exists and create a new one based on
         * the insert statement we have created previously
         */
        DB::select(DB::raw("DROP TABLE IF EXISTS `$table_name`"));
        DB::select(DB::raw("CREATE TABLE `$table_name` ($insert_statement_temp_table);"));

        /**
         * Establish a connection to the MySQL server whose credentials we
         * had specified earlier
         */
        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
            PDO::MYSQL_ATTR_LOCAL_INFILE => true,
        ));


        // Load the data from the csv import into the table
        $query = sprintf("LOAD DATA local INFILE '%s' INTO TABLE $table_name FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '\"' ESCAPED BY '\"' LINES TERMINATED BY '\\n' IGNORE 1 LINES", addslashes($fileName));
        $conn->exec($query);

        // Unassign agents from accounts that have not been worked inside the RNN corporation
        DB::select(DB::raw("UPDATE active_accounts SET ACCT_AGENT = NULL WHERE CORPORATION_ID = 2 AND LAST_WORKED IS NULL"));

        // Update ADD_DATE to the correct format
        DB::select(DB::raw("UPDATE `$table_name` SET ADD_DATE = STR_TO_DATE(ADD_DATE,'%Y%m%d')"));
        DB::select(DB::raw("UPDATE `$table_name` SET ADD_DATE = null WHERE ADD_DATE = '0--';"));

        // Update ACCT_DUE_DATE to the correct format
        DB::select(DB::raw("UPDATE `$table_name` SET ACCT_DUE_DATE = STR_TO_DATE(ACCT_DUE_DATE,'%Y%m%d')"));
        DB::select(DB::raw("UPDATE `$table_name` SET ACCT_DUE_DATE = null WHERE ACCT_DUE_DATE = '0--';"));

        // Update ACCT_DOB to the correct format
        DB::select(DB::raw("UPDATE `$table_name` SET ACCT_DOB = STR_TO_DATE(ACCT_DOB,'%Y%m%d') WHERE ACCT_DOB IS NOT NULL"));
        DB::select(DB::raw("UPDATE `$table_name` SET ACCT_DOB = null WHERE ACCT_DOB = '0--' OR ACCT_DOB = '0';"));

        // Unassign all of the accounts in the temporary table
        DB::select(DB::raw("UPDATE `$table_name` SET ACCT_AGENT = null WHERE ACCT_AGENT IS NOT NULL;"));

        /**
         * Alter the table to match data types and naming conventions in Apollo
         * adds a lot of columns that we will work directly with before importing
         * the temporary table data into our active accounts table
         */
        DB::select(DB::raw('ALTER TABLE ' . $table_name . '
                            DROP MISC, DROP WORK_COMMENTS, DROP LAST_SEEN, DROP REMINDER,
                            CHANGE DIR_ID DIRECTORY_ALT_LINK VARCHAR(90), CHANGE UID ALT_ID VARCHAR( 90 ), CHANGE ACCT_COE TEAM_NAME VARCHAR( 90 ),
                            ADD COLUMN `CORPORATION_ID` VARCHAR(45) NOT NULL DEFAULT 2 AFTER ' . $lastHead . ',
                            ADD COLUMN `TEAM_ID` INT DEFAULT NULL AFTER CORPORATION_ID,
                            ADD COLUMN `PINPOINT` INT NOT NULL DEFAULT 0 AFTER TEAM_ID,
                            ADD COLUMN `ON_HOLD` INT DEFAULT 0 AFTER PINPOINT,
                            ADD COLUMN `POWERLEAD_FLAG` INT DEFAULT NULL AFTER ON_HOLD,
                            ADD COLUMN `DIRECTORY_FLAG` INT DEFAULT NUll AFTER POWERLEAD_FLAG,
                            ADD COLUMN `DIRECTORY_LINK` INT DEFAULT NULL AFTER DIRECTORY_FLAG,
                            ADD COLUMN `ACCESS_RULES` VARCHAR(45) DEFAULT NULL AFTER DIRECTORY_LINK,
                            ADD COLUMN `BLOCKED_CHECK` INT DEFAULT 1 AFTER ACCESS_RULES,
                            ADD COLUMN `NAME_MATCH` VARCHAR(45) DEFAULT NULL AFTER ACCESS_RULES'));

        /**
         * Create indexes in the temporary table to make querying it more efficient
         */
        DB::select(DB::raw("CREATE INDEX EMPL_NAME_INDEX ON `$table_name` (EMPL_NAME);"));
        DB::select(DB::raw("CREATE INDEX CAPCODE_INDEX ON `$table_name` (CAPCODE);"));
        DB::select(DB::raw("CREATE INDEX ACCT_AGENT_INDEX ON `$table_name` (ACCT_AGENT);"));

        /**
         * Set team ids based on the team name that is assigned to the accounts
         */
        DB::select(DB::raw("UPDATE `$table_name` tt INNER JOIN teams ON teams.name=tt.TEAM_NAME SET tt.TEAM_ID = teams.team_id WHERE teams.CORPORATION_ID=2"));

        /**
         * Convert the held accounts to the way we store them in Apollo
         * (including BOT accounts and queues 7720, 2001)
         */
        DB::select(DB::raw("UPDATE `$table_name` SET PINPOINT = 1, ON_HOLD = 1, ACCT_AGENT = NULL WHERE ACCT_AGENT = 'OVERFLOWED'"));
        DB::select(DB::raw("UPDATE `$table_name` SET ON_HOLD = 1, ACCT_AGENT = NULL WHERE ACCT_AGENT = 'SCOREHOLD'"));
        DB::select(DB::raw("UPDATE `$table_name` SET ON_HOLD = 1, ACCT_AGENT = 3333 WHERE ACCT_AGENT = 'RECALLED'"));
        DB::select(DB::raw("UPDATE `$table_name` SET ON_HOLD = 1 WHERE ACCT_AGENT IN (1901, 1902, 1904, 7720, 2001)"));

        /**
         * Display the correct capcode id for the imported accounts
         * (including setting the capcode 0 to NULL)
         */
        DB::select(DB::raw("UPDATE `$table_name` SET capcode = NULL WHERE capcode = 0;"));
        DB::select(DB::raw("UPDATE `$table_name` INNER JOIN capcodes on $table_name.capcode = capcodes.capcode SET $table_name.capcode = capcodes.id WHERE $table_name.capcode != 2302;"));

        /**
         * Take held 5C accounts (no matter if it is at pinpoint) and held RNN accounts off of hold
         * if they are not assigned to a BOT
         */
        DB::select(DB::raw("UPDATE `$table_name` SET ON_HOLD = 0 WHERE (TEAM_ID = 5 AND ON_HOLD = 1) OR (ON_HOLD = 1 AND CORPORATION_ID = 2 AND PINPOINT = 0 AND TEAM_ID != 10);"));

        /**
         * Clean up the directory link and last worked to null based on old rocky's null value
         */
        DB::select(DB::raw("UPDATE `$table_name` SET DIRECTORY_LINK = null WHERE DIRECTORY_ALT_LINK = 0 OR DIRECTORY_ALT_LINK = '';"));
        DB::select(DB::raw("UPDATE `$table_name` SET LAST_WORKED = null WHERE LAST_WORKED = ''"));

        /**
         * Set the timezone for the imported accounts based on which state they are located within
         */
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'AKST' where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('AK')"));
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'AST'  where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('PR', 'USVI')"));
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'CST'  where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('AL', 'AR', 'IL', 'IA', 'KS', 'KY', 'LA', 'MN', 'MS', 'MO', 'NE', 'ND', 'OK', 'TN', 'WI', 'TX')"));
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'EST'  where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('CT', 'DE', 'FL', 'GA', 'ME', 'MD', 'MA', 'MI' 'NH', 'NJ', 'NY', 'NC', 'OH', 'PA', 'RI', 'SC', 'VT', 'VA', 'DC', 'WV')"));
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'HST'  where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('HI')"));
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'MST'  where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('AZ', 'CO', 'ID', 'MT', 'NM', 'SD', 'UT', 'WY')"));
        DB::select(DB::raw("UPDATE $table_name SET TIME_ZONE = 'PST'  where (TIME_ZONE is null or TIME_ZONE = '') AND CORPORATION_ID = 2 and ACCT_ST in ('CA', 'NV', 'OR', 'WA')"));
    }
}
