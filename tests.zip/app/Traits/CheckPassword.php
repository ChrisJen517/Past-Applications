<?php

namespace App\Traits;

trait CheckPassword
{
    public function CheckPassword($password){
        if (strlen($password) < 10 && strlen($password) < 33) {
            return false;
        }
        //validate capital letter
        if (!preg_match('/[A-Z]/',$password)) {
            return false;
        }
    
        //validate lowercase letter
        if (!preg_match('/[a-z]/',$password)) {
            return false;
        }
    
        //validate number '/\\d/'
        if (!preg_match("/\\d/",$password)) {
            return false;
        }
    
        //validate special character 
        if (!preg_match('/^(?=.*?[?!@$%^&*-])/',$password)) {
            return false;
        }

        return true;
    }
}