<?php

namespace App\Traits;

use App\Models\Fax_Queue;
use App\RNNMailer;
use Auth;
use PHPMailer\PHPMailer\PHPMailer;
use Config;

Trait SetFaxEmail
{
    public function setFaxHistory($account, $fax, $company_name, $fullSSN, $active)
    {
        $history = new Fax_Queue();

        $history->account_id = $account->ID;
        $history->AGENT_ID = $account->ACCT_AGENT;
        $history->EMPL_NAME = $company_name;
        $history->EMPL_ST = $account->EMPL_ST;
        $history->EMPL_ZIP = $account->EMPL_ZIP;
        $history->EMPL_CITY = $account->EMPL_CITY;
        $history->EMPL_ADDR1 = $account->EMPL_ADDR1;
        $history->EMPL_ADDR2 = $account->EMPL_ADDR2;
        $history->EMPL_PHONE1_NMBR = $account->EMPL_PHONE1_NMBR;
        $history->EMPL_FAX = preg_replace('/[^0-9]/', '', $fax);
        $history->ACCT_LAST_NAME = $account->ACCT_LAST_NAME;
        $history->ACCT_FIRST_NAME = $account->ACCT_FIRST_NAME;

        //send full ssn or last 4 digits based on role and choice
        if($fullSSN == 1)
            $history->ACCT_SSN = $this->formatSSN($account->ACCT_SSN);
        else{
            $ssn = $this->formatSSN($account->ACCT_SSN);
            $history->ACCT_SSN = 'xxx-xx-' . substr($ssn, -4);
        }

        $history->role = Auth::user()->role;
        $history->active = $active;
        $history->sent = 0;
        $history->save();

        return $history;
    }


    public function setUpEmail($account, $email, $company, $ssn)
    {

        $fnm = ucfirst($account->ACCT_FIRST_NAME);
        $lnm = ucfirst($account->ACCT_LAST_NAME);
        $name = $fnm . ' ' . $lnm;
        $name = strtolower($name);
        $name = ucwords($name);
        // echo json_encode($ssn);
        $dt = date("Y-m-d");
        $to = $email;
        $from = "employmentverification@rnngroup.com";
        $subject = "Employment Verification, " . $name;
        $header = "Employment Verification";
        $message = "<html>
                        <body>

                        <div align='center' style='font-family:Arial, Helvetica, sans-serif; background:#ffffff !important'>
                          <table width='100%'  border='0' cellspacing='4' cellpadding='0'>
                                   <tr>
                                    <td align='left' valign='top'><p align='center' style='font:bold 22px/22px Arial, Helvetica, sans-serif;'>EMPLOYMENT VERIFICATION REQUEST
                                    </p>
                                    <p align='center' style='font:normal 12px/12px 'Trebuchet MS', Arial, Helvetica, sans-serif'>&nbsp;</p>
                                      <p style='font:normal 15px/22px 'Trebuchet MS', Arial, Helvetica, sans-serif'>Date: $dt<br>
                                      Reference #:<strong> " . $account->ID . "</strong><br>
                                      Company/Department/Name:<strong> " . $company . "</strong><br>
                                      Email: <strong>" . $email . "</strong><br>
                                      </p>
                                        <hr style=''>

                                    <p style='font:normal 15px/22px 'Trebuchet MS', Arial, Helvetica, sans-serif'>
                                    Hello,<br>
                                    I am reaching out today to verify employment on the individual below and sincerely appreciate if you can help me at your earliest convenience. <strong>Please note, no salary or wage information is needed.</strong>
                                    <br><br>
                                    Employee Name: <strong>" . $name . "</strong><br>";
        if (substr($ssn, 0, 1) == 'x') {
            $message = $message . "Employee SSN (Last 4): <strong>" . $ssn . "</strong>";
        } else {
            $message = $message . "Employee SSN: <strong>" . $ssn . "</strong>";
        }

        $message = $message . "<br><br>
                                    Thank you for verification and/or employment verification profile information below:
                                    <br>
                                    <table border='1' cellspacing='0' cellpadding='4' width='738'>
                                      <tr>
                                        <td width='375'><p align='center'><strong>Verification Question</strong></p></td>
                                        <td width='245' nowrap><p align='center'><strong>Response</strong></td>
                                      </tr>
                                      <tr>
                                        <td width='375'><strong>This individual is currently employed by your company? </strong></td>
                                        <td width='245' nowrap>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td width='375'><strong>Does this employee work over 30 hours per week?</strong></td>
                                        <td width='245' nowrap>&nbsp;</td>
                                      </tr>
                                      <tr>
                                        <td width='375'><strong>Your Name and Title:</strong> <strong></strong></td>
                                        <td width='245' nowrap><p>&nbsp;</p></td>
                                      </tr>
                                      <tr>
                                        <td width='375'><strong>Name of Company Correct?</strong></td>
                                        <td width='245' nowrap>" . $company . "</td>
                                      </tr>
                                      <tr>
                                        <td width='375'><strong>Is this the correct company address</strong> (please update if no)</td>
                                        <td width='245'>" . $account->EMPL_ADDR1 . " " . $account->EMPL_ADDR2 . " " . $account->EMPL_CITY . " " . $account->EMPL_ST . " " . $account->EMPL_ZIP . "</td>
                                      </tr>
                                    </table>
                                    <p>&nbsp;</p>
                                    <p style='font:normal 15px/22px 'Trebuchet MS', Arial, Helvetica, sans-serif'>
                                    Thanks so much in advance for your response at your convenience.
                                    <p style='font:normal 15px/22px 'Trebuchet MS', Arial, Helvetica, sans-serif'>
                                     With Sincere Appreciation,
                                     <br />
                                     <br>
                                     <strong>Dottie Harris </strong>| EMPLOYMENT VERIFICATION TEAM<br>
                                    <strong style='color:#B00000'>Main COE Phone: </strong>470-205-4014<br>
                                    <strong style='color:#B00000'>Fax: </strong>770-741-0982<br>
                                    <strong style='color:#B00000'>Website: </strong><a href='https://rnngroup.com' target='_blank'>www.rnngroup.com</a></p>
                                    <p><a href='https://rnngroup.com/'><img border='0' width='87' height='49' src='https://rnngroup.com/images/clip_image001.gif' alt='RNN Group Logo'></a>&nbsp;&nbsp;  &nbsp;<img border='0' width='46' height='46' src='https://rnngroup.com/images/clip_image003.jpg' alt='Inc5000 logo'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href='https://twitter.com/RNNGroupInc?lang=en'><img border='0' width='29' height='48' src='https://rnngroup.com/images/clip_image004.gif' alt='RNN Twitter'></a> &nbsp;&nbsp;<a href='https://www.linkedin.com/company/3620617/'><img border='0' width='30' height='30' src='https://rnngroup.com/images/clip_image005.png' alt='RNN LinkedIn'></a></p>
                                    <p style='font:normal 15px/22px 'Trebuchet MS', Arial, Helvetica, sans-serif'>If  you have any concerns or questions regarding this email, please email: <a href='mailto:response@rnngroup.com'>response@rnngroup.com</a>. We are here to serve you.</p>
                                     <p style='font:normal 9px/12px 'Trebuchet MS', Arial, Helvetica, sans-serif'>
                                     Disclaimer: Privileged/Confidential information may be contained in this message and may be subject to legal privilege. Access to this e-mail/fax by anyone other than the intended is unauthorized. If you are not the intended recipient (or responsible for delivery of the message to such person), you may not use, copy, distribute or deliver to anyone this message (or any part of its content) or take any action in reliance on it. In such case, you should destroy this message, and notify the sender immediately. If you have received this email in error, please notify us immediately by e-mail at itsupport@rnngroup.com and delete the e-mail from any computer. If you or your employer does not consent to internet e-mail messages of this kind, please notify us immediately at itsupport@rnngroup.com. All reasonable precautions have been taken to ensure no viruses are present in this e-mail. As our company cannot accept responsibility for any loss or damage arising from the use of this email or attachments we recommend that you subject these to your virus checking procedures prior to use. The views, opinions, conclusions and other information expressed in this electronic mail are not given or endorsed by the company unless otherwise indicated by an authorized representative independent of this message. If verification is required please request a hard-copy version to RNN Group INC, 101 Marietta Street NW, Suite 3305. Atlanta, GA 30363. https://rnngroup.com</p>

                                    </tr>
                                </table>
                        </div>
                          </body>
                        </html>";
        //environment check
        $env = Config::get('app.env');
        if ($env == 'prod') {
            return $this->sendEmail($to, $subject, $message, $header);
        }
    }

    public function sendEmail($email, $subject, $message, $header){
        $mail = new RNNMailer(true);

        //Recipients
        $mail->createHeader($header);
        $mail->setFrom('employmentverification@rnngroup.com', 'Employment Verification');
        $mail->addReplyTo('employmentverification@rnngroup.com', 'Employment Verification');
        $mail->addAddress($email);

        // Content<p>{{  }}</p>
        $mail->Subject = $subject;
        $mail->Body = $message;

        // Mail Send
        $mail->send();
    }
}
