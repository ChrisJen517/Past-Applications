<?php

namespace App\Traits;

use App\Models\Account_Source;
use App\Models\Active_Account;
use App\Models\Agent;

use App\Models\Access_Levels;
use App\Models\Team;
use DB;
use App\Jobs\TeamDistrubutionQueue;
use App\Traits\GetOrderArray;
use App\Traits\getIdCombinations;

trait AccountDistrubution
{
    use GetOrderArray, getIdCombinations;

    public function TeamDistrubution($corp_Id)
    {
            ini_set('memory_limit', '1024M');
            ini_set('max_execution_time', 720); //3 minutes
            ini_set('default_socket_timeout', 6000);

            $corporation_id = $corp_Id;
            $teams =  Team::select('team_id')->where('corporation_id', $corporation_id)->where('is_deactivated', 0)->where('team_id', '!=', 10)->get();
            $agents = Agent::where('corporation_id', $corporation_id)->with('user_link')->get();
            $team_rules = DB::SELECT(DB::RAW("SELECT team_id as 'teamid', (SELECT GROUP_CONCAT(distinct(has_access))  from users inner join agents on users.user_id = agents.user_id WHERE agents.team_id = teamid order by has_access) AS 'rule_team' FROM agents WHERE corporation_id = ".$corporation_id." AND team_id != 10 GROUP BY team_id;
            "));
            $query_builder = "SELECT ACCESS_RULES AS 'RULES', COUNT(ID) AS 'COUNT', (SELECT GROUP_CONCAT(id order by id) FROM access_levels WHERE FIND_IN_SET(shortcode, ACCESS_RULES) AND corporation_id = ".$corporation_id.") AS 'shortcode_id'";
            $count = 0;
            foreach($teams as $team){
                $query_builder = $query_builder.", (SELECT count(ID) from active_accounts where ACCESS_RULES = RULES and CORPORATION_ID = ".$corporation_id." and TEAM_ID = ".$team->team_id.") AS 'COUNT_".$team->team_id."',
                (0) AS 'ID_".$team->team_id."'";
            $count++;
            }
            $query_builder = $query_builder." FROM `active_accounts` WHERE `corporation_id` = ".$corporation_id." AND `TEAM_ID` IS NULL GROUP BY `ACCESS_RULES` LIMIT 50001";
            $available_counts = DB::SELECT(DB::RAW($query_builder));

            foreach($team_rules as $team){
                $array = explode(',',$team->rule_team);
                sort($array);
                if($array[0] == '')
                {
                    array_shift($array);
                }
                $array = collect($array);
                $array = $array->unique()->toArray();
                $teamAccessLevelsSet = [];
                $teamAccessLevels[$team->teamid] = $this->getIdCombinations($teamAccessLevelsSet, $array);

                $teamAccessLevels[$team->teamid] = collect($teamAccessLevels[$team->teamid]);

                $agents_by_team = $agents->where('team_id', $team->teamid);
                foreach($agents_by_team as $agent_by_team){
                    $rule_array = explode(',',$agent_by_team->user_link->has_access);
                    sort($rule_array);
                    if($rule_array[0] == '')
                    {
                        array_shift($rule_array);
                    }
                    $rule_array = collect($rule_array);
                    $rule_array = $rule_array->unique()->toArray();
                    $agentAccessSet = [];
                    $agentAccessLevels[$agent_by_team->agent_id] = $this->getIdCombinations($agentAccessSet, $rule_array);
                    $agentAccessLevels[$agent_by_team->agent_id] = collect($agentAccessLevels[$agent_by_team->agent_id]);
                }
            }

            foreach($available_counts as $available_count){
                if($available_count->RULES == '' || $available_count->RULES == NULL){

                    foreach($team_rules as $team){
                        $count_team_term = "ID_".$team->teamid;
                        $available_count->$count_team_term = 1;
                    }

                }else{
                    foreach($team_rules as $team){

                        $count_team_term = "ID_".$team->teamid;

                        if($teamAccessLevels[$team->teamid]->contains($available_count->shortcode_id))
                        {
                            $agents_by_team = $agents->where('team_id', $team->teamid);
                            foreach($agents_by_team as $agent_by_team){
                                if($agentAccessLevels[$agent_by_team->agent_id]->contains($available_count->shortcode_id)){
                                    $available_count->$count_team_term++;
                                }
                            }
                        }
                    }
                }
            }
            //if there are no accounts, ends the function
            if(count($available_counts) == 0)
                return;

            //makes sure at least one agent can work one kind of account
            $workable = false;
            $workableCount = 0;
            foreach($available_counts as $counts){
                $account = (array) $counts;
                foreach($teams as $team){
                    if($account['ID_'.$team->team_id] > 0){
                        $workable = true;
                        break;
                    }
                }
                if($workable)
                    $workableCount = $workableCount + $account['COUNT'];
            }
            if($workableCount == 0)
                return;
            elseif ($workableCount > 50000){
                $this->dispatch(new TeamDistrubutionQueue($corporation_id));
            }

            for($i = 0; $i < $count; $i++){
                $teamID[$i] = $teams[$i]->team_id;
                $teamUpdate[$i] = ' ';
                $teamCurrentCount[$i] = 0;
            }

            $count_team = 0;

            $account_sources = Account_Source::where('corporation_id', $corp_Id)->orderBy('priority')->get();
            $account_source_order = '';
            foreach($account_sources as $account_source)
            {
                $account_source_order = $account_source_order.'"'.$account_source->shortcode.'",';
            }
            $account_source_order =substr_replace($account_source_order ,"", -1);

            $orderArray = $this->getOrderArray($corp_Id);
            $first = $orderArray[0];
            $second = $orderArray[1];
            $third = $orderArray[2];

            foreach($available_counts as $available_count){
                // IF no rule exists normal distribution happens ELSE assures the team has someone that can work the rule
                for($i = 0; $i < $count; $i++){
                    $teamID[$i] = $teams[$i];
                    $teamUpdate[$i] = '';
                    $teamCurrentCount[$i] = 0;
                    $teamMax[$i] = 0;
                }
                if($available_count->RULES == '' || $available_count->RULES == NULL){
                    $active_accounts = Active_Account::select('ID')->where('corporation_id', $corporation_id)
                    ->where('TEAM_ID', null)->where('ACCESS_RULES', $available_count->RULES)
                    ->when($first, function ($query, $first) {
                        return $query->orderByRaw($first);
                    })
                    ->when($second, function ($query, $second) {
                        return $query->orderByRaw($second);
                    })
                    ->when($third, function ($query, $third) {
                        return $query->orderByRaw($third);
                    })->get();

                    foreach($active_accounts as $active_account)
                    {
                        $teamUpdate[$count_team] = $teamUpdate[$count_team].'"'.$active_account->ID.'",';
                        $count_team++;
                        if($count_team >= $count){
                            $count_team = 0;
                        }
                    }
                    $count_team = 0;
                    for($i = 0; $i < $count; $i++){
                        $teamUpdate[$i] =substr_replace($teamUpdate[$i] ,"", -1);
                        if($teamUpdate[$i] !=''){
                            DB::select( DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = '.$teams[$i]->team_id.'  WHERE `ID` IN ('.$teamUpdate[$i].');'));
                        }
                     }
                }else{
                    $active_accounts = Active_Account::select('ID')->where('corporation_id', $corporation_id)
                    ->where('TEAM_ID', null)->where('ACCESS_RULES', $available_count->RULES)
                    ->when($first, function ($query, $first) {
                        return $query->orderByRaw($first);
                    })
                    ->when($second, function ($query, $second) {
                        return $query->orderByRaw($second);
                    })
                    ->when($third, function ($query, $third) {
                        return $query->orderByRaw($third);
                    })->get();

                    $totalAgents = 0;
                    $arrayCountforSpecificRule = 0;
                    $totalAA = count($active_accounts);
                    $fullCount = 0;
                    // Seeing if the team has any agents that can work the rule
                    // If they can set up their information or remove them from array
                    for($i = 0; $i < $count; $i++){
                        $count_agent_term = "ID_".$teams[$i]->team_id;
                        if($available_count->$count_agent_term == 0){
                            array_pop($teamUpdate);
                            array_pop($teamCurrentCount);
                            array_pop($teamID);
                            array_pop($teamMax);
                        }else{
                            $count_team_term = "COUNT_".$teams[$i]->team_id;
                            $teamID[$arrayCountforSpecificRule] = $teams[$i]->team_id;
                            $totalAgents = $totalAgents + $available_count->$count_agent_term;
                            $teamCurrentCount[$arrayCountforSpecificRule] = $available_count->$count_team_term;
                            $fullCount = $fullCount + $teamCurrentCount[$arrayCountforSpecificRule];
                            $arrayCountforSpecificRule++;
                        }
                    }

                    if($totalAgents == 0){

                    }else{
                        $maxAgents = 0;
                        $maxFullCount = 0;
                        // Finding out if one team already has too many accounts based on how many agents they have
                        for($i =0; $i < $arrayCountforSpecificRule; $i++){
                            $count_agent_term = "ID_".$teamID[$i];
                            $count_team_term = "COUNT_".$teamID[$i];
                            $totalAAandTotalofEachTeam = $fullCount + $totalAA;
                            $percentageOfAccounts = $available_count->$count_agent_term / $totalAgents;
                            $totalAANeeded = ceil($totalAAandTotalofEachTeam * $percentageOfAccounts);
                            if($totalAANeeded <= $teamCurrentCount[$i]){
                                unset($teamCurrentCount[$i]);
                                unset($teamUpdate[$i]);
                                unset($teamID[$i]);
                                unset($teamMax[$i]);
                            }else{
                                $maxAgents = $maxAgents + $available_count->$count_agent_term;
                                $maxFullCount = $maxFullCount + $teamCurrentCount[$i];
                            }
                        }
                        $teamCurrentCount = array_values($teamCurrentCount);
                        $teamUpdate = array_values($teamUpdate);
                        $teamID = array_values($teamID);
                        $teamMax = array_values($teamMax);
                        $countForMaxSize = count($teamID);
                        // Determining how many accounts goes to each team
                        for($i=0; $i < $countForMaxSize; $i++){
                            $count_agent_term = "ID_".$teamID[$i];
                            $totalAAandTotalofEachTeam = $maxFullCount + $totalAA;
                            $percentageOfAccounts = $available_count->$count_agent_term / $maxAgents;
                            $totalAANeeded = ceil($totalAAandTotalofEachTeam * $percentageOfAccounts);
                            $teamMax[$i] = $teamCurrentCount[$i] - $totalAANeeded;
                            if($teamMax[$i] < 0){
                                $teamMax[$i] = $totalAA;
                            }
                            $teamCurrentCount[$i] = 0;
                        }

                $countTeam = 0;
                $agentLoop = 0;
                $mostAccounts = 0;
                // Looping through all active accounts in the rule set
                foreach($active_accounts as $active_account){
                    $count_agent_term = "ID_".$teamID[$countTeam];
                    // Checking to see if the team has reached its max accounts for the rule based on available agents
                    if($teamMax[$countTeam] < $teamCurrentCount[$countTeam]){
                        $teamUpdate[$countTeam] =substr_replace($teamUpdate[$countTeam] ,"", -1);
                        if($teamUpdate[$countTeam] !=''){
                            DB::select( DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = '.$teamID[$countTeam].'  WHERE `ID` IN ('.$teamUpdate[$countTeam].');'));
                        }
                        // Removing team from the array to continue assigning accounts to other teams in the array
                        unset($teamCurrentCount[$countTeam]);
                        unset($teamUpdate[$countTeam]);
                        unset($teamID[$countTeam]);
                        unset($teamMax[$countTeam]);

                        $teamCurrentCount = array_values($teamCurrentCount);
                        $teamUpdate = array_values($teamUpdate);
                        $teamID = array_values($teamID);
                        $teamMax = array_values($teamMax);
                        $countForMaxSize = count($teamID);
                    }

                    startCheck:
                    // This IF block checks to see if they have looped through each available agent on the team
                    // that can work accounts of this rule set and if they have look at the next team
                    if($available_count->$count_agent_term >= $agentLoop && $countTeam < $countForMaxSize){
                        $agentLoop++;
                    }
                    else{
                        $countTeam++;
                        // This IF block checks if they looked through all teams start back at the first one
                        if($countTeam >= $countForMaxSize){
                            $countTeam = 0;
                        }
                        $agentLoop = 0;
                        $count_agent_term = "ID_".$teams[$countTeam]->team_id;

                        goto startCheck;
                    }
                    $teamUpdate[$countTeam] = $teamUpdate[$countTeam].' '.$active_account->ID.',';
                    $teamCurrentCount[$countTeam]++;

                }
                for($i = 0; $i < $countForMaxSize; $i++){
                    $teamUpdate[$i] =substr_replace($teamUpdate[$i] ,"", -1);
                    if($teamUpdate[$i] !=''){
                        DB::select( DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = '.$teamID[$i].'  WHERE `ID` IN ('.$teamUpdate[$i].');'));
                    }
                 }
            }
            }
        }
    }

    public function setAgentQueue($company_id)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);

        //gets the teams, if no teams exist, returns
        $teams = Team::select('team_id')->where('corporation_id', $company_id)
        ->where('is_deactivated', 0)->where('team_id', '!=', 10)->get();

        foreach($teams as $team){
            $this->setAgentQueueByTeam($team->team_id);
        }
    }

    public function setAgentQueueByTeam($team_id)
    {
        //gets the teams, if no teams exist, returns
        $team = Team::find($team_id);
        $company_id = $team->corporation_id;
        if ($team == null) {
            return;
        }

        $agents = DB::SELECT(DB::RAW("SELECT
        agent_id,
        (SELECT has_access FROM users as u WHERE a.user_id = u.user_id ) as access_levels,
        (SELECT group_concat(shortcode) from access_levels WHERE FIND_IN_SET(id,access_levels)) AS shortcodes
        FROM agents as a INNER JOIN users on a.user_id = users.user_id
        where a.corporation_id = $team->corporation_id and team_id = $team->team_id and users.is_deactivated = 0 and users.active = 1 and a.active = 1 and a.paused = 0
        ORDER BY LENGTH(access_Levels) DESC"));

        //removed activity log code, was removed after activity log was disabled but kept for once it was fixed
        // join statement: left join activity_logs on users.user_id = activity_logs.user_id
        // where statement: and activity_logs.login >= DATE_SUB(NOW(),INTERVAL 12 HOUR)

        $query_builder = "SELECT ACCESS_RULES AS 'RULES',
        (SELECT GROUP_CONCAT(id order by id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) AND corporation_id = $team->corporation_id)  AS 'shortcode_id'";
        $count = 0;
        foreach($agents as $agent){
            $query_builder = $query_builder.", (0) AS 'ID_".$agent->agent_id."'";
        $count++;
        }
        $query_builder = $query_builder."FROM `active_accounts` WHERE `corporation_id` = ".$company_id." AND `TEAM_ID` = ".$team->team_id." AND `ACCESS_RULES` != '' AND `ACCESS_RULES` IS NOT NULL GROUP BY `ACCESS_RULES`";
        $agentRules = DB::SELECT(DB::RAW($query_builder));

        $agentAccessLevels = [];
        $ivr = [];
        $ivr_id = Access_Levels::where('shortcode', 'IVR')->where('corporation_id', $company_id)->first()->id;

        foreach($agents as $agent){
            $array = explode(',',$agent->access_levels);
            $agentAccessLevelSet = [];
            $agentAccessLevels[$agent->agent_id] = $this->getIdCombinations($agentAccessLevelSet, $array);

            $agentAccessLevels[$agent->agent_id] = collect($agentAccessLevels[$agent->agent_id]);

            if($agent->access_levels == $ivr_id)
                $ivr[]  = 'true';
            else
                $ivr[] = 'false';
        }

        foreach($agentRules as $agentRule){
            foreach($agents as $agent){
                $count_team_term = "ID_".$agent->agent_id;

                if($agentAccessLevels[$agent->agent_id]->contains($agentRule->shortcode_id))
                {
                    $agentRule->$count_team_term = 1;
                }
            }
        }
        //gets the corporations rules and the count of all their users
        $agentCounts = Active_Account::where('team_id', $team->team_id)->SELECT(DB::raw('count(*) as count, ACCT_AGENT'))->groupBy('ACCT_AGENT')->get();

        $orderArray = $this->getOrderArray($company_id, $team_id);
        $first = $orderArray[0];
        $second = $orderArray[1];
        $third = $orderArray[2];

        $numberOfAgents = count($agents);
        if($numberOfAgents == 0)
            return;

        $max = $team->max_accounts;
        // return $max;
            //gets the accounts for the team based on the number of priorities they set, if none uses just due date
            $teamAccounts = Active_Account::select('ID', 'ACCESS_RULES')
            ->where('TEAM_ID',  $team->team_id)->where('CORPORATION_ID', $team->corporation_id)
            ->where('ON_HOLD', '!=', 1)->where('ACCT_AGENT', null)
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })
            ->when($third, function ($query, $third) {
                return $query->orderByRaw($third);
            })
            ->get();

            if ($teamAccounts != null) {
                $teamMember = 0;

                //sets up the agents counts and the empty array for their inputs
                for ($teamMember = 0; $teamMember < $numberOfAgents; $teamMember++) {
                    $agentsAccounts[$teamMember] = '';
                    $agentAvailableRules[$teamMember][] = '';
                    $check = $agentCounts->where('ACCT_AGENT', $agents[$teamMember]->agent_id)->first();

                    if ($check == null) {
                        $agentLimit[$teamMember] = 0;
                        $agentID[$teamMember] = $agents[$teamMember]->agent_id;
                    }
                    else{
                        $agentLimit[$teamMember] = $check->count;
                        $agentID[$teamMember] = $agents[$teamMember]->agent_id;
                    }

                }

                $teamMember = 0;
                $removed_rules_count = 0;
                $removed_rules=[];
                foreach($agentRules as $agentRule){
                    $remove = 0;
                    $count_agent_term = "ID_".$agentID[$teamMember];
                    for($i=0; $i < $numberOfAgents; $i++){
                        $count_agent_term = "ID_".$agentID[$i];
                        if($agentRule->$count_agent_term <= 0){
                            $remove++;
                        }else{
                            $agentAvailableRules[$teamMember][] = $agentRule->RULES;
                        }

                        if($remove >= $numberOfAgents){
                            $removed_rules[$removed_rules_count] = $agentRule->RULES;
                            $removed_rules_count++;
                        }
                    }
                }

                for ($i = 0; $i < $numberOfAgents; $i++) {
                    $agentAvailableRules[$i] = collect($agentAvailableRules[$i]);
                }
                $removed_rules = collect($removed_rules);

                foreach ($teamAccounts as $account) {
                    startTeam:
                    if(!$removed_rules->isEmpty() && $removed_rules->contains($account->ACCESS_RULES) ){

                    }else{

                    //checks to see if any agents have hit their max
                    if ($agentLimit[$teamMember] >= $max) {
                        $count_agent_term = "ID_".$agentID[$teamMember];
                        if ($agentsAccounts[$teamMember] != "") {
                            $agentsAccounts[$teamMember] = substr_replace($agentsAccounts[$teamMember], "", -2);
                            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = ' . $agentID[$teamMember]. '  WHERE `ID` IN (' . $agentsAccounts[$teamMember] . ');'));
                        }
                        foreach($agentRules as $agentRule){
                            $remove = 0;
                            $count_agent_term = "ID_".$agentID[$teamMember];
                            $agentRule->$count_agent_term--;
                            for($i=0; $i < $numberOfAgents; $i++){
                                $count_agent_term = "ID_".$agentID[$i];
                                if($agentRule->$count_agent_term <= 0){
                                    $remove++;
                                }else{
                                    break;
                                }

                                if($remove >= $numberOfAgents){
                                    $removed_rules[$removed_rules_count] = $agentRule->RULES;
                                    $removed_rules_count++;
                                }
                            }
                        }
                        unset($agentID[$teamMember]);
                        unset($agentsAccounts[$teamMember]);
                        unset($agentLimit[$teamMember]);
                        unset($agentAvailableRules[$teamMember]);

                        $agentID = array_values($agentID);
                        $agentsAccounts = array_values($agentsAccounts);
                        $agentLimit = array_values($agentLimit);
                        $agentAvailableRules = array_values($agentAvailableRules);
                        $numberOfAgents = count($agentID);
                        if($numberOfAgents == 0){
                            return "done";
                        }

                        $teamMember++;
                        if ($teamMember >= $numberOfAgents) {
                            $teamMember = 0;
                        }

                        goto startTeam;
                    }

                    if($ivr[$teamMember] == 'true' && $account->ACCESS_RULES != 'IVR'){

                    }else if($ivr[$teamMember] == 'true' && $account->ACCESS_RULES == 'IVR'){
                        $agentsAccounts[$teamMember] = $agentsAccounts[$teamMember] . '"' . $account->ID . '", ';
                        $agentLimit[$teamMember]++;
                    }else if($account->ACCESS_RULES == null || $account->ACCESS_RULES == ""){

                        $agentsAccounts[$teamMember] = $agentsAccounts[$teamMember] . '"' . $account->ID . '", ';
                        $agentLimit[$teamMember]++;
                    }elseif($agentAvailableRules[$teamMember]->contains($account->ACCESS_RULES)){
                        $agentsAccounts[$teamMember] = $agentsAccounts[$teamMember] . '"' . $account->ID . '", ';
                        $agentLimit[$teamMember]++;
                    }
                    //adds to the users list of account ID's


                    //moves to the next team memeber
                    $teamMember++;
                    if ($teamMember >= $numberOfAgents) {
                        $teamMember = 0;
                    }

                }
            }
                //updates the database
                for ($teamMember = 0; $teamMember < $numberOfAgents; $teamMember++) {
                    if ($agentsAccounts[$teamMember] != "") {
                        $agentsAccounts[$teamMember] = substr_replace($agentsAccounts[$teamMember], "", -2);
                        DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = ' . $agentID[$teamMember] . '  WHERE `ID` IN (' . $agentsAccounts[$teamMember] . ');'));
                    }
                }
            }
    }

    public function redistributeToAgent($agent_id){

        $agent = Agent::with('user_link')->where('agent_id', $agent_id)->first();
        $team = Team::find($agent->team_id);

        $agentRules = DB::SELECT(DB::RAW("SELECT ACCESS_RULES AS 'RULES',
        (SELECT GROUP_CONCAT(id order by id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) and CORPORATION_ID = ".$agent->corporation_id.") AS 'shortcode_id',
                    (0) AS 'HAS_RULE'
                    FROM `active_accounts`
                    WHERE `corporation_id` = ".$agent->corporation_id."
                    AND `TEAM_ID` = ".$team->team_id."
                    AND `ACCESS_RULES` != '' AND `ACCESS_RULES` IS NOT NULL GROUP BY `ACCESS_RULES`"));

        $agentAccessLevels = [];
        $array = explode(',',$agent->user_link->has_access);
        $agentAccessLevelSet = [];
        $agentAccessLevels[$agent->agent_id] = $this->getIdCombinations($agentAccessLevelSet, $array);
        $agentAccessLevels[$agent->agent_id] = collect($agentAccessLevels[$agent->agent_id]);
        $notIn = [];
        foreach($agentRules as $agentRule){
            if($agentAccessLevels[$agent->agent_id]->contains($agentRule->shortcode_id))
            {
                $agentRule->HAS_RULE = 1;
            }
            else{
                $notIn[] = $agentRule->RULES;
            }
        }

        $orderArray = $this->getOrderArray($agent->corporation_id, $agent->team_id);
        $first = $orderArray[0];
        $second = $orderArray[1];
        $third = $orderArray[2];

        $active_accounts = Active_Account::select('ID', 'ACCESS_RULES')
        ->where('TEAM_ID', $agent->team_id)->where('CORPORATION_ID', $agent->corporation_id)
        ->where('ON_HOLD', '!=', 1)->where('ACCT_AGENT', null)
        ->when($first, function ($query, $first) {
            return $query->orderByRaw($first);
        })
        ->when($second, function ($query, $second) {
            return $query->orderByRaw($second);
        })
        ->when($third, function ($query, $third) {
            return $query->orderByRaw($third);
        })->when($notIn, function($query, $notIn){
            return $query->whereNotIn('ACCESS_RULES',$notIn);
        })
        ->limit($team->max_accounts)->get();

        $countAccounts = count($active_accounts);
        if($countAccounts <= 0){
            return 'Agent Unblocked, but no Accounts found to distribute';
        };

       $countAccounts = count($active_accounts);
        $active_account_ids = '';
        $ivr_id = Access_Levels::where('shortcode', 'IVR')->where('corporation_id', $agent->corporation_id)->first()->id;

        foreach($active_accounts as $active_account){
            if($agent->user_link->has_access == $ivr_id && $active_account->ACCESS_RULES != 'IVR')
                continue;
            $active_account_ids = $active_account_ids.'"'.$active_account->ID.'",';

        }
            $active_account_ids =substr_replace($active_account_ids ,"", -1);
            if ($active_account_ids!= "") {
            DB::select( DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = '.$agent->agent_id.'  WHERE `ID` IN ('.$active_account_ids.');'));
            }
            return "Agent Unblocked, and ".$countAccounts." accounts added to Agents Queue";
    }
}
