<?php

namespace App\Traits;

use Illuminate\Http\Request;
use App\Models\Active_Account;
use Auth;
use App\Models\Redistribution_Record;
use App\Models\Team;
use App\Traits\GetOrderArray;
use App\Traits\getIdCombinations;
use App\Models\Access_Levels;
use DB;

trait TossAccounts
{
    use GetOrderArray, getIdCombinations;

    //tosses to an agent (agent to agent or team to agent)
    public function tossAgentAccounts(Request $request)
    {   
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $teams = Team::where('corporation_id', $corporation_id);

        $orderArray = $this->getOrderArray($corporation_id);
        $first = $orderArray[0];
        $second = $orderArray[1];
        $third = $orderArray[2];

        $case = $request->account_case;
        $score = $request->score_select;
        $timezone = $request->timezone_select;
        $unworked = $request->unworked_check;
        if($request->toss_type == "Agent to Agent"){
            $fromAgent = $request->agent_selected;
            $fromTeam = null;
        }
        else{
            $fromAgent = null;
            $fromTeam = $request->team_selected;
        }
        $sendAgents = $request->send_to_agent;

        $accounts = Active_Account::select('ID', 'ACCT_AGENT','ACCESS_RULES')
            ->when($fromAgent, function ($query, $fromAgent) { return $query->where('ACCT_AGENT', $fromAgent); })
            ->when($fromTeam, function ($query, $fromTeam) { 
                return $query->where('TEAM_ID', $fromTeam)->whereNull('ACCT_AGENT'); 
            })
            ->where('CORPORATION_ID', $corporation_id)
            ->where('ON_HOLD', 0)
            ->when($case, function ($query) use ($case) {return $query->whereIn('ACCT_CASE', $case); })
            ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
            ->when($timezone, function ($query, $timezone) { return $query->where('TIME_ZONE', $timezone);})  
            ->when($unworked, function ($query) { return $query->where(function ($q) {$q->whereNull('LAST_WORKED')->orWhere('LAST_WORKED', ' ');});})
            ->when($first, function ($query, $first) { return $query->orderByRaw($first); })
            ->when($second, function ($query, $second) { return $query->orderByRaw($second); })
            ->when($third, function ($query, $third) { return $query->orderByRaw($third); })
            ->orderBy('LAST_WORKED') 
            ->get();


        $agentList = implode(',',$sendAgents);
        $maxNeeded = $request->max_per_to * count($sendAgents);
        //gets the list of agents and their access levels
        $agents = DB::SELECT(DB::RAW("SELECT 
        agent_id, team_id,
        (SELECT has_access FROM users as u WHERE a.user_id = u.user_id ) as access_levels,
        (SELECT group_concat(shortcode) from access_levels WHERE FIND_IN_SET(id,access_levels)) AS shortcodes
        FROM agents as a INNER JOIN users on a.user_id = users.user_id 
        where corporation_id = $corporation_id and agent_id IN ($agentList) and users.is_deactivated = 0 ORDER BY LENGTH(access_Levels) DESC"));

        //gets all possible combinations in the company accounts
        $query_builder = "SELECT ACCESS_RULES AS 'RULES', 
        (SELECT GROUP_CONCAT(id order by id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) AND corporation_id = $corporation_id)  AS 'shortcode_id'";
        $count = 0; 
        foreach($agents as $agent){
            $query_builder = $query_builder.", (0) AS 'ID_".$agent->agent_id."'";
            $count++;
        }        
        $query_builder = $query_builder."FROM `active_accounts` WHERE `corporation_id` = ".$corporation_id; 
        if($fromAgent != null)
            $query_builder = $query_builder. " AND `ACCT_AGENT` = $fromAgent"; 
        else
            $query_builder = $query_builder. " AND `TEAM_ID` = $fromTeam";
        $query_builder = $query_builder." AND `ACCESS_RULES` != '' AND `ACCESS_RULES` IS NOT NULL GROUP BY `ACCESS_RULES`";
        $agentRules = DB::SELECT(DB::RAW($query_builder));
        $agentAccessLevels = [];

        $agentCounts = Active_Account::selectRaw('count(*) as totalAccounts, ACCT_AGENT')->whereIn('ACCT_AGENT', $sendAgents)->groupBy('ACCT_AGENT')->get();
        $totalCount = count($accounts);
        if ($request->max_per_to)
            $baseMax = $request->max_per_to;
        else
            $baseMax = ceil($totalCount / count($sendAgents));

        //initialize count and agent arrays, and get list of agent access level combinations
        $ruleSet = [];
        $max = [];
        $ivr = [];
        $ivr_id = Access_Levels::where('shortcode', 'IVR')->where('corporation_id', $corporation_id)->first()->id;
        foreach($agents as $agent){
            $array = explode(',',$agent->access_levels);
            $agentAccessLevelSet = [];
            $agentAccessLevels[] = collect($this->getIdCombinations($agentAccessLevelSet, $array));
        
            if($agent->access_levels == $ivr_id)
                $ivr[]  = 'true';
            else
                $ivr[] = 'false';
            
            $agentCountArray[] = 0;
            $agentUpdateArray[] = "";
            $agentTeamInfoArray[] = $agent->team_id;
            $ruleSet[] = [];

            //sets the maximum for each agent based on if the teams max or the requested max is lower
            $teamsMax = $teams->where('team_id', $agent->team_id)->first()->max_accounts;
            $totalAccounts = $agentCounts->where('ACCT_AGENT', $agent->agent_id)->first()->totalAccounts ?? 0;
            $maximumNeeded = $teamsMax - $totalAccounts;
            if($maximumNeeded < $baseMax)
                $max[] = $maximumNeeded;
            else
                $max[] = $baseMax;
        }

        //gets the set of workable rules for each agent
        $nonWorkableCodes = [];
        $removeMessage = "";
        foreach($agentRules as $agentRule){
            $i = 0;
            $notWorkable = true;
            foreach($agents as $agent){

                if($agentAccessLevels[$i]->contains($agentRule->shortcode_id))
                {
                    $ruleSet[$i][] = strtoupper($agentRule->RULES);
                    $ruleSet[$i][] = strtolower($agentRule->RULES);
                    $notWorkable = false;
                }

                $i++;
            }

            //adds to array of non workable accounts
            if($notWorkable){
                $nonWorkableCodes[] = strtolower($agentRule->RULES);
                $nonWorkableCodes[] = strtoupper($agentRule->RULES);
                $removeMessage = $agentRule->RULES.', '.$removeMessage;
            }
        }

        //removes accounts that cannot be worked
        if(!empty($nonWorkableCodes)){
            $removedCount = count($accounts->whereIn('ACCESS_RULES',$nonWorkableCodes));
            $accounts = $accounts->whereNotIn('ACCESS_RULES',$nonWorkableCodes);
            $removeMessage = substr_replace($removeMessage, "", -2);
        }
        
        //gets the total count and the max based on the information given
        $movedAccounts = 0;
        $lefToMove = 0;
        $totalCount = count($accounts);
        while ($totalCount > 0) {
            $i = 0;
            foreach ($accounts as $account) {

                $totalCount--;
                $i++;
                //checking to see if looped through all agents
                if ($i >= count($sendAgents)) {
                    $i = 0;
                }

                $loopcount = 0;
                $teamMemberStart = $i;
                $maxCount = 0;
                startCheckRule:
                //checking to see if agent has reached max
                if ($agentCountArray[$i] >= $max[$i]) {
                    $maxCount++;
                    //check to see if all agents have reached max
                    if ($maxCount == count($agentCountArray)) {
                        break;
                    }
                    else{
                        $i++;
                        if ($i >= count($sendAgents)) {
                            $i = 0;
                        }
                        goto startCheckRule;
                    }
                }
                //add acct_id to agent array
                if($ivr[$i] == 'true' && $account->ACCESS_RULES != 'IVR'){
                    $loopcount++;
                }else if($ivr[$i] == 'true' && $account->ACCESS_RULES == 'IVR'){
                    $agentUpdateArray[$i] = $agentUpdateArray[$i] . '"' . $account->ID . '", ';
                    $agentCountArray[$i] += 1;
                    $movedAccounts++;
                }else if(($account->ACCESS_RULES == null) || ($account->ACCESS_RULES == "")){
                    $agentUpdateArray[$i] = $agentUpdateArray[$i] . '"' . $account->ID . '", ';
                    $agentCountArray[$i] += 1;
                    $movedAccounts++;
                }elseif(in_array($account->ACCESS_RULES, $ruleSet[$i])){
                    $agentUpdateArray[$i] = $agentUpdateArray[$i] . '"' . $account->ID . '", ';
                    $agentCountArray[$i] += 1;
                    $movedAccounts++;
                    $i = $teamMemberStart;
                }elseif($loopcount >= count($sendAgents)){
                    $i = $teamMemberStart;
                }else{
                    $i++;
                    if ($i >= count($sendAgents)) {
                        $i = 0;
                    }
                    $loopcount++;
                    goto startCheckRule;
                } 
            }
        }
    
        //updates the database
        for ($i = 0; $i < count($sendAgents); $i++) {
            if ($agentUpdateArray[$i] != "") {
                $agentUpdateArray[$i] = substr_replace($agentUpdateArray[$i], "", -2);
                $team = $teams->where('team_id', $agentTeamInfoArray[$i])->first();
                DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = ' . $sendAgents[$i] . ', `TEAM_ID` = '.$team->team_id.', `TEAM_NAME` = "'.$team->name.'", UPDATED_AT = NOW()   
                                    WHERE `ID` IN (' . $agentUpdateArray[$i] . ');'));
            }
        }

        //add redistribution record to update agent queues
        $redistribution_record = new Redistribution_Record();
        $redistribution_record->corporation_id = $corporation_id;
        $redistribution_record->team_id = 0;
        $redistribution_record->save();
        
        //if an account had to be removed, displays an error
        if($removeMessage != "" && $movedAccounts < $maxNeeded){
            $lefToMove = abs($maxNeeded - $movedAccounts);
            return back()->with('error', 'Unable to assign '.$lefToMove.' accounts, agents were missing following access rules: '.$removeMessage.'. Accounts with those Access Rules: '.$removedCount);
        }else
            return back()->with('success', 'Successfully Updated Accounts');
    }

    //tosses to a team (agent to team ot team to team)
    public function tossTeamAccounts(Request $request)
    { 
        $corporation_id = Auth::User()->corporation_corporate_admin_link->corporation_id;
        $team = Team::where('team_id', $request->send_to_team)->first();

        $orderArray = $this->getOrderArray($corporation_id);
        $first = $orderArray[0];
        $second = $orderArray[1];
        $third = $orderArray[2];

        $case = $request->account_case;
        $score = $request->score_select;
        $timezone = $request->timezone_select;
        $unworked = $request->unworked_check;

        if($request->toss_type == "Agent to Team"){
            $fromAgent = $request->agent_selected;
            $fromTeam = null;
        }
        else{
            $fromAgent = null;
            $fromTeam = $request->team_selected;
        }

        //selects 
        $accounts = Active_Account::select('ID', 'ACCT_AGENT','ACCESS_RULES')
            ->when($fromAgent, function ($query, $fromAgent) { return $query->where('ACCT_AGENT', $fromAgent); })
            ->when($fromTeam, function ($query, $fromTeam) { return $query->where('TEAM_ID', $fromTeam); })
            ->where('CORPORATION_ID', $corporation_id)
            ->where('ON_HOLD', 0)
            ->when($case, function ($query) use ($case) {return $query->whereIn('ACCT_CASE', $case); })
            ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
            ->when($timezone, function ($query, $timezone) { return $query->where('TIME_ZONE', $timezone);})  
            ->when($unworked, function ($query) { return $query->where(function ($q) {$q->whereNull('LAST_WORKED')->orWhere('LAST_WORKED', ' ');});})
            ->when($first, function ($query, $first) { return $query->orderByRaw($first); })
            ->when($second, function ($query, $second) { return $query->orderByRaw($second); })
            ->when($third, function ($query, $third) { return $query->orderByRaw($third); })
            ->orderBy('LAST_WORKED') 
            ->get();

        $sendTeam = $request->send_to_team;
        //gets the list of agents and their access levels
        $agents = DB::SELECT(DB::RAW("SELECT 
        agent_id,
        (SELECT has_access FROM users as u WHERE a.user_id = u.user_id ) as access_levels,
        (SELECT group_concat(shortcode) from access_levels WHERE FIND_IN_SET(id,access_levels)) AS shortcodes
        FROM agents as a INNER JOIN users on a.user_id = users.user_id 
        where corporation_id = $corporation_id and team_id = $sendTeam and users.is_deactivated = 0 ORDER BY LENGTH(access_Levels) DESC"));

        $maxNeeded = $request->max_per_to;

        //gets all possible combinations in the company accounts
        $query_builder = "SELECT ACCESS_RULES AS 'RULES', 
        (SELECT GROUP_CONCAT(id order by id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) AND corporation_id = $corporation_id)  AS 'shortcode_id'";
        $count = 0; 
        foreach($agents as $agent){
            $query_builder = $query_builder.", (0) AS 'ID_".$agent->agent_id."'";
            $count++;
        }        
        $query_builder = $query_builder."FROM `active_accounts` WHERE `corporation_id` = ".$corporation_id; 
        if($fromAgent != null)
            $query_builder = $query_builder. " AND `ACCT_AGENT` = $fromAgent"; 
        else
            $query_builder = $query_builder. " AND `TEAM_ID` = $fromTeam";
        $query_builder = $query_builder." AND `ACCESS_RULES` != '' AND `ACCESS_RULES` IS NOT NULL GROUP BY `ACCESS_RULES`";
        $agentRules = DB::SELECT(DB::RAW($query_builder));

        $agentAccessLevels = [];

        //initialize count and agent arrays, and get list of agent access level combinations
        $ruleSet = [];
        foreach($agents as $agent){
            $array = explode(',',$agent->access_levels);
            $agentAccessLevelSet = [];
            $agentAccessLevels[] = collect($this->getIdCombinations($agentAccessLevelSet, $array));
        
            $agentCountArray[] = 0;
            $agentUpdateArray[] = "";
            $ruleSet[] = [];
        }
        $ivr = Access_Levels::where('shortcode', 'IVR')->where('corporation_id', $corporation_id)->first();

        //gets the set of workable rules for each agent
        $nonWorkableCodes = [];
        $removeMessage = "";
        foreach($agentRules as $agentRule){
            $i = 0;
            $notWorkable = true;
            foreach($agents as $agent){
                if($agentAccessLevels[$i]->contains($agentRule->shortcode_id))
                {
                    $ruleSet[$i][] = strtoupper($agentRule->RULES);
                    $ruleSet[$i][] = strtolower($agentRule->RULES);
                    $notWorkable = false;
                }else if($agentAccessLevels[$i]->contains($ivr->id)) {
                    $ruleSet[$i][] = strtoupper($ivr->shortcode);
                    $notWorkable = false;
                }

                $i++;
            }

            //adds to array of non workable accounts
            if($notWorkable){
                $nonWorkableCodes[] = strtolower($agentRule->RULES);
                $nonWorkableCodes[] = strtoupper($agentRule->RULES);
                $removeMessage = $agentRule->RULES.', '.$removeMessage;
            }
        }

        //removes accounts that cannot be worked
        if(!empty($nonWorkableCodes)){
            $removedCount = count($accounts->whereIn('ACCESS_RULES',$nonWorkableCodes));
            $accounts = $accounts->whereNotIn('ACCESS_RULES',$nonWorkableCodes);
            $removeMessage = substr_replace($removeMessage, "", -2);
        }

        //gets the total count and the max based on the information given
        $movedAccounts = 0;
        $lefToMove = 0;
        $teamUpdateArray = [];
        if ($request->max_per_to)
            $max = $request->max_per_to;
        else
            $max = count($accounts);

        foreach ($accounts as $account) {
            //checks to see if they have hit max, if so ends the loop
            if(count($teamUpdateArray) >= $max)
                break;
            
            //next checks if there is no rule, if so adds it then moves to the next account
            if(($account->ACCESS_RULES == null) || ($account->ACCESS_RULES == "") || ($account->ACCESS_RULES == " ")){
                
                $valid = true;
                foreach($ruleSet as $agentRules){
                    //assures that at least one agent has this access rule, if so adds the account and ends the agent loop
                    if(in_array('IVR', $agentRules)){
                        $valid = false;
                    } else {
                        $valid = true;
                        break;
                    }
                }
                if($valid) {
                    $teamUpdateArray[] = $account->ID;
                }
                continue;
            }

            //if the account has an access rule, checks all agents for said rule
            foreach($ruleSet as $agentRules){
                //assures that at least one agent has this access rule, if so adds the account and ends the agent loop
                if(in_array($account->ACCESS_RULES, $agentRules)){
                    $teamUpdateArray[] = $account->ID;
                    break;
                }
            }
        }
        
        if (!empty($teamUpdateArray)) {
            $teamUpdateArray =  implode(',',$teamUpdateArray);
            DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = null, `TEAM_ID` = '.$team->team_id.', `TEAM_NAME` = "'.$team->name.'", UPDATED_AT = NOW()  WHERE `ID` IN (' . $teamUpdateArray . ');'));
        
            //add redistribution record to update agent queues
            $redistribution_record = new Redistribution_Record();
            $redistribution_record->corporation_id = $corporation_id;
            $redistribution_record->team_id = 0;
            $redistribution_record->save();
        }
        
        //if an account had to be removed, displays an error
        if($removeMessage != "" && $movedAccounts < $maxNeeded){
            $lefToMove = abs($maxNeeded - $movedAccounts);
            return back()->with('error', 'Unable to assign '.$lefToMove.' accounts, agents were missing following access rules: '.$removeMessage.'. Accounts with those Access Rules: '.$removedCount);
        }else
            return back()->with('success', 'Successfully Updated Accounts');
    }
}