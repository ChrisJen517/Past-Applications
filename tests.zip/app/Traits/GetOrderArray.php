<?php

namespace App\Traits;

use App\Models\Account_Source;
use App\Models\Distribution_Rules;
use App\Models\Team_Distribution_Rules;

trait GetOrderArray
{
    //gets the order of accounts based on the team or corporation rules
    public function getOrderArray($corporation_id, $team_id = null)
    {
        $orderArray[0] = null;
        $orderArray[1] = null;
        $orderArray[2] = null;

        //if no team is set, go off the corporation rules
        if($team_id != null)
            $rules = Team_Distribution_Rules::where('team_id', $team_id)->first();
        else
            $rules = Distribution_Rules::where('corporation_id', $corporation_id)->first();

        if ($rules != null) {
            $account_sources = Account_Source::Select('shortcode')->where('corporation_id', $corporation_id)->orderBy('priority')->get();
            $account_source_order = '';

            foreach ($account_sources as $account_source) {
                $account_source_order = '"' . $account_source->shortcode . '",' . $account_source_order;
            }
            $account_source_order = substr_replace($account_source_order, "", -1);

            $orderArray[0] = $rules->priority;
            $orderArray[1] = $rules->second_priority;
            $orderArray[2] = $rules->third_priority;

            for ($i = 0; $i < 3; $i++) {
                if ($orderArray[$i] == 'ACCT_SOURCE') {
                    if($account_source_order != '')
                        $orderArray[$i] = "FIELD(ACCT_SOURCE, " . $account_source_order . ") DESC";
                    else
                        $orderArray[$i] = null;
                } elseif ($orderArray[$i] == 'POESCORE') {
                    $orderArray[$i] = "POESCORE DESC";
                }
            }
        }
        return $orderArray;
    }
}