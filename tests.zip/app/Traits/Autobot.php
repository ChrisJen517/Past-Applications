<?php

namespace App\Traits;

use App\Models\Capcode;
use App\Models\Worked_History;

trait Autobot {
    use SetFaxEmail;

    private function sendBottyAutoFax($fax, $employer_name, $active_account, $email, $date, $agent_id, $origin) {
        if($email == 1)
            $capcode = Capcode::where('capcode', 2211)->where('corporation_id', $active_account->CORPORATION_ID)->first();
        else
            $capcode = Capcode::where('capcode', 2216)->where('corporation_id', $active_account->CORPORATION_ID)->first();

        $active_account->CAPCODE = $capcode->id;
        $active_account->EMPL_FAX = $fax;
        $active_account->LAST_WORKED = $date;
        $active_account->TEAM_ID = 10;
        $active_account->TEAM_NAME = "BOT";
        $active_account->ACCT_AGENT = 1901; // * Botty

        $worked_history = new Worked_History;
        $worked_history->active_account_id = $active_account->ID;
        $worked_history->agent_id = 1901;
        $worked_history->user_role = 'agent';
        $worked_history->capcode = $capcode->id;
        $worked_history->notes = 'Auto Fax Sent by ' . ucwords(str_replace('_', ' ', $origin)).'. Sent to: '.$fax.', Employer name: '.$employer_name;;
        $worked_history->created_at = date('Y-m-d H:i:s');
        $worked_history->updated_at = date('Y-m-d H:i:s');
        $worked_history->save();

        $this->setFaxHistory($active_account, $fax, $employer_name, 0, 1);
    }

    private function sendDottyAutoEmail($email, $employer_name, $active_account, $fax, $date, $agent_id, $isHotty, $origin) {
        if($fax == 1)
            $capcode = Capcode::where('capcode', 2211)->where('corporation_id', $active_account->CORPORATION_ID)->first();
        else
            $capcode = Capcode::where('capcode', 2217)->where('corporation_id', $active_account->CORPORATION_ID)->first();

        $active_account->CAPCODE = $capcode->id;
        $active_account->EMPL_EMAIL = $email;
        $active_account->LAST_WORKED = $date;
        $active_account->TEAM_ID = 10;
        $active_account->TEAM_NAME = "BOT";
        $active_account->ACCT_AGENT = $isHotty ? 1904 : 1902; // * Hotty / Dotty

        $worked_history = new Worked_History();
        $worked_history->capcode = $capcode->id;
        $worked_history->active_account_id = $active_account->ID;
        $worked_history->agent_id = $isHotty ? 1904 : 1902;
        $worked_history->user_role = 'agent';
        $worked_history->notes = 'Auto Email Sent by ' . ucwords(str_replace('_', ' ', $origin)).'. Sent to: '.$email.', Employer name: '.$employer_name;
        $worked_history->created_at = date('Y-m-d H:i:s');
        $worked_history->updated_at = date('Y-m-d H:i:s');
        $worked_history->save();

        $ssn = $this->formatSSN($active_account->ACCT_SSN);
        $ssn = 'xxx-xx-' . substr($ssn, -4);
        $this->setUpEmail($active_account, $email, $employer_name, $ssn);
    }

    private function hottyDomainSearch($domain) {
        $api_key = 'a52258fc350e4da8aac51cf059de77ff';
        $addr = ['hr', 'payroll', 'accounting'];
        $data = new \stdClass;
        $data->found = 0;
        foreach($addr as $prefix) {
            $email = $prefix . '@' . $domain;
            $url = 'https://api.zerobounce.net/v2/validate?api_key='.$api_key.'&email='.urlencode($email).'&ip_address=';
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_SSLVERSION, 6);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
            curl_setopt($ch, CURLOPT_TIMEOUT, 150);
            echo $response = curl_exec($ch);
            if (empty($response))
                continue;
            curl_close($ch);
            if (empty(json_decode($response, true)))
                continue;
            extract(json_decode($response, true));
            if ($status=='valid' || $status=='do_not_mail') {
                $data->found = 1;
                $data->prefix = $prefix;
                break;
            }
            if ($mx_found=='false') {
                break;
            }
        }
        return $data;
    }

    private function formatSSN($ssn)
    {
        if (strlen($ssn) < 9) {
            $ssn = str_pad($ssn, 9, '0', STR_PAD_LEFT);
        }

        if (preg_match("#^\d{3}-?\d{2}-?\d{4}$#", $ssn)) {
            return preg_replace("#^(\d{3})-?(\d{2})-?(\d{4})$#", "$1-$2-$3", $ssn);
        }

        return null;
    }
}
