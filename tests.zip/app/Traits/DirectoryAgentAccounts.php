<?php

namespace App\Traits;


use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Setting;
use DB;

trait DirectoryAgentAccounts
{
    //removes accounts from a selected agent
    public function removeAccounts($agentId){
        $accounts = Directory_Active_Account::where('directory_agent_id', $agentId)->select('directory_account_id')->get();

        //gets a list of ids
        $ids = "";
        foreach($accounts as $account){
            $ids = $account->directory_account_id.", ".$ids;
        }

        //mass updates the agent field to null
        if($ids != ""){
            $ids = substr_replace($ids, "", -2);
            DB::select(DB::raw('UPDATE `directory_active_accounts` SET `directory_agent_id` = null WHERE `directory_account_id` IN ('.$ids.');'));
        }
    }

    public function distributeDirectory(){
        //gets needed information
        $directoryAgent = Directory_Agent::where('active', 1)->get();
        $agentCounts = Directory_Active_Account::SELECT(DB::raw('count(*) as count, directory_agent_id'))->groupBy('directory_agent_id')->get();
        $max = Directory_Setting::first()->max_accounts;
        $agentNumber = 0;
        $numberOfAgents = count($directoryAgent);
        $allAgents['fresh'] = 0;
        $allAgents['phone_verified'] = 0;

        //sets up the agents arrays
        foreach($directoryAgent as $agent){
            $check = $agentCounts->where('directory_agent_id', $agent->directory_agent_id)->first()->count ?? 0;

            if($check >= $max){
                $numberOfAgents = $numberOfAgents - 1;
            }
            else{
                $directoryAgentInfo[$agent->dir_account_type][] =[
                    "NUMBER_OF_ACCOUNTS" => $check,
                    "AA_IDS" => '',
                    "AGENT_ID" => $agent->directory_agent_id,
                ];
                $agentNumber++;
                $allAgents[$agent->dir_account_type]++;
            }
        }

        if(count($directoryAgentInfo) == 0)
            return;

        $neededAccounts = $max * $numberOfAgents;
        if($neededAccounts > 10000)
            $neededAccounts = 10000;

        //gets the accounts to distribute
        $seperatedAccounts['fresh'] = Directory_Active_Account::where('directory_agent_id', null)
        ->where(function($q) { $q->where('fresh_flag', 1)->orwhere('live_flag', 1);})
        ->orderBy('due_date', 'asc')->orderBy('created_at', 'asc')->limit($neededAccounts)->select('directory_account_id')->get();
        $seperatedAccounts['phone_verified'] = Directory_Active_Account::where('directory_agent_id', null)->where('phone_verified', 1)
        ->orderBy('created_at', 'asc')->limit($neededAccounts)->select('directory_account_id')->get();

        foreach($directoryAgentInfo as $type => $agentInfo){
            // Mass Update
            $agentNumber = 0;
            $checkedAll = 0;

            $activeAccounts = $seperatedAccounts[$type];
            $numberOfAgents = $allAgents[$type];

            //if there are no agents or accounts skips to the next type
            if($activeAccounts->count() == 0 || $numberOfAgents == 0)
                continue;

            foreach($activeAccounts as $active_account){
                startTeam:
                if ($agentInfo[$agentNumber]["NUMBER_OF_ACCOUNTS"] >= $max) {
                    $checkedAll++;
                    if ($checkedAll == $numberOfAgents) {
                        break;
                    }

                    $agentNumber++;
                    if ($agentNumber == $numberOfAgents) {
                        $agentNumber = 0;
                    }

                    goto startTeam;
                } else {
                    $checkedAll = 0;
                }

                $agentInfo[$agentNumber]["AA_IDS"] = $agentInfo[$agentNumber]["AA_IDS"].'"' . $active_account->directory_account_id . '",';
                $agentInfo[$agentNumber]["NUMBER_OF_ACCOUNTS"]++;

                $agentNumber++;
                if ($agentNumber == $numberOfAgents) {
                    $agentNumber = 0;
                }
            }

            //updates the database
            foreach($agentInfo as $directoryAgent) {
                if ($directoryAgent["AA_IDS"] != "") {
                    $directoryAgent["AA_IDS"] = substr_replace($directoryAgent["AA_IDS"], "", -1);
                    DB::select(DB::raw('UPDATE `directory_active_accounts` SET `directory_agent_id` = '.$directoryAgent["AGENT_ID"].' WHERE `directory_account_id` IN ('.$directoryAgent["AA_IDS"].');'));
                }
            }
        }
    }

}
