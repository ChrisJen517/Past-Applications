<?php

namespace App\Traits;

trait getIdCombinations
{
    //gets a full list of combinations that an agent can work
    //passes in the result array, all combinations used previously, and the array of all current shortcode ids
    public function getIdCombinations($results, $shortCodes){
        //if there is only one number in the array passes it back
        if(count($shortCodes) == 1){
            if(!in_array($shortCodes[0], $results))
                $results[] = $shortCodes[0];
            return $results;
        }
        else{
            //gets the current list
            $fullCombo = implode(',', $shortCodes);

            //if the current list exists returns
            if(in_array($fullCombo, $results))
                return $results;
            else{
                $results[] = $fullCombo;

                //runs through the array removing one of the ids each time
                foreach($shortCodes as $key => $arr){
                    $smallerArray = [];
                    foreach($shortCodes as $id){
                        if($id != $shortCodes[$key])
                            $smallerArray[] = $id;
                    }

                    //itterates and restarts with the new smaller array 
                    $results = $this->getIdCombinations($results, $smallerArray);
                }

                //after going through the entire array returns
                return $results;
            }
        }
    }

    //gets list of all combinations
    //pass in he array to get combinations, blank string, desired output array
    function getAllCombinations($arr, $temp_string, &$collect) {
        if ($temp_string != "") 
            $collect []= $temp_string;
    
        for ($i=0, $iMax = sizeof($arr); $i < $iMax; $i++) {
            $arrcopy = $arr;
            $elem = array_splice($arrcopy, $i, 1); // removes and returns the i'th element
            if (sizeof($arrcopy) > 0) {
                $this->getAllCombinations($arrcopy, $temp_string ." " . $elem[0], $collect);
            } else {
                $collect []= $temp_string. " " . $elem[0];
            }   
        } 
        
        return $collect;
    }
}