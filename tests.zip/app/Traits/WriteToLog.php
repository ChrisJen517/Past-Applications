<?php

namespace App\Traits;

Trait WriteToLog
{

    public function writeToLog($input)
    {
        // $file = '/home/rnngroup/public_html/verifications.rnngroup.com/FromRNN/ImportLog.txt';
        //$file = 'C:/Users/Brandon/Desktop/RandomTestLog.txt';
        // $file = 'C:/Users/dhudson/Documents/PowerleadTestLog.txt';
        // $file = 'C:/Users/rsche/Documents/ReleaseByCOE.txt';
        $file = '/home/rocky/public_html/rocky-sync/Maintence/speedTest.txt';

        // $date = date('h-i-s');
        // $this->WriteToLog($date.' message');
        $input = "\r\n" . $input;
        file_put_contents($file,$input,FILE_APPEND);
    }
}
