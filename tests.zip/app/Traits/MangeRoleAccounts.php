<?php

namespace App\Traits;

use App\Models\Team;
use DB;
use App\Models\Directory_Agent;
use App\Models\Powerlead;
use App\Models\Agent;
use App\Models\Corporate_Admin;
use App\Models\Manager;
use App\Models\Powerlead_Directory_Manager;
use Config;

trait MangeRoleAccounts
{

    private $notAllowedIds = array(
        '1901', '1902', '1904', '3333', '9999'
    );
    
    //adds accounts types to the user or reactivates them 
    public function AddRoleAccounts($user, $corporation_id, $team_id = null, $agent_id = null, $directory_id = null, $power_id = null){
        if($corporation_id == null){
            $corporation_id = 2;
        }

        if($team_id == null || !(Team::where('team_id', $team_id)->where('is_deactivated', 0)->exists())){
            $team_id = Team::where('corporation_id', $corporation_id)->where('is_deactivated', 0)->first()->team_id ?? null;
        }

        $roleList = explode(',', $user->role_list);
        if(in_array("corporate_admin", $roleList)){
            if(!Corporate_Admin::where('user_id', $user->user_id)->exists()){
                $corpAdmin = new Corporate_Admin();
                $corpAdmin->corporation_id = $corporation_id;
                $corpAdmin->user_id = $user->user_id;
                $corpAdmin->save();
            }
            else{
                $corpAdmin = Corporate_Admin::select('active', 'corporate_admin_id')->where('user_id', $user->user_id)->first();
                $corpAdmin->active = 1;
                $corpAdmin->save();
            }
        }
        if(in_array("manager", $roleList)){
            if(!Manager::where('user_id', $user->user_id)->exists()){
                $manager = new Manager();
                $manager->corporation_id = $corporation_id;
                $manager->team_id = $team_id;
                $manager->user_id = $user->user_id;
                $manager->save();
            }
            else{
                $manager = Manager::select('active', 'manager_id')->where('user_id', $user->user_id)->first();
                $manager->active = 1;
                $manager->save();
            }
        }
        if(in_array("powerlead_directory_manager", $roleList)){
            if(!Powerlead_Directory_Manager::where('user_id', $user->user_id)->exists()){
                $PowDirManager = new Powerlead_Directory_Manager();
                $PowDirManager->user_id = $user->user_id;
                $PowDirManager->save();
            }
            else{
                $PowDirManager = Powerlead_Directory_Manager::select('active' , 'powerlead_directory_id')->where('user_id', $user->user_id)->first();
                $PowDirManager->active = 1;
                $PowDirManager->save();
            }
        }
        if(in_array("agent", $roleList)){
            if(!Agent::where('user_id', $user->user_id)->exists()){
                $agent = new Agent();
                $agent->corporation_id = $corporation_id;
                $agent->team_id = $team_id;
                if(!empty($agent_id))
                    $agent->agent_id = $agent_id;
                $agent->user_id = $user->user_id;
                $agent->save();
                if(in_array($agent->agent_id, $this->notAllowedIds)) {
                    if($agent->agent_id <= 1904)
                        $agent->agent_id = 1905;
                    else
                        $agent->agent_id += 1;
                }
            }
            else{
                $agent = Agent::select('active', 'agent_id')->where('user_id', $user->user_id)->first();
                $agent->active = 1;
                $agent->save();
            }
        }
        if(in_array("directory_agent", $roleList)){
            if(!Directory_Agent::where('user_id', $user->user_id)->exists()){
                $dirAgent = new Directory_Agent();
                if(!empty($directory_id))
                    $dirAgent->directory_agent_id = $directory_id;
                $dirAgent->user_id = $user->user_id;
                $dirAgent->save();
            }
            else{
                $dirAgent = Directory_Agent::select('active', 'directory_agent_id')->where('user_id', $user->user_id)->first();
                $dirAgent->active = 1;
                $dirAgent->save();
            }
        }
        if(in_array("powerlead", $roleList)){
            if(!Powerlead::where('user_id', $user->user_id)->exists()){
                $powAgent = new Powerlead();
                if(!empty($power_id))
                    $powAgent->id = $power_id;
                $powAgent->user_id = $user->user_id;
                $powAgent->save();
            }
            else{
                $powAgent = Powerlead::select('active', 'id')->where('user_id', $user->user_id)->first();
                $powAgent->active = 1;
                $powAgent->save();
            }
        }
    }

    //deactivates the accounts or blocks in the given list 
    public function deactivateRoles($user, $roleList){
        if(in_array("corporate_admin", $roleList)){
            if(Corporate_Admin::where('user_id', $user->user_id)->exists()){
                $corpAdmin = Corporate_Admin::select('active', 'corporate_admin_id')->where('user_id', $user->user_id)->first();
                $corpAdmin->active = 0;
                $corpAdmin->save();
            }
        }
        if(in_array("manager", $roleList)){
            if(Manager::where('user_id', $user->user_id)->exists()){
                $manager = Manager::select('active', 'manager_id')->where('user_id', $user->user_id)->first();
                $manager->active = 0;
                $manager->save();
            }
        }
        if(in_array("powerlead_directory_manager", $roleList)){
            if(Powerlead_Directory_Manager::where('user_id', $user->user_id)->exists()){
                $PowDirManager = Powerlead_Directory_Manager::select('active' , 'powerlead_directory_id')->where('user_id', $user->user_id)->first();
                $PowDirManager->active = 0;
                $PowDirManager->save();
            }
        }
        if(in_array("agent", $roleList)){
            if(Agent::where('user_id', $user->user_id)->exists()){
                $agent = Agent::select('active', 'agent_id')->where('user_id', $user->user_id)->first();
                $agent->active = 0;
                $agent->save();
                DB::select(DB::raw('UPDATE `active_accounts` SET `ACCT_AGENT` = NULL WHERE `ACCT_AGENT` = '.$agent->agent_id.';'));
            }
        }
        if(in_array("directory_agent", $roleList)){
            if(Directory_Agent::where('user_id', $user->user_id)->exists()){
                $dirAgent = Directory_Agent::select('active', 'directory_agent_id')->where('user_id', $user->user_id)->first();
                $dirAgent->active = 0;
                $dirAgent->save();
                $this->removeAccounts($dirAgent->directory_agent_id);
            }
        }
        if(in_array("powerlead", $roleList)){
            if(Powerlead::where('user_id', $user->user_id)->exists()){
                $powAgent = Powerlead::select('active', 'id')->where('user_id', $user->user_id)->first();
                $powAgent->active = 0;
                $powAgent->save();

                DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_CAPCODE` = 2, `POWERLEAD_AGENT_ID` = NULL WHERE `POWERLEAD_CAPCODE` = 3 AND `POWERLEAD_AGENT_ID` = '.$powAgent->id.';'));
                DB::select(DB::raw('UPDATE `powerlead_accounts` SET `powerlead_agent_id` = NULL WHERE `verified` is null AND `powerlead_agent_id` = '.$powAgent->id.';'));
            }
        }
    }
}