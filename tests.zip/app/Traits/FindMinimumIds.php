<?php

namespace App\Traits;


use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Directory_Setting;
use App\Models\Team;
use DB;

trait FindMinimumIds
{
    // public function FindMinimumIdsForATeam($corporation_id){
    //     $teams = Team::select('team_id', '')->where('is_deactivated', 0)
    //     ->when($corporation_id != "all", function ($q) use ($corporation_id) {
    //         $q->where('corporation_id', $corporation_id);
    //     })->get();

    //     foreach($teams as $team){
            // $firstAvaliable = DB::SELECT(DB::RAW("SELECT MIN(t1.agent_id + 1) AS nextAgentID
            // FROM agents t1
            //    LEFT JOIN powerlead_agent t2
            //        ON t1.id + 1 = t2.id
            //     left join agents t3
            //         on t1.id + 1 = t3.agent_id
            //     left join managers t4
            //         on t1.id + 1 = t4.manager_id
            //     left join corporate_admins t5
            //         on t1.id + 1 = t5.corporate_admin_id
            //     left join directory_agent t6
            //         on t1.id + 1 = t6.directory_agent_id
            // WHERE t2.id IS NULL
            // AND t3.agent_id IS NULL
            // AND t4.manager_id IS NULL
            // AND t5.corporate_admin_id IS NULL
            // AND t6.directory_agent_id IS NULL
            // AND t1.id >= 800;"));
    //     }
    // }

    public function getMinimumPowerleadDirectoryID(){

        $firstAvaliablePower = DB::SELECT(DB::RAW("SELECT MIN(t1.id + 1) AS nextAgentID
            FROM powerlead_agent t1
            LEFT JOIN powerlead_agent t2
                ON t1.id + 1 = t2.id
                left join agents t3
                    on t1.id + 1 = t3.agent_id
                left join managers t4
                    on t1.id + 1 = t4.manager_id
                left join corporate_admins t5
                    on t1.id + 1 = t5.corporate_admin_id
                left join directory_agent t6
                    on t1.id + 1 = t6.directory_agent_id
            WHERE t2.id IS NULL
            AND t3.agent_id IS NULL
            AND t4.manager_id IS NULL
            AND t5.corporate_admin_id IS NULL
            AND t6.directory_agent_id IS NULL
            AND t1.id >= 799;"));

        if($firstAvaliablePower[0]->nextAgentID == null)
            $nextIds[] = 800;
        else
            $nextIds[] = $firstAvaliablePower[0]->nextAgentID;
        
        $firstAvaliableDirectory = DB::SELECT(DB::RAW("SELECT MIN(t1.directory_agent_id + 1) AS nextAgentID
            FROM directory_agent t1
               LEFT JOIN powerlead_agent t2
                   ON t1.directory_agent_id + 1 = t2.id
                left join agents t3
                    on t1.directory_agent_id + 1 = t3.agent_id
                left join managers t4
                    on t1.directory_agent_id + 1 = t4.manager_id
                left join corporate_admins t5
                    on t1.directory_agent_id + 1 = t5.corporate_admin_id
                left join directory_agent t6
                    on t1.directory_agent_id + 1 = t6.directory_agent_id
            WHERE t2.id IS NULL
            AND t3.agent_id IS NULL
            AND t4.manager_id IS NULL
            AND t5.corporate_admin_id IS NULL
            AND t6.directory_agent_id IS NULL
            AND t1.directory_agent_id >= 4799;"));

        if($firstAvaliableDirectory[0]->nextAgentID == null)
            $nextIds[] = 4800;
        else
            $nextIds[] = $firstAvaliableDirectory[0]->nextAgentID;

        return $nextIds;
    }
}