<?php

namespace App\Traits;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Models\Access_Levels;
use App\Models\Active_Account;
use App\Models\Inactive_Account;
use App\Models\Agent;

Trait HasAccess
{
    public function checkAccess($active_account_id)
    {
        $account = []; 
        if(!empty(Active_Account::find($active_account_id))){
            $account = Active_Account::find($active_account_id);
        }else{
            $account = Inactive_Account::find($active_account_id);
        }

        if($account == null)
            return false;

        if($account->ACCESS_RULES == null){
            return true;
        }

        $user_access = Auth::user()->has_access;
        $account_levels = explode (",", $account->ACCESS_RULES); //Input Active Account Shortcode into an Array
        $access_arr = collect(explode (",", $user_access)); // Array of Users allowed Access levels by ID      
        $companyAccessShortcodes = Access_Levels::where('corporation_id', $account->CORPORATION_ID)->get(); // All the shortcodes available
        
        return $this->checkAllAccessLevels($account_levels, $companyAccessShortcodes, $access_arr);
    }

    public function checkAgentAccess($active_account_id, $agent_id)
    {
        $account = []; 
        if(!empty(Active_Account::find($active_account_id))){
            $account = Active_Account::find($active_account_id);
        }else{
            $account = Inactive_Account::find($active_account_id);
        }

        if($account == null)
            return false;

        if($account->ACCESS_RULES == null){
            return true;
        }
        
        $user_access = Agent::find($agent_id)->user_link->has_access;
        $account_levels = explode (",", $account->ACCESS_RULES); //Input Active Account Shortcode into an Array
        $access_arr = collect(explode (",", $user_access)); // Array of Users allowed Access levels by ID      
        $companyAccessShortcodes = Access_Levels::where('corporation_id', $account->CORPORATION_ID)->get(); // All the shortcodes available
        
        return $this->checkAllAccessLevels($account_levels, $companyAccessShortcodes, $access_arr);
    }

    public function getAllAccessIds($ssn, $corporation_id, $type, $agent_id = null){
        $workableAccounts = [];
        if($type == "inactive"){
            $accounts = Inactive_Account::select('ACCESS_RULES','ID')
                ->where('CORPORATION_ID', $corporation_id)->where('ACCT_SSN', $ssn)->get();
        }else{
            $accounts = Active_Account::select('ACCESS_RULES','ID')
                ->where('CORPORATION_ID', $corporation_id)->where('ACCT_SSN', $ssn)->get();
        }

        //makes sure there is at least 1 account
        if(empty($accounts)){
            return $workableAccounts;
        }

        //if no agent is selected, uses the current user
        if($agent_id == null)
            $user_access = Auth::user()->has_access;
        else
            $user_access = Agent::find($agent_id)->user_link->has_access;

        $access_arr = collect(explode (",", $user_access)); // Array of Users allowed Access levels by ID 
        $companyAccessShortcodes = Access_Levels::where('corporation_id', $corporation_id)->get(); // All the shortcodes available 

        foreach($accounts as $account){
            if($account->ACCESS_RULES == null || $account->ACCESS_RULES == ''){
                $workableAccounts[] = $account->ID;
            }
            else{
                $account_levels = explode (",", $account->ACCESS_RULES);

                if($this->checkAllAccessLevels($account_levels, $companyAccessShortcodes, $access_arr)){
                    $workableAccounts[] = $account->ID;
                }
            }
        }

        return $workableAccounts;
    }

    //checks the list of access rules against the agents
    //the accounts access rules exploded by a comma, the company's access rules as an object, the user's rules exploded by a comma
    public function checkAllAccessLevels($account_levels, $companyAccessShortcodes, $access_arr){
        foreach($account_levels as $account_level)
        {
            $account_level = strtoupper($account_level);
            $current_code = $companyAccessShortcodes->where('shortcode', $account_level)->first();

            if(empty($current_code) == true)
                return false;
            if(!$access_arr->contains($current_code->id)){
                return false;
            }
        }
       return true;
    }
}