<?php

namespace App;

use Laravel\Passport\HasApiTokens;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Database\Eloquent\Model;

class User extends Authenticatable
{
    use HasApiTokens, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password',
    ];

    protected $primaryKey = 'user_id';
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public function passwordHistories()
    {
        return $this->hasMany('App\Models\old_passwords', 'user_id');
    }

    public function agent_link()
    {
        return $this->hasOne('App\Models\Agent', 'user_id');
    }
    
    public function powerlead_link()
    {
        return $this->hasOne('App\Models\Powerlead', 'user_id');
    }
    
    public function manager_link()
    {
        return $this->hasOne('App\Models\Manager', 'user_id');
    } 

    public function corporate_admin_link()
    {
        return $this->hasOne('App\Models\Corporate_Admin', 'user_id');
    }

    public function directory_agent_link()
    {
        return $this->hasOne('App\Models\Directory_Agent', 'user_id');
    }

    public function powerlead_directory_manager_link()
    {
        return $this->hasOne('App\Models\Powerlead_Directory_Manager', 'user_id');
    }
    
    public function corporation_agent_link()
    {
        return $this->hasOneThrough('App\Models\Corporation', 'App\Models\Agent', 'user_id', 'corporation_id', 'user_id', 'corporation_id');
    }

    public function corporation_manager_link()
    {
        return $this->hasOneThrough('App\Models\Corporation', 'App\Models\Manager', 'user_id', 'corporation_id', 'user_id', 'corporation_id');
    }

    public function corporation_corporate_admin_link()
    {
        return $this->hasOneThrough('App\Models\Corporation', 'App\Models\Corporate_Admin', 'user_id', 'corporation_id', 'user_id', 'corporation_id');
    }
    
    public function corporate_api_link()
    {
        return $this->hasOne('App\Models\Corporate_Api', 'user_id');
    }

    public function getRoleId(){
        switch ($this->role){
            case 'agent':
                return $this->agent_link->agent_id;
            break;
            case 'manager':
                return $this->manager_link->manager_id;
            break;
            case 'corporate_admin':
                return $this->corporate_admin_link->corporate_admin_id;
            break;
            case 'directory_agent':
                return $this->directory_agent_link->directory_agent_id;
            break;
            case 'powerlead':
                return $this->powerlead_link->id;
            break;
            case 'admin':
                return $this->user_id;
            break;
            case 'powerlead_directory_manager':
                return $this->powerlead_directory_manager_link->powerlead_directory_id;
            break;
        }
    }
}

