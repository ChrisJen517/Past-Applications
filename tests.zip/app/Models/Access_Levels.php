<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Access_Levels extends Model
{
    protected $table = 'access_levels';
}
