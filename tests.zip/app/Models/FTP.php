<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FTP extends Model
{
    protected $table="FTP";

    protected $primaryKey = 'FTP_id';
}