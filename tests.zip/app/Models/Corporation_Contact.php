<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Corporation_Contact extends Model
{
    protected $primaryKey = 'corporation_contact_id';

    protected $table="corporation_contacts";

    public function corporation_link()
    {
        return $this->belongsTo('App\Models\Corporation', 'corporation_id');
    }
}
