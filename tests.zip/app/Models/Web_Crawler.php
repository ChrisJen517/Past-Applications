<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class web_crawler extends Model
{
    protected $table = 'web_crawler';
}
