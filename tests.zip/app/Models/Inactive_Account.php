<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Inactive_Account extends Model
{
    protected $table = "inactive_accounts";

    protected $fillable = [
        'ADD_DATE', 'ACCT_AD1', 'corporation_id',
    ];
    
    protected $primaryKey = 'ID';

    public function inactive_capcode_link()
    {
        return $this->hasOne('App\Models\Capcode', 'id', 'CAPCODE');
    }

}