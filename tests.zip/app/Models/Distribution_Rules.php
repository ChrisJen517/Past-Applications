<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Distribution_Rules extends Model
{
    protected $table="distribution_rules";

    protected $primaryKey = 'distribution_rules_id';
}