<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Powerlead_Directory_Manager extends Model
{
    protected $table = 'powerlead_directory_managers';
    protected $primaryKey = 'powerlead_directory_id';

    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
}
