<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Powerlead_Accounts extends Model
{
    protected $table = 'powerlead_accounts';
}
