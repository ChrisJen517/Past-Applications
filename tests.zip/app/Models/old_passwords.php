<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class old_passwords extends Model
{
    //
    protected $table="old_passwords";

    protected $guarded = [];
    
    public function post()
    {
        return $this->belongsTo('App\User');
    }
}
