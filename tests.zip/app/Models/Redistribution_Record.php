<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Redistribution_Record extends Model
{
    protected $table = 'redistributions';

}
