<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Blocked_Company extends Model
{
    protected $table="blocked_companies";

    protected $primaryKey = 'blocked_company_id';

    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
}