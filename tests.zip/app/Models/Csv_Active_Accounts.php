<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Csv_Active_Accounts extends Model
{
    protected $table = "csv_active_accounts";

}
