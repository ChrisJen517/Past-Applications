<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Corporate_Admin extends Model
{
    protected $table = 'corporate_admins';

    protected $primaryKey = 'corporate_admin_id';

    public function corporation_link()
    {
        return $this->belongsTo('App\Models\Corporation', 'corporation_id');
    } 
    
    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
}
