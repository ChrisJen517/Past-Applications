<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Powerlead_Capcode extends Model
{
    protected $table = 'powerlead_capcode';
}
