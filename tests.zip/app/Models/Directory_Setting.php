<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Directory_Setting extends Model
{
    protected $table = 'directory_settings';

    protected $primaryKey = 'directory_setting_id';
}