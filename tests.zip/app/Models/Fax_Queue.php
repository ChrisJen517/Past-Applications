<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Agent;
use Auth;

class Fax_Queue extends Model
{
    protected $table= "fax_queue";
}