<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Directory_Work_History extends Model
{
    protected $table = 'directory_work_history';

    public function directory_capcode_link()
    {
        return $this->hasOne('App\Models\Directory_Capcode', 'capcode_id', 'capcode');
    }

    public function user_directory_agent_link()
    {
        return $this->hasOneThrough('App\User', 'App\Models\Directory_Agent', 'directory_agent_id', 'user_id', 'worker_id', 'user_id');
    }

    public function user_agent_link()
    {
        return $this->hasOneThrough('App\User', 'App\Models\Agent', 'agent_id', 'user_id', 'worker_id', 'user_id');
    }

    public function user_powerlead_directory_manager_link(){
        return $this->hasOneThrough('App\User', 'App\Models\Powerlead_Directory_Managers', 'powerlead_directory_id', 'user_id', 'worker_id', 'user_id');    
    }

    public function admin_link(){
        return $this->hasOne('App\Users', 'user_id', 'worker_id');
    }
}