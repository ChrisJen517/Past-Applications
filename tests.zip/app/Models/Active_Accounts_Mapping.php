<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Active_Accounts_Mapping extends Model
{
    //
    protected $primaryKey = 'ID';

    protected $table = 'active_accounts_mapping';
}
