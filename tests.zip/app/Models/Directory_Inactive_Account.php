<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Directory_Inactive_Account extends Model
{
    protected $table = 'directory_inactive_accounts';

    protected $primaryKey = 'directory_account_id';

    public function inactive_capcode_link()
    {
        return $this->hasOne('App\Models\Directory_Capcode', 'capcode_id', 'capcode');
    }
}