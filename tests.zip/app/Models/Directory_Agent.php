<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Directory_Agent extends Model
{
    protected $table = 'directory_agent';

    protected $primaryKey = 'directory_agent_id';

    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
}
