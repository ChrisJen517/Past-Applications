<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Agent;
use Auth;

class Manager extends Model
{
    protected $table="managers";

    protected $primaryKey = 'manager_id';

    public function getTeamAgents()
    {
        $agentsIds = Agent::select('user_id')->where('team_id', $this->team_id);

        return Auth::user()->whereIn('user_id', $agentsIds)->get();
    } 

    public function corporation_link()
    {
        return $this->belongsTo('App\Models\Corporation', 'corporation_id');
    }
    
    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
}