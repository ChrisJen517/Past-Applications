<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Team extends Model
{
    protected $table = "teams";

    protected $primaryKey = 'team_id';
    
    public function corporation_link()
    {
        return $this->belongsTo('App\Models\Corporation', 'corporation_id');
    }

    public function agent_link()
    {
        return $this->hasMany('App\Models\Agent', 'team_id');
    }
    
    public function manager_link()
    {
        return $this->hasMany('App\Models\Manager', 'team_id');
    }

    public function user_agent_link()
    {
        return $this->hasManyThrough('App\User', 'App\Models\Agent', 'team_id', 'user_id', 'team_id', 'user_id');
    }

    
    public function user_manager_link()
    {
        return $this->hasManyThrough('App\User', 'App\Models\Manager', 'team_id', 'user_id', 'team_id', 'user_id');
    }
}
