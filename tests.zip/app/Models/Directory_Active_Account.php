<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Directory_Active_Account extends Model
{
    protected $table = 'directory_active_accounts';

    protected $primaryKey = 'directory_account_id';

    public function active_capcode_link()
    {
        return $this->hasOne('App\Models\Directory_Capcode', 'capcode_id', 'capcode');
    }
}