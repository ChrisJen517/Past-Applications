<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Agent;
use Auth;

class Message extends Model
{
    protected $table="messages";

    protected $primaryKey = 'message_id';
}