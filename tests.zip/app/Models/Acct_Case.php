<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Acct_Case extends Model
{
    //
    protected $table = 'TEST_acct_case';

}
