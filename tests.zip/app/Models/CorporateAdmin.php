<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CorporateAdmin extends Model
{
    //
    protected $table="corporate_admins";

    protected $primaryKey = 'corporate_admin_id';
}