<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\Agent;
use Auth;

class Legal_Document extends Model
{
    protected $table= "legal_documents";

    protected $primaryKey = 'document_id';
}