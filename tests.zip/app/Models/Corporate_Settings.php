<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Corporate_Settings extends Model
{
    //
    protected $table = 'corporate_settings';

}
