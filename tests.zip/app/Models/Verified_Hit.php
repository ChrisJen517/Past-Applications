<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Verified_Hit extends Model
{
    protected $table = 'verified_hits';
}
