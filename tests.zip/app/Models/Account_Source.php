<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Account_Source extends Model
{
    protected $table = 'account_sources';

    protected $primaryKey = 'account_source_id';
}
