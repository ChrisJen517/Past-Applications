<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Directory_Capcode extends Model
{
    protected $table = "directory_capcodes";

    protected $primaryKey = "capcode_id";
}
