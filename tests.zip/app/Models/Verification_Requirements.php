<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Verification_Requirements extends Model
{
    protected $table = 'verification_requirements';
}