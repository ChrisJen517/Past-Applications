<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Team_Distribution_Rules extends Model
{
    //
    protected $table="team_distribution_rules";
}
