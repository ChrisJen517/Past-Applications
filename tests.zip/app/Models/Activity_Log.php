<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Activity_Log extends Model
{
    protected $primaryKey = 'activity_log_id';

    protected $table = 'activity_logs';

    public function user_activity_link()
    {
        return $this->hasOne('App\User', 'user_id', 'user_id');
    }

}
