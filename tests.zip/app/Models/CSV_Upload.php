<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class CSV_Upload extends Model
{
    protected $table = "csv_uploads";

}