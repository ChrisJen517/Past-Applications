<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Powerlead_Settings extends Model
{
    protected $table = 'powerlead_settings';

}
