<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Powerlead extends Model
{
    protected $table = 'powerlead_agent';

    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
}
