<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Corporate_Api extends Model
{
    protected $table = 'corporate_api';

    protected $primaryKey = 'corporate_api_id';
}
