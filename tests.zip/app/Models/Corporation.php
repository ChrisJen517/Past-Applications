<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Corporation extends Model
{
    //
    protected $primaryKey = 'corporation_id';

    protected $table="corporations";
   
    public function corporationContacts()
    {
        return $this->hasMany('App\Models\Corporation_Contact', 'corporation_id');
    } 
    
    public function corporationAgents()
    {
        return $this->hasMany('App\Models\Agent', 'corporation_id');
    }

    public function corporationManager()
    {
        return $this->hasMany('App\Models\Manager', 'corporation_id');
    }

    public function team_link()
    {
        return $this->hasMany('App\Models\Team', 'corporation_id');
    }

    public function user_agent_link()
    {
        return $this->hasManyThrough('App\User', 'App\Models\Agent', 'corporation_id', 'user_id', 'corporation_id', 'user_id');
    }
    
    public function user_manager_link()
    {
        return $this->hasManyThrough('App\User', 'App\Models\Manager', 'corporation_id', 'user_id', 'corporation_id', 'user_id');
    }

    public function user_corporate_admin_link()
    {
        return $this->hasManyThrough('App\User', 'App\Models\Corporate_Admin', 'corporation_id', 'user_id', 'corporation_id', 'user_id');
    }

}
