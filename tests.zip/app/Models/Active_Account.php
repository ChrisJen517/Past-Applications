<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Active_Account extends Model
{
    protected $table = "active_accounts";

    protected $fillable = [
        'ADD_DATE', 'ACCT_AD1', 'corporation_id',
    ];
    
    protected $primaryKey = 'ID';

    public function active_capcode_link()
    {
        return $this->hasOne('App\Models\Capcode', 'id', 'CAPCODE');
    }
}
