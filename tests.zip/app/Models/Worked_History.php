<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Worked_History extends Model
{
    //
    protected $primaryKey = 'worked_history_id';

    protected $table = 'worked_history';

    public function capcode_link()
    {
        return $this->hasOne('App\Models\Capcode', 'id', 'capcode');
    }
}
