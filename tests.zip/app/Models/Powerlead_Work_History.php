<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Powerlead_Work_History extends Model
{
    protected $table = 'powerlead_work_history';
}
