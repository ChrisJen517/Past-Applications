<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Message_Thread extends Model
{
    protected $table="message_threads";

    protected $primaryKey = 'thread_id';

    public $timestamps = false;
}