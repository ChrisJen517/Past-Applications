<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AWG7_Phone_Numbers extends Model
{
    protected $table="AWG7_phone_numbers";

    protected $primaryKey = 'id';
}