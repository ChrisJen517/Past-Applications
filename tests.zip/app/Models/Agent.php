<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Agent extends Model
{
    //
    protected $table="agents";

    protected $primaryKey = 'agent_id';

    public function corporation_link()
    {
        return $this->belongsTo('App\Models\Corporation', 'corporation_id');
    }

    public function user_link()
    {
        return $this->belongsTo('App\User', 'user_id');
    }
    
    public function team_link()
    {
        return $this->belongsTo('App\Models\Team', 'team_id');
    }    

    public function active_accounts_link()
    {
        return $this->hasMany('App\Models\Active_Account', 'ACCT_AGENT');
    }
}