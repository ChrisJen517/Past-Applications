<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Previous_Export extends Model
{
    protected $table = 'previous_exports';
}
