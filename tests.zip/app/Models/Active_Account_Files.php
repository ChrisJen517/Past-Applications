<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Active_Account_Files extends Model
{
    //
    protected $table = 'active_account_files';

}
