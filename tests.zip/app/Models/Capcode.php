<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Capcode extends Model
{
    protected $table = "capcodes";
}
