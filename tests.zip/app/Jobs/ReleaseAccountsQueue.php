<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Team;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Distribution_Rules;
use App\Models\Queue_Log;

class ReleaseAccountsQueue implements ShouldQueue
{
    public $tries = 3;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corporation_id;
    protected $recallOption;
    protected $case_num;
    protected $tier_value;
    protected $score;
    protected $team_id;

    public function __construct($corporation_id, $recallOption, $case_num, $tier_value, $score, $team_id)
    {
        $this->corporation_id = $corporation_id;
        $this->recallOption = $recallOption;
        $this->case_num = $case_num;
        $this->tier_value = $tier_value;
        $this->score = $score;
        $this->team_id = $team_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {     
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
        
        $queue_log = new Queue_Log();
        $queue_name = 'ReleaseAccountsQueue';
        $time_start = date('h:i:s');

        $corporation_id = $this->corporation_id;
        $score = $this->score;
        $case_num = $this->case_num;
        $tier_value = $this->tier_value;
        $recallOption = $this->recallOption;
        $team_id = $this->team_id;
        if($recallOption == 'case')
        {
            $tier_value = null;
        }
        else
        {
            $case_num = null;
        }
        $distribution_rules = Distribution_Rules::Select('priority','second_priority','third_priority')->where('corporation_id', $corporation_id)->first();
        $account_sources = Account_Source::Select('shortcode')->where('corporation_id', $corporation_id)->orderBy('priority')->get();
        $account_source_order = '';

        foreach($account_sources as $account_source){
            $account_source_order = '"'.$account_source->shortcode.'",'.$account_source_order;
        }
        $account_source_order =substr_replace($account_source_order ,"", -1);
        
        $first = $distribution_rules->priority;
        $second = $distribution_rules->second_priority;
        $third = $distribution_rules->third_priority; 
        
        if($first == 'ACCT_SOURCE'){
            if($account_source_order == '')
                $first = null;
            else
             $first = "FIELD(ACCT_SOURCE, ".$account_source_order.") DESC";
        }
        elseif($second == 'ACCT_SOURCE'){
            if($account_source_order == '')
                $second = null;
            else
                $second = "FIELD(ACCT_SOURCE, ".$account_source_order.") DESC";
        }
        elseif($third == 'ACCT_SOURCE'){
            if($account_source_order == '')
                $third = null;
            else
                $third = "FIELD(ACCT_SOURCE, ".$account_source_order.") DESC";
        }
        
        $active_accounts = Active_Account::select('ID')
        ->where('ON_HOLD', 1)->where('CORPORATION_ID', $corporation_id)
        ->when($tier_value, function($query, $tier_value){
            return $query->where('TIER', '>=', $tier_value);
        })
        ->when($case_num, function($query, $case_num){
            return $query->where('ACCT_CASE', $case_num);
        })
        ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
        ->when($first, function ($query, $first) {
            return $query->orderByRaw($first);
        })
        ->when($second, function ($query, $second) {
            return $query->orderByRaw($second);
        })
        ->when($third, function ($query, $third) {
            return $query->orderByRaw($third);
        })
        ->limit(50001)->get();
        $countOfActiveAccounts = count($active_accounts);
        $loop = false;
        if($active_accounts->isEmpty() == true)    
        {
            $message = "ReleaseAccountsQueue ran no Accounts Found";
            $time_finished = date('h:i:s');
            $queue_log->queue_name = $queue_name;
            $queue_log->message = $message;
            $queue_log->time_start = $time_start;
            $queue_log->time_finished = $time_finished;
            $queue_log->save();
            return "done";
        }
        elseif($countOfActiveAccounts > 50000){
            unset($active_accounts[50000]);
            $loop = true;
        }
    
        if($team_id == 'All'){
            
            $teams = Team::select('team_id', 'name')->where('corporation_id', $corporation_id)->get();

            $max_count_team = count($teams);
            $count_team = 0;
            $teamUpdate = [];
            $count_start = 0;
            foreach($active_accounts as $active_account){
                if($count_start == 0){
                    $teamUpdate[$count_team] = '"'.$active_account->ID.'",';
                    $count_team++;
                    if($count_team >= $max_count_team){
                        $count_start = 1;
                    }
                }
                else{
                    $teamUpdate[$count_team] = $teamUpdate[$count_team].'"'.$active_account->ID.'",';
                    $count_team++;
                }

                if($count_team >= $max_count_team){
                    $count_team = 0;
                }
            }
            $count_team = 0;
                
            foreach($teams as $team){               
                $teamUpdate[$count_team] =substr_replace($teamUpdate[$count_team] ,"", -1);
                DB::select( DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = '.$team->team_id.', `TEAM_NAME` = "'.$team->name.'", `ON_HOLD` = 0 WHERE `ID` IN ('.$teamUpdate[$count_team].');'));
                $count_team++;
            }
        }
        else{
            $id_string = '';
            $id_count = 0;
            foreach($active_accounts as $data){
                if($id_count == 0){
                    $id_string = '"'.$data->ID.'",'; 
                    $id_count++;
                }
                else{
                    $id_string = $id_string.' "'.$data->ID.'",';
                }
            }
            $id_string = substr_replace($id_string ,'', -1);
            DB::select(DB::raw("UPDATE active_accounts SET TEAM_ID = $team_id, ON_HOLD = 0 WHERE ID IN('$id_string');"));
        }
        //recursion
        if($loop)
            dispatch(new ReleaseAccountsQueue($corporation_id, $recallOption, $case_num, $tier_value, $score, $team_id));
        
        $message = "ReleaseAccountsQueue ran ".$countOfActiveAccounts." records";
        $time_finished = date('h:i:s');
        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }
}