<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use DB;
use PDO;
use Config;
use App\Models\Queue_Log;
use App\RNNMailer;
use App\User;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Input;
use PHPMailer\PHPMailer\PHPMailer;
use Storage;
use Illuminate\Support\Facades\Log;
use File;

class AccountUploadAccountQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    public function __construct()
    {

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $queue_log = new Queue_Log();
        $time_start = date('h:i:s');
        $queue_name = 'AccountUploadAccountQueue';
        $users = User::where('csv_upload', 1)->limit(10)->get();
        // return $users;
        foreach($users as $user){
            $token = rand(100000000000, 999999999999);
            $user->password = bcrypt($token);
            $user->csv_upload = 0;
            $user->save();

            $env = Config::get('app.env');
            if ($env == 'prod'){
                File::makeDirectory('/home/rocky/public_html/ProfilePictures/'.$user->user_id);
                $file = File::get('/home/rocky/public_html/ProfilePictures/baseAvatar.png');
                File::put('/home/rocky/public_html/ProfilePictures/'.$user->user_id.'/avatar.png', $file);
                Log::debug("User ".$user->user_id." created from job");
            } else { 
                Storage::disk('profile_pictures')->makeDirectory($user->user_id);
                $file = File::get(public_path('ProfilePictures/baseAvatar.png'));
                File::put(public_path('ProfilePictures/' . $user->user_id . '/avatar.png'), $file);
            }

            $mail = new RNNMailer(true);

            //Recipients
            $mail->addAddress($user->email);

            // Content<p>{{  }}</p>
            $date = date("M,d,Y h:i:s A");
            $mail->Subject = "Account Login for RockySkipTracing";
            $mail->Body = "Your Account Name is $user->email, and your temporary password is $token, please login with the link https://www.rockyskiptracing.com and change your password under 'Manage Account.'";

            // Mail Send
            $mail->send();
            $mail = null;
        }

        $user_check = User::where('csv_upload', 1)->limit(1)->get();
        if(count($user_check) > 0){
            $this->dispatch(new AccountUploadAccountQueue());
        }

        $message = "AccountUploadAccountQueue ran 3 records";
        $time_finished = date('h:i:s');
        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }
}