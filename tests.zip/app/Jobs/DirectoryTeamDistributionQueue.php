<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Setting;
use DB;
use App\Traits\WriteToLog;
use App\Models\Queue_Log;

class DirectoryTeamDistributionQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct($corp_Id)
    {
        $this->corp_Id = $corp_Id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $corporation_id = $this->corp_Id;
        $this->distribute();
        //starts the recurion
        $loop = $this->linkAccounts($corporation_id);

        //if told to loop, loops
        if($loop == 'loop')
            dispatch(new DirectoryTeamDistributionQueue($corporation_id));

        return;
    }

    function linkAccounts($corporation_id){
        $accounts = Active_Account::where('CORPORATION_ID', $corporation_id)->where('EMPL_NAME', '!=', null)->where('EMPL_NAME', '!=', "")
        ->where('DIRECTORY_FLAG', 1)->select('EMPL_NAME', 'ID', 'DIRECTORY_LINK', 'DIRECTORY_FLAG')->limit(201)->get();

        //checks if there is more than 200, if so sets it to loop after it finishes
        $loop = false;
        if(count($accounts) > 200){
            unset($accounts[200]);
            $loop = true;
        }

        //if there are no more accounts ends the code
        if($accounts->first() == null)
            return;

        //gets the accounts into an array based on their names and a list of ids
        $accountNames = [];
        $links = [];
        $update = "";
        foreach($accounts as $account){
            if(array_key_exists($account->EMPL_NAME, $accountNames)){
                $accountNames[$account->EMPL_NAME]['account'] = $accountNames[$account->EMPL_NAME]['account'].', '.$account->ID;
            }
            else{
                $accountNames[$account->EMPL_NAME] = [
                    'name' => $account->EMPL_NAME,
                    'account' => ''.$account->ID.'',
                ];
            }

            $update = $account->ID.", ".$update;
        }

        
        //checks the active names
        $directoryAccounts = Directory_Active_Account::whereIn('employer_name', array_keys($accountNames))->select('employer_name')->get();
        foreach($directoryAccounts as $directoryAccount){
            if(array_key_exists($directoryAccount->employer_name, $accountNames)){
                unset($accountNames[$directoryAccount->employer_name]);
            }
        }

        //checks the inactive names
        $directoryAccounts = Directory_Inactive_Account::whereIn('employer_name', array_keys($accountNames))->select('employer_name', 'directory_account_id')->get();
        foreach($directoryAccounts as $directoryAccount){
            if(array_key_exists($directoryAccount->employer_name, $accountNames)){
                $links[$directoryAccount->employer_name] = [
                    'id' => $directoryAccount->directory_account_id,
                    'accounts' => $accountNames[$directoryAccount->employer_name]['account'],
                ];

                unset($accountNames[$directoryAccount->employer_name]);
            }
        }

        //checks the akas of the active
        $directoryAccounts = Directory_Active_Account::where(function ($query) use ($accountNames) {
            foreach($accountNames as $name){
                $query->orWhere('aka', 'like', '%'.$name['name'].'%');
            }
        })->select('aka')->get();
        foreach($directoryAccounts as $directoryAccount){
            $aliases = explode('|', $directoryAccount->aka);
            foreach($aliases as $name){
                if(array_key_exists($name, $accountNames))
                    unset($accountNames[$name]);
            }
        }


        //checks the aka's of the inactive
        $directoryAccounts = Directory_Inactive_Account::where(function ($query) use ($accountNames) {
            foreach($accountNames as $name){
                $query->orWhere('aka', 'like', '%'.$name['name'].'%');
            }
        })->select('aka', 'directory_account_id')->get();
        foreach($directoryAccounts as $directoryAccount){
            $aliases = explode('|', $directoryAccount->aka);
            foreach($aliases as $name){
                if(array_key_exists($name, $accountNames)){
                    $links[$name] = [
                        'id' => $directoryAccount->directory_account_id,
                        'accounts' => $accountNames[$name]['account'],
                    ];
                    unset($accountNames[$name]);
                }
            }
        }

        //sets the flag to zero so they aren't called again
        $update = substr_replace($update, "", -2);
        DB::select(DB::raw('UPDATE `active_accounts` SET `DIRECTORY_FLAG` = 0 WHERE `ID` IN ('.$update.');'));
        
        //fixes the directory link
        foreach($links as $link){
            DB::select(DB::raw('UPDATE `active_accounts` SET `DIRECTORY_LINK` = '.$link['id'].' WHERE `ID` IN ('.$link['accounts'].');'));
        }

        //creates the accounts
        foreach($accountNames as $name){
            $newDirectory = new Directory_Active_Account();
            $newDirectory->employer_name = $name['name'];
            $newDirectory->save();
        }

        if($loop)
            return 'loop';
        else
            return 'end';
    }

    
}