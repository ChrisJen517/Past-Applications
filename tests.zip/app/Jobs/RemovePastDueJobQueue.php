<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use DB;
use App\Models\Queue_Log;
use App\Models\Capcode;
use App\Jobs\UnblockAutoFaxEmailQueue;

class RemovePastDueJobQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct($corp_Id)
    {
        $this->corp_Id = $corp_Id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $this->removePastDueAccounts($this->corp_Id);
    }

    public function removePastDueAccounts($id)
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000);
        
        //gets the pass due capcode id
        $neededCapcodes = Capcode::select('capcode', 'id')->where('corporation_id', $id)->whereIn('capcode', [5514, 2335])->get();
        $pastDue = $neededCapcodes->where('capcode', 5514)->first()->id ?? 0;
        $overWorked = $neededCapcodes->where('capcode', 2335)->first()->id ?? 0;
        if($pastDue == 0){
            return;
        }

        //updates the capcode to the past due
        DB::Select(DB::RAW("UPDATE `active_accounts` SET CAPCODE = $pastDue where CORPORATION_ID = $id  AND DATE(ACCT_DUE_DATE) < curdate();"));

        //updates the capcode to the past due for overworked accounts
        if($overWorked != 0)
            DB::Select(DB::RAW("UPDATE `inactive_accounts` SET CAPCODE = $pastDue where CORPORATION_ID = $id AND DATE(ACCT_DUE_DATE) < curdate() AND CAPCODE = $overWorked;"));

        DB::Select(DB::raw("INSERT INTO inactive_accounts 
            SELECT * from `active_accounts` where CORPORATION_ID =  $id AND CAPCODE = $pastDue;"));

        DB::select(DB::raw("DELETE FROM active_accounts WHERE CAPCODE = $pastDue AND CORPORATION_ID = $id;"));
    }
}