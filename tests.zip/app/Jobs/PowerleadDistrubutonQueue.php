<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Settings;
use App\Models\Queue_Log;

class PowerleadDistrubutonQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct($corp_Id)
    {
        $this->corp_Id = $corp_Id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    { 
        $queue_log = new Queue_Log();
        $queue_name = 'PowerleadDistrubutonQueue';
        $time_start = date('h:i:s');

        $corporation_id = $this->corp_Id;
        $powerlead_settings = Powerlead_Settings::first();
        $powerlead_agents = Powerlead::with('user_link')->where('active', 1)->get();
        $accounts_to_assign = 0;
        $powerlead_agents_info = [];
        $agent_count = 0;   
        $allAccounts = Active_Account::where('POWERLEAD_CAPCODE', 3)->get();
 
        foreach($powerlead_agents as $powerlead_agent)
        {
            if($powerlead_agent->user_link->active == 1){           
                $agent_count++;
                
            $queued_accounts = $allAccounts->where('POWERLEAD_AGENT_ID', $powerlead_agent->id);
            $accounts_to_assign_per_agent = $powerlead_settings->max_accounts - count($queued_accounts);
            $powerlead_agents_info[] = array(
                "AGENT_ID" => $powerlead_agent->id,
                "NUMBER_OF_ACCOUNTS" => count($queued_accounts),
                "AA_IDS" => ''
            );
            $accounts_to_assign = $accounts_to_assign + $accounts_to_assign_per_agent;
            if($accounts_to_assign < 0){
                $accounts_to_assign = 0;
            }
        }

        }

        //limits the number of accounts needed or if none ends recursion
        $loop = false;
        if($accounts_to_assign == 0){
            $message = "PowerleadDistrubutonQueue All Queues were filled";
            $time_finished = date('h:i:s');
            $queue_log->queue_name = $queue_name;
            $queue_log->message = $message;
            $queue_log->time_start = $time_start;
            $queue_log->time_finished = $time_finished;
            $queue_log->save();
            return;
        }
        elseif($accounts_to_assign > 50000){
            $accounts_to_assign = 50000;
            $loop = true;
        }

        $first = $powerlead_settings->priority;
        $second = $powerlead_settings->second_priority;
       
        $active_accounts = Active_Account::where('POWERLEAD_FLAG', 1)->whereNull('POWERLEAD_CAPCODE')
        ->where('POESCORE','>', $powerlead_settings->hold_accounts_below_score)
        ->when($first, function ($query, $first) {
            return $query->orderByRaw($first);
        })
        ->when($second, function ($query, $second) {
            return $query->orderByRaw($second);
        })->limit($accounts_to_assign)->get();

        $countOfActiveAccounts = count($active_accounts);
        //if there is no accounts left ends recursion
        if($countOfActiveAccounts == 0){

            $message = "PowerleadDistrubutonQueue no accounts found";
            $time_finished = date('h:i:s');
            $queue_log->queue_name = $queue_name;
            $queue_log->message = $message;
            $queue_log->time_start = $time_start;
            $queue_log->time_finished = $time_finished;
            $queue_log->save();
            return;

        }

        // Mass Update
        $numberOfAgents = $agent_count;
        $agentNumber = 0;
        $checkedAll = 0;

        foreach($active_accounts as $active_account){
            startTeam:
            if ($powerlead_agents_info[$agentNumber]["NUMBER_OF_ACCOUNTS"] >= $powerlead_settings->max_accounts) {
                $checkedAll++;
                if ($checkedAll == $numberOfAgents) {
                    break;
                }

                $agentNumber++;
                if ($agentNumber == $numberOfAgents) {
                    $agentNumber = 0;
                }

                goto startTeam;
            } else {
                $checkedAll = 0;
            }

            $powerlead_agents_info[$agentNumber]["AA_IDS"] = $powerlead_agents_info[$agentNumber]["AA_IDS"].'"' . $active_account->ID . '",';
            $powerlead_agents_info[$agentNumber]["NUMBER_OF_ACCOUNTS"]++;
            
            $agentNumber++;
            if ($agentNumber == $numberOfAgents) {
                $agentNumber = 0;
            }
        }

        //updates the database
        foreach($powerlead_agents_info as $powerlead_agent) {
            if ($powerlead_agent["AA_IDS"] != "") {
                $powerlead_agent["AA_IDS"] = substr_replace($powerlead_agent["AA_IDS"], "", -1);
                DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_AGENT_ID` = '.$powerlead_agent["AGENT_ID"].', POWERLEAD_CAPCODE = 3 WHERE `ID` IN ('.$powerlead_agent["AA_IDS"].');'));
            }
        }

        // Loop Active_accounts to assign powerlead account id
        foreach($active_accounts as $active_account){
            $active_account_input = Active_Account::find($active_account->ID);
            if($active_account_input->POWERLEAD_ID != null){
                $powerlead_account = Powerlead_Accounts::find($active_account_input->POWERLEAD_ID);
            }else{
                $powerlead_account = new Powerlead_Accounts;    
            }
            $powerlead_account->powerlead_agent_id = $active_account_input->POWERLEAD_AGENT_ID;
            $powerlead_account->active_account_id  = $active_account_input->ID;
            $powerlead_account->save();
            
            $active_account_input->POWERLEAD_ID = $powerlead_account->id;
            $active_account_input->save();
        }

        $active_accounts = Active_Account::where('POWERLEAD_FLAG', 1)->whereNull('POWERLEAD_CAPCODE')
        ->where('POESCORE','>', $powerlead_settings->hold_accounts_below_score)->get();

        $unassigned_ids = '';
        foreach($active_accounts as $active_account){
            $unassigned_ids = $unassigned_ids.'"' . $active_account->ID . '",';
        }

        if ($unassigned_ids != "") {
            $unassigned_ids = substr_replace($unassigned_ids, "", -1);
            DB::select(DB::raw('UPDATE `active_accounts` SET POWERLEAD_CAPCODE = 2 WHERE `ID` IN ('.$unassigned_ids.');'));
        }

        $active_accounts = Active_Account::where('POWERLEAD_FLAG', 1)->whereNull('POWERLEAD_CAPCODE')
        ->where('POESCORE','<=', $powerlead_settings->hold_accounts_below_score)->get();
        
        $on_hold_ids = '';
        foreach($active_accounts as $active_account){
            $on_hold_ids = $on_hold_ids.'"' . $active_account->ID . '",';
        }

        if ($on_hold_ids != "") {
            $on_hold_ids = substr_replace($on_hold_ids, "", -1);
            DB::select(DB::raw('UPDATE `active_accounts` SET POWERLEAD_CAPCODE = 1 WHERE `ID` IN ('.$on_hold_ids.');'));
        }

        //recursion
        if($loop)
            dispatch(new PowerleadDistrubutonQueue($corporation_id));

        $message = "PowerleadDistrubutonQueue ran ".$countOfActiveAccounts." records";
        $time_finished = date('h:i:s');
        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }
}