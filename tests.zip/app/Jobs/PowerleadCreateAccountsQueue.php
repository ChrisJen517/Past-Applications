<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use DB;
use App\Traits\WriteToLog;
use App\Models\Powerlead_Settings;

class PowerleadCreateAccountsQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct()
    {
        //$this->corp_Id = $corp_Id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $neededPowerleadAccounts = Active_Account::select('ID', 'POESCORE')
            ->where('POWERLEAD_FLAG', 1)->whereNull('POWERLEAD_ID')
            ->orderBy('CREATED_AT')
            ->limit('40001')
            ->get();

        $startTime = date('Y-m-d h:i:s');

        $numberOfAccounts = count($neededPowerleadAccounts);

        if($numberOfAccounts == 0){
            return;
        }
        $loop = false;
        if($numberOfAccounts > 40000){
            unset($neededPowerleadAccounts[40000]);
            $loop = true;
        }

        $newAccountsStatement = "";
        foreach($neededPowerleadAccounts as $account){
            $newAccountsStatement = $newAccountsStatement." ('".$account->ID."', '".$startTime."', '".$startTime."'),";
        }
        $newAccountsStatement = substr_replace($newAccountsStatement ,"", -1);

        DB::select(DB::raw("INSERT INTO `powerlead_accounts` (active_account_id, updated_at, created_at) VALUES ".$newAccountsStatement.";"));

        DB::SELECT( DB::RAW("UPDATE `active_accounts` 
                    INNER JOIN `powerlead_accounts` PLA ON active_accounts.ID = PLA.active_account_id
                    SET active_accounts.UPDATED_AT = '".$startTime."', active_accounts.POWERLEAD_ID = PLA.id,
                    active_accounts.POWERLEAD_CAPCODE = 2
                    WHERE PLA.created_at = '".$startTime."';"));

        $powerlead_settings = Powerlead_Settings::first();

        DB::SELECT( DB::RAW("UPDATE `active_accounts` 
            INNER JOIN `powerlead_accounts` PLA ON active_accounts.ID = PLA.active_account_id
            SET active_accounts.POWERLEAD_CAPCODE = 1
            WHERE PLA.created_at = '".$startTime."' AND POESCORE < ".$powerlead_settings->hold_accounts_below_score.";"));

        if($loop)
            dispatch(new PowerleadCreateAccountsQueue());
    }
}