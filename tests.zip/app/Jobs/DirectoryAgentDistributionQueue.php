<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Directory_Active_Account;
use App\Models\Directory_Agent;
use App\Models\Directory_Inactive_Account;
use App\Models\Directory_Setting;
use DB;
use App\Traits\WriteToLog;
use App\Models\Queue_Log;


class DirectoryAgentDistributionQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct($corp_Id)
    {
        $this->corp_Id = $corp_Id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //tries to distribute the accounts to agents
        $this->distribute();
    }

    //distributes to agents copy of this function is in, trait/DirectoryAgentAccounts any modifications need to be done to both
    public function distribute(){
        $queue_log = new Queue_Log();
        $time_start = date('h:i:s');
        $queue_name = 'DirectoryAgentDistributionQueue';
        //gets needed information
        $directoryAgent = Directory_Agent::where('active', 1)->get();
        $agentCounts = Directory_Active_Account::SELECT(DB::raw('count(*) as count, directory_agent_id'))->groupBy('directory_agent_id')->get();
        $max = Directory_Setting::first()->max_accounts;
        $agentNumber = 0;
        $numberOfAgents = count($directoryAgent);

        //sets up the agents arrays
        foreach($directoryAgent as $agent){
            $directoryAgentInfo[$agentNumber] =[
                "NUMBER_OF_ACCOUNTS" => 0,
                "AA_IDS" => '',
                "AGENT_ID" => $agent->directory_agent_id,
            ];

            $check = $agentCounts->where('directory_agent_id', $agent->directory_agent_id)->first();
            
            if($check != null)
                $directoryAgentInfo[$agentNumber]["NUMBER_OF_ACCOUNTS"]= $check->count;

            if($directoryAgentInfo[$agentNumber]["NUMBER_OF_ACCOUNTS"] >= $max)
                unset($directoryAgentInfo[$agentNumber]); 
            else
                $agentNumber++;
        }

        //checks if there is no agents to be filled
        if(count($directoryAgentInfo) == 0){
            $message = "DirectoryAgentDistributionQueue ran all agents queues full";
            $time_finished = date('h:i:s'); 
            $queue_log->queue_name = $queue_name;
            $queue_log->message = $message;
            $queue_log->time_start = $time_start;
            $queue_log->time_finished = $time_finished;
            $queue_log->save();
            return;
        }

        //checks to see if the needed accounts are above 50,000 if so sets it to loop again
        $loop = false;
        $neededAccounts = $max * count($directoryAgentInfo);
        if($neededAccounts > 50000){
            $neededAccounts = 50000;
            $loop = true;
        }

        //gets the accounts to distribute
        $activeAccounts = Directory_Active_Account::where('directory_agent_id', null)->orderBy('created_at', 'asc')
        ->limit($neededAccounts)->select('directory_account_id')->get();
        $countOfActiveAccounts = count($activeAccounts);
        //if there are no accounts left, ends the recursion
        if($countOfActiveAccounts == 0){
            $message = "DirectoryAgentDistributionQueue ran no accounts found";
            $time_finished = date('h:i:s'); 
            $queue_log->queue_name = $queue_name;
            $queue_log->message = $message;
            $queue_log->time_start = $time_start;
            $queue_log->time_finished = $time_finished;
            $queue_log->save();
            return;
        }
            

        // Mass Update        
        $agentNumber = 0;
        $checkedAll = 0;

        foreach($activeAccounts as $active_account){
            startTeam:
            //checks if currect agent has reached their maximum
            if ($directoryAgentInfo[$agentNumber]["NUMBER_OF_ACCOUNTS"] >= $max) {
                //if all agents are checked breaks the loop
                $checkedAll++; 
                if ($checkedAll == $numberOfAgents) {
                    break;
                }

                //goes to the next agent otherwise
                $agentNumber++;
                if ($agentNumber == $numberOfAgents) {
                    $agentNumber = 0;
                }
                goto startTeam;
            } else {
                $checkedAll = 0;
            }

            $directoryAgentInfo[$agentNumber]["AA_IDS"] = $directoryAgentInfo[$agentNumber]["AA_IDS"].'"' . $active_account->directory_account_id . '",';
            $directoryAgentInfo[$agentNumber]["NUMBER_OF_ACCOUNTS"]++;
            
            $agentNumber++;
            if ($agentNumber == $numberOfAgents) {
                $agentNumber = 0;
            }
        }

        //updates the database
        foreach($directoryAgentInfo as $directoryAgent) {
            if ($directoryAgent["AA_IDS"] != "") {
                $directoryAgent["AA_IDS"] = substr_replace($directoryAgent["AA_IDS"], "", -1);
                DB::select(DB::raw('UPDATE `directory_active_accounts` SET `directory_agent_id` = '.$directoryAgent["AGENT_ID"].' WHERE `directory_account_id` IN ('.$directoryAgent["AA_IDS"].');'));
            }
        }

        //recursion
        if($loop)
            dispatch(new DirectoryAgentDistributionQueue($this->corp_Id));
   
        $message = "DirectoryAgentDistributionQueue ran ".$countOfActiveAccounts." records";
        $time_finished = date('h:i:s');

        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }

}