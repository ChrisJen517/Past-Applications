<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Powerlead;
use App\Models\Powerlead_Accounts;
use App\Models\Powerlead_Settings;
use App\Models\Queue_Log;

class PowerleadScoreDistributionQueue implements ShouldQueue
{
    public $tries = 3;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    public function __construct()
    {

    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $queue_log = new Queue_Log();
        $queue_name = 'PowerleadScoreDistributionQueue';
        $time_start = date('h:i:s');

        $powerlead_agents = Powerlead::with('user_link')->get();
        $powerlead_settings = Powerlead_Settings::first();
        $accounts_to_assign = 0;
        $agent_count = 0;
        $powerlead_agents_info = [];
        $allActive = Active_Account::where('POWERLEAD_CAPCODE', 3)->where('POWERLEAD_AGENT_ID', '!=' , null)->get();

        foreach($powerlead_agents as $powerlead_agent){
            if($powerlead_agent->user_link->active == 1){           
                $agent_count++;
            $queued_accounts = $allActive->where('POWERLEAD_AGENT_ID', $powerlead_agent->id);
            $accounts_to_assign_per_agent = $powerlead_settings->max_accounts - count($queued_accounts);
            $powerlead_agents_info[] = array(
                "AGENT_ID" => $powerlead_agent->id,
                "NUMBER_OF_ACCOUNTS" => count($queued_accounts),
                "AA_IDS" => ''
            );
            
            $accounts_to_assign = $accounts_to_assign + $accounts_to_assign_per_agent;
            if($accounts_to_assign < 0){
                $accounts_to_assign = 0;
            }
        }
        }

        //just a catch for the accounts active accounts
        $countOfActiveAccounts = 0;

        if($accounts_to_assign > 0){
            $first = $powerlead_settings->priority;
            $second = $powerlead_settings->second_priority;

            //if loops are beyond the limit
            $loop = false;
            if($accounts_to_assign > 50000){
                $accounts_to_assign = 50000;
                $loop = true;
            }
           
            $active_accounts = Active_Account::where('POWERLEAD_FLAG', 1)->where('POWERLEAD_CAPCODE', 2)
            ->when($first, function ($query, $first) {
                return $query->orderByRaw($first);
            })
            ->when($second, function ($query, $second) {
                return $query->orderByRaw($second);
            })->limit($accounts_to_assign)->get();

            $countOfActiveAccounts = count($active_accounts);
            if($countOfActiveAccounts == 0){
                $message = "ReleaseAccountsQueue ran no accounts found";
                $time_finished = date('h:i:s');
                $queue_log->queue_name = $queue_name;
                $queue_log->message = $message;
                $queue_log->time_start = $time_start;
                $queue_log->time_finished = $time_finished;
                $queue_log->save();
                return;
            }

            // Mass Update
            $numberOfAgents = $agent_count;
            $agentNumber = 0;
            $checkedAll = 0;

            foreach($active_accounts as $active_account){
                startTeam:
                if ($powerlead_agents_info[$agentNumber]["NUMBER_OF_ACCOUNTS"] >= $powerlead_settings->max_accounts) {
                    $checkedAll++;
                    if ($checkedAll == $numberOfAgents) {
                        break;
                    }

                    $agentNumber++;
                    if ($agentNumber == $numberOfAgents) {
                        $agentNumber = 0;
                    }

                    goto startTeam;
                } else {
                    $checkedAll = 0;
                }

                $powerlead_agents_info[$agentNumber]["AA_IDS"] = $powerlead_agents_info[$agentNumber]["AA_IDS"].'"' . $active_account->ID . '",';
                $powerlead_agents_info[$agentNumber]["NUMBER_OF_ACCOUNTS"]++;
                
                $agentNumber++;
                if ($agentNumber == $numberOfAgents) {
                    $agentNumber = 0;
                }
            }
            //updates the database
            foreach($powerlead_agents_info as $powerlead_agent) {
                if ($powerlead_agent["AA_IDS"] != "") {
                    $powerlead_agent["AA_IDS"] = substr_replace($powerlead_agent["AA_IDS"], "", -1);
                    DB::select(DB::raw('UPDATE `active_accounts` SET `POWERLEAD_AGENT_ID` = '.$powerlead_agent["AGENT_ID"].', POWERLEAD_CAPCODE = 3 WHERE `ID` IN ('.$powerlead_agent["AA_IDS"].');'));
                }
            }

            // Loop Active_accounts to assign powerlead account id
            foreach($active_accounts as $active_account){
                $active_account_input = Active_Account::find($active_account->ID);
                if($active_account_input->POWERLEAD_ID != null){
                    $powerlead_account = Powerlead_Accounts::find($active_account_input->POWERLEAD_ID);
                }else{
                    $powerlead_account = new Powerlead_Accounts;    
                }
                $powerlead_account->powerlead_agent_id = $active_account_input->POWERLEAD_AGENT_ID;
                $powerlead_account->active_account_id  = $active_account_input->ID;
                $powerlead_account->save();
                
                $active_account_input->POWERLEAD_ID = $powerlead_account->id;
                $active_account_input->save();
            }

            //recursion
            if($loop)
                dispatch(new PowerleadScoreDistributionQueue());
        }

        $message = "PowerleadScoreDistributionQueue ran ".$countOfActiveAccounts." records";
        $time_finished = date('h:i:s');
        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }
}