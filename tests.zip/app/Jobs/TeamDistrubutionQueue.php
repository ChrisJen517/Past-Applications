<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Team;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Distribution_Rules;
use App\Traits\AccountDistrubution;
use App\Models\Queue_Log;
use App\Models\Agent;

class TeamDistrubutionQueue implements ShouldQueue
{
    public $tries = 3;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;
    use AccountDistrubution;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct($corp_Id)
    {
        $this->corp_Id = $corp_Id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
        
        $queue_log = new Queue_Log();
        $queue_name = 'TeamDistrubutionQueue';
        $time_start = date('h:i:s');
        
        $corporation_id = $this->corp_Id;

        $this->TeamDistrubution($corporation_id);
        
        $message = "TeamDistrubutionQueue ran for corporation: ".$corporation_id;
        $time_finished = date('h:i:s');
        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    
    }
}
