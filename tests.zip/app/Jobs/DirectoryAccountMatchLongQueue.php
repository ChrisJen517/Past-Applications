<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use DB;
use PDO;
use Config;
use App\Models\Queue_Log;

class DirectoryAccountMatchLongQueue implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    public function __construct()
    {
    
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
        $queue_log = new Queue_Log();
        $time_start = date('h:i:s');
        $queue_name = 'DirectoryAccountMatchLongQueue';
        // Assigning DB values   
        $server = Config::get('app.server');
        $user = Config::get('app.user');
        $pass = Config::get('app.pass');
        $dbname = Config::get('app.dbname');

        $conn = new \PDO("mysql:host=$server;dbname=$dbname;", "$user", "$pass", array(
            PDO::ATTR_EMULATE_PREPARES => true
        ));
        $conn->exec("CALL directory_link_long_names_procedure();");
        $check = DB::select(DB::raw("SELECT count(*) AS 'count' FROM active_accounts WHERE DIRECTORY_FLAG = 1 AND DIRECTORY_LINK IS NULL AND NAME_MATCH IS NOT NULL AND NAME_MATCH != '' AND LENGTH(NAME_MATCH) > 7;"));

        if($check[0]->count > 0){
            dispatch(new DirectoryAccountMatchLongQueue());
        }
        
        $message = "DirectoryAccountMatchLongQueue ran 1000 records";
        $time_finished = date('h:i:s');

        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }
}
