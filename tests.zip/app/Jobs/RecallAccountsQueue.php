<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Team;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Distribution_Rules;
use App\Models\Queue_Log;

class RecallAccountsQueue implements ShouldQueue
{
    public $tries = 3;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog;

    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corporation_id;
    protected $source_code;
    protected $case_number;
    protected $client_id;
    protected $score;
    protected $comments;

    public function __construct($corporation_id, $source_code, $case_number, $client_id, $score, $comments)
    {
        $this->corporation_id = $corporation_id;
        $this->source_code = $source_code;
        $this->case_number = $case_number;
        $this->client_id = $client_id;
        $this->score = $score;
        $this->comments = $comments;
    }
    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        ini_set('memory_limit', '1024M');
        ini_set('max_execution_time', 720); //3 minutes
        ini_set('default_socket_timeout', 6000); 
        
        $queue_log = new Queue_Log();
        $queue_name = 'RecallAccountsQueue';
        $time_start = date('h:i:s');

        $corporation_id = $this->corporation_id;
        $comments = $this->comments;
        $source_code= $this->source_code;
        $case_number = $this->case_number;
        $client_id = $this->client_id;
        $score = $this->score; 

        $active_accounts = Active_Account::select('ID')
        ->where('CORPORATION_ID', $corporation_id)
        ->whereNotNull('TEAM_ID')->where('ON_HOLD', 0)
        ->when($source_code, function($query, $source_code){
            return $query->where('ACCT_SOURCE', $source_code);
        })
        ->when($case_number, function($query, $case_number){
            return $query->where('ACCT_CASE', $case_number);
        })
        ->when($client_id, function($query, $client_id){
            return $query->where('ACCT_CLIENT', $client_id);
        })
        ->when(!empty($score), function ($query) use ($score) { return $query->whereIN('POESCORE', $score);})
        ->limit(50001)->get();

        $countOfActiveAccounts = count($active_accounts);
        $loop = false;
        if($countOfActiveAccounts == 0)    
        {
            $message = "ReleaseAccountsQueue ran no Accounts Found";
            $time_finished = date('h:i:s');
            $queue_log->queue_name = $queue_name;
            $queue_log->message = $message;
            $queue_log->time_start = $time_start;
            $queue_log->time_finished = $time_finished;
            $queue_log->save();
            return 'done';
        }
        elseif(count($active_accounts) > 50000){
            unset($active_accounts[50000]);
            $loop = true;
        }

        $id_string = '';
        $id_count = 0;
        foreach($active_accounts as $data){
            if($id_count == 0){
                $id_string = '"'.$data->ID.'",'; 
                $id_count++;
            }
            else{
                $id_string = $id_string.' "'.$data->ID.'",';
            }
        }
        
        $id_string = substr_replace($id_string ,'', -1);
        DB::select(DB::raw("UPDATE active_accounts SET ACCT_AGENT = NULL, ON_HOLD = 1, LAST_COMMENTS = '$comments' WHERE ID IN($id_string);"));
    
        if($loop)
            dispatch(new RecallAccountsQueue($corporation_id, $source_code, $case_number, $client_id, $score, $comments));

        $message = "RecallAccountsQueue ran ".$countOfActiveAccounts." records";
        $time_finished = date('h:i:s');
        $queue_log->queue_name = $queue_name;
        $queue_log->message = $message;
        $queue_log->time_start = $time_start;
        $queue_log->time_finished = $time_finished;
        $queue_log->save();
    }
}