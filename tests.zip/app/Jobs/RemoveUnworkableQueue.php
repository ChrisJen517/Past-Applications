<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Team;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Distribution_Rules;
use App\Traits\getIdCombinations;
use App\Models\Queue_Log;
use App\Models\Agent;

class RemoveUnworkableQueue implements ShouldQueue
{
    public $tries = 3;

    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, WriteToLog, getIdCombinations;


    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;


    public function __construct($corp_Id)
    {
        $this->corp_Id = $corp_Id;
    }

    public function handle(){
        $corporation_id = $this->corp_Id;;
        $agents = Agent::where('corporation_id', $corporation_id)->with('user_link')->get();
        $teams =  Team::select('team_id','name')->where('is_deactivated', 0)->where('corporation_id', $corporation_id)->get();
        $team_rules = DB::SELECT(DB::RAW("SELECT team_id as 'teamid', (SELECT GROUP_CONCAT(distinct(has_access))  from users inner join agents on users.user_id = agents.user_id WHERE agents.team_id = teamid order by has_access) AS 'rule_team' FROM agents WHERE corporation_id = ".$corporation_id." GROUP BY team_id;
        "));
        $query_builder = "SELECT ACCESS_RULES AS 'RULES', COUNT(ID) AS 'COUNTs', (SELECT GROUP_CONCAT(id ORDER BY id) FROM access_levels WHERE FIND_IN_SET(shortcode, REPLACE(ACCESS_RULES, ' ', '')) and CORPORATION_ID = ".$corporation_id.") AS 'shortcode_id'";
        $count = 0; 
        foreach($teams as $team){
            $query_builder = $query_builder.", (SELECT count(ID) from active_accounts where ACCESS_RULES = RULES and CORPORATION_ID = ".$corporation_id." and TEAM_ID = ".$team->team_id.") AS 'COUNT_".$team->team_id."'";
            $count++;
        }        
        $query_builder = $query_builder." FROM `active_accounts` WHERE `corporation_id` = ".$corporation_id." AND `TEAM_ID` IS NOT NULL AND ACCESS_RULES IS NOT NULL AND ACCESS_RULES != '' GROUP BY `ACCESS_RULES` ORDER BY COUNTs DESC";
        $available_counts = DB::SELECT(DB::RAW($query_builder));

        foreach($team_rules as $team){
            $teamAccessLevels[$team->teamid] = [];
            
            $agents_by_team = $agents->where('team_id', $team->teamid);
            foreach($agents_by_team as $agent_by_team){
                $rule_array = explode(',',$agent_by_team->user_link->has_access);
                sort($rule_array);
                if($rule_array[0] == '')
                {
                    array_shift($rule_array); 
                }
                $rule_array = collect($rule_array);
                $rule_array = $rule_array->unique()->toArray();
                
                $teamAccessLevels[$team->teamid] = $this->getIdCombinations($teamAccessLevels[$team->teamid], $rule_array);
            }

            $teamAccessLevels[$team->teamid] = collect($teamAccessLevels[$team->teamid]);

            $removeAccessLevel[$team->teamid] = "";
        }

        foreach($available_counts as $available_count){
            //skips no shortcodes
            if($available_count->RULES == '' || $available_count->RULES == NULL){
                foreach($team_rules as $team){
                    continue;
                }
            }else{
                foreach($team_rules as $team){
                    $id = 'COUNT_'.$team->teamid;
                    //sees if the team has any of this type
                    if($available_count->$id != 0){
                        //checks if its not even a single agent could possibly work the account
                        if(!$teamAccessLevels[$team->teamid]->contains($available_count->shortcode_id))
                        {
                            $removeAccessLevel[$team->teamid] = $removeAccessLevel[$team->teamid].'"'.$available_count->RULES.'", ';
                        }
                    }
                }
            }
        }

        foreach($team_rules as $team){
            if($removeAccessLevel[$team->teamid] != ""){
                $removeAccessLevel[$team->teamid] = substr_replace($removeAccessLevel[$team->teamid], "", -2);
                DB::select(DB::raw('UPDATE `active_accounts` SET `TEAM_ID` = NULL, `TEAM_NAME` = NULL, ACCT_AGENT = NULL WHERE `TEAM_ID` = '.$team->teamid.' AND ACCESS_RULES IN ('.$removeAccessLevel[$team->teamid].');'));
            }
        }
    }
}