<?php

namespace App\Jobs;

use App\Models\Access_Levels;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Models\Active_Account;
use App\Models\Team;
use App\Models\Account_Source;
use DB;
use App\Traits\WriteToLog;
use App\Models\Distribution_Rules;
use App\Traits\HasAccess;
use App\Models\Queue_Log;
use App\Models\Agent;

class CheckWorkedSSN implements ShouldQueue
{
    public $tries = 3;
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels, HasAccess;
    /**
     * Create a new job instance.
     *
     * @return void 
     */

    protected $corp_Id;
    protected $start;
    protected $end;
    

    public function __construct($corp_Id, $start, $end)
    {
        $this->corp_Id = $corp_Id;
        $this->start = $start;
        $this->end = $end;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //gets all the ssns in the most recent upload
        $ssns = Active_Account::select('ACCT_SSN')
            ->where('ID', '>=', $this->start)->where('ID', '<=', $this->end)
            ->where('CORPORATION_ID', $this->corp_Id)->groupBy('ACCT_SSN')->get();

        if(count($ssns) == 0)
            return;
            
        $numbers = [];
        foreach($ssns as $ssn){
            $numbers[] = "'".$ssn->ACCT_SSN."'";
        }
        $numbers = implode(',', $numbers);

        //gets all agents who have worked one of the ssn
        $matchingSSN = DB::SELECT(DB::RAW(
            "SELECT DISTINCT(ACCT_SSN), ACCT_AGENT, TEAM_ID, VERIFIED_HITS_ID FROM `active_accounts`
            WHERE `ACCT_AGENT` IS NOT NULL 
            AND `LAST_WORKED` IS NOT NULL 
            AND `LAST_WORKED` != ''
            AND `ACCT_SSN` in (".$numbers.")
            AND `CORPORATION_ID` = ".$this->corp_Id.";")); 

        //if none, ends the job
        if(count($matchingSSN) == 0)
            return;

        $agentSSN = [];
        $team_ids = [];
        foreach($matchingSSN as $ssn){
            $agentSSN[$ssn->ACCT_AGENT][] = "'".$ssn->ACCT_SSN."'";
            $team_ids[$ssn->ACCT_AGENT] = "'".$ssn->TEAM_ID."'";
            $verified_ids[$ssn->ACCT_AGENT] = "'".$ssn->VERIFIED_HITS_ID."'"; 
            $ssnNoQuotes[$ssn->ACCT_AGENT][] = $ssn->ACCT_SSN;
        }

        $whereQueries = $this->getWhereQueries($ssnNoQuotes);

        //assigns agents to the social numbers
        foreach($agentSSN as $agent => $ssn){
            $agentNumbers = implode(',', $ssn);
            if($verified_ids[$agent] != null || $verified_ids[$agent] != ''){
                DB::select(DB::raw('UPDATE `active_accounts` 
                SET `ON_HOLD` = 0, `VERIFIED_HITS_ID` = '.$verified_ids[$agent].', `ACCT_AGENT` = '.$agent.', `TEAM_ID` = '.$team_ids[$agent].'
                WHERE `CORPORATION_ID` = '.$this->corp_Id.' AND ACCT_SSN IN ('.$agentNumbers.') '.$whereQueries[$agent].';'));
            }
            else{
                DB::select(DB::raw('UPDATE `active_accounts` 
                SET `ON_HOLD` = 0, `ACCT_AGENT` = '.$agent.', `TEAM_ID` = '.$team_ids[$agent].'
                WHERE `CORPORATION_ID` = '.$this->corp_Id.' AND ACCT_SSN IN ('.$agentNumbers.') '.$whereQueries[$agent].';'));
            }
        }
    }

    public function getWhereQueries($agentSSN){
        //sets all the agent ids and puts all ssns in an array
        $agentIds = [];
        $ssns = [];
        foreach($agentSSN as $agent => $acctSSNS){
            $agentIds[] = $agent;

            foreach($acctSSNS as $ssn)
                $ssns[] = $ssn;
        }

        //gets needed information
        $agents = Agent::whereIn('agent_id', $agentIds)->with('user_link')->get();
        $companyAccessShortcodes = Access_Levels::where('corporation_id', $this->corp_Id)->select('id', 'shortcode')->get();

        $SSNRules = Active_Account::select('ACCT_SSN', 'ACCESS_RULES', 'ID')
        ->where('ACCESS_RULES', '!=', null)->where('ACCESS_RULES', '!=', '')
        ->where('corporation_id', $this->corp_Id)->whereIn('ACCT_SSN', $ssns)
        ->groupBy('ACCT_SSN')->groupBy('ACCESS_RULES')->get();

        $allRules = [];
        foreach($agentSSN as $agent => $ssn){
            $agentAccess = $agents->where('agent_id', $agent)->first()->user_link->has_access;
            $agentAccess = collect(explode (",", $agentAccess));
            $accountRules = $SSNRules->whereIn('ACCT_SSN', $ssn);

            $rules = [];
            foreach($accountRules as $currentRules){
                array_push($rules, $currentRules->ACCESS_RULES);
            }

            if(!empty($rules)){
                foreach($rules as $rule){
                    $addToList = $this->checkAllAccessLevels(explode (",", $rule), $companyAccessShortcodes, $agentAccess);
                    if($addToList == true){
                        $allRules[$agent][] = "'".$rule."'";
                    }
                }
            }
        } 

        //sets up the final where queries
        $whereQueries = [];
        foreach($agentSSN as $agent => $ssn){
            $whereStatment = "AND (ACCESS_RULES = '' OR ACCESS_RULES IS NULL";
            if(!empty($allRules[$agent]))
                $whereStatment = $whereStatment." OR ACCESS_RULES IN (".implode(",", $allRules[$agent]).")";
            $whereQueries[$agent] = $whereStatment.")";
        }

        return $whereQueries;
    }
}