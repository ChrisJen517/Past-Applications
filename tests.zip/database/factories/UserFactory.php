<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */
use App\User;
use Illuminate\Support\Str;
use Faker\Generator as Faker;

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/

$factory->state(User::class, 'agent', function (Faker $faker) {
    return [
        'email' => $faker->unique()->safeEmail,
        'password' => bcrypt('Password1!'), // password
        'remember_token' => Str::random(10),
        'role' => 'agent',
        'password_valid' => 0,
        'active' => 0,
        'first_name' => $faker->firstNameMale,
        'last_name' => $faker->lastName
    ];
});

$factory->state(User::class, 'corporate_admin', function (Faker $faker) {
    return [
        'email' => $faker->unique()->safeEmail,
        'password' => bcrypt('Password1!'), // password
        'remember_token' => Str::random(10),
        'role' => 'corporate_admin',
        'password_valid' => 0,
        'active' => 0,
        'first_name' => $faker->firstNameMale,
        'last_name' => $faker->lastName
    ];
});

$factory->state(User::class, 'corporate_api', function (Faker $faker) {
    return [
        'email' => $faker->unique()->safeEmail,
        'password' => bcrypt('481231875'), // password
        'remember_token' => Str::random(10),
        'role' => 'corporate_api',
        'password_valid' => 0,
        'active' => 0,
        'first_name' => $faker->firstNameMale,
        'last_name' => $faker->lastName
    ];
});


$factory->state(User::class, 'manager', function (Faker $faker) {
    return [
        'email' => $faker->unique()->safeEmail,
        'password' => bcrypt('Password1!'), // password
        'remember_token' => Str::random(10),
        'role' => 'manager',
        'password_valid' => 0,
        'active' => 0,
        'first_name' => $faker->firstNameMale,
        'last_name' => $faker->lastName
    ];
});

$factory->state(User::class, 'Michael', function (Faker $faker) {
    return [
        'email' => 'MichaelC@rnngroup.com',
        'password' => bcrypt('Password1!'), // password
        'remember_token' => Str::random(10),
        'role' => 'admin',
        'password_valid' => 0,
        'active' => 1,
        'first_name' => 'Michael',
        'last_name' => 'Chestney'
    ];
});

$factory->state(User::class, 'Christian', function (Faker $faker) {
    return [
        'email' => 'ChristianJ@RNNGroup.com',
        'password' => bcrypt('Password1!'), // password
        'remember_token' => Str::random(10),
        'role' => 'admin',
        'password_valid' => 0,
        'active' => 1,
        'first_name' => 'Christian',
        'last_name' => 'Jensen'
    ];
});

$factory->state(User::class, 'Noah', function (Faker $faker) {
    return [
        'email' => 'NoahK@RNNGroup.com',
        'password' => bcrypt('Password1!'), // password
        'remember_token' => Str::random(10),
        'role' => 'admin',
        'password_valid' => 0,
        'active' => 1,
        'first_name' => 'Noah',
        'last_name' => 'Krause'
    ];
});

$factory->define(User::class, function (Faker $faker) {

    return [

    ];
});
