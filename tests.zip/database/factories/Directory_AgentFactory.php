<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Models\Directory_Agent;
use App\Models\Team;
use App\User;

$factory->define(Directory_Agent::class, function (Faker $faker) {
    $team = Team::orderBy('created_at', 'DESC')->first();
    $user = User::where('role', 'directory_agent')->where('active', 0)->first();
    $user->active = 1;
    $user->save();

    return [
        'team_id' => $team->team_id,
        'user_id' => $user->user_id,
    ];
});
