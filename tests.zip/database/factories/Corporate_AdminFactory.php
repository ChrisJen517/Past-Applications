<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */
use App\Models\Corporation;
use Illuminate\Support\Str;
use Faker\Generator as Faker;
use App\Models\Corporate_Admin;
use App\User;
/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| This directory should contain each of the model factory definitions for
| your application. Factories provide a convenient way to generate new
| model instances for testing / seeding your application's database.
|
*/


$factory->define(Corporate_Admin::class, function (Faker $faker) {
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $user = User::where('role', 'corporate_admin')->where('active', 0)->first();
    $user->active = 1;
    $user->save();

    return [
        'user_id' => $user->user_id,
        'corporation_id' => $corporation->corporation_id,
    ];
});
