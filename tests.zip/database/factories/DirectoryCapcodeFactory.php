<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Directory_Capcode;
use App\Models\Corporation;
use Faker\Generator as Faker;

$factory->define(Directory_Capcode::class, function (Faker $faker) {
    return DB::select(DB::raw("CALL seed_directory_capcodes();"));
});
