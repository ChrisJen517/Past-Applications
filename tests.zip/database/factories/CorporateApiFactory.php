<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Corporate_Api;
use App\Models\Corporation;
use Faker\Generator as Faker;
use App\User;

$factory->define(Corporate_Api::class, function (Faker $faker) {
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $user = User::where('role', 'corporate_api')->where('active', 0)->first();


    return [
        'user_id' => $user->user_id,
        'corporation_id' => $corporation->corporation_id,
        'UP' => '481231875',
    ];


});
