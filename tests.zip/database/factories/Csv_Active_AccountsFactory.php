<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Csv_Active_Accounts;
use Faker\Generator as Faker;
use Carbon\Carbon;
use App\Models\Corporation;
use App\Models\Agent;
use App\Models\Capcode;
use App\User;
use App\Models\Team;
use App\Models\Account_Source;
use App\Models\Acct_Case;

$factory->state(Csv_Active_Accounts::class, 'csv_start', function (Faker $faker) {
    
    // $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $corporation = Corporation::find(4);
    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);

    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);
    
    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $due_date_faker = $faker->dateTimeBetween($start = '+1 months', $end = '+1 years');

    $date = $dt->format("Y-m-d"); // 1994-09-24
    $due_date = $due_date_faker->format("Y-m-d");
    

    return [
        'acct_client' =>  $faker->unique()->randomNumber($nbDigits = 5, $strict = true),
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $due_date,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = true),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = true),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'POESCORE' => $faker->numberBetween(1, 10),
        'TIER' => $faker->numberBetween(1, 5),
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});

$factory->state(Csv_Active_Accounts::class, 'csv_continue', function (Faker $faker) {
    
    $last_account = Csv_Active_Accounts::orderBy('ID', 'DESC')->first();

    // $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $corporation = Corporation::find(4);

    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);

    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $due_date_faker = $faker->dateTimeBetween($start = '-1 years', $end = '-1 months');

    $date = $dt->format("Y-m-d"); // 1994-09-24
    $due_date = $due_date_faker->format("Y-m-d");

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $due_date,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'POESCORE' => $faker->numberBetween(1, 10),
        'TIER' => $faker->numberBetween(1, 5),
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});

$factory->state(Csv_Active_Accounts::class, 'csv_continue_team', function (Faker $faker) {
    $corporation_id = 253;
    $last_account = Csv_Active_Accounts::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::where('corporation_id', $corporation_id)->first();
    $Teams = Team::where('corporation_id', $corporation_id)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    shuffle($TeamArray);

    $account_sources = Account_Source::where('corporation_id', $corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);
    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $due_date_faker = $faker->dateTimeBetween($start = '-1 years', $end = '-1 months');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    $due_date = $due_date_faker->format("Y-m-d");
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'acct_case' => $last_account->ACCT_CASE,
        'acct_due_date' => $due_date,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'POESCORE' => $faker->numberBetween(1, 10),
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
    ];
});

$factory->state(Csv_Active_Accounts::class, 'csv_continue_agent', function (Faker $faker) {
    $corporation_id = 253;
    $last_account = Csv_Active_Accounts::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::where('corporation_id', $corporation_id)->first();
    $Teams = Team::where('corporation_id', $corporation_id)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    
    $account_sources = Account_Source::where('corporation_id', $corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    $agents = Agent::where('team_id', $TeamArray[0]->team_id)->get();
    $agents_Array = array();
    foreach($agents as $agent)
    {
        $agents_Array[] = $agent;
    }
    shuffle($agents_Array);

    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'ACCT_AGENT' => $agents_Array[0]->agent_id,
        'acct_case' => $last_account->ACCT_CASE,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $faker->dateTimeBetween($startDate = '-80 years', $end = '-18 years'),
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'POESCORE' => $faker->numberBetween(1, 10),
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
    ];
});



$factory->define(Csv_Active_Accounts::class, function (Faker $faker) {
    
    return [
 
    ];
});

