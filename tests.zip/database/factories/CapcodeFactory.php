<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Capcode;
use App\Models\Corporation;
use Faker\Generator as Faker;

$factory->define(Capcode::class, function (Faker $faker) {

    $corporation = Corporation::orderBy('created_at', 'DESC')->first();

    $curTime = new \DateTime();
    $created_at = $curTime->format("Y-m-d H:i:s");
    return DB::select(DB::raw("CALL generateDefaultCapcodes($corporation->corporation_id, '$created_at' );"));
});
