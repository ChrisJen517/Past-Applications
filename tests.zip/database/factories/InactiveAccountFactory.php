<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Inactive_Account;
use Faker\Generator as Faker;
use Carbon\Carbon;
use App\Models\Corporation;
use App\Models\Agent;
use App\Models\Capcode;
use App\User;
use App\Models\Team;
use App\Models\Active_Account;
use App\Models\Account_Source;
use App\Models\Acct_Case;


$factory->state(Inactive_Account::class, 'inactive_start', function (Faker $faker) {

    $last_account = Active_Account::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);
    $Teams = Team::where('corporation_id', $corporation->corporation_id)->where('team_id', 3)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    
    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    $agents = Agent::where('team_id', $TeamArray[0]->team_id)->get();
    $agents_Array = array();
    foreach($agents as $agent)
    {
        $agents_Array[] = $agent;
    }
    shuffle($agents_Array);

    $capcodes = Capcode::where('corporation_id', $corporation->corporation_id)->Where('type', 'verified')->get();

    $capcode_array = array();
    foreach($capcodes as $capcode)
    {
        $capcode_array[] = $capcode;
    }
    shuffle($capcode_array);
    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_NAME' => $TeamArray[0]->team_name,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'ACCT_AGENT' => $agents_Array[0]->agent_id,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'poescore' => $faker->randomDigit,
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'TIER' => $faker->numberBetween(1, 5),
        'CAPCODE' => $capcode_array[0]->capcode,
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});

$factory->state(Inactive_Account::class, 'inactive_verified', function (Faker $faker) {

    $last_account = Inactive_Account::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);
    $Teams = Team::where('corporation_id', $corporation->corporation_id)->where('team_id', 3)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    shuffle($TeamArray);
    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    $agents = Agent::where('team_id', $TeamArray[0]->team_id)->get();
    $agents_Array = array();
    foreach($agents as $agent)
    {
        $agents_Array[] = $agent;
    }
    shuffle($agents_Array);

    $capcodes = Capcode::where('corporation_id', $corporation->corporation_id)->Where('type', 'verified')->get();

    $capcode_array = array();
    foreach($capcodes as $capcode)
    {
        $capcode_array[] = $capcode;
    }
    shuffle($capcode_array);
    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_NAME' => $TeamArray[0]->team_name,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'ACCT_AGENT' => $agents_Array[0]->agent_id,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'poescore' => $faker->randomDigit,
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'TIER' => $faker->numberBetween(1, 5),
        'CAPCODE' => $capcode_array[0]->capcode,
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});


$factory->state(Inactive_Account::class, 'inactive_unverified', function (Faker $faker) {
    $last_account = Inactive_Account::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);
    $Teams = Team::where('corporation_id', $corporation->corporation_id)->where('team_id', 3)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    
    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    $agents = Agent::where('team_id', $TeamArray[0]->team_id)->get();
    $agents_Array = array();
    foreach($agents as $agent)
    {
        $agents_Array[] = $agent;
    }
    shuffle($agents_Array);

    $capcodes = Capcode::where('corporation_id', $corporation->corporation_id)->Where('type', 'unverified')->get();

    $capcode_array = array();
    foreach($capcodes as $capcode)
    {
        $capcode_array[] = $capcode;
    }
    shuffle($capcode_array);

    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_NAME' => $TeamArray[0]->team_name,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'ACCT_AGENT' => $agents_Array[0]->agent_id,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'poescore' => $faker->randomDigit,
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'TIER' => $faker->numberBetween(1, 5),
        'CAPCODE' => $capcode_array[0]->capcode,
        'CORPORATION_ID' => $corporation->corporation_id

    ];
});


$factory->define(Inactive_Account::class, function (Faker $faker) {
    
    return [
 
    ];
});

