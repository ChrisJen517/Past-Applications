<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Models\Acct_Case;

$factory->define(acct_case::class, function (Faker $faker) {

    return [
        'acct_case' => $faker->unique()->randomNumber($nbDigits = 5, $strict = true),
    ];
});
