<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Active_Account;
use Faker\Generator as Faker;
use Carbon\Carbon;
use App\Models\Corporation;
use App\Models\Agent;
use App\Models\Capcode;
use App\User;
use App\Models\Team;
use App\Models\Account_Source;
use App\Models\Acct_Case;
$factory->state(Active_Account::class, 'active_start', function (Faker $faker) {

    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);

    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);
    
    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');

    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    

    return [
        'acct_client' =>  $faker->unique()->randomNumber($nbDigits = 5, $strict = true),
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = true),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = true),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'POESCORE' => $faker->randomDigit,
        'TIER' => $faker->numberBetween(1, 5),
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});

$factory->state(Active_Account::class, 'active_continue', function (Faker $faker) {
    
    $last_account = Active_Account::orderBy('ID', 'DESC')->first();

    $corporation = Corporation::orderBy('created_at', 'DESC')->first();

    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);

    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'POESCORE' => $faker->randomDigit,
        'TIER' => $faker->numberBetween(1, 5),
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});

$factory->state(Active_Account::class, 'active_continue_team', function (Faker $faker) {
    $last_account = Active_Account::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();

    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);
    $Teams = Team::where('corporation_id', $corporation->corporation_id)->where('team_id', 3)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    shuffle($TeamArray);

    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);
    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_NAME' => $TeamArray[0]->team_name,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'poescore' => $faker->randomDigit,
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'TIER' => $faker->numberBetween(1, 5),
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});

$factory->state(Active_Account::class, 'active_continue_agent', function (Faker $faker) {
    $last_account = Active_Account::orderBy('ID', 'DESC')->first();
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $acct_cases = acct_case::orderBy('id', 'DESC')->limit(5)->get();
    $acct_caseArray = array();
    foreach($acct_cases as $acct_case)
    {
        $acct_caseArray[] = $acct_case;
    }
    shuffle($acct_caseArray);
    $Teams = Team::where('corporation_id', $corporation->corporation_id)->where('team_id', 3)->get();
    $TeamArray = array();
    foreach($Teams as $Team)
    {
        $TeamArray[] = $Team;
    }
    shuffle($TeamArray);

    $account_sources = Account_Source::where('corporation_id', $corporation->corporation_id)->get();
    $account_sourceArray = array();
    foreach($account_sources as $account_source)
    {
        $account_sourceArray[] = $account_source;
    }
    shuffle($account_sourceArray);

    $agents = Agent::where('team_id', $TeamArray[0]->team_id)->get();
    $agents_Array = array();
    foreach($agents as $agent)
    {
        $agents_Array[] = $agent;
    }
    shuffle($agents_Array);

    //Start point of our date range
    $start = Carbon::now();
    //End point of our date range.
    $end = Carbon::now()->addMonths(3);
    //Custom range.
    $randomDate = Carbon::createFromTimestamp(rand($end->timestamp, $start->timestamp))->format('Y-m-d');
    
    $dt = $faker->dateTimeBetween($start = '-80 years', $end = '-18 years');
    $date = $dt->format("Y-m-d"); // 1994-09-24
    

    return [
        'acct_client' =>  $last_account->ACCT_CLIENT,
        'TEAM_NAME' => $TeamArray[0]->team_name,
        'TEAM_ID' => $TeamArray[0]->team_id,
        'ACCT_AGENT' => $agents_Array[0]->agent_id,
        'acct_case' => $acct_caseArray[0]->acct_case,
        'acct_due_date' => $randomDate,
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $date,
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'poescore' => $faker->randomDigit,
        'ACCT_SOURCE'=> $account_sourceArray[0]->shortcode,
        'TIER' => $faker->numberBetween(1, 5),
        'CORPORATION_ID' => $corporation->corporation_id
    ];
});



$factory->define(Active_Account::class, function (Faker $faker) {
    
    return [
 
    ];
});

