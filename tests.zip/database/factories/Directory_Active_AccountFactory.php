<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Models\Directory_Active_Accounts;
use App\Models\Agent;

$factory->define(Directory_Active_Accounts::class, function (Faker $faker) {
    $agent = Agent::orderBy('created_at', 'DESC')->first();
    return [
        'directory_account_id' => $faker->unique()->randomNumber($nbDigits = 8),
        'directory_agent_id' => $agent->agent_id,
        'capcode' => $faker->randomNumber($nbDigits = 6, $strict = false),
        'direct_phone' => $faker->phoneNumber,
        'contact_email' => $faker->email,
        'verification_phone' => $faker->phoneNumber,
        'verification_email' => $faker->email,
        'verification_fax' => $faker->phoneNumber,
        'third_party_name' => $faker->company,
        'third_party_account_number' => $faker->unique()->randomNumber($nbDigits = 8),
        'company_website' => $faker->url,
        'verification_contact' => $faker->name,
        'change_agent_id' => $faker->unique()->randomNumber($nbDigits = 7),

    ];
});
