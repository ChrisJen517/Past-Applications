<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use Faker\Generator as Faker;
use App\Models\Corporation;
use App\Models\Account_Source;

$factory->define(Account_Source::class, function (Faker $faker) {

    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    static $priority = 1;

    return [
        'name' => $faker->catchPhrase,
        'description' => $faker->bs,
        'shortcode' => $faker->bothify('sc##??'),
        'priority' => $priority++,
        'corporation_id' => $corporation->corporation_id
    ];
});
