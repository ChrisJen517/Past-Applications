<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Team_Distribution_Rules;
use App\Models\Corporation;
use Faker\Generator as Faker;
use App\Models\Team;

$factory->define(Team_Distribution_Rules::class, function (Faker $faker) {
    $team = Team::orderBy('created_at', 'DESC')->first();


    return [
        'team_id' => $team->team_id,
        'priority' => 'POESCORE',
        'second_priority' => 'ACCT_DUE_DATE'
    ];
});
