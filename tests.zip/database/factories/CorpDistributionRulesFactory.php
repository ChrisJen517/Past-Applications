<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Distribution_Rules;
use App\Models\Corporation;
use Faker\Generator as Faker;

$factory->define(Distribution_Rules::class, function (Faker $faker) {
    $corporation = Corporation::orderBy('created_at', 'DESC')->first();

    return [
        'corporation_id' => $corporation->corporation_id,
        'priority' => 'POESCORE',
        'second_priority' => 'ACCT_DUE_DATE'
    ];
});
