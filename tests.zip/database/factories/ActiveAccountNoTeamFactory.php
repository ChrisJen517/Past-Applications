<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Active_Account;
use App\Models\Corporation;
use App\Models\Agent;
use App\Models\Capcode;
use App\User;
use App\Models\Team;
use Faker\Generator as Faker;


$factory->define(Active_Account::class, function (Faker $faker) {


    
    
    return [
 
    ];
});

$factory->state(Active_Account::class, 'ActiveAccountNoTeam', function (Faker $faker) {

    $corporation = Corporation::orderBy('created_at', 'DESC')->first();
    $capcodes = Capcode::where('corporation_id', $corporation->corporation_id)->get();
    $capcodeArray = array();
    

    foreach($capcodes as $capcode)
    {
        $capcodeArray[] = $capcode;
    }
    shuffle($capcodeArray);
    
    return [
        'add_date' => $faker->dateTimeThisYear,
        'add_file' => Str::random(10).'.'.$faker->fileExtension,
        'added_by' => $faker->name,
        'acct_client' =>  $faker->randomNumber($nbDigits = null, $strict = false),
        'acct_agent' => $faker->unique()->randomNumber($nbDigits = 5),
        'acct_case' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'acct_due_date' => $faker->dateTimeBetween($startDate = '+1 months', $endDate = '+1 years'),
        'acct_ssn' => $faker->randomNumber($nbDigits = 9, $strict = false),
        'acct_first_name' => $faker->firstName,
        'acct_last_name' => $faker->lastName,
        'acct_ad1' => $faker->streetAddress,
        'acct_city' => $faker->city,
        'acct_st' => $faker->state,
        'acct_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'acct_dob' => $faker->dateTimeBetween($startDate = '-80 years', $end = '-18 years'),
        'acct_id' => $faker->unique()->randomNumber($nbDigits = null, $strict = false),
        'acct_source' => $faker->randomNumber(),
        'empl_name' => $faker->company,
        'empl_addr1' => $faker->streetAddress,
        'empl_city' => $faker->city,
        'empl_st' => $faker->state,
        'empl_zip' => $faker->randomNumber($nbDigits = 5, $strict = false),
        'empl_hr_addr' => $faker->address,
        'empl_phone1_nmbr' => $faker->phoneNumber,
        'empl_ph_source' => $faker->company,
        'empl_fax' => $faker->phoneNumber,
        'empl_email' => $faker->companyEmail,
        'empl_contact' => $faker->name,
        'empl_contact_title' => $faker->jobTitle,
        'capcode' => $capcodeArray[0]->capcode,
        'last_worked' => $faker->dateTime($max = '-1 day'),
        'last_comments' =>$faker->text,
        'time_zone' => $faker->timezone,
        'poescore' => $faker->randomDigit,
        'reminder' => $faker->text($maxNbChars = 45),
        'corporation_id' => $corporation->corporation_id
    ];
});




