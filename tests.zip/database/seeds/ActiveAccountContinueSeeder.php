<?php

use Illuminate\Database\Seeder;

class ActiveAccountContinueSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Active_Account::class, 25)->states('active_continue')->create();
    }
}
