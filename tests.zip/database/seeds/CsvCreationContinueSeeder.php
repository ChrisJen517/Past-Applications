<?php

use Illuminate\Database\Seeder;

class CsvCreationContinueSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Csv_Active_Accounts::class, 25)->states('csv_continue')->create();
    }
}
