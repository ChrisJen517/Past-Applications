<?php

use Illuminate\Database\Seeder;

class InactiveAccountStartSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Inactive_Account::class, 1)->states('inactive_start')->create();
    }
}
