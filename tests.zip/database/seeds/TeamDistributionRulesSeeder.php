<?php

use Illuminate\Database\Seeder;

class TeamDistributionRulesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Team_Distribution_Rules::class, 1)->create();
    }
}
