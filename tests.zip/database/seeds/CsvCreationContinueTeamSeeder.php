<?php

use Illuminate\Database\Seeder;

class CsvCreationContinueTeamSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Csv_Active_Accounts::class, 15)->states('csv_continue_team')->create();
    }
}
