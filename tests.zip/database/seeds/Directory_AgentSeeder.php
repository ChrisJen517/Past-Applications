<?php

use Illuminate\Database\Seeder;

class Directory_AgentSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Directory_Agent::class, 1)->create();
    }
}
