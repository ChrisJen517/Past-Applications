<?php

use Illuminate\Database\Seeder;

class ActiveAccountContinueTeamSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Active_Account::class, 15)->states('active_continue_team')->create();
    }
}
