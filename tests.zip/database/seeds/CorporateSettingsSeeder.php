<?php

use Illuminate\Database\Seeder;

class CorporateSettingsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Models\Corporate_Settings::class, 1)->create();
    }
}
