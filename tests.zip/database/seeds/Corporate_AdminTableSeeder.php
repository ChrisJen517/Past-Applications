<?php

use Illuminate\Database\Seeder;

class Corporate_AdminTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Corporate_Admin::class, 1)->create();
    }
}
