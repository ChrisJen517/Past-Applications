<?php

use Illuminate\Database\Seeder;

class InactiveAccountVerifiedSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Inactive_Account::class, 20)->states('inactive_verified')->create();
    }
}
