<?php

use Illuminate\Database\Seeder;

class DatabaseFullSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call(UserTableAdminSeeder::class);

        $runCount = 0;

        do {
            $countTeam = 0;
            $countAdmin = 0;
            $this->call(CorporationTableSeeder::class);
            $this->call(UserTableCorporateApiSeeder::class);
            $this->call(CorporateApiSeeder::class);
            $this->call(CorporateSettingsSeeder::class);
            $this->call(CorpDistributionRulesSeeder::class);
            $this->call(AccountSourceSeeder::class);
            $this->call(CapcodeSeeder::class);
            do {
                $this->call(UserTableCorporateAdminSeeder::class);
                $this->call(Corporate_AdminTableSeeder::class);
                $countAdmin++;
            } while ($countAdmin < 2);
            do {
                $this->call(TeamTableSeeder::class);
                $this->call(TeamDistributionRulesSeeder::class);
                $countManager = 0;
                do {
                    $this->call(UserTableManagerSeeder::class);
                    $this->call(ManagerTableSeeder::class);
                    $countManager++;
                } while ($countManager < 2);

                $countAgent = 0;
                do {
                    $this->call(UserTableAgentSeeder::class);
                    $this->call(AgentTableSeeder::class);
                    $countAgent++;
                } while ($countAgent < 15);

                $countTeam++;
            } while ($countTeam < 3);
            $runCount++;
        } while ($runCount < 1);
    }
}
