<?php

use Illuminate\Database\Seeder;

class Directory_Active_AccountSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Directory_Active_Account::class, 10)->create();
    }
}
