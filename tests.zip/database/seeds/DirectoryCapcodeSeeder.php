<?php

use Illuminate\Database\Seeder;

class DirectoryCapcodeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Directory_Capcode::class, 1)->create();
    }
}
