<?php

use Illuminate\Database\Seeder;

class ActiveAccountContinueAgentSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Active_Account::class, 30)->states('active_continue_agent')->create();
    }
}
