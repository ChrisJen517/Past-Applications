<?php

use Illuminate\Database\Seeder;

class UserTableAdminSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\User::class, 1)->states('Noah')->create();
        factory(App\User::class, 1)->states('Michael')->create();
        factory(App\User::class, 1)->states('Christian')->create();
    }
}
