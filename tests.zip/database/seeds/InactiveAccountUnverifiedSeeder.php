<?php

use Illuminate\Database\Seeder;

class InactiveAccountUnverifiedSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Inactive_Account::class, 10)->states('inactive_unverified')->create();
    }
}
