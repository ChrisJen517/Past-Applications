<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        // Active/Inactive Account Seed
 
        // $count = 0;
        // do{
            // $this->call(AcctCaseSeeder::class);
        //     $this->call(ActiveAccountSeeder::class);
        //     $this->call(ActiveAccountContinueSeeder::class);    
        //     $this->call(ActiveAccountContinueTeamSeeder::class);
        //     $this->call(ActiveAccountContinueAgentSeeder::class);
        //     $this->call(InactiveAccountStartSeeder::class);
        //     $this->call(InactiveAccountVerifiedSeeder::class);
        //     $this->call(InactiveAccountUnverifiedSeeder::Class);    
        //     $count++;
        // }while($count < 50);

        // CSV Active Account Seed

        $count = 0;
        do{
            $this->call(AcctCaseSeeder::class);
            $this->call(CsvCreationSeeder::class);
            $this->call(CsvCreationContinueSeeder::class);  
            $count++;
        }while($count < 35);
    }
}