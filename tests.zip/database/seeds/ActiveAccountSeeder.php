<?php

use Illuminate\Database\Seeder;

class ActiveAccountSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Active_Account::class, 1)->states('active_start')->create();
    }
}
