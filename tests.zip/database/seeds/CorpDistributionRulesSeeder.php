<?php

use Illuminate\Database\Seeder;

class CorpDistributionRulesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Distribution_Rules::class, 1)->create();
    }
}
