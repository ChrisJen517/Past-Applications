<?php

use Illuminate\Database\Seeder;

class Directory_Inactive_AccountSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(\App\Models\Directory_Inactive_Account::class, 10)->create();
    }
}
