<?php

use Illuminate\Database\Seeder;

class AccountSourceSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      
        
        factory(\App\Models\Account_Source::class, 12)->create();
        
    }
}
