<?php

use Illuminate\Database\Seeder;

class CsvCreationContinueAgentSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Csv_Active_Accounts::class, 10)->states('csv_continue_agent')->create();
    }
}
