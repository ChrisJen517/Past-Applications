<?php

use Illuminate\Database\Seeder;

class CsvCreationSeeder extends Seeder
{
    public function run()
    {
        factory(\App\Models\Csv_Active_Accounts::class, 1)->states('csv_start')->create();
    }
}
