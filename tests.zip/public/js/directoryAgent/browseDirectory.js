function confirmDelete(account_id, type) {
    urlLink = "/directory_agent/DeleteAccount";
    swal({
        title: "Are you sure?",
        text: "This account will be permanently deleted!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                console.log(type);
                console.log(account_id);
                $.ajax({
                    headers: {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        )
                    },
                    type: "POST",
                    url: urlLink,
                    data: { type: type, accountId: account_id },
                    dataType: "json"
                });
                $("#browseDirectoryTable")
                    .DataTable()
                    .ajax.reload();

                $.LoadingOverlay("hide");
                swal(" Account Was Deleted!", {
                    icon: "success"
                });
            });
        } else {
            swal("Account was not blocked!");
        }
    });
}

$(document).ready(function() {
    var table = $("#browseDirectoryTable").DataTable({
        processing: true,
        serverSide: true,
        initComplete: function(settings, json) {
            $("#loader")
                .delay(25)
                .fadeOut();
            $("#accountCard")
                .delay(450)
                .fadeIn();

            var input = $(".dataTables_filter input").unbind(),
                self = this.api();

            $(".dataTables_filter input").keyup(function(e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, "")).draw();
            }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                )
                    .text("search")
                    .click(function() {
                        self.search(input.val().replace(/['"]+/g, "")).draw();
                    }));
            $(".dataTables_filter").append($searchButton);
        },
        ajax: "/directory_agent/getDirectoryTable",
        columns: [
            { data: "directory_account_id" },
            { data: "employer_name" },
            { 
                data: "phone number",
                render: function (data, type, row, meta) {
                    number = row.direct_phone || row.empl_org_phone;
                    return number;
                }
            },
            { data: "last_worked" },
            { data: "aka" },
            { data: "capcode" },
            {
                data: "action",
                searchable: false,
                sortable: false,
                render: function(action, type, row, meta) {
                    if($('#open_new_tab').val() == 1)
                        newTab = 'target="_blank"'
                    else
                        newTab = '';
                    
                    return (
                        '<form action="/directory_agent/WorkAccount" '+newTab+' method="GET"  enctype="multipart/form-data" id="workedAccount" ><td class="text-center" id="workTD"><input hidden value="' +
                        row.type +
                        '" name="type"><input name="accountId" id="accountId" value="' +
                        row.directory_account_id +
                        '" hidden><input type="submit" class="btn btn-info" value="Work Account" id="workAccount"></td></form>'
                    );
                }
            }
        ],
        lengthChange: false,
        buttons: [
            { extend: "copy", className: "copyButton btn-info" },
            { extend: "excel", className: "excelButton" },
            { extend: "pdf", className: "pdfButton" },
            { extend: "print", className: "printButton" },
            { extend: "colvis", className: "colvisButton" }
        ]
    });
    function confirmDelete(account_id, type) {
        urlLink = "/admin/directory/DeleteAccount";
        swal({
            title: "Are you sure?",
            text: "Once blocked, you will be able to unblock account!",
            icon: "warning",
            buttons: true,
            dangerMode: true
        }).then(willDelete => {
            if (willDelete) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: urlLink,
                        contentType: "application/json; charset=utf-8",
                        data: { type: type, accountId: account_id },
                        dataType: "json",
                        success: AjaxSucceeded,
                        error: AjaxFailed
                    });
                    parent.empty();
                    $.LoadingOverlay("hide");
                    swal(data + " Account Was Deleted!", {
                        icon: "success"
                    });
                });
            } else {
                swal("Account was not blocked!");
            }
        });
    }

    table.on("processing.dt", function(e, settings, processing) {
        $("#processingIndicator").css("display", "none");
        if (processing) {
            $("#accountCard")
                .delay(0)
                .fadeOut();
            $("#loader")
                .delay(450)
                .fadeIn();
        } else {
            $("#loader")
                .delay(25)
                .fadeOut();
            $("#accountCard")
                .delay(450)
                .fadeIn();
        }
    });
    table
        .buttons()
        .container()
        .appendTo("#example_wrapper .col-md-6:eq(0)");
});

// Brandon's code below
//
// $(document).ready(function() {
//     $("#posts").DataTable({
//         processing: true,
//         serverSide: true,
//         ajax: {
//             url: "{{ url('/directory_agent/getDirectoryTable') }}",
//             dataType: "json",
//             type: "POST",
//             data: { _token: "{{csrf_token()}}" }
//         },
//         columns: [
//             { data: "employer_name" },
//             { data: "direct_phone" },
//             { data: "last_worked" },
//             { data: "aka" },
//             { data: "capcode" }
//         ]
//     });
// });
