
$(document).ready(function () {

    var table = $('#example').DataTable({
        lengthChange: false,
        autoWidth: false
    });

    table.buttons().container()
        .appendTo('#example_wrapper .col-md-6:eq(0)');

});

//remove deactive rows from first datatable
$("#example > tbody > .deactive").remove();

$(document).ready(function () {


    var table = $("#deactivesTable").DataTable({
        lengthChange: false,
        autoWidth: false
    })

    table.buttons().container()
        .appendTo('#deactivesTable_wrapper .col-md-6:eq(0)');

        $("#deactivesTable_wrapper").css('display', 'none');

});




//toggle datatable showing all deactive accounts


//initialize multi-select in edit user form
$(document).ready(function () {
    $('.multiple-select-access').select2({
        placeholder: 'Please Select Access Levels'
    });

    $('.multiple-select-roles').select2({
        placeholder: 'Please Select Roles'
    });
});


//function for getting Access level IDs and submitting edit user form
function submitEdit() {

    var titles = [];

    if ($('.select2-selection__choice').length) {
        $.each($('.select2-selection__choice'), function () {
            var title = $(this).prop('title');
            var shortcode = title.slice(title.indexOf(',') + 1);
            shortcode = shortcode.trim();
            titles.push(shortcode);
        })


        $.ajax({
            url: '/getCorpAccessIds',
            data: { titles: titles },
            type: "GET",
            success: function (data) {
                var items = JSON.parse(data);

                $("#access_levels").val(items);
                $("#edit_user_form").submit();
            }
        })
    } else {
        $("#access_levels").val('');
        $("#edit_user_form").submit();
    }
}



$('#myModalMod').on('show.bs.modal', function (e) {

    $('#pswd_info').hide();
    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget;//this holds the element who called the modal
    //we get details from attributes
    var idName = $(opener).attr('id-name');
    var first_name = $(opener).attr('d-first_name');
    var last_name = $(opener).attr('d-last_name');
    var email = $(opener).attr('d-email');
    var role = $(opener).attr('d-role');
    var access = $(opener).attr('d-access');
    var role_list = $(opener).attr("d-role_list");
    var agent_id = $(opener).attr("d-agent_id");
    access = access.split(',');
    role = role.charAt(0).toUpperCase() + role.substring(1)

    $('#edit_user_form').find('[name="idName"]').val(idName);
    $('#edit_user_form').find('[name="first_name"]').val(first_name);
    $('#edit_user_form').find('[name="last_name"]').val(last_name);
    $('#edit_user_form').find('[name="email"]').val(email);
    $('#edit_user_form').find('[name="role"]').val(role);

    if(agent_id != ''){
        $("#agent_edit").val(agent_id);
        $("#agent_edit").prop( "disabled", true );
    }
    else
        $("#agent_edit").prop( "disabled", false );

    $('#multiple-select-access').val(access).trigger('change');

    if(role_list != 'null'){
        role_list = role_list.split(",");
        $("#role_list_edit").val(role_list).trigger("change");
    }
});

var neededRoleList = ['agent'];
var neededFieldList = ['agent'];

$("#role_list_edit").on("change", function() {
    role_list = $("#role_list_edit").val();

    for(i = 0; i < neededRoleList.length; i++){
        field = '#'+neededFieldList[i]+'_edit_id';
        if((jQuery.inArray(neededRoleList[i], role_list) != -1))
            $(field).prop( "hidden", false );
        else
            $(field).prop( "hidden", true );
    }
});

$("#role_list_add").on("change", function() {
    role_list = $("#role_list_add").val();
    selected_role = $("#Update").find('[name="role"]').val();

    for(i = 0; i < neededRoleList.length; i++){
        field = '#'+neededFieldList[i]+'_create_id';
        if((jQuery.inArray(neededRoleList[i], role_list) != -1) || (selected_role == neededRoleList[i]))
            $(field).prop( "hidden", false );
        else
            $(field).prop( "hidden", true );
    }
});

$("#roleAdd").on("change", function() {
    var valueSelected = this.value;
    if (valueSelected == "agent"){
        $('#agent_create_id').attr('hidden', false);
    }
    else{
        $('#agent_create_id').attr('hidden', true);
    }
});

function confirmDelete(userId, agentId) {
    urlLink = "/corporateAdmin/DeleteAgent/" + userId;
    swal({
        title: "Are you sure?",
        text: "This user will not be able to use the application until reactivated!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
                window.location = urlLink;
                $.LoadingOverlay("show");
        }
        else {
            swal("Account Not Deactivated!");
        }
    });
}

function confirmReactivate(userId, teamId) {
    urlLink = "/corporateAdmin/ReactivateAgent/" + userId + "/" + teamId;
    swal({
        title: "Are you sure?",
        text: "Would you like to reactivate this account?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {

                window.location = urlLink;
                $.LoadingOverlay("show");
        }
        else {
            swal("Account Not Reactivated!");
        }
    });
}

function passwordReset(userId) {
    urlLink = "/corporateAdmin/SendPasswordReset/" + userId;
    swal({
        title: "Are you sure?",
        text: "Once Sent, an email will be sent to reset password!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {

                window.location = urlLink;
                $.LoadingOverlay("show");

        }
        else {
            swal("Password Not Reset!");
        }
    });
}

$(window).load(function () {
    $('#loader').delay(70).fadeOut();
    $('#accountCard').delay(450).fadeIn();
});

$('.block').click(function () {
    $.LoadingOverlay("show");
});

//hides or shows the deactive accounts
function toggleDeactive() {
    $("#example").toggle();
    $("#example_wrapper").toggle();
    $("#deactivesTable").toggle();
    $("#deactivesTable_wrapper").toggle();
    if($('#example').css('display') == 'none'){
        $("#toggleHidden").html('Hide Deactivated Accounts');
    }else{
        $("#toggleHidden").html('Show Deactivated Accounts');
    }

}


var selected_team;
var reactivate_user;

$('#myModalReactivate').on('show.bs.modal', function (e) {

    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget;//this holds the element who called the modal
    //we get details from attributes
    var idName = $(opener).attr('id-name');
    var first_name = $(opener).attr('d-first_name');
    var last_name = $(opener).attr('d-last_name');
    var team_id = $(opener).attr('d-team');

    reactivate_user = idName;

    $('#reactivate_user_form').find('[name="idName"]').val(idName);
    $('#reactivate_user_form').find('[name="first_name"]').val(first_name);
    $('#reactivate_user_form').find('[name="last_name"]').val(last_name);
    $('#reactivate_user_submit').attr('onclick', 'confirmReactivate(' + idName + ', ' + team_id + ')');
    $('#team_'+team_id).attr('selected', 'selected');
    selected_team = $('#team_'+team_id);

});

$('#team').on('change', function(){
    var team_id = $(this).val();
    $('#reactivate_user_submit').attr('onclick', 'confirmReactivate(' + reactivate_user + ', ' + team_id + ')');

    if(selected_team.attr("selected") == "selected")
        selected_team.removeAttr('selected');

    if($("#team_" + $(this).val()).attr('deactivated') == 1)
        $('#team_warning').removeAttr('hidden');
    else
        $('#team_warning').prop('hidden', true);
});

