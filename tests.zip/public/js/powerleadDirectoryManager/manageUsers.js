
$(document).ready(function () {

    var table = $('#example').DataTable({
        lengthChange: false,
        autoWidth: false
    });

    table.buttons().container()
        .appendTo('#example_wrapper .col-md-6:eq(0)');

});

//remove deactive rows from first datatable
$("#example > tbody > .deactive").remove();

$(document).ready(function () {
    $('.multiple-select-roles').select2({
        placeholder: 'Please Select Roles'
    });

    var table = $("#deactivesTable").DataTable({
        lengthChange: false,
        autoWidth: false
    })

    table.buttons().container()
        .appendTo('#deactivesTable_wrapper .col-md-6:eq(0)');

        $("#deactivesTable_wrapper").css('display', 'none');

});



$('#myModalMod').on('show.bs.modal', function (e) {

    $('#pswd_info').hide();
    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget;//this holds the element who called the modal
    //we get details from attributes
    var idName = $(opener).attr('id-name');

    var first_name = $(opener).attr('d-first_name');
    var last_name = $(opener).attr('d-last_name');
    var email = $(opener).attr('d-email');
    var role = $(opener).attr('d-role');
    var dir_account_type = $(opener).attr("d-dir_account_type");
    var role_list = $(opener).attr("d-role_list");
    var directory_id = $(opener).attr("d-directory_id");
    var power_id = $(opener).attr("d-power_id");

    role = role.charAt(0).toUpperCase() + role.substring(1)

    $('#edit_user_form').find('[name="userId"]').val(idName);
    $('#edit_user_form').find('[name="first_name"]').val(first_name);
    $('#edit_user_form').find('[name="last_name"]').val(last_name);
    $('#edit_user_form').find('[name="email"]').val(email);
    $('#edit_user_form').find('[name="role"]').val(role);

    $("#directory_account_type_row").hide();

    if(directory_id != ''){
        $("#directory_edit").val(directory_id);
        $("#directory_edit").prop( "disabled", true );
        $("#directory_account_type_row").show();
        $("#dir_account_type").val(dir_account_type);
    }
    else
        $("#directory_edit").prop( "disabled", false );
    if(power_id != ''){
        $("#power_edit").val(power_id);
        $("#power_edit").prop( "disabled", true );
    }
    else
        $("#power_edit").prop( "disabled", false );

    if(role_list != 'null'){
        role_list = role_list.split(",");
        $("#role_list_edit").val(role_list).trigger("change");
    }
});

$('#myModalAddUser').on('show.bs.modal', function (e) {
    $('#next_id_direct').attr('hidden', true);
    $('#next_id_Power').attr('hidden', false);
});

$("#roleAdd").on("change", function() {
    var valueSelected = this.value;
    if (valueSelected == "directory_agent"){
        $("#create_directory_account_type_row").show();
        $('#next_id_direct').attr('hidden', false);
        $('#next_id_Power').attr('hidden', true);
        $('#power_create_id').prop( "hidden", false );
    }
    else{
        $("#create_directory_account_type_row").hide();
        $('#next_id_direct').attr('hidden', true);
        $('#next_id_Power').attr('hidden', false);
        $('#directory_create_id').prop( "hidden", false );
    }
});

var neededRoleList = ['powerlead', 'directory_agent'];
var neededFieldList = ['power','directory'];

$("#role_list_edit").on("change", function() {
    role_list = $("#role_list_edit").val();

    for(i = 0; i < neededRoleList.length; i++){
        field = '#'+neededFieldList[i]+'_edit_id';
        if((jQuery.inArray(neededRoleList[i], role_list) != -1))
            $(field).prop( "hidden", false );
        else
            $(field).prop( "hidden", true );
    }
});

$("#role_list_add").on("change", function() {
    role_list = $("#role_list_add").val();
    selected_role = $("#Update").find('[name="role"]').val();

    for(i = 0; i < neededRoleList.length; i++){
        field = '#'+neededFieldList[i]+'_create_id';
        if((jQuery.inArray(neededRoleList[i], role_list) != -1) || (selected_role == neededRoleList[i]))
            $(field).prop( "hidden", false );
        else
            $(field).prop( "hidden", true );
    }
});


function confirmDelete(userId, agentId) {
    urlLink = "deleteUser/" + userId;
    swal({
        title: "Are you sure?",
        text: "This user will not be able to use the application until reactivated!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            swal("Account Deactivated!", {
                icon: "success",
            }).then(function () {
                window.location = urlLink;
                $.LoadingOverlay("show");

            });
        }
        else {
            swal("Account Not Deactivated!");
        }
    });
}

function confirmReactivate(userId, agentId) {
    urlLink = "reactivateUser/" + userId;
    swal({
        title: "Are you sure?",
        text: "Would you like to reactivate this account?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            swal("Account Reactivated!", {
                icon: "success",
            }).then(function () {
                window.location = urlLink;
                $.LoadingOverlay("show");

            });
        }
        else {
            swal("Account Not Reactivated!");
        }
    });
}


function passwordReset(userId) {
    urlLink = "sendPasswordReset/" + userId;
    swal({
        title: "Are you sure?",
        text: "Once Sent, an email will be sent to reset password!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            swal("Password Reset Email Sent!", {
                icon: "success",
            }).then(function () {
                window.location = urlLink;
                $.LoadingOverlay("show");
            });
        }
        else {
            swal("Password Not Reset!");
        }
    });
}

$(window).load(function () {
    $('#loader').delay(70).fadeOut();
    $('#accountCard').delay(450).fadeIn();
});


//hides or shows the deactive accounts
function toggleDeactive() {
    $("#example").toggle();
    $("#example_wrapper").toggle();
    $("#deactivesTable").toggle();
    $("#deactivesTable_wrapper").toggle();
    if($('#example').css('display') == 'none'){
        $("#toggleHidden").html('Hide Deactivated Accounts');
    }else{
        $("#toggleHidden").html('Show Deactivated Accounts');
    }

}

$('input[name=newPassword]').focus(function () {
    $('#pswd_info').show();
    //$('#pswd_info').show();
});

function check_pass() {
    var pswd = document.getElementById('newPassword').value;
    document.getElementById("edit_user_submit").disabled = false;

    if (pswd.length < 10 && pswd.length < 33) {
        $('#length').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    } else {
        $('#length').removeClass('invalid').addClass('valid');
    }
    //validate capital letter
    if (pswd.match(/[A-Z]/)) {
        $('#letter_upper').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_upper').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    //validate lowercase letter
    if (pswd.match(/[a-z]/)) {
        $('#letter_lower').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_lower').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    //validate number
    if (pswd.match(/\d/)) {
        $('#number').removeClass('invalid').addClass('valid');
    } else {
        $('#number').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    //validate special character
    if (pswd.match(/^(?=.*?[?!@$%^&*-])/)  && !/\s/.test(pswd)) {
        $('#special').removeClass('invalid').addClass('valid');
    } else {
        $('#special').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    if(pswd == "")
        document.getElementById("edit_user_submit").disabled = false;

    if (document.getElementById('newPassword').value ==
        document.getElementById('c_password').value) {
        document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Matching';
    } else {
        document.getElementById('edit_user_submit').disabled = true;
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Not Same';
    }
}

function showPassword() {
    var x = document.getElementById("newPassword");
    var y = document.getElementById("c_password");
    if (x.type === "password") {
        x.type = "text";
        y.type = "text";
    } else {
        x.type = "password";
        y.type = "password";
    }
}
