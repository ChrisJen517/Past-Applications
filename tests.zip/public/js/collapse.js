
$(function() {
    "use strict";
     
    $(".toggle-menu").on("click", function(e) {
        e.preventDefault();
        $("#wrapper").toggleClass("toggled");
        $("#wrapper").toggleClass("toggled-icons");
        
        var icon = $("#wrapper").find("#sidebar-wrapper-icons .sidebar-menu .active .sidebar-submenu");
        
        icon.slideUp(0, function(){
            icon.removeClass('menu-open');
        });
        icon.parent("li").removeClass('active');

        var interv = window.setInterval(function(){
            $('#main-stuff').width($('#info-cards').width());
            console.log(50);
            clearInterval(interv);
        }, 500);
    });
    
});	   
