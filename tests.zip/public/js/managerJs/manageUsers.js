$(document).ready(function () {
    //Default data table
    $('#default-datatable').DataTable();

    var table = $('#example').DataTable({
        lengthChange: false,
        autoWidth: false,
        "initComplete": function (settings, json) {
            $('#loader').delay(25).fadeOut();
            $('#accountCard').delay(450).fadeIn();
        },
    });

    var table2 = $('#deactivesTable').DataTable({
        lengthChange: false,
        autoWidth: false
    });

    table.buttons().container()
        .appendTo('#example_wrapper .col-md-6:eq(0)');

    table2.buttons().container()
        .appendTo('#deactivesTable_wrapper .col-md-6:eq(0)');

    $("#deactivesTable_wrapper").css('display', 'none');
});


//hides or shows the deactive accounts
function toggleDeactive() {
    $("#example").toggle();
    $("#example_wrapper").toggle();
    $("#deactivesTable").toggle();
    $("#deactivesTable_wrapper").toggle();
    if($('#example').css('display') == 'none'){
        $("#toggleHidden").html('Hide Deactivated Accounts');
    }else{
        $("#toggleHidden").html('Show Deactivated Accounts');
    }

}

//initialize multi-select in edit user form
$(document).ready(function () {
    $('.multiple-select-access').select2({
        placeholder: 'Please Select Access Levels'
    });
});

$('input[name=newPassword]').focus(function () {
    $('#pswd_info').show();
});

$('input[name=newPassword]').focusout(function(){
    if(document.getElementById("newPassword").value == ""){
        $('#pswd_info').hide();
    }
});

$(".block").click(function () {
    $.LoadingOverlay("show");
})

$('#myModalAddAgent').on('show.bs.modal', function (e) {
    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget;//this holds the element who called the modal
});

//function for getting Access level IDs and submitting edit user form
function submitEdit() {
    $.LoadingOverlay('hide');

    var titles = [];

    if ($('.select2-selection__choice').length) {
        $.each($('.select2-selection__choice'), function () {
            var title = $(this).prop('title');
            var shortcode = title.slice(title.indexOf(',') + 1);
            shortcode = shortcode.trim();
            titles.push(shortcode);
        })

        $.ajax({
            url: '/getAccessIds',
            data: { titles: titles },
            type: "GET",
            beforeSend: function () {
                $("#edit_user_form").LoadingOverlay("show");
            },
            success: function (data) {
                var items = JSON.parse(data);
                $("#access_levels").val(items);
                $("#edit_user_form").submit();
            }
        })
    } else {
        $("#access_levels").val('');
        $("#edit_user_form").LoadingOverlay("show");
        $("#edit_user_form").submit();
    }
}

$('#myModalMod').on('show.bs.modal', function (e) {

    $('#pswd_info').hide();
    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget;//this holds the element who called the modal
    //we get details from attributes
    var idName = $(opener).attr('id-name');
    var first_name = $(opener).attr('d-first_name');
    var last_name = $(opener).attr('d-last_name');
    var email = $(opener).attr('d-email');
    var access = $(opener).attr('d-access');
    access = access.split(',');

    $('#edit_user_form').find('[name="idName"]').val(idName);
    $('#edit_user_form').find('[name="first_name"]').val(first_name);
    $('#edit_user_form').find('[name="last_name"]').val(last_name);
    $('#edit_user_form').find('[name="email"]').val(email);

    $('#multiple-select-access').val(access).trigger('change');
});

function confirmDelete(userId) {
    urlLink = "/managerDeleteAgent/" + userId;
    swal({
        title: "Are you sure?",
        text: "This user will not be able to use the application until reactivated!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            swal("Account Deactivated!", {
                icon: "success",
            }).then(function () {
                window.location = urlLink;
                $.LoadingOverlay("show");
            });
        }
        else {
            swal("Account Not Deactivated!");
        }
    });
}

function confirmReactivate(userId) {
    urlLink = "/managerReactivateAgent/" + userId;
    swal({
        title: "Are you sure?",
        text: "Would you like to reactivate this account?",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willReactivate) => {
        if (willReactivate) {
            swal("Account Reactivated!", {
                icon: "success",
            }).then(function () {
                window.location = urlLink;
                $.LoadingOverlay("show");
            });
        }
        else {
            swal("Account Not Reactivated!");
        }
    });
}

function passwordReset(userId) {
    urlLink = "/managerSendPasswordReset/" + userId;
    swal({
        title: "Are you sure?",
        text: "Once Sent, an email will be sent to reset password!",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    }).then((willDelete) => {
        if (willDelete) {
            swal("Password Reset Email Sent!", {
                icon: "success",
            }).then(function () {
                window.location = urlLink;
                $.LoadingOverlay("show");

            });
        }
        else {
            swal("Password Not Reset!");
        }
    });
}

    function check_pass() {
        var pswd = document.getElementById('newPassword').value;
        document.getElementById("edit_user_submit").disabled = false;

        if (pswd.length < 10 && pswd.length < 33) {
            $('#length').removeClass('valid').addClass('invalid');
            document.getElementById("edit_user_submit").disabled = true;
        } else {
            $('#length').removeClass('invalid').addClass('valid');
        }
        //validate capital letter
        if (pswd.match(/[A-Z]/)) {
            $('#letter_upper').removeClass('invalid').addClass('valid');
        } else {
            $('#letter_upper').removeClass('valid').addClass('invalid');
            document.getElementById("edit_user_submit").disabled = true;
        }

        //validate lowercase letter
        if (pswd.match(/[a-z]/)) {
            $('#letter_lower').removeClass('invalid').addClass('valid');
        } else {
            $('#letter_lower').removeClass('valid').addClass('invalid');
            document.getElementById("edit_user_submit").disabled = true;
        }

        //validate number
        if (pswd.match(/\d/)) {
            $('#number').removeClass('invalid').addClass('valid');
        } else {
            $('#number').removeClass('valid').addClass('invalid');
            document.getElementById("edit_user_submit").disabled = true;
        }

        //validate special character
        if (pswd.match(/^(?=.*?[?!@$%^&*-])/)  && !/\s/.test(pswd)) {
            $('#special').removeClass('invalid').addClass('valid');
        } else {
            $('#special').removeClass('valid').addClass('invalid');
            document.getElementById("edit_user_submit").disabled = true;
        }

        if(pswd == "")
            document.getElementById("edit_user_submit").disabled = false;

        if (document.getElementById('newPassword').value ==
            document.getElementById('c_password').value) {
            document.getElementById('message').style.color = 'green';
            document.getElementById('message').innerHTML = 'Matching';
        } else {
            document.getElementById('edit_user_submit').disabled = true;
            document.getElementById('message').style.color = 'red';
            document.getElementById('message').innerHTML = 'Not Same';
        }
    }

    function showPassword() {
        var x = document.getElementById("newPassword");
        var y = document.getElementById("c_password");
        if (x.type === "password") {
            x.type = "text";
            y.type = "text";
        } else {
            x.type = "password";
            y.type = "password";
        }
    }
