var warningTimeout = 840000;
var timeoutNow = 60000;
var warningTimerID, timeoutTimerID;
var date = new Date();
var time = date.getTime();
time = time.toString().substring(0, 10);

function startTimer() {
    // window.setTimeout returns an Id that can be used to start and stop a timer
    warningTimerID = window.setTimeout(warningInactive, warningTimeout);
    date = new Date();
    time = date.getTime();
    // time = time.substring(0, 11);
    time = time.toString().substring(0, 10);

}

function warningInactive() {
    window.clearTimeout(warningTimerID);
    timeoutTimerID = window.setTimeout(IdleTimeout, timeoutNow);

    swal({
        title: "Your session is about to expire!",
        text: "Click ok or remain active on this page to avoid being logged out",
        icon: "warning",
        buttons: true,
        dangerMode: true,
    })
}

function resetTimer() {
    window.clearTimeout(timeoutTimerID);
    window.clearTimeout(warningTimerID);
    startTimer();
}

// Logout the user.
function IdleTimeout() {

    document.getElementById('logout-form').submit();

}

function setupTimers() {
    document.addEventListener("mousedown", resetTimer, false);
    document.addEventListener("keypress", resetTimer, false);
    document.addEventListener("onscroll", resetTimer, false);

    startTimer();
}


$(document).ready(function () {
    setupTimers();
});

$(document).ready(function () {
    setTimeout(updateSession, 60000);
});



function updateSession() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $.ajax({
        url: '/updateSession',
        method: "POST",
        data: {time:time},
        success: function (data) {
            setTimeout(updateSession, 60000);
        },

    })
}