$("#loader")
    .delay(25)
    .fadeOut();
$(".accountSourceCard")
    .delay(450)
    .fadeIn();

// Set all of the fields when editing an account source based on the element's data
$("#modalEditAccountSource").on("show.bs.modal", function(e) {
    var opener = e.relatedTarget;

    var name = $(opener).attr("data-name");
    var description = $(opener).attr("data-description");
    var accountSourceId = $(opener).attr("data-id");
    var shortcode = $(opener).attr("data-shortcode");
    var corporation_id = $(opener).attr("data-corporation");

    $("#name").val(name);
    $("#description").val(description);
    $("#account_source_id").val(accountSourceId);
    $("#shortcode").val(shortcode);
    $("#corporation_id").val(corporation_id);
});

/* ? Not sure why this is necessary as corp_id input field already exists,
but its setting the corporation_id based on the source's data */
$("#modalAddAccountSource").on("show.bs.modal", function(e) {
    var opener = e.relatedTarget;
    var corporation_id = $(opener).attr("data-corporation");
    $("#add_corporation_id").val(corporation_id);
});

$(document).ready(function() {
    // Initialize a boolean variable to use to block the user from leaving the page while saving
    var saving = false;

    // Initialize the datatable
    var table = $("#accountSourceTable").DataTable({
        rowReorder: true,
        lengthChange: false,
        searching: false,
        columnDefs: [
            {
                targets: "_all",
                orderable: false
            }
        ],
        paging: false
    });

    // Set up ajax so that it correctly passes in the csrf token from laravel
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
        }
    });

    // Listen to the jquery datatables row-reordered event (post update)
    table.on("row-reordered", function(e, details) {
        // If no changes were made, do not save the priorities
        if (details.length == 0) return;

        // Set saving to true so that the user can not redirect off of the page
        saving = true;
        table.rowReorder.disable();
        $("#save-message").text(
            "Drag and Drop Sources to Change Their Priority (saving...)"
        );

        // Create an array to store the name of the sources and their current priorities
        var priorityData = table
            .rows({ order: "applied" })
            .nodes()
            .data();
        shortcodes = [];
        orders = [];
        for (i = 0; i < priorityData.length; i++) {
            shortcodes.push(priorityData[i][3]);
            orders.push(priorityData[i][0]);
        }

        // Make an ajax post request to the webserver to save the priority order of all of the sources
        $.post(
            "/admin/updatePriority",
            {
                shortcodes: shortcodes,
                orders: orders,
                corporation_id: $("#corp_id").val()
            },
            () => {
                saving = false;
                table.rowReorder.enable();
                $("#save-message").text(
                    "Drag and Drop Sources to Change Their Priority"
                );
            }
        );
    });

    window.onbeforeunload = () => {
        if (saving)
            return "Are you sure you want to redirect off this page? The sources are saving.";
    };
});

// Prevent commas from making it into the shortcode
$(".shortcode-input").keydown(function(e) {
    if (e.keyCode == 188) e.preventDefault();
});

// Modal to confirm deleting an account source
function confirmDelete(accountSourceId) {
    urlLink = "/admin/deleteAccountSource/" + accountSourceId;
    swal({
        title: "Are you sure?",
        text: "Once deleted, you will not be able to recover this source!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            window.location = urlLink;
            $.LoadingOverlay("show");
        } else {
            swal("Source Not Deleted!");
        }
    });
}
