

$(document).ready(function () {
    //Default data table
    $('#default-datatable').DataTable();

    var table = $('#companiesTable').DataTable({
        lengthChange: false,
    });
    $('#companiesTable').show();

    table.buttons().container()
        .appendTo('#companiesTable_wrapper .col-md-6:eq(0)');

});

//load button blocked or unblocked based on corporation->active status
$(document).ready(function () {

    //    $('.blockButton').each(function(){
    //        if($(this).data('active') == 0){
    //            $(this).toggleClass('hideBlock');
    //            $(this).next('.hideBlock').toggleClass('hideBlock');
    //        }
    //    })

});

//block company via ajax 
$(document).ready(function () {

    $('#companiesTable tbody').on('click', '.blockButton', function () {

        var corpId = $(this).attr('data-blockId');
        var _token = $('input[name="_token"]').val();
        var blockButton = $(this);
        var parent = $(blockButton).parent();


        swal({
            title: "Are you sure you want to block this company?",
            text: "All users in the company will be blocked from their accounts",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {

                    swal("Blocking Company", {
                        icon: "success",
                    }).then(function () {
                        $.ajax({
                            url: $(".blockButton").attr("url"),
                            method: "POST",
                            data: { corpId: corpId, _token: _token },
                            beforeSend: function () {
                                $.LoadingOverlay("show");

                            },
                            success: function (result) {
                                swal({
                                    title: "Company Blocked",
                                    text: "All users are unable to access account",
                                    icon: "success",
                                    buttons: true,
                                })
                            },
                            complete: function () {
                                parent.empty();
                                parent.append('<a data-unblockId="' + corpId + '"class="btn unblockButton btn-success hideBlock btn-sm" style="color:white;" url="/admin/pages/unblockCorporation">Unblock</a>')

                                $.LoadingOverlay("hide", true);

                            }
                        })
                    });
                }
                else {
                    swal("Company not blocked!");
                }
            })

    })
});

//unblock company via ajax
$(document).ready(function () {

    $('#companiesTable tbody').on('click', '.unblockButton', function () {

        var corpId = $(this).attr('data-unblockId');
        var _token = $('input[name="_token"]').val();
        var unblockButton = $(this);
        var parent = $(unblockButton).parent();
        swal({
            title: "Are you sure you want to unblock this company?",
            text: "All users in the company will be unblocked from their accounts",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {

                    swal("Unblocking Company", {
                        icon: "success",
                    }).then(function () {
                        $.ajax({
                            url: $(".unblockButton").attr("url"),
                            method: "POST",
                            data: { corpId: corpId, _token: _token },
                            beforeSend: function () {
                                $.LoadingOverlay("show");

                            },
                            success: function (result) {
                                swal({
                                    title: "Company Unblocked",
                                    text: "All users are now able to access accounts",
                                    icon: "success",
                                    buttons: true,
                                })
                            },
                            complete: function () {
                                parent.empty();
                                parent.append('<a data-blockId="' + corpId + '"class="btn blockButton btn-danger btn-sm" style="color:white;" url="/admin/pages/blockCorporation">block</a>')

                                $.LoadingOverlay("hide", true);

                            }
                        })
                    });
                }
                else {
                    swal("Company not unblocked!");
                }
            })

    })
});