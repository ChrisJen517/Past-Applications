$(document).ready(function() {
    var table = $("#manageAccountsTable").DataTable({
        processing: true,
        serverSide: true,
        initComplete: function(settings, json) {
            $("#loader")
                .delay(25)
                .fadeOut();
            $("#accountCard")
                .delay(450)
                .fadeIn();

            var input = $(".dataTables_filter input").unbind(),
                self = this.api();

            $(".dataTables_filter input").keyup(function(e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13) self.search(input.val()).draw();
            }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                )
                    .text("search")
                    .click(function() {
                        self.search(input.val()).draw();
                    }));
            $(".dataTables_filter").append($searchButton);
        },
        ajax: "getUsersTable/" + 0,
        columns: [
            { data: "name" },
            { data: "email" },
            { data: "role" },
            { data: "corporation" },
            {
                data: "user_id",
                class: "text-center",
                searchable: false,
                sortable: false,
                render: function(user_id, type, row, meta) {
                    if (row.is_deactivated == 0)
                        return (
                            '<button class="btn btn-info btn-sm" '+
                            'd-dir_account_type="' +
                            row.dir_account_type +
                            '"d-first_name="' +
                            row.first_name +
                            '" id-name="' +
                            row.user_id +
                            '" d-last_name="' +
                            row.last_name +
                            '"d-corporation_id="' +
                            row.corporation_id +
                            '" d-access="' +
                            row.has_access +
                            '" d-role="' +
                            row.role +
                            '" d-email="' +
                            row.email +
                            '" d-agent_id="' +
                            row.agent_id +
                            '" d-directory_id="' +
                            row.directory_agent_id +
                            '" d-power_id="' +
                            row.powerlead_id +
                            '" d-role_list="' +
                            row.role_list +
                            '"  data-toggle="modal" data-target="#myModalMod">Edit</button>'
                        );
                    else return "Deactivated";
                }
            },
            {
                data: "user_id",
                class: "text-center",
                searchable: false,
                sortable: false,
                render: function(user_id, type, row, meta) {
                    if (row.is_deactivated == 0) {
                        var blockRoute = "blockAccount/" + row.user_id;
                        var unblockRoute = "unblockAccount/" + row.user_id;
                        if (row.corporation_active == 0) {
                            return '<p style="padding-top:10px; font-weight:500">Company Blocked</p>';
                        } else if (row.active == 1) {
                            return (
                                '<button id="block' +
                                row.user_id +
                                '" class="btn btn-danger btn-sm" onclick="confirmBlock(' +
                                row.user_id +
                                ')">Block</button>'
                            );
                        } else {
                            return (
                                '<button id="unblock' +
                                row.user_id +
                                '" class="btn btn-success btn-sm" onclick="confirmUnblock(' +
                                row.user_id +
                                ')">Unblock</button>'
                            );
                        }
                    } else return "Deactivated";
                }
            },
            {
                data: "user_id",
                class: "text-center",
                searchable: false,
                sortable: false,
                render: function(user_id, type, row, meta) {
                    if (row.is_deactivated == 0)
                        return (
                            '<button id="delete' +
                            row.user_id +
                            '" class="btn btn-danger btn-sm" onclick="confirmDelete(' +
                            row.user_id +
                            ')">Deactivate</button>'
                        );
                    else
                            return (
                                '<button class="btn btn-success btn-sm" d-first_name="' + row.first_name + '"' + ' d-role="' + row.role + '" ' +
                                'd-last_name="' + row.last_name + '" id-name="' + row.user_id + '" d-team="' + row.team_id + '" d-corp_id="' + row.corporation_id + '" ' +
                                'data-toggle="modal" data-target="#myModalReactivate">Reactivate</button>'
                            );
                }
            },
            {
                data: "user_id",
                class: "text-center",
                searchable: false,
                sortable: false,
                render: function(user_id, type, row, meta) {
                    if (row.is_deactivated == 0)
                        return (
                            '<button id="password' +
                            row.user_id +
                            '" class="btn btn-sm btn-warning" onclick="passwordReset(' +
                            row.user_id +
                            ')">Password Reset</button>'
                        );
                    else return "Deactivated";
                }
            }
        ],
        lengthChange: false,
        buttons: [
            { extend: "copy", className: "copyButton btn-info" },
            { extend: "excel", className: "excelButton" },
            { extend: "pdf", className: "pdfButton" },
            { extend: "print", className: "printButton" },
            { extend: "colvis", className: "colvisButton" }
        ]
    });

    table.on("processing.dt", function(e, settings, processing) {
        $("#processingIndicator").css("display", "none");
        if (processing) {
            $("#accountCard")
                .delay(0)
                .fadeOut();
            $("#loader")
                .delay(450)
                .fadeIn();
        } else {
            $("#loader")
                .delay(25)
                .fadeOut();
            $("#accountCard")
                .delay(450)
                .fadeIn();
        }
    });
    table
        .buttons()
        .container()
        .appendTo("#example_wrapper .col-md-6:eq(0)");
});

// --------- Modal to Add New Account
$("#myModalAddAccount").on("show.bs.modal", function(e) {
    // get information to update quickly to modal view as loading begins
    $("#adminAddAccount").trigger("reset");
    $("#role").val("admin").change();
    var opener = e.relatedTarget; //this holds the element who called the modal
});

// ----------- Modal to Update Accounts
$("#myModalMod").on("show.bs.modal", function(e) {
    $("#multiple-select-access option").remove();
    $("#pswd_info").hide();
    var x = document.getElementById("newPassword");
    var y = document.getElementById("c_password");
    x.type = "password";
    y.type = "password";
    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget; //this holds the element who called the modal
    //we get details from attributes
    var idName = $(opener).attr("id-name");
    var first_name = $(opener).attr("d-first_name");
    var dir_account_type = $(opener).attr("d-dir_account_type");
    var last_name = $(opener).attr("d-last_name");
    var email = $(opener).attr("d-email");
    var corporation_id = $(opener).attr("d-corporation_id");
    var role = $(opener).attr("d-role");
    var access = $(opener).attr("d-access");
    var role_list = $(opener).attr("d-role_list");
    var directory_id = $(opener).attr("d-directory_id");
    var power_id = $(opener).attr("d-power_id");
    var agent_id = $(opener).attr("d-agent_id");

    access = access.split(",");
    $("#Update")
        .find('[name="idName"]')
        .val(idName);
    $("#Update")
        .find('[name="first_name"]')
        .val(first_name);
    $("#Update")
        .find('[name="last_name"]')
        .val(last_name);
    $("#Update")
        .find('[name="email"]')
        .val(email);

    $("#directory_account_type_row").hide();
    if (role == "admin") {
        $("#access_levels_div").hide();
    }
    else if(role == "directory_agent"){
        $("#access_levels_div").hide();
        $("#directory_account_type_row").show();
        $("#dir_account_type").val(dir_account_type);
    }
    else {
        $("#access_levels_div").show();
        getAccessList(corporation_id, access);
    }

    if(directory_id != null && directory_id != 'null'){
        $("#directory_edit").val(directory_id);
        $("#directory_edit").prop( "disabled", true );
    }
    else
        $("#directory_edit").prop( "disabled", false );
    if(power_id != null && power_id != 'null'){
        $("#power_edit").val(power_id);
        $("#power_edit").prop( "disabled", true );
    }
    else
        $("#power_edit").prop( "disabled", false );
    if(agent_id != null && agent_id != 'null'){
        $("#agent_edit").val(agent_id);
        $("#agent_edit").prop( "disabled", true );
    }
    else
        $("#agent_edit").prop( "disabled", false );

    if(role_list != 'null'){
        role_list = role_list.split(",");
        $("#role_list_edit").val(role_list).trigger("change");

        if(jQuery.inArray('agent', role_list) != -1)
            $("#agent_edit_id").prop( "hidden", false );
        if(jQuery.inArray('powerlead', role_list) != -1)
            $("#power_edit_id").prop( "hidden", false );
        if(jQuery.inArray("directory_agent", role_list) != -1)
            $("#directory_edit_id").prop( "hidden", false );
    }
});


var neededRoleList = ['agent', 'powerlead', 'directory_agent'];
var neededFieldList = ['agent','power','directory'];

$("#role_list_edit").on("change", function() {
    role_list = $("#role_list_edit").val();

    for(i = 0; i < neededRoleList.length; i++){
        field = '#'+neededFieldList[i]+'_edit_id';
        if((jQuery.inArray(neededRoleList[i], role_list) != -1))
            $(field).prop( "hidden", false );
        else
            $(field).prop( "hidden", true );
    }
});

$("#role_list_add").on("change", function() {
    role_list = $("#role_list_add").val();
    selected_role = $("#Update").find('[name="role"]').val();

    for(i = 0; i < neededRoleList.length; i++){
        field = '#'+neededFieldList[i]+'_create_id';
        if((jQuery.inArray(neededRoleList[i], role_list) != -1) || (selected_role == neededRoleList[i]))
            $(field).prop( "hidden", false );
        else
            $(field).prop( "hidden", true );
    }
});

//ajax call to get list of access levels for user's corporation and append them to dropdown
function getAccessList(corporation_id, access) {
    $.ajax({
        url: "/admin/getAccessLevels",
        data: { corporation_id: corporation_id },
        datatype: "json",
        type: "GET",
        beforeSend: function() {
            $("#Update").LoadingOverlay("show");
        },
        success: function(data) {
            var cases = JSON.parse(data);
            // console.log(cases);
            $.each(cases, function(key, value) {
                $("#multiple-select-access").append(
                    "<option value=" +
                        value["id"] +
                        ">" +
                        value["name"] +
                        ", " +
                        value["shortcode"] +
                        "</option>"
                );
            });

            $("#multiple-select-access")
                .val(access)
                .trigger("change");
        },
        complete: function() {
            $("#Update").LoadingOverlay("hide");
        }
    });
}

// ---- Confirm Delete Popup
function confirmDelete(userId) {
    urlLink = "/admin/pages/deleteAccount/" + userId;
    buttonId = "#delete" + userId;
    var parent = $(buttonId).parent();
    var parentOf = parent.parent();

    swal({
        title: "Are you sure?",
        text: "This user will not be able to use the application until reactivated!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                $.get(
                    urlLink, // url
                    function(data) {
                        if(data[1] == "error") {
                            $.LoadingOverlay("hide");
                            swal(data[0], {
                                icon: "error"
                            });
                        } else {
                            parentOf.empty();
                            // if no managers found in team, removing select and adding text
                            $.LoadingOverlay("hide");
                            swal(data[0], {
                                icon: data[1]
                            });
                            var table = $("#manageAccountsTable").DataTable();
                            table.ajax.reload();
                        }
                    }
                );
            });
        } else {
            swal("Account Not Deactivated!");
        }
    });
}


// ---- Confirm Reactivate
function confirmReactivate(userId, team_id) {
    urlLink = "/admin/pages/reactivateAccount/" + userId + "/" + team_id;
    buttonId = "#reactivate" + userId;
    var parent = $(buttonId).parent();
    var parentOf = parent.parent();

    $('#myModalReactivate').modal('hide');

    swal({
        title: "Are you sure?",
        text: "Would you like to reactivate this account?",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                $.get(
                    urlLink, // url
                    function(data) {
                        if(data[1] == "error") {
                            $.LoadingOverlay("hide");
                            swal(data[0], {
                                icon: "error"
                            });
                        } else {
                            parentOf.empty();
                            // if no managers found in team, removing select and adding text
                            $.LoadingOverlay("hide");
                            swal(data[0], {
                                icon: data[1]
                            });
                            var table = $("#manageAccountsTable").DataTable();
                            table.ajax.reload();
                        }
                    }
                );
            });
        } else {
            swal("Account Not Reactivated!");
        }
    });
}

function confirmBlock(userId) {
    urlLink = "/admin/pages/blockAccount/" + userId;
    buttonId = "#block" + userId;
    var parent = $(buttonId).parent();
    swal({
        title: "Are you sure?",
        text: "Once blocked, you will be able to unblock account!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                $.get(
                    urlLink, // url
                    function(data) {
                        if(data[1] == "error") {
                            $.LoadingOverlay("hide");
                            swal(data[0], {
                                icon: "error"
                            });
                        }
                        else {
                            parent.empty();
                            parent.append(
                                '<button id="unblock' +
                                    userId +
                                    '" class="btn btn-success btn-sm" onclick="confirmUnblock(' +
                                    userId +
                                    ')">Unblock</button>'
                            );
                            // if no managers found in team, removing select and adding text
                            $.LoadingOverlay("hide");
                            swal(data + " Account Was Blocked!", {
                                icon: "success"
                            });
                        }
                    }
                );
            });
        } else {
            swal("Account was not blocked!");
        }
    });
}

function confirmUnblock(userId) {
    urlLink = "/admin/pages/unblockAccount/" + userId;
    buttonId = "#unblock" + userId;
    var parent = $(buttonId).parent();
    swal({
        title: "Are you sure?",
        text: "Once unblocked, you will be able to reblock account!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                $.get(
                    urlLink, // url
                    function(data) {
                        parent.empty();
                        parent.append(
                            '<button id="block' +
                                userId +
                                '" class="btn btn-danger btn-sm" onclick="confirmBlock(' +
                                userId +
                                ')">Block</button>'
                        );
                        // if no managers found in team, removing select and adding text
                        $.LoadingOverlay("hide");
                        swal(data + " Account Was Unblocked!", {
                            icon: "success"
                        });
                    }
                );
            });
        } else {
            swal("Account Was Not Unblocked!");
        }
    });
}

// Confirm Password Reset PopUp
function passwordReset(userId) {
    urlLink = "/admin/pages/sendPasswordReset/" + userId;
    swal({
        title: "Are you sure?",
        text: "Once Sent, an email will be sent to reset password!",
        icon: "warning",
        buttons: true,
        dangerMode: true
    }).then(willDelete => {
        if (willDelete) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                $.get(
                    urlLink, // url
                    function(data) {
                        // if no managers found in team, removing select and adding text
                        $.LoadingOverlay("hide");
                        swal(data + " Was Sent A Password Reset Email!", {
                            icon: "success"
                        });
                    }
                );
            });
        } else {
            swal("Password Not Reset!");
        }
    });
}

// -------- Add New Account when Role Change function
$("#role").on("change", function() {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    $('#agent_id_add').attr('hidden', true);
    $('#next_id_add').attr('hidden', true);
    $("#create_directory_account_type_row").hide();
    // Checks if role changed to is Agent
    if (valueSelected == "agent") {
        // Turning on all ui Elements
        $("#myModalAddBody").LoadingOverlay("show");
        $("#corporationSelect").show();
        $("#teamSelect").show();
        $("#addAccountButton").prop("disabled", false);
        $('#agent_id_add').attr('hidden', false);

        var corporationSelectValue = $("#corporation").val();
        $(function() {
            "use strict";
            // Ajax call to grab team names
            $.get(
                "/getTeamNames/" + corporationSelectValue, // url
                function(data) {
                    // Removing old team names tied to other corporations
                    $("#team").empty();
                    $("#team").show();
                    $("#noTeam").remove();
                    // If no teams in corporation added, removing select and adding text
                    if (jQuery.isEmptyObject(data[0])) {
                        $("#team").hide();
                        $("#teamDiv").append(
                            '<span id="noTeam"> No Teams Found </span>'
                        );
                        $("#addAccountButton").prop("disabled", true);
                    } else {
                        // Teams are found looping through teams and building options
                        $.each(data, function(i, team) {
                            $("#team").append(
                                '<option value="' +
                                    data[i].team_id +
                                    '">' +
                                    data[i].name +
                                    "</option>"
                            );
                        });
                    }

                    setTimeout(function() {
                        $("#myModalAddBody").LoadingOverlay("hide");
                    }, 1000);
                }
            );
        });
    } else if (valueSelected == "manager") {
        // Checks if role changed to is Manager
        // Turning on all ui Elements
        $("#myModalAddBody").LoadingOverlay("show");
        $("#addAccountButton").prop("disabled", false);
        var corporationSelectValue = $("#corporation").val();
        $(function() {
            "use strict";
            // Ajax call to grab team names
            $.get(
                "/getTeamNames/" + corporationSelectValue, // url
                function(data) {
                    // Removing old team names tied to other corporations
                    $("#team").empty();
                    $("#team").show();
                    $("#noTeam").remove();
                    // If no teams in corporation added, removing select and adding text
                    if (jQuery.isEmptyObject(data[0])) {
                        $("#team").hide();
                        $("#teamDiv").append(
                            '<span id="noTeam"> No Teams Found </span>'
                        );
                        $("#addAccountButton").prop("disabled", true);
                    } else {
                        // Teams are found looping through teams and building options
                        $.each(data, function(i, team) {
                            $("#team").append(
                                '<option value="' +
                                    data[i].team_id +
                                    '">' +
                                    data[i].name +
                                    "</option>"
                            );
                        });
                    }
                }
            );
        });
        // Showing Proper UI connected to role manager
        $("#corporationSelect").show();
        $("#teamSelect").show();
        $("#managerSelect").hide();

        $("#myModalAddBody").LoadingOverlay("hide");
    } else if (valueSelected == "corporate_admin") {
        // Checks if role changed to is Manager
        // Showing proper UI Elements
        $("#addAccountButton").prop("disabled", false);
        $("#corporationSelect").show();
        $("#teamSelect").hide();
        $("#managerSelect").hide();
    } else if (valueSelected == "directory_agent" || valueSelected == "powerlead") {
        $('#next_id_add').attr('hidden', false);
        $('#agent_id_add').attr('hidden', false);
        $("#addAccountButton").prop("disabled", false);
        $("#corporationSelect").hide();
        $("#teamSelect").hide();
        $("#managerSelect").hide();
        $("#noManager").remove();
        if (valueSelected == "directory_agent"){
            $("#create_directory_account_type_row").show();
            $('#next_id_direct').attr('hidden', false);
            $('#next_id_Power').attr('hidden', true);
        }
        else{
            $('#next_id_direct').attr('hidden', true);
            $('#next_id_Power').attr('hidden', false);
        }
    } else {
        // Role is Admin, Showing proper UI elements
        $("#addAccountButton").prop("disabled", false);
        $("#corporationSelect").hide();
        $("#teamSelect").hide();
        $("#managerSelect").hide();
        $("#noManager").remove();
    }
});

// On Corporation Change
$("#corporation").on("change", function() {
    var optionSelected = $("option:selected", this);
    var valueSelected = this.value;
    var role = $("#role").val();
    // Check if not corporate_admin
    if (role != "corporate_admin") {
        $("#myModalAddBody").LoadingOverlay("show");
        $(function() {
            "use strict";
            // Grabbing Team Names
            $.get(
                "/getTeamNames/" + valueSelected, // url
                function(data) {
                    // Reseting UI elements
                    $("#addAccountButton").prop("disabled", false);
                    $("#team").empty();
                    $("#manager").empty();
                    $("#team").show();
                    $("#manager").show();
                    $("#noTeam").remove();
                    $("#noManager").remove();
                    if (jQuery.isEmptyObject(data[0])) {
                        // No Teams found, removing Select and adding Text
                        $("#team").hide();
                        $("#teamDiv").append(
                            '<span id="noTeam"> No Teams Found </span>'
                        );
                        $("#manager").hide();
                        $("#managerDiv").append(
                            '<span id="noManager"> No Managers Found </span>'
                        );
                        $("#addAccountButton").prop("disabled", true);
                    } else {
                        // Teams Found and looping through teams to build select option
                        $.each(data, function(i, team) {
                            $("#team").append(
                                '<option value="' +
                                    data[i].team_id +
                                    '">' +
                                    data[i].name +
                                    "</option>"
                            );
                        });
                    }
                }
            );
        });
        setTimeout(function() {
            $("#myModalAddBody").LoadingOverlay("hide");
        }, 1500);
    }
});

//hides or shows the deactive accounts
function toggleDeactive() {
    var hide = 0;

    //if they are shown, hides the elements
    if (document.getElementById("toggleHidden").value == 1) {
        document.getElementById("toggleHidden").innerHTML =
            "Show Deactivated Accounts";
        document.getElementById("toggleHidden").value = 0;
    }
    //if they are hidden, shows the elements
    else {
        document.getElementById("toggleHidden").innerHTML =
            "Hide Deactived Accounts";
        document.getElementById("toggleHidden").value = 1;

        hide = 1;
    }

    //reloads the table
    var table = $("#manageAccountsTable").DataTable();
    table.ajax.url("getUsersTable/" + hide).load();
}

var selected_team;
var reactivate_user;

$('#myModalReactivate').on('show.bs.modal', function (e) {

    $("#myModalReactivateBody").LoadingOverlay("show");
    // get information to update quickly to modal view as loading begins
    var opener = e.relatedTarget;//this holds the element who called the modal
    //we get details from attributes
    var idName = $(opener).attr('id-name');
    var first_name = $(opener).attr('d-first_name');
    var last_name = $(opener).attr('d-last_name');
    var role = $(opener).attr('d-role');
    var team_id = $(opener).attr('d-team');
    var corporationSelectValue= $(opener).attr('d-corp_id');

    reactivate_user = idName;


    if(role == "agent" || role == "manager") {
        $("#team_reactivate_div").show();
    } else {
        $("#team_reactivate_div").hide();
        team_id = null;
    }
    $(function() {
            "use strict";
            // Ajax call to grab team names
            $.get(
                "/getTeamNames/" + corporationSelectValue, // url
                function(data) {
                    // Removing old team names tied to other corporations
                    $("#team_reactivate").empty();
                    // If no teams in corporation added, removing select and adding text
                    if (jQuery.isEmptyObject(data[0])) {
                        $('#reactivate_user_submit').prop('disabled', true);
                        $('#team_warning').removeAttr('hidden');
                        $("#team_reactivate").prop('hidden', true);
                    } else {
                        $('#reactivate_user_submit').removeAttr('disabled');
                        $('#team_warning').prop('hidden', true);
                        $('#team_reactivate').removeAttr('hidden');
                        // Teams are found looping through teams and building options
                        $.each(data, function(i, team) {
                            $("#team_reactivate").append(
                                '<option id="team_' + data[i].team_id + '" deactivated="' + data[i].is_deactivated + '" value="' +
                                    data[i].team_id +
                                    '">' +
                                    data[i].name +
                                    "</option>"
                            );
                                $('#team_'+team_id).attr('selected', 'selected');
                                selected_team = $('#team_'+team_id);

                        });
                    }
                    setTimeout(function() {
                        $("#myModalReactivateBody").LoadingOverlay("hide");
                    }, 1000);
                }
            );
        });

    $('#reactivate_user_form').find('[name="idName"]').val(idName);
    $('#reactivate_user_form').find('[name="first_name"]').val(first_name);
    $('#reactivate_user_form').find('[name="last_name"]').val(last_name);
    $('#reactivate_user_submit').attr('onclick', 'confirmReactivate(' + idName + ', ' + team_id + ')');
});

$('#team_reactivate').on('change', function(){
    var team_id = $(this).val();
    $('#reactivate_user_submit').attr('onclick', 'confirmReactivate(' + reactivate_user + ', ' + team_id + ')');

    if(selected_team.attr("selected") == "selected")
        selected_team.removeAttr('selected');

});
