$().ready(function () {
    $("#user_information_form").submit(function () {
        $('#myModalAddBody').LoadingOverlay("show");
    });
    $("#personal-info").validate();
    
    // validate signup form on keyup and submit
    $("#user_information_form").validate({
        rules: {
            first_name:"required",
            last_name:"required",
            name: "required",
            teamName: "required",
            newPassword: {
                passwordCorrectRules: function (element) {
                    return $("#newPassword").val() != "";
                }
            },
            email: {
                required: true,
                email: true,
            },
            capcode: {
                required: true,
            },
            address: {
                required: true,
                addressCorrectRules: function (element) {
                    return $("#address").val() != "";
                }
            },
            zip: {
                required: true,
            },
            city: {
                required: true,
            },
        },
        messages: {
            first_name: "Please enter your first name",
            last_name: "Please enter your last name",
            name: "Please enter your name",
            teamName: "Please enter the team name",
            newPassword: {
                required: "Please provide a password",
                minlength: "Your password must be at least 5 characters long",
            },
            email: {
                required: "Please enter a valid email",
                email: "Please enter a valid email address",
                remote: "This email is already in use"
            },
            capcode: {
                required: "Please enter a capcode",
            },
            host: "Please enter a host",
            port: "Please enter a port",
            address: "Please enter an address",
            zip: "Please enter a Zipcode",
            city: "Please Enter a city",

        },
        invalidHandler: function (event, validator) {
            // 'this' refers to the form
            var errors = validator.numberOfInvalids();
            if (errors) {
                $('#myModalAddBody').LoadingOverlay("hide");
            } else {
                $('#myModalAddBody').LoadingOverlay("show");

            }
        }
    });


    jQuery.validator.addMethod("addressCorrectRules", function (value, element) {
        return this.optional(element) || /(\d{1,}) [a-zA-Z0-9\s]+(\.)?/.test(value);
    }, "Please enter a valid address.");


    jQuery.validator.addMethod("passwordCorrectRules", function (value, element) {
        return this.optional(element) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,32}$/.test(value);
    }, "Must follow password rules");


    $('input[name=newPassword]').focus(function () {
        $('#pswd_info').show();
    });

    $('input[name=newPassword]').focusout(function(){
        if(document.getElementById("newPassword").value == ""){
            $('#pswd_info').hide();
        }
    });


});

function showPassword() {
    var x = document.getElementById("newPassword");
    var y = document.getElementById("c_password");
    if (x.type === "password") {
        x.type = "text";
        y.type = "text";
    } else {
        x.type = "password";
        y.type = "password";
    }
}

function check_pass() {
    var pswd = document.getElementById('newPassword').value;
    document.getElementById("edit_user_submit").disabled = false;

    if (pswd.length < 10 && pswd.length < 33) {
        $('#length').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    } else {
        $('#length').removeClass('invalid').addClass('valid');
    }
    //validate capital letter
    if (pswd.match(/[A-Z]/)) {
        $('#letter_upper').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_upper').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    //validate lowercase letter
    if (pswd.match(/[a-z]/)) {
        $('#letter_lower').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_lower').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    //validate number
    if (pswd.match(/\d/)) {
        $('#number').removeClass('invalid').addClass('valid');
    } else {
        $('#number').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    //validate special character
    if (pswd.match(/^(?=.*?[?!@$%^&*-])/)  && !/\s/.test(pswd)) {
        $('#special').removeClass('invalid').addClass('valid');
    } else {
        $('#special').removeClass('valid').addClass('invalid');
        document.getElementById("edit_user_submit").disabled = true;
    }

    if(pswd == "")
        document.getElementById("edit_user_submit").disabled = false;

    if (document.getElementById('newPassword').value ==
        document.getElementById('c_password').value) {
        document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Matching';
    } else {
        document.getElementById('edit_user_submit').disabled = true;
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Not Same';
    }
}

//check file size and type for avatar upload
$(document).ready(function () {
    $('#avatar').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            if (fileSize > 51200) //check file size
            {
                swal({
                    title: "File size too large!",
                    text: "Image size cannot exceed 50kb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }

            else if (ext != '.jpg' && ext != '.jpeg' && ext != '.png') //check file extension type
            {

                swal({
                    title: "Wrong file type",
                    text: "Must be .jpg, .jpeg, or .png",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }
        }
    })
});


//validate csv file for account uploads
$(document).ready(function () {
    $('#accountUpload').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;

            if (ext != '.csv') //check file extension type
            {
                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "File size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
        }
    })

    $('#uploadUnactive').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;

            if (ext != '.csv') //check file extension type
            {
                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "File size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
        }
    })

    $('#uploadAgents').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;

            if (ext != '.csv') //check file extension type
            {
                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "File size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
        }
    })

    $('#uploadUpdate').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;

            if (ext != '.csv') //check file extension type
            {
                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "File size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
        }
    });
});

//adds on click event for the four account upload buttons
$("#submitAccountUpload").click(function(e){
    testForNoFile("#accountUpload", e);
})
$("#submitInactiveUpload").click(function(e){
    testForNoFile("#uploadUnactive", e);
})
$("#submitUserUpload").click(function(e){
    testForNoFile("#uploadAgents", e);
});
$("#submitMassUpdateUpload").click(function(e){
    testForNoFile("#uploadUpdate", e);
});

//adds in a check to see if they are filled
function testForNoFile(filebutton, e){
    if (($(filebutton).val() == "")) {
        e.preventDefault();
        swal({
            title: "Please select a file for uploading!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
    }
}

//validate csv file for test uploads
$(document).ready(function () {
    $('#testMappingFile').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;


            if (ext != '.csv') //check file extension type
            {

                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }

            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "Image size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }

        }
       
    })
});

//confirm file exists for test upload
$("#testMappingSubmit").click(function(e){
    
    if($("#testMappingFile").val() == ""){
        e.preventDefault();
        swal({
            title: "Please select a file for uploading!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
    }
    else{
        $.LoadingOverlay("show");
    }
})