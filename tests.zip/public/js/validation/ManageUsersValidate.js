$().ready(function () {

    $("#add_user_form").validate({

        rules: {
            first_name: "required",
            last_name: "required",
            email: "required",


        },
        messages: {
            first_name: "Please enter a first name",
            last_name: "Please enter a last name",
            email: "Please enter an email",

        },

    });

    

});

$().ready(function () {

    $("#edit_user_form").validate({

        rules: {
            first_name: "required",
            last_name: "required",


        },
        messages: {
            first_name: "Please enter a first name",
            last_name: "Please enter a last name",

        },

    });

    

});


//only show overlay if form is valid
$(document).ready(function (e) {
    $("#add_user_submit").click(function () {
        if ($("#add_user_form").valid()) {
            $.LoadingOverlay("show");
        }
    })
})

$(document).ready(function (e) {
    $("#edit_user_submit").click(function () {
        if ($("#edit_user_form").valid()) {
            $.LoadingOverlay("show");
        }
    })
})