$().ready(function() {

  
    $("#edit_account_source_form").validate({

        rules: {
            name: "required",
            shortcode: {
                required: true,
            }
            
            
        },
        messages: {
            name: "Please enter an Account Source name",
            shortcode: {
                required: "Please enter a unique shortcode for this account source",
                
            }

        }
    });
});

$().ready(function() {

    

    $("#add_account_source_form").validate({

        rules: {
            name: "required",
            shortcode: {
                required: true,
            }
            
            
        },
        messages: {
            name: "Please enter an Account Source name",
            shortcode: {
                required: "Please enter a unique shortcode for this account source",
            }
        }
    });
});

$(document).ready(function(){
    $("#addAccountSourceModal").click(function(){
        if($("#add_account_source_form").valid()){
            $.LoadingOverlay("show");
        }
    })  
})

$(document).ready(function(){
    $("#updateAccountSource").click(function(){
        if($("#edit_account_source_form").valid()){
            $.LoadingOverlay("show");
        }
    })  
})