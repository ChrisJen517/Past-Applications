$().ready(function () {

    $("#manage_queues_form").validate({

        rules: {
            agent_selected: "required",
            "send_to_agent[]": "required",
            team_selected: "required",
            send_to_team: "required"
        },
        messages: {
            agent_selected: "Please Select an Agent",
            "send_to_agent[]": "Please Select an Agent to Send Accounts",
            team_selected: "Please Select A Team",
            send_to_team: "Please Select A Team"
        },
    
    });
    
    $('#recall-submit').click(function(event){
        var case_number = $("select#case_number option:checked").val();
        var client_id = $( "select#client_id option:checked" ).val();
        var source_code = $( "select#source_code option:checked" ).val();
        var recall_score_select = $("#recall_score_select").select2("val");

        if(case_number != '' || client_id != '' || source_code != '' || recall_score_select != '')
            recallSWAL(case_number, client_id, source_code, recall_score_select);
        else
            $('#need_one_recall').show();

    })

         
    function recallSWAL(case_number, client_id, source_code, recall_score_select) {
        var message = "You are unassigning all Active Accounts that are in ";
        var count = 0;
        if(client_id != ''){
            message = message+"Client ID: "+client_id;
            count = count + 1;
        }
        
        if(source_code != '')
        {
          if(count > 0)
              message = message+", Source Code: "+source_code;
          else{
              message = message+"Source Code: "+source_code;
              count = count + 1;
          }     
        }
        
        if(recall_score_select != null)
        {
          var score_message =" "+recall_score_select[0];
          for(var i = 1; i < recall_score_select.length; i++){
            score_message = score_message+", "+recall_score_select[i];
          }
        }
        else{
          score_message = " All scores";
        }
        if(count > 0){
          message = message+", Score(s):"+score_message;
        }
        else{
          message = message+"Score(s):"+score_message;
          count = count + 1;
        } 
        
        if(case_number != '')
        {
          if(count > 0){
              message = message+", Case Number: "+case_number+".";
          }
          else{
              message = message+"Case Number: "+case_number+".";
              count = count + 1;
          }      
        }

        swal({
          title: "Are you sure?",
          text: message,
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $('#recallForm').submit();

          } else {
            swal("Accounts not unassigned");
            return false;
        }
        });
        }

    $('#releaseButton').click(function(event){
        var release_option = $("input[name='recallOption']:checked").val();
        var case_select = $("select#case_num option:checked").val();
        var tier_value = $("select#tier_value option:checked").val();
        var score = $('#score').select2("val");
        var team_id = $('#team_id option:selected').attr('id');

        if(release_option == 'case')
        {
            if(case_select != '')
                releaseAccountsSWAL(release_option, case_select, tier_value, score, team_id);
            else
                $('#need_one_release').show();
        }
        else
            releaseAccountsSWAL(release_option, case_select, tier_value, score, team_id);
    })

    
         
function releaseAccountsSWAL(release_option, case_select, tier_value, score, team_id) {

    if(score != null)
    {
      var score_message =" "+score[0];
      for(var i = 1; i < score.length; i++){
        score_message = score_message+", "+score[i];
      }
    }
    else{
      score_message = " All scores";
    }
    var message = "You will be distributing all Active Accounts to "+team_id+" that have Score(s):"+score_message;
    if(release_option == 'case')
        message = message+" and have the Case Number: "+case_select+".";
    else if(release_option == 'tier')
        message = message+" and have Tier Value "+tier_value+" and Above.";
    
    swal({
      title: "Are you sure?",
      text: message,
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $('#releaseForm').submit();
      } else {
        swal("Accounts Not Distributed!");
      }
    });
    }

    //only show overlay if form is valid
$(document).ready(function (e) {
    $("#accounts_submit").click(function (e) {
        if($("#manage_queues_form").valid()){
            e.preventDefault();
            var message = "You will be distributing Active Accounts ";
            var type = $("#toss_type").val();
            var agent_selected = '';
            var team_selected = '';

            switch (type) {
              case "Team to Team":
                team_selected = $('#team_selected option:selected').attr('id');
                team_to = $('#send_to_team option:selected').attr('id');
                message = message+"from team: "+team_selected+" to team: "+team_to;
              break;
              case "Team to Agent":
                team_selected = $('#team_selected option:selected').attr('id');
                message = message+"from team: "+team_selected+" to agents";
              break;
              case "Agent to Team":
                agent_selected = $('#agent_selected option:selected').attr('id');
                team_to = $('#send_to_team option:selected').attr('id');
                message = message+"agent: "+agent_selected+" to team: "+team_to;
              break;
              case "fromTeam":
                message = message+"from the holding queue to agents";
              break;
              case "toTeam":
                agent_selected = $('#agent_selected option:selected').attr('id');
                message = message+"from agent: "+agent_selected+" to the holding queue";
              break;
              default:
                agent_selected = $('#agent_selected option:selected').attr('id');
                message = message+"from agent: "+agent_selected+" to other agents";
              break;
            }

            swal({
                title: "Are you sure?",
                text: message,
                icon: "warning",
                buttons: true,
                dangerMode: true,
              })
              .then((willDelete) => {
                if (willDelete) {
                  $.LoadingOverlay("show");
                  $("#manage_queues_form").submit();
                } else {
                  swal("Accounts Not Distributed!");
                  return 'false';  
                }
              });            
            
        }
    })  
})


});