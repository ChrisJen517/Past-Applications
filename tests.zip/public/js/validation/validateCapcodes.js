$('#loader').delay(25).fadeOut();
$('.capcodeCard').delay(450).fadeIn();

$(document).ready(function() {
    var table = $('#capcodeTable').DataTable( {
        lengthChange: true,
        autoWidth: false,
        buttons: [
            {
                extend: 'excel',
                title: 'Capcodes List'
            }
        ],
    });
    table.buttons().container()
            .appendTo( '#capcodeTable_wrapper .col-md-6:eq(0)' );
    var table2 = $('#capcodeTableAll').DataTable( {
        lengthChange: true,
        autoWidth: false,
        buttons: [
            {
                extend: 'excel',
                title: 'Capcodes List'
            }
        ],
    });
    table2.buttons().container()
            .appendTo( '#capcodeTableAll_wrapper .col-md-6:eq(0)' );

    var showingArchived = false;

    $('#showArchived').on('click', function() {
        showingArchived = !showingArchived;
        $(this).text(showingArchived ? "Hide Archived Capcodes" : "Show Archived Capcodes");
        if (showingArchived) {
            $('#capcodeCard').prop('hidden', true);
            $('#capcodeCardAll').prop('hidden', false);
        } else {
            $('#capcodeCard').prop('hidden', false);
            $('#capcodeCardAll').prop('hidden', true);
        }
    });

    //sets up the validation for both forms
    capcodeForms = ["#add_capcode_form", "#edit_capcode_form"];
    for(i = 0; i < 2; i++){
        $(capcodeForms[i]).validate({
            rules: {
                name: "required",
                capcode: {
                    required: true,
                },
                agent_access: "required",
            },
            messages: {
                name: "Please enter a name",
                capcode: {
                    required: "Please enter a unique capcode",
                },
                agent_access: "Please select if an agent can use this capcode",
            },
            invalidHandler: function (event, validator) {
                // 'this' refers to the form
                var errors = validator.numberOfInvalids();
                if (errors) {
                    $('#myModalAddBody').LoadingOverlay("hide");
                } else {
                    $('#myModalAddBody').LoadingOverlay("show");
                }
            }
        });

        $(capcodeForms[i]).submit(function(e){
            if($(this).valid())
            {
                $(this).LoadingOverlay('show');
            }
        });
    }
});

function confirmArchive(capcodeId) {
    if(document.getElementById('adminPage') != null)
        urlLink = "/admin/archiveCapcode/"+capcodeId;
    else
        urlLink = "/corporateAdmin/archiveCapcode/"+capcodeId;

    swal({
    title: "Are you sure?",
    text: "You are about to archive this capcode.",
    icon: "warning",
    buttons: true,
    dangerMode: true,
    })
    .then((willArchive) => {
        if (willArchive) {
            window.location = urlLink;
            $.LoadingOverlay("show");
        } else {
            swal("Capcode was not archived!");
        }
    });
}

function confirmUnarchive(capcodeId) {
    if(document.getElementById('adminPage') != null)
        urlLink = "/admin/archiveCapcode/"+capcodeId;
    else
        urlLink = "/corporateAdmin/archiveCapcode/"+capcodeId;

    swal({
    title: "Are you sure?",
    text: "You are about to unarchive this capcode.",
    icon: "warning",
    buttons: true,
    dangerMode: true,
    })
    .then((willUnarchive) => {
        if (willUnarchive) {
            window.location = urlLink;
            $.LoadingOverlay("show");
        } else {
            swal("Capcode was not unarchived!");
        }
    });
}

$('#modalAddCapcode').on('show.bs.modal', function (e) {
    var opener=e.relatedTarget;
    var corpId=$(opener).attr('data-corpId');
    $('#corp_id').val(corpId);
});

$('#modalEditCapcode').on('show.bs.modal', function (e) {
    var opener=e.relatedTarget;

    var id=$(opener).attr('data-id');
    var corpId=$(opener).attr('data-corpId');
    var capcode=$(opener).attr('data-capcode');
    var name=$(opener).attr('data-name');
    var description=$(opener).attr('data-description');
    var type=$(opener).attr('data-type');
    var account=$(opener).attr('data-account');
    var agent_access = $(opener).attr('data-agent-access');

    $('#capcode_id').val(id);
    $('#corporation_id').val(corpId);
    $('#capcode').val(capcode);
    $('#name').val(name);
    $('#description').val(description);
    $('#type').val(type);
    $("#edit_agent_access").val(agent_access);
    if(account == "AWG7")
        $('#account').val(account);
});
