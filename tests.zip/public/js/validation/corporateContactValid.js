$().ready(function() {
    
    
    $("#corporationContact").validate({

        rules: {
            name: "required",
            email: {
                required: true,
                email: true
            },
            job_title: "required",
            phone_number: "required",
        },
        messages: {
            name: "Please enter your name",
            email: "Please enter a valid email address",
            job_title: "Please enter a job title",
            phone_number: "Please enter a valid phone number"
            },
            
    });


});


//only show overlay if form is valid
$(document).ready(function (e) {
    $("#corporation_add_contact_submit").click(function () {
        if ($("#corporationContact").valid()) {
            $.LoadingOverlay("show");
        }
    })
})