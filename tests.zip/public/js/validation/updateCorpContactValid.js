$().ready(function() {
    
    $("#personal-info").validate();
   // validate signup form on keyup and submit
    $("#updateCorporationContact").validate({

        rules: {
            name: "required",
            email: {
                required: true,
                email: true
            },
            job_title: "required",
            phone_number: "required",
        },
        messages: {
            name: "Please enter your name",
            email: "Please enter a valid email address",
            job_title: "Please enter a job title",
            phone_number: "Please enter a valid phone number"
            },
            
    });

    jQuery.validator.addMethod("addressCorrectRules", function(value, element) {
        return this.optional(element) || /(\d{1,}) [a-zA-Z0-9\s]+(\.)?/.test(value);
    }, "Please enter a valid address.");

});

//only show overlay if form is valid
$(document).ready(function (e) {
    $("#submit-button").click(function () {
        if ($("#updateCorporationContact").valid()) {
            $.LoadingOverlay("show");
        }
    })
})