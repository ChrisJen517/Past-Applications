$('#datetimepicker').datetimepicker({
    minDate: 0,
    inline: true,
    sideBySide: true,
    formatTime: 'g:iA',
    format: 'Y-m-d H:i ',
    step: 30
});

function showOrHideButtons(prefix, bool) {
    if(bool == true) {
        $(prefix + "google_button").hide();
        $(prefix + "copy_button").hide();
        $(prefix + "call_button").hide();
        $(prefix + "fax_button").hide();
        $(prefix + "email_button").hide();
    } else {
        $(prefix + "google_button").show();
        $(prefix + "copy_button").show();
        $(prefix + "call_button").show();
        $(prefix + "fax_button").show();
        $(prefix + "email_button").show();
    }
}

function uploadFile() {
    if (document.getElementById("verified_file").files.length == 0) {
        swal('Please choose a file to upload!', {
            dangerMode: true
        });
        return
    }
    formData = new FormData($('#verified_form')[0]);
    $.ajax({
        url: "/agent/uploadFileActive",
        type: "POST",
        data: formData,
        contentType: false,
        cache: false,
        processData: false,
        success: function (data, status) {
            var data = JSON.parse(data);
            $("<tr id='file_row_" + data['fileid'] + "'><td style='font-size:15px'>" + data['filename'] + "</td><td style='font-size:10px'><button class='btn btn-info' type='button' onClick='dowloadFile(" + data['fileid'] + ")'>Download</button></td><td style='font-size:10px'><button class='btn btn-danger' type='button' onClick='deleteOverlay(" + data['fileid'] + ")'>Delete</button></td></tr>").insertAfter('#active_files tr:eq(0)');
            $("#verified_file").val(null);
        }, error: function (err) {
            if (err.status == 419) 
                location.reload();
        }
    });
}
function deleteOverlay(id) {
    $("#active_files").LoadingOverlay("show");
    $.ajax({
        url: "/agent/deleteActive/" + id,
        type: "POST",
        contentType: false,
        cache: false,
        processData: false,
        success: function () {
            $("#file_row_" + id).remove();
            $("#active_files").LoadingOverlay("hide");
        }, error: function (err) {
            if (err.status == 419) 
                location.reload();
        }
    });
}

//Account worked timer
var sec = $("#seconds-spent").val();
function pad(val) { return val > 9 ? val : "0" + val; }
var timerInterval = setInterval(function () {
    $("#seconds").html(pad(++sec % 60));
    $("#minutes").html(pad(parseInt(sec / 60, 10)));
    $("#seconds-spent").val(pad(sec));
}, 1000);

checkAttemptReload = true;
//checks if an attempt is made and the page is being unloaded
$(window).bind("beforeunload", function () {
    if (($("#is_attempt").val() == 1) && (checkAttemptReload)) {
        $.post('/agent/increaseWorkAttempts', {
            account_id: $("#account_history_id").val(),
            max_attempts_total: $("#max_attempts_total").val(),
            seconds_spent: $("#seconds-spent").val()
        });
        $.LoadingOverlay("show");
    }
});


function changeColors(current) {
    $("tr.history_row").addClass("nonSelected");
    $("tr.history_row").removeClass("table-striped");

    current = "tr.record" + current;
    $(current).removeClass("nonSelected");
    $(current).addClass("table-striped");
}

function updateHeader(cases) {
    $("#IDHeader").html(cases[0]["ID"]);

    $("#firstNameHeader").html(cases[0]["ACCT_FIRST_NAME"]);
    $("#firstNameHeaderTitle").attr("hidden", cases[0]["ACCT_FIRST_NAME"] == null); //Hide if null show if not
    $("#lastNameHeader").html(cases[0]["ACCT_LAST_NAME"]);
    $("#lastNameHeaderTitle").attr("hidden", cases[0]["ACCT_LAST_NAME"] == null);
    $("#birthDateHeader").html(cases[0]["ACCT_DOB"]);
    $("#birthDateHeaderTitle").attr("hidden", cases[0]["ACCT_DOB"] == null);
    $("#adressHeader").html(cases[0]['ACCT_AD1']);
    $("#adressHeaderTitle").attr("hidden", cases[0]["ACCT_AD1"] == null);
    $("#cityHeader").html(cases[0]['ACCT_CITY']);
    $("#cityHeaderTitle").attr("hidden", cases[0]["ACCT_CITY"] == null);
    $("#stateHeader").html(cases[0]['ACCT_ST']);
    $("#stateHeaderTitle").attr("hidden", cases[0]["ACCT_ST"] == null);
    $("#zipHeader").html(cases[0]['ACCT_ZIP']);
    $("#zipHeaderTitle").attr("hidden", cases[0]["ACCT_ZIP"] == null);
    $("#ACCTIdTitle").attr("hidden", cases[0]["ACCT_ID"] == null);
    if (cases[0]["ACCT_ID"] == null) 
        $("#ACCTIDHeader").html("");
    else 
        $("#ACCTIDHeader").html(cases[0]['ACCT_ID']);

    var show = $("#clientPhoneHeader");
    if (show) {
        $("#clientPhoneHeader").html(cases[0]['CLIENT_PHONE']);
        $("#clientPhoneHeaderTitle").attr("hidden", cases[0]["CLIENT_PHONE"] == null);
        $("#clientNameHeader").html(cases[0]['CLIENT_NAME']);
        $("#clientNameHeaderTitle").attr("hidden", cases[0]["CLIENT_NAME"] == null);
    }

}

//change value for save & open next
$("#saveOpenNext").click(function (e) {
    $("#open_next").val(1);
});

$("#select-ssn").change(function () {
    $('#select-lead-type').empty();
    $("#powerlead-form").hide();
    $("#directory-data").hide();
    $("#lead-form").show();
    $("#web_crawler").hide();
    var lastEmplName = $("#last_empl_name").val();
    var lastEmplAddr = $("#last_empl_addr").val();
    var lastEmplPhone = $("#last_empl_phone").val();
    var lastEmplEmail = $("#last_empl_email").val();
    var lastEmplFax = $("#last_empl_fax").val();
    var lastId = $("#currentAAid").val();
    var acctid = $(this).val();
    $.ajax({
        url: "/agent/getSSNAccount/",
        data: {
            id: acctid,
            emplName: lastEmplName,
            emplAddr: lastEmplAddr,
            emplPhone: lastEmplPhone,
            emplEmail: lastEmplEmail,
            emplFax: lastEmplFax,
            lastId: lastId
        },
        datatype: "json",
        type: "GET",
        beforeSend: function () {
            $.LoadingOverlay("show");
        },
        success: function (data) {
            var cases = JSON.parse(data);
            $("#currentAAid").val(acctid);
            if (cases[1] == false) {
                $("#select-lead-type").append(
                    '<option value="" disabled selected>No Access</option>'
                );
                fill_out_lead_data(null);
            } else {
                updateHeader(cases);
                changeColors(cases[0]["ID"]);
                $("#currectHistoryId").html(cases[0]["ID"]);
                $("#account_history_id").val(cases[0]["ID"]);
                $("#account_id").val(cases[0]["ID"]);

                fill_out_lead_data(cases[0]["ID"]);

                $("#select-lead-type").append('<option value="lead">Lead Data</option>');
                if (cases[0]["POWERLEAD_ID"] != null) {
                    fill_out_powerlead_data(cases[0]["POWERLEAD_ID"]);
                    $("#select-lead-type").append('<option id="powerlead_option" value="powerlead">Powerlead Data</option>');
                }
                if (cases[0]["DIRECTORY_LINK"] != null) {
                    fill_out_directory_data(cases[0]["DIRECTORY_LINK"]);
                    $("#select-lead-type").append('<option id="directory_option" value="directory">Directory Data</option>');
                }
                if (cases[0]["WEB_CRAWLER_ID"] != null) {
                    fill_out_webcrawler_data(cases[0]["WEB_CRAWLER_ID"]);
                    $("#select-lead-type").append('<option id="webcrawler_option" value="webcrawler">Web Crawler</option>');
                }
                if ((cases[0]["POWERLEAD_ID"] == null) && (cases[0]["DIRECTORY_LINK"] == null) && (cases[0]["WEB_CRAWLER_ID"] == null)) {
                    $("#select-lead-label").hide();
                    $("#select-lead-dropdown").hide();
                } else {
                    $("#select-lead-label").show();
                    $("#select-lead-dropdown").show();
                }
            }
        }, error: function (err) {
            if ((err.status == 419) || (err.status == 401)) {
                location.reload();
            }
        }
    });
});

function fill_out_lead_data(aaid) {
    $.ajax({
        url: "/agent/getLeadData/",
        data: { id: aaid },
        datatype: "json",
        type: "GET",
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0]["EMPL_NAME"] != null) {
                $("#empl_name1").val(data[0]["EMPL_NAME"]);
                $("#empl_name1_div").attr("hidden", false);
            } else 
                $("#empl_name1_div").attr("hidden", true);

            if (((data[0]["EMPL_ADDR1"] + data[0]["EMPL_CITY"] + data[0]["EMPL_ST"] + data[0]["EMPL_ZIP"]) != 0) && (data[0].length != 0)) {
                allAdress = "" + data[0]["EMPL_ADDR1"] + ", " + data[0]["EMPL_CITY"] + ", " + data[0]["EMPL_ST"] + ", " + data[0]["EMPL_ZIP"];
                allAdress = allAdress.replace(/null,/g, "");
                allAdress = allAdress.replace('null', "");
                $("#empl_addr1").val(allAdress);
                $("#empl_addr1").html(allAdress);
                $("#empl_addr1_div").attr("hidden", false);
                $("#empl_addr1").attr("data-address", data[0]["EMPL_ADDR1"]);
                $("#empl_addr1").attr("data-city", data[0]["EMPL_CITY"]);
                $("#empl_addr1").attr("data-state", data[0]["EMPL_ST"]);
                $("#empl_addr1").attr("data-zip", data[0]["EMPL_ZIP"]);
            } else 
                $("#empl_addr1_div").attr("hidden", true);

            if (data[0]["EMPL_PHONE1_NMBR"] != null) {
                $("#empl_ph_nmbr1_div").attr("hidden", false)
                $("#empl_ph_nmbr1").empty();
                $("#empl_ph_nmbr1").append('<option value="' + data[0]["EMPL_PHONE1_NMBR"] + '" selected>' + data[0]["EMPL_PHONE1_NMBR"] + (data[1] ? ' (blocked)' : '') + '</option>');
                showOrHideButtons("#phone_", data[1]);
            } else 
                $("#empl_ph_nmbr1_div").attr("hidden", true);

            if (data[0]["EMPL_FAX"] != null) {
                $("#empl_fax_div").attr("hidden", false);
                $("#empl_fax").val(data[0]["EMPL_FAX"] + (data[3] ? ' (blocked)' : ''));
                showOrHideButtons("#fax_", data[3]);
            } else 
                $("#empl_fax_div").attr("hidden", true);

            if (data[0]["EMPL_EMAIL"] != null) {
                $("#empl_email_div").attr("hidden", false);
                $("#empl_email").val(data[0]["EMPL_EMAIL"] + (data[2] ? ' (blocked)' : ''));
                showOrHideButtons("#email_", data[2]);
            } else 
                $("#empl_email_div").attr("hidden", true);

            $("#last_empl_name").val(data[0]["LAST_EMPL_NAME"] || "");
            $("#last_empl_addr").val(data[0]["LAST_EMPL_ADDR"] || "");
            $("#last_empl_phone").val(data[0]["LAST_EMPL_PHONE"] || "");
            $("#last_empl_email").val(data[0]["LAST_EMPL_EMAIL"] || "");
            $("#last_empl_fax").val(data[0]["LAST_EMPL_FAX"] || "");
            $("#countAttempts").val(data[0]['WORK_ATTEMPTS'] || 0);
            $("#count").html(data[0]['WORK_ATTEMPTS'] || "0");
            checkColors();
        },
        complete: function () {
            $.LoadingOverlay("hide");
        }
    });
}
function fill_out_webcrawler_data(WCid) {
    var corporation_id = $("#corporation_id").val();

    $.ajax({
        url: "/agent/getWebCrawlerData/",
        data: {
            id: WCid,
            corpId: corporation_id
        },
        datatype: "json",
        type: "GET",
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0] == null) {
                var x = $("#webcrawler_option");
                x.remove(x.selectedIndex);
            } else {
                if (data[0]["company_name"] != null) {
                    $("#crawler_name").val(data[0]["company_name"]);
                    $("#crawler_name_div").attr("hidden", false);
                } else 
                    $("#crawler_name_div").attr("hidden", true);
                if (data[0]["company_website"] != null) {
                    $("#crawler_web").val(data[0]["company_website"]);
                    $("#crawler_web_div").attr("hidden", false);
                } else 
                    $("#crawler_web_div").attr("hidden", true);
                if (data[0]["employee_count"] != null) {
                    $("#crawler_empl_count").val(data[0]["employee_count"]);
                    $("#crawler_empl_count_div").attr("hidden", false);
                } else 
                    $("#crawler_empl_count_div").attr("hidden", true);
                if (data[0]["company_country"] != null) {
                    $("#crawler_empl_country").val(data[0]["company_country"]);
                    $("#crawler_empl_country_div").attr("hidden", false);
                } else 
                    $("#crawler_empl_country_div").attr("hidden", true);

                if (data[0]["company_phone"] != null) {
                    $("#crawler_empl_ph_nmbr1").empty();
                    $("#crawler_empl_ph_nmbr1").append('<option value="' + data[0]["company_phone"] + '" selected>' + data[0]["company_phone"] + (data[1] ? ' (blocked)' : '') + '</option>');
                    showOrHideButtons("#web_phone_", data[1]);
                    $("#crawler_empl_ph_nmbr1_div").attr("hidden", false);
                } else 
                    $("#crawler_empl_ph_nmbr1_div").attr("hidden", true);
                if (data[0]["company_email"] != null) {
                    $("#crawler_email").val(data[0]["company_email"] + (data[2] ? ' (blocked)' : ''));
                    showOrHideButtons("#web_email_", data[2]);
                    $("#crawler_email_div").attr("hidden", false);
                } else 
                    $("#crawler_email_div").attr("hidden", true);

                if (data[0]["company_industry"] != null) {
                    $("#crawler_empl_industry").val(data[0]["company_industry"]);
                    $("#crawler_empl_industry_div").attr("hidden", false);
                } else 
                    $("#crawler_empl_industry_div").attr("hidden", true);

                if (data[0]["company_linked_in"] != null) {
                    $("#crawler_linkedin").val(data[0]["company_linked_in"]);
                    $("#crawler_linkedin_div").attr("hidden", false);
                } else 
                    $("#crawler_linkedin_div").attr("hidden", true);

                if ((data[0]["company_address"] + data[0]["company_city"] + data[0]["company_state"] + data[0]["company_zip"]) != 0) {
                    allAdress = "" + data[0]["company_address"] + ", " + data[0]["company_city"] + ", " + data[0]["company_state"] + ", " + data[0]["company_zip"];
                    allAdress = allAdress.replace(/null,/g, "");
                    allAdress = allAdress.replace('null', "");
                    $("#crawler_empl_addr1").val(allAdress);
                    $("#crawler_empl_addr1").attr("data-address", data[0]["company_address"]);
                    $("#crawler_empl_addr1").attr("data-city", data[0]["company_city"]);
                    $("#crawler_empl_addr1").attr("data-state", data[0]["company_state"]);
                    $("#crawler_empl_addr1").attr("data-zip", data[0]["company_zip"]);

                    $("#crawler_empl_addr1_div").attr("hidden", false);
                } else 
                    $("#crawler_empl_addr1_div").attr("hidden", true);
            }
        }
    });
}
function fill_out_directory_data(DLid) {
    var corporation_id = $("#corporation_id").val();
    $.ajax({
        url: "/agent/getDirectoryData/",
        data: {
            id: DLid,
            corpId: corporation_id
        },
        datatype: "json",
        type: "GET",
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0] == null) {
                var x = $("#directory_option");
                x.remove(x.selectedIndex);
            } else {
                if (data[0]["employer_name"] != null && data[0]["employer_name"] != '') {
                    $("#empl_name").val(data[0]["employer_name"]);
                    $('#direct_empl_name_div').show();
                } else
                    $('#direct_empl_name_div').hide();

                if (data[0]["direct_phone"] != null && data[0]["direct_phone"] != '') {
                    $("#direct_empl_ph_nmbr").val(data[0]["direct_phone"] + (data[7] == true ? '(blocked)' : ''));
                    showOrHideButtons("#direct_phone_", data[7]);
                    $('#direct_phone_div').show();
                } else
                    $('#direct_phone_div').hide();

                if (data[0]["verification_phone"] != null && data[0]["verification_phone"] != '') {
                    $("#verification_empl_ph_nmbr").val(data[0]["verification_phone"] + (data[6] == true ? '(blocked)' : ''));
                    showOrHideButtons("#direct_veri_", data[6]);
                    $('#direct_veri_phone_div').show();
                } else
                    $('#direct_veri_phone_div').hide();

                if (data[0]["verification_email"] != null && data[0]["verification_email"] != '') {
                    $("#dir_empl_email").val(data[0]["verification_email"] + (data[8] == true ? '(blocked)' : ''));
                    showOrHideButtons("#direct_email_", data[8]);
                    $('#direct_email_div').show();
                } else
                    $('#direct_email_div').hide();

                if (data[0]["verification_fax"] != null && data[0]["verification_fax"] != '') {
                    $("#directory_empl_fax").val(data[0]["verification_fax"] + (data[9] == true ? '(blocked)' : ''));
                    showOrHideButtons("#direct_fax_", data[9]);
                    $('#direct_fax_div').show();
                } else
                    $('#direct_fax_div').hide();

                if (data[0]["verification_contact"] != null && data[0]["verification_contact"] != '') {
                    document.getElementById("verification_contact").value = data[0]["verification_contact"];
                    $('#direct_contact_div').show();
                } else
                    $('#direct_contact_div').hide();

                if (data[0]["verification_contact_title"] != null && data[0]["verification_contact_title"] != '') {
                    document.getElementById("verification_contact_title").value = data[0]["verification_contact_title"];
                    $('#direct_contact_title_div').show();
                } else
                    $('#direct_contact_title_div').hide();

                if (data[0]["verification_mailing_adress"] != null && data[0]["verification_mailing_adress"] != '') {
                    document.getElementById("verification_mailing_address").value = data[0]["verification_mailing_adress"];
                    $('#direct_mail_address_div').show();
                } else
                    $('#direct_mail_address_div').hide();

                if (data[0]["verification_notes"] != null && data[0]["verification_notes"] != '') {
                    $('#directory_notes').val(data[0]["verification_notes"]);
                    $('#direct_notes_div').show();
                } else
                    $('#direct_notes_div').hide();

                if (data[0]["third_party_name"] != null && data[0]["third_party_name"] != '') {
                    document.getElementById("third_party_name").value = data[0]["third_party_name"];
                    $('#direct_third_party_div').show();
                } else
                    $('#direct_third_party_div').hide();

                if (data[1] > 0) {
                    $("#directory_address").empty();
                    $.each(data[3], function (i) {
                        $("#directory_address").append('<label class="form-control-label" for="empl_addr1">Directory Employer Address: ' + (i + 1) + '</label><div class="col-sm-12"><div class="input-group mb-3"><textarea type="text" class="form-control" id="empl_addr" name="empl_addr"data-address="' + data[2][i] + '" data-city="' + data[3][i] + '"data-state="' + data[4][i] + '" data-zip="' + data[5][i] + '"readonly>' + data[2][i] + ', ' + data[3][i] + ', ' + data[4][i] + ', ' + data[5][i] + '</textarea><div class="input-group-append input-clipboard"><span class="input-group-text"><i class="fa fa-clipboard" style="color:green" aria-hidden="true"></i></span></div><div class="input-group-append input-google"><span class="input-group-text"><i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i></span></div></div></div>');
                    });
                    $("#directory_address").show();
                } else 
                    $("#directory_address").hide();
            }
        },
    });
}

function fill_out_powerlead_data(PLid) {
    var corporation_id = document.getElementById("corporation_id").value;
    $.ajax({
        url: "/agent/getPowerLeadData/",
        data: {
            id: PLid,
            corpId: corporation_id
        },
        datatype: "json",
        type: "GET",
        beforeSend: function () {
            $("#Update").LoadingOverlay("show");
        },
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0] == null) {
                var x = document.getElementById("powerlead_option");
                x.remove(x.selectedIndex);
            } else {
                if (data[0]["employer_name"] != null) {
                    document.getElementById("power_empl_name1").value = data[0]["employer_name"];
                    document.getElementById("power_empl_name1_div").hidden = false;
                } else 
                    document.getElementById("power_empl_name1_div").hidden = true;

                if ((data[0]["employer_address"] + data[0]["employer_city"] + data[0]["employer_state"] + data[0]["employer_zip"]) != 0) {
                    allAdress = "" + data[0]["employer_address"] + ", " + data[0]["employer_city"] + ", " + data[0]["employer_state"] + ", " + data[0]["employer_zip"];
                    allAdress = allAdress.replace(/null,/g, "");
                    allAdress = allAdress.replace('null', "");
                    document.getElementById("power_empl_addr1").value = allAdress;
                    document.getElementById("power_empl_addr1").setAttribute("data-address", data[0]["employer_address"]);
                    document.getElementById("power_empl_addr1").setAttribute("data-city", data[0]["employer_city"]);
                    document.getElementById("power_empl_addr1").setAttribute("data-zip", data[0]["employer_zip"]);
                    document.getElementById("power_empl_addr1").setAttribute("data-state", data[0]["employer_state"]);
                    document.getElementById("power_empl_addr1_div").hidden = false;
                } else 
                    document.getElementById("power_empl_addr1_div").hidden = true;

                if (data[0]["main_phone"] != null) {
                    $("#power_empl_ph_nmbr1").empty();
                    $("#power_empl_ph_nmbr1").append('<option value="' + data[0]["main_phone"] + '" selected>' + data[0]["main_phone"] + (data[1] ? ' (blocked)' : '') + '</option>');
                    showOrHideButtons("#power_phone_", $data[1]);
                    document.getElementById("power_empl_ph_nmbr1_div").hidden = false;
                } else 
                    document.getElementById("power_empl_ph_nmbr1_div").hidden = true;

                if (data[0]["email"] != null) {
                    document.getElementById("power_empl_email").value = data[0]["email"] + (data[2] ? ' (blocked)' : '');
                    showOrHideButtons("#power_email_", data[2]);
                    document.getElementById("power_empl_email_div").hidden = false;
                } else 
                    document.getElementById("power_empl_email_div").hidden = true;

                if (data[0]["website"] != null) {
                    document.getElementById("power_website").value = data[0]["website"];
                    $("#power_website_div").show();
                } else 
                    $("#power_website_div").hide();

                if (data[0]["local_address"] != null) {
                    document.getElementById("power_local_address").value = data[0]["local_address"];
                    document.getElementById("power_local_address_div").hidden = false;
                } else 
                    document.getElementById("power_local_address_div").hidden = true;

                if (data[0]["fax"] != null) {
                    document.getElementById("power_empl_fax").value = data[0]["fax"] + (data[3] ? ' (blocked)' : '');
                    showOrHideButtons("#power_fax_", data[3]);
                    document.getElementById("power_empl_fax_div").hidden = false;
                } else 
                    document.getElementById("power_empl_fax_div").hidden = true;
            }
        }
    });
}

//toggle lead/powerlead data from dropdown
$("#select-lead-type").change(function () {
    $("#powerlead-form").hide();
    $("#directory-data").hide();
    $("#lead-form").hide();
    $("#web_crawler").hide();

    if ($(this).val() == "lead") 
        $("#lead-form").show();
    else if ($(this).val() == "powerlead") 
        $("#powerlead-form").show();
    else if ($(this).val() == "directory") 
        $("#directory-data").show();
    else if ($(this).val() == "webcrawler") 
        $("#web_crawler").show();
});

//change verification attempts color
$(document).ready(function () {

    checkColors();

    var current = $("#IDHeader").html();
    var multipleCheck = $("#select-ssn");

    if (multipleCheck)
        $(multipleCheck).val(current);

    changeColors(current);

    //fadeout error/success message
    $(".message").delay(2500).fadeOut('slow');



    //stretch top bar text when sidebar collapsed
    $('.toggle-menu').click(function () {
        $("#rocky-content").toggleClass('rocky-content');
    });

    //toggle inputs for future verification field in directory
    $(".directory-check-input").click(function () {
        var id = $(this).attr('id');
        $('#future_directory_selection .form-control').each(function () {
            if (!$(this).parent().parent().parent().hasClass('future_selection')) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
            if ($(this).hasClass(id)) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
        })
    });

    //toggle inputs for future verification field in verified hits
    $(".form-check-input").click(function () {
        var id = $(this).attr('id');
        $('#future_selection .form-control').each(function () {
            if (!$(this).parent().parent().parent().hasClass('future_selection')) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
            if ($(this).hasClass(id)) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
        })
    });


});

function checkColors() {
    var maxAttempts = $("#max_attempts_total").val();
    var attempts = $("#countAttempts").val();
    if (attempts < maxAttempts - 1)
        $('#attempts').css('color', '#71d223'); //green
    else if (attempts >= maxAttempts)
        $('#attempts').css('color', '#fd2f3e'); //red
    else
        $('#attempts').css('color', '#f1c46c'); //orange
}

$('[data-toggle="tooltip"]').tooltip();

//copy input fields to verified form
$(document).ready(function () {
    $("#rocky_form").on('click', 'div.input-clipboard', function () {
        var input = $(this).parent().find('.form-control');
        var inputVal = input.val();
        var inputId = input.attr('id');
        //split address and copy to verified column
        if (inputId == 'empl_addr1' || inputId == 'power_empl_addr1' || inputId == 'crawler_empl_addr1' || inputId == 'empl_addr' || inputId == "last_empl_addr" || inputId == "power_local_address") {

            var notSet = false;
            var address = input.data('address') || '';
            var city = input.data('city') || '';
            var state = input.data('state') || '';
            var zip = input.data('zip') || '';
            var fullAddress = '';

            //checks if anything but the address is se
            if (city == '' && state == '' && zip == '') {
                fullAddress = inputVal;
                notSet = true;
            }

            //breaks appart the input by the full adress
            if (notSet) {
                fullAddress = fullAddress.split(",");
                address = fullAddress[0] || '';
                city = fullAddress[1] || '';
                state = fullAddress[2] || '';
                zip = fullAddress[3] || '';
            }

            //removes any spaces at the start of the state
            while (state.indexOf(' ') == 0) {
                state = state.replace(' ', '');
            }
            //removes any spaces from the end of the string
            while (/\s+$/.test(state)) {
                state = state.substring(0, state.length - 1);
            }

            state = state.charAt(0).toUpperCase() + state.slice(1).replace(/[^A-Za-z ]/g, '');

            //check if state is two words
            if (state.indexOf(' ') >= 0) {
                index = state.indexOf(' ');
                var cap = state.charAt(index + 1).toUpperCase() + state.slice(index + 2);
                var first = state.slice(0, index);
                state = first + " " + cap;
            }

            //convert state value if not abbreviated
            if (state.length > 2) {
                state = convertState(state);
                state = state || ''; //if not found sets it to empty
            }

            //makes sure the letters are uppercase
            state = state.toUpperCase();

            $("#empl_addr1_verified").val(address);
            $("#empl_city_verified").val(city);
            $("#company_state").val(state);
            $("#empl_zip_verified").val(zip);
        } else if (inputId != 'empl_addr1') {
            $("#verified_form .form-control").each(function () {
                if ($(this).hasClass(inputId + '_verified')) 
                    $(this).val(inputVal);
            })
        }
    })

})

//google search buttons
$(document).ready(function () {
    $(".input-google").click(function () {
        var input = $(this).parent().find('.form-control').val();
        var inputId = $(this).parent().find('.form-control').attr("id");
        if (input != '') {
            var search = '';
            if (inputId == 'empl_name1' || inputId == 'last_empl_name') {
                var leadCity = $("#empl_addr1").data('city');
                var leadState = $("#empl_addr1").data('state');
                var state = $('#stateHeader').text();
                var city = $('#cityHeader').text();
                search = input + ' ' + city + ', ' + state;
                if (leadCity != '' && leadState != '' && inputId == 'empl_name1')
                    search = input + ' ' + leadCity + ', ' + leadState;
            } else if (inputId == 'empl_addr1' || inputId == 'empl_email' || inputId == 'empl_fax') {
                search = $("#empl_name1").val() + ' ' + input;
            } else if (inputId == 'last_empl_addr' || inputId == 'last_empl_email' || inputId == 'last_empl_fax') {
                search = $("#last_empl_name").val();
                if ($("#last_empl_name").val() == '') 
                    search = $("#empl_name1").val();
            } else 
                search = input;
            window.open('https://www.google.com/search?q=' + escape(search), '_blank');
        }
    })
})

//website link button
$(document).ready(function () {
    $(".input-link").click(function () {
        var input = $(this).parent().find('.form-control').val();
        if (input != '') {
            if (!input.includes("https://www."))
                input = "https://www." + input;

            window.open(input, '_blank');
        }
    })
});

//Update active account with verified data
$(document).ready(function () {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("#saveOpenNext").click(function () {
        if ($('#CAPCODE').val() == '') {
            swal('Please select a capcode!', {
                dangerMode: true
            });
            return
        }
        if ($('#CAPCODE option:selected').hasClass('verified')) {
            if (!checkNonOptinal()) {
                swal('Please fill all outlined fields!', {
                    dangerMode: true
                });
                return
            }
        }
        swal({
            title: "Are you sure?",
            text: "Please click OK to confirm changes",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willChange) => {
            if (willChange) {
                checkAttemptReload = false;
                $.LoadingOverlay('show');
                saveLastAAInfo();
                $("#verified_form").submit();
            } else 
                swal("Lead not updated!");
        });
    })
    $("#saveUpdate").on('click', function (e) {

        if ($('#CAPCODE').val() == '') {
            swal('Please select a capcode!', {
                dangerMode: true
            });
            return
        }
        if ($('#CAPCODE option:selected').hasClass('verified')) {
            if (!checkNonOptinal()) {
                swal('Please fill all outlined fields!', {
                    dangerMode: true
                });
                return
            }
        }
        var account_id = $("#account_id").val();
        formData = new FormData($('#verified_form')[0]);
        swal({
            title: "Are you sure?",
            text: "Please click OK to confirm changes",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willChange) => {
            if (willChange) {
                saveLastAAInfo();
                $.LoadingOverlay('show');
                $.ajax({
                    url: "/agent/updateAccount",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function (data, status) {
                        var history = JSON.parse(data);

                        $.LoadingOverlay('hide');

                        if (history['failed']) {
                            $('.nonOptional').css('outline', '3px solid #fd2f3e');
                            $('.nonOptionalForm').css('outline', '3px solid #fd2f3e');

                            swal("Not all required fields filled! If it isn't showing, refresh the page.", {
                                icon: "warning",
                                allowOutsideClick: false
                            });
                            return;
                        }

                        var date = history['date'];
                        date = date.replace('T', ' ').substring(0, date.lastIndexOf('.'));
                        var worker = $("#historyWorkedBy").html();
                        var time = '';
                        var notes = '';
                        if (history['time'] != null) 
                            time = history['time'];
                        if (history['notes'] != null) 
                            notes = history['notes'];

                        //appends the history to the table
                        var newHistory = "";
                        if (history['admin'])
                            newHistory = "<tr class='history_row record" + account_id + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + account_id + "</td><td class='text-center phone'>" + notes + "</td>" + "<td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        else
                            newHistory = "<tr class='history_row record" + account_id + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + account_id + "</td><td class='text-center phone'>" + notes + "</td><td class='text-center'>" + time + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        $(newHistory).insertAfter('#work_history_table tr:eq(1)');

                        if (history['filename'] != null) {
                            $("#verified_file").val(null);
                            $("<tr><td style='font-size:15px'>" + history['filename'] + "</td><td style='font-size:10px'><a class='btn btn-info' href='downloadActive/" + history['fileid'] + "'>Download</a></td><td style='font-size:10px'><button class='btn btn-danger' type='button' onClick='deleteOverlay(" + data['fileid'] + ")'>Delete</button></td></tr>").insertAfter('#active_files tr:eq(0)');
                        }
                        //update attempts and color
                        attempts = history['count'] || 0;
                        $("#count").html(attempts);
                        $("#countAttempts").val(attempts);
                        checkColors();

                        //reset is_attempt value
                        $("#is_attempt").val(0);

                        //reset account timer
                        $("#seconds-spent").val(0);
                        sec = 0;

                        if (history['closed']) {
                            $.LoadingOverlay('hide');
                            swal("Lead Closed Successfully!", {
                                icon: "success",
                                allowOutsideClick: false
                            });
                            $.LoadingOverlay('show');

                            if (history['admin']) 
                                window.history.back();
                            else 
                                window.location.href = '/agent/newActiveAccounts/';
                            
                        } else {
                            $.LoadingOverlay('hide');
                            swal("Lead Updated Successfully!", {
                                icon: "success"
                            });
                        }
                    }, error: function (err) {
                        $.LoadingOverlay('hide');
                        $(".lengthError").remove();
                        if (err.status == 419) 
                            location.reload();
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            // you can loop through the errors object and show it to the user
                            console.warn(err.responseJSON.errors);
                            // display errors on each form field
                            $.each(err.responseJSON.errors, function (i, error) {
                                var message = "This field " + error[0].slice(error[0].indexOf('may'));
                                var el = $(document).find('[name="' + i + '"]').parent();
                                el.after($('<div class="lengthError"><span style="color: red;">' + message + '</span><br><br></div>'));
                            });
                        }
                    }
                });
            } else 
                swal("Lead not updated!");
        });
    });
})

$(document).ready(function () {
    $('#verified_file').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size / 1024 / 1024;
            if (fileSize > 25) //check file size
            {
                swal({
                    title: "File size too large!",
                    text: "File size cannot exceed 25mbs",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");
            }
        }
    })
});

//auto-update worked history based on call/fax/email actions
$(document).ready(function () {
    $('.input-phone').click(function (e) {
        $.LoadingOverlay('show');
        setTimeout($.LoadingOverlay('hide'), 500);

        var phone = $(this).parent().find('.form-control').val();

        if (phone == '') 
            return swal("Please enter a phone number"); 
        if (checkBlocked(phone, 'phone_number')) 
            return swal("This Number is blocked");
        
        checkCallAttempts(phone);
    });

    function incrementAttempts() {
        $("#count").html(parseInt($('#count').html(), 10));
    }

    //check the number of attempts and give warning if greater than 0 in 24 hours
    function checkCallAttempts(newPhone) {
        var date = new Date();
        var count = 0;
        var result = '';

        $('.date').each(function () {
            var historyDate = $(this).html()
            historyDate = historyDate.substring(0, historyDate.lastIndexOf(' '));
            var newDate = new Date(historyDate);
            var timeDiff = date.getTime() - newDate.getTime();
            var diffDays = timeDiff / (1000 * 3600 * 24);
            var capcode = $(this).parent().find('.capcode').html();
            var phone = $(this).parent().find('.phone').html();
            phone = phone.substring(phone.lastIndexOf(':') + 2).replace(/[^0-9]/g, '');
            newPhone = newPhone.replace(/[^0-9]/g, '');

            if (capcode == 2210 && diffDays <= 1 && phone == newPhone) 
                count++;
        })

        if (newPhone.replace(/ /g, '') == '') 
            return swal("Please enter a valid phone number");

        if (count == 0) {
            var note = "Called phone number: " + newPhone;
            if ($("#note").val().length != 0) 
                $("#note").val($("#note").val() + '\n' + '\n' + note);
            else 
                $("#note").val($("#note").val() + note);
            callNumber(newPhone);
        }

        if (count > 0) {
            swal({
                title: "Warning: You Have Called This Number " + count + " time(s) in the last 24 hours.",
                text: "Are You Sure You Want to Continue?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willChange) => {
                if (willChange) {
                    callNumber(newPhone);
                    //copy note to notes field
                    var note = "Called phone number: " + newPhone;
                    if ($("#note").val().length != 0)
                        $("#note").val($("#note").val() + '\n' + '\n' + note);
                    else
                        $("#note").val($("#note").val() + note);
                    $("#is_attempt").val(1);
                    incrementAttempts();
                    var id = $("#account_history_id").val();
                    newPhone = newPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
                    var note = 'Called phone number: ' + newPhone;
                    var type = $("#type").val();
                    $("#lead_data").LoadingOverlay('show', { zIndex: 10 });
                    $("#directory-data").LoadingOverlay('show', { zIndex: 10 });
                    $.post('/agent/incrementHistory',
                        {
                            phone: newPhone,
                            id: id,
                            note: note,
                            type: type,
                        },
                        function (data, status) {
                            var history = JSON.parse(data);
                            var date = history['date'];
                            var worker = $("#historyWorkedBy").html();
                            date = date.replace('T', ' ').substring(0, date.lastIndexOf('.'));

                            if (history['admin']) {
                                newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                                $(newHistory).insertAfter('#work_history_table tr:eq(1)');
                            } else {
                                newHistory = "<tr hidden class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                                $(newHistory).appendTo('#work_history_table');
                            }

                            $("#lead_data").LoadingOverlay('hide');
                            $("#directory-data").LoadingOverlay('hide');
                        }).fail(function (err) {

                            if (err.status == 422) {
                                //removes the console error
                                console.clear();
                                swal("Invalid Email");
                            } else if (err.status == 419) 
                                location.reload();
                            return;
                        });
                } else {
                    swal("Call Cancelled");
                    result = false;
                }
            });
        } else {
            $("#is_attempt").val(1);
            incrementAttempts();
            newPhone = newPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
            var id = $("#account_history_id").val();
            var note = 'Called phone number: ' + newPhone;

            $.post('/agent/incrementHistory', {
                    phone: newPhone,
                    id: id,
                    note: note,
                },
                function (data, status) {
                    var history = JSON.parse(data);
                    var date = history['date'].replace('T', ' ');
                    date = date.substring(0, date.lastIndexOf('.'));
                    var worker = $("#historyWorkedBy").html();

                    if (history['admin']) {
                        newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        $(newHistory).insertAfter('#work_history_table tr:eq(1)');
                    } else {
                        newHistory = "<tr hidden class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        $(newHistory).appendTo('#work_history_table');
                    }
                }).fail(function (err) {
                    if (err.status == 422) {
                        //removes the console error
                        console.clear();
                        swal("Invalid Email");
                    } else if (err.status == 419) 
                        location.reload();
                    return;
                })
        }
        return result;
    }
});



var fax;
$(document).ready(function () {
    $('.input-fax').click(function () {
        fax = $(this).parent().parent().find('.form-control').val();
        if (fax == '') 
            return swal("Please have at least 10 alphanumeric characters and no more than 15 before sending a fax.");

        //tests to make sure there the fax is in a proper format before moving on
        faxLength = fax.replace(/[^0-9a-zA-Z]/g, '');
        faxLength = faxLength.length;
        if (faxLength < 10 || faxLength > 15) 
            return swal("Please have at least 10 alphanumeric characters and no more than 15 before sending a fax.");

        check = checkBlocked(fax, 'fax');
        if (check == true) 
            return swal("This Fax is blocked");

        allEmpty = checkForEmployeerName();
        //if the array is empty displays an error otherwise shows the select modal
        if (allEmpty) 
            return swal("At Least One Name field must be filled!");
        else {
            $("#sendEmailButton").attr("hidden", true);
            $("#sendFaxButton").attr("hidden", false);
            $('#faxNameSelectModal').modal('show');
        }
    });
});

function checkForEmployeerName(){
    //puts all potential names into an array
    var nameArry = new Array(6);
    nameArry[0] = $("#empl_name_verified").val() || '';
    nameArry[1] = $("#empl_name1").val() || '';
    nameArry[2] = $("#last_empl_name").val() || '';
    nameArry[3] = $("#empl_name").val() || '';
    nameArry[4] = $("#power_empl_name1").val() || '';
    nameArry[5] = $("#crawler_name").val() || '';

    //list of the fields origin and empties the old list
    var fieldList = ['Verified Employer Name', 'Lead Data Employer Name', 'Additional Data Employer Name',
        'Directory Data Employer Name', 'Powerlead Data Employer Name', 'Webcrawler Company Name'];
    $('#select-fax-name').empty();

    //appends non empty words into the select
    var allEmpty = true;
    for (let i = 0; i < 6; i++) {
        if (nameArry[i].replace(/ /g, '') != '') {
            allEmpty = false;
            $('#select-fax-name').append('<option value="' + nameArry[i] + '">' + fieldList[i] + ': ' + nameArry[i] + '</option>');
        }
    }
    return allEmpty;
}

function sendFax() {
    $("#is_attempt").val(1);
    //copy note to notes field
    var note = "Sent fax to: " + fax;
    if ($("#note").val().length != 0) 
        $("#note").val($("#note").val() + '\n' + '\n' + note);
    else 
        $("#note").val($("#note").val() + note);
    
    var company_name = $('#select-fax-name').val();
    var fullSSN = $("#fullSSN").val() || 0;
    var id = $("#account_history_id").val();
    var note = 'Sent fax to: ' + fax;

    if (company_name.replace(/ /g, '') == '') 
        return swal("Please select one valid name!");
    
    $.LoadingOverlay("show");
    $.post('/agent/incrementHistory', {
            fax: fax,
            id: id,
            company_name: company_name,
            fullSSN: fullSSN,
            note: note,
        },
        function (data, status) {
            var history = JSON.parse(data);

            //backend check to see if the name was still filled out
            if (history.length == 0) {
                swal("Oh No! No name was entered!");
                $('#faxNameSelectModal').modal('hide');
                return;
            }

            var date = history['date'];
            date = date.replace('T', ' ').substring(0, date.lastIndexOf('.'));
            var worker = $("#historyWorkedBy").html();

            if (history['admin']) {
                newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                $(newHistory).insertAfter('#work_history_table tr:eq(1)');
            }

        }).fail(function (err) {
            $.LoadingOverlay("hide");
            if (err.status == 422) {
                //removes the console error
                console.clear();
                swal("Invalid Email");
            } else if (err.status == 419) 
                location.reload();
            return;
        })
    swal('Fax Sent');
    $.LoadingOverlay("hide");
    $('#faxNameSelectModal').modal('hide');
}

var email;

$(document).ready(function () {
    $('.input-email').click(function () {
        email = $(this).parent().parent().find('.form-control').val();
        check = checkBlocked(email, 'email');
        if (check == true) 
            return swal("This email is blocked");
        else if(email == "")
            return swal("Please enter a valid email");

        allEmpty = checkForEmployeerName();

        //if the array is empty displays an error otherwise shows the select modal
        if (allEmpty) 
            return swal("At Least One Name field must be filled!");
        else {
            document.getElementById("sendEmailButton").hidden = false;
            document.getElementById("sendFaxButton").hidden = true;
            $('#faxNameSelectModal').modal('show');
        }
    });
});

function sendEmail() {
    var email_acct_id = $("#IDHeader").html();
    var email_acct_type = $("#select-lead-type").val();
    var acct_type = $("#acct_type").html();
    var company_name = $('#select-fax-name').val();
    var fullSSN = $("#fullSSN").val() || 0;

    $.LoadingOverlay("show");
    $.post('/agent/formatEmailData', {
            email_acct_id: email_acct_id,
            email_acct_type: email_acct_type,
            email: email,
            acct_type: acct_type,
            company_name: company_name,
            fullSSN: fullSSN
        }).done(function () {
            $('#faxNameSelectModal').modal('hide');
            $("#is_attempt").val(1);

            //copy note to notes field
            var note = "Sent email to: " + email;
            if ($("#note").val().length != 0) 
                $("#note").val($("#note").val() + '\n' + '\n' + note);
            else 
                $("#note").val($("#note").val() + note);

            var id = $("#account_history_id").val();
            var note = 'Sent email to: ' + email;

            $.post('/agent/incrementHistory', {
                    email: email,
                    id: id,
                    note: note,
                },
                function (data, status) {
                    var history = JSON.parse(data);
                    var date = history['date'];
                    date = date.replace('T', ' ').substring(0, date.lastIndexOf('.'));
                    var worker = $("#historyWorkedBy").html();

                    if (history['admin']) {
                        newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "<td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center'></td></tr>";
                        $(newHistory).insertAfter('#work_history_table tr:eq(1)');
                    }
                })
            swal('Email Sent', {});
            $.LoadingOverlay("hide");
        }).fail(function (err) {
            $.LoadingOverlay("hide");
            if (err.status == 422) {
                //removes the console error
                console.clear();
                swal("Invalid Email");
            } else if (err.status == 419) 
                location.reload();
            return;
        })
}

function convertState(input) {
    var states = [
        ['Alabama', 'AL'],
        ['Alaska', 'AK'],
        ['American Samoa', 'AS'],
        ['Arizona', 'AZ'],
        ['Arkansas', 'AR'],
        ['Armed Forces Americas', 'AA'],
        ['Armed Forces Europe', 'AE'],
        ['Armed Forces Pacific', 'AP'],
        ['California', 'CA'],
        ['Colorado', 'CO'],
        ['Connecticut', 'CT'],
        ['Delaware', 'DE'],
        ['District Of Columbia', 'DC'],
        ['Florida', 'FL'],
        ['Georgia', 'GA'],
        ['Guam', 'GU'],
        ['Hawaii', 'HI'],
        ['Idaho', 'ID'],
        ['Illinois', 'IL'],
        ['Indiana', 'IN'],
        ['Iowa', 'IA'],
        ['Kansas', 'KS'],
        ['Kentucky', 'KY'],
        ['Louisiana', 'LA'],
        ['Maine', 'ME'],
        ['Marshall Islands', 'MH'],
        ['Maryland', 'MD'],
        ['Massachusetts', 'MA'],
        ['Michigan', 'MI'],
        ['Minnesota', 'MN'],
        ['Mississippi', 'MS'],
        ['Missouri', 'MO'],
        ['Montana', 'MT'],
        ['Nebraska', 'NE'],
        ['Nevada', 'NV'],
        ['New Hampshire', 'NH'],
        ['New Jersey', 'NJ'],
        ['New Mexico', 'NM'],
        ['New York', 'NY'],
        ['North Carolina', 'NC'],
        ['North Dakota', 'ND'],
        ['Northern Mariana Islands', 'NP'],
        ['Ohio', 'OH'],
        ['Oklahoma', 'OK'],
        ['Oregon', 'OR'],
        ['Pennsylvania', 'PA'],
        ['Puerto Rico', 'PR'],
        ['Rhode Island', 'RI'],
        ['South Carolina', 'SC'],
        ['South Dakota', 'SD'],
        ['Tennessee', 'TN'],
        ['Texas', 'TX'],
        ['US Virgin Islands', 'VI'],
        ['Utah', 'UT'],
        ['Vermont', 'VT'],
        ['Virginia', 'VA'],
        ['Washington', 'WA'],
        ['West Virginia', 'WV'],
        ['Wisconsin', 'WI'],
        ['Wyoming', 'WY'],
        ['United States Minor Outlying Islands', 'UM'],
    ];
    for (i = 0; i < states.length; i++) {
        if (states[i][0] == input) {
            return (states[i][1]);
        }
    }

}

//checks for ctrl shift + c on lead employer phone
$('#empl_ph_nmbr1').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#empl_ph_nmbr1').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        callNumber($('#empl_ph_nmbr1').val().replace(/[^0-9]/g, ''));
    }
});

//checks for ctrl shift + c on directory direct phone
$('#direct_empl_ph_nmbr').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#direct_empl_ph_nmbr').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        callNumber($('#direct_empl_ph_nmbr').val().replace(/[^0-9]/g, ''));
    }
});

//checks for ctrl shift + c on directory verification phone
$('#verification_empl_ph_nmbr').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#verification_empl_ph_nmbr').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        callNumber($('#verification_empl_ph_nmbr').val().replace(/[^0-9]/g, ''));
    }
});


//checks for ctrl shift + c on directory verification phone
$('#power_empl_ph_nmbr1').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#power_empl_ph_nmbr1').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        callNumber($('#power_empl_ph_nmbr1').val().replace(/[^0-9]/g, ''));
    }
});

//calls selected phone number
function callNumber(phoneNumber) {
    checkAttemptReload = false;
    var link = "tel:" + phoneNumber;
    window.location.href = link;
    checkAttemptReload = true;
}

//downloads the file while not calling unload
function dowloadFile(fileNumber) {
    checkAttemptReload = false;
    var link = "/agent/downloadActive/" + fileNumber;
    window.location.href = link;
    checkAttemptReload = true;
}

var verified = 0;

$('select[name="verified_capcode"]').change(function () {
    if ($('select[name="verified_capcode"] :selected').hasClass("verified")) 
        verified = 1;
    else
        verified = 0;
});

function checkNonOptinal() {
    var reqlength = $('.nonOptional').length;
    var value = $('.nonOptional').filter(function () {
        return this.value.replace(/ /g, '') != '';
    });
    if ($("input:radio.nonOptional")[0]) {
        var radios = $("input:radio.nonOptional").length;
        var checked = $("input:radio.nonOptional:checked").length;

        if ((radios == 7 && checked < 2) || (radios < 7 && checked < 1)) {
            $('.nonOptional').css('outline', '3px solid #fd2f3e');
            $('.nonOptionalForm').css('outline', '3px solid #fd2f3e');
            return false;
        }
    }

    if ($(".nonOptionalForm")[0]) {
        reqlength++;
        var filledForm = $('.nonOptionalForm').filter(function () {
            if ($(this).is(":visible"))
                return this.value != '';
        });
        value.length = value.length + filledForm.length;
    }

    if (value.length >= 0 && (value.length !== reqlength)) {
        $('.nonOptional').css('outline', '3px solid #fd2f3e');
        $('.nonOptionalForm').css('outline', '3px solid #fd2f3e');
        return false;
    } else {
        $('.nonOptional').css('outline', 'none');
        $('.nonOptionalForm').css('outline', 'none');
        return true;
    }
}

function saveLastAAInfo() {
    $.get("/agent/updateAALastInfo/", {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
        emplName: $("#last_empl_name").val(),
        emplAddr: $("#last_empl_addr").val(),
        emplPhone: $("#last_empl_phone").val(),
        emplEmail: $("#last_empl_email").val(),
        emplFax: $("#last_empl_fax").val(),
        lastId: $("#currentAAid").val(),
    });
}
// returns var check to determine if value exists in blocked information
function checkBlocked(number, type) {
    var check = false;
    if (type == 'email') 
        number = number.toLowerCase();
    
    $.each(blockednumbers, function (i) {
        if (blockednumbers[i]['type'] == type) {
            if (type == 'fax') {
                if (blockednumbers[i]['fax_number'] == number) {
                    check = true;
                    return false;
                } else
                    check = false;
            } else {
                if (blockednumbers[i][type] == number) {
                    check = true;
                    return false;
                } else
                    check = false;
            }
        }
    });
    return check;
}
