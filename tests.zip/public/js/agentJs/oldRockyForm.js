$('#datetimepicker').datetimepicker({
    minDate: 0,
    inline: true,
    sideBySide: true,
    formatTime: 'g:iA',
    format: 'Y-m-d H:i ',
    step: 30
});

function uploadFile() {
    if (document.getElementById("verified_file").files.length == 0) {
        swal('Please choose a file to upload!', {
            dangerMode: true
        });
        return
    }
    var form = $('#verified_form')[0];
    formData = new FormData(form);
    $.ajax({
        url: "/agent/uploadFileActive",
        type: "POST",
        data: formData,
        contentType: false,
        cache: false,
        processData: false,
        success: function (data, status) {
            var data = JSON.parse(data);
            $("<tr id='file_row_" + data['fileid'] + "'><td style='font-size:15px'>" + data['filename'] + "</td><td style='font-size:10px'><button class='btn btn-info' type='button' onClick='dowloadFile(" + data['fileid'] + ")'>Download</button></td><td style='font-size:10px'><button class='btn btn-danger' type='button' onClick='deleteOverlay(" + data['fileid'] + ")'>Delete</button></td></tr>").insertAfter('#active_files tr:eq(0)');
            $("#verified_file").val(null);
        }, error: function (err) {
            if (err.status == 419) {
                location.reload();
            }
        }
    });
}
function deleteOverlay(id) {
    $("#active_files").LoadingOverlay("show");
    $.ajax({
        url: "/agent/deleteActive/" + id,
        type: "POST",
        contentType: false,
        cache: false,
        processData: false,
        success: function () {
            document.getElementById("file_row_" + id).remove();
            $("#active_files").LoadingOverlay("hide");
        }, error: function (err) {
            if (err.status == 419) {
                location.reload();
            }
        }
    });
}

//Account worked timer
var sec = $("#seconds-spent").val();
function pad(val) { return val > 9 ? val : "0" + val; }
var timerInterval = setInterval(function () {
    document.getElementById("seconds").innerHTML = pad(++sec % 60);
    document.getElementById("minutes").innerHTML = pad(parseInt(sec / 60, 10));
    document.getElementById("seconds-spent").value = pad(sec);
}, 1000);




$(document).ready(function () {
    var current = document.getElementById("IDHeader").innerHTML;

    var multipleCheck = document.getElementById("select-ssn");

    if (multipleCheck)
        multipleCheck.value = current;

    changeColors(current);

});

checkAttemptReload = true;
//checks if an attempt is made and the page is being unloaded
$(window).bind("beforeunload", function () {
    if (($("#is_attempt").val() == 1) && (checkAttemptReload)) {
        $.post('/agent/increaseWorkAttempts', {
            account_id: $("#account_history_id").val(),
            max_attempts_total: $("#max_attempts_total").val(),
            seconds_spent: $("#seconds-spent").val()
        });
        $.LoadingOverlay("show");
    }
});


function changeColors(current) {
    $("tr.history_row").addClass("nonSelected");
    $("tr.history_row").removeClass("table-striped");

    current = "tr.record" + current;

    $(current).removeClass("nonSelected");
    $(current).addClass("table-striped");
}

function updateHeader(cases) {
    document.getElementById("IDHeader").innerHTML = cases[0]["ID"];

    document.getElementById("firstNameHeader").innerHTML = cases[0]["ACCT_FIRST_NAME"];
    if (cases[0]["ACCT_FIRST_NAME"] == null)
        document.getElementById("firstNameHeaderTitle").hidden = true;
    else {
        document.getElementById("firstNameHeaderTitle").hidden = false;
    }

    document.getElementById("lastNameHeader").innerHTML = cases[0]["ACCT_LAST_NAME"];
    if (cases[0]["ACCT_LAST_NAME"] == null)
        document.getElementById("lastNameHeaderTitle").hidden = true;
    else {
        document.getElementById("lastNameHeaderTitle").hidden = false;
    }

    document.getElementById("birthDateHeader").innerHTML = cases[0]["ACCT_DOB"];
    if (cases[0]["ACCT_DOB"] == null)
        document.getElementById("birthDateHeaderTitle").hidden = true;
    else {
        document.getElementById("birthDateHeaderTitle").hidden = false;
    }

    document.getElementById("adressHeader").innerHTML = cases[0]['ACCT_AD1'];
    if (cases[0]["ACCT_AD1"] == null)
        document.getElementById("adressHeaderTitle").hidden = true;
    else {
        document.getElementById("adressHeaderTitle").hidden = false;
    }

    document.getElementById("cityHeader").innerHTML = cases[0]['ACCT_CITY'];
    if (cases[0]["ACCT_CITY"] == null)
        document.getElementById("cityHeaderTitle").hidden = true;
    else {
        document.getElementById("cityHeaderTitle").hidden = false;
    }

    document.getElementById("stateHeader").innerHTML = cases[0]['ACCT_ST'];
    if (cases[0]["ACCT_ST"] == null)
        document.getElementById("stateHeaderTitle").hidden = true;
    else {
        document.getElementById("stateHeaderTitle").hidden = false;
    }

    document.getElementById("zipHeader").innerHTML = cases[0]['ACCT_ZIP'];
    if (cases[0]["ACCT_ZIP"] == null)
        document.getElementById("zipHeaderTitle").hidden = true;
    else {
        document.getElementById("zipHeaderTitle").hidden = false;
    }

    if (cases[0]["ACCT_ID"] == null) {
        document.getElementById("ACCTIdTitle").hidden = true;
        document.getElementById("ACCTIDHeader").innerHTML = "";
    }
    else {
        document.getElementById("ACCTIdTitle").hidden = false;
        document.getElementById("ACCTIDHeader").innerHTML = cases[0]['ACCT_ID'];
    }

    var show = document.getElementById("clientPhoneHeader");
    if (show) {
        document.getElementById("clientPhoneHeader").innerHTML = cases[0]['CLIENT_PHONE'];
        if (cases[0]["CLIENT_PHONE"] == null)
            document.getElementById("clientPhoneHeaderTitle").hidden = true;
        else {
            document.getElementById("clientPhoneHeaderTitle").hidden = false;
        }

        document.getElementById("clientNameHeader").innerHTML = cases[0]['CLIENT_NAME'];
        if (cases[0]["CLIENT_NAME"] == null)
            document.getElementById("clientNameHeaderTitle").hidden = true;
        else {
            document.getElementById("clientNameHeaderTitle").hidden = false;
        }
    }

}

//change value for save & open next
$("#saveOpenNext").click(function (e) {
    $("#open_next").val(1);
});

$("#select-ssn").change(function () {
    $('#select-lead-type').empty();
    $("#powerlead-form").hide();
    $("#directory-data").hide();
    $("#lead-form").show();
    $("#web_crawler").hide();
    var lastEmplName = document.getElementById("last_empl_name").value;
    var lastEmplAddr = document.getElementById("last_empl_addr").value;
    var lastEmplPhone = document.getElementById("last_empl_phone").value;
    var lastEmplEmail = document.getElementById("last_empl_email").value;
    var lastEmplFax = document.getElementById("last_empl_fax").value;
    var lastId = document.getElementById("currentAAid").value;

    var acctid = $(this).val();
    $.ajax({
        url: "/agent/getSSNAccount/",
        data: {
            id: acctid,
            emplName: lastEmplName,
            emplAddr: lastEmplAddr,
            emplPhone: lastEmplPhone,
            emplEmail: lastEmplEmail,
            emplFax: lastEmplFax,
            lastId: lastId
        },
        datatype: "json",
        type: "GET",
        beforeSend: function () {
            $.LoadingOverlay("show");
        },
        success: function (data) {
            var cases = JSON.parse(data);
            document.getElementById("currentAAid").value = acctid;
            if (cases[1] == false) {
                $("#select-lead-type").append(
                    '<option value="" disabled selected>No Access</option>'
                );
                fill_out_lead_data(null);
            } else {
                updateHeader(cases);
                changeColors(cases[0]["ID"]);
                document.getElementById("currectHistoryId").innerHTML = cases[0]["ID"];
                document.getElementById("account_history_id").value = cases[0]["ID"];
                document.getElementById("account_id").value = cases[0]["ID"];


                fill_out_lead_data(cases[0]["ID"]);

                $("#select-lead-type").append('<option value="lead">Lead Data</option>');
                if (cases[0]["POWERLEAD_ID"] != null) {
                    fill_out_powerlead_data(cases[0]["POWERLEAD_ID"]);
                    $("#select-lead-type").append('<option id="powerlead_option" value="powerlead">Powerlead Data</option>');
                }
                if (cases[0]["DIRECTORY_LINK"] != null) {
                    fill_out_directory_data(cases[0]["DIRECTORY_LINK"]);
                    $("#select-lead-type").append('<option id="directory_option" value="directory">Directory Data</option>');
                }
                if (cases[0]["WEB_CRAWLER_ID"] != null) {
                    fill_out_webcrawler_data(cases[0]["WEB_CRAWLER_ID"]);
                    $("#select-lead-type").append('<option id="webcrawler_option" value="webcrawler">Web Crawler</option>');
                }
                if ((cases[0]["POWERLEAD_ID"] == null) && (cases[0]["DIRECTORY_LINK"] == null) && (cases[0]["WEB_CRAWLER_ID"] == null)) {
                    $("#select-lead-label").hide();
                    $("#select-lead-dropdown").hide();
                }
                else {
                    $("#select-lead-label").show();
                    $("#select-lead-dropdown").show();
                }
            }
        }, error: function (err) {
            if ((err.status == 419) || (err.status == 401)) {
                location.reload();
            }
        }
    });
});

function fill_out_lead_data(aaid) {
    // alert("The function called 'function_two' has been called.");
    $.ajax({
        url: "/agent/getLeadData/",
        data: { id: aaid },
        datatype: "json",
        type: "GET",
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0]["EMPL_NAME"] != null) {
                document.getElementById("empl_name1").value = data[0]["EMPL_NAME"];
                document.getElementById("empl_name1_div").hidden = false;
            }
            else {
                document.getElementById("empl_name1_div").hidden = true;
            }

            if (((data[0]["EMPL_ADDR1"] + data[0]["EMPL_CITY"] + data[0]["EMPL_ST"] + data[0]["EMPL_ZIP"]) != 0) && (data[0].length != 0)) {
                allAdress = "" + data[0]["EMPL_ADDR1"] + ", " + data[0]["EMPL_CITY"] + ", " + data[0]["EMPL_ST"] + ", " + data[0]["EMPL_ZIP"];
                allAdress = allAdress.replace(/null,/g, "");
                allAdress = allAdress.replace('null', "");
                document.getElementById("empl_addr1").value = allAdress;
                document.getElementById("empl_addr1").innerHTML = allAdress;
                document.getElementById("empl_addr1_div").hidden = false;
                document.getElementById("empl_addr1").setAttribute("data-address", data[0]["EMPL_ADDR1"]);
                document.getElementById("empl_addr1").setAttribute("data-city", data[0]["EMPL_CITY"]);
                document.getElementById("empl_addr1").setAttribute("data-state", data[0]["EMPL_ST"]);
                document.getElementById("empl_addr1").setAttribute("data-zip", data[0]["EMPL_ZIP"]);
            }
            else {
                document.getElementById("empl_addr1_div").hidden = true;
            }

            if (data[0]["EMPL_PHONE1_NMBR"] != null) {
                document.getElementById("empl_ph_nmbr1_div").hidden = false;
                $("#empl_ph_nmbr1").empty();
                if (data[1] == true) {
                    $("#empl_ph_nmbr1").append('<option value="' + data[0]["EMPL_PHONE1_NMBR"] + '" selected>' + data[0]["EMPL_PHONE1_NMBR"] + ' (blocked)</option>');
                    $("#phone_google_button").hide();
                    $("#phone_copy_button").hide();
                    $("#phone_button").hide();
                } else {
                    $("#empl_ph_nmbr1").append('<option value="' + data[0]["EMPL_PHONE1_NMBR"] + '" selected>' + data[0]["EMPL_PHONE1_NMBR"] + '</option>');
                    $("#phone_google_button").show();
                    $("#phone_copy_button").show();
                    $("#phone_button").show();
                }
            }
            else {
                document.getElementById("empl_ph_nmbr1_div").hidden = true;
            }

            if (data[0]["EMPL_FAX"] != null) {
                document.getElementById("empl_fax_div").hidden = false;
                if (data[3] == true) {
                    document.getElementById("empl_fax").value = data[0]["EMPL_FAX"] + ' (blocked)';
                    $("#fax_copy_button").hide();
                    $("#fax_google_button").hide();
                    $("#fax_fax_button").hide();
                } else {
                    document.getElementById("empl_fax").value = data[0]["EMPL_FAX"];
                    $("#fax_copy_button").show();
                    $("#fax_google_button").show();
                    $("#fax_fax_button").show();
                }
            }
            else {
                document.getElementById("empl_fax_div").hidden = true;
            }

            if (data[0]["EMPL_EMAIL"] != null) {
                document.getElementById("empl_email_div").hidden = false;
                if (data[2] == true) {
                    document.getElementById("empl_email").value = data[0]["EMPL_EMAIL"] + ' (blocked)';
                    $("#email_google_button").hide();
                    $("#email_copy_button").hide();
                    $("#email_email_button").hide();
                } else {
                    document.getElementById("empl_email").value = data[0]["EMPL_EMAIL"];
                    $("#email_google_button").show();
                    $("#email_copy_button").show();
                    $("#email_email_button").show();
                }
            }
            else {
                document.getElementById("empl_email_div").hidden = true;
            }

            document.getElementById("last_empl_name").value = data[0]["LAST_EMPL_NAME"] || "";
            document.getElementById("last_empl_addr").value = data[0]["LAST_EMPL_ADDR"] || "";
            document.getElementById("last_empl_phone").value = data[0]["LAST_EMPL_PHONE"] || "";
            document.getElementById("last_empl_email").value = data[0]["LAST_EMPL_EMAIL"] || "";
            document.getElementById("last_empl_fax").value = data[0]["LAST_EMPL_FAX"] || "";
            document.getElementById("countAttempts").value = data[0]['WORK_ATTEMPTS'] || 0;
            document.getElementById("count").innerHTML = data[0]['WORK_ATTEMPTS'] || "0";
            checkColors();
        },
        complete: function () {
            $.LoadingOverlay("hide");
        }
    });
}
function fill_out_webcrawler_data(WCid) {
    var corporation_id = document.getElementById("corporation_id").value;

    $.ajax({
        url: "/agent/getWebCrawlerData/",
        data: {
            id: WCid,
            corpId: corporation_id
        },
        datatype: "json",
        type: "GET",
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0] == null) {
                var x = document.getElementById("webcrawler_option");
                x.remove(x.selectedIndex);
            } else {
                if (data[0]["company_name"] != null) {
                    document.getElementById("crawler_name").value = data[0]["company_name"];
                    document.getElementById("crawler_name_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_name_div").hidden = true;
                }
                if (data[0]["company_website"] != null) {
                    document.getElementById("crawler_web").value = data[0]["company_website"];
                    document.getElementById("crawler_web_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_web_div").hidden = true;
                }
                if (data[0]["employee_count"] != null) {
                    document.getElementById("crawler_empl_count").value = data[0]["employee_count"];
                    document.getElementById("crawler_empl_count_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_empl_count_div").hidden = true;
                }
                if (data[0]["company_country"] != null) {
                    document.getElementById("crawler_empl_country").value = data[0]["company_country"];
                    document.getElementById("crawler_empl_country_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_empl_country_div").hidden = true;
                }

                if (data[0]["company_phone"] != null) {
                    $("#crawler_empl_ph_nmbr1").empty();
                    if (data[1] == true) {
                        $("#crawler_empl_ph_nmbr1").append('<option value="' + data[0]["company_phone"] + '" selected>' + data[0]["company_phone"] + ' (blocked)</option>');
                        $("#web_phone_google_button").hide();
                        $("#web_phone_copy_button").hide();
                        $("#web_phone_phone_button").hide();
                    } else {
                        $("#crawler_empl_ph_nmbr1").append('<option value="' + data[0]["company_phone"] + '" selected>' + data[0]["company_phone"] + '</option>');
                        $("#web_phone_google_button").show();
                        $("#web_phone_copy_button").show();
                        $("#web_phone_phone_button").show();
                    }
                    document.getElementById("crawler_empl_ph_nmbr1_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_empl_ph_nmbr1_div").hidden = true;
                }
                if (data[0]["company_email"] != null) {
                    if (data[2] == true) {
                        document.getElementById("crawler_email").value = data[0]["company_email"] + '(blocked)';
                        $("#web_email_copy_button").hide();
                        $("#web_email_google_button").hide();
                    } else {
                        document.getElementById("crawler_email").value = data[0]["company_email"];
                        $("#web_email_copy_button").show();
                        $("#web_email_google_button").show();
                    }
                    document.getElementById("crawler_email_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_email_div").hidden = true;
                }

                if (data[0]["company_industry"] != null) {
                    document.getElementById("crawler_empl_industry").value = data[0]["company_industry"];
                    document.getElementById("crawler_empl_industry_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_empl_industry_div").hidden = true;
                }

                if (data[0]["company_linked_in"] != null) {
                    document.getElementById("crawler_linkedin").value = data[0]["company_linked_in"];
                    document.getElementById("crawler_linkedin_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_linkedin_div").hidden = true;
                }

                if ((data[0]["company_address"] + data[0]["company_city"] + data[0]["company_state"] + data[0]["company_zip"]) != 0) {
                    allAdress = "" + data[0]["company_address"] + ", " + data[0]["company_city"] + ", " + data[0]["company_state"] + ", " + data[0]["company_zip"];
                    allAdress = allAdress.replace(/null,/g, "");
                    allAdress = allAdress.replace('null', "");
                    document.getElementById("crawler_empl_addr1").value = allAdress;
                    document.getElementById("crawler_empl_addr1").setAttribute("data-address", data[0]["company_address"]);
                    document.getElementById("crawler_empl_addr1").setAttribute("data-city", data[0]["company_city"]);
                    document.getElementById("crawler_empl_addr1").setAttribute("data-state", data[0]["company_state"]);
                    document.getElementById("crawler_empl_addr1").setAttribute("data-zip", data[0]["company_zip"]);

                    document.getElementById("crawler_empl_addr1_div").hidden = false;
                }
                else {
                    document.getElementById("crawler_empl_addr1_div").hidden = true;
                }
            }
        }
    });
}
function fill_out_directory_data(DLid) {
    var corporation_id = document.getElementById("corporation_id").value;
    $.ajax({
        url: "/agent/getDirectoryData/",
        data: {
            id: DLid,
            corpId: corporation_id
        },
        datatype: "json",
        type: "GET",
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0] == null) {
                var x = document.getElementById("directory_option");
                x.remove(x.selectedIndex);
            } else {
                if (data[0]["employer_name"] != null && data[0]["employer_name"] != '') {
                    document.getElementById("empl_name").value = data[0]["employer_name"];
                    $('#direct_empl_name_div').show();
                } else
                    $('#direct_empl_name_div').hide();

                if (data[0]["direct_phone"] != null && data[0]["direct_phone"] != '') {
                    if (data[7] == true) {
                        document.getElementById("direct_empl_ph_nmbr").value = data[0]["direct_phone"] + '(blocked)';
                        $("#direct_phone_copy_button").hide();
                        $("#direct_phone_google_button").hide();
                        $("#direct_phone_phone_button").hide();
                    } else {
                        document.getElementById("direct_empl_ph_nmbr").value = data[0]["direct_phone"];
                        $("#direct_phone_copy_button").show();
                        $("#direct_phone_google_button").show();
                        $("#direct_phone_phone_button").show();
                    }
                    $('#direct_phone_div').show();
                } else
                    $('#direct_phone_div').hide();

                if (data[0]["verification_phone"] != null && data[0]["verification_phone"] != '') {
                    if (data[6] == true) {
                        document.getElementById("verification_empl_ph_nmbr").value = data[0]["verification_phone"] + '(blocked)';
                        $("#direct_verit_phone_copy_button").hide();
                        $("#direct_veri_phone_google_button").hide();
                        $("#direct_veri_phone_phone_button").hide();
                    } else {
                        document.getElementById("verification_empl_ph_nmbr").value = data[0]["verification_phone"];
                        $("#direct_verit_phone_copy_button").show();
                        $("#direct_veri_phone_google_button").show();
                        $("#direct_veri_phone_phone_button").show();
                    }
                    $('#direct_veri_phone_div').show();
                } else
                    $('#direct_veri_phone_div').hide();

                if (data[0]["verification_email"] != null && data[0]["verification_email"] != '') {
                    if (data[8] == true) {
                        document.getElementById("dir_empl_email").value = data[0]["verification_email"] + '(blocked)';
                        $("#direct_email_copy_button").hide();
                        $("#direct_email_google_button").hide();
                        $("#direct_email_email_button").hide();
                    } else {
                        document.getElementById("dir_empl_email").value = data[0]["verification_email"];
                        $("#direct_email_copy_button").show();
                        $("#direct_email_google_button").show();
                        $("#direct_email_email_button").show();
                    }
                    $('#direct_email_div').show();
                } else
                    $('#direct_email_div').hide();

                if (data[0]["verification_fax"] != null && data[0]["verification_fax"] != '') {
                    if (data[9] == true) {
                        document.getElementById("directory_empl_fax").value = data[0]["verification_fax"] + '(blocked)';
                        $("#direct_fax_copy_button").hide();
                        $("#direct_fax_google_button").hide();
                        $("#direct_fax_fax_button").hide();
                    } else {
                        document.getElementById("directory_empl_fax").value = data[0]["verification_fax"];
                        $("#direct_fax_copy_button").show();
                        $("#direct_fax_google_button").show();
                        $("#direct_fax_fax_button").show();
                    }
                    $('#direct_fax_div').show();
                } else
                    $('#direct_fax_div').hide();

                if (data[0]["verification_contact"] != null && data[0]["verification_contact"] != '') {
                    document.getElementById("verification_contact").value = data[0]["verification_contact"];
                    $('#direct_contact_div').show();
                } else
                    $('#direct_contact_div').hide();

                if (data[0]["verification_contact_title"] != null && data[0]["verification_contact_title"] != '') {
                    document.getElementById("verification_contact_title").value = data[0]["verification_contact_title"];
                    $('#direct_contact_title_div').show();
                } else
                    $('#direct_contact_title_div').hide();

                if (data[0]["verification_mailing_adress"] != null && data[0]["verification_mailing_adress"] != '') {
                    document.getElementById("verification_mailing_address").value = data[0]["verification_mailing_adress"];
                    $('#direct_mail_address_div').show();
                } else
                    $('#direct_mail_address_div').hide();

                if (data[0]["verification_notes"] != null && data[0]["verification_notes"] != '') {
                    $('#directory_notes').val(data[0]["verification_notes"]);
                    $('#direct_notes_div').show();
                } else
                    $('#direct_notes_div').hide();

                if (data[0]["third_party_name"] != null && data[0]["third_party_name"] != '') {
                    document.getElementById("third_party_name").value = data[0]["third_party_name"];
                    $('#direct_third_party_div').show();
                } else
                    $('#direct_third_party_div').hide();

                if (data[1] > 0) {
                    $("#directory_address").empty();
                    $.each(data[3], function (i) {
                        $("#directory_address").append('<label class="form-control-label" for="empl_addr1">Directory Employer Address: ' + (i + 1) + '</label><div class="col-sm-12"><div class="input-group mb-3"><textarea type="text" class="form-control" id="empl_addr" name="empl_addr"data-address="' + data[2][i] + '" data-city="' + data[3][i] + '"data-state="' + data[4][i] + '" data-zip="' + data[5][i] + '"readonly>' + data[2][i] + ', ' + data[3][i] + ', ' + data[4][i] + ', ' + data[5][i] + '</textarea><div class="input-group-append input-clipboard"><span class="input-group-text"><i class="fa fa-clipboard" style="color:green" aria-hidden="true"></i></span></div><div class="input-group-append input-google"><span class="input-group-text"><i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i></span></div></div></div>');
                    });
                    $("#directory_address").show();

                } else {
                    $("#directory_address").hide();
                }
            }
        },
    });
}

function fill_out_powerlead_data(PLid) {
    var corporation_id = document.getElementById("corporation_id").value;

    $.ajax({
        url: "/agent/getPowerLeadData/",
        data: {
            id: PLid,
            corpId: corporation_id
        },
        datatype: "json",
        type: "GET",
        beforeSend: function () {
            $("#Update").LoadingOverlay("show");
        },
        success: function (data) {
            var data = JSON.parse(data);
            if (data[0] == null) {
                var x = document.getElementById("powerlead_option");
                x.remove(x.selectedIndex);
            } else {
                if (data[0]["employer_name"] != null) {
                    document.getElementById("power_empl_name1").value = data[0]["employer_name"];
                    document.getElementById("power_empl_name1_div").hidden = false;
                }
                else {
                    document.getElementById("power_empl_name1_div").hidden = true;
                }

                if ((data[0]["employer_address"] + data[0]["employer_city"] + data[0]["employer_state"] + data[0]["employer_zip"]) != 0) {
                    allAdress = "" + data[0]["employer_address"] + ", " + data[0]["employer_city"] + ", " + data[0]["employer_state"] + ", " + data[0]["employer_zip"];
                    allAdress = allAdress.replace(/null,/g, "");
                    allAdress = allAdress.replace('null', "");
                    document.getElementById("power_empl_addr1").value = allAdress;
                    document.getElementById("power_empl_addr1").setAttribute("data-address", data[0]["employer_address"]);
                    document.getElementById("power_empl_addr1").setAttribute("data-city", data[0]["employer_city"]);
                    document.getElementById("power_empl_addr1").setAttribute("data-zip", data[0]["employer_zip"]);
                    document.getElementById("power_empl_addr1").setAttribute("data-state", data[0]["employer_state"]);

                    document.getElementById("power_empl_addr1_div").hidden = false;
                }
                else {
                    document.getElementById("power_empl_addr1_div").hidden = true;
                }

                if (data[0]["main_phone"] != null) {
                    $("#power_empl_ph_nmbr1").empty();
                    if (data[1] == true) {
                        $("#power_empl_ph_nmbr1").append('<option value="' + data[0]["main_phone"] + '" selected>' + data[0]["main_phone"] + ' (blocked)</option>');
                        $("#power_phone_google_button").hide();
                        $("#power_phone_copy_button").hide();
                        $("#power_phone_phone_button").hide();
                    } else {
                        $("#power_empl_ph_nmbr1").append('<option value="' + data[0]["main_phone"] + '" selected>' + data[0]["main_phone"] + '</option>');
                        $("#power_phone_google_button").show();
                        $("#power_phone_copy_button").show();
                        $("#power_phone_phone_button").show();
                    }

                    document.getElementById("power_empl_ph_nmbr1_div").hidden = false;
                }
                else {
                    document.getElementById("power_empl_ph_nmbr1_div").hidden = true;
                }

                if (data[0]["email"] != null) {
                    if (data[2] == true) {
                        document.getElementById("power_empl_email").value = data[0]["email"] + ' (blocked)';
                        $("#power_email_copy_button").hide();
                        $("#power_email_google_button").hide();
                        $("#power_email_email_button").hide();
                    } else {
                        document.getElementById("power_empl_email").value = data[0]["email"];
                        $("#power_email_copy_button").show();
                        $("#power_email_google_button").show();
                        $("#power_email_email_button").show();
                    }

                    document.getElementById("power_empl_email_div").hidden = false;
                }
                else {
                    document.getElementById("power_empl_email_div").hidden = true;
                }

                if (data[0]["website"] != null) {
                    document.getElementById("power_website").value = data[0]["website"];
                    $("#power_website_div").show();
                } else {
                    $("#power_website_div").hide();
                }

                if (data[0]["local_address"] != null) {
                    document.getElementById("power_local_address").value = data[0]["local_address"];
                    document.getElementById("power_local_address_div").hidden = false;
                } else {
                    document.getElementById("power_local_address_div").hidden = true;

                }

                if (data[0]["fax"] != null) {
                    if (data[3] == true) {
                        document.getElementById("power_empl_fax").value = data[0]["fax"] + ' (blocked)';
                        $("#power_fax_copy_button").hide();
                        $("#power_fax_google_button").hide();
                        $("#power_fax_fax_button").hide();
                    } else {
                        document.getElementById("power_empl_fax").value = data[0]["fax"];
                        $("#power_fax_copy_button").show();
                        $("#power_fax_google_button").show();
                        $("#power_fax_fax_button").show();
                    }

                    document.getElementById("power_empl_fax_div").hidden = false;
                }
                else {
                    document.getElementById("power_empl_fax_div").hidden = true;
                }
            }
        }
    });
}
//toggle lead/powerlead data from dropdown

$("#select-lead-type").change(function () {
    if ($(this).val() == "lead") {
        $("#powerlead-form").hide();
        $("#directory-data").hide();
        $("#lead-form").show();
        $("#web_crawler").hide();
    } else if ($(this).val() == "powerlead") {
        $("#powerlead-form").show();
        $("#lead-form").hide();
        $("#directory-data").hide();
        $("#web_crawler").hide();
    } else if ($(this).val() == "directory") {
        $("#powerlead-form").hide();
        $("#lead-form").hide();
        $("#directory-data").show();
        $("#web_crawler").hide();
    } else if ($(this).val() == "webcrawler") {
        $("#powerlead-form").hide();
        $("#lead-form").hide();
        $("#directory-data").hide();
        $("#web_crawler").show();

    }
})

//change verification attempts color
$(document).ready(function () {
    checkColors();
});

function checkColors() {
    var maxAttempts = $("#max_attempts_total").val();
    var attempts = $("#countAttempts").val();
    if (attempts < maxAttempts - 1)
        $('#attempts').css('color', '#71d223'); //green
    else if (attempts >= maxAttempts)
        $('#attempts').css('color', '#fd2f3e'); //red
    else
        $('#attempts').css('color', '#f1c46c'); //orange
}

//stretch top bar text when sidebar collapsed
$(document).ready(function () {

    $('.toggle-menu').click(function () {
        // $("#account_info").toggleClass('account_info');
        // $("#rules_div").toggleClass('rules_div');
        $("#rocky-content").toggleClass('rocky-content');
    });
});




//toggle inputs for future verification field in directory
$(document).ready(function () {
    $(".directory-check-input").click(function () {
        var id = $(this).attr('id');
        $('#future_directory_selection .form-control').each(function () {
            if (!$(this).parent().parent().parent().hasClass('future_selection')) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
            if ($(this).hasClass(id)) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
        })
    })
});


//toggle inputs for future verification field in verified hits
$(document).ready(function () {
    $(".form-check-input").click(function () {
        var id = $(this).attr('id');
        $('#future_selection .form-control').each(function () {
            if (!$(this).parent().parent().parent().hasClass('future_selection')) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
            if ($(this).hasClass(id)) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
        })
    })
});

$('[data-toggle="tooltip"]').tooltip();

//copy input fields to verified form
$(document).ready(function () {
    // }
    // $('.input-clipboard').click(function () {
    $("#rocky_form").on('click', 'div.input-clipboard', function () {
        var input = $(this).parent().find('.form-control');
        var inputVal = input.val();
        var inputId = input.attr('id');
        //split address and copy to verified column
        if (inputId == 'empl_addr1' || inputId == 'power_empl_addr1' || inputId == 'crawler_empl_addr1' || inputId == 'empl_addr' || inputId == "last_empl_addr" || inputId == "power_local_address") {

            var notSet = false;

            //gets the directory data
            if (inputId == 'empl_addr') {
                var address = input.data('address');
                var city = input.data('city') || '';
                var state = input.data('state') || '';
                var zip = input.data('zip') || '';

                //checks if anything but the address is set
                if (city == '' && state == '' && zip == '') {
                    var fullAddress = inputVal;
                    notSet = true;
                }
            }
            //gets the rest of the data
            else {
                inputId = "#" + inputId;
                var address = $(inputId).data('address') || '';
                var city = $(inputId).data('city') || '';
                var state = $(inputId).data('state') || '';
                var zip = $(inputId).data('zip') || '';

                //checks if anything but the address is set
                if (city == '' && state == '' && zip == '') {
                    var fullAddress = $(inputId).val();
                    notSet = true;
                }
            }

            //breaks appart the input by the full adress
            if (notSet) {
                fullAddress = fullAddress.split(",");

                var address = fullAddress[0] || '';
                var city = fullAddress[1] || '';
                var state = fullAddress[2] || '';
                var zip = fullAddress[3] || '';
            }

            //removes any spaces at the start of the state
            while (state.indexOf(' ') == 0) {
                state = state.replace(' ', '');
            }
            //removes any spaces from the end of the string
            while (/\s+$/.test(state)) {
                state = state.substring(0, state.length - 1);
            }

            state = state.charAt(0).toUpperCase() + state.slice(1);
            state = state.replace(/[^A-Za-z ]/g, '');

            //check if state is two words
            if (state.indexOf(' ') >= 0) {
                index = state.indexOf(' ');
                var cap = state.charAt(index + 1).toUpperCase() + state.slice(index + 2);
                var first = state.slice(0, index);
                state = first + " " + cap;
            }

            //convert state value if not abbreviated
            if (state.length > 2) {
                state = convertState(state);
                state = state || ''; //if not found sets it to empty
            }

            //makes sure the letters are uppercase
            state = state.toUpperCase();

            $("#empl_addr1_verified").val(address);
            $("#empl_city_verified").val(city);
            $("#company_state").val(state);
            $("#empl_zip_verified").val(zip);
        }
        else if (inputId != 'empl_addr1') {

            $("#verified_form .form-control").each(function () {
                if ($(this).hasClass(inputId + '_verified')) {
                    $(this).val(inputVal);
                }
            })
        }
    })

})

//google search buttons
$(document).ready(function () {
    $(".input-google").click(function () {
        var input = $(this).parent().find('.form-control').val();
        var inputId = $(this).parent().find('.form-control').attr("id");
        if (input != '') {
            if (inputId == 'empl_name1' || inputId == 'last_empl_name') {
                var leadCity = $("#empl_addr1").data('city');
                var leadState = $("#empl_addr1").data('state');
                var state = $('#stateHeader').text();
                var city = $('#cityHeader').text();
                if (leadCity != '' && leadState != '' && inputId == 'empl_name1') {
                    window.open('https://www.google.com/search?q=' + escape(input + ' ' + leadCity + ', ' + leadState), '_blank');
                } else {
                    window.open('https://www.google.com/search?q=' + escape(input + ' ' + city + ', ' + state), '_blank');
                }
            } else if (inputId == 'empl_addr1' || inputId == 'empl_email' || inputId == 'empl_fax') {
                var empName = $("#empl_name1").val();
                window.open('https://www.google.com/search?q=' + escape(empName + ' ' + input), '_blank');
            } else if (inputId == 'last_empl_addr' || inputId == 'last_empl_email' || inputId == 'last_empl_fax') {
                var empName = $("#last_empl_name").val();
                if (empName == '') {
                    var empName = $("#empl_name1").val();
                    window.open('https://www.google.com/search?q=' + escape(empName + ' ' + input), '_blank');
                } else {
                    window.open('https://www.google.com/search?q=' + escape(empName + ' ' + input), '_blank');
                }
            } else {
                window.open('https://www.google.com/search?q=' + escape(input), '_blank');
            }
        }
    })
})

//website link button
$(document).ready(function () {
    $(".input-link").click(function () {
        var input = $(this).parent().find('.form-control').val();
        if (input != '') {
            if (!input.includes("https://www."))
                input = "https://www." + input;

            window.open(input, '_blank');
        }
    })
});

//Update active account with verified data
$(document).ready(function () {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("#saveOpenNext").click(function () {
        if ($('#CAPCODE').val() == '') {
            swal('Please select a capcode!', {
                dangerMode: true
            });
            return
        }
        if ($('#CAPCODE option:selected').hasClass('verified')) {
            if (!checkNonOptinal()) {
                swal('Please fill all outlined fields!', {
                    dangerMode: true
                });
                return
            }
        }
        swal({
            title: "Are you sure?",
            text: "Please click OK to confirm changes",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willChange) => {
            if (willChange) {
                checkAttemptReload = false;
                $.LoadingOverlay('show');
                saveLastAAInfo();
                $("#verified_form").submit();
            }
            else {
                swal("Lead not updated!");
            }
        });
    })
    $("#saveUpdate").on('click', function (e) {

        if ($('#CAPCODE').val() == '') {
            swal('Please select a capcode!', {
                dangerMode: true
            });
            return
        }
        if ($('#CAPCODE option:selected').hasClass('verified')) {
            if (!checkNonOptinal()) {
                swal('Please fill all outlined fields!', {
                    dangerMode: true
                });
                return
            }
        }
        var account_id = $("#account_id").val();
        var form = $('#verified_form')[0];
        formData = new FormData(form);
        swal({
            title: "Are you sure?",
            text: "Please click OK to confirm changes",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willChange) => {
            if (willChange) {
                saveLastAAInfo();
                $.LoadingOverlay('show');
                $.ajax({
                    url: "/agent/updateAccount",
                    type: "POST",
                    data: formData,
                    contentType: false,
                    cache: false,
                    processData: false,
                    success: function (data, status) {
                        var history = JSON.parse(data);

                        $.LoadingOverlay('hide');

                        if (history['failed']) {
                            $('.nonOptional').css('outline', '3px solid #fd2f3e');
                            $('.nonOptionalForm').css('outline', '3px solid #fd2f3e');

                            $.LoadingOverlay('hide');
                            swal("Not all required fields filled! If it isn't showing, refresh the page.", {
                                icon: "warning",
                                allowOutsideClick: false
                            });
                            return;
                        }

                        var date = history['date'];
                        date = date.replace('T', ' ');
                        date = date.substring(0, date.lastIndexOf('.'));
                        var worker = document.getElementById("historyWorkedBy").innerHTML;
                        var time = '';
                        var notes = '';
                        if (history['time'] != null) {
                            time = history['time'];
                        }
                        if (history['notes'] != null) {
                            notes = history['notes'];
                        }

                        //appends the history to the table
                        var newHistory = "";
                        if (history['admin'])
                            newHistory = "<tr class='history_row record" + account_id + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + account_id + "</td><td class='text-center phone'>" + notes + "</td>" + "<td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        else
                            newHistory = "<tr class='history_row record" + account_id + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + account_id + "</td><td class='text-center phone'>" + notes + "</td><td class='text-center'>" + time + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        $(newHistory).insertAfter('#work_history_table tr:eq(1)');

                        if (history['filename'] != null) {
                            $("#verified_file").val(null);
                            $("<tr><td style='font-size:15px'>" + history['filename'] + "</td><td style='font-size:10px'><a class='btn btn-info' href='downloadActive/" + history['fileid'] + "'>Download</a></td><td style='font-size:10px'><button class='btn btn-danger' type='button' onClick='deleteOverlay(" + data['fileid'] + ")'>Delete</button></td></tr>").insertAfter('#active_files tr:eq(0)');
                        }
                        //update attempts and color
                        attempts = history['count'] || 0;
                        $("#count").html(attempts);
                        $("#countAttempts").val(attempts);
                        checkColors();

                        //reset is_attempt value
                        $("#is_attempt").val(0);

                        //reset account timer
                        $("#seconds-spent").val(0);
                        sec = 0;


                        if (history['closed']) {
                            $.LoadingOverlay('hide');
                            swal("Lead Closed Successfully!", {
                                icon: "success",
                                allowOutsideClick: false
                            });
                            $.LoadingOverlay('show');
                            if (history['admin']) {

                                window.history.back();
                                $.LoadingOverlay('show');

                            } else {
                                var message = 'account has been closed';
                                window.location.href = '/agent/newActiveAccounts/';
                            }
                        } else {
                            $.LoadingOverlay('hide');
                            swal("Lead Updated Successfully!", {
                                icon: "success"
                            });
                        }


                    }, error: function (err) {

                        $.LoadingOverlay('hide');
                        $(".lengthError").remove();
                        if (err.status == 419) {
                            location.reload();
                        }
                        if (err.status == 422) { // when status code is 422, it's a validation issue
                            console.log(err.responseJSON);
                            // $('#error').fadeIn().html(err.responseJSON.message);

                            // you can loop through the errors object and show it to the user
                            console.warn(err.responseJSON.errors);
                            // display errors on each form field
                            $.each(err.responseJSON.errors, function (i, error) {
                                var message = error[0].slice(error[0].indexOf('may'));
                                message = "This field " + message;
                                var el = $(document).find('[name="' + i + '"]');
                                el = el.parent();

                                el.after($('<div class="lengthError"><span style="color: red;">' + message + '</span><br><br></div>'));
                            });
                        }
                    }


                });
            }
            else {
                swal("Lead not updated!");
            }

        });
    });
})

$(document).ready(function () {
    $('#verified_file').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size / 1024 / 1024;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            if (fileSize > 25) //check file size
            {
                swal({
                    title: "File size too large!",
                    text: "File size cannot exceed 25mbs",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }
        }
    })
});

//auto-update worked history based on call/fax/email actions
$(document).ready(function () {

    $('.input-phone').click(function (e) {
        $.LoadingOverlay('show');
        setTimeout($.LoadingOverlay('hide'), 500);

        var phone = $(this).parent().find('.form-control').val();

        if (phone == '') {
            swal("Please enter a phone number");
            return;
        }

        check = checkBlocked(phone, 'phone_number');
        if (check == true) {
            swal("This Number is blocked");
            return;
        }
        checkCallAttempts(phone);


    });
    //check work attempts
    function incrementAttempts() {
        $("#count").html(parseInt($('#count').html(), 10));
        var number = $("#count").html();
        // var max_attempts = $("#max_attempts").val();
        // if (number >= max_attempts) {
        //     $("#inactivate_form").submit();
        // }
    }

    //check the number of attempts and give warning if greater than 0 in 24 hours
    function checkCallAttempts(newPhone) {
        var date = new Date();
        var count = 0;
        var result = '';

        $('.date').each(function () {
            var historyDate = $(this).html()
            historyDate = historyDate.substring(0, historyDate.lastIndexOf(' '));
            historyDate = historyDate.replace(/-/g, '/');
            var newDate = new Date(historyDate);
            var timeDiff = date.getTime() - newDate.getTime();
            var diffDays = timeDiff / (1000 * 3600 * 24);

            var capcode = $(this).parent().find('.capcode').html();
            var phone = $(this).parent().find('.phone').html();
            phone = phone.substring(phone.lastIndexOf(':') + 2);
            phone = phone.replace(/[^0-9]/g, '');
            newPhone = newPhone.replace(/[^0-9]/g, '');

            if (capcode == 2210 && diffDays <= 1 && phone == newPhone) {
                count++;
            }
        })
        if (newPhone.replace(/ /g, '') == '') {
            swal("Please enter a valid phone number");
            return;
        }

        if (count == 0) {
            var note = "Called phone number: " + newPhone;
            if ($("#note").val().length != 0) {
                $("#note").val($("#note").val() + '\n' + '\n' + note);
            } else {
                $("#note").val($("#note").val() + note);
            }
            callNumber(newPhone);
        }

        if (count > 0) {
            swal({
                title: "Warning: You Have Called This Number " + count + " time(s) in the last 24 hours.",
                text: "Are You Sure You Want to Continue?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willChange) => {
                if (willChange) {
                    callNumber(newPhone);
                    //copy note to notes field
                    var note = "Called phone number: " + newPhone;
                    if ($("#note").val().length != 0) {
                        $("#note").val($("#note").val() + '\n' + '\n' + note);
                    } else {
                        $("#note").val($("#note").val() + note);
                    }

                    $("#is_attempt").val(1);

                    incrementAttempts();

                    var id = $("#account_history_id").val();
                    newPhone = newPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
                    var note = 'Called phone number: ' + newPhone;
                    var type = $("#type").val();
                    $("#lead_data").LoadingOverlay('show', { zIndex: 10 });
                    $("#directory-data").LoadingOverlay('show', { zIndex: 10 });
                    $.post('/agent/incrementHistory',
                        {
                            phone: newPhone,
                            id: id,
                            note: note,
                            type: type,
                        },
                        function (data, status) {
                            var history = JSON.parse(data);
                            var date = history['date'];
                            var worker = document.getElementById("historyWorkedBy").innerHTML;
                            date = date.replace('T', ' ');
                            date = date.substring(0, date.lastIndexOf('.'));

                            if (history['admin']) {
                                newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                                $(newHistory).insertAfter('#work_history_table tr:eq(1)');
                            }
                            else {
                                newHistory = "<tr hidden class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                                $(newHistory).appendTo('#work_history_table');
                            }


                            $("#lead_data").LoadingOverlay('hide');
                            $("#directory-data").LoadingOverlay('hide');
                        }).fail(function (err) {

                            if (err.status == 422) {
                                //removes the console error
                                console.clear();
                                swal("Invalid Email");
                            }
                            else if (err.status == 419) {
                                location.reload();
                            }
                            return;
                        });

                }
                else {
                    swal("Call Cancelled");
                    result = false;
                }
            });
        } else {
            $("#is_attempt").val(1);
            incrementAttempts();
            newPhone = newPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");

            var id = $("#account_history_id").val();
            var note = 'Called phone number: ' + newPhone;

            $.post('/agent/incrementHistory',
                {
                    phone: newPhone,
                    id: id,
                    note: note,
                },
                function (data, status) {
                    var history = JSON.parse(data);
                    var date = history['date'];
                    date = date.replace('T', ' ');
                    date = date.substring(0, date.lastIndexOf('.'));
                    var worker = document.getElementById("historyWorkedBy").innerHTML;

                    if (history['admin']) {
                        newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        $(newHistory).insertAfter('#work_history_table tr:eq(1)');
                    } else {
                        newHistory = "<tr hidden class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                        $(newHistory).appendTo('#work_history_table');
                    }

                }).fail(function (err) {

                    if (err.status == 422) {
                        //removes the console error
                        console.clear();
                        swal("Invalid Email");
                    }
                    else if (err.status == 419) {
                        location.reload();
                    }
                    return;
                })
        }
        return result;
    }
});



var fax;
$(document).ready(function () {
    $('.input-fax').click(function () {

        fax = $(this).parent().parent().find('.form-control').val();
        if (fax == '') {
            swal("Please have at least 10 alphanumeric characters and no more than 15 before sending a fax.");
            return;
        }

        //tests to make sure there the fax is in a proper format before moving on
        faxLength = fax.replace(/[^0-9a-zA-Z]/g, '');
        faxLength = faxLength.length;
        if (faxLength < 10 || faxLength > 15) {
            swal("Please have at least 10 alphanumeric characters and no more than 15 before sending a fax.");
            return;
        }
        check = checkBlocked(fax, 'fax');
        if (check == true) {
            swal("This Fax is blocked");
            return;
        }

        allEmpty = checkForEmployeerName();

        //if the array is empty displays an error otherwise shows the select modal
        if (allEmpty) {
            swal("At Least One Name field must be filled!");
            return;
        }
        else {
            document.getElementById("sendEmailButton").hidden = true;
            document.getElementById("sendFaxButton").hidden = false;
            $('#faxNameSelectModal').modal('show');
        }
    });
});

function checkForEmployeerName(){
    //puts all potential names into an array
    var nameArry = new Array(6);
    nameArry[0] = $("#empl_name_verified").val() || '';
    nameArry[1] = $("#empl_name1").val() || '';
    nameArry[2] = $("#last_empl_name").val() || '';
    nameArry[3] = $("#empl_name").val() || '';
    nameArry[4] = $("#power_empl_name1").val() || '';
    nameArry[5] = $("#crawler_name").val() || '';

    //list of the fields origin and empties the old list
    var fieldList = ['Verified Employer Name', 'Lead Data Employer Name', 'Additional Data Employer Name',
        'Directory Data Employer Name', 'Powerlead Data Employer Name', 'Webcrawler Company Name'];
    $('#select-fax-name').empty();

    //appends non empty words into the select
    var allEmpty = true;
    for (let i = 0; i < 6; i++) {
        if (nameArry[i].replace(/ /g, '') != '') {
            allEmpty = false;
            $('#select-fax-name').append('<option value="' + nameArry[i] + '">' + fieldList[i] + ': ' + nameArry[i] + '</option>');
        }
    }

    return allEmpty;
}

function sendFax() {
    $("#is_attempt").val(1);
    //copy note to notes field
    var note = "Sent fax to: " + fax;
    if ($("#note").val().length != 0) {
        $("#note").val($("#note").val() + '\n' + '\n' + note);
    } else {
        $("#note").val($("#note").val() + note);
    }

    var company_name = $('#select-fax-name').val();
    var fullSSN = $("#fullSSN").val() || 0;
    var id = $("#account_history_id").val();
    var note = 'Sent fax to: ' + fax;

    if (company_name.replace(/ /g, '') == '') {
        swal("Please select one valid name!");
        return;
    }
    $.LoadingOverlay("show");
    $.post('/agent/incrementHistory',
        {
            fax: fax,
            id: id,
            company_name: company_name,
            fullSSN: fullSSN,
            note: note,
        },
        function (data, status) {
            var history = JSON.parse(data);

            //backend check to see if the name was still filled out
            if (history.length == 0) {
                swal("Oh No! No name was entered!");
                $('#faxNameSelectModal').modal('hide');
                return;
            }

            var date = history['date'];
            date = date.replace('T', ' ');
            date = date.substring(0, date.lastIndexOf('.'));
            var worker = document.getElementById("historyWorkedBy").innerHTML;

            if (history['admin']) {
                newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td></td></tr>";
                $(newHistory).insertAfter('#work_history_table tr:eq(1)');
            }

        }).fail(function (err) {
            $.LoadingOverlay("hide");
            if (err.status == 422) {
                //removes the console error
                console.clear();
                swal("Invalid Email");
            }
            else if (err.status == 419) {
                location.reload();
            }
            return;
        })

    swal('Fax Sent');
    $.LoadingOverlay("hide");
    $('#faxNameSelectModal').modal('hide');

}

var email;

$(document).ready(function () {
    $('.input-email').click(function () {
        email = $(this).parent().parent().find('.form-control').val();

        check = checkBlocked(email, 'email');
        if (check == true) {
            swal("This email is blocked");
            return;
        }
        else if(email == ""){
            swal("Please enter a valid email");
            return;
        }

        allEmpty = checkForEmployeerName();

        //if the array is empty displays an error otherwise shows the select modal
        if (allEmpty) {
            swal("At Least One Name field must be filled!");
            return;
        }
        else {
            document.getElementById("sendEmailButton").hidden = false;
            document.getElementById("sendFaxButton").hidden = true;
            $('#faxNameSelectModal').modal('show');
        }
    });
});

function sendEmail() {
    var email_acct_id = $("#IDHeader").html();
    var email_acct_type = $("#select-lead-type").val();
    var acct_type = $("#acct_type").html();
    var company_name = $('#select-fax-name').val();
    var fullSSN = $("#fullSSN").val() || 0;

    $.LoadingOverlay("show");
    $.post('/agent/formatEmailData',
        {
            email_acct_id: email_acct_id,
            email_acct_type: email_acct_type,
            email: email,
            acct_type: acct_type,
            company_name: company_name,
            fullSSN: fullSSN
        }).done(function () {
            $('#faxNameSelectModal').modal('hide');

            $("#is_attempt").val(1);

            //copy note to notes field
            var note = "Sent email to: " + email;
            if ($("#note").val().length != 0) {
                $("#note").val($("#note").val() + '\n' + '\n' + note);
            } else {
                $("#note").val($("#note").val() + note);
            }

            var id = $("#account_history_id").val();
            var note = 'Sent email to: ' + email;


            $.post('/agent/incrementHistory',
                {
                    email: email,
                    id: id,
                    note: note,
                },
                function (data, status) {
                    var history = JSON.parse(data);
                    var date = history['date'];
                    date = date.replace('T', ' ');
                    date = date.substring(0, date.lastIndexOf('.'));
                    var worker = document.getElementById("historyWorkedBy").innerHTML;

                    if (history['admin']) {
                        newHistory = "<tr class='history_row record" + history['active_account_id'] + "'><td class='text-center date'>" + date + "</td><td class='text-center'>" + worker + "</td><td class='text-center'>" + history['active_account_id'] + "</td><td class='text-center phone'>" + history['notes'] + "</td>" + "<td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center'></td></tr>";
                        $(newHistory).insertAfter('#work_history_table tr:eq(1)');
                    }
                })
            swal('Email Sent', {});
            $.LoadingOverlay("hide");

        }).fail(function (err) {
            $.LoadingOverlay("hide");

            if (err.status == 422) {
                //removes the console error
                console.clear();
                swal("Invalid Email");
            }
            else if (err.status == 419) {
                location.reload();
            }
            return;
        })
}


function convertState(input) {

    var states = [
        ['Alabama', 'AL'],
        ['Alaska', 'AK'],
        ['American Samoa', 'AS'],
        ['Arizona', 'AZ'],
        ['Arkansas', 'AR'],
        ['Armed Forces Americas', 'AA'],
        ['Armed Forces Europe', 'AE'],
        ['Armed Forces Pacific', 'AP'],
        ['California', 'CA'],
        ['Colorado', 'CO'],
        ['Connecticut', 'CT'],
        ['Delaware', 'DE'],
        ['District Of Columbia', 'DC'],
        ['Florida', 'FL'],
        ['Georgia', 'GA'],
        ['Guam', 'GU'],
        ['Hawaii', 'HI'],
        ['Idaho', 'ID'],
        ['Illinois', 'IL'],
        ['Indiana', 'IN'],
        ['Iowa', 'IA'],
        ['Kansas', 'KS'],
        ['Kentucky', 'KY'],
        ['Louisiana', 'LA'],
        ['Maine', 'ME'],
        ['Marshall Islands', 'MH'],
        ['Maryland', 'MD'],
        ['Massachusetts', 'MA'],
        ['Michigan', 'MI'],
        ['Minnesota', 'MN'],
        ['Mississippi', 'MS'],
        ['Missouri', 'MO'],
        ['Montana', 'MT'],
        ['Nebraska', 'NE'],
        ['Nevada', 'NV'],
        ['New Hampshire', 'NH'],
        ['New Jersey', 'NJ'],
        ['New Mexico', 'NM'],
        ['New York', 'NY'],
        ['North Carolina', 'NC'],
        ['North Dakota', 'ND'],
        ['Northern Mariana Islands', 'NP'],
        ['Ohio', 'OH'],
        ['Oklahoma', 'OK'],
        ['Oregon', 'OR'],
        ['Pennsylvania', 'PA'],
        ['Puerto Rico', 'PR'],
        ['Rhode Island', 'RI'],
        ['South Carolina', 'SC'],
        ['South Dakota', 'SD'],
        ['Tennessee', 'TN'],
        ['Texas', 'TX'],
        ['US Virgin Islands', 'VI'],
        ['Utah', 'UT'],
        ['Vermont', 'VT'],
        ['Virginia', 'VA'],
        ['Washington', 'WA'],
        ['West Virginia', 'WV'],
        ['Wisconsin', 'WI'],
        ['Wyoming', 'WY'],
        ['United States Minor Outlying Islands', 'UM'],
    ];

    for (i = 0; i < states.length; i++) {
        if (states[i][0] == input) {
            return (states[i][1]);
        }
    }

}

//fadeout error/success message
$(document).ready(function () {
    $(".message").delay(2500).fadeOut('slow');
})

//checks for ctrl shift + c on lead employer phone
$('#empl_ph_nmbr1').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#empl_ph_nmbr1').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        var phone = $('#empl_ph_nmbr1').val();
        phone = phone.replace(/[^0-9]/g, '');
        callNumber(phone);
    }
});

//checks for ctrl shift + c on directory direct phone
$('#direct_empl_ph_nmbr').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#direct_empl_ph_nmbr').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        var phone = $('#direct_empl_ph_nmbr').val();
        phone = phone.replace(/[^0-9]/g, '');
        callNumber(phone);
    }
});

//checks for ctrl shift + c on directory verification phone
$('#verification_empl_ph_nmbr').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#verification_empl_ph_nmbr').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        var phone = $('#verification_empl_ph_nmbr').val();
        phone = phone.replace(/[^0-9]/g, '');
        callNumber(phone);
    }
});


//checks for ctrl shift + c on directory verification phone
$('#power_empl_ph_nmbr1').on('keydown', function (e) {
    if ((e.metaKey || e.ctrlKey) && (String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
        e.preventDefault();
        if ($('#power_empl_ph_nmbr1').val() == '') {
            swal('No phone number to call!', {
                dangerMode: true
            });
            return
        }
        var phone = $('#power_empl_ph_nmbr1').val();
        phone = phone.replace(/[^0-9]/g, '');
        callNumber(phone);
    }
});



//calls selected phone number
function callNumber(phoneNumber) {
    checkAttemptReload = false;

    var link = "tel:" + phoneNumber;
    window.location.href = link;

    checkAttemptReload = true;
}

//downloads the file while not calling unload
function dowloadFile(fileNumber) {
    checkAttemptReload = false;

    var link = "/agent/downloadActive/" + fileNumber;
    window.location.href = link;

    checkAttemptReload = true;
}

var verified = 0;

$('select[name="verified_capcode"]').change(function () {
    if ($('select[name="verified_capcode"] :selected').hasClass("verified")) {
        verified = 1;
    }
    else
        verified = 0;
});

function checkNonOptinal() {
    var reqlength = $('.nonOptional').length;

    var value = $('.nonOptional').filter(function () {
        var noSpaces;
        noSpaces = this.value.replace(/ /g, '');
        return noSpaces != '';
    });

    if ($("input:radio.nonOptional")[0]) {
        var radios = $("input:radio.nonOptional").length;
        var checked = $("input:radio.nonOptional:checked").length;

        if ((radios == 7 && checked < 2) || (radios < 7 && checked < 1)) {
            $('.nonOptional').css('outline', '3px solid #fd2f3e');
            $('.nonOptionalForm').css('outline', '3px solid #fd2f3e');
            return false;
        }
    }

    if ($(".nonOptionalForm")[0]) {
        reqlength++;
        var filledForm = $('.nonOptionalForm').filter(function () {
            if ($(this).is(":visible"))
                return this.value != '';
        });

        value.length = value.length + filledForm.length;
    }

    if (value.length >= 0 && (value.length !== reqlength)) {
        $('.nonOptional').css('outline', '3px solid #fd2f3e');
        $('.nonOptionalForm').css('outline', '3px solid #fd2f3e');
        return false;
    } else {
        $('.nonOptional').css('outline', 'none');
        $('.nonOptionalForm').css('outline', 'none');
        return true;
    }
}



function saveLastAAInfo() {

    var lastEmplName = document.getElementById("last_empl_name").value;
    var lastEmplAddr = document.getElementById("last_empl_addr").value;
    var lastEmplPhone = document.getElementById("last_empl_phone").value;
    var lastEmplEmail = document.getElementById("last_empl_email").value;
    var lastEmplFax = document.getElementById("last_empl_fax").value;
    var lastId = document.getElementById("currentAAid").value;
    $.get("/agent/updateAALastInfo/", {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
        emplName: lastEmplName,
        emplAddr: lastEmplAddr,
        emplPhone: lastEmplPhone,
        emplEmail: lastEmplEmail,
        emplFax: lastEmplFax,
        lastId: lastId,
    });
}
// returns var check to determine if value exists in blocked information
function checkBlocked(number, type) {
    var check = false;
    if (type == 'email') {
        number = number.toLowerCase();
    }

    $.each(blockednumbers, function (i) {
        if (blockednumbers[i]['type'] == type) {
            if (type == 'fax') {
                if (blockednumbers[i]['fax_number'] == number) {
                    check = true;
                    return false;
                } else
                    check = false;
            } else {
                if (blockednumbers[i][type] == number) {
                    check = true;
                    return false;
                } else
                    check = false;
            }
        }
    });
    return check;
}
