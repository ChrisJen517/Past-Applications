     
$(function () {
    "use strict";
    $.get('/getBarData',  // url
    function (data, jqXHR) {  // success callback

Morris.Bar({
    element: 'morris-chart-3',
    data: [{
        y: data[0][0],
        a: data[0][1],
        b: data[0][2],
        c: data[0][3]
    }, {
        y: data[1][0],
        a: data[1][1],
        b: data[1][2],
        c: data[1][3]
    }, {
        y: data[2][0],
        a: data[2][1],
        b: data[2][2],
        c: data[2][3]
    }, {
        y: data[3][0],
        a: data[3][1],
        b: data[3][2],
        c: data[3][3]
    }, {
        y: data[4][0],
        a: data[4][1],
        b: data[4][2],
        c: data[4][3]
    }, {
        y: data[5][0],
        a: data[5][1],
        b: data[5][2],
        c: data[5][3]
    }, {
        y: data[6][0],
        a: data[6][1],
        b: data[6][2],
        c: data[6][3]
    }],
    xkey: 'y',
    ykeys: ['a', 'b', 'c'],
    labels: ['A', 'B', 'C'],
    barColors:['#008cff', '#15ca20', '#75808a'],
    hideHover: 'auto',
    gridLineColor: '#eef0f2',
    resize: true
})
});
});
