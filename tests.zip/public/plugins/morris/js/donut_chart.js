     
$(function () {
    "use strict";
    
    $.get('/getData',  // url
      function (data, jqXHR) {  // success callback
        var accountChart = Morris.Donut({
            element: 'morris-chart-2',
            data: [{
                label: data[0][0],
                value: data[0][1],
    
            }, {
                label: data[1][0],
                value: data[1][1]
            }, {
                label: data[2][0],
                value: data[2][1]
            }],
            resize: true,
            colors:['#008cff', '#15ca20', '#fd3550']
        });
        accountChart.options.data.forEach(function(label, i) {
            var legendItem = $('<span></span>').text( label['label'] + " ( " +label['value'] + " )" ).prepend('<br><span>&nbsp;</span>');
            legendItem.find('span')
              .css('backgroundColor', accountChart.options.colors[i])
              .css('width', '20px')
              .css('display', 'inline-block')
              .css('margin', '5px');
            $('#legend').append(legendItem)
          });
    });


});