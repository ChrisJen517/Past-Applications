
$(function () {
    "use strict";
    
    $.get('/getLineData',  // url
    function (data, jqXHR) { 

Morris.Area({
        element: 'morris-chart-1',
        data: [{
                    period: data[0][0],
                    iphone: data[0][1],
                    ipad: data[0][2]
                }, {
                    period: data[1][0],
                    iphone: data[1][1],
                    ipad: data[1][2]
                }, {
                    period: data[2][0],
                    iphone: data[2][1],
                    ipad: data[2][2]
                }, {
                    period: data[3][0],
                    iphone: data[3][1],
                    ipad: data[3][2]
                }, {
                    period: data[4][0],
                    iphone: data[4][1],
                    ipad: data[4][2]
                }, {
                    period: data[5][0],
                    iphone: data[5][1],
                    ipad: data[5][2]
                }, {
                    period: data[6][0],
                    iphone: data[6][1],
                    ipad: data[6][2]
                }
                ],
        xkey: 'period',
        ykeys: ['iphone', 'ipad'],
        labels: ['iPhone', 'iPad'],
        pointSize: 3,
        fillOpacity: 0,
        pointStrokeColors:['#008cff', '#15ca20'],
        behaveLikeLine: true,
        gridLineColor: '#e0e0e0',
        lineWidth: 3,
        hideHover: 'auto',
        lineColors: ['#008cff', '#15ca20'],
        resize: true,
        parseTime: false,
        
    })
});

});