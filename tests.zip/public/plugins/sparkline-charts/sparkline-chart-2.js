
  $(function() {
    "use strict";
    $.get('/getSparkLineData2',  // url
    function (data, jqXHR) { 
  $('#sparklinechart2').sparkline([data[0], data[1], data[2]], {
    type: 'pie',
    width: '65',
    height: '65',
    resize: true,
    sliceColors: ['#008cff', '#15ca20', '#fd3550']
})
    });
  });   