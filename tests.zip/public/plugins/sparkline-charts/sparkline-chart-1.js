
  $(function() {
    "use strict";
    $.get('/getSparkLineData1',  // url
    function (data, jqXHR) { 
$('#sparklinechart1').sparkline([ data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12]], {
    type: 'bar',
    height: '65',
    barWidth: '4',
    resize: true,
    barSpacing: '5',
    barColor: '#008cff'
})
    });
});