
  $(function() {
    "use strict";
    $.get('/getSparkLineData3',  // url
    function (data, jqXHR) { 
$("#sparklinechart3").sparkline([data[0],data[1],data[2],data[3],data[4],data[5],data[6],data[7],data[8],data[9],data[10],data[11] ], {
    type: 'line',
    width: '100',
    height: '65',
    lineColor: '#15ca20',
    fillColor: '#15ca20',
    maxSpotColor: '#15ca20',
    highlightLineColor: 'rgba(0, 0, 0, 0.2)',
    highlightSpotColor: '#15ca20'
  })
});
});