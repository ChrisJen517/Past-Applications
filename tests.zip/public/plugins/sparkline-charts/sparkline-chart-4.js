
  $(function() {
    "use strict";
    $.get('/getSparkLineData4',  // url
    function (data, jqXHR) { 
$("#sparklinechart4").sparkline([data[0], data[1], data[2], data[3], data[4], data[5], data[6], data[7], data[8], data[9], data[10], data[11], data[12]], {
    type: 'line',
    width: '100',
    height: '65',
    lineWidth: '2',
    lineColor: '#fd3550',
    fillColor: 'transparent',
    spotColor: '#fff',
    minSpotColor: undefined,
    maxSpotColor: undefined,
    highlightSpotColor: undefined,
    highlightLineColor: undefined
})
    });
  }); 
