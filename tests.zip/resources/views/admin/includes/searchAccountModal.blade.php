<div class="modal fade" id="searchAccount" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm-6" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="searchAccountLabel"> Search Account</h5>
                <button type="button" class="close"  data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form action="{{ route('searchAccounts') }}" method="GET" enctype="multipart/form-data" id="searchAccountForm" >
                    {{ csrf_field() }}
                    <div class="form-group row">
                        <div class="col-sm-12">
                            <label class="col-lg-3 col-form-label form-control-label">Type</label>
                                <label class="radio-inline"> <input type="radio" class="type_selector" name="type" id="rocky" value="rocky" checked> Rocky </label>
                                <label class="radio-inline"> <input type="radio" class="type_selector" name="type" id="directory" value="directory"> Directory </label>
                                <label class="radio-inline"> <input type="radio" class="type_selector" name="type" id="powerLead" value="powerLead"> Power Lead </label>
                        </div>
                    </div>
                    <div id="rocky_options">
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Unique ID</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchUniqueId" name="unique_Id" placeholder="Unique Id" style="width: 100%;" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">First Name</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchFirstName" name="first_name" placeholder="First Name" style="width: 100%;" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Last Name</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchLastName" name="last_name" placeholder="Last Name" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Employer</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchEmployerName" name="employer_name" placeholder="Employer Name" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Agent Queue</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchAgentQue" name="agent_que" placeholder="Agent Queue" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">SSN</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchSSN" name="SSN" placeholder="SSN" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Account ID</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchAccountId" name="account_id" placeholder="Account ID" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Case #</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchCaseNum" name="case_num" placeholder="Case #" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Client Name</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchClientName" name="client_name" placeholder="Client Name" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        @if(Auth::user()->role == 'admin')
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Corporation ID</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchCorporationId" name="corporation_id" placeholder="Corporation ID" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                        @endif
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label"style="text-decoration: underline;" data-toggle="tooltip" title="Searchs the notes on the accounts that have been worked">Keywords</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchKeyWords" name="keywords" placeholder="Keywords" onkeyup="checkEnter(event)">
                            </div>
                        </div>
                    </div>
                    <div id="directory_options" style="display: none;">
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Company Name or Alias</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchDirectoryCompanyName" name="name" placeholder="Company Name" style="width: 100%;" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Phone Number</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchDirectoryPhoneNumber" name="phone" placeholder="Phone Number" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Unique ID</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchDirectoryAccountID" name="directory_account_id" placeholder="Unique ID" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label"> Directory Agent ID</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchDirectoryAgentID" name="directory_agent_id" placeholder="Directory agent ID" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                    </div>
                    <div id="power_options" style="display:none">
                        {{-- <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Employer</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="searchEmployerName" name="powerlead_employer_name" placeholder="Employer Name" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div> --}}
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Powerlead Agent ID</label>
                            <div class="col-lg-9">
                                <input type="number" class="form-control" id="searchPowerleadAgentId" name="powerlead_agent_id" placeholder="Powerlead Agent ID" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Powerlead ID</label>
                            <div class="col-lg-9">
                                <input type="number" class="form-control" id="searchPowerleadId" name="powerlead_id" placeholder="Powerlead ID" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Rocky ID</label>
                            <div class="col-lg-9">
                                <input type="number" class="form-control" id="searchRockyId" name="rocky_id" placeholder="Rocky ID" onkeyup="checkEnter(event)" disabled>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <span style="color:red;" id="search_fill_error" hidden> Please fill at least one field </span>
                        <button id="searchSubmit" type="button" name="btnSubmit" class="btn btn-info float-right"
                            onclick="checkSearchFields()"> Search Account </button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
//makes sure at least one field is filled out
function checkSearchFields() {
    var checks_radios = $('#searchAccountForm').find(':checkbox, :radio')
    var inputs = $('#searchAccountForm').find(':input').not(checks_radios).not('[type="submit"],[type="button"],[type="reset"]'),
    filled = inputs.filter(function(){
        return $.trim($(this).val()).length > 0;
    });

    if(filled.length < 2)
        document.getElementById('search_fill_error').hidden = false;
    else{
        document.getElementById('searchAccountForm').submit();
        $.LoadingOverlay("show");
    }
}

$('[data-toggle="tooltip"]').tooltip();

//allows enter to submit the form
function checkEnter(event){
    if(event.keyCode == 13){
        checkSearchFields();
    }
}

function getActive(){
        var valueSelected = document.querySelector('#searchAccount .type_selector:checked').value;
        if (valueSelected == 'rocky'){
            $('#searchAccount #power_options').hide();
            $('#searchAccount #power_options').find('input').prop('disabled', true);
            $('#searchAccount #directory_options').hide();
            $('#searchAccount #directory_options').find('input').prop('disabled', true);
            $('#searchAccount #rocky_options').show();
            $('#searchAccount #rocky_options').find('input').prop('disabled', false);
            $('#searchAccountForm').attr('action', "{{ route('searchAccounts') }}");
        }
        if (valueSelected == 'powerLead'){
            $('#searchAccount #rocky_options').hide();
            $('#searchAccount #rocky_options').find('input').prop('disabled', true);
            $('#searchAccount #directory_options').hide();
            $('#searchAccount #directory_options').find('input').prop('disabled', true);
            $('#searchAccount #power_options').show();
            $('#searchAccount #power_options').find('input').prop('disabled', false);
            $('#searchAccountForm').attr('action', "{{ route('powerleadSearchAccount') }}");
        }
        if (valueSelected == 'directory'){
            $('#searchAccount #rocky_options').hide();
            $('#searchAccount #rocky_options').find('input').prop('disabled', true);
            $('#searchAccount #power_options').hide();
            $('#searchAccount #power_options').find('input').prop('disabled', true);
            $('#searchAccount #directory_options').show();
            $('#searchAccount #directory_options').find('input').prop('disabled', false);
            $('#searchAccountForm').attr('action', "{{ route('searchAccountsDirectoryAdmin') }}");
        }
    }
    document.querySelectorAll("#searchAccount .type_selector").forEach( input => input.addEventListener('click', getActive) );

    $('#searchAccount').on('hidden.bs.modal', function() {
        $('#searchAccount #power_options').hide();
        $('#searchAccount #power_options').find('input').prop('disabled', true);
        $('#searchAccount #directory_options').hide();
        $('#searchAccount #directory_options').find('input').prop('disabled', true);
        $('#searchAccount #rocky_options').show();
        $('#searchAccount #rocky_options').find('input').prop('disabled', false);
        $('#searchAccountForm').attr('action', "{{ route('searchAccounts') }}");
        $('#searchAccount #powerLead').prop('checked', false);
        $('#searchAccount #rocky').prop('checked', true);
        $('#searchAccount #directory').prop('checked', false);
    });
</script>
