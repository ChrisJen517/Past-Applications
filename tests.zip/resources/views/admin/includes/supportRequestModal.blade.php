<div class="modal fade" id="supportRequest" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm-6" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="supportRequestLabel"> Send A Message To A User</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body" id="supportRequestBody">
                <form action="{{route('adminNewRequest')}}" method="POST" enctype="multipart/form-data"
                    id="supportRequestForm">
                    {{ csrf_field() }}
                    <div id="supportRequestCorporationSelect">
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Corporation</label>
                            <div class="col-lg-9">
                                <select name="supportRequestCorporation" id="supportRequestCorporation"
                                    onchange="getUsersSupport()">
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="supportRequestUserSelect">
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label"
                                id="supportRequestUserLabel">User</label>
                            <div class="col-lg-9" id="supportRequestUserDiv">
                                <select name='supportRequestUserId' id='supportRequestUserId'
                                    style="text-transform: capitalize;">
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Title</label>
                        <div class="col-lg-9">
                            <input type="text" name="supportRequestTitle" id="supportRequestTitle"
                                placeholder="Write title here" style="width: 100%;" maxlength="50"
                                onkeyup="titleCountCharacters()" required>
                            <label id="titleRemainingLetters"> 0 out of 50 </label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Message</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" name="supportRequestMessage" rows="5" cols="50"
                                id="supportRequestMessage" placeholder="Write message here" maxlength="250"
                                onkeyup="messageCountCharacters()" required></textarea>
                            <label id="messageRemainingLetters"> 0 out of 250 </label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label"></label>
                        <div class="col-lg-9">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input type="submit" id="submitSupportRequest" class="btn btn-info float-right"
                            value="Send Support Request">
                </form>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script src="{{asset('plugins/jquery-validation/js/jquery.validate.min.js')}}"></script>


<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>

<script src="{{asset('js\validation\supportRequestValidate.js')}}"></script>

<script>
    $('#supportRequest').on('shown.bs.modal', function () {
        $('#supportRequestBody').LoadingOverlay("show");

        $.get('/getCoporationNames', function(data){
            //checks if there is any corporations
            if(jQuery.isEmptyObject(data[0])){
                //displays error if there are none
                $('#supportRequestCorporation').hide();
                $('#supportRequestCorporationSelect').append('<span id="noCoporationSupport"> No corporations Found </span>');
                $('#submitSupportRequest').attr("disabled", true);
                $('#supportRequestBody').LoadingOverlay("hide");

            }
            else{
                $.each(data, function(i, corporation){
                    $('#supportRequestCorporation').append('<option value="'+data[i].corporation_id+'">'+data[i].name+'</option>');
                });
                
                getUsersSupport();
            }
        });
    });

    $("#submitSupportRequest").click(function()
    {
        if($("#supportRequestForm").valid()){
            $.LoadingOverlay("show");
        }
    }); 

    function getUsersSupport(){
        $('#supportRequestBody').LoadingOverlay("show");

        var corporationSelectValue = $('#supportRequestCorporation').val();
        $('#supportRequestUserId').empty();
          
        $.get('/getAllUsers/'+corporationSelectValue, function(data){
            //checks if there is any users in the corporation
            
            if(jQuery.isEmptyObject(data[0])){
                //displays error if there are none
                $('#supportRequestUserId').hide();
                $('#noCoporationSupport').attr('hidden', false);
                $('#supportRequestBody').LoadingOverlay("hide", true);
                $('#submitSupportRequest').attr("disabled", true);
                $('#supportRequestBody').LoadingOverlay("hide", true);

            }
            else{
                $.each(data, function(i, corporation){
                    $('#supportRequestUserId').show();
                    $('#supportRequestUserId').append('<option style="text-transform: capitalize;" value="'+data[i].user_id+'">'+data[i].last_name+', '+data[i].first_name+' - '+data[i].role+'</option>');
                    $('#SupportRequestSubmit').attr("disabled", false);
                    $('#noCoporationSupport').attr('hidden', true);
                });

                $('#supportRequestBody').LoadingOverlay("hide", true);
            }
        });        
    }

    //counts the number of characters in title field
    function titleCountCharacters(){
        var count = document.getElementById('supportRequestTitle').value.length;
        document.getElementById('titleRemainingLetters').innerHTML = count + " out of 50";
        if(count == 50)
            document.getElementById('titleRemainingLetters').style.color = 'red';
        else
            document.getElementById('titleRemainingLetters').style.color = 'black';
    }
    
    //counts the number of characters in message field
    function messageCountCharacters(){
        var count = document.getElementById('supportRequestMessage').value.length;
        document.getElementById('messageRemainingLetters').innerHTML = count + " out of 250";
        if(count == 250)
            document.getElementById('messageRemainingLetters').style.color = 'red';
        else
            document.getElementById('messageRemainingLetters').style.color = 'black';
    }
</script>