<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
  <div class="brand-logo text-center">
   <a href="{{asset('/')}}">
    <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon">
  </a>
</div>
<ul class="sidebar-menu do-nicescrol">
    <li class="sidebar-header">MAIN NAVIGATION</li>
    <li>
      <a href="{{asset('/')}}" class="waves-effect">
        <i class="icon-home"></i> <span>Dashboard</span>
      </a>
    </li>
    <li>
      <a href="{{asset('admin/pages/manageAccounts')}}" class="waves-effect">
        <i class="fa fa-address-book"></i>
        <span>Manage Users</span>
      </a>
    </li>
    <li>
      <a href="{{asset('admin/pages/manageCorporations')}}" class="waves-effect">
        <i class="icon-briefcase"></i>
        <span>Manage Clients</span>
      </a>
    </li>
    <li>
      <a href="{{asset('/admin/showAccessLevel')}}" class="waves-effect">
        <i class="fa fa-lock"></i>
        <span>Manage Access  <span style="margin-left:17%">Levels</span></span>
      </a>
    </li>
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="fa fa-compass"></i>
        <span>Directory Team</span> <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu">
        <li><a href="{{asset('/admin/directory/capcodeManagement')}}"><i class="fa fa-circle-o"></i>Manage Capcodes</a></li>
        <li><a href="{{asset('/admin/directory/seeReports')}}"><i class="fa fa-circle-o"></i>Agent Performance Report</a></li>
        <li><a href="{{asset('/admin/directory/budget')}}"><i class="fa fa-circle-o"></i>Budget Report</a></li>
        <li><a href="{{asset('/admin/directory/holdingQueue')}}"><i class="fa fa-circle-o"></i>Queue Management</a></li>
        <li><a href="{{asset('/admin/directory/queueByTimezone')}}"><i class="fa fa-circle-o"></i>Queue By Timezone</a></li>
        <li><a href="{{asset('/admin/directory/followups')}}"><i class="fa fa-circle-o"></i>Followups</a></li>
        <li><a href="{{asset('/admin/directory/settings')}}"><i class="fa fa-circle-o"></i>Settings</a></li>
        <li><a href="{{asset('/admin/directory/browse')}}"><i class="fa fa-circle-o"></i>Browse Directories</a></li>
        <li><a href="{{asset('/admin/directory/closedAccounts')}}"><i class="fa fa-circle-o"></i>Closed Accounts</a></li>
      </ul>
    </li>
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="fa fa-search"></i>
        <span>Powerlead</span> <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu">
        <li><a href="{{asset('/admin/powerlead/powerleadSettings')}}"><i class="fa fa-circle-o"></i>Powerlead Settings</a></li>
        <li><a href="{{asset('/admin/powerlead/managePowerleadHolding')}}"><i class="fa fa-circle-o"></i>Powerlead Holding Queue</a></li>
        <li><a href="{{asset('/admin/powerlead/PowerleadDatedLivePeformanceReport')}}"><i class="fa fa-circle-o"></i>Live Performance</a></li>
        <li><a href="{{asset('/admin/pages/powerleadWorkHistoryDated')}}"><i class="fa fa-circle-o"></i>Closed Accounts</a></li>
        <li><a href="{{asset('/admin/powerleadDirectoryReport')}}"><i class="fa fa-circle-o"></i>Directory & Powerlead <span style="margin-left:30px">Performance</span></a></li>
        <li><a href="{{asset('/admin/powerlead/enhancedDetailReport')}}"><i class="fa fa-circle-o"></i>Enhanced Detail Report</a></li>
      </ul>
    </li>
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="fa fa-usd"></i>
        <span>Billing</span> <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu">
        <li><a href="{{asset('/admin/billing')}}"><i class="fa fa-circle-o"></i>Billing Report</a></li>
        <li><a href="{{asset('/admin/invoice')}}"><i class="fa fa-circle-o"></i>Invoice Report</a></li>
      </ul>
    </li>
    <li>
      <a href="{{asset('/admin/faxEmailReport')}}" class="waves-effect">
        <i class="fa fa-fax"></i>
        <span>Fax/Email Response <span style="margin-left:17%">Team Stats</span></span>
      </a>
    </li>
    <li>
      <a href="javaScript:void();" class="waves-effect">
      <i class="icon-envelope"></i>
      <span>Support</span> <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu">
      <li><a href="/admin/seeAllMessages"><i class="fa fa-circle-o"></i>See Support Messages</a></li>
      <li style="cursor: pointer;"><a data-toggle="modal" data-target="#supportRequest"><i class="fa fa-circle-o"></i>Send Support Message</a></li>
      </ul>
    </li>
 </ul>
</div>

<div id="sidebar-wrapper-icons">
  <div class="brand-logo text-center small-bar">
    <a href="{{asset('admin/dashboard')}}" class="small-image-wrapper">
      <img src="/images/RNN-Logo-Square.png" class="rnn-logo-small logo-icon" alt="logo icon">
    </a>
  </div>
  <ul class="sidebar-menu do-nicescrol" style="margin-top: 50px;">
    {{-- Dashboard --}}
    <li>
      <a href="/" class="nav-link waves-effect">
        <i class="icon-home"></i>
      </a>
    </li>
    {{-- Account Settings --}}
    <li>
      <a href="{{asset('admin/pages/manageAccounts')}}" class="waves-effect">
        <i class="fa fa-address-book"></i>
      </a>
    </li>
    {{-- Corporations Options --}}
    <li>
      <a href="{{asset('admin/pages/manageCorporations')}}" class="waves-effect">
        <i class="icon-briefcase"></i>
      </a>
    </li>
    {{-- Access Level Options --}}
    <li>
      <a href="{{asset('/admin/showAccessLevel')}}" class="waves-effect">
        <i class="fa fa-lock"></i>
      </a>
    </li>
     {{-- Directory Agent --}}
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="fa fa-compass"></i>
        <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu sidebar-submenu-icons" style="width: 110px;">
        <li><a href="{{asset('/admin/directory/capcodeManagement')}}">Manage Capcodes</a></li>
        <li><a href="{{asset('/admin/directory/seeReports')}}">Agent Performance Report</a></li>
        <li><a href="{{asset('/admin/directory/holdingQueue')}}">Queue Management</a></li>
        <li><a href="{{asset('/admin/directory/queueByTimezone')}}">Queue By Timezone</a></li>
        <li><a href="{{asset('/admin/directory/followups')}}">Followups</a></li>
        <li><a href="{{asset('/admin/directory/settings')}}">Browse Directories</a></li>
        <li><a href="{{asset('/admin/directory/closedAccounts')}}">Closed Accounts</a></li>
        <li><a href="{{asset('/admin/directory/browse')}}">Settings</a></li>
      </ul>
    </li>
    {{-- Powerlead Agent --}}
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="fa fa-search"></i>
        <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu sidebar-submenu-icons" style="width: 110px;">
        <li><a href="{{asset('/admin/powerlead/powerleadSettings')}}">Powerlead Settings</a></li>
        <li><a href="{{asset('/admin/powerlead/managePowerleadHolding')}}">Powerlead Holding Queue</a></li>
        <li><a href="{{asset('/admin/powerlead/PowerleadDatedLivePeformanceReport')}}">Live Performance</a></li>
        <li><a href="{{asset('/admin/pages/powerleadWorkHistoryDated')}}">Closed Accounts</a></li>
        <li><a href="{{asset('/admin/powerlead/enhancedDetailReport')}}">Enhanced Detail Report</a></li>
      </ul>
    </li>
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="fa fa-usd"></i>
        <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu sidebar-submenu-icons" style="width: 110px;">
        <li><a href="{{asset('/admin/billing')}}">Billing Report</a></li>
        <li><a href="{{asset('/admin/invoice')}}">Invoice Report</a></li>
      </ul>
    </li>
    {{-- Fax/Email Response Team Report --}}
    <li>
      <a href="{{asset('/admin/faxEmailReport')}}" class="waves-effect">
        <i class="fa fa-fax"></i>
      </a>
    </li>
     {{-- Support Options --}}
    <li>
      <a href="javaScript:void();" class="waves-effect">
        <i class="icon-envelope"></i>
        <i class="fa fa-angle-right pull-right"></i>
      </a>
      <ul class="sidebar-submenu sidebar-submenu-icons">
          <li><a href="/admin/seeAllMessages"></i>See Support Messages</a></li>
          <li style="cursor: pointer;"><a data-toggle="modal" data-target="#supportRequest"></i>Send Support Message</a></li>
      </ul>
    </li>
  </ul>
</div>

<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/popper.min.js')}}"></script>
<script src="{{asset('js/bootstrap.min.js')}}"></script>
<script src="{{asset('/plugins/simplebar/js/simplebar.js')}}"></script>
<!-- sidebar-menu js -->
<script src="{{asset('js/sidebar-menu.js')}}"></script>
<!-- simplebar js -->
