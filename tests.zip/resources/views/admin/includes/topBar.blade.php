<header class="topbar-nav">
  <nav class="navbar navbar-expand fixed-top bg-topbar">
    <ul class="navbar-nav mr-auto align-items-center">
      <li class="nav-item">
        <a class="nav-link toggle-menu" href="javascript:void();">
          <i class="icon-menu menu-icon"></i>
        </a>
      </li>
    </ul>

    <ul class="navbar-nav align-items-center right-nav-link">
      <a class="nav-link waves-effect"
        data-toggle="modal" data-target="#searchAccount">
        <i class="fa fa-search"></i><span class="badge badge-danger badge-up"></span>
      </a>
      <a class="nav-link waves-effect"
        href="/admin/seeAllMessages">
        <i class="icon-envelope-open"></i><span class="badge badge-danger badge-up" id="envelopeAlert"></span>
      </a>
      <li class="nav-item">
        <a class="nav-link dropdown-toggle dropdown-toggle-nocaret" data-toggle="dropdown" href="#">
          <span class="user-profile"><img id="userImage" @if(file_exists(public_path('/ProfilePictures'.'/'.Auth::user()->user_id.'/avatar.png'))) src="{{asset('ProfilePictures/'.Auth::user()->user_id.'/avatar.png?'.time())}}"
                                                         @else src="https://via.placeholder.com/110x110" @endif class="img-circle"
              alt="user avatar"></span>
        </a>
        <ul class="dropdown-menu dropdown-menu-right">
          <li class="dropdown-item user-details">
              <div class="media">
                <div class="avatar"><img id="userImage" class="align-self-start mr-3" @if(file_exists(public_path('/ProfilePictures'.'/'.Auth::user()->user_id.'/avatar.png'))) src="{{asset('ProfilePictures/'.Auth::user()->user_id.'/avatar.png?'.time())}}"
                                                            @else src="https://via.placeholder.com/110x110" @endif
                alt="user avatar"></div>
                <div class="media-body">
                  <h6 class="mt-2 user-title">{{ Auth::user()->first_name }} {{ Auth::user()->last_name }}</h6>
                  <p class="user-subtitle">{{ Auth::user()->email }}</p>
                </div>
              </div>
          </li>
          <li class="dropdown-divider"></li>
          <a href="{{asset('/admin/seeAllMessages')}}"><li class="dropdown-item" style="color: inherit;"><i class="icon-envelope mr-2"></i>Messages</li></a>
          <li class="dropdown-divider"></li>
          <a href="{{asset('/accountSettings')}}"><li class="dropdown-item" style="color: inherit;"><i class="icon-wallet mr-2"></i>Account</li></a>
          <li class="dropdown-divider"></li>
          <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <li class="dropdown-item" style="color: inherit;"><i class="icon-power mr-2"></i>{{ __('Logout') }}</li>
          </a>
        </ul>
      </li>
      <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
        @csrf
    </form>
    </ul>
  </nav>
</header>

<script>
  window.onload = function() {
    recheckMessage();
    //setInterval(recheckMessage, 30000);
  }

  function recheckMessage() {
    $.ajax({
      type: 'get',
      url: "{{ asset('/admin/getTotalNewMessages')}}",
      data: $('form').serialize(),
      dataType : 'json',
      success : function (result) {
        if(result != null){
          if(result != 0){
            document.getElementById('envelopeAlert').innerHTML = String(result);
          }
          else
            document.getElementById('envelopeAlert').innerHTML = "";
        }
      },
    });
  }
</script>