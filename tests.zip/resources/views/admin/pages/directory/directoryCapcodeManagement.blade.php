@extends('includes.basicLayout')

@section('content')


<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />

<div class="row">
    <div class="col-lg-12">
        <!-- the main card and table-->
        <div class="loader my-5 ml-5" id="loader" style="display:show">
        </div>
        <div class="capcodeCard card" style="display:none">
            <div class="card-header"><i class="fa fa-table"></i> Manage Capcodes For Directory Team
                <button class="btn btn-info float-right" id="#addCapcodeButton" data-target="#modalAddCapcode"
                    data-toggle="modal">Add Capcode</button>
                <button class="btn btn-info float-right" id="showArchived" style="margin-right: 15px;">Show Archived Capcodes</button>
            </div>
            <div id="capcodeCard">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="capcodeTable" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="15%">Capcode</th>
                                    <th width="20%">Name</th>
                                    <th width="20%">Description</th>
                                    <th width="15%">Type</th>
                                    <th width="10%">Profile Type</th>
                                    <th width="10%" class="text-center">Edit</th>
                                    <th width="10%" class="text-center">Archive</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($verifieds as $verified)
                                    @if($verified->is_archived == 0)
                                    <tr>
                                        <td class="verified">{{$verified->capcode}}</td>
                                        <td class="verified">{{$verified->name}}</td>
                                        <td class="verified">{{$verified->description}}</td>
                                        <td class="verified">{{$verified->type}}</td>
                                        <td class="verified">{{str_replace('_', ' ', $verified->profile_type)}}</td>
                                        @if(in_array($verified->capcode, $requiredCapcodes))
                                            <td class="text-center verified">N/A</td>
                                            <td class="text-center verified">N/A</td>
                                        @else
                                            <td class="text-center verified">
                                                <button class="btn btn-info"
                                                    data-id="{{$verified->capcode_id}}"
                                                    data-capcode="{{$verified->capcode}}" data-name="{{$verified->name}}"
                                                    data-description="{{$verified->description}}"
                                                    data-profile="{{$verified->profile_type}}"
                                                    data-type="{{$verified->type}}" data-toggle="modal"
                                                    data-target="#modalEditCapcode">
                                                    Edit
                                                </button>
                                            </td>
                                            <td class="text-center verified">
                                                <button class="btn btn-danger" onclick="confirmArchive({{$verified->capcode_id}})">
                                                    Archive
                                                </button>
                                            </td>
                                        @endif
                                    </tr>
                                    @endif
                                @endforeach
                                @foreach($inconclusives as $inconclusive)
                                    @if($inconclusive->is_archived == 0)
                                    <tr>
                                        <td class="inconclusive">{{$inconclusive->capcode}}</td>
                                        <td class="inconclusive">{{$inconclusive->name}}</td>
                                        <td class="inconclusive">{{$inconclusive->description}}</td>
                                        <td class="inconclusive">{{$inconclusive->type}}</td>
                                        <td class="inconclusive">N/A</td>
                                        @if(in_array($inconclusive->capcode, $requiredCapcodes))
                                            <td class="text-center inconclusive">N/A</td>
                                            <td class="text-center inconclusive">N/A</td>
                                        @else
                                            <td class="text-center inconclusive">
                                                <button class="btn btn-info"
                                                    data-id="{{$inconclusive->capcode_id}}"
                                                    data-capcode="{{$inconclusive->capcode}}"
                                                    data-name="{{$inconclusive->name}}"
                                                    data-description="{{$inconclusive->description}}"
                                                    data-type="{{$inconclusive->type}}" data-toggle="modal"
                                                    data-target="#modalEditCapcode">
                                                    Edit
                                                </button>
                                            </td>
                                            <td class="text-center inconclusive">
                                                <button class="btn btn-danger" onclick="confirmArchive({{$inconclusive->capcode_id}})">
                                                    Archive
                                                </button>
                                            </td>
                                        @endif
                                    </tr>
                                    @endif
                                @endforeach
                                @foreach($unverifieds as $unverified)
                                    @if($unverified->is_archived == 0)
                                    <tr>
                                        <td class="unverified">{{$unverified->capcode}}</td>
                                        <td class="unverified">{{$unverified->name}}</td>
                                        <td class="unverified">{{$unverified->description}}</td>
                                        <td class="unverified">{{$unverified->type}}</td>
                                        <td class="unverified">N/A</td>
                                        @if(in_array($unverified->capcode, $requiredCapcodes))
                                            <td class="text-center unverified">N/A</td>
                                            <td class="text-center unverified">N/A</td>
                                        @else
                                            <td class="text-center unverified"><button class="btn btn-info"
                                                    data-id="{{$unverified->capcode_id}}"
                                                    data-capcode="{{$unverified->capcode}}" data-name="{{$unverified->name}}"
                                                    data-description="{{$unverified->description}}"
                                                    data-type="{{$unverified->type}}" data-toggle="modal"
                                                    data-target="#modalEditCapcode">Edit</button></td>
                                            <td class="text-center unverified">
                                                <button class="btn btn-danger" onclick="confirmArchive({{$unverified->capcode_id}})">
                                                    Archive
                                                </button>
                                            </td>
                                        @endif
                                    </tr>
                                    @endif
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Capcode</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Type</th>
                                    <th>Profile Type</th>
                                    <th class="text-center">Edit</th>
                                    <th class="text-center">Archive</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
            <div id="capcodeCardAll" hidden>
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="capcodeTableAll" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th width="15%">Capcode</th>
                                    <th width="20%">Name</th>
                                    <th width="20%">Description</th>
                                    <th width="15%">Type</th>
                                    <th width="10%">Profile Type</th>
                                    <th width="10%" class="text-center">Edit</th>
                                    <th width="10%" class="text-center">Archive</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($verifieds as $verified)
                                    <tr>
                                        <td class="verified">{{$verified->capcode}}</td>
                                        <td class="verified">{{$verified->name}}</td>
                                        <td class="verified">{{$verified->description}}</td>
                                        <td class="verified">{{$verified->type}}</td>
                                        <td class="verified">{{str_replace('_', ' ', $verified->profile_type)}}</td>
                                        @if(in_array($verified->capcode, $requiredCapcodes))
                                            <td class="text-center verified">N/A</td>
                                            <td class="text-center verified">N/A</td>
                                        @else
                                            <td class="text-center verified">
                                                <button class="btn btn-info"
                                                    data-id="{{$verified->capcode_id}}"
                                                    data-capcode="{{$verified->capcode}}" data-name="{{$verified->name}}"
                                                    data-description="{{$verified->description}}"
                                                    data-profile="{{$verified->profile_type}}"
                                                    data-type="{{$verified->type}}" data-toggle="modal"
                                                    data-target="#modalEditCapcode">
                                                    Edit
                                                </button>
                                            </td>
                                            @if($verified->is_archived == 0)
                                            <td class="text-center verified">
                                                <button class="btn btn-danger" onclick="confirmArchive({{$verified->capcode_id}})">
                                                    Archive
                                                </button>
                                            </td>
                                            @else
                                            <td class="text-center verified">
                                                <button class="btn btn-danger" onclick="confirmUnarchive({{$verified->capcode_id}})">
                                                    Unarchive
                                                </button>
                                            </td>
                                            @endif
                                        @endif
                                    </tr>
                                @endforeach
                                @foreach($inconclusives as $inconclusive)
                                    <tr>
                                        <td class="inconclusive">{{$inconclusive->capcode}}</td>
                                        <td class="inconclusive">{{$inconclusive->name}}</td>
                                        <td class="inconclusive">{{$inconclusive->description}}</td>
                                        <td class="inconclusive">{{$inconclusive->type}}</td>
                                        <td class="inconclusive">N/A</td>
                                        @if(in_array($inconclusive->capcode, $requiredCapcodes))
                                            <td class="text-center inconclusive">N/A</td>
                                            <td class="text-center inconclusive">N/A</td>
                                        @else
                                            <td class="text-center inconclusive">
                                                <button class="btn btn-info"
                                                    data-id="{{$inconclusive->capcode_id}}"
                                                    data-capcode="{{$inconclusive->capcode}}"
                                                    data-name="{{$inconclusive->name}}"
                                                    data-description="{{$inconclusive->description}}"
                                                    data-type="{{$inconclusive->type}}" data-toggle="modal"
                                                    data-target="#modalEditCapcode">
                                                    Edit
                                                </button>
                                            </td>
                                            @if($inconclusive->is_archived == 0)
                                            <td class="text-center inconclusive">
                                                <button class="btn btn-danger" onclick="confirmArchive({{$inconclusive->capcode_id}})">
                                                    Archive
                                                </button>
                                            </td>
                                            @else
                                            <td class="text-center inconclusive">
                                                <button class="btn btn-danger" onclick="confirmUnarchive({{$inconclusive->capcode_id}})">
                                                    Unarchive
                                                </button>
                                            </td>
                                            @endif
                                        @endif
                                    </tr>
                                @endforeach
                                @foreach($unverifieds as $unverified)
                                    <tr>
                                        <td class="unverified">{{$unverified->capcode}}</td>
                                        <td class="unverified">{{$unverified->name}}</td>
                                        <td class="unverified">{{$unverified->description}}</td>
                                        <td class="unverified">{{$unverified->type}}</td>
                                        <td class="unverified">N/A</td>
                                        @if(in_array($unverified->capcode, $requiredCapcodes))
                                            <td class="unverified">N/A</td>
                                            <td class="unverified">N/A</td>
                                        @else
                                            <td class="text-center unverified"><button class="btn btn-info"
                                                    data-id="{{$unverified->capcode_id}}"
                                                    data-capcode="{{$unverified->capcode}}" data-name="{{$unverified->name}}"
                                                    data-description="{{$unverified->description}}"
                                                    data-type="{{$unverified->type}}" data-toggle="modal"
                                                    data-target="#modalEditCapcode">Edit</button></td>
                                            @if($unverified->is_archived == 0)
                                                <td class="text-center unverified">
                                                    <button class="btn btn-danger" onclick="confirmArchive({{$unverified->capcode_id}})">
                                                        Archive
                                                    </button>
                                                </td>
                                            @else
                                                <td class="text-center unverified">
                                                    <button class="btn btn-danger" onclick="confirmUnarchive({{$unverified->capcode_id}})">
                                                        Unarchive
                                                    </button>
                                                </td>
                                            @endif
                                        @endif
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <th>Capcode</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Type</th>
                                    <th class="text-center">Edit</th>
                                    <th class="text-center">Archive</th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="modalEditCapcode" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm-6 modal-dialog-centered" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="myModalLabel">Edit Capcode</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form id="user_information_form" action="{{route('updateAdminCapcodeDirectory')}}" method="POST"
                    enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <input type="hidden" name="_token" id="csrf-token" value="{{ Session::token() }}" />
            <input type="hidden" id="capcode_id" name="capcode_id" value="">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Capcode</label>
                        <div class="col-lg-9">
                            <input class="form-control" id="capcode" name="capcode" type="number" min='0' max='999999'
                                value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Name</label>
                        <div class="col-lg-9">
                            <input class="form-control" id="name" name="name" type="text" maxlength="255" value="">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" id="description" name="description" maxlength="255" value=""></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Type</label>
                        <div class="col-lg-9">
                            <select class="form-control" id="type_edit" name="type" type="text" onchange="changeType('type_edit', 'profile_type_edit')">
                                <option value="verified">Verified</option>
                                <option value="inconclusive">Inconclusive</option>
                                <option value="unverified">Unverified</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="profile_type_edit" hidden>
                        <label class="col-lg-3 col-form-label form-control-label">Profile Type</label>
                        <div class="col-lg-9">
                            <select class="form-control" id="profile_type" name="profile_type" type="text">
                                <option value="phone_other_profile">Phone/Other Profile</option>
                                <option value="fax_profile">Fax Profile</option>
                                <option value="email_profile">Email Profile</option>
                                <option value="ivr_profile">IVR Profile</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input id="update-capcode-button" type="submit" name="" class="btn btn-info float-right"
                            value="submit">
                </form>
                <button id="closeCapcodeModal" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</div>

<div class="modal fade" id="modalAddCapcode" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm-6 modal-dialog-centered" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="myModalLabel">Add Capcode</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form id="add_capcode_form" action="{{route('addAdminCapcodeDirectory')}}" method="POST"
                    enctype="multipart/form-data">
                    {{ csrf_field() }}
                    <input type="hidden" id="capcode_id" name="capcode_id" value="">
                    <input type="hidden" id="corp_id" name="corp_id" value="">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Capcode</label>
                        <div class="col-lg-9">
                            <input class="form-control" id="capcode" name="capcode" type="number" min='0' max='999999'
                        value="{{old('capcode')}}">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Name</label>
                        <div class="col-lg-9">
                            <input class="form-control" id="name" name="name" type="text" maxlength="255" value="">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" id="description" name="description" maxlength="255" value=""></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Type</label>
                        <div class="col-lg-9">
                            <select class="form-control" id="type_add" name="type" type="text" onchange="changeType('type_add', 'profile_type_add')">
                                <option value="verified">Verified</option>
                                <option value="inconclusive">Inconclusive</option>
                                <option value="unverified">Unverified</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="profile_type_add">
                        <label class="col-lg-3 col-form-label form-control-label">Profile Type</label>
                        <div class="col-lg-9">
                            <select class="form-control" id="profile_type" name="profile_type" type="text">
                                <option value="phone_other_profile">Phone/Other Profile</option>
                                <option value="fax_profile">Fax Profile</option>
                                <option value="email_profile">Email Profile</option>
                                <option value="ivr_profile">IVR Profile</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <input id="update-capcode-button" type="submit" name="" class="btn btn-info float-right"
                            value="submit">
                </form>
                        <button id="closeCapcodeModal" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
            </div>
        </div>
    </div>
</div>



<script src="{{asset('js/validation/userFormValidate.js')}}"></script>
<script src="{{asset('js/validation/validateCapcodes.js?'.time())}}"></script>
<script src="{{asset('plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

<script>
    $('#modalEditCapcode').on('show.bs.modal', function (e) {
        var opener=e.relatedTarget;

        var id=$(opener).attr('data-id');
        var corpId=$(opener).attr('data-corpId');
        var capcode=$(opener).attr('data-capcode');
        var name=$(opener).attr('data-name');
        var description=$(opener).attr('data-description');
        var type=$(opener).attr('data-type');

        $('#capcode_id').val(id);
        $('#corporation_id').val(corpId);
        $('#capcode').val(capcode);
        $('#name').val(name);
        $('#description').val(description);
        $('#type_edit').val(type);

        if(type == 'verified'){
            var profileType = $(opener).attr('data-profile');
            document.getElementById("profile_type_edit").hidden = false;
            $('#profile_type').val(profileType);
        }
        else{
            document.getElementById("profile_type_edit").hidden = true;
        }
    });

    function changeType(capcodeType, profileType){
        type = $("#"+capcodeType).val();
        if(type == 'verified'){
            document.getElementById(profileType).hidden = false;
        }
        else{
            document.getElementById(profileType).hidden = true;
        }
    }

    $('#modalAddCapcode').on('show.bs.modal', function (e) {

        var opener=e.relatedTarget;

        var corpId=$(opener).attr('data-corpId');
        $('#corp_id').val(corpId);
    });

    $("#user_information_form").submit(function(e){

        if($("#capcode").val() != '' && $("#name").val() != '')
        {
            $(this).LoadingOverlay('show');
        }
    })

    $("#add_capcode_form").submit(function(e){
        var capcode = $(this).find("#capcode").val().length;
        var name = $(this).find("#name").val().length;
        if(capcode != 0 && name != 0)
        {
            $(this).LoadingOverlay('show');
        }
    });

    function confirmArchive(capcodeId) {
        // console.log(capcodeId);
        urlLink = "/admin/directory/archiveCapcode/"+capcodeId;
        swal({
            title: "Are you sure?",
            text: "You are about to archive this capcode.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willArchive) => {
            if (willArchive) {
                window.location = urlLink;
                $.LoadingOverlay("show");
            } else {
            swal("Capcode was not archived!");
            }
        });
    }

    function confirmUnarchive(capcodeId) {
        urlLink = "/admin/directory/archiveCapcode/"+capcodeId;
        swal({
            title: "Are you sure?",
            text: "You are about to unarchive this capcode.",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
        .then((willUnarchive) => {
            if (willUnarchive) {
                window.location = urlLink;
                $.LoadingOverlay("show");
            } else {
            swal("Capcode was not unarchived!");
            }
        });
    }
</script>
@endsection
