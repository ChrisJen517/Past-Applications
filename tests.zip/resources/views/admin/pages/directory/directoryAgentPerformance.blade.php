@extends('includes.basicLayout')
@section('content')
<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<div class="row">
    <div class="col-lg-12"> <!-- agent comparison-->
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Agent Comparison <span>{{$timeMessage}}</span>
                <form id="directoryAgentPerformanceTime" action="{{route('adminSeeReportDirectoryTime')}}" method="GET"
                enctype="multipart/form-data" autocomplete="off" style="float:right; margin-bottom:0px;">
                {{ csrf_field() }}
                    <select name="agent" id="agent">
                        <option value="all" selected> - Leave Blank For All Agents - </option>
                        @if($agents != null)
                            @foreach ($agents as $agent)
                                <option value="{{$agent['id']}}">{{$agent['id']}}: {{$agent['name']}} </option>
                            @endforeach
                        @endif
                    </select>
                    <label for="from">From</label>
                    <input type="text" id="from" name="from" placeholder="Leave Blank For Last Week">
                    <label for="to">to</label>
                    <input type="text" id="to" name="to" placeholder="Leave Blank For Today">
                    <input id="changeDate" type="submit" name="submit" class="btn-sm btn-info" value="Change Date">
                </form>
            </div>
            <div class="card-body">
                @if(!empty($compare))
                    <div id="stacked_chart" style="width: 100%; height: 300px; align:center;"></div>
                @else
                    <h4 style="margin-left: 30px;">No accounts worked yet!</h4>
                @endif
            </div>
        </div>
    </div>
</div>

@if($data == null)
    <div class="row">
        <div class="col-lg-12"> <!-- the main card and table-->
            <div class="card">
                <div class="card-header"><i class="fa fa-table"></i> No Data Avaliable
                </div>
            </div>
        </div>
    </div>
@else
    <div class="row">
        <div class="col-lg-12"> <!-- the main card and table-->
            <div class="card">
                <div class="card-header"><i class="fa fa-table"></i> Agent Performance <span>{{$timeMessage}}</span></div>
                <div class="card-body">
                    <div class="hidden-table-wrapper" hidden>
                        <table id="hidden-table" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width:8%">Agent ID</th>
                                    <th>Name</th>
                                    <th>Total Calls</th>
                                    <th>Total Worked</th>
                                    <th>Total Inconclusive</th>
                                    <th>Total Verified</th>
                                    <th>Total Unverified</th>
                                    <th>Total Closed</th>
                                    <th>Closed Verification %</th>
                                    <th>Closed Unverification %</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php  $totalInconclusive = 0; $totalVerified = 0; $totalUnverified = 0;  $followup = 0; $totalCalls = 0;?>
                                @foreach ($data[0] as $agent)
                                @if($agent['callsMade'] + $agent['unverified'] + $agent['verified'] + $agent['inconclusive'] != 0)
                                    <?php
                                        $totalInconclusive = $totalInconclusive + $agent['inconclusive'];
                                        $totalVerified = $totalVerified + $agent['verified'];
                                        $totalUnverified = $totalUnverified + $agent['unverified'];
                                        $followup = $followup + $agent['followup'];
                                        $totalCalls += $agent['callsMade'];
                                    ?>
                                    <tr>
                                        <td>{{$agent['id']}}</td>
                                        <td>{{$agent['name']}} </td>
                                        <td>{{$agent['callsMade']}}</td>
                                        <td>{{$agent['unverified'] + $agent['verified'] + $agent['inconclusive']}}</td>
                                        <td class="inconclusive">{{$agent['inconclusive']}}</td>
                                        <td class="verified">{{$agent['verified']}}</td>
                                        <td class="unverified">{{$agent['unverified']}}</td>
                                        <td>{{$agent['unverified'] + $agent['verified']}}</td>
                                        <?php $total = $agent['unverified'] + $agent['verified'] + $agent['inconclusive']?>
                                        @if($total != 0)
                                            <?php $percent = ($agent['verified']/$total)*100 ?>
                                            <td>{{bcdiv($percent, 1, 2)}}%</td>
                                        @else
                                            <td>0.00%</td>
                                        @endif
                                        @if($total != 0)
                                            <?php $percent = ($agent['unverified']/$total)*100 ?>
                                            <td>{{bcdiv($percent, 1, 2)}}%</td>
                                        @else
                                            <td>0.00%</td>
                                        @endif
                                    </tr>
                                @endif
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <?php $total = $totalInconclusive + $totalVerified + $totalUnverified?>
                                    <th>Total</th>
                                    <th></th>
                                    <th>{{$totalCalls}}</th>
                                    <th>{{$total}}</th>
                                    <th class="inconclusive">{{$totalInconclusive}}</th>
                                    <th class="verified">{{$totalVerified}}</th>
                                    <th class="unverified">{{$totalUnverified}}</th>
                                    <th>{{$totalUnverified + $totalVerified}}</th>
                                    @if($total != 0)
                                        <?php $percent = ($totalVerified/$total)*100 ?>
                                        <th>{{bcdiv($percent, 1, 2)}}%</th>
                                    @else
                                        <th>0.00%</th>
                                    @endif
                                    @if($total != 0)
                                    <?php $percent = ($totalUnverified/$total)*100 ?>
                                    <th>{{bcdiv($percent, 1, 2)}}%</th>
                                @else
                                    <th>0.00%</th>
                                @endif
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                    <div class="table-responsive" id="accountCard">
                        <table id="example" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width:8%">Agent ID</th>
                                    <th>Name</th>
                                    <th>Total Calls</th>
                                    <th>Total Worked</th>
                                    <th>Total Inconclusive</th>
                                    <th>Total Verified</th>
                                    <th>Total Unverified</th>
                                    <th>Total Closed</th>
                                    <th>Closed Verification %</th>
                                    <th>Closed Unverification %</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data[0] as $agent)
                                    <tr>
                                        <td>{{$agent['id']}}</td>
                                        <td>{{$agent['name']}} </td>
                                        <td>{{$agent['callsMade']}}</td>
                                        <td>{{$agent['unverified'] + $agent['verified'] + $agent['inconclusive']}}</td>
                                        <td class="inconclusive">{{$agent['inconclusive']}}</td>
                                        <td class="verified">{{$agent['verified']}}</td>
                                        <td class="unverified">{{$agent['unverified']}}</td>
                                        <td>{{$agent['unverified'] + $agent['verified']}}</td>
                                        <?php $total = $agent['unverified'] + $agent['verified'] + $agent['inconclusive']?>
                                        @if($total != 0)
                                            <?php $percent = ($agent['verified']/$total)*100 ?>
                                            <td>{{bcdiv($percent, 1, 2)}}%</td>
                                        @else
                                            <td>0.00%</td>
                                        @endif
                                        @if($total != 0)
                                            <?php $percent = ($agent['unverified']/$total)*100 ?>
                                            <td>{{bcdiv($percent, 1, 2)}}%</td>
                                        @else
                                            <td>0.00%</td>
                                        @endif
                                    </tr>
                                @endforeach
                            </tbody>
                            <tfoot>
                                <tr>
                                    <?php $total = $totalInconclusive + $totalVerified + $totalUnverified?>
                                    <th>Total</th>
                                    <th></th>
                                    <th>{{$totalCalls}}</th>
                                    <th>{{$total}}</th>
                                    <th class="inconclusive">{{$totalInconclusive}}</th>
                                    <th class="verified">{{$totalVerified}}</th>
                                    <th class="unverified">{{$totalUnverified}}</th>
                                    <th>{{$totalUnverified + $totalVerified}}</th>
                                    @if($total != 0)
                                        <?php $percent = ($totalVerified/$total)*100 ?>
                                        <th>{{bcdiv($percent, 1, 2)}}%</th>
                                    @else
                                        <th>0.00%</th>
                                    @endif
                                    @if($total != 0)
                                    <?php $percent = ($totalUnverified/$total)*100 ?>
                                    <th>{{bcdiv($percent, 1, 2)}}%</th>
                                @else
                                    <th>0.00%</th>
                                @endif
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- End table-->
    <div class="row">
        <div class="col-lg-12"> <!-- the main card and table-->
            <div class="card">
                <div class="card-header"><i class="fa fa-table"></i> Calls Made by Agent <span>{{$timeMessage}}</span></div>
                <div class="card-body">
                    <div class="table-responsive" id="accountCard">
                        <table id="callsMade" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width:8%">Agent ID</th>
                                    <th>Name</th>
                                    <th>Calls Made</th>
                                    <th>Hours Worked</th>
                                    <th>Average Calls per hour</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($data[0] as $agent)
                                    <tr>
                                        <td>{{$agent['id']}}</td>
                                        <td>{{$agent['name']}}</td>
                                        <td>{{$agent['callsMade']}}</td>
                                        <td>{{$agent['hoursWorked']}}</td>
                                        <td>{{$agent['averageCalls']}}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12"> <!-- the main card and table-->
            <div class="card">
                <div class="card-header"><i class="fa fa-table"></i> Capcode Usage <span>{{$timeMessage}}</span></div>
                <div class="card-body">
                    <div class="table-responsive" id="teamCard">
                        <table id="team" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Capcode</th>
                                    <th>Uses</th>
                                    <th>Type</th>
                                    <th>Percent by type</th>
                                    <th>Percent by total</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($data[1] as $capcode)
                                    <tr @if($capcode['type'] == 'verified') class="verified" @elseif($capcode['type'] == 'unverified') class="unverified" @elseif($capcode['type'] == 'inconclusive') class="inconclusive" @endif>
                                        <td>{{$capcode['capcode']}} </td>
                                        <td>{{$capcode['count']}}</td>
                                        <td>{{$capcode['type']}}</td>
                                        @if($data[2][$capcode['type']] != 0)
                                            <?php $percent = ($capcode['count']/$data[2][$capcode['type']])*100?>
                                            <td>{{bcdiv($percent, 1, 2)}}%</td>
                                        @else
                                            <td>0.00%</td>
                                        @endif
                                        <?php $total = $data[2]['unverified'] + $data[2]['verified'] + $data[2]['inconclusive']?>
                                        @if($total != 0)
                                            <?php $percent = ($capcode['count']/$total)*100 ?>
                                            <td>{{bcdiv($percent, 1, 2)}}%</td>
                                        @else
                                            <td>0.00%</td>
                                        @endif
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div><!-- End table-->
@endif


<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="{{asset('plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>

<script>
    $(document).ready(function() {
        var date = '<?php echo $timeMessage ?>'
        var table = $('#example').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            "initComplete": function(settings, json) {
            },
        } );

        var tableHidden = $('#hidden-table').DataTable( {
            "order": [[ 0, "desc" ]],
            buttons: [
                {
                    extend: 'excel',
                    footer: true,
                    title: 'Directory Agent Performance '+date
                }
            ]
        } );

        tableHidden.buttons().container()
            .appendTo( '#example_wrapper .col-md-6:eq(0)' );

        var table2 = $('#team').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
                {
                    extend: 'excel',
                    title: 'Directory Capcode Usage '+date
                }
            ],
            "initComplete": function(settings, json) {
            },
        } );

        table2.buttons().container()
            .appendTo( '#team_wrapper .col-md-6:eq(0)' );

        var callsTable = $('#callsMade').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
                {
                    extend: 'excel',
                    title: 'Calls made by agents '+date
                }
            ],
            "initComplete": function(settings, json) {
            },
        } );

        callsTable.buttons().container()
            .appendTo( '#callsMade_wrapper .col-md-6:eq(0)' );


    });

    $( function() {
        var dateFormat = "mm/dd/yy",
        from = $( "#from" )
            .datepicker({
                changeMonth: true,
                numberOfMonths: 1,
                maxDate: new Date()
            })
            .on( "change", function() {
                to.datepicker( "option", "minDate", getDate( this ) );
            }),
            to = $( "#to" ).datepicker({
                changeMonth: true,
                numberOfMonths: 1,
                maxDate: "+1d"
            })
            .on( "change", function() {
                from.datepicker( "option", "maxDate", getDate( this ) );
            });

        function getDate( element ) {
            var date;
            try {
                date = $.datepicker.parseDate( dateFormat, element.value );
            } catch( error ) {
                date = null;
            }

            return date;
        }
    } );

    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    window.addEventListener('resize', drawChart);
    var inputData = {!! json_encode($compare) !!};
    function drawChart() {
        //stacked chart
        var data = [];
        data.push(['type', 'Inconclusive', 'Verified', 'Unverified', { role: 'annotation' } ]);
        inputData.forEach(element => {
            data.push([element['name'], element['inconclusive'], element['verified'], element['unverified'], '']);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            hAxis : {
        textStyle : {
            fontSize: 9 // or the number you want
        }

    },
            legend: { position: 'top', maxLines: 3 },
            bar: { groupWidth: '75%' },
            isStacked: true,
            series: {
                0: { color: 'orange' },
                1: { color: 'green' },
                2: { color: 'red' }
            }
        };

        var chart = new google.visualization.ColumnChart(document.getElementById('stacked_chart'));
        chart.draw(data, options);
    }
</script>
@endsection
