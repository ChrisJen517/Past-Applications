@extends('includes.basicLayout')
@section('content')
<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<link href="{{asset('plugins/select2/css/select2.min.css')}}" rel="stylesheet" type="text/css" />
<div class="row">

    <div class="container float-left" style="width: 31%">
        <div class="card report-info border-info border-left-sm" style="border-color: #0dceec; border-left: 1px solid; border-bottom: 1px solid; border-top: 0.5px solid; border-right: 0.5px solid;">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                    <h3 class="text-info">Directory Fresh Queue:</h3>
                        <h4 class="text-success">{{$directory_fresh['total']}}</h4>
                        <span class="info-subtext">Total Accounts</span>
                        <h4 class="text-success">{{$directory_fresh['assigned']}}</h4>
                        <span class="info-subtext">Accounts Assigned</span>
                        <h4 class="text-success">{{$directory_fresh['unassigned']}}</h4>
                        <span class="info-subtext">Accounts Unassigned</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container float-left" style="width: 31%">
        <div class="card report-info border-info border-left-sm" style="border-color: #0dceec; border-left: 1px solid; border-bottom: 1px solid; border-top: 0.5px solid; border-right: 0.5px solid;">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                    <h3 class="text-info">Directory Live Queue:</h3>
                        <h4 class="text-success">{{$directory_live['total']}}</h4>
                        <span class="info-subtext">Total Accounts</span>
                        <h4 class="text-success">{{$directory_live['assigned']}}</h4>
                        <span class="info-subtext">Accounts Assigned</span>
                        <h4 class="text-success">{{$directory_live['unassigned']}}</h4>
                        <span class="info-subtext">Accounts Unassigned</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="container float-left" style="width: 30%">
        <div class="card report-info border-info border-left-sm" style="border-color: #0dceec; border-left: 1px solid; border-bottom: 1px solid; border-top: 0.5px solid; border-right: 0.5px solid;">
            <div class="card-body">
                <div class="media">
                    <div class="media-body text-left">
                        <h3 class="text-info">Phone Verified Queue:</h3>
                        <h4 class="text-success">{{$phone_verified['total']}}</h4>
                        <span class="info-subtext">Total Accounts</span>
                        <h4 class="text-success">{{$phone_verified['assigned']}}</h4>
                        <span class="info-subtext">Accounts Assigned</span>
                        <h4 class="text-success">{{$phone_verified['unassigned']}}</h4>
                        <span class="info-subtext">Accounts Unassigned</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
@if($agents == null)
<div class="row">
    <div class="col-lg-12">
        <!-- the main card and table-->
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> No Data Found</div>
        </div>
    </div>
</div>
@else
<div class="row">
    <div class="col-lg-12">
        <!-- the main card and table-->
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Queue
                {{-- Removed the redistribute button to prevent it from being clicked --}}
                {{-- <form action="{{route('adminDirectoryRedistribute')}}" method="POST" enctype="multipart/form-data" id="redistributeForm" name="Re" style="float:right; margin-bottom:0px;">
                    {{ csrf_field() }}
                    <input id="redistribute" type="submit" name="submit" class="btn-sm btn-info" value="Redistribute Accounts">
                </form> --}}
            </div>
            <div class="card-body">
                <div class="table-responsive" id="accountCard">
                    <h4 class="text-center">
                    Total Accounts: {{$all}} <span style="margin-left:10%; margin-right:10%">
                    Unworked Accounts: {{$unworked}}</span>
                    Worked Accounts: {{$worked}}</h4>
                    <div class="hidden-table-wrapper" hidden>
                        <table id="hidden-table" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 20%;">Name</th>
                                    <th style="width: 20%;">Agent ID</th>
                                    <th style="width: 20%;">Total Worked</th>
                                    <th style="width: 20%;">Total Unworked</th>
                                    <th style="width: 20%;">Total Accounts</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($agents as $agent)
                                @if($agent['worked'] + $agent['unworked'] != 0)
                                <tr>
                                    <td>{{$agent['name']}}</td>
                                    <td>{{$agent['id']}}</td>
                                    <td>{{$agent['worked']}}</td>
                                    <td>{{$agent['unworked']}}</td>
                                    <td>{{$agent['unworked'] + $agent['worked']}}</td>
                                </tr>
                                @endif
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <table id="example" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 20%;">Name</th>
                                <th style="width: 20%;">Agent ID</th>
                                <th style="width: 20%;">Total Worked</th>
                                <th style="width: 20%;">Total Unworked</th>
                                <th style="width: 20%;">Total Accounts</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($agents as $agent)
                            <tr>
                                <td>{{$agent['name']}}</td>
                                <td>{{$agent['id']}}</td>
                                <td>{{$agent['worked']}}</td>
                                <td>{{$agent['unworked']}}</td>
                                <td>{{$agent['unworked'] + $agent['worked']}}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div><!-- End table-->
<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header text-center"><i class="fa fa-table"></i> Toss Agent Accounts</div>
            <form action="{{route('adminDirectorytossAccounts')}}" method="POST" enctype="multipart/form-data" id="toss_accounts_form">
                {{ csrf_field() }}
                <div class="card-body">
                    <div class="form-group row">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Select A Queue To Pull Accounts From</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control agent-selected" id="toss_type" name="toss_type" required>
                                <option value="">Select A Toss Type</option>
                                <option value="agent">From Agent To Agent</option>
                                <option value="queue">From Queue To Agent</option>
                                <option value="toQueue">Clear Agent Accounts</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="fromQueueSelector" style="display: none">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Select A Queue To Pull Accounts From</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control agent-selected" id="team_selected" name="team_selected">
                                <option value="fresh">Directory Fresh Accounts</option>
                                <option value="phone">Phone Verified Accounts</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="fromAgentSelector" style="display: none">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Select An Agent To Pull Accounts From</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control agent-selected" id="agent_selected" name="agent_selected">
                                @foreach($agents as $agent)
                                <option value="{{$agent['id']}}">
                                    {{$agent['id']}}: {{$agent['name']}}
                                </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="toQueueSelector" style="display: none">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Select A Queue To Give Accounts</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control" id="send_to_team" name="send_to_team">
                                <option value="fresh">Fresh Directory Accounts</option>
                                <option value="phone">Phone Verified Accounts</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="toAgentSelector" style="display: none">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Select Agent(s) To Give Accounts</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control multiple-select-send" id="send_to_agent" name="send_to_agent[]" multiple>
                                @foreach($agents as $agent)
                                <option value="{{$agent['id']}}">
                                    {{$agent['id']}}: {{$agent['name']}}
                                </option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <?php $statesAbrviations = ['', 'AL', 'AK', 'AS', 'AZ', 'AR', 'CA', 'CO', 'CT', 'DE', 'DC', 'FM', 'FL', 'GA', 'GU', 'HI', 'ID', 'IL', 'IN', 'IA', 'KS', 'KY', 'LA', 'ME', 'MH', 'MD', 'MA', 'MI', 'MN', 'MS', 'MO', 'MT', 'NE', 'NV', 'NH', 'NJ', 'NM', 'NY', 'NC', 'ND', 'MP', 'OH', 'OK', 'OR', 'PW', 'PA', 'PR', 'RI', 'SC', 'SD', 'TN', 'TX', 'UT', 'VT', 'VI', 'VA', 'WA', 'WV', 'WI', 'WY']; ?>
                        <?php $stateNames = ['All States', 'Alabama', ' Alaska', ' Arizona', ' Arkansas', ' California', ' Colorado', ' Connecticut', ' Delaware', ' Florida', ' Georgia', ' Hawaii', ' Idaho', ' Illinois', ' Indiana', ' Iowa', ' Kansas', ' Kentucky', ' Louisiana', ' Maine', ' Maryland', ' Massachusetts', ' Michigan', ' Minnesota', ' Mississippi', ' Missouri', ' Montana', ' Nebraska', ' Nevada', ' New Hampshire', ' New Jersey', ' New Mexico', ' New York', ' North Carolina', ' North Dakota', ' Ohio', ' Oklahoma', ' Oregon', ' Pennsylvania', ' Rhode Island', ' South Carolina', ' South Dakota', ' Tennessee', ' Texas', ' Utah', ' Vermont', ' Virginia', ' Washington', ' West Virginia', ' Wisconsin', ' Wyoming'] ?>
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Select A State</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control agent-selected" id="state_selected" name="state_selected">
                                @for($i = 0; $i < 50; $i++ ) <option value="{{$statesAbrviations[$i]}}">{{$stateNames[$i]}}</option>
                                    @endfor
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Maximum To Be Sent</label>
                        <div class="col-lg-8 input-group">
                            <input class="form-control" type="number" name="max_per_agent" id="max_per_agent">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Time Zone</label>
                        <div class="col-lg-8 input-group">
                            <select class="form-control agent-selected" id="time_zone" name="time_zone">
                                <option value="">All Time Zones</option>
                                @foreach($timeZones as $timeZone)
                                <option value="{{$timeZone}}">{{$timeZone}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label style="font-size: .85rem;" class="col-lg-4 col-form-label form-control-label">Unworked Only</label>
                        <div class="col-lg-8 input-group">
                            <input type="checkbox" name="unworked_check" id="unworked_check" checked>
                        </div>
                    </div>
                </div>
                <div class="modal-footer form-group row justify-content-center pt-4 pb-0">
                    <button class="btn btn-info" id="accounts_submit" style="color:white;">Update
                        Queues</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif


<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>
<script src="{{asset('plugins/select2/js/select2.min.js')}}"></script>
<script>
    $(document).ready(function() {
        var table = $('#example').DataTable({
            "order": [
                [0, "desc"]
            ],
            "pageLength": 10,
            lengthChange: false,
            autoWidth: false,
            "initComplete": function(settings, json) {}
        });

        var tableForExport = $('#hidden-table').DataTable({
            buttons: [{
                extend: 'excel',
                title: 'Directory Holding Queue'
            }]
        });

        tableForExport.buttons().container()
            .appendTo('#example_wrapper .col-md-6:eq(0)');

        $('.multiple-select-send').select2({
            placeholder: 'Select Agent(s)'
        });
    });

    $("#redistribute").click(function() {
        $.LoadingOverlay("show");
    });

    $("#toss_type").change(function(e) {
        var type = $(this).val();
        $("#fromQueueSelector").hide();
        $("#toQueueSelector").hide();
        $("#fromAgentSelector").hide();
        $("#toAgentSelector").hide();

        switch (type) {
            case "agent":
                $("#fromAgentSelector").show();
                $("#toAgentSelector").show();
                break;
            case "queue":
                $("#fromQueueSelector").show();
                $("#toAgentSelector").show();
                break;
            case "toQueue":
                $("#fromAgentSelector").show();
                //$("#toQueueSelector").show();
                break;
        }
    });

    $(document).ready(function() {
        $('#toss_accounts_form').validate({
            rules: {
                "send_to_agent[]": "required",
            },
            messages: {
                "send_to_agent[]": "Please Select at least one agent",
            }
        });

        $('#toss_accounts_form').submit(function(e) {
            if ($(this).valid()) {
                $.LoadingOverlay('show');
            }
        });
    });
</script>
@endsection
