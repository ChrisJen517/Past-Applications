@extends('includes.basicLayout')
@section('content')
<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />
<style>    
    td{
        text-align: center;
    }
</style>
<input hidden value="{{Auth::user()->open_new_tab}}" id="open_new_tab">
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <i class="fa fa-table"></i> Directory Leads
                <button class="btn btn-info float-right" data-target="#addDirectoryModal" data-toggle="modal">Add
                    Directory</button>
            </div>
            <div id="accountCard" style="display:none">
                <div class="card-body">
                    <div class="table-responsive">
                        <table id="browseDirectoryTable" class="table table-bordered table-striped" style="width:100%">
                            <thead>
                                <tr>
                                    <th class="text-center">Unique ID</th>
                                    <th class="text-center employer">Employer Name</th>
                                    <th class="text-center phone">Phone #</th>
                                    <th class="text-center">Last Worked</th>
                                    <th class="text-center">AKA</th>
                                    <th class="text-center">CAPCODE </th>
                                    <th class="text-center">DELETE</th>
                                    <th class="text-center">Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
            <div class="loader my-5 ml-5" id="loader" style="display:show">
            </div>
        </div>
    </div>
</div><!-- End table-->

<div class="modal fade" id="addDirectoryModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm-6" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="myModalLabel">Add Directory</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body" id="myModalAddBody">
                <form action="{{route('adminAddDirectory')}}" method="POST" enctype="multipart/form-data" id="Update">
                    {{ csrf_field() }}

                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Employer Name</label>
                        <div class="col-lg-8">
                            <input class="form-control" name="employer_name" type="text">
                        </div>
                    </div>

                    <div class="modal-footer">
                        <input id="addAccountButton" type="submit" name="submit" class="btn btn-info float-right"
                            value="Submit">
                </form>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
            </div>
        </div>
    </div>
</div>

<script src="{{asset('js/validation/accountFormNoReqPass.js')}}"></script>
<script src="{{asset('js/adminJs/browseDirectory.js?version=3.4')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

@endsection