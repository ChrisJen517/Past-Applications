@extends('includes.basicLayout')
@section('content')

<div class="row">
    <div class="col-lg-12"> <!-- the main card and table-->
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Directory Performance
                <form id="directoryAgentCost" action="{{route('directoryBudgetChange')}}" method="POST"
                enctype="multipart/form-data" autocomplete="off" style="float:right; margin-bottom:0px; margin-right:0px;">
                {{ csrf_field() }}
                    <label for="cost">Cost Per FTE:</label>
                    <input type="number" id="cost" name="cost" value="{{$cost}}">
                    <input id="changePrice" type="submit" name="submit" class="btn-sm btn-info" value="Change Cost">
                </form>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="accountCard">
                    <table id="example" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Month</th>
                                <th>Days In The Month</th>
                                <th style="width:5%"># Of Reps Working</th>
                                <th># Of Fax Profiles</th>
                                <th># Of Email Profiles</th>
                                <th># Of Profiles Completed</th>
                                <th style="width:8%">% Fax / Email</th>
                                <th>Average Profiles Per FTE</th>
                                <th>Average Profiles Fax / Email Per FTE</th>
                                <th style="width:6%">Cost Per FTE</th>
                                <th>Cost Per Profile</th>
                                <th>Cost Per Fax / Email Profile</th>
                                <th>Average Daily Profiles</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($months as $month)
                                <tr>
                                    <td>{{$month[0]}}</td>
                                    <td>{{$month[1]}}</td>
                                    <td style="width:5%">{{$month[2]}}</td>
                                    <td>{{$month[3]}}</td>
                                    <td>{{$month[4]}}</td>
                                    <td>{{$month[5]}}</td>
                                    <td style="width:8%">{{bcdiv($month[6]*100,1,2)}}%</td>
                                    @if($month[2] != 0)
                                        <td>{{bcdiv($month[5], $month[2],2)}}</td>
                                        <td>{{bcdiv(($month[5]*$month[6]),$month[2],2)}}</td>
                                    @else
                                        <td>0.00</td>
                                        <td>0.00</td>
                                    @endif
                                    <td style="width:6%">${{$cost}}</td>
                                    @if($month[5] != 0)
                                        <?php $costPerProfile = bcdiv($cost,$month[5],2)?>
                                        @if($costPerProfile > 0.00)
                                            <td>${{$costPerProfile}}</td>
                                        @else
                                            <td>< $0.01</td>
                                        @endif
                                    @else
                                        <td>$0.00</td>
                                    @endif

                                    @if(($month[5] != 0) && ($month[6] != 0))
                                        <?php $costPerFax = bcdiv($cost,($month[5]*$month[6]),2) ?>
                                        @if($costPerFax > 0.00)
                                            <td>${{$costPerFax}}</td>
                                        @else
                                            <td>< $0.01</td>
                                        @endif
                                    @else
                                        <td>$0.00</td>
                                    @endif

                                    @if($month[1] != 0)
                                        <td>{{bcdiv($month[5],$month[1],2)}}</td>
                                    @else
                                        <td>0.00</td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div><!-- End table-->
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Average Profiles Per FTE</div>
            <div class="card-body">
                <div id="average_FTE" style="width: 100%; height: 200px; align:center;"></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Average Profiles Fax/Email Per FTE</div>
            <div class="card-body">
                <div id="average_fax" style="width: 100%; height: 200px; align:center;"></div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Average Daily Profiles</div>
            <div class="card-body">
                <div id="average_daily" style="width: 100%; height: 200px; align:center;"></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">% Fax / Email</div>
            <div class="card-body">
                <div id="percent_fax" style="width: 100%; height: 200px; align:center;"></div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Cost Per Profile</div>
            <div class="card-body">
                <div id="cost_profile" style="width: 100%; height: 200px; align:center;"></div>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header">Cost Per Fax/Email Profile</div>
            <div class="card-body">
                <div id="cost_fax" style="width: 100%; height: 200px; align:center;"></div>
            </div>
        </div>
    </div>
</div>


<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="{{asset('plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script>

    $(document).ready(function() {
        var table = $('#example').DataTable( {
            lengthChange: false,
            "ordering": false,
            "searching": false,
            "paging": false,
            "info": false,
            buttons: [
                {
                    extend: 'excel',
                    title: 'Directory Agent Performance '
                }
            ],

        } );
        table.buttons().container()
            .appendTo( '#example_wrapper .col-md-6:eq(0)' );
    });

    $('#changePrice').click(function(){
        $.LoadingOverlay("show");
    });

    google.charts.load("current", {packages:["corechart"]});
    google.charts.setOnLoadCallback(drawChart);
    window.addEventListener('resize', drawChart);
    var inputData = {!! json_encode($months) !!};
    var cost = "<?php echo $cost ?>"
    function drawChart() {
        //average_FTE
        var data = [];
        data.push(['Month', 'Average Profiles Per FTE', { role: 'annotation' } ]);
        inputData.forEach(element => {
            if(element[2] != 0)
                data.push([element[0], element[5]/ element[2], (element[5]/element[2]).toFixed(2)]);
            else
                data.push([element[0], 0, 0]);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            legend: { position: 'top' },
            crosshair: {trigger:'both'},
            colors: ['red'],
        };

        var chart = new google.visualization.LineChart(document.getElementById('average_FTE'));
        chart.draw(data, options);
        //end average_FTE

        //average_fax
        var data = [];
        data.push(['Month', 'Average Fax/Email Profiles Per FTE', { role: 'annotation' } ]);
        inputData.forEach(element => {
            if(element[2] != 0){
                data.push([element[0], parseFloat((element[5]*element[6]/ element[2]).toFixed(2)), (element[5]*element[6]/element[2]).toFixed(2)]);
            }
            else
                data.push([element[0], 0, 0]);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            legend: { position: 'top' },
            crosshair: {trigger:'both'},
            colors: ['red'],
        };

        var chart = new google.visualization.LineChart(document.getElementById('average_fax'));
        chart.draw(data, options);
        //end average_fax

        //average_daily
        var data = [];
        data.push(['Month', 'Average Daily Profiles', { role: 'annotation' } ]);
        inputData.forEach(element => {
            if(element[1] != 0)
                data.push([element[0], element[5]/element[1], (element[5]/element[1]).toFixed(2)]);
            else
                data.push([element[0], 0, 0]);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            legend: { position: 'top' },
            crosshair: {trigger:'both'},
            colors: ['red'],
        };

        var chart = new google.visualization.LineChart(document.getElementById('average_daily'));
        chart.draw(data, options);
        //end average_daily

        //percent_fax
        var data = [];
        data.push(['Month', '%Fax/Email', { role: 'annotation' } ]);
        inputData.forEach(element => {
            data.push([element[0], element[6]*100, (element[6]*100).toFixed(2)+'%']);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            legend: { position: 'top' },
            crosshair: {trigger:'both'},
            colors: ['red'],
        };

        var chart = new google.visualization.LineChart(document.getElementById('percent_fax'));
        chart.draw(data, options);
        //end percent_fax

        //cost_profile
        var data = [];
        data.push(['Month', 'Cost Per Profile', { role: 'annotation' } ]);
        inputData.forEach(element => {
            if(element[5] != 0)
                data.push([element[0], (cost/element[5]), '$'+(cost/element[5]).toFixed(2)]);
            else
                data.push([element[0], 0, '$'+0]);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            legend: { position: 'top' },
            crosshair: {trigger:'both'},
            colors: ['red'],
        };

        var chart = new google.visualization.LineChart(document.getElementById('cost_profile'));
        chart.draw(data, options);
        //end cost_profile

        //cost_fax
        var data = [];
        data.push(['Month', 'Cost Per Fax/Email Profile', { role: 'annotation' } ]);
        inputData.forEach(element => {
            if((element[5] != 0) && (element[6] != 0))
                data.push([element[0], (cost/(element[5]*element[6])), '$'+(cost/(element[5]*element[6])).toFixed(2)]);
            else
                data.push([element[0], 0, '$'+0]);
        });

        var data = google.visualization.arrayToDataTable(data)

        var options = {
            legend: { position: 'top' },
            crosshair: {trigger:'both'},
            colors: ['red'],
        };

        var chart = new google.visualization.LineChart(document.getElementById('cost_fax'));
        chart.draw(data, options);
        //end cost_fax
    }
</script>

@endsection
