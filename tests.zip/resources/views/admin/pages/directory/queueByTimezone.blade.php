@extends('includes.basicLayout')
@section('content')
<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Directory Agent Active Queue by Timezone</div>
            <div class="card-body">
                <div class="table-responsive" id="accountCard">
                    <table id="queueByTimezoneTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 10%;">Agent ID</th>
                                <th style="width: 16%;">Name</th>
                                <th style="width: 10%;">Total Active In Queue</th>
                                <th style="width: 8%;">EST</th>
                                <th style="width: 8%;">PST</th>
                                <th style="width: 8%;">CST</th>
                                <th style="width: 8%;">MST</th>
                                <th style="width: 8%;">AKST</th>
                                <th style="width: 8%;">AST</th>
                                <th style="width: 8%;">HST</th>
                                <th style="width: 8%;">No Timezone</th>
                            </tr>
                        </thead>
                        <tbody>
                            @if(empty($totalData))
                            <p>No Active Directory Agents</p>
                            @else
                            @foreach($totalData as $data)
                            <tr>
                                <td>{{$data['id']}}</td>
                                <td>{{$data['name']}}</td>
                                <td>{{$data['totalActive']}}</td>
                                <td>{{$data['EST']}}</td>
                                <td>{{$data['PST']}}</td>
                                <td>{{$data['CST']}}</td>
                                <td>{{$data['MST']}}</td>
                                <td>{{$data['AKST']}}</td>
                                <td>{{$data['AST']}}</td>
                                <td>{{$data['HST']}}</td>
                                <td>{{$data['NF']}}</td>
                            </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    var table = $('#queueByTimezoneTable').DataTable( {
        "order": [[ 0, "desc" ]],
        lengthChange: false,
        autoWidth: false,
        dom: 'Bfrtip',
        buttons: [
            {
                extend: 'excel',
                title: 'Directory Agent Queue by Timezone'
            }
        ]
    });

});
</script>
@endsection
