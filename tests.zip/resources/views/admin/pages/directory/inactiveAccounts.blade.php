@extends('includes.basicLayout')
@section('content')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<div class="row">
    <div class="col-lg-12">
        <!-- the main card and table-->
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Verified Closed (latest <span class="verified_count">...</span> accounts)
                <form id="timeClosedDirectory" action="{{route('dirClosedAccounts')}}" method="GET"
                    enctype="multipart/form-data" autocomplete="off" style="float:right; margin-bottom:0px;">
                    {{ csrf_field() }}
                    <label for="from">From</label>
                    <input type="text" id="from" name="from" placeholder="Leave Blank For Last Week" value="{{$startTime}}">
                    <label for="to">to</label>
                    <input type="text" id="to" name="to" placeholder="Leave Blank For Today" value="{{$endTime}}">
                    <input id="changeDate" type="submit" name="submit" class="btn-sm btn-info" value="Change Date">
                </form>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="accountCard">
                    <div class="table-parent-verified" style="overflow: hidden; height: 0px; width: 100%;">
                        <table id="verifiedTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">Date Added</th>
                                    <th style="width: 5%;">Unique ID</th>
                                    <th style="width: 5%;">Agent ID</th>
                                    <th style="width: 25%;">Employer Name</th>
                                    <th style="width: 5%;">Time Zone</th>
                                    <th style="width: 15%;">Phone #</th>
                                    <th style="width: 10%;">Last Worked</th>
                                    <th style="width: 15%;">AKA</th>
                                    <th style="width: 5%;">CAPCODE</th>
                                    <th style="width: 5%;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>
                    </div>
                    <div class="loader my-5 ml-5" id="loader-verified" style="display:show"></div>
                </div>
            </div>
        </div>

    <div class="card">
        <div class="card-header"><i class="fa fa-table"></i> Unverified Closed (latest <span class="unverified_count">...</span> accounts)
        </div>
        <div class="card-body">
            <div class="table-responsive" id="accountCard">
                <div class="table-parent-unverified" style="overflow: hidden; height: 0px; width: 100%;">
                    <table id="unverifiedTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 10%;">Date Added</th>
                                <th style="width: 5%;">Unique ID</th>
                                <th style="width: 5%;">Agent ID</th>
                                <th style="width: 25%;">Employer Name</th>
                                <th style="width: 5%;">Time Zone</th>
                                <th style="width: 15%;">Phone #</th>
                                <th style="width: 10%;">Last Worked</th>
                                <th style="width: 15%;">AKA</th>
                                <th style="width: 5%;">CAPCODE</th>
                                <th style="width: 5%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader-unverified" style="display:show"></div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-header"><i class="fa fa-table"></i> Inconclusive Closed (latest <span class="inconclusive_count">...</span> accounts)
        </div>
        <div class="card-body">
            <div class="table-responsive" id="accountCard">
                <div class="table-parent-inconclusive" style="overflow: hidden; height: 0px; width: 100%;">
                    <table id="inconclusiveTable" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th style="width: 10%;">Date Added</th>
                                <th style="width: 5%;">Unique ID</th>
                                <th style="width: 5%;">Agent ID</th>
                                <th style="width: 25%;">Employer Name</th>
                                <th style="width: 5%;">Time Zone</th>
                                <th style="width: 15%;">Phone #</th>
                                <th style="width: 10%;">Last Worked</th>
                                <th style="width: 15%;">AKA</th>
                                <th style="width: 5%;">CAPCODE</th>
                                <th style="width: 5%;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader-inconclusive" style="display:show"></div>
            </div>
        </div>
    </div>
</div>
</div><!-- End table-->

<script src="{{asset('js/validation/userFormValidate.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
    $(document).ready(function() {
        var tableVerified = $('#verifiedTable').DataTable({
            "order": [[ 0,  "desc" ]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "ajax": {
                    "url": "{{ route('directoryVerifiedAccounts') }}",
                    "dataType": "json",
                    "type": "POST",
                    "data": {
                        _token: "{{csrf_token()}}",
                        startTime: "{{$startTime}}",
                        endTime: "{{$endTime}}",
                    }
            },
            "columns": [
                { "data": "created_at" },
                { "data": "directory_account_id" },
                { "data": "directory_agent_id" },
                { "data": "employer_name" },
                { "data": "time_zone" },
                {
                    "data": "direct_phone",
                    render: function(direct_phone, type, row, meta) {
                        if (direct_phone == undefined || direct_phone == null)
                            var phone = '';
                        else
                            var phone = direct_phone;

                        if (phone.trim() == '')
                            phone = row.empl_org_phone;

                        if (phone == undefined || phone == null)
                            phone = '';
                        return (
                            `<td>${phone}</td>`
                        );
                    }
                },
                { "data": "last_worked" },
                {
                    "data": "aka",
                    render: function(aka, type, row, meta) {
                        if (aka != null)
                            var replacedAka = aka.trim().replace(/\|/g, ", ");
                        else
                            var replacedAka = '';
                        return (
                            `<td>${replacedAka}</td>`
                        );
                    }
                },
                { "data": "inactive_capcode_link.capcode" },
                {
                    data: "directory_account_id",
                    class: "text-center",
                    searchable: false,
                    sortable: false,
                    render: function(directory_account_id, type, row, meta) {
                        return (
                            `
                            <td class="text-center">
                                <form action="{{ route('workAccountAdmin') }}" method="GET" enctype="multipart/form-data" @if(Auth::user()->open_new_tab == 1) target="_blank" @endif>
                                    {{ csrf_field() }}
                                    <input hidden name="type" value="inactive">
                                    <input name="accountId"
                                        value="${directory_account_id}" hidden>
                                    <input type="submit" class="btn btn-info" value="Work Account" style="margin-top: 5px">
                                </form>
                            </td>
                            `
                        );
                    }
                },
            ],
            lengthChange: true,
            "createdRow": function(row, data, dataIndex) {
                $(row).css('background-color', '#28a745').css('color', 'white');
            },
            "initComplete": function(settings, json) {
                $('#loader-verified').delay(25).fadeOut();
                $('#verifiedTable').delay(450).fadeIn();
                $(".table-parent-verified").removeAttr("style");
                $(".verified_count").text(this.fnSettings().fnRecordsTotal());
            },
        });

        tableVerified.buttons().container()
            .appendTo( '#verifiedTable_wrapper .col-md-6:eq(0)' );

        var tableUnverified = $('#unverifiedTable').DataTable({
            "order": [[ 0,  "desc" ]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "ajax": {
                    "url": "{{ route('directoryUnverifiedAccounts') }}",
                    "dataType": "json",
                    "type": "POST",
                    "data": {
                        _token: "{{csrf_token()}}",
                        startTime: "{{$startTime}}",
                        endTime: "{{$endTime}}",
                    }
            },
            "columns": [
                { "data": "created_at" },
                { "data": "directory_account_id" },
                { "data": "directory_agent_id" },
                { "data": "employer_name" },
                { "data": "time_zone" },
                {
                    "data": "direct_phone",
                    render: function(direct_phone, type, row, meta) {
                        if (direct_phone == undefined || direct_phone == null)
                            var phone = '';
                        else
                            var phone = direct_phone;

                        if (phone.trim() == '')
                            phone = row.empl_org_phone;

                        if (phone == undefined || phone == null)
                            phone = '';
                        return (
                            `<td>${phone}</td>`
                        );
                    }
                },
                { "data": "last_worked" },
                {
                    "data": "aka",
                    render: function(aka, type, row, meta) {
                        if (aka != null)
                            var replacedAka = aka.trim().replace(/\|/g, ", ");
                        else
                            var replacedAka = '';
                        return (
                            `<td>${replacedAka}</td>`
                        );
                    }
                },
                { "data": "inactive_capcode_link.capcode" },
                {
                    data: "directory_account_id",
                    class: "text-center",
                    searchable: false,
                    sortable: false,
                    render: function(directory_account_id, type, row, meta) {
                        return (
                            `
                            <td class="text-center">
                                <form action="{{ route('workAccountAdmin') }}" method="GET" enctype="multipart/form-data" @if(Auth::user()->open_new_tab == 1) target="_blank" @endif>
                                    {{ csrf_field() }}
                                    <input hidden name="type" value="inactive">
                                    <input name="accountId"
                                        value="${directory_account_id}" hidden>
                                    <input type="submit" class="btn btn-info" value="Work Account" style="margin-top: 5px">
                                </form>
                            </td>
                            `
                        );
                    }
                },
            ],
            lengthChange: true,
            "createdRow": function(row, data, dataIndex) {
                $(row).css('background-color', '#bf2821').css('color', 'white');
            },
            "initComplete": function(settings, json) {
                $('#loader-unverified').delay(25).fadeOut();
                $('#unverifiedTable').delay(450).fadeIn();
                $(".table-parent-unverified").removeAttr("style");
                $(".unverified_count").text(this.fnSettings().fnRecordsTotal());
            },
        });

        tableUnverified.buttons().container()
            .appendTo( '#unverifiedTable_wrapper .col-md-6:eq(0)' );


        var tableInconclusive = $('#inconclusiveTable').DataTable({
            "order": [[ 0,  "desc" ]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "ajax": {
                    "url": "{{ route('directoryInconclusiveAccounts') }}",
                    "dataType": "json",
                    "type": "POST",
                    "data": {
                        _token: "{{csrf_token()}}",
                        startTime: "{{$startTime}}",
                        endTime: "{{$endTime}}",
                    }
            },
            "columns": [
                { "data": "created_at" },
                { "data": "directory_account_id" },
                { "data": "directory_agent_id" },
                { "data": "employer_name" },
                { "data": "time_zone" },
                {
                    "data": "direct_phone",
                    render: function(direct_phone, type, row, meta) {
                        if (direct_phone == undefined || direct_phone == null)
                            var phone = '';
                        else
                            var phone = direct_phone;

                        if (phone.trim() == '')
                            phone = row.empl_org_phone;

                        if (phone == undefined || phone == null)
                            phone = '';
                        return (
                            `<td>${phone}</td>`
                        );
                    }
                },
                { "data": "last_worked" },
                {
                    "data": "aka",
                    render: function(aka, type, row, meta) {
                        if (aka != null)
                            var replacedAka = aka.trim().replace(/\|/g, ", ");
                        else
                            var replacedAka = '';
                        return (
                            `<td>${replacedAka}</td>`
                        );
                    }
                },
                { "data": "inactive_capcode_link.capcode" },
                {
                    data: "directory_account_id",
                    class: "text-center",
                    searchable: false,
                    sortable: false,
                    render: function(directory_account_id, type, row, meta) {
                        return (
                            `
                            <td class="text-center">
                                <form action="{{ route('workAccountAdmin') }}" method="GET" enctype="multipart/form-data" @if(Auth::user()->open_new_tab == 1) target="_blank" @endif>
                                    {{ csrf_field() }}
                                    <input hidden name="type" value="inactive">
                                    <input name="accountId"
                                        value="${directory_account_id}" hidden>
                                    <input type="submit" class="btn btn-info" value="Work Account" style="margin-top: 5px">
                                </form>
                            </td>
                            `
                        );
                    }
                },
            ],
            lengthChange: true,
            "createdRow": function(row, data, dataIndex) {
                $(row).css('background-color', 'goldenrod').css('color', 'white');
            },
            "initComplete": function(settings, json) {
                $('#loader-inconclusive').delay(25).fadeOut();
                $('#inconclusiveTable').delay(450).fadeIn();
                $(".table-parent-inconclusive").removeAttr("style");
                $(".inconclusive_count").text(this.fnSettings().fnRecordsTotal());
            },
        });

        tableInconclusive.buttons().container()
            .appendTo('#inconclusiveTable_wrapper .col-md-6:eq(0)');
    });

    $('#timeClosedDirectory').on('submit', function(e) {
        $.LoadingOverlay('show');
    });

    $( function() {
        var dateFormat = "mm/dd/yy",
        from = $( "#from" )
            .datepicker({
                changeMonth: true,
                numberOfMonths: 1,
                maxDate: new Date(),
            })
            .on( "change", function() {
            to.datepicker( "option", "minDate", getDate( this ) );
            }),
            to = $( "#to" ).datepicker({
                changeMonth: true,
                numberOfMonths: 1,
                maxDate: "+0d",
            })
            .on( "change", function() {
                from.datepicker( "option", "maxDate", getDate( this ) );
        });

        function getDate( element ) {
            var date;
            try {
                date = $.datepicker.parseDate( dateFormat, element.value );
            } catch( error ) {
                date = null;
            }

            return date;
        }
        $("#from").change();
        $("#to").change();
    });
</script>
@endsection
