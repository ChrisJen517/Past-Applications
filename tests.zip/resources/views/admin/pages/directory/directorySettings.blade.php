@extends('includes.basicLayout')
@section('content') 
<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<div class="row">
    <div class="col-lg-12"> <!-- the main card and table-->
        <div class="card">
            <form action="{{route('directorySettingsUpdate')}}" method="POST" enctype="multipart/form-data"
                id="UpdateClient">
                {{ csrf_field() }}
            <div class="card-header"><i class="fa fa-table"></i>Directory Settings</div> 
            <div class="card-body">
                <div class="container">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Max Attempts</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="max_attempts" type="number" value="{{$settings->max_attempts}}" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Max Attempts For Live Accounts</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="live_max_attempts" type="number" value="{{$settings->live_max_attempts}}" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Max Accounts Per Agent</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="max_accounts" type="number" value="{{$settings->max_accounts}}" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Auto Distribute Accounts</label>
                        <div class="col-lg-9">
                            <select name="redistribute_accounts" id="redistribute_accounts" class="form-control">
                                <option value="0" @if($settings->redistribute_accounts == 0) selected @endif>Do Not Auto Distribute Accounts</option>
                                <option value="1" @if($settings->redistribute_accounts == 1) selected @endif>Auto Distribute Accounts</option>
                            </select>
                        </div>
                    </div>
                    <input id="verified_submit" class="btn btn-lg btn-success float-right" name="submit" type="submit"
                    value="Save" />
                </form>
                </div>
            </div>
        </div>
    </div>
</div><!-- End table-->


@endsection