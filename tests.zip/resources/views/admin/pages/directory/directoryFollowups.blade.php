@extends('includes.basicLayout')
@section('content')
<link href="{{asset('css/corporateAdmin/capcodeManagement.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<div class="row">
    <div class="col-lg-12"> <!-- the main card and table-->
        <div class="card" id="followupTableCard">
            <div class="card-header">
                <i class="fa fa-table"></i> Follow Ups {{$timeMessage}}
                <form id="adminFollowupsTime" action="{{route('adminFollowupsDirectory')}}" method="GET"
                enctype="multipart/form-data" autocomplete="off" style="float:right; margin-bottom:0px;">
                {{ csrf_field() }}
                    <label for="startTime">From</label>
                    <input type="text" id="startTime" name="startTime" placeholder="Leave Blank For Today">
                    <input id="changeDate" type="submit" name="submit" class="btn-sm btn-info" value="Change Date">
                </form>
            </div>
            <div class="card-body">
                <div class="table-responsive" id="accountCard">
                    <div class="table-parent" style="overflow: hidden; height: 0px; width: 100%;">
                        <table id="followupTable" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th style="width: 12%">Last Worked</th>
                                    <th style="width: 20%">Currently Assigned Directory Agent</th>
                                    <th style="width: 6%">Unique ID</th>
                                    <th style="width: 6%">Capcode</th>
                                    <th style="width: 26%">Verification Notes</th>
                                    <th style="width: 26%">Work Notes</th>
                                    <th style="width: 10%">Work Directory</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($workedHistory as $history)
                                    <tr>
                                        <td>{{$history['last_worked']}}</td>
                                        <td>{{$history['agent']}}</td>
                                        <td>{{$history['id']}}</td>
                                        <td class="inconclusive">
                                            {{$history['capcode']}}
                                        </td>
                                        <td>{{$history['notes']}}</td>
                                        <td>{{$history['notes_worked']}}</td>
                                        <form action="{{ route('workAccountAdmin') }}" method="GET" enctype="multipart/form-data" id="workedAccount"
                                            @if(Auth::user()->open_new_tab == 1) target="_blank" @endif>
                                            {{ csrf_field() }}
                                            <td class="text-center">
                                                <input hidden name="type" value="inconclusive">
                                                <input name="accountId" id="accountId" value="{{$history['id']}}" hidden>
                                                <input type="submit" class="btn btn-info" value="Directory" id="workAccount">
                                            </td>
                                        </form>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="loader my-5 ml-5" id="loader" style="display:show"></div>
                </div>
            </div>
        </div>
    </div>
</div><!-- End table-->

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>

<script>
    $(document).ready(function() {

        var table = $('#followupTable').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
                {
                    extend: 'excel',
                    title: 'Directory Work History'
                }
            ],
            "initComplete": function(settings, json) {
                $('#loader').delay(25).fadeOut();
                $('#followupTable').delay(450).fadeIn();
                $(".table-parent").removeAttr("style");
            },
        } );

        table.buttons().container()
            .appendTo( '#example_wrapper .col-md-6:eq(0)' );

        var dateFormat = "mm/dd/yy";

        var from = $("#startTime")
        .datepicker({
            changeMonth: true,
            numberOfMonths: 1,
            maxDate: new Date()
        });

        $('#adminFollowupsTime').on('submit', function(e) {
            $.LoadingOverlay('show');
        });
    });

</script>
@endsection
