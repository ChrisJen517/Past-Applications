@extends('includes.basicLayout')
@section('content')
<div class="row">
    <div class="col-lg-12 mx-auto">
        <div class="card">
            <div class="card-body">
                <h4 class="form-header text-uppercase text-center pt-3">
                    <i class="fa fa-usd"></i>
                    TBA Billing
                </h4>
                <div class="row pt-5"> 
                    <div class="col" id="showForm">
                    {{-- <iframe width="420" height="315" src="{{ asset('images/vid.mp4') }}" frameborder="0"  allowfullscreen></iframe> --}}
                    </div>
                </div>    
            </div>
        </div>
    </div>
</div>
@endsection