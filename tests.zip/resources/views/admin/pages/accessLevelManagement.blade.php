@extends('includes.basicLayout')

@section('content')
<div class="col-lg-12">
    <div class="card">
        <div class="card-header"><i class="fa fa-table"></i> Access Permissions<button class="btn btn-info float-right" id="#addPermissionButton" data-target="#modaladdPermission" data-toggle="modal">Add Permission</button> </div>
        <div class="card-body">
            <div class="table-responsive table-striped">
                <table id="Accounts_Assigned_Table" class="table table-bordered" style="width:100%">
                    <thead>
                        <tr>
                            <th>Corporation ID</th>
                            <th>Corporation Name</th>
                            <th>Name</th>
                            <th>Description</th>
                            <th>Shortcode</th>
                            <th style="width:10%">Edit</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($access_levels as $access_level)
                            <tr>
                                <td>{{$access_level->corporation_id}}</td>
                                <td>{{$corporations->where('corporation_id',$access_level->corporation_id)->first()->name}}</td>
                                <td>{{$access_level->name}}</td>
                                <td>{{$access_level->desc}}</td>
                                <td>{{$access_level->shortcode}}</td>
                                @if(in_array($access_level->shortcode, $requiredAccessLevels))
                                    <td class="text-center">Required</td>
                                @else
                                    <td class="text-center">
                                        <button class="btn btn-info btn-sm"
                                            d-name="{{$access_level->name}}" id-name="{{$access_level->id}}"
                                            d-desc="{{$access_level->desc}}" d-shortcode="{{$access_level->shortcode}}"
                                            d-corporation_id="{{$access_level->corporation_id}}"
                                            data-toggle="modal" data-target="#myModalMod">
                                                Edit
                                        </button>
                                    </td>
                                @endif
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="modal fade" id="modaladdPermission" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-sm-6 modal-dialog-centered" role="document">
            <div class="modal-content border-0">
                <div class="modal-header bg-info">
                    <h5 class="modal-title text-white" id="myModalLabel">Add Permission</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <form id="add_capcode_form" action="{{route('addPermissionsAdmin')}}" method="POST" enctype="multipart/form-data">
                        {{ csrf_field() }}
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Name</label>
                            <div class="col-lg-9">
                                <input class="form-control" id="name" name="name" type="text" value="" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Description</label>
                            <div class="col-lg-9">
                                <textarea class="form-control" id="desc" name="desc" value="" maxlength="200"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Shortcode</label>
                            <div class="col-lg-9">
                                <input class="form-control" id="shortcode" name="shortcode" type="text" value="" onkeypress="checkKey('character_error_add')" required>
                                <span id="character_error_add" style="color:red; display:block;" hidden>Please don't use | or , in shortcodes</span>
                            </div>
                        </div>
                        <div id="corporationSelect">
                            <div class="form-group row">
                                <label class="col-lg-3 col-form-label form-control-label">Corporation</label>
                                <div class="col-lg-9">
                                    <select name="corporation_id" id="corporation_id">
                                        @foreach($corporations as $corporation)
                                        <option value="{{$corporation->corporation_id}}">{{$corporation->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <input id="update-capcode-button" type="submit" name="" class="btn btn-info float-right" value="Submit">
                    </form>
                            <button id="closePermissionModal" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        </div>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="myModalMod" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog modal-sm-6 modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header bg-info">
                    <h5 class="modal-title text-white" id="myModalLabel">Update Permission</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body" id="myModalUpdateBody">
                    <form action="{{route('updatePermissionAdmin')}}" method="POST" enctype="multipart/form-data" id="Update">
                        {{ csrf_field() }}
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Name</label>
                            <div class="col-lg-9">
                                <input class="form-control" name="name" value="" type="text" id="name" placeholder="name" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Description</label>
                            <div class="col-lg-9">
                                <textarea class="form-control" name="desc" value="" type="text" id="desc" placeholder="Description" maxlength="200"></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Shortcode</label>
                            <div class="col-lg-9">
                                <input class="form-control" type="text" value="" name="shortcode" placeholder="shortcode" onkeypress="checkKey('character_error_edit')" required>
                                <span id="character_error_edit" style="color:red; display:block;" hidden>Please don't use | or , in shortcodes</span>
                            </div>
                        </div>
                        <div hidden class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">idName</label>
                            <div class="col-lg-9">
                                <input class="form-control" type="text" value="" name="idName" placeholder="idName">
                            </div>
                        </div>
                        <div id="corporationSelect">
                            <div class="form-group row">
                                <label class="col-lg-3 col-form-label form-control-label">Corporation</label>
                                <div class="col-lg-9">
                                    <select name="corporation_id" id="corporation_id">
                                        @foreach($corporations as $corporation)
                                        <option value="{{$corporation->corporation_id}}">{{$corporation->name}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>
                </div>
                <div class="modal-footer">
                    <input id="edit_user_submit" type="submit" name="submit" class="btn btn-info float-right" value="Submit">
                </form>
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script>
    // ----------- Modal to Update Accounts
    $('#myModalMod').on('show.bs.modal', function(e) {
        // get information to update quickly to modal view as loading begins
        var opener = e.relatedTarget; //this holds the element who called the modal
        //we get details from attributes
        var idName = $(opener).attr('id-name');
        var name = $(opener).attr('d-name');
        var desc = $(opener).attr('d-desc');
        var shortcode = $(opener).attr('d-shortcode');
        var corporation_id = $(opener).attr('d-corporation_id');

        $('#Update').find('[name="corporation_id"]').val(corporation_id);
        $('#Update').find('[name="idName"]').val(idName);
        $('#Update').find('[name="name"]').val(name);
        $('#Update').find('[name="desc"]').val(desc);
        $('#Update').find('[name="shortcode"]').val(shortcode);
    });

    //makes sure the user can't enter a | or , key
    function checkKey(error){
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if ((key == "|") || (key == ",")) {
            document.getElementById(error).hidden = false;
            event.preventDefault();
            return false;
        }
        else{
            document.getElementById(error).hidden = true;
        }
    };

    $(document).ready(function() {
        var table = $('#Accounts_Assigned_Table').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            "initComplete": function(settings, json) {
            },
        } );
        table.buttons().container()
            .appendTo( '#Accounts_Assigned_Table_wrapper .col-md-6:eq(0)' );
    });

    $('#Update').submit(function(){
        $.LoadingOverlay('show');
    });
    $('#add_capcode_form').submit(function(){
        $.LoadingOverlay('show');
    });
</script>
@endsection
