@extends('includes.basicLayout')
@section('content')
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>

<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header"><i class="fa fa-table"></i> Fax/Email Response Team Stats <span>{{$timeMessage}}</span>
                <form id="directoryAgentPerformanceTime" action="{{route('faxEmailReportTime')}}" method="GET"
                enctype="multipart/form-data" autocomplete="off" style="float:right; margin-bottom:0px;">
                {{ csrf_field() }}
                    <label for="from">From</label>
                    <input type="text" id="from" name="from" placeholder="Leave Blank For Last Week">
                    <label for="to">to</label>
                    <input type="text" id="to" name="to" placeholder="Leave Blank For Today">
                    <input id="changeDate" type="submit" name="submit" class="btn-sm btn-info" value="Change Date">
                </form>
            </div>
            <div class="card-body">
                <table id="example" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Account</th>
                            <th>Name</th>
                            <th>Total Worked</th>
                            <th>Total Verified</th>
                            <th>Total Unverified</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($data as $account)
                            <tr>
                                <td>{{$account['account']}}</td>
                                <td>{{$account['name']}}</td>
                                <td>{{$account['worked']}}</td>
                                <td>{{$account['verified']}}</td>
                                <td>{{$account['unverified']}}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script src="{{asset('plugins/alerts-boxes/js/sweetalert.min.js')}}"></script>
<script>
    $(document).ready(function() {
        var table = $('#example').DataTable( {
            lengthChange: false,
            buttons: [
                {
                    extend: 'excel',
                    title: 'Fax/Email Response Team Stats'
                }
            ],

        } );
        table.buttons().container()
            .appendTo( '#example_wrapper .col-md-6:eq(0)' );
    });

    $( function() {
        var dateFormat = "mm/dd/yy",
        from = $( "#from" )
            .datepicker({
                changeMonth: true,
                numberOfMonths: 1,
                maxDate: new Date()
            })
            .on( "change", function() {
                to.datepicker( "option", "minDate", getDate( this ) );
            }),
        to = $( "#to" ).datepicker({
            changeMonth: true,
            numberOfMonths: 1,
            maxDate: "+1d"
        })
        .on( "change", function() {
            from.datepicker( "option", "maxDate", getDate( this ) );
        });

        function getDate( element ) {
            var date;
            try {
                date = $.datepicker.parseDate( dateFormat, element.value );
            } catch( error ) {
                date = null;
            }

            return date;
        }
    } );

</script>
@endsection
