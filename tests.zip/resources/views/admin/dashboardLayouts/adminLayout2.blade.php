@extends('includes.basicLayout')

@section('content')
<style>
    .chart-margin {
        margin-left: 100px !important;
    }
</style>
<!-- Basic Style for all charts-->
<div class="row">
    <div class="col-lg-12 mx-auto">
        <div class="card">
            <div class="card-header text-uppercase text-center">Total Weekly Application Usage</div>
            <div class="card-body">
                <div id="dataArray" data-array="{{$data}}" hidden></div>
                <div id="chart_div" class="col-lg-12 mx-auto" style="height: 500px;"></div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12 mx-auto">
        <div class="card">
            <div class="card-header text-uppercase text-center">Weekly Corporation Application Usage</div>
            <div class="card-body">
            <div id="corpDataArray" data-corparray="{{$corpData}}" hidden></div>
                <div id="corporation_div" class="col-lg-12 mx-auto" style="height: 500px;"></div>
            </div>
        </div>
    </div>
</div>

<div class="row">
        <div class="col-lg-12 mx-auto">
            <div class="card">
                <div class="card-header text-uppercase text-center">Weekly RNN Application Usage</div>
                <div class="card-body">
                <div id="rnnData" data-rnn="{{$rnnData}}" hidden></div>
                    <div id="rnn_div" class="col-lg-12 mx-auto" style="height: 500px;"></div>
                </div>
            </div>
        </div>
    </div>

<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<script>
    google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
      google.charts.setOnLoadCallback(drawCorporationChart);
      google.charts.setOnLoadCallback(drawRNNChart);


        var dataArray = $("#dataArray").data('array');
      function drawChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Date');
        data.addColumn('number', 'Total Hours Worked');
        data.addRows(dataArray);

        var options = {
        //   curveType: 'function',
          legend: { position: 'bottom' },
          crosshair: {trigger:'both'},
          colors: ['red'],
          vAxis: {
              title: 'Total Hours',
              titleTextStyle: {
                fontSize:22
              },
              textStyle: {
                  fontSize:20
              }
          },
          hAxis: {
              textStyle: {
                  fontSize: 18
              }
          },
          
          
        };
        var chart = new google.visualization.LineChart(document.getElementById('chart_div'));

        chart.draw(data, options);
    }
    
        var corpDataArray = $("#corpDataArray").data('corparray');
      function drawCorporationChart() {
        var data = new google.visualization.arrayToDataTable(corpDataArray);

        var options = {
        //   curveType: 'function',
          legend: { position: 'bottom' },
          crosshair: {trigger:'both'},
          vAxis: {
              title: 'Total Hours',
              titleTextStyle: {
                fontSize:22
              },
              textStyle: {
                  fontSize:20
              }
          },
          hAxis: {
              textStyle: {
                  fontSize: 18
              }
          }
          
        };

        var corporation_chart = new google.visualization.LineChart(document.getElementById('corporation_div'));

        corporation_chart.draw(data, options);

      }

      var rnnData = $("#rnnData").data('rnn');
      function drawRNNChart() {
        var data = new google.visualization.DataTable();
        data.addColumn('string', 'Date');
        data.addColumn('number', 'Total Hours Worked');
        data.addRows(rnnData);

        var options = {
        //   curveType: 'function',
          legend: { position: 'bottom' },
          crosshair: {trigger:'both'},
          vAxis: {
              title: 'Total Hours',
              titleTextStyle: {
                fontSize:22
              },
              textStyle: {
                  fontSize:20
              }
          },
          hAxis: {
              textStyle: {
                  fontSize: 18
              }
          }
        };
        var chart = new google.visualization.LineChart(document.getElementById('rnn_div'));

        chart.draw(data, options);
    }
 $(document).ready(function(){
     $('.toggle-menu').click(function(){
         $("#chart_div").toggleClass('chart-margin');
         $("#corporation_div").toggleClass('chart-margin');
         $("#rnn_div").toggleClass('chart-margin');

     })
 })
</script>
@endsection