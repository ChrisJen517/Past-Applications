<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddRemoveFieldsAsPerFinalDesignCompanies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn([
                'corp_url',
                'bank2_name',
                'bank2_address',
                'bank2_city',
                'bank2_state',
                'bank2_zip',
                'bank2_company_name',
                'bank2_company_address',
                'bank2_company_city',
                'bank2_company_state',
                'bank2_company_zip',
                'bank2_account_type',
                'bank2_routing',
                'bank2_account_number',
                'mailing_address',
                'mailing_address2',
                'mailing_city',
                'mailing_state',
                'mailing_zip'
            ]);
            $table->string('industry_type')->after('company_name');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->string('corp_url')->nullable()->default(null);
            $table->string('bank2_name')->nullable()->default(null);
            $table->string('bank2_address')->nullable()->default(null);
            $table->string('bank2_city')->nullable()->default(null);
            $table->string('bank2_state')->nullable()->default(null);
            $table->string('bank2_zip')->nullable()->default(null);
            $table->string('bank2_company_name')->nullable()->default(null);
            $table->string('bank2_company_address')->nullable()->default(null);
            $table->string('bank2_company_city')->nullable()->default(null);
            $table->string('bank2_company_state')->nullable()->default(null);
            $table->string('bank2_company_zip')->nullable()->default(null);
            $table->string('bank2_account_type')->nullable()->default(null);
            $table->string('bank2_routing')->nullable()->default(null);
            $table->string('bank2_account_number')->nullable()->default(null);
            $table->string('mailing_address')->nullable()->default(null);
            $table->string('mailing_address2')->nullable()->default(null);
            $table->string('mailing_city')->nullable()->default(null);
            $table->string('mailing_state')->nullable()->default(null);
            $table->string('mailing_zip')->nullable()->default(null);
            $table->dropColumn('industry_type');
        });
    }
}
