<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RemoveFieldsFromCommHistories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('communication_histories', function (Blueprint $table) {
            $table->dropColumn(['type','source','destination','subject', 'content', 'status', 'first_read_time','last_read_time']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('communication_histories', function (Blueprint $table) {
            $table->string('type')->nullable()->default(null);
            $table->string('source')->nullable()->default(null);
            $table->string('destination')->nullable()->default(null);
            $table->text('subject')->nullable()->default(null);
            $table->longText('content')->nullable()->default(null);
            $table->string('status')->nullable()->default(null);
            $table->string('first_read_time')->nullable()->default(null);
            $table->string('last_read_time')->nullable()->default(null);
        });
    }
}
