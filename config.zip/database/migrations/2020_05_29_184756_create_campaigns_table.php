<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCampaignsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('campaigns', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('group_id');
            $table->unsignedBigInteger('template_id');
            $table->unsignedBigInteger('total_sent')->default(0);
            $table->unsignedBigInteger('total_failed')->default(0);
            $table->unsignedBigInteger('total_delivered')->default(0);
            $table->unsignedBigInteger('total_balance_delivered')->default(0);
            $table->unsignedBigInteger('created_by');
            $table->timestamp('sent_at')->nullable()->default(null);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('campaigns');
    }
}
