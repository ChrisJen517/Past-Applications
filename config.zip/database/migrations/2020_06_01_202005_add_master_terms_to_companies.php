<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddMasterTermsToCompanies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->double('pif_balance_discount_percent')->after('approved_by')->nullable()->default(null);
            $table->double('ppa_balance_discount_percent')->after('pif_balance_discount_percent')->nullable()->default(null);
            $table->double('min_monthly_pay_percent')->after('ppa_balance_discount_percent')->nullable()->default(null);
            $table->double('min_days_setup_payment')->after('min_monthly_pay_percent')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn(['pif_balance_discount_percent', 'ppa_balance_discount_percent',
                'min_monthly_pay_percent', 'min_days_setup_payment']);
        });
    }
}
