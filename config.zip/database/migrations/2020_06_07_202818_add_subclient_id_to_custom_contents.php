<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSubclientIdToCustomContents extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('custom_contents', function (Blueprint $table) {
            $table->unsignedBigInteger('subclient_id')->after('company_id')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('custom_contents', function (Blueprint $table) {
            $table->dropColumn('subclient_id');
        });
    }
}
