<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCommunicationHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('communication_histories', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('type')->nullable()->default(null);
            $table->string('source')->nullable()->default(null);
            $table->string('destination')->nullable()->default(null);
            $table->text('subject')->nullable()->default(null);
            $table->string('company_id')->nullable()->default(null);
            $table->string('consumer_id')->nullable()->default(null);
            $table->longText('content')->nullable()->default(null);
            $table->string('status')->nullable()->default(null);
            $table->string('first_read_time')->nullable()->default(null);
            $table->string('last_read_time')->nullable()->default(null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('communication_histories');
    }
}
