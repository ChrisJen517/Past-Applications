<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateElettersConsumersMapTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('eletters_consumers_map', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('eletters_id')->nullable()->default(null);
            $table->unsignedBigInteger('consumer_id')->nullable()->default(null);
            $table->boolean('enabled')->default(false);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('eletters_consumers_map');
    }
}
