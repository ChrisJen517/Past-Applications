<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterRnnTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('rnn_transactions', function (Blueprint $table) {
          $table->dropColumn('sms_cost');
          $table->dropColumn('email_cost');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rnn_transactions', function ($table) {
            $table->integer('sms_cost')->nullable()->default(0.0);
            $table->integer('email_cost')->nullable()->default(0.0);
        });
    }
}
