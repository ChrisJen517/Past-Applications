<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RemoveUnnecessaryFieldsCustomStyles extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('custom_styles', function (Blueprint $table) {
            $table->dropColumn(['hover_color', 'sidebar_bg_color', 'header_bg_color']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('custom_styles', function (Blueprint $table) {
            $table->string('hover_color');
            $table->string('sidebar_bg_color');
            $table->string('header_bg_color');
        });
    }
}
