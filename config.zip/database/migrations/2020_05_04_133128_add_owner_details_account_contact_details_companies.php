<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddOwnerDetailsAccountContactDetailsCompanies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->text('owner1_full_name')->after('technical_phone')->nullable()->default(null);
            $table->text('owner1_email')->after('owner1_full_name')->nullable()->default(null);
            $table->text('owner1_phone')->after('owner1_email')->nullable()->default(null);
            $table->text('account_contact_full_name')->after('owner1_phone')->nullable()->default(null);
            $table->text('account_contact_email')->after('account_contact_full_name')->nullable()->default(null);
            $table->text('account_contact_phone')->after('account_contact_email')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn(['owner1_full_name', 'owner1_email', 'owner1_phone', 'account_contact_full_name',
                'account_contact_email', 'account_contact_phone']);
        });
    }
}
