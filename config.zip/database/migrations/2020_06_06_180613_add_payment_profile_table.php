<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPaymentProfileTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('payment_profiles', function($table) {
            $table->string('profile_id')->nullable();
            $table->string('payment_profile_id')->nullable();;
            $table->string('shipping_profile_id')->nullable();;
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('payment_profiles', function($table) {
            $table->dropColumn('profile_id');
            $table->dropColumn('payment_profile_id');
            $table->dropColumn('shipping_profile_id');
        });
    }
}
