<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class RemoveCompanyTypeUniqueIdParentIdFromCompanies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropUnique('companies_unique_id_unique');
            $table->dropColumn(['company_type', 'unique_id', 'parent_id']);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->string('company_type')->nullable()->default(null);
            $table->string('unique_id')->unique()->nullable()->default(null);
            $table->unsignedInteger('parent_id')->nullable()->default(null);
        });
    }
}
