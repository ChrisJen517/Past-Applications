<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMerchantsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('merchants', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('company_id');
            $table->string('merchant_name');
            $table->unsignedBigInteger('subclient_id')->nullable()->default(null);
            $table->text('usaepay_key')->nullable()->default(null);
            $table->string('usaepay_pin')->nullable()->default(null);
            $table->string('authorize_login_id')->nullable()->default(null);
            $table->string('authorize_transaction_key')->nullable()->default(null);
            $table->string('authorize_key')->nullable()->default(null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('merchants');
    }
}
