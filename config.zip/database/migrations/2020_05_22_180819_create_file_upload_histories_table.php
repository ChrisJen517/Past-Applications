<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFileUploadHistoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('file_upload_histories', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('company_id');
            $table->string('filename')->nullable()->default(null);
            $table->string('uploaded_by')->nullable()->default(null);
            $table->string('type')->nullable()->default(null);
            $table->string('num_of_records')->nullable()->default(null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('file_upload_histories');
    }
}
