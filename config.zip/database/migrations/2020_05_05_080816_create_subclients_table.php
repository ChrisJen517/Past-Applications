<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSubclientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('subclients', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('subclient_name');
            $table->string('subclient_type');
            $table->unsignedInteger('company_id');
            $table->string('unique_id')->unique();
            $table->unsignedInteger('parent_id')->nullable()->default(null);
            $table->string('address');
            $table->string('address2')->nullable()->default(null);
            $table->text('city');
            $table->text('state');
            $table->string('zip');
            $table->string('corp_url');
            $table->string('fed_tax_id')->nullable()->default(null);
            $table->text('mailing_address')->nullable()->default(null);
            $table->text('mailing_address2')->nullable()->default(null);
            $table->string('mailing_city')->nullable()->default(null);
            $table->string('mailing_state')->nullable()->default(null);
            $table->string('mailing_zip')->nullable()->default(null);
            $table->string('bank1_name')->nullable()->default(null);
            $table->text('bank1_address')->nullable()->default(null);
            $table->string('bank1_city')->nullable()->default(null);
            $table->string('bank1_state')->nullable()->default(null);
            $table->string('bank1_zip')->nullable()->default(null);
            $table->string('bank1_company_name')->nullable()->default(null);
            $table->text('bank1_company_address')->nullable()->default(null);
            $table->string('bank1_company_city')->nullable()->default(null);
            $table->string('bank1_company_state')->nullable()->default(null);
            $table->string('bank1_company_zip')->nullable()->default(null);
            $table->string('bank1_account_type')->nullable()->default(null);
            $table->string('bank1_routing')->nullable()->default(null);
            $table->string('bank1_account_number')->nullable()->default(null);
            $table->string('bank2_name')->nullable()->default(null);
            $table->text('bank2_address')->nullable()->default(null);
            $table->string('bank2_city')->nullable()->default(null);
            $table->string('bank2_state')->nullable()->default(null);
            $table->string('bank2_zip')->nullable()->default(null);
            $table->string('bank2_company_name')->nullable()->default(null);
            $table->text('bank2_company_address')->nullable()->default(null);
            $table->string('bank2_company_city')->nullable()->default(null);
            $table->string('bank2_company_state')->nullable()->default(null);
            $table->string('bank2_company_zip')->nullable()->default(null);
            $table->string('bank2_account_type')->nullable()->default(null);
            $table->string('bank2_routing')->nullable()->default(null);
            $table->string('bank2_account_number')->nullable()->default(null);
            $table->string('billing_name')->nullable()->default(null);
            $table->string('billing_email')->nullable()->default(null);
            $table->string('billing_phone')->nullable()->default(null);
            $table->string('technical_name')->nullable()->default(null);
            $table->string('technical_email')->nullable()->default(null);
            $table->string('technical_phone')->nullable()->default(null);
            $table->text('owner1_full_name')->nullable()->default(null);
            $table->text('owner1_email')->nullable()->default(null);
            $table->text('owner1_phone')->nullable()->default(null);
            $table->text('account_contact_full_name')->nullable()->default(null);
            $table->text('account_contact_email')->nullable()->default(null);
            $table->text('account_contact_phone')->nullable()->default(null);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('subclients');
    }
}
