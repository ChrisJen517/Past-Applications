<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateConsumerNegotiationsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('consumer_negotiations', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('consumer_id');
            $table->unsignedInteger('company_id');
            $table->string('one_time_settlement');
            $table->string('negotiate_amount');
            $table->string('monthly_amount');
            $table->string('no_of_installments');
            $table->string('last_month_amount');
            $table->string('installment_type');
            $table->string('first_pay_date');
            $table->boolean('offer_accepted')->default(0);
            $table->string('counter_one_time_amount');
            $table->string('counter_negotiate_amount');
            $table->string('counter_monthly_amount');
            $table->string('counter_no_of_installments');
            $table->string('counter_last_month_amount');
            $table->string('counter_first_pay_date');
            $table->boolean('counter_offer_accepted')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('consumer_negotiations');
    }
}
