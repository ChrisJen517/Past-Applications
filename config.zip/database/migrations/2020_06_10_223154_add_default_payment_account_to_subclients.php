<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddDefaultPaymentAccountToSubclients extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('subclients', function (Blueprint $table) {
            $table->boolean('default_payment_account')->after('bank1_account_number');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('subclients', function (Blueprint $table) {
            $table->dropColumn('default_payment_account');
        });
    }
}
