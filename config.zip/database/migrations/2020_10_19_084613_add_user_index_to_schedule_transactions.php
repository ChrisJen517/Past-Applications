<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddUserIndexToScheduleTransactions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('schedule_transactions', function (Blueprint $table) {
            $table->index(['consumer_id', 'status'], 'conuser_status_index');
            $table->index(['company_id'], 'company_index');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('scheduled_transactions', function (Blueprint $table) {
            //
        });
    }
}
