<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateConsumerTableIndexes extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('consumers', function (Blueprint $table) {
            $table->index('company_id');
            $table->index('consumer_login_id');
            $table->index('account_number');
            $table->index('status');
            $table->index('first_name');
            $table->index('email1');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('consumers', function (Blueprint $table) {
            $table->dropIndex(['company_id', 'consumer_login_id', 'account_number', 'status', 'first_name', 'email1']);
        });
    }
}
