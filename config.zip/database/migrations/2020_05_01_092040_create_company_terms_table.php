<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCompanyTermsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('company_terms', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedBigInteger('company_id');
            $table->unsignedBigInteger('rnn_share')->nullable()->default(null);
            $table->unsignedBigInteger('flat_transaction_fee')->nullable()->default(null);
            $table->unsignedBigInteger('monthly_licensing_fee')->nullable()->default(null);
            $table->unsignedBigInteger('processing_charges_percent')->nullable()->default(null);
            $table->unsignedBigInteger('min_one_time_percent')->nullable()->default(null);
            $table->unsignedBigInteger('min_monthly_pay_percent')->nullable()->default(null);
            $table->unsignedBigInteger('pay_setup_discount_percent')->nullable()->default(null);
            $table->unsignedBigInteger('pif_discount_percent')->nullable()->default(null);
            $table->string('negotiation_rule')->nullable()->default(null);
            $table->softDeletes();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('company_terms');
    }
}
