<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddSmsRateEmailRateRnnShareBillingScheduleToCompanies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->double('sms_rate')->after('min_days_setup_payment')->nullable()->default(null);
            $table->double('email_rate')->after('sms_rate')->nullable()->default(null);
            $table->double('rnn_share')->after('email_rate')->nullable()->default(null);
            $table->string('billing_schedule')->after('rnn_share')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->dropColumn(['sms_rate', 'email_rate', 'rnn_share', 'billing_schedule']);
        });
    }
}
