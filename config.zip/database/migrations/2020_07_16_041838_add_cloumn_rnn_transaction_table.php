<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddCloumnRnnTransactionTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('rnn_transactions', function (Blueprint $table) {
            $table->timestamp('billing_cycle_start')->nullable()->default(null);
            $table->timestamp('billing_cycle_end')->nullable()->default(null);
            $table->integer('sms_count')->nullable()->default(null);
            $table->integer('email_count')->nullable()->default(null);
            $table->integer('sms_cost')->nullable()->default(null);
            $table->integer('email_cost')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rnn_transactions', function (Blueprint $table) {
            $table->dropColumn('billing_cycle_start');
            $table->dropColumn('billing_cycle_end');
            $table->dropColumn('sms_count');
            $table->dropColumn('email_count');
            $table->dropColumn('sms_cost');
            $table->dropColumn('email_cost');
        });
    }
}
