<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateConsumersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('consumers', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('company_id')->nullable()->default(null);
            $table->bigInteger('sub_client1_id')->nullable()->default(null);
            $table->string('sub_client1_name')->nullable()->default(null);
            $table->bigInteger('sub_client2_id')->nullable()->default(null);
            $table->string('sub_client2_name')->nullable()->default(null);
            $table->integer('reference_number')->nullable()->default(null);
            $table->bigInteger('account_number')->nullable()->default(null);
            $table->bigInteger('unique_customer_id')->nullable()->default(null);
            $table->string('full_ssn')->nullable()->default(null);
            $table->string('last4ssn')->nullable()->default(null);
            $table->string('first_name')->nullable()->default(null);
            $table->string('middle_name')->nullable()->default(null);
            $table->string('last_name')->nullable()->default(null);
            $table->string('dob')->nullable()->default(null);
            $table->string('gender')->nullable()->default(null);
            $table->string('address1')->nullable()->default(null);
            $table->string('address2')->nullable()->default(null);
            $table->string('city')->nullable()->default(null);
            $table->string('state')->nullable()->default(null);
            $table->string('zip')->nullable()->default(null);
            $table->string('mobile1')->nullable()->default(null);
            $table->string('mobile2')->nullable()->default(null);
            $table->string('mobile3')->nullable()->default(null);
            $table->string('land1')->nullable()->default(null);
            $table->string('land2')->nullable()->default(null);
            $table->string('land3')->nullable()->default(null);
            $table->string('email1')->nullable()->default(null);
            $table->string('email2')->nullable()->default(null);
            $table->string('email3')->nullable()->default(null);
            $table->bigInteger('total_balance')->nullable()->default(null);
            $table->bigInteger('principle_balance')->nullable()->default(null);
            $table->bigInteger('fees_balance')->nullable()->default(null);
            $table->bigInteger('daily_interest_add')->nullable()->default(null);
            $table->bigInteger('monthly_interest_add')->nullable()->default(null);
            $table->bigInteger('current_balance')->nullable()->default(null);
            $table->bigInteger('min_one_time_percent')->nullable()->default(null);
            $table->bigInteger('pif_discount_balance')->nullable()->default(null);
            $table->bigInteger('pif_discount_percent')->nullable()->default(null);
            $table->boolean('negotiation_rule')->default(0);
            $table->bigInteger('pay_setup_discount_percent')->nullable()->default(null);
            $table->bigInteger('min_monthly_pay_percent')->nullable()->default(null);
            $table->bigInteger('min_monthly_pay_amount')->nullable()->default(null);
            $table->bigInteger('max_days_first_pay')->nullable()->default(null);
            $table->string('pass_through1')->nullable()->default(null);
            $table->string('pass_through2')->nullable()->default(null);
            $table->string('pass_through3')->nullable()->default(null);
            $table->string('pass_through4')->nullable()->default(null);
            $table->string('pass_through5')->nullable()->default(null);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('consumers');
    }
}
