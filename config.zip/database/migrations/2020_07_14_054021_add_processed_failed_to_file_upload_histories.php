<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddProcessedFailedToFileUploadHistories extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('file_upload_histories', function (Blueprint $table) {
            $table->unsignedBigInteger('processed_count')->after('num_of_records')->default(0);
            $table->unsignedBigInteger('failed_count')->after('processed_count')->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('file_upload_histories', function (Blueprint $table) {
            $table->dropColumn(['processed_count', 'failed_count']);
        });
    }
}
