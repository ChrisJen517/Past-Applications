<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddInvoiceRnnTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
      Schema::table('rnn_transactions', function (Blueprint $table) {
             $table->bigInteger('rnn_invoice_id')->default(1000);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
         Schema::table('rnn_transactions', function (Blueprint $table) {
            $table->dropColumn('rnn_invoice_id');
        });
    }
}
