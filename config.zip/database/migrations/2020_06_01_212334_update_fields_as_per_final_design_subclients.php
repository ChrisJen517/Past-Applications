<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class UpdateFieldsAsPerFinalDesignSubclients extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('subclients', function (Blueprint $table) {
            $table->string('industry_type')->after('subclient_name')->nullable()->default(null);
            $table->string('share_payment')->after('parent_id')->nullable()->default(null);
            $table->string('consumer_company_name')->after('technical_phone')->nullable()->default(null);
            $table->double('pif_balance_discount_percent')->after('account_contact_phone')->nullable()->default(null);
            $table->double('ppa_balance_discount_percent')->after('pif_balance_discount_percent')->nullable()->default(null);
            $table->double('min_monthly_pay_percent')->after('ppa_balance_discount_percent')->nullable()->default(null);
            $table->double('max_days_first_pay')->after('min_monthly_pay_percent')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('subclients', function (Blueprint $table) {
            $table->dropColumn([
                'industry_type',
                'share_payment',
                'consumer_company_name',
                'pif_balance_discount_percent',
                'ppa_balance_discount_percent',
                'min_monthly_pay_percent',
                'max_days_first_pay'
            ]);
        });
    }
}
