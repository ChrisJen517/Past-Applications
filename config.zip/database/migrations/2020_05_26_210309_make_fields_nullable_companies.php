<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class MakeFieldsNullableCompanies extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->string('address')->nullable()->default(null)->change();
            $table->string('address2')->nullable()->default(null)->change();
            $table->string('city')->nullable()->default(null)->change();
            $table->string('state')->nullable()->default(null)->change();
            $table->string('zip')->nullable()->default(null)->change();
            $table->string('owner1_full_name')->nullable()->default(null)->change();
            $table->string('owner1_email')->nullable()->default(null)->change();
            $table->string('owner1_phone')->nullable()->default(null)->change();
            $table->string('industry_type')->nullable()->default(null)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('companies', function (Blueprint $table) {
            $table->string('address')->change();
            $table->string('address2')->change();
            $table->string('city')->change();
            $table->string('state')->change();
            $table->string('zip')->change();
            $table->string('owner1_full_name')->change();
            $table->string('owner1_email')->change();
            $table->string('owner1_phone')->change();
            $table->string('industry_type')->change();
        });
    }
}
