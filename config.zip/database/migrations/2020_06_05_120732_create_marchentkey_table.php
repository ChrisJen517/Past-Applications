<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateMarchentkeyTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('marchentkey', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('company_id')->nullable()->default(null);
            $table->unsignedInteger('subclient1_id')->nullable()->default(null);
            $table->unsignedInteger('subclient2_id')->nullable()->default(null);
            $table->string('MERCHANT_LOGIN_ID');
            $table->string('MERCHANT_TRANSACTION_KEY');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('marchentkey');
    }
}
