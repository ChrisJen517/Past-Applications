<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('transactions', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->unsignedInteger('consumer_login_id')->nullable();
            $table->string('transaction_type')->nullable();
            $table->string('consumer_id')->nullable();
            $table->string('company_id')->nullable();
            $table->string('payment_profile_id')->nullable();
            $table->text('gateway_respnse_raw')->nullable();
            $table->string('status')->nullable();
            $table->string('status_code')->nullable();
            $table->string('amount')->nullable();
            $table->string('processing_charges')->nullable();
            $table->string('flat_transaction_charges')->nullable();
            $table->string('rnn_share')->nullable();
            $table->string('company_share')->nullable();
            $table->string('subclient1_share')->nullable();
            $table->string('subclient2_share')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('transactions');
    }
}
