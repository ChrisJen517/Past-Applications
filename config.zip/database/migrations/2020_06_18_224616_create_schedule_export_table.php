<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateScheduleExportTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('schedule_export', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('user_id');
            $table->string('report_type');
            $table->string('company_id');
            $table->string('customer_group');
            $table->string('frequency');
            $table->string('delivery_type');
            $table->string('host')->nullable()->default(null);
            $table->string('username')->nullable()->default(null);
            $table->string('password')->nullable()->default(null);
            $table->string('keyfile')->nullable()->default(null);
            $table->string('port')->nullable()->default(null);
            $table->string('folder_path')->nullable()->default(null);
            $table->string('email_id')->nullable()->default(null);
            $table->integer('push')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('schedule_export');
    }
}
