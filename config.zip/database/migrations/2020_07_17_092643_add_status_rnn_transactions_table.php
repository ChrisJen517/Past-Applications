<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddStatusRnnTransactionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
     Schema::table('rnn_transactions', function (Blueprint $table) {
            $table->string('status')->nullable()->default(null);
            $table->double('sms_cost')->nullable()->default(0);
            $table->double('email_cost')->nullable()->default(0);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
       Schema::table('rnn_transactions', function (Blueprint $table) {
            $table->dropColumn('status');
                $table->dropColumn('sms_cost');
          $table->dropColumn('email_cost');
        });
    }
}
