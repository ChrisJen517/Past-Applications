<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSftpImportSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('sftp_import_settings', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->integer('company_id');
            $table->integer('subclient_id')->nullable()->default(null);
            $table->string('host');
            $table->string('username');
            $table->string('password');
            $table->string('keyfile')->nullable()->default(null);
            $table->string('path');
            $table->integer('port');
            $table->integer('pause')->comment('0 enable 1 disable');
            $table->string('type');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('sftp_import_settings');
    }
}
