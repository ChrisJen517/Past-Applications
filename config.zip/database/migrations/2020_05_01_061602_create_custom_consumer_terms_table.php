<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateCustomConsumerTermsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('custom_consumer_terms', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('company_id');
            $table->bigInteger('sub_client1_id')->nullable()->default(null);;
            $table->bigInteger('sub_client2_id')->nullable()->default(null);;
            $table->string('term_type')->nullable()->default(null);;
            $table->string('term_value')->nullable()->default(null);;
            $table->boolean('one_time_rule')->default(0);
            $table->string('min_one_time_percent')->nullable()->default(null);;
            $table->string('monthly_pay_percent')->nullable()->default(null);;
            $table->string('max_negotiation_discount_percent')->nullable()->default(null);;
            $table->string('pif_discount_percent')->nullable()->default(null);;
            $table->string('master_negotiation_rule')->nullable()->default(null);;
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('custom_consumer_terms');
    }
}
