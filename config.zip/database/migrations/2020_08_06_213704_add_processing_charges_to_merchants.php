<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddProcessingChargesToMerchants extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('merchants', function (Blueprint $table) {
            $table->double('processing_charge_percentage')->nullable()->default(null)->after('authorize_key');
            $table->double('min_processing_amount')->nullable()->default(null)->after('processing_charge_percentage');
            $table->double('max_processing_amount')->nullable()->default(null)->after('min_processing_amount');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('merchants', function (Blueprint $table) {
            $table->dropColumn(['processing_charge_percentage', 'min_processing_amount', 'max_processing_amount']);
        });
    }
}
