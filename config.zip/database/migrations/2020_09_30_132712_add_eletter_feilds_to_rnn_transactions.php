<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddEletterFeildsToRnnTransactions extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('rnn_transactions', function (Blueprint $table) {
            $table->double('eletter_cost')->nullable()->after('email_cost')->default(0);
            $table->integer('eletter_count')->nullable()->after('email_count')->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rnn_transactions', function (Blueprint $table) {
            //
        });
    }
}
