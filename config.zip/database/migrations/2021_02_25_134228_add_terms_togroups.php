<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddTermsTogroups extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('groups', function (Blueprint $table) {
            $table->double('pif_balance_discount_percent')->after('customer_custom_rule')->nullable()->default(null);
            $table->double('ppa_balance_discount_percent')->after('pif_balance_discount_percent')->nullable()->default(null);
            $table->double('min_monthly_pay_percent')->after('ppa_balance_discount_percent')->nullable()->default(null);
            $table->double('max_days_first_pay')->after('min_monthly_pay_percent')->nullable()->default(null);
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}