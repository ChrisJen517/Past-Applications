<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateScheduledCampaignsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('scheduled_campaigns', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('company_id')->nullable()->default(null);
            $table->string('group_id')->nullable()->default(null);
            $table->string('template_id')->nullable()->default(null);
            $table->string('frequency')->nullable()->default(null);
            $table->boolean('enabled')->default(true);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
