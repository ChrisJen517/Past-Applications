<?php
return [
    'paginate_rows' => 2,
    'profile_validation_rules' => [
        'step-1' => [
            'company_name' => 'required',
            'industry_type' => 'required',
            'fed_tax_id' => 'required',
            'address' => 'required',
            'address2' => 'nullable',
            'city' => 'required',
            'state' => 'required',
            'zip' => 'required|numeric',
        ],
        "step-2" => [
            "bank1_name" => "required",
            "bank1_address" => "required",
            "bank1_city" => "required",
            "bank1_state" => "required",
            "bank1_zip" => "required|numeric",
            "bank1_company_name" => "required",
            "bank1_company_address" => "required",
            "bank1_company_city" => "required",
            "bank1_company_state" => "required",
            "bank1_company_zip" => "required",
            "bank1_account_type" => "required",
            "bank1_routing" => "required|numeric",
            "bank1_account_number" => "required|numeric",
        ],
        "step-3" => [
            "merchant_name" => "nullable",
            "merchant_type" => "nullable",
            "usaepay_key" => "nullable",
            "usaepay_pin" => "nullable",
            "authorize_login_id" => "nullable",
            "authorize_transaction_key" => "nullable",
            "authorize_key" => "nullable",
            "paidyet_subdomain" => "nullable",
            "paidyet_key" => "nullable",
            /*"processing_charge_percentage" => "nullable",
            "processing_charge_amount" => "nullable",
            "min_processing_amount" => "nullable",
            "max_processing_amount" => "nullable",*/
        ],
        "step-4" => [
            "owner1_full_name" => "required",
            "billing_name" => "required",
            "billing_email" => "required|email",
            "billing_phone" => "required|numeric",
            "technical_name" => "required",
            "technical_email" => "required|email",
            "technical_phone" => "required|numeric",
            "account_contact_full_name" => "required",
            "account_contact_email" => "required|email",
            "account_contact_phone" => "required|numeric",
        ]
    ],
    'registration_validation_rules' => [
        "company_name" => "required|unique:companies,company_name",
    ],
    'master_terms_validation_rule' => [
        'pif_balance_discount_percent' => 'required|numeric',
        'ppa_balance_discount_percent' => 'required|numeric',
        'min_monthly_pay_percent' => 'required|numeric',
        'max_days_first_pay' => 'required|numeric',
    ],

    'group_master_terms_validation_rule' => [
        'group' => 'required',
        'pif_balance_discount_percent' => 'required|numeric',
        'ppa_balance_discount_percent' => 'required|numeric',
        'min_monthly_pay_percent' => 'required|numeric',
        'max_days_first_pay' => 'required|numeric',
    ],

    'default_style' => [
        'logo_path' => 'public/assets/images/logos/1588194575.jpeg',
        'bg_color' => '#66FFFF',
        'button_color' => '#007cfb',
        'font_color' => '#000',
        'hover_color' => '#007cfb',
        'sidebar_bg_color' => '#F9F9F9',
        'header_bg_color' => '#F9F9F9',
    ],
    "bank_account_types" => [
        "Checking" => "Checking",
        "Saving" => "Saving"
    ],

    "content_titles" => [
        'about-us' => 'about-us',
        'contact-us' => 'contact-us'
    ],

    'billing_schedule' => [
        'Weekly',
        'Monthly'
    ],
    'config_fields' => [
        'rnn_id',
        'contract_date',
        'sms_rate',
        'email_rate',
        'eletter_rate',
        'user_experience_rate',
        'rnn_share',
        'billing_schedule'
    ]

];