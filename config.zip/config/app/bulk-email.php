<?php

return [
    'paginate_rows' => 12,
    'creation_validation_rules' => [
        'name' => 'required|unique:templates,name',
        'template_id' => 'required|exists:templates,id',
        'group_id' => 'required|exists:groups,id'
    ],
    'update_validation_rules' => [
        'name' => 'required',
        'template_id' => 'required|exists:templates,id',
        'group_id' => 'required|exists:groups,id'
    ],
];
