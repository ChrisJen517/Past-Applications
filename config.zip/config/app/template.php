<?php

return [
    'paginate_rows' => 12,
    'creation_validation_rules' => [
        'name' => 'required',
        'type' => 'required',
        'subject' => 'required_if:type,email',
        'content' => 'required',
        'attach_group' => 'nullable'
    ],
    'update_validation_rules' => [
        'name' => 'required',
        'type' => 'required',
        'subject' => 'required_if:type,email',
        'content' => 'required',
        'attach_group' => 'nullable'
    ],
    'merge_fields' => [
        '[First Name]',
        '[Last Name]',
        '[Account Number]',
        '[Master Company Name]',
        '[Current Creditor Name]',
        '[Original Creditor Name]',
        // '[Loan Originator Name]',
        '[Account Balance]',
        '[Payment Set up Discount %]',
        '[Payment Set up Discount Amount]',
        '[Pay in Full Discount %]',
        '[Pay in Full Discount Amount]',
        '[You Negotiate Link]',
        '[Pass Through 1]',
        '[Pass Through 2]',
        '[Pass Through 3]',
        '[Pass Through 4]',
        '[Pass Through 5]',
    ],
    'max_sms_length' => 160
];
