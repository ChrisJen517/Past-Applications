<?php
return [
    'update_validation_rules' => [
        'type' => 'required',
        'host' => 'required',
        'username' => 'required',
        'password' => 'required',
        'port' => 'required',
        'root' => 'required',
        'timeout' => 'required|numeric',
    ]
];