<?php

return [
    'paginate_rows' => 12,
    'creation_validation_rules' => [
        'title' => 'required',
        'subject' => 'required',
        'message' => 'required',
        'attach_group' => 'nullable'
    ],
    'update_validation_rules' => [
        'title' => 'required',
        'subject' => 'required',
        'message' => 'required',
        'attach_group' => 'nullable'
    ],
    'merge_fields' => [
        '[First Name]',
        '[Last Name]',
        '[Date]',
        '[Address 1]',
        '[Address 2]',
        '[City]',
        '[State]',
        '[Zip]',
        '[Total Balance Due]',
        '[Settlement $ Amount]',
        '[Master name]',
        '[Master account number]',
        '[Current creditor name]',
        '[Current creditor account number]',
        '[Original creditor name]',
        '[Original creditor account number]',
        '[Payment Plan]',
        '[Payment plan agreed # of payments]',
        '[Payment amount $$]',
        '[Beginning date for first payment]',
        '[DOB]',
        '[Last 4 SSN]',
    ],
    'max_sms_length' => 160
];