<?php

return [
    'paginate_rows' => 12,
    'update_validation_rules' => [
        'rnn_share' => 'required|numeric',
        'flat_transaction_fee' => 'required|numeric',
        'monthly_licensing_fee' => 'required|numeric',
        'processing_charges_percent' => 'required|numeric',
        'min_one_time_percent' => 'required|numeric',
        'min_monthly_pay_percent' => 'required|numeric',
        'pay_setup_discount_percent' => 'required|numeric',
        'pif_discount_percent' => 'required|numeric',
        'negotiation_rule' => 'required',
    ],
];
