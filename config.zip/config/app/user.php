<?php

return [
    'paginate_rows' => 12,

    'user_types' => [
        'company' => 'Company',
        'subclient' => 'Subclient',
    ],

    'registration_validation_rules' => [
        'name' => ['required', 'string', 'max:255'],
        'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
        'password' => 'required|string|min:8|confirmed|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/',
    ],

    'password_reset_rules' => [
        'token' => 'required',
        'email' => 'required|email',
        'password' => 'required|string|min:8|confirmed|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/',
    ],

    'creation_validation_rules' => [
        'name' => ['required', 'string', 'max:255'],
        'email' => ['required', 'string', 'email', 'max:255', 'unique:users'],
        'phone_no' => ['nullable', 'string', 'max:255'],
        'subclient_id' => 'nullable',
        'rnn_user_type' => 'nullable',
    ],
    'update_validation_rules' => [
        'name' => ['required', 'string', 'max:255'],
        'email' => ['required', 'string', 'email', 'max:255', 'unique_or_exists:users,email'],
        'phone_no' => ['nullable', 'string', 'max:255'],
        'subclient_id' => 'nullable',
        'rnn_user_type' => 'nullable',
    ],
];
