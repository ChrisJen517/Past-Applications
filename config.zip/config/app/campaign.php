<?php

return [
    'paginate_rows' => 12,
    'creation_validation_rules' => [
        'group_id' => 'required|exists:groups,id',
        'template_id' => 'nullable|exists:templates,id',
        'email_template' => 'nullable|exists:templates,id',
        'sms_template' => 'nullable|exists:templates,id',
    ],
];
