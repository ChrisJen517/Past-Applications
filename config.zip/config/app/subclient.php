<?php
return [
    'paginate_rows' => 2,
    'payment_methods' => [
        'ACH',
        'Credit Card',
        'Both'
    ],
    'creation_validation_rules' => [
        'step-1' => [
            'subclient_name' => 'required',
            'industry_type' => 'required',
            'subclient_type' => 'required',
            'parent_id' => 'required_if:subclient_type,Subclient2',
//            'default_payment_account' => 'required',
//            'payment_method' => 'required_if:default_payment_account,true',
//            'fed_tax_id' => 'required_if:default_payment_account,true',
        ],
        'step-2' => [
            'pif_balance_discount_percent' => "nullable|numeric",
            'ppa_balance_discount_percent' => "nullable|numeric",
            'min_monthly_pay_percent' => "nullable|numeric",
            'max_days_first_pay' => "nullable|numeric",
        ],
        'step-3' => [
            'default_payment_account' => 'required',
            'merchant_name_cc' => 'nullable',
            'merchant_type_cc' => 'nullable',
            'usaepay_key_cc' => 'nullable',
            'usaepay_pin_cc' => 'nullable',
            'authorize_login_id_cc' => 'nullable',
            'authorize_transaction_key_cc' => 'nullable',
            'authorize_key_cc' => 'nullable',

            'merchant_name_ach' => 'nullable',
            'merchant_type_ach' => 'nullable',
            'usaepay_key_ach' => 'nullable',
            'usaepay_pin_ach' => 'nullable',
            'authorize_login_id_ach' => 'nullable',
            'authorize_transaction_key_ach' => 'nullable',
            'authorize_key_ach' => 'nullable',

        ],
        'step-4' => [
            /*'mailing_address' => 'nullable',
            'mailing_address2' => 'nullable',
            'mailing_city' => 'nullable',
            'mailing_state' => 'nullable',
            'mailing_zip' => 'nullable',*/
            'billing_name' => 'nullable',
            'billing_email' => 'nullable|email',
            'billing_phone' => 'nullable',
            'technical_name' => 'nullable',
            'technical_email' => 'nullable|email',
            'technical_phone' => 'nullable',
            'consumer_company_name' => 'nullable',
            'account_contact_full_name' => 'nullable',
            'account_contact_email' => 'required|email',
            'account_contact_phone' => 'nullable',
        ],
    ],
    'term_validation_rules' => [
        'id' => 'nullable|exists:subclients,id',
        'pif_balance_discount_percent' => 'nullable',
        'ppa_balance_discount_percent' => 'nullable',
        'min_monthly_pay_percent' => 'nullable',
        'max_days_first_pay' => 'nullable',
    ]
];

