<?php

return [
    'paginate_rows' => 10
];
