<?php
ini_set("memory_limit","768M");
set_time_limit(0);

date_default_timezone_set("US/Eastern");
$tdate=date('Y-m-d H:i:s');

//$conn=mysql_connect("localhost","rnnginc","H3rcules99##")or die (mysql_error());
//$db=mysql_select_db("rnnginc_webapp",$conn)or die (mysql_error());

$sq=mysql_query("Select ID, ACCT_SSN, ACCT_AGENT, CAPCODE from b_active_accounts where ACCT_CASE='96157' group by ACCT_SSN");
while($sr=mysql_fetch_assoc($sq))
{
	$chq=mysql_query("Select UID, ACCT_AGENT from b_work_history where ACCT_CASE='96157' and ACCT_SSN='".$sr['ACCT_SSN']."' group by UID");
	if(mysql_num_rows($chq)==0)
	{
		$dq=mysql_query("Delete from b_active_accounts where ACCT_CASE='96157' and ACCT_SSN='".$sr['ACCT_SSN']."' and ID!='".$sr['ID']."'");
		$nr=$nr+mysql_affected_rows();
	}
	else if(mysql_num_rows($chq)==1)
	{
		$chr=mysql_fetch_assoc($chq);
		$dq=mysql_query("Delete from b_active_accounts where ACCT_CASE='96157' and ACCT_SSN='".$sr['ACCT_SSN']."' and ID!='".$chr['UID']."'");
		$wr=$wr+mysql_affected_rows();
	}
	else if(mysql_num_rows($chq)>1)
	{
		echo $chr['UID'].'|'.$chr['ACCT_AGENT'].'|'.$sr['ACCT_AGENT'].'|'.$sr['CAPCODE'].'<br/>';
		$dr++;
		$agent='RCALL-DUP'.$sr['ACCT_AGENT'];
		$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='$agent' where ID='".$sr['ID']."'");
		$ur=$ur+mysql_affected_rows();
	}
	
}
echo $nr.' --> '.$wr.' --> '.$dr.' --> '.$ur;
die();


$user = 'rnnitsupport';
$pass = 'RNNsg332@@#'; 
$request =  'https://api.sendgrid.com/api/mail.send.json';

$pdfnam='WEAVERJOHNSON.pdf';

$fileName = 'ROCKYPDF/'.$pdfnam;
$filePath = dirname(__FILE__);

$html='<html>
<head>
<meta charset="utf-8">
</head>
<body>
<div dir="ltr">
  <p> <strong style="color:#0015FF"><u>CIMA Medical Health Center</u></strong></p>
  <p> 85 Grand Canal Drive Ste 400</p>
  <p> Miami, FL 33144-2570</p>
  <p> Office: 305-603-7449</p>
  <p> Fax: 786-598-7449</p>
  <p> Email: <a href="mailto:admin@cimamedicalhealthcenter.com" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable">admin@cima</a><a href="https://protect2.fireeye.com/v1/url?k=eadfa9c7-b441afe2-ead89549-86f27bc93baa-e55da6a3b1265e8a&q=1&e=5b31e4fb-547a-44c3-ae63-19cd66507ece&u=http%3A%2F%2Fmedcenter.com%2F" target="_blank" rel="noopener noreferrer" data-auth="NotApplicable">medcenter.com</a></p>
  <p>  </p>
  <p> The   information contained in this transmission may contain privileged and   confidential information.  It is intended only for the use of the   person(s) named above.  If you are not the intended recipient,  you are hereby notified that any review, dissemination, distribution or   duplication of this communication is strictly prohibited.</p>
  <p>  </p>
  <p> Health Care   Information is personal and sensitive information related to a persons health care. It is being emailed to you after appropriate authorization   from the patient or under circumstances that  do not require patient authorization. You, the recipient, are obligated   to maintain it in a safe, secure and confidential manner. Re-disclosure   without any additional patient consent or as permitted by law is   prohibited. Unauthorized re-disclosure or failure  to maintain confidentiality could subject you to penalties described in   federal and state law.  If you are not the intended recipient, please   contact the sender by reply e-mail and destroy all copies of the   original message.</p>
</div>
</body>
</html>
';

$txxt='

CIMA Medical Health Center

85 Grand Canal Drive Ste 400

Miami, FL 33144-2570

Office: 305-603-7449

Fax: 786-598-7449

Email: admin@cimamedcenter.com

 

The information contained in this transmission may contain privileged and confidential information.  It is intended only for the use of the person(s) named above.  If you are not the intended recipient, you are hereby notified that any review, dissemination, distribution or duplication of this communication is strictly prohibited.

 

Health Care Information is personal and sensitive information related to a persons health care. It is being emailed to you after appropriate authorization from the patient or under circumstances that do not require patient authorization. You, the recipient, are obligated to maintain it in a safe, secure and confidential manner. Re-disclosure without any additional patient consent or as permitted by law is prohibited. Unauthorized re-disclosure or failure to maintain confidentiality could subject you to penalties described in federal and state law.  If you are not the intended recipient, please contact the sender by reply e-mail and destroy all copies of the original message.
';

$params = array(
    'api_user'  => $user,
    'api_key'   => $pass,
	'to'        => 'donna@rnngroup.com',
    'subject'   => 'CONFIDENTIAL LAB RESULT',
    'html'      => $html,
    'text'      => $txxt,
    'from'      => 'labresults@cimamedcenter.com',
	'files['.$pdfnam.']' => '@'.$filePath.'/'.$fileName
  );
 
// Generate curl request
$session = curl_init($request);
// Tell curl to use HTTP POST
curl_setopt ($session, CURLOPT_POST, true);
// Tell curl that this is the body of the POST
curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
// Tell curl not to return headers, but do return the response
curl_setopt($session, CURLOPT_HEADER, false);
curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
 
// obtain response
$response = curl_exec($session);
curl_close($session);


die();

$sq=mysql_query("Select ID, ACCT_SSN, ACCT_AGENT, CAPCODE from b_active_accounts where ACCT_CASE='96157' group by ACCT_SSN");
while($sr=mysql_fetch_assoc($sq))
{
	$chq=mysql_query("Select UID, ACCT_AGENT from b_work_history where ACCT_CASE='96157' and ACCT_SSN='".$sr['ACCT_SSN']."' group by UID");
	if(mysql_num_rows($chq)==0)
	{
		$dq=mysql_query("Delete from b_active_accounts where ACCT_CASE='96157' and ACCT_SSN='".$sr['ACCT_SSN']."' and ID!='".$sr['ID']."'");
		$nr=$nr+mysql_affected_rows();
	}
	else if(mysql_num_rows($chq)==1)
	{
		$chr=mysql_fetch_assoc($chq);
		$dq=mysql_query("Delete from b_active_accounts where ACCT_CASE='96157' and ACCT_SSN='".$sr['ACCT_SSN']."' and ID!='".$chr['UID']."'");
		$wr=$wr+mysql_affected_rows();
	}
	else if(mysql_num_rows($chq)>1)
	{
		echo $chr['UID'].'|'.$chr['ACCT_AGENT'].'|'.$sr['ACCT_AGENT'].'|'.$sr['CAPCODE'].'<br/>';
		$dr++;
		$agent='RCALL-DUP'.$sr['ACCT_AGENT'];
		$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='$agent' where ID='".$sr['ID']."'");
		$ur=$ur+mysql_affected_rows();
	}
	
}
echo $nr.' --> '.$wr.' --> '.$dr.' --> '.$ur;
die();

$coehead="ACCT_AGENT,ACCT_CLIENT1,ACCT_SOR_DATE,ACCT_SSNUM,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,ACCT_DOB,ACCT_ID,ACCT_SCORE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_AREA,EMPL_PHONE1_NMBR"."\n";
	
	$coefile='To_ROCKY_Cus'.$wcase.'.csv';
	echo $coefpath='files/Admin/'.$coefile;
	$sendrc=0;
	//$coeupsq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='RAW' where case_no='$wcase' and Source_Code='122'");
	$coesq=mysql_query("Select * from rnnginc_webapp.a_intoRNN_POE where case_no IN ('71784','71805','71851','71849','71607') and status='RAW' group by social_security_number");
	if(mysql_num_rows($coesq)>0)
	{
		$coehandle = fopen($coefpath, "w");
		fwrite($coehandle,$coehead);
		
		$badpoe="hair dresser||army, navy, etc. ||ssa||va benefits||day care||freelancer||dept of defense||us air force||missing phone #'s||retired||ssi||benefits||disability||disabled||disabled veteran||home worker||homemaker||pension||self||self employed||selfemployed||slf||social security||ss||s.s.||s.s||ssd||ssdi||ssi||va||none||n/a ||na||widow ||military ret||unemployment||disabled veteran||daycare||benfits||veterans administration||self emp||us army||us congress||us marines||social security administration||social security-disability||us navy||retired ssi||n/a||social security disability||n/a||n/a||retired disabled||n/a||n/a||retired verizon||n/a||retireddeptofdef||social security/disability||social security adm||retired / part -time||social security & ravens store||self-employeed||soc sec va||sef employed||n/a||n/a||disabiled||ssi disabled||soc sec disab||ssi & ssd||disability ssi||n/a||home maker||retired - self employed||retired ssd||retired/ssi||disability income||ssi/ rail road||retssi||disabilityssi||ssi & pension||home maker||disabled vet||disabilty ssi||social security widow benefit||n-a||disability pending||disabilaty||retired pension business||home maker||ssd and child support||va local 322||ssi disb||n/a||retired city of wincheste||retired disable vet||ssdi pension||retirement rental||soc sec/dis||ue||ssid / alimony||ss va pension||home maker||social sec||social security desability||disabiltiy||retired state of california||ue||retired trucking||retired cbr||disability income||ss disability insurance||retired/us army||social security/disability||retired ssi||ssi pension||veterans admin||veterans pension||ue||n/a||va & federal government||ssdi pension||retirement and disability||retired disabled||ssi/pension||disability - ssd||va disability||soc security||ssi/retired||home/self||social security disability||disablilty||une||ssi retiment||veterans affair disa||social secuity||social security/disability||social security/disability||social security disability||social security/disability||social security ssi||retirement survivor annuity||social security/disability||social security administr||social security/disability||unemployed||social sercuity||social security/disability||disability/social security||socail security||ssi/retirement||disability/social security||social security disability||social security - disability||disability/social security||socialsecurityadministration||disable||social security administr||no job||ssi/disabilty||self employee||disability/social security||ssi social security||disability/social security||retired from d. m. v.||n/a||na sitter||no employer||retirement-va hosp||retired pers le||veterans of foreign wars department of montana||veterabn||disability 582||ss heating nle||veterans with dignity||ssi retirer||retired 67||soc sec 718 00||ssi and self emp landscaper||homemaker sdt||ssi 1070 00||ssi 4th wed of month||retired legal profes||self employed full time||social security retiremen||social security disab.||soc sec||retired from rent control||ss retirement||ssi and pension||va retirement||ssdi self employed||no poe||social securitu||no poe||retirement/pension/ss death||veterans affairs||socail security||ssi$ssa||va disabilaty||no job||retirement||retirement||ssi 766||retirement/pension||socialsecurity_disability||retirement||social security income||ss disability||unemployed||disability ss||ss & disability||ssi/dis||soc sec dis||ssi and di||social secuity disability||ss pension||retired sos sec||disabily||ssi retirement pension||not working||u e||soc sec & wife||u e||u e||retired johnson co sheriff||ss/retired||ssi and disability||soc sec disability||umemployed||social security ad||s s i disability||ss/ penison||retirement income||na on cbr||retired per cbr||social security disabilit||retrried pention||retired per cbr||u e||retired gm||soc sec & pension||retired veteran||ssi vad dfas||retired- pension||u e||retired gm||disablity ssi||ss retired||social security-retirement||retired per cbr||retired chrysler||ret||ss/retired||unemloyed||soc sec disability||ssidisability||disabililty||self emploed||self-employed||disabity||ssi/employed||unemployment benefits||disablity||ssidisability||retire||socialsecurity||unemploment||ss and va||not applicable||ssi & d||dissability||self emplyed||u e almst a yr||ssi 73 years old||ssi dob 10 1938||disability 1574||ssi 1115 mon||retired born 11 37||retired ssi pensio||ssi 600 month||ssi /pension||disbale||ssi (retired)||retired 08 31 05||retired military||disab||retired state of florida||na ssi||social security adm.||ssa disability||ssci||ssi/674||ssi/visiting anger||retired sub docs||retired from gm per cbr||retired-hopper constructi||disabilty||retired kansas building trades||veterans a||ssi/ssdi||retired us military||veteran s administration||ssd dss grant||disability benefits||soc sec benefits||ssi income||ssd ssi||social security retirement||disability/ workers comp||social security & annuity||ssd/pension||social security rec||ssd and comp||ss plus pension||ssi / pension||veterans disability||ss i||ssa recipient||soc sec recipient||retirement/ss||soc sec benefits||retired social security||socailsocarity||social security/ daycare||retired_benefits||retired/pension||social security/ self employed||disability benefits||self-employer||disbled||my self||social securtity||selfemployer||va disbility and retireme||scoial security||home||home||self emloyed||social security & ssi||retired and ssi||retired civil servic||retired boeing aircr||ssi & retirement||benefits admin corp||social security benefits||unknown||uber||ssi disabilty||ssi / widows pension||social security admin||soc||ssdi/pension-net||ssi monthly on 1st||ssn||ssi disab||ss recipient||ssdi benefits||ssi disability benefits||ssi/ pension||soc scc||social socurity||ssi 674 00 each month||ssi benefits||diabled||segura social/ssi||uber||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown||other ||disabled vet||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi pension va||ssi va pension||retired nypd||ss / workers comp||ssi and retirement||ss dis||retired pension||soc sec pension||ssi penson||ssd pension||soc sec / pen||retired social secur||retired nyc police officer||retired nyc corrections||retired ny dept corrections||ssi dissability||ss benefits||social sec recipient||social security recipient||retired from nyc law dept||social sec income||ssdssi||ssi recipient||social security recipient||social security recipient||ssd pension||ssi recipient||retired us army||soc security admin||ssi pension investments||retired transit worker||social security recipient||socai security||ssi/ssd||waiter||waitress||bartender||taxi driver||cab driver||disabled/ssi||un employed||disability self employed||ssdi social security||retiired||someone||adult and child||clean houses||sss disability||soical security||housewife||on disability||u.s. government||ss- $507.00||socical sercurity||ssbeneifits||daycare provider||mother||soical security||nothing||disabllty||soc sec retirement||retired general elec||retired city of cleveland||retired disabilty||house wife||no poe on cbr||retired - alcoa||disabilitly||child provider||retirement housing||social security / annuity||us social security administration||on ssa||my own buisiness||ssa.gov||social security disabilty||unemployed/going on disability||self employer||retired-social security||ssi diabilaty||i dont work||disabeled||retired from comprehensive care center||retired disablity||i am disable||retirment||disability and social security||husbands income||retired/ disabiliabled||ssid & childcare||self employed andcsocial security||self employment||child support||none-retired||catholic charities||social secuirty/disabilty||fedgoverment||na company||retired -ssa||pers retired/pension||disabled and child support||dis||ssdi/ssidi||united states army||retirement systems of alabama||social security administration benefits||ss administration||retired receive retirement/ss||ssaandstudent||s.s. disabled||ssi benifits||unemployment state of ohio||social serurity||social security di||retied||us disability||selfempl||s s i||ssldc||social security 1391||self imployed||unemploed||ssc||fedgovernment||husband on va disablity & socisal securty||ssa treas 31o xxsoc sec||ssi collect for myself||retired/disables||retired teacher||i am on security||not workng||sis||disibility||disability/pension||ssa & ltd||on social security disability||on disability||don't work||rertirment||retired and disability||social security widow||soc. sec.||gov\\||na company||social security and ssi||disabillity||military- army||house wifr||social security and disability||not specified||nonameyet||self support personal care||retiredselfemployedssdi||my cleaning co||on s.s,i > disibitiy||housewife my husband works at walmart||ss53rm disability||ssi/disability||fed government||selfempoled||ret army.||federal government||disability (ssi)||social security administrator||disabilitly||united states army||child care provider (paid by the state)||retired u s army||socail secretary||social securuty benefits||social securit||not collected||retited||currently disabled||s.s. disabilty||not available||notemployed||us army benefits||b||unmpolyment||not employed||home address||diability||army||missouri unemployment||social security disablity||ssi ss child support||dissablitity||na/receives disability||ssi unemployment||social securtiy beneifits||ssdi soc sec||none at this time||retired vet||ss benifits||not provided||n a between jobs who wants me i want to work||training up a child||no poe per cbr||hairstylist||ssissa||babysitting||miltary||retyirement||ssi civil service||retirement/disability||retired us navy||us navy va disability||usarmy||natalys home salon||employer name||not provided||ssi and benefits||none listed on cbr||ssi food asst||ssi per consumer||united states military||none cbr||retired)||pending disability||no poe cbr||ssi per cbr||disblty||not listed||no poe listed||none listed on cbr||usps retired||retired ny dept of correc||no poe onc br||retired-pension||ssa/ssi disability||house keeping||na/receives disability||usnavy||child care||ssdi soc sec||sst||remax/self employed||disabilityva||socal security||us military||permanently disabled||army ret||retired disable||usd 259 retired||dont work ssi||navy||court ordered child support||swlf employed||800-772-1213||disbilty||none on cbr||cbr says student||us military army||disabilitysocial sec||l aid of f||retired disability||retired from kroger 2007||retired navy||benefits||va disablity||ssi + pension||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||avon||veteran s benefits||non employed ||ssi/benefits||sitter||pension||retiree||diabled||segura social/ssi||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown(has no #'s) ||other (has no #'s)||disabled vet||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi||workman s comp||at home mom ||disabled-soc sec||worker comp||retored||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||veteran s benefits||non employed ||sitter||segura social||u s army||retired ssi disabili||u.s. army||caregiver||n a||care taker||disability pension||babysitter||u s gov dept of army||retired nurse||social sacerity||childcare||ssi (0) (401)||survivors benefits ss||socaial security||va disibility||retired/disability||right at home||care taker||dept of defense - air firce...||ssi va||retired pera||disability per cnsmr||wendys no tlx hit||fmc retired||department of veterans af||ssi/chrysler||retired delphi||no record||retired val ss wife has busin||not listed in cbr||gm retired pension||disaiblityssi||mary kay||per cb approved mfg no info||ssi disability per cbr||i am retired||social secur||macys no tlx hit||avon||cbr na||i am christ minstry||net social security||disable with no income yet||ssi va||ssi-disability||retired/disabled||not employed-retired||retirement benefits||s s disabiltiy||ss disablity||no poe listed cbr||social security pension||mcdonalds mgr no tlx hit||retired ssi disability||cbr self emp||s s disability||us government no tlx hit||no po on cbr||us postal service no tlx||gm no tlx hit||disabled vetetan||ssoe group||ssidisablity &heartsidefoods||n\a||1099 self employed||us social security administration / gm||disabled homemaker||no||disiablity||retired postal worker||retired and social security||i am disabled vet collecting a check please help||gov assistance||self (was)now retired on s.s.||ssi / retirement / pension||ssi 647 00||government benefits||desempleo edd||ssi (0) (401)||retirement benefits||reteried||disability check||va/ssi||retired usps, and military retired||retired/social secuity||not employed at this time||ssid, disabled||retired army||department of defense||social security administration office of disability operations||social /death benifits||retired(deptof defense||disibiy||social sercurity administ||ssid||retierd||disability-social secur||social security pays her||disabled ssi||ssid||ssa and ssi||disabled ssi||va ssi||daughters ssi||ssisuplement||ssi - tanf||ssi dissabiluty||oregon ssi||retired-ssi-va||ssdi and ssi||ssi incom||pension ssi||ssi 00000-0000||ssi3rd1569||ssi death benefit||ssi- disability||ssi disablity||ssi 00000-0000||ssi office||ssi-1st 00000-0000||ssi and child support||ssid||vassi||ssi-3rd||ssi subsidy||fargo ssi||ssi baby sitter||ssidiss||ssi for daughter||ssi3rd1279.00||ssi grossed up||ssiannuity||retired dissability||retiredusarmy||retired-disb||retired us.army||retired and pension||retireddisa||retired-disabled||us army retired||retired spartan stores||social disability||disability-social secur||social securitydisabili||disability-social secur||social security pays her||disability-social secur||disability-social secur||social securitydisabili||social security office||social security adminis||disability-social secur||social security--1st||disability social secur||disability-social secur||disability-social secur||social worker||disability-social secur||social security 3rd of every 0||disability-social secur||socialsecuritybenefits||social securty disabili||disability-social secur||disability-social secur||social security adminis||socialional||social security disab||disability-social secur||disability-social secur||social security disabil||disability-social secur||social studies school ser||social media consult serv||social security admini||disability-social secur||disability-social secur||disability-social secur||self emploted||self empolyed||self employed ryans rod s||work for myself||self employeed- barber||self employeed||self employed schilling||self kennedy corp||self employeed||self employeed||self employed self empl||self employed nanny||selfemployedx2f1099 emp||self-employee||craig moore - self||self employed dover dowry.com||self employeed||self employed home heal||self direct||self employeed||self-billie walker||uberself employed||self employed care take||selfemployedx2f1099 emp||self employed barber||self employeed||self employed-owner||self emplooyed||workers compensation||housekeeping||housekeeping||baby sitter||cleaning and baby sitti||babysitterefri 300||social security/pension||disability social security||disability social security||recv ssi disability||disabled ss workman com||retired united states a||ss dis 00000-0000||ssid||retired - ssi||social sec disabity||homemaker and take care of elderly||ssi 3rd||ssid||pssi||ssi government pay||ssi/disabitly||ssd &ssi||ssi/child support/tafdc||i am on ssi||ssi/adoption||disssi**1st & 3rd**||ssi 1st||ssi (1st)||disibiltyssi||ssi\ssa||ssi (1st)||retiredssi||ssi dis net||retirement-ssi||social securiy||social security disabilities||social security state of||socail securty||soci||disability social se||disability social security||social security admi||social sercurity||social secuirty||socialecurity||security social||social secruity||social security '||us social security a||socjal security||disability-social secur||social security disabil||social security retirem||social security 00000-0000||soc secdaycare||disabled social securit||social security disabi||social securites||socjal security||social security disabil||soc security (1st3rd)||soc sec admin||social securitydisabili||social security disabi||disability-social secur||social security disabil||social securitydisability||va retired||disabled retired vetera||retired-hilton hawaiian||retiredpention||railroad retirement disability||disability and retirement||us army - military retired||retired us air force||us army retired||disability & retired||fred thornton/ retired||retired va||retired-shipyard||retired 00000-0000||retiredd - military||retired 00000-0000||retired with pension||retired smco||retired 00000-0000||self employed retired||gm retired||retieed||caretaker||retier||disibity||disabled/mgr burger king||ssa disablity||disability rights center-kansas||state disability||la. disability determinat||va disability and ssdi||disiblity||permanent dissability||disabilities rights||disabale||unemployeement dis||ss disable||disabled miltary veteran||dis. 1st||s.s.idisability||disability - 2 checks   730||dis (3rd)||sosial security disabil||disablitiy||disabiloity||disabilty from aflac||disability1st 00000-0000||self - daycare||self employed massage t||self employeed||self employed-toolz n t||self daycare||self-rental property||selfemployeed-mkt||self-daycare||self employedowner||self employeed||self-employed uber driver||self - home remodel||self employed (painter)||nys unemployment||child support/unempl||layoff unemployment  47||ssi benefits||diabled||segura social/ssi||uber||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown(has no #'s) ||other (has no #'s)||disabled vet||hope community||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi||workman s comp||at home mom ||disabled-soc sec||worker comp||retored||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||avon||veteran s benefits||non employed ||ssi/benefits||sitter||pension||retiree||unknown ||segura social||international pension||social secretirement||2nd income ||home maker||home maker mom||lyft||permanent disability||ssi/da||ssi/pns||foster grandparents||self employed/musician ||ssi income ||full time student ||funded by parents ||privatecaregiver||care giver||social security 4||military pension||ssdi||dlsability||self employed2||unemployed ||2nd income||2nd income||2nd income||2nd income||military disability||dis from metlife||disabled va benefits||disability-sondaughter||disablety||disabled mth.||dis veteran 00000-0000||dis3rd931||disability on 2 kids||dis3rd1194||dis 3rd 1072 00000-0000||social security-disabil||dis 00000-0000||ssi disabled 00000-0000||disability 3rd wed 00000-0000||social security dis||disability 00000-0000||dis-third dd to mutual saving||disabss||ssi disability 00000-0000||disability rights||dis-safeway||social security-disabil||retired nfl||retirementssi||retirementss||retirement  ss||retiredinv||retirement-||social security benefit||ssi her 00000-0000||ssi-child support||ssi for a child||perm dis ssi||ssi-ssa||ssipension||ssi benefits ||pension and ssi||ssdi ssi||ihss and ssi||ssi f||ssa 2nd wed 1257.00 00000-0000||other||other||other income||self emp - seven day beau||self employed construction 000||selfgraphic designer||selfgardener||self-landscaping||hcc construction self||self employee avonjoyas||self employedserigio fi||self emplolyeed||ssi/pension (va)/pension (usps)||ssi c#526619845a||ssi disability va pe||ssi benefit||ssi di||ca disability||disabled vet veterans pension||pendind disability||social security disability opm postal retirement||social security / disability||social seurity disab||socialsecurity disability||ss disabilty||disability network wayne county||social security disability benefits||copes. /dshs s.s.a disability||i am disabled||ny dissabilitay||ssdi.org - social security disability information||sc disability||disability income and social security income||social security / disability||no longer emp as of dec||self employment expo||officeemploye||myofficeemploye||self employed baby sitter||umemployment||self manufacturer||self contract||ssi 2nd wednesday||ssi retirement||ssi husband||ssipension||ssid||ssi 00000-0000||ssinew horizon||disabled ssi||pension ssi||retirement and ssi||penion ssi||ssi retirement||ssipension||retiredssi||ssi grossed up||ssid||ssi 00000-0000||ssissd||soc ssi||ssi   ssd||ssi 00000-0000||disabled ssi||reitred ssi||ssi ssa||ssi/ consultant||ssissdchild support||ssi survivors benefits||retired-ssi-va||ssi||ssi and child support||the ssi group||get ssi||ssi and dis||ssi - 1 child||ssi- dis||olympic diner  ssi||unemployed-ssi||retiredssissdpension||ssi and alimony||ssi 122||ssi/social security||social security disability /ssi||ssi ssdi||va compensation||workmans compensation||widows pension||retired pension ss||retired spfld city sch||retired-city of lngv||u.s navy retirement||sprintretired||retired ss||retird||retired 00000-0000||retired - dmv||caretaker||retired- va benefits||retired-disability||us army retired||fedex retirement||social security 00000-0000||disability-social secur||social security disabil||us soc sec disability||social security disabil||social security disab||disability and socail security||disability-soc sec||social vocational services||soc sec-widows benefits||soc. sec. dis.||social security dis||social security - disab||social||social security room 2||social security 00000-0000||social security disabil||social security and dis||disability-social secur||disability-social secur||socsecben||disability-social secur||social security 00000-0000||social security admi||social security   disab||disability-social secur||social security adminis||social security ha||social security 00000-0000||social3||disability-social secur||social security 00000-0000||social security dis||social security disabil||social security adminis||disability-social secur||social secrutiy||disability-social secur||receive social security||self employed recyclin||sekf employed||unemploymet||selfemployedx2f1099 emp||self employed legally||selfemployedx2f1099 emp||disemployed||self-employed caregiver||self-employedx2f1099 e||slef employed||wi unemployment||unempoloyed||temp disability||self-employedx2f1099 e||self employeed||not currenly employoed||self employeed||self employedlogger||self - employed||tempstaff||selfemployedx2f1099 emp||unemplyed||employer||unemployed take care of||self employed - it spec||self employeed||temporary fill ins||unemployed with income||cmo title loan noemploy||self employed barbershop||not employed as of yet||cmo title loan noemploy||self funeral director||self- silvercreek reali||my self my mother||self one stop auto||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income 00000-0000||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||work||workers comp||work at home||work||work||isabled||private daycare||foster care||caregiver services||care givers||licensed care givers||selfemployed||self employee||selfemploy||self-employee||self_employee||self employeed||selfemployeed||self-employeed||creditors collection||creditors collection service||aarons||aaron's||champion financial services||champion financial";
		$badpoear=explode('||',$badpoe);
		
		while($coerow=mysql_fetch_assoc($coesq))
		{
			$coerow = array_map(
			function($coerow) {
				$x=str_replace("'", "", $coerow);
				$x=str_replace("\n", " ", $x);
				$x=str_replace("/", "RNNSLASH", $x);
				$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
				$x=str_replace("RNNSLASH", "/", $x);
				return str_replace(",", "", $x);
			},
			$coerow
			);
			
			$chkphn=preg_replace("/[^0-9]+/", "", $coerow['employer1_telephone']);
			if($chkphn!='')
			{
				$chkphn=substr($chkphn,-10);
			}
			if(in_array(strtolower($coerow['employer1_name']),$badpoear))
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='TRASHED' where id='".$coerow['id']."'");
			}
			else if($chkphn=='6784023000')
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='TRASHED' where id='".$coerow['id']."'");	
			}
			else if($chkphn=='8007221213' && $coerow['employer1_name']=='')//SSI Phone Trash
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='TRASHED' where id='".$coerow['id']."'");
			}
			else
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='RAW' where id='".$coerow['id']."'");
				
				$dued=date('Ymd', strtotime($coerow['Due_Date'].' - 2 Weekday'));
				$phnar='';
				$phnnm=$chkphn;
				$dcheck=preg_replace("/[^0-9]+/", "", $coerow['date_of_birth']);
				if(strlen($dcheck)>6)
				{
					$dob=date('Ymd', strtotime($coerow['date_of_birth']));
				}
				else
				{
					$dob='';	
				}
				
				$insrow=''.','.$coerow['case_no'].','.$dued.','.$coerow['social_security_number'].','.$coerow['first_name'].','.$coerow['last_name'].','.$coerow['street_address_1'].','.$coerow['street_address_2'].','.$coerow['city_name'].','.$coerow['state_name'].','.$coerow['zip_code'].','.$dob.','.$coerow['id'].','.$coerow['Source_Code'].','.$coerow['employer1_name'].','.$coerow['employer1_address'].','.$coerow['employer1_address2'].','.$coerow['employer1_city'].','.$coerow['employer1_state'].','.$coerow['employer1_zip'].','.$phnar.','.$phnnm."\n";
				$sendrc++;
				fwrite($coehandle,$insrow);
			}
		}
		fclose($coehandle);
	}

die();


include("sendgrid/sendgrid_mail_function.php");


$sq=mysql_query("Select ID from b_active_accounts where ACCT_AGENT='' and SECOND_CASE='20202020'");
while($sr=mysql_fetch_assoc($sq))
{

	$aq=mysql_query("Select ACCT_AGENT, ACCT_COE from b_work_history where UID='".$sr['ID']."' and CAPCODE='2210' order by ID DESC");
	if(mysql_num_rows($aq)>0)
	{
		$ar=mysql_fetch_assoc($aq);
		$nagntid=substr($ar['ACCT_AGENT'],-4);
		$ncoe=$ar['ACCT_COE'];
	}
	else
	{
		$ncoe='COL';
		$nagntid='9999';
	}
	$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='".$nagntid."', ACCT_COE='".$ncoe."' where ID='".$sr['ID']."'");
	$aas=$aas+mysql_affected_rows();
}
echo 'Updated Agents: '.$aas;

mysql_query("Update `b_active_accounts` SET ACCT_COE='ATL' where ACCT_AGENT Like '4%' OR ACCT_AGENT='4444'");
mysql_query("Update `b_active_accounts` SET ACCT_COE='COL' where ACCT_AGENT Like '3%' OR ACCT_AGENT='9999'");
mysql_query("Update `b_active_accounts` SET ACCT_COE='EBC' where ACCT_AGENT Like '5%' OR ACCT_AGENT='8888'");
mysql_query("Update `b_active_accounts` SET ACCT_COE='5C' where ACCT_AGENT Like '6%' OR ACCT_AGENT='7783'");
mysql_query("Update `b_active_accounts` SET ACCT_COE='BOT' where ACCT_AGENT Like '1%'");

$sql=mysql_query("Select * from rnnginc_webapp.rnnwusers where coerestrict!=''");
while($sqr=mysql_fetch_assoc($sql))
{
	if($sqr['coerestrict']=='ATL'){ $coeaid='4444'; }
	if($sqr['coerestrict']=='5C'){ $coeaid='7783'; }
	if($sqr['coerestrict']=='EBC'){ $coeaid='8888'; }
	if($sqr['coerestrict']=='COL'){ $coeaid='9999'; }

	if($sqr['coerestrict']=='ATL')
	{
		$upq="Update rnnginc_webapp.b_active_accounts SET ACCT_COE='ATL', ACCT_AGENT='$coeaid' where ACCT_CLIENT='".$sqr['id']."' and ADD_FILE='$cfilename' and ACCT_COE NOT IN ('ATL','EMP','BOT','5C')";
	}
	else if($sqr['coerestrict']=='5C')
	{
		$upq="Update rnnginc_webapp.b_active_accounts SET ACCT_COE='5C', ACCT_AGENT='$coeaid' where ACCT_CLIENT='".$sqr['id']."' and ADD_FILE='$cfilename' and ACCT_COE NOT IN ('5C','BOT')";
	}
	else
	{
		$upq="Update rnnginc_webapp.b_active_accounts SET ACCT_COE='".$sqr['coerestrict']."', ACCT_AGENT='$coeaid' where ACCT_CLIENT='".$sqr['id']."' and ADD_FILE='$cfilename' and ACCT_COE!='".$sqr['coerestrict']."'";
	}
	mysql_query($upq);
	$bba=$bba+mysql_affected_rows();
}

echo "Moved Accounts: ".$bba;

die();


$to = "prateektgi@gmail.com,prateekg@rnngroup.com";
$from = "no-reply@younegotiate.com";
$subject = "Test Email";
$header = "YouNegotiate.com";
echo $message='<html>  
<style>
.btn-success{background: -webkit-gradient(linear, left top, left bottom, from(#1d9609), to(#35a523));
background: linear-gradient(to bottom, #1d9609 0%, #35a523 100%); border:1px solid #1d9609; padding:10px 20px 10px 20px; color:#FFFFFF !important; font:bold 16px/18px Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif; }

.btn-primary{background: -webkit-gradient(linear, left top, left bottom, from(#3887ff), to(#43caeb));
background: linear-gradient(to bottom, #3887ff 0%, #43caeb 100%); border:1px solid #3887ff; padding:10px 20px 10px 20px; color:#FFFFFF !important; font:bold 16px/18px Segoe, "Segoe UI", "DejaVu Sans", "Trebuchet MS", Verdana, sans-serif; }

</style>
    <body>
      
    <div align="center" style="border:5px solid #0079f2; padding:20px; font-family:Arial, Helvetica, sans-serif; background:#ffffff !important; width:70% !important; margin:0 auto;">
      
      <div align="center">
      	<img src="https://younegotiate.com/logo.png">
      </div>
      <p>&nbsp;</p>
      <p align="justify">
      	Welcome to YouNegotiate!
      </p>
      
      <p align="justify">
      	Thanks for Signing Up on YouNegotiate.<br>
		
        Please click the below link or copy paste the below URL to CONFIRM your email address.
      </p>
      <p align="left">
      <input type="button" class="btn-success" value="Click Here to Confirm Your Email!" />
      <input type="button" class="btn-primary" value="Click Here to Confirm Your Email!" />
      </p>
    </div>
  </body> 
</html>		
';

sendgrid_mail($to,$from,$subject,$message,$header);

die();

echo $thead="ID,CAPCODE,AGENT,ACT_AGENT,ROCKY_EMPL_NAME,PP_EMPL_NAME,ROCKY_PHONE,PP_PHONE"."<br/>";
$aq=mysql_query("Select * from all_incoming_vpoe_hits where vendor ='1572-Pinpoint VPOE' order by id desc limit 10000");
while($ar=mysql_fetch_assoc($aq))
{

	$sq=mysql_query("Select UID, ACCT_ID, EMPL_PHONE1_NMBR, CAPCODE, ACCT_AGENT, EMPL_NAME from b_closed_accounts where ACCT_CASE='".$ar['case_no']."' and ACCT_SSN='".$ar['social_security_number']."'");
	if(mysql_num_rows($sq)>0)
	{
		$sr=mysql_fetch_assoc($sq);
		echo $row=$sr['ACCT_ID'].','.$sr['CAPCODE'].','.$sr['ACCT_AGENT'].','.substr($sr['ACCT_AGENT'],-4).','.$sr['EMPL_NAME'].','.$ar['rnn_employer_name'].','.$sr['EMPL_PHONE1_NMBR'].','.$ar['rnn_employer_phone']."<br/>";
		$aa++;
	}
	if($aa==100)
	{
		break;
	}
}
die();

$sq=mysql_query("Select ACCT_ID, ACCT_AGENT, ACCT_COE, AEMPL_EMAIL, CLOSED_ON from b_closed_accounts where length(ACCT_AGENT)=4 and CLOSED_ON Like '2019-11-%'");
$fhand=fopen("Pref_Method_Report_Nov2019.csv","w");
$thead="ID,AGENT,COE,TIME,VER_TYPE,VER_PHONE,VER_AUTO_PHONE,VER_FAX,VER_EMAIL"."\n";
fwrite($fhand,$thead);
while($sr=mysql_fetch_assoc($sq))
{
	$ex=explode('|',$sr['AEMPL_EMAIL']);
	$type=$ex[19];
	$phone=$ex[20];
	$fax=$ex[21];
	$email=$ex[22];
	$autophone=$ex[27];
	$agent=$sr['ACCT_AGENT'];
	$coe=$sr['ACCT_COE'];	
	$row=$sr['ACCT_ID'].','.$agent.','.$coe.','.$sr['CLOSED_ON'].','.$type.','.$phone.','.$autophone.','.$fax.','.$email."\n";
	fwrite($fhand,$row);
}

die();

$emq=mysql_query("SELECT ID, UID FROM b_powerlead_active order by ID ASC");
if(mysql_num_rows($emq) > 0 )
{
	while($rw = mysql_fetch_assoc($emq))
	{
		$sq=mysql_query("Select ID from b_active_accounts where ID='".$rw['UID']."' and ACCT_AGENT not like '%PPOF%' and ACCT_AGENT not like '%RCALL%'");
		$actid=$rw['ID'];
		if(mysql_num_rows($sq)==0)
		{
			$cinsw="INSERT INTO `b_powerlead_closed`(`ID`, `UID`, `ACCT_AGENT`, `ACCT_COE`, `ADD_DATE`, `ACCT_CASE`, `ACCT_CLIENT`, `ACCT_FNAME`, `ACCT_LNAME`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `EMPL_NAME`, `PHONE_LEAD`, `PHONE_TYPE`, `ADDR_LEAD`, `ADD_TYPE`, `EMPL_WEBSITE`, `EMPL_FB`, `PHONE_CORP`, `ADDR_CORP`, `EMPL_FAX`, `EMPL_EMAIL`, `PHONE_LOCAL1`, `ADDR_LOC1`, `PHONE_LOCAL2`, `ADDR_LOC2`, `ACCT_SOURCE`, `ACCT_LINKEDIN`, `EMPL_3RD`, `EMPL_3RD_NUMBER`, `CAPCODE`, `AUTONOTES`, `LAST_UPDATE`, `CUSTOM1`, `CUSTOM2`, `CUSTOM3`, `CUSTOM4`, `shortname`) Select `ID`, `UID`, `ACCT_AGENT`, `ACCT_COE`, `ADD_DATE`, `ACCT_CASE`, `ACCT_CLIENT`, `ACCT_FNAME`, `ACCT_LNAME`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `EMPL_NAME`, `PHONE_LEAD`, `PHONE_TYPE`, `ADDR_LEAD`, `ADD_TYPE`, `EMPL_WEBSITE`, `EMPL_FB`, `PHONE_CORP`, `ADDR_CORP`, `EMPL_FAX`, `EMPL_EMAIL`, `PHONE_LOCAL1`, `ADDR_LOC1`, `PHONE_LOCAL2`, `ADDR_LOC2`, `ACCT_SOURCE`, `ACCT_LINKEDIN`, `EMPL_3RD`, `EMPL_3RD_NUMBER`, `CAPCODE`, 'InactiveLeads' as `AUTONOTES`, '$tdate' as `LAST_UPDATE`, `CUSTOM1`, `CUSTOM2`, `CUSTOM3`, `CUSTOM4`, `shortname` from b_powerlead_active where ID= '$actid'";
			mysql_query($cinsw);
			if(mysql_affected_rows()>0)
			{
				$delq=mysql_query("Delete from b_powerlead_active where ID= '$actid'");
				$de=$de+mysql_affected_rows();
			}
		}	
	}
}

echo '<br> Inactive Removed: '.$de.'<br/>';

die();
$sq=mysql_query("Select * from b_active_accounts order by LAST_WORKED DESC");
while($sr=mysql_fetch_assoc($sq))
{
	$ssn=$sr['ACCT_SSN'];
	$case=$sr['ACCT_CASE'];
	
	$acq=mysql_query("Select ID from b_active_accounts where ACCT_CASE='".$case."' and ACCT_SSN='$ssn'");
	if(mysql_num_rows($acq)>1)
	{
		$ins=mysql_query("Insert into b_active_accounts_dup_remove Select * from b_active_accounts where ACCT_CASE='".$case."' and ACCT_SSN='$ssn' and ID!='".$sr['ID']."'");
		
		$daq=mysql_query("Delete from b_active_accounts where ACCT_CASE='".$case."' and ACCT_SSN='$ssn' and ID!='".$sr['ID']."'");
		$del++;
	}
	
	$acq=mysql_query("Select ID from b_closed_accounts where ACCT_CASE='".$case."' and ACCT_SSN='$ssn'");
	if(mysql_num_rows($acq)>0)
	{
		$ins=mysql_query("Insert into b_active_accounts_dup_remove Select * from b_active_accounts where ACCT_CASE='".$case."' and ACCT_SSN='$ssn' and ID='".$sr['ID']."'");
		
		$daq=mysql_query("Delete from b_active_accounts where ACCT_CASE='".$case."' and ACCT_SSN='$ssn' and ID='".$sr['ID']."'");
		$del++;
	}
}
echo $del;
die();
$sr['ACCT_CASE']='81645';
$ahead="social_security_number,first_name,last_name,street_address_1,street_address_2,city,state,zip_code,date_of_birth,phone_1,phone_2,phone_3,client_field_1,client_field_2,client_field_3,client_field_4,client_field_5,account_open_date,rnn_id,rnn_employer_name,rnn_employer_address_1,rnn_employer_address_2,rnn_employer_city,rnn_employer_state,rnn_employer_zip,rnn_employer_phone,source_code,status"."\n";
$ehead="rnn_id,rnn_employer_name,rnn_employer_address_1,rnn_employer_address_2,rnn_employer_city,rnn_employer_state,rnn_employer_zip,rnn_employer_phone,source_code,status,verification_method"."\n";
$fsq=mysql_query("SELECT * FROM `b_closed_accounts` WHERE TIER='8' and ACCT_CASE='".$sr['ACCT_CASE']."'");
		//$fsq=mysql_query("SELECT ACCT_CASE, ACCT_AGENT, CAPCODE, UID, ACCT_ID, EMPL_PHONE1_NMBR, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP` FROM `b_closed_accounts` WHERE TIER='9' and SECOND_CASE=''");
		if(mysql_num_rows($fsq)>0)
		{
			$efullpath='files/Admin/Cases/'.$sr['ACCT_CASE'].'/'.$tdate.'_'.$sr['ACCT_CASE'].'_CLEADS2_ERRORs.csv';
			$efname=basename($efullpath);
			$ehandle=fopen($efullpath,'w');
			fwrite($ehandle,$ahead);
			echo $afullpath='files/Admin/Cases/'.$sr['ACCT_CASE'].'/'.$tdate.'_'.$sr['ACCT_CASE'].'_CLEADS2_Completed_Accounts.csv';
			$afname=basename($afullpath);
			$ahandle=fopen($afullpath,'w');
			fwrite($ahandle,$ahead);
			//echo '<br/>';
			$chits=0;$awgerr='';$misemp='';$chits=0;
			while($fsr=mysql_fetch_assoc($fsq))
			{
				$cc1='';$cdesc='';$awgrow='';$cc1='';$cap='';
				$fsr = array_map(
				function($fsr) {
					$x=str_replace("'", "", $fsr);
					$x=str_replace("\n", " ", $x);
					$x=str_replace("/", "RNNSLASH", $x);
					$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
					$x=str_replace("RNNSLASH", "/", $x);
					$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
					return str_replace(",", "", $x);
				},
				$fsr
				);
				
				$export=mysql_query("SELECT `social_security_number`, `first_name`, `last_name`, `street_address_1`, `street_address_2`, `city_name`, `state_name`, `zip_code`, `date_of_birth`, `phone_1`, `phone_2`, `phone_3`, `client_field_1`, `client_field_2`, `client_field_3`, `client_field_4`, `client_field_5`, `account_open_date` from a_intoRNN_POE_completed where case_no='".$sr['ACCT_CASE']."' and social_security_number='".$fsr['ACCT_SSN']."'");
				if(mysql_num_rows($export)>0)
				{
					$exportrow=mysql_fetch_assoc($export);
					$exportrow = array_map(
					function($exportrow) {
						$x=str_replace("'", "", $exportrow);
						$x=str_replace("\n", " ", $x);
						$x=str_replace("/", "RNNSLASH", $x);
						$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
						$x=str_replace("RNNSLASH", "/", $x);
						$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
						return str_replace(",", "", $x);
					},
					$exportrow
					);
					$expl=explode("-",$exportrow['rnn_id']);
					
					$cc1=substr($fsr['CAPCODE'],0,1);
					if($cc1==2)
					{
						$cdesc='INCONCLUSIVE';
					}
					else if($cc1==1)
					{
						$cdesc='YES';
					}
					else
					{
						$cdesc='NO';
					}
					
					if($fsr['EMPL_PHONE1_NMBR']!='')
					{
						$fsr['EMPL_PHONE1_NMBR']=preg_replace("/[^0-9]+/", "", $fsr['EMPL_PHONE1_NMBR']);
						$fsr['EMPL_PHONE1_NMBR']=substr($fsr['EMPL_PHONE1_NMBR'],-10);
					}
					$cc1=substr($fsr['CAPCODE'],0,1);
					if($cc1==1)
					{
						$cap=$fsr['CAPCODE'];
					}
					else
					{
						$cap='';
					}
					$arow=implode(',',$exportrow).','.$sr['ACCT_CASE'].'-'.$fsr['ACCT_ID'].','.$fsr['EMPL_NAME'].','.$fsr['EMPL_ADDR1'].','.$fsr['EMPL_ADDR2'].','.$fsr['EMPL_CITY'].','.$fsr['EMPL_ST'].','.$fsr['EMPL_ZIP'].','.$fsr['EMPL_PHONE1_NMBR'].','.$fsr['ACCT_SOURCE'].','.$cdesc.','.$cap."\n";
					fwrite($ahandle,$arow);
					$chits++;
					
				}
				else
				{	
					echo '<br/>';
					
					echo $errow=$sr['ACCT_CASE'].'-'.$fsr['ACCT_ID'].','.$fsr['EMPL_NAME'].','.$fsr['EMPL_ADDR1'].','.$fsr['EMPL_ADDR2'].','.$fsr['EMPL_CITY'].','.$fsr['EMPL_ST'].','.$fsr['EMPL_ZIP'].','.$fsr['EMPL_PHONE1_NMBR'].','.$fsr['ACCT_SOURCE'].','.$cdesc."\n";
					fwrite($ehandle,$errow);
					$awgerr.=$errow;
				}
			}
			fclose($ahandle);
			fclose($ehandle);
			
		}

die();

$sq=mysql_query("Select ACCT_ID, ACCT_AGENT, ACCT_COE, AEMPL_EMAIL, CLOSED_ON from b_closed_accounts where length(ACCT_AGENT)=4 and CLOSED_ON Like '2019-10-%'");
$fhand=fopen("Pref_Method_Report_Oct2019.csv","w");
$thead="ID,AGENT,COE,TIME,VER_TYPE,VER_PHONE,VER_AUTO_PHONE,VER_FAX,VER_EMAIL"."\n";
fwrite($fhand,$thead);
while($sr=mysql_fetch_assoc($sq))
{
	$ex=explode('|',$sr['AEMPL_EMAIL']);
	$type=$ex[19];
	$phone=$ex[20];
	$fax=$ex[21];
	$email=$ex[22];
	$autophone=$ex[27];
	$agent=$sr['ACCT_AGENT'];
	$coe=$sr['ACCT_COE'];	
	$row=$sr['ACCT_ID'].','.$agent.','.$coe.','.$sr['CLOSED_ON'].','.$type.','.$phone.','.$autophone.','.$fax.','.$email."\n";
	fwrite($fhand,$row);
}

die();
$sq=mysql_query("Select SQL_NOTES, count(ID) as tot from b_closed_accounts where SQL_NOTES like '%VER_201910%' and CAPCODE Like '1%' group by SQL_NOTES");

while($sr=mysql_fetch_assoc($sq))
{
	$bas=basename($sr['SQL_NOTES']);
	$nn=str_replace('Ver_COE_','',$bas);
	$no_of_lines=0;
	
	$chk=mysql_query("Select * from auto_ftp_files where destination Like '%".$nn."%'");
	if(mysql_num_rows($chk)>0)
	{
		$chr=mysql_fetch_assoc($chk);
		$no_of_lines = count(file($chr['destination']));	
		if(($no_of_lines-1)==$sr['tot'])
		{
			echo 'matched,'.$nn.'<br/>';
		}
		else
		{
			echo 'UNmatched,'.$nn.','.$no_of_lines.','.$sr['tot'].'<br/>';	
		}
	}
	else
	{
		echo 'NotFound,'.$nn.','.$no_of_lines.','.$sr['tot'].'<br/>';
	}
}
die();
$sr['ACCT_CASE']='81645';
$ahead="social_security_number,first_name,last_name,street_address_1,street_address_2,city,state,zip_code,date_of_birth,phone_1,phone_2,phone_3,client_field_1,client_field_2,client_field_3,client_field_4,client_field_5,account_open_date,rnn_id,rnn_employer_name,rnn_employer_address_1,rnn_employer_address_2,rnn_employer_city,rnn_employer_state,rnn_employer_zip,rnn_employer_phone,source_code,status"."\n";
$ehead="rnn_id,rnn_employer_name,rnn_employer_address_1,rnn_employer_address_2,rnn_employer_city,rnn_employer_state,rnn_employer_zip,rnn_employer_phone,source_code,status"."\n";
$fsq=mysql_query("SELECT * FROM `b_closed_accounts` WHERE TIER='8' and ACCT_CASE='".$sr['ACCT_CASE']."'");
		//$fsq=mysql_query("SELECT ACCT_CASE, ACCT_AGENT, CAPCODE, UID, ACCT_ID, EMPL_PHONE1_NMBR, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP` FROM `b_closed_accounts` WHERE TIER='9' and SECOND_CASE=''");
		if(mysql_num_rows($fsq)>0)
		{
			$efullpath='files/Admin/Cases/'.$sr['ACCT_CASE'].'/'.$tdate.'_'.$sr['ACCT_CASE'].'_CLEADS2_ERRORs.csv';
			$efname=basename($efullpath);
			$ehandle=fopen($efullpath,'w');
			fwrite($ehandle,$ahead);
			echo $afullpath='files/Admin/Cases/'.$sr['ACCT_CASE'].'/'.$tdate.'_'.$sr['ACCT_CASE'].'_CLEADS2_Completed_Accounts.csv';
			$afname=basename($afullpath);
			$ahandle=fopen($afullpath,'w');
			fwrite($ahandle,$ahead);
			//echo '<br/>';
			$chits=0;$awgerr='';$misemp='';$chits=0;
			while($fsr=mysql_fetch_assoc($fsq))
			{
				$cc1='';$cdesc='';$awgrow='';
				$fsr = array_map(
				function($fsr) {
					$x=str_replace("'", "", $fsr);
					$x=str_replace("\n", " ", $x);
					$x=str_replace("/", "RNNSLASH", $x);
					$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
					$x=str_replace("RNNSLASH", "/", $x);
					$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
					return str_replace(",", "", $x);
				},
				$fsr
				);
				
				$export=mysql_query("SELECT `social_security_number`, `first_name`, `last_name`, `street_address_1`, `street_address_2`, `city_name`, `state_name`, `zip_code`, `date_of_birth`, `phone_1`, `phone_2`, `phone_3`, `client_field_1`, `client_field_2`, `client_field_3`, `client_field_4`, `client_field_5`, `account_open_date` from a_intoRNN_POE_completed where case_no='".$sr['ACCT_CASE']."' and social_security_number='".$fsr['ACCT_SSN']."'");
				if(mysql_num_rows($export)>0)
				{
					$exportrow=mysql_fetch_assoc($export);
					$exportrow = array_map(
					function($exportrow) {
						$x=str_replace("'", "", $exportrow);
						$x=str_replace("\n", " ", $x);
						$x=str_replace("/", "RNNSLASH", $x);
						$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
						$x=str_replace("RNNSLASH", "/", $x);
						$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
						return str_replace(",", "", $x);
					},
					$exportrow
					);
					$expl=explode("-",$exportrow['rnn_id']);
					
					$cc1=substr($fsr['CAPCODE'],0,1);
					if($cc1==2)
					{
						$cdesc='INCONCLUSIVE';
					}
					else if($cc1==1)
					{
						$cdesc='YES';
					}
					else
					{
						$cdesc='NO';
					}
					
					if($fsr['EMPL_PHONE1_NMBR']!='')
					{
						$fsr['EMPL_PHONE1_NMBR']=preg_replace("/[^0-9]+/", "", $fsr['EMPL_PHONE1_NMBR']);
						$fsr['EMPL_PHONE1_NMBR']=substr($fsr['EMPL_PHONE1_NMBR'],-10);
					}
					
					$arow=implode(',',$exportrow).','.$sr['ACCT_CASE'].'-'.$fsr['ACCT_ID'].','.$fsr['EMPL_NAME'].','.$fsr['EMPL_ADDR1'].','.$fsr['EMPL_ADDR2'].','.$fsr['EMPL_CITY'].','.$fsr['EMPL_ST'].','.$fsr['EMPL_ZIP'].','.$fsr['EMPL_PHONE1_NMBR'].','.$fsr['ACCT_SOURCE'].','.$cdesc."\n";
					fwrite($ahandle,$arow);
					$chits++;
					
				}
				else
				{
					$errow=$sr['ACCT_CASE'].'-'.$fsr['ACCT_ID'].','.$fsr['EMPL_NAME'].','.$fsr['EMPL_ADDR1'].','.$fsr['EMPL_ADDR2'].','.$fsr['EMPL_CITY'].','.$fsr['EMPL_ST'].','.$fsr['EMPL_ZIP'].','.$fsr['EMPL_PHONE1_NMBR'].','.$fsr['ACCT_SOURCE'].','.$cdesc."\n";
					fwrite($ehandle,$errow);
					$awgerr.=$errow;
				}
			}
			fclose($ahandle);
			fclose($ehandle);
			
		}

die();
$bphand=fopen('Client_Phones.csv',"r");
while (($data = fgetcsv($bphand, 100000, ",")) !== FALSE) 
{
	if($i>0 && $data[0]!='')
	{
		$sq=mysql_query("update rnnwusers SET coephone='".$data[2]."' where id ='".$data[0]."'");
	}
	$i++;	
}

die();

$export=mysql_query("SELECT `social_security_number`, `first_name`, `last_name`, `street_address_1`, `street_address_2`, `city`, `state`, `zip_code`, `date_of_birth`, `phone_1`, `phone_2`, `phone_3`, `client_field_1`, `client_field_2`, `client_field_3`, `client_field_4`, `client_field_5`, `account_open_date`, concat(`case_no`,'-',`id`) as `rnn_id`, `employer_name`, `employer_address_1`, `employer_address_2`, `employer_city`, `employer_state`, `employer_zip`, `employer_phone_1`, `employer_phone_2`, `employer_phone_3`, `employer_phone_4`, `employer_phone_5`, `employer_phone_6`, `employer_phone_7`, ACCT_ID from rnnginc_webapp.a_intoRNN_EMPPH_completed where case_no='82422' order by id asc");
$header='';
/*$fields = mysql_num_fields ( $export );
for ( $i = 0; $i < $fields; $i++ )
{
	$header .= mysql_field_name( $export , $i ) . ",";
}
$header=rtrim($header,',')."\n";*/

$tinp=0;$awgnohit=0;$awgins=0;
if(mysql_num_rows($export)>0)
{
	while( $ndata = mysql_fetch_assoc($export))
	{
		$ndata = array_map(
		function($ndata) {
			$x=str_replace("'", "", $ndata);
			$x=str_replace("\n", " ", $x);
			$x=str_replace("/", "RNNSLASH", $x);
			$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
			$x=str_replace("RNNSLASH", "/", $x);
			$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
			return str_replace(",", "", $x);
		},
		$ndata
		);
		$cxx=explode('-',$ndata['rnn_id']);
		
		$awgdob=date("Ymd",strtotime($ndata['date_of_birth']));
		if($ndata['employer_phone_1']!='' || $ndata['employer_phone_7']!='')
		{
			$dq=mysql_query("Select ID from b_active_accounts where ACCT_CASE='82422' and ACCT_SSN='".$ndata['social_security_number']."'");
			$aq=mysql_query("Select ID from b_closed_accounts where ACCT_CASE='82422' and ACCT_SSN='".$ndata['social_security_number']."'");
			if(mysql_num_rows($dq)==0 && mysql_num_rows($aq)==0)
			{
				$columbiaq="INSERT INTO rnnginc_webapp.`b_active_accounts`(`ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_PHONE1_NMBR`, `COE_RULE`, `POESCORE`, `TIER`) VALUES ('', '20191018', 'Sync.csv', '999', '2566', 'COL', '9977', '82422', '20191029', '".$ndata['social_security_number']."', '".$ndata['first_name']."', '".$ndata['last_name']."', '".$ndata['street_address_1']."', '".$ndata['street_address_2']."', '".$ndata['city']."', '".$ndata['state']."', '".$ndata['zip_code']."', '".$awgdob."', '".$ndata['ACCT_ID']."', '186', '".$ndata['employer_name']."', '".$ndata['employer_address_1']."', '".$ndata['employer_address_2']."', '".$ndata['employer_city']."', '".$ndata['employer_state']."', '".$ndata['employer_zip']."', '".$ndata['employer_phone_7']."', 'COL', '10', '9')";
				mysql_query($columbiaq);
				$awgins=mysql_affected_rows()+$awgins;
			}
			else
			{
				$dup++;
			}
			
		}
		else
		{
			$awgnohit++;
		}
		
		$ndata['rnn_id']=$cxx[0];
		$tinp++;
	}
}
echo 'Add:'.$awgins.' --> Dup:'.$dup.' --> NoHit:'.$awgnohit;
die();
$sq=mysql_query("Select ACCT_SSN, ID from b_active_accounts where ACCT_CASE='82422'");
while($sr=mysql_fetch_assoc($sq))
{
	$dq=mysql_query("Delete from b_active_accounts where ACCT_CASE='82422' and ACCT_SSN='".$sr['ACCT_SSN']."' and ID!='".$sr['ID']."' ");
	$r=$r+mysql_affected_rows();
}
echo $r;

die();
$sq=mysql_query("Select * from a_intoRNN_EMPPH_completed where case_no='82458'");

while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Update a_intoRNN_EMPPH_completed set employer_phone_1='".$sr['employer_phone_1']."', employer_phone_2='".$sr['employer_phone_2']."', employer_phone_3='".$sr['employer_phone_3']."', employer_phone_4='".$sr['employer_phone_4']."', employer_phone_5='".$sr['employer_phone_5']."', employer_phone_6='".$sr['employer_phone_6']."', employer_phone_7='".$sr['employer_phone_7']."' where case_no='82422' and social_security_number='".$sr['social_security_number']."'");
}

die();
$arr[63100277]='FL'; $arr[64000059]='TN'; $arr[61000104]='FL'; $arr[61000104]='VA'; $arr[125000105]='WA'; $arr[42000013]='OH'; $arr[107000327]='NM'; $arr[21200339]='NJ'; $arr[125000024]='WA'; $arr[107002312]='NM'; $arr[61000104]='GA'; $arr[61000052]='GA'; $arr[61000104]='TN'; $arr[64000020]='TN'; $arr[124302150]='UT'; $arr[61092387]='GA'; $arr[81000210]='MO'; $arr[123103729]='ID'; $arr[122100024]='AZ'; $arr[21000021]='NY'; $arr[123271978]='ID'; $arr[123000220]='OR'; $arr[75000019]='WI'; $arr[71000013]='IL'; $arr[21100361]='CT'; $arr[71904779]='IL'; $arr[91408501]='SD'; $arr[91015224]='MN'; $arr[72000326]='MI'; $arr[44000037]='OH'; $arr[322271627]='CA'; $arr[81000032]='MO'; $arr[121000358]='CA'; $arr[51000017]='MI'; $arr[323070380]='OR'; $arr[11900571]='CT'; $arr[122101706]='AZ'; $arr[21202337]='NJ'; $arr[263189865]='FL'; $arr[73000545]='IA'; $arr[325070760]='OR'; $arr[42100175]='KY'; $arr[102001017]='CO'; $arr[83000137]='KY'; $arr[61000104]='MD'; $arr[325070760]='WA'; $arr[103000648]='OK'; $arr[52001633]='MD'; $arr[121201694]='CA'; $arr[62001186]='AL'; $arr[63013924]='FL'; $arr[122105744]='AZ'; $arr[82000549]='AR'; $arr[51000017]='VA'; $arr[73000176]='IA'; $arr[111000614]='TX'; $arr[74900783]='IN'; $arr[122400724]='NV'; $arr[102000021]='CO'; $arr[21000322]='NY'; $arr[71103619]='IL'; $arr[11000138]='MA'; $arr[121201694]='NV'; $arr[75000022]='WI'; $arr[54001204]='DC'; $arr[107005319]='CO'; $arr[322271627]='NV'; $arr[72000326]='MD'; $arr[123103716]='ID'; $arr[113000023]='TX'; $arr[122105155]='AZ'; $arr[51000017]='WA'; $arr[86300041]='IL'; $arr[42000314]='OH'; $arr[71923909]='IN'; $arr[31201360]='NJ'; $arr[72405455]='MI'; $arr[107000783]='NM'; $arr[124001545]='UT'; $arr[104000029]='NE'; $arr[1113000023]='TX'; $arr[26013673]='NY'; $arr[211370545]='MA'; $arr[111902000]='TX'; $arr[61000104]='AL'; $arr[101100045]='KS'; $arr[11103093]='CT'; $arr[65400137]='LA'; $arr[74000010]='IN'; $arr[101000187]='KS'; $arr[67014822]='FL'; $arr[104000029]='ND'; $arr[82000073]='AR'; $arr[103000017]='OK'; $arr[53000196]='NC'; $arr[31202084]='PA'; $arr[36001808]='PA'; $arr[61000104]='NC'; $arr[12371978]='ID'; $arr[91000022]='FL'; $arr[11400495]='NH'; $arr[11500010]='RI'; $arr[92900383]='MT'; $arr[53904483]='SC'; $arr[51900366]='WV'; $arr[21200339]='TN'; $arr[102001017]='NJ'; $arr[121000358]='TX'; $arr[111000023]='TX';

$aa="52001633,61092387,52001633,107005319,107005319,107005319,102001017,102001017,102001017,102001017,107005319,102001017,107005319,51000017,72000326,51000017,51000017,51000017,51000017,54001204,54001204,51000017,51000017,51000017,51000017,51000017,51000017,51000017,51000017,72000326,72000326,72000326,72000326,72000326,72000326,72000326,51000017,31202084,72000326,72000326,72000326,31202084,51000017,72000326,51000017,72000326,51000017,31202084,31202084,72000326,51000017,51000017,31202084,51000017,31202084,51000017,31202084,51000017,31202084,31202084,31202084,51000017,83000137,31202084,31202084,61000104,72000326,31202084,51000017,31202084,31202084,31202084,102001017,102001017,102001017,107005319,102000021,102001017,322271627,322271627,121201694,123000220,121201694,322271627,102001017,102001017,107005319,107005319,107005319,107005319,102001017,102001017,102001017,83000137,52001633,52001633,52001633,51000017,72000326,72000326,51000017,51000017,51000017,51000017,72000326,72000326,72000326,72000326,102001017,102001017,102001017,102001017,102001017,102001017,102001017,322271627,102001017,102001017,102001017,102001017,107005319,102001017,102001017,102001017,102001017,102001017,102001017,107005319,107005319,102000021,107005319,102001017,107005319,102001017,322271627,102001017,102001017,121201694,102000021,102001017,102000021,102000021,107005319,107005319,107005319,107005319,102001017,107005319,107005319,107005319,107005319,107005319,107005319,102001017,107005319,107005319,102001017,107005319,102001017,107005319,102001017,107005319,107005319,107005319,102000021,107005319,107005319,107005319,107005319,102001017,102001017,31202084";
$ex=explode(",",$aa);

foreach($ex as $d)
{
	echo $d.'|'.$arr[$d].'<br/>';
}

die();

$sq=mysql_query("Select ACCT_ID, ACCT_AGENT, ACCT_COE, AEMPL_EMAIL, CLOSED_ON from b_closed_accounts where length(ACCT_AGENT)=4 and CLOSED_ON Like '2019-09-%'");
$fhand=fopen("Dir_Report_Sep2019.csv","w");
$thead="ID,AGENT,COE,TIME,VER_TYPE,VER_PHONE,VER_AUTO_PHONE,VER_FAX,VER_EMAIL"."\n";
fwrite($fhand,$thead);
while($sr=mysql_fetch_assoc($sq))
{
	$ex=explode('|',$sr['AEMPL_EMAIL']);
	$type=$ex[19];
	$phone=$ex[20];
	$fax=$ex[21];
	$email=$ex[22];
	$autophone=$ex[27];
	$agent=$sr['ACCT_AGENT'];
	$coe=$sr['ACCT_COE'];	
	$row=$sr['ACCT_ID'].','.$agent.','.$coe.','.$sr['CLOSED_ON'].','.$type.','.$phone.','.$autophone.','.$fax.','.$email."\n";
	fwrite($fhand,$row);
}

die();
$sq=mysql_query("Select ID, ACCT_CASE, ACCT_DUE_DATE, ACCT_SSN, CLOSED_ON, ACCT_CLIENT, TIER, ACCT_AGENT, ACCT_COE from b_closed_accounts where CAPCODE like '1%' and CLOSED_ON Like '2019-10-%' and CLOSED_ON Not Like '2019-10-15%' and TIER<6 and SQL_NOTES!=''");
while($sr=mysql_fetch_assoc($sq))
{
	$chkq=mysql_query("Select * from all_incoming_vpoe_hits where social_security_number='".$sr['ACCT_SSN']."' and case_no='".$sr['ACCT_CASE']."'");
	if(mysql_num_rows($chkq)==0)
	{
		echo implode('|',$sr).'|'.date("Ymd",strtotime($sr['CLOSED_ON'])).'<br/>';
		//$upq=mysql_query("Update b_closed_accounts SET SQL_NOTES='' where ID='".$sr['ID']."'");
		//$mm=$mm+mysql_affected_rows();
	}
}
echo $mm;
die();
require_once("sendgrid/sendgrid_mail_function.php");

$sq=mysql_query("Select * from b_closed_accounts where TIER='8' and SECOND_CASE='' group by ACCT_CASE");

$ahead="social_security_number,first_name,last_name,street_address_1,street_address_2,city,state,zip_code,date_of_birth,phone_1,phone_2,phone_3,client_field_1,client_field_2,client_field_3,client_field_4,client_field_5,account_open_date,rnn_id,rnn_employer_name,rnn_employer_address_1,rnn_employer_address_2,rnn_employer_city,rnn_employer_state,rnn_employer_zip,rnn_employer_phone,source_code,status"."\n";
$pdate=date('Ymd');
$ehead="rnn_id,rnn_employer_name,rnn_employer_address_1,rnn_employer_address_2,rnn_employer_city,rnn_employer_state,rnn_employer_zip,rnn_employer_phone,source_code,status"."\n";

while($sr=mysql_fetch_assoc($sq))
{
	$upq=mysql_query("Update b_closed_accounts SET TIER='8' where ACCT_CASE='".$sr['ACCT_CASE']."'");
	
	$fsq=mysql_query("SELECT * FROM `b_closed_accounts` WHERE TIER='8' and ACCT_CASE='".$sr['ACCT_CASE']."' and SECOND_CASE=''");
	//$fsq=mysql_query("SELECT ACCT_CASE, ACCT_AGENT, CAPCODE, UID, ACCT_ID, EMPL_PHONE1_NMBR, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP` FROM `b_closed_accounts` WHERE TIER='9' and SECOND_CASE=''");
	if(mysql_num_rows($fsq)>0)
	{
		
		$upq=mysql_query("Update b_closed_accounts SET SECOND_CASE='$pdate' WHERE TIER='8' and SECOND_CASE='' and ACCT_CASE='".$sr['ACCT_CASE']."'");
		
		$efullpath='files/Admin/Cases/'.$sr['ACCT_CASE'].'/'.$pdate.'_'.$sr['ACCT_CASE'].'_CLEADS2_ERRORs.csv';
		$efname=basename($efullpath);
		$ehandle=fopen($efullpath,'w');
		fwrite($ehandle,$ahead);
		$afullpath='files/Admin/Cases/'.$sr['ACCT_CASE'].'/'.$pdate.'_'.$sr['ACCT_CASE'].'_CLEADS2_Completed_Accounts.csv';
		$afname=basename($afullpath);
		$ahandle=fopen($afullpath,'w');
		fwrite($ahandle,$ahead);
		//echo '<br/>';
		$chits=0;$awgerr='';$misemp='';$chits=0;
		while($fsr=mysql_fetch_assoc($fsq))
		{
			$cc1='';$cdesc='';$awgrow='';
			$fsr = array_map(
			function($fsr) {
				$x=str_replace("'", "", $fsr);
				$x=str_replace("\n", " ", $x);
				$x=str_replace("/", "RNNSLASH", $x);
				$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
				$x=str_replace("RNNSLASH", "/", $x);
				$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
				return str_replace(",", "", $x);
			},
			$fsr
			);
			
			$export=mysql_query("SELECT `social_security_number`, `first_name`, `last_name`, `street_address_1`, `street_address_2`, `city_name`, `state_name`, `zip_code`, `date_of_birth`, `phone_1`, `phone_2`, `phone_3`, `client_field_1`, `client_field_2`, `client_field_3`, `client_field_4`, `client_field_5`, `account_open_date` from a_intoRNN_POE_completed where case_no='".$sr['ACCT_CASE']."' and (id='".$sr['ACCT_ID']."' or social_security_number='".$fsr['ACCT_SSN']."')");
			if(mysql_num_rows($export)>0)
			{
				$exportrow=mysql_fetch_assoc($export);
				$exportrow = array_map(
				function($exportrow) {
					$x=str_replace("'", "", $exportrow);
					$x=str_replace("\n", " ", $x);
					$x=str_replace("/", "RNNSLASH", $x);
					$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
					$x=str_replace("RNNSLASH", "/", $x);
					$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
					return str_replace(",", "", $x);
				},
				$exportrow
				);
				$expl=explode("-",$exportrow['rnn_id']);
				
				$cc1=substr($fsr['CAPCODE'],0,1);
				if($cc1==2)
				{
					$cdesc='INCONCLUSIVE';
				}
				else if($cc1==1)
				{
					$cdesc='YES';
				}
				else
				{
					$cdesc='NO';
				}
				
				if($fsr['EMPL_PHONE1_NMBR']!='')
				{
					$fsr['EMPL_PHONE1_NMBR']=preg_replace("/[^0-9]+/", "", $fsr['EMPL_PHONE1_NMBR']);
					$fsr['EMPL_PHONE1_NMBR']=substr($fsr['EMPL_PHONE1_NMBR'],-10);
				}
				
				$arow=implode(',',$exportrow).','.$sr['ACCT_CASE'].'-'.$fsr['ACCT_ID'].','.$fsr['EMPL_NAME'].','.$fsr['EMPL_ADDR1'].','.$fsr['EMPL_ADDR2'].','.$fsr['EMPL_CITY'].','.$fsr['EMPL_ST'].','.$fsr['EMPL_ZIP'].','.$fsr['EMPL_PHONE1_NMBR'].','.$fsr['ACCT_SOURCE'].','.$cdesc."\n";
				fwrite($ahandle,$arow);
				$chits++;
				
			}
			else
			{
				$errow=$sr['ACCT_CASE'].'-'.$fsr['ACCT_ID'].','.$fsr['EMPL_NAME'].','.$fsr['EMPL_ADDR1'].','.$fsr['EMPL_ADDR2'].','.$fsr['EMPL_CITY'].','.$fsr['EMPL_ST'].','.$fsr['EMPL_ZIP'].','.$fsr['EMPL_PHONE1_NMBR'].','.$fsr['ACCT_SOURCE'].','.$cdesc."\n";
				fwrite($ehandle,$errow);
				$awgerr.=$errow;
			}
		}
		fclose($ahandle);
		fclose($ehandle);
		
		if($chits>0)
		{
			$allcq=mysql_query("Select client from all_cases where case_no='".$sr['ACCT_CASE']."'");
			$allcr=mysql_fetch_assoc($allcq);
			$clxx=explode('-',$allcr['client']);
			$Ftype='CLEADS2 Completed Accounts';
			
			$cfile=$afname.'|'.$Ftype;
			$ruser='999|'.$allcr['client'];
			$clientcomm=$chits.' CLEADS2 Closed Accounts';
			$admincomm=$chits.' CLEADS2 Closed Accounts (Source 240)';
			
			$cuSql= "SELECT * FROM `rnnwusers` where id='".$clxx[0]."'";
			$cucheck = mysql_query($cuSql);
			$cucount = mysql_num_rows($cucheck);
			if($cucount>0)
			{
				$curow=mysql_fetch_array($cucheck);
			}
			if($curow['ademail']!='')
			{
				$cemails=$curow['rnnwemail'].','.$curow['ademail'];
			}
			else
			{
				$cemails=$curow['rnnwemail'];
			}			
			
			
			$to=$cemails.',prateekg@rnngroup.com';
			//$to='prateekg@rnngroup.com';
			$Email='Operations@rnngroup.com';
			$User=$curow['name'];
			$Case=$sr['ACCT_CASE'];
			$File=$afname;
			$subject = 'Case #'.$Case.' Additional File Ready for Download';
	
			$message = "
			<html>  
				<body>
					<div align='center' style='border:4px solid #AE210D; padding:20px; font-family:Arial, Helvetica, sans-serif; background:#ffffff !important'>
						<table width='100%'  border='0' cellspacing='4' cellpadding='0'>
							<tr>
								<td align='left' valign='top'><p>Dear ".$User.",</p>
								<p>A file has been placed for you to download at <a href='http://rnngroup.com' target='_blank'>RNNGroup.com</a>. Please download this file at your convenience.</p>
								<p>Case # <strong>".$Case."</strong><br>
								File Name: <strong>".$File."</strong><br>
								File Type: <strong>".$Ftype."</strong><br>
								Number of Accounts: <strong>".$chits."</strong><br>
								</p>
								<p>If you have any questions please let us know and we will be happy to help.</p>
								<p>Thank you for your business and have a great day.</p>
								<p>&nbsp;</p>
								<p>RNN Group<br>
								Operations@rnngroup.com<br>
								<img src='https://rnngroup.com/images/1logo.png' width='250'>
							</tr>
						</table>
					</div>
				</body> 
			</html>";

			$from = $Email;
			$header = "RNN Operations";				
			sendgrid_mail($to,$from,$subject,$message,$header);
			
			$chkftp=mysql_query("Select id from auto_ftp_users where cid='".$clxx[0]."' and products like '%-CLEADS2-%'");
			if(mysql_num_rows($chkftp)>0)
			{
				$ftprow=mysql_fetch_assoc($chkftp);
				//echo '<br/>';
				$_REQUEST['ftpfolder']=$ftprow['id'];
				//echo '<br/>';
			}
			else
			{
				$_REQUEST['ftpfolder']='';
			}
			//$_REQUEST['ftpfolder']='511';//Testing FTP
			if($_REQUEST['ftpfolder']!='')
			{
				$chkrnnftp=mysql_query("Select * from auto_ftp_users where id='".$_REQUEST['ftpfolder']."'");
				if(mysql_num_rows($chkrnnftp)>0)
				{
					$lfile=$afullpath;
					$ftpfname=$afname;
					
					$ftpext = pathinfo($ftpfname, PATHINFO_EXTENSION);
					if($ftpext=='')
					{
						$ftpfname=$ftpfname.'.csv';
					}
		
					$ftprow=mysql_fetch_array($chkrnnftp);
					$username = $ftprow['uname'];
					$password = $ftprow['passw'];
					$port = $ftprow['port'];
					$url = $ftprow['host'];
					$checkid = $ftprow['id'];
					$products = $ftprow['products'];
					$sendpath = $ftprow['sendfile'];
					$sendpath = rtrim($sendpath, '/');
					$sendpath = ltrim($sendpath, '/');
					$sendpath = '/'.$sendpath;
					$matchpath=$sendpath.'/'.$ftpfname;
					if($ftprow['type']=='RNN' || $ftprow['type']=='FTPS')
					{
						$host=$url;
						$uname=$username;
						$passw=$password;
		
						$uname=$uname.'@'.$host;
						$ftp = ftp_ssl_connect($host);
						if (!$ftp) die('Could not connect to FTP!');
						$r = ftp_login($ftp, $uname, $passw);
						if (!$r) die('Could not login to FTP!');
						$r = ftp_pasv($ftp, true);
						if (!$r) die('Could not enable passive mode on FTP');
		
						ftp_chdir($ftp, $sendpath);
						ftp_put($ftp, $ftpfname, $lfile, FTP_BINARY);
						$contents_on_server = ftp_nlist($ftp, $sendpath);
						if (in_array($ftpfname, $contents_on_server)) 
						{
							$_SESSION['FTPSTAT']='File uploaded successfully to FTPS: '.$matchpath;
							$spcomm='File Sent to FTPS: '.$matchpath.' - ';
						}
						else
						{
							$spcomm='Failed sending to FTPS: '.$matchpath.' - ';
							$_SESSION['FTPSTAT']='Something went wrong in FTPS transfer. Please check manually!';
						}
						
					}
					else if($ftprow['type']=='SFTP' || $ftprow['type']=='SFTPNORM')
					{
						include('Net/SFTP.php');
						$host=$url;
						$uname=$username;
						$passw=$password;
						$sftp = new Net_SFTP($host);
						if (!$sftp->login($uname, $passw)) {
							echo "Login Failed";
							continue;
						}
						//change directory
						$sftp->chdir($sendpath);
						//put(remote,local,NET_----)
						$sftp->put($ftpfname, $lfile, NET_SFTP_LOCAL_FILE);
						$contents_on_server=$sftp->nlist();
						if (in_array($ftpfname, $contents_on_server)) 
						{
							$_SESSION['FTPSTAT']='File uploaded successfully to SFTP: '.$matchpath;
							$spcomm='File Sent to SFTP: '.$matchpath.' - ';
						}
						else
						{
							$spcomm='Failed sending to SFTP: '.$matchpath.' - ';
							$_SESSION['FTPSTAT']='Something went wrong in SFTP transfer. Please check manually!';
						}
						
						
					}
					else if($ftprow['type']=='FTP')
					{
						$host=$url;
						$uname=$username;
						$passw=$password;
		
						$uname=$uname.'@'.$host;
						$ftp = ftp_connect($host);
						if (!$ftp) die('Could not connect to FTP!');
						$r = ftp_login($ftp, $uname, $passw);
						if (!$r) die('Could not login to FTP!');
						$r = ftp_pasv($ftp, true);
						if (!$r) die('Could not enable passive mode on FTP');
		
						ftp_chdir($ftp, $sendpath);
						ftp_put($ftp, $ftpfname, $lfile, FTP_BINARY);
						
						$contents_on_server = ftp_nlist($ftp, $sendpath);
						if (in_array($ftpfname, $contents_on_server)) 
						{
							$_SESSION['FTPSTAT']='File uploaded successfully to FTP: '.$matchpath;
							$spcomm='File Sent to FTP: '.$matchpath.' - ';
						}
						else
						{
							$spcomm='Failed sending to FTP: '.$matchpath.' - ';
							$_SESSION['FTPSTAT']='Something went wrong in FTP transfer. Please check manually!';
						}
						
					}
				}	
			}
			$clientcomm=$spcomm.' - '.$clientcomm;
			//echo '<br/>';
			$event='File Uploaded and Ready to Invoice';
			$cquery="INSERT INTO `case_history`(`id`, `case_no`, `event`, `user`, `comments`, `files`, `datetime`, `records`, `acct_com`) VALUES('','".$sr['ACCT_CASE']."', '$event', '$ruser', '$clientcomm', '$cfile', '$tdate', '$chits', '$admincomm')";
			mysql_query($cquery);
		}
		else
		{
			$to="prateekg@rnngroup.com,vimals@rnngroup.com";
			$from = "RNNClientServices@rnngroup.com";
			$subject = "CLEADS2 Hit FIle Issue. Case: ".$sr['ACCT_CASE'];
			$header = "RNN Client Services";
			$message = "Dear Admin, Unable to send closed file. No Hits found in all closed CLEADS2. File: ".$afullpath;
			/************************* Send Grid Email Function ******************/
			sendgrid_mail($to,$from,$subject,$message,$header);
		}
		
		if($errrow!='')
		{
			$fileName = basename($efullpath);
			$filePath = dirname(__FILE__);
			
			$to="prateekg@rnngroup.com,vimals@rnngroup.com";
			$from = "RNNClientServices@rnngroup.com";
			$subject = "CLEADS2 Case: ".$sr['ACCT_CASE'].' QC failed accounts '.date("Y-m-d");
			$header = "RNN Client Services";
			$message = "Dear Admin, Some closed accounts were moved back to Agent queues as they failed the auto QC process. Please see the attached file: ".$fileName;
			
			$user = 'rnnitsupport';
			$pass = 'RNNsg332@@#'; 
			$request =  'https://api.sendgrid.com/api/mail.send.json';
			
			$params = array(
				'api_user'  => $user,
				'api_key'   => $pass,
				'to'        => $to,
				'subject'   => 'AWG7 QC Failed Accounts '.date("Y-m-d"),
				'html'      => $message,
				'text'      => $message,
				'from'      => 'operations@rnngroup.com',
				'files['.$fileName.']' => '@'.$filePath.'/'.$efullpath
			  );
			 
			// Generate curl request
			$session = curl_init($request);
			// Tell curl to use HTTP POST
			curl_setopt ($session, CURLOPT_POST, true);
			// Tell curl that this is the body of the POST
			curl_setopt ($session, CURLOPT_POSTFIELDS, $params);
			// Tell curl not to return headers, but do return the response
			curl_setopt($session, CURLOPT_HEADER, false);
			curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
			 
			// obtain response
			$response = curl_exec($session);
			curl_close($session);
		}
	}
}

die();
$emq=mysql_query("SELECT UID, ACCT_ID, CLOSED_ON FROM b_closed_accounts WHERE ACCT_COE = 'BOT' and CLOSED_ON Like '2019-09-%'");
if(mysql_num_rows($emq) > 0 )
{
	while($rw = mysql_fetch_assoc($emq))
	{
		$echeck=mysql_query("Select ID, ACCT_AGENT, EMPL_PH_SOURCE, ADD_DATE from b_work_history where UID= '".$rw['UID']."' and CAPCODE='2210' order by ID DESC limit 1");
		if(mysql_num_rows($echeck) > 0 )
		{
			$rr = mysql_fetch_assoc($echeck);
			echo $rw['ACCT_ID'].'|'.$rw['CLOSED_ON'].'|'.$rr['ACCT_AGENT'].'|'.$rr['EMPL_PH_SOURCE'].'|'.$rr['ADD_DATE'].'<br/>';
			$nf++;
		}
		else
		{
			
		}
		$ch++;
	}
}
echo '<br/><br/> Total Checked: '.$ch.' - Found: '.$nf;
die();
$page_file_temp='files/Admin/Cases/80242/80242_VerLast30_Hits.csv';
echo $page_directory = dirname($page_file_temp);

die();

$strCommandLine = "unzip -P 1UwEuM5xszft3FWGzmXCngbWHz4IOEq6 assets/To_LCI_09-17-2019_DEL_BK.zip";
$zipres=system($strCommandLine);
$zipx=explode(' inflating: ',$zipres);
echo '<br/><br/>Name: '.end($zipx);
if(file_exists(end($zipx)))
{
	echo '<br/>Found';
}
die();

$lfile='files/Admin/Cases/80242/80242_VerLast30_Hits.csv';

$lcizip=str_replace('.csv','.zip',$lfile);

$base=basename($lfile);
copy($lfile,$base);
system('zip -P 1UwEuM5xszft3FWGzmXCngbWHz4IOEq6 '.$lcizip.' '.$base.'');
unlink($base);
$lfile=$lcizip;

die();



die();

$emq=mysql_query("SELECT * FROM b_active_accounts WHERE ACCT_CASE = '80475' and (ACCT_ID='' OR ACCT_ID='0')");
if(mysql_num_rows($emq) > 0 )
{
	while($rw = mysql_fetch_assoc($emq))
	{
		$echeck=mysql_query("Select id from a_intoRNN_POE where social_security_number= '".$rw['ACCT_SSN']."' and case_no='80475'");
		if(mysql_num_rows($echeck) > 0 )
		{
			$rr = mysql_fetch_assoc($echeck);
			$upq=mysql_query("Update b_active_accounts SET ACCT_ID='".$rr['id']."' where ID='".$rw['ID']."'");
			$f++;
		}
		else
		{
			$nf++;
		}
	}
}
echo $f.' --> '.$nf;
die();
$bphand=fopen('Try.csv',"r");
$newf=fopen('FullTry.csv',"w");
while (($data = fgetcsv($bphand, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$ifsn = preg_replace("/[^0-9]/", "", $data[0]);
		$ischeck=intval($ifsn);
		if($ischeck>0)
		{
			$ifssn=str_pad($ischeck, 9, '0', STR_PAD_LEFT);
		}
		$cid=$data[1];
		$oq=mysql_query("SELECT `social_security_number`, `first_name`, `last_name`, `street_address_1`, `street_address_2`, `city`, `state`, `zip_code`, `date_of_birth`, `phone_1`, `phone_2`, `phone_3`, `client_field_1`, `client_field_2`, `client_field_3`, `client_field_4`, `client_field_5`, `account_open_date`, `rnn_id` FROM `vast_all_web` WHERE social_security_number='".$ifssn."' and rnn_id='$cid'");
		if(mysql_num_rows($oq)>0)
		{
			$or = mysql_fetch_assoc($oq);
			$row=implode(',',$or)."\n";
			fwrite($newf,$row);
		}
	}
	$i++;
}

die();
$emq=mysql_query("SELECT * FROM b_active_accounts WHERE ACCT_COE != 'EMP' and POESCORE!='0' and TIER!='9' order by ACCT_DUE_DATE ASC");
if(mysql_num_rows($emq) > 0 )
{
	while($rw = mysql_fetch_assoc($emq))
	{
		$echeck=mysql_query("Select * from b_powerlead_active where UID = '".$rw['ID']."' order by ID DESC");
		if(mysql_num_rows($echeck) > 0 )
		{
			
		}
		else
		{
			$echeck1=mysql_query("Select * from b_powerlead_closed where UID = '".$rw['ID']."' order by ID DESC");
			if(mysql_num_rows($echeck1) > 0 )
			{
				
			}
			else
			{
				$inSQl = mysql_query("INSERT INTO `b_powerlead_active`(`ID`, `UID`, `ACCT_AGENT`, `ACCT_COE`, `ADD_DATE`, `ACCT_CASE`, `ACCT_CLIENT`, `ACCT_FNAME`, `ACCT_LNAME`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `EMPL_NAME`, `PHONE_LEAD`, `PHONE_TYPE`, `ADDR_LEAD`, `ADD_TYPE`, `EMPL_WEBSITE`, `EMPL_FB`, `PHONE_CORP`, `ADDR_CORP`, `EMPL_FAX`, `EMPL_EMAIL`, `PHONE_LOCAL1`, `ADDR_LOC1`, `PHONE_LOCAL2`, `ADDR_LOC2`, `ACCT_SOURCE`, `ACCT_LINKEDIN`, `EMPL_3RD`, `EMPL_3RD_NUMBER`, `CAPCODE`, `AUTONOTES`, `LAST_UPDATE`, `CUSTOM1`, `CUSTOM2`, `CUSTOM3`, `CUSTOM4`, `shortname`) VALUES ('', '".$rw['ID']."', '', '".$rw['ACCT_COE']."', '".$rw['ADD_DATE']."', '".$rw['ACCT_CASE']."', '".$rw['ACCT_CLIENT']."', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '".$rw['ACCT_SOURCE']."', '', '', '', '', '', '$tdate', '".$rw['POESCORE']."', '', '".$rw['ACCT_DUE_DATE']."', '', '')");
				$qq=$qq+mysql_affected_rows();
				//exit;
			}
		}
	}
}

echo $qq.' - Added to PowerLead Queue<br/>';

die();
$bphand=fopen('Try.csv',"r");
while (($data = fgetcsv($bphand, 100000, ",")) !== FALSE) 
{
	$rid=$data[2];
	$cid=$data[1];
	$capcode=0;
	$score=$data[4];
	$act='';
	$oq=mysql_query("Select * from b_closed_accounts where UID='".$rid."'");
	
	if(mysql_num_rows($oq)>0)
	{
		$or=mysql_fetch_assoc($oq);
		$oname=$or['EMPL_NAME']; $oad1=$or['EMPL_ADDR1']; $oad2=$or['EMPL_ADDR2']; $ocity=$or['EMPL_CITY']; $ost=$or['EMPL_ST']; $ozip=$or['EMPL_ZIP']; $oph=$or['EMPL_PHONE1_NMBR']; $oven=$or['ACCT_SOURCE']; $opl=$or['PL_MATCH'].'::'.$or['DIR_REF'];
		
		$agnt=$or['ACCT_AGENT'];$act='';
		
		if($or['ACCT_COE']=='5C')
		{
			$agnt='7783';
		}
		else if($or['ACCT_COE']=='ATL')
		{
			$agnt='4444';
		}
		else if($or['ACCT_COE']=='EBC')
		{
			$agnt='8888';
		}
		else if($or['ACCT_COE']=='COL')
		{
			$agnt='9999';
		}
		else
		{
			$agnt='7783';
		}
		 $agnt='HOLDsp-'.$agnt;
		$insq="Insert into b_active_accounts (`ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `AEMPL_EMAIL`, `COE_RULE`, `TIER`, `POESCORE`) SELECT '' as `ID`, '20190904' as `ADD_DATE`, 'VSTcustom.csv' as `ADD_FILE`, 'PrateekVST' as `ADDED_BY`, '$cid' as `ACCT_CLIENT`, `ACCT_COE`, '$agnt' as `ACCT_AGENT`, '80475' as `ACCT_CASE`, '20191020' as `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, '0' as `CAPCODE`, '' as `LAST_WORKED`, '' as `LAST_COMMENTS`, '' as `AEMPL_EMAIL`, `COE_RULE`, `TIER`, '$score' as `POESCORE` FROM `b_closed_accounts` WHERE UID='".$rid."'";
		mysql_query($insq);
		if(mysql_affected_rows()>0)
		{
			//$dq=mysql_query("Delete from b_closed_accounts where UID='".$rid."'");
			$cvv++;
		}
		
	}
	
}
echo $cvv.'<br/>';
fclose($bphand);
				
				die();
$asd=fopen('vastnn.csv','w');
$ahd="SSN,Client,UID,CAPCODE,POESCORE,CLOSED_ON,PL_MATCH"."\n";
fwrite($asd,$ahd);
$expq=mysql_query("SELECT social_security_number, rnn_id FROM `vast_all_web` WHERE shortcodes Like '%VP1%'");
while($sr=mysql_fetch_assoc($expq))
{
	$oq=mysql_query("Select UID, CAPCODE, POESCORE, CLOSED_ON, PL_MATCH from b_closed_accounts where ACCT_SSN='".$sr['social_security_number']."' order by ID desc limit 1");
	if(mysql_num_rows($oq)>0)
	{
		$or=mysql_fetch_assoc($oq);
		$row=$sr['social_security_number'].','.$sr['rnn_id'].','.$or['UID'].','.$or['CAPCODE'].','.$or['POESCORE'].','.$or['CLOSED_ON'].','.$or['PL_MATCH']."\n";
		fwrite($asd,$row);
		$ff++;
	}
	if($ff==100000)
	{
		echo '10K';
		die();
	}
}

die();

$tt="9608|2638747|TIRE DISCOUNT|CARBIT PAINT COMPANY LLC,9616|2638783|MARTINS DAY CARE|BELL STORES,9629|2638852|CAREER TEAM LLC|CAPITAL WORKFORCE,9669|2638949|ASROTEK|AEROTEK,9671|2638951|STICKER MULE|HOPKINS TSCHETTER SULZER,9705|2638845|SKY HAIR STUDIO|KOREAN CENTRAL PRESBYTERIAN CHURCH,9710|2638768||DANIEL JS SALON,9719|2638789||Csl Plasma, Inc,9720|2638795|THE WILLOWS AT BELLEVUE|FIRST CHOICE,9756|2638919||PARKVIEW HAVEN";
$ttx=explode(',',$tt);
foreach($ttx as $tx)
{
	$cx=explode('|',$tx);
	$sid=$cx[0];
	$rid=$cx[1];
	
	$rq=mysql_query("Select * from b_all_employers where ID='$sid'");
	
	$oq=mysql_query("Select * from b_closed_accounts where UID='".$rid."'");
	
	if(mysql_num_rows($rq)>0 && mysql_num_rows($oq)>0)
	{
		$rr=mysql_fetch_assoc($rq);
		$rname=$rr['EMPL_NAME']; $rad1=$rr['EMPL_ADDR1']; $rad2=$rr['EMPL_ADDR2']; $rcity=$rr['EMPL_CITY']; $rst=$rr['EMPL_ST']; $rzip=$rr['EMPL_ZIP']; $rph=$rr['EMPL_PHONE1_NMBR']; $rven=$rr['ACCT_SOURCE']; $rpx=explode('::',$rr['NOTES']);$rpl=$rpx[0];$rdr=$rpx[1];
		
		$or=mysql_fetch_assoc($oq);
		$oname=$or['EMPL_NAME']; $oad1=$or['EMPL_ADDR1']; $oad2=$or['EMPL_ADDR2']; $ocity=$or['EMPL_CITY']; $ost=$or['EMPL_ST']; $ozip=$or['EMPL_ZIP']; $oph=$or['EMPL_PHONE1_NMBR']; $oven=$or['ACCT_SOURCE']; $opl=$or['PL_MATCH'].'::'.$or['DIR_REF'];
		
		$agnt=$or['ACCT_AGENT'];$act='';
		
		if(strstr($or['ACCT_AGENT'],'RCALL') || strstr($or['ACCT_AGENT'],'PPOF'))
		{
			$act='NO';
		}
		else
		{
			if(strlen($or['ACCT_AGENT'])!=4)
			{
				if($or['ACCT_COE']=='5C')
				{
					$agnt='7783';
				}
				else if($or['ACCT_COE']=='ATL')
				{
					$agnt='4444';
				}
				else if($or['ACCT_COE']=='EBC')
				{
					$agnt='8888';
				}
				else if($or['ACCT_COE']=='COL')
				{
					$agnt='9999';
				}
				else
				{
					$agnt='7783';
				} 
			}
		}
		if($act=='')
		{
			$upq1="Update b_closed_accounts SET EMPL_NAME='$rname', EMPL_ADDR1='$rad1', EMPL_ADDR2='$rad2', EMPL_CITY='$rcity', EMPL_ST='$rst', EMPL_ZIP='$rzip', EMPL_PHONE1_NMBR='$rph', ACCT_SOURCE='$rven', PL_MATCH='$rpl', DIR_REF='$rdr' where UID='".$rid."'";
			
			$upq2="Update b_all_employers SET EMPL_NAME='$oname', EMPL_ADDR1='$oad1', EMPL_ADDR2='$oad2', EMPL_CITY='$ocity', EMPL_ST='$ost', EMPL_ZIP='$ozip', EMPL_PHONE1_NMBR='$oph', ACCT_SOURCE='$oven', NOTES='$opl' where ACCT_ID='".$rr['ACCT_ID']."' and ACCT_SOURCE='".$oven."'";
			mysql_query($upq2);
			echo $rr['ACCT_ID'].'-';
			if(mysql_affected_rows()>0)
			{
				echo '1-';
				mysql_query($upq1);
				if(mysql_affected_rows()>0)
				{
					echo '2-';
					$rnd=rand(7,10);
					
					$insq="Insert into b_active_accounts (`ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `AEMPL_EMAIL`, `COE_RULE`, `TIER`, `POESCORE`) SELECT `UID`, `ADD_DATE`, `ADD_FILE`, 'Prateek2nd' as `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, '$agnt' as `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `AEMPL_EMAIL`, `COE_RULE`, `TIER`, '$rnd' as `POESCORE` FROM `b_closed_accounts` WHERE UID='".$rid."'";
					mysql_query($insq);
					if(mysql_affected_rows()>0)
					{
						$dq=mysql_query("Delete from b_closed_accounts where UID='".$rid."'");
						echo 'done';
						//echo '<br/>';
						//echo $insq;
					}
				}
			}	
		}
	}
	echo '<br/>';

}

die();

$expq=mysql_query("SELECT * FROM `b_all_employers` WHERE ACCT_CASE>'70000'");
while($sr=mysql_fetch_assoc($expq))
{
	$oq=mysql_query("Select * from b_closed_accounts where ACCT_ID='".$sr['ACCT_ID']."' and ACCT_DUE_DATE>='20190830' and ACCT_SOURCE!='".$sr['ACCT_SOURCE']."' and CAPCODE not like '1%'");
	if(mysql_num_rows($oq)>0)
	{
		$or=mysql_fetch_assoc($oq);
		
		$empsname  =  strtolower($sr['EMPL_NAME']);			
		$empsname  = str_ireplace(array('  incorporation',' inc',' llc',' ltd',' llp',' s-corp',' corp',' corporation'),'',$empsname);	
		$empsname  = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empsname));
		
		$empmname  =  strtolower($or['EMPL_NAME']);
		$mulid=$or['ID'];
		
		$empmname  = str_ireplace(array('  incorporation',' inc',' llc',' ltd',' llp',' s-corp',' corp',' corporation'),'',$empmname);	
		$empmname  = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmname));
		$multiple='No';
		if(strlen($empsname)>5 || strlen($empmname)>5)
		{
			if(strstr($empmname,$empsname) || strstr($empsname,$empmname))
			{
				$multiple='No';
			}
			else
			{
				$multiple='Yes';
			}
		}
		else
		{
			if($empsname==$empmname)
			{
				$multiple='No';
			}
			else
			{
				$multiple='Yes';
			}
		}
		if($multiple=='Yes')
		{
			echo $sr['ID'].'|'.$or['UID'].'|'.$sr['EMPL_NAME'].'|'.$or['EMPL_NAME'].'<br/>';
		}
	}
}

die();
$chkd=date("Y-m-d H:i:s",strtotime($tdate.' - 1 Weekday'));
$bpactpath='files/Admin/BFrame_BadPOE.csv';
			if(file_exists($bpactpath))
			{
				$bphand=fopen($bpactpath,"r");
				while (($data = fgetcsv($bphand, 100000, ",")) !== FALSE) 
				{
					$badpoe.=implode('||',$data);
				}
				fclose($bphand);
				$badpoe=strtolower($badpoe);
			}
			else
			{
			
			}
			
			$badpoe.="united states navy-retired||hair dresser||army, navy, etc. ||ssa||va benefits||day care||freelancer||dept of defense||us air force||missing phone #'s||retired||ssi||benefits||disability||disabled||disabled veteran||home worker||homemaker||pension||self||self employed||selfemployed||slf||social security||ss||s.s.||s.s||ssd||ssdi||ssi||va||none||n/a ||na||widow ||military ret||unemployment||disabled veteran||daycare||benfits||veterans administration||self emp||us army||us congress||us marines||social security administration||social security-disability||us navy||retired ssi||n/a||social security disability||n/a||n/a||retired disabled||n/a||n/a||retired verizon||n/a||retireddeptofdef||social security/disability||social security adm||retired / part -time||social security & ravens store||self-employeed||soc sec va||sef employed||n/a||n/a||disabiled||ssi disabled||soc sec disab||ssi & ssd||disability ssi||n/a||home maker||retired - self employed||retired ssd||retired/ssi||disability income||ssi/ rail road||retssi||disabilityssi||ssi & pension||home maker||disabled vet||disabilty ssi||social security widow benefit||n-a||disability pending||disabilaty||retired pension business||home maker||ssd and child support||va local 322||ssi disb||n/a||retired city of wincheste||retired disable vet||ssdi pension||retirement rental||soc sec/dis||ue||ssid / alimony||ss va pension||home maker||social sec||social security desability||disabiltiy||retired state of california||ue||retired trucking||retired cbr||disability income||ss disability insurance||retired/us army||social security/disability||retired ssi||ssi pension||veterans admin||veterans pension||ue||n/a||va & federal government||ssdi pension||retirement and disability||retired disabled||ssi/pension||disability - ssd||va disability||soc security||ssi/retired||home/self||social security disability||disablilty||une||ssi retiment||veterans affair disa||social secuity||social security/disability||social security/disability||social security disability||social security/disability||social security ssi||retirement survivor annuity||social security/disability||social security administr||social security/disability||unemployed||social sercuity||social security/disability||disability/social security||socail security||ssi/retirement||disability/social security||social security disability||social security - disability||disability/social security||socialsecurityadministration||disable||social security administr||no job||ssi/disabilty||self employee||disability/social security||ssi social security||disability/social security||retired from d. m. v.||n/a||na sitter||no employer||retirement-va hosp||retired pers le||veterans of foreign wars department of montana||veterabn||disability 582||ss heating nle||veterans with dignity||ssi retirer||retired 67||soc sec 718 00||ssi and self emp landscaper||homemaker sdt||ssi 1070 00||ssi 4th wed of month||retired legal profes||self employed full time||social security retiremen||social security disab.||soc sec||retired from rent control||ss retirement||ssi and pension||va retirement||ssdi self employed||no poe||social securitu||no poe||retirement/pension/ss death||veterans affairs||socail security||ssi$ssa||va disabilaty||no job||retirement||retirement||ssi 766||retirement/pension||socialsecurity_disability||retirement||social security income||ss disability||unemployed||disability ss||ss & disability||ssi/dis||soc sec dis||ssi and di||social secuity disability||ss pension||retired sos sec||disabily||ssi retirement pension||not working||u e||soc sec & wife||u e||u e||retired johnson co sheriff||ss/retired||ssi and disability||soc sec disability||umemployed||social security ad||s s i disability||ss/ penison||retirement income||na on cbr||retired per cbr||social security disabilit||retrried pention||retired per cbr||u e||retired gm||soc sec & pension||retired veteran||ssi vad dfas||retired- pension||u e||retired gm||disablity ssi||ss retired||social security-retirement||retired per cbr||retired chrysler||ret||ss/retired||unemloyed||soc sec disability||ssidisability||disabililty||self emploed||self-employed||disabity||ssi/employed||unemployment benefits||disablity||ssidisability||retire||socialsecurity||unemploment||ss and va||not applicable||ssi & d||dissability||self emplyed||u e almst a yr||ssi 73 years old||ssi dob 10 1938||disability 1574||ssi 1115 mon||retired born 11 37||retired ssi pensio||ssi 600 month||ssi /pension||disbale||ssi (retired)||retired 08 31 05||retired military||disab||retired state of florida||na ssi||social security adm.||ssa disability||ssci||ssi/674||ssi/visiting anger||retired sub docs||retired from gm per cbr||retired-hopper constructi||disabilty||retired kansas building trades||veterans a||ssi/ssdi||retired us military||veteran s administration||ssd dss grant||disability benefits||soc sec benefits||ssi income||ssd ssi||social security retirement||disability/ workers comp||social security & annuity||ssd/pension||social security rec||ssd and comp||ss plus pension||ssi / pension||veterans disability||ss i||ssa recipient||soc sec recipient||retirement/ss||soc sec benefits||retired social security||socailsocarity||social security/ daycare||retired_benefits||retired/pension||social security/ self employed||disability benefits||self-employer||disbled||my self||social securtity||selfemployer||va disbility and retireme||scoial security||home||home||self emloyed||social security & ssi||retired and ssi||retired civil servic||retired boeing aircr||ssi & retirement||benefits admin corp||social security benefits||unknown||uber||ssi disabilty||ssi / widows pension||social security admin||soc||ssdi/pension-net||ssi monthly on 1st||ssn||ssi disab||ss recipient||ssdi benefits||ssi disability benefits||ssi/ pension||soc scc||social socurity||ssi 674 00 each month||ssi benefits||diabled||segura social/ssi||uber||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown||other ||disabled vet||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi pension va||ssi va pension||retired nypd||ss / workers comp||ssi and retirement||ss dis||retired pension||soc sec pension||ssi penson||ssd pension||soc sec / pen||retired social secur||retired nyc police officer||retired nyc corrections||retired ny dept corrections||ssi dissability||ss benefits||social sec recipient||social security recipient||retired from nyc law dept||social sec income||ssdssi||ssi recipient||social security recipient||social security recipient||ssd pension||ssi recipient||retired us army||soc security admin||ssi pension investments||retired transit worker||social security recipient||socai security||ssi/ssd||waiter||waitress||bartender||taxi driver||cab driver||disabled/ssi||un employed||disability self employed||ssdi social security||retiired||someone||adult and child||clean houses||sss disability||soical security||housewife||on disability||u.s. government||ss- $507.00||socical sercurity||ssbeneifits||daycare provider||mother||soical security||nothing||disabllty||soc sec retirement||retired general elec||retired city of cleveland||retired disabilty||house wife||no poe on cbr||retired - alcoa||disabilitly||child provider||retirement housing||social security / annuity||us social security administration||on ssa||my own buisiness||ssa.gov||social security disabilty||unemployed/going on disability||self employer||retired-social security||ssi diabilaty||i dont work||disabeled||retired from comprehensive care center||retired disablity||i am disable||retirment||disability and social security||husbands income||retired/ disabiliabled||ssid & childcare||self employed andcsocial security||self employment||child support||none-retired||catholic charities||social secuirty/disabilty||fedgoverment||na company||retired -ssa||pers retired/pension||disabled and child support||dis||ssdi/ssidi||united states army||retirement systems of alabama||social security administration benefits||ss administration||retired receive retirement/ss||ssaandstudent||s.s. disabled||ssi benifits||unemployment state of ohio||social serurity||social security di||retied||us disability||selfempl||s s i||ssldc||social security 1391||self imployed||unemploed||ssc||fedgovernment||husband on va disablity & socisal securty||ssa treas 31o xxsoc sec||ssi collect for myself||retired/disables||retired teacher||i am on security||not workng||sis||disibility||disability/pension||ssa & ltd||on social security disability||on disability||don't work||rertirment||retired and disability||social security widow||soc. sec.||gov\\||na company||social security and ssi||disabillity||military- army||house wifr||social security and disability||not specified||nonameyet||self support personal care||retiredselfemployedssdi||my cleaning co||on s.s,i > disibitiy||housewife my husband works at walmart||ss53rm disability||ssi/disability||fed government||selfempoled||ret army.||federal government||disability (ssi)||social security administrator||disabilitly||united states army||child care provider (paid by the state)||retired u s army||socail secretary||social securuty benefits||social securit||not collected||retited||currently disabled||s.s. disabilty||not available||notemployed||us army benefits||b||unmpolyment||not employed||home address||diability||army||missouri unemployment||social security disablity||ssi ss child support||dissablitity||na/receives disability||ssi unemployment||social securtiy beneifits||ssdi soc sec||none at this time||retired vet||ss benifits||not provided||n a between jobs who wants me i want to work||training up a child||no poe per cbr||hairstylist||ssissa||babysitting||miltary||retyirement||ssi civil service||retirement/disability||retired us navy||us navy va disability||usarmy||natalys home salon||employer name||not provided||ssi and benefits||none listed on cbr||ssi food asst||ssi per consumer||united states military||none cbr||retired)||pending disability||no poe cbr||ssi per cbr||disblty||not listed||no poe listed||none listed on cbr||usps retired||retired ny dept of correc||no poe onc br||retired-pension||ssa/ssi disability||house keeping||na/receives disability||usnavy||child care||ssdi soc sec||sst||remax/self employed||disabilityva||socal security||us military||permanently disabled||army ret||retired disable||usd 259 retired||dont work ssi||navy||court ordered child support||swlf employed||800-772-1213||disbilty||none on cbr||cbr says student||us military army||disabilitysocial sec||l aid of f||retired disability||retired from kroger 2007||retired navy||benefits||va disablity||ssi + pension||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||avon||veteran s benefits||non employed ||ssi/benefits||sitter||pension||retiree||diabled||segura social/ssi||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown(has no #'s) ||other (has no #'s)||disabled vet||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi||workman s comp||at home mom ||disabled-soc sec||worker comp||retored||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||veteran s benefits||non employed ||sitter||segura social||u s army||retired ssi disabili||u.s. army||caregiver||n a||care taker||disability pension||babysitter||u s gov dept of army||retired nurse||social sacerity||childcare||ssi (0) (401)||survivors benefits ss||socaial security||va disibility||retired/disability||right at home||care taker||dept of defense - air firce...||ssi va||retired pera||disability per cnsmr||wendys no tlx hit||fmc retired||department of veterans af||ssi/chrysler||retired delphi||no record||retired val ss wife has busin||not listed in cbr||gm retired pension||disaiblityssi||mary kay||per cb approved mfg no info||ssi disability per cbr||i am retired||social secur||macys no tlx hit||avon||cbr na||i am christ minstry||net social security||disable with no income yet||ssi va||ssi-disability||retired/disabled||not employed-retired||retirement benefits||s s disabiltiy||ss disablity||no poe listed cbr||social security pension||mcdonalds mgr no tlx hit||retired ssi disability||cbr self emp||s s disability||us government no tlx hit||no po on cbr||us postal service no tlx||gm no tlx hit||disabled vetetan||ssoe group||ssidisablity &heartsidefoods||n\a||1099 self employed||us social security administration / gm||disabled homemaker||no||disiablity||retired postal worker||retired and social security||i am disabled vet collecting a check please help||gov assistance||self (was)now retired on s.s.||ssi / retirement / pension||ssi 647 00||government benefits||desempleo edd||ssi (0) (401)||retirement benefits||reteried||disability check||va/ssi||retired usps, and military retired||retired/social secuity||not employed at this time||ssid, disabled||retired army||department of defense||social security administration office of disability operations||social /death benifits||retired(deptof defense||disibiy||social sercurity administ||ssid||retierd||disability-social secur||social security pays her||disabled ssi||ssid||ssa and ssi||disabled ssi||va ssi||daughters ssi||ssisuplement||ssi - tanf||ssi dissabiluty||oregon ssi||retired-ssi-va||ssdi and ssi||ssi incom||pension ssi||ssi 00000-0000||ssi3rd1569||ssi death benefit||ssi- disability||ssi disablity||ssi 00000-0000||ssi office||ssi-1st 00000-0000||ssi and child support||ssid||vassi||ssi-3rd||ssi subsidy||fargo ssi||ssi baby sitter||ssidiss||ssi for daughter||ssi3rd1279.00||ssi grossed up||ssiannuity||retired dissability||retiredusarmy||retired-disb||retired us.army||retired and pension||retireddisa||retired-disabled||us army retired||retired spartan stores||social disability||disability-social secur||social securitydisabili||disability-social secur||social security pays her||disability-social secur||disability-social secur||social securitydisabili||social security office||social security adminis||disability-social secur||social security--1st||disability social secur||disability-social secur||disability-social secur||social worker||disability-social secur||social security 3rd of every 0||disability-social secur||socialsecuritybenefits||social securty disabili||disability-social secur||disability-social secur||social security adminis||socialional||social security disab||disability-social secur||disability-social secur||social security disabil||disability-social secur||social studies school ser||social media consult serv||social security admini||disability-social secur||disability-social secur||disability-social secur||self emploted||self empolyed||self employed ryans rod s||work for myself||self employeed- barber||self employeed||self employed schilling||self kennedy corp||self employeed||self employeed||self employed self empl||self employed nanny||selfemployedx2f1099 emp||self-employee||craig moore - self||self employed dover dowry.com||self employeed||self employed home heal||self direct||self employeed||self-billie walker||uberself employed||self employed care take||selfemployedx2f1099 emp||self employed barber||self employeed||self employed-owner||self emplooyed||workers compensation||housekeeping||housekeeping||baby sitter||cleaning and baby sitti||babysitterefri 300||social security/pension||disability social security||disability social security||recv ssi disability||disabled ss workman com||retired united states a||ss dis 00000-0000||ssid||retired - ssi||social sec disabity||homemaker and take care of elderly||ssi 3rd||ssid||pssi||ssi government pay||ssi/disabitly||ssd &ssi||ssi/child support/tafdc||i am on ssi||ssi/adoption||disssi**1st & 3rd**||ssi 1st||ssi (1st)||disibiltyssi||ssi\ssa||ssi (1st)||retiredssi||ssi dis net||retirement-ssi||social securiy||social security disabilities||social security state of||socail securty||soci||disability social se||disability social security||social security admi||social sercurity||social secuirty||socialecurity||security social||social secruity||social security '||us social security a||socjal security||disability-social secur||social security disabil||social security retirem||social security 00000-0000||soc secdaycare||disabled social securit||social security disabi||social securites||socjal security||social security disabil||soc security (1st3rd)||soc sec admin||social securitydisabili||social security disabi||disability-social secur||social security disabil||social securitydisability||va retired||disabled retired vetera||retired-hilton hawaiian||retiredpention||railroad retirement disability||disability and retirement||us army - military retired||retired us air force||us army retired||disability & retired||fred thornton/ retired||retired va||retired-shipyard||retired 00000-0000||retiredd - military||retired 00000-0000||retired with pension||retired smco||retired 00000-0000||self employed retired||gm retired||retieed||caretaker||retier||disibity||disabled/mgr burger king||ssa disablity||disability rights center-kansas||state disability||la. disability determinat||va disability and ssdi||disiblity||permanent dissability||disabilities rights||disabale||unemployeement dis||ss disable||disabled miltary veteran||dis. 1st||s.s.idisability||disability - 2 checks   730||dis (3rd)||sosial security disabil||disablitiy||disabiloity||disabilty from aflac||disability1st 00000-0000||self - daycare||self employed massage t||self employeed||self employed-toolz n t||self daycare||self-rental property||selfemployeed-mkt||self-daycare||self employedowner||self employeed||self-employed uber driver||self - home remodel||self employed (painter)||nys unemployment||child support/unempl||layoff unemployment  47||ssi benefits||diabled||segura social/ssi||uber||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown(has no #'s) ||other (has no #'s)||disabled vet||hope community||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi||workman s comp||at home mom ||disabled-soc sec||worker comp||retored||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||avon||veteran s benefits||non employed ||ssi/benefits||sitter||pension||retiree||unknown ||segura social||international pension||social secretirement||2nd income ||home maker||home maker mom||lyft||permanent disability||ssi/da||ssi/pns||foster grandparents||self employed/musician ||ssi income ||full time student ||funded by parents ||privatecaregiver||care giver||social security 4||military pension||ssdi||dlsability||self employed2||unemployed ||2nd income||2nd income||2nd income||2nd income||military disability||dis from metlife||disabled va benefits||disability-sondaughter||disablety||disabled mth.||dis veteran 00000-0000||dis3rd931||disability on 2 kids||dis3rd1194||dis 3rd 1072 00000-0000||social security-disabil||dis 00000-0000||ssi disabled 00000-0000||disability 3rd wed 00000-0000||social security dis||disability 00000-0000||dis-third dd to mutual saving||disabss||ssi disability 00000-0000||disability rights||dis-safeway||social security-disabil||retired nfl||retirementssi||retirementss||retirement  ss||retiredinv||retirement-||social security benefit||ssi her 00000-0000||ssi-child support||ssi for a child||perm dis ssi||ssi-ssa||ssipension||ssi benefits ||pension and ssi||ssdi ssi||ihss and ssi||ssi f||ssa 2nd wed 1257.00 00000-0000||other||other||other income||self emp - seven day beau||self employed construction 000||selfgraphic designer||selfgardener||self-landscaping||hcc construction self||self employee avonjoyas||self employedserigio fi||self emplolyeed||ssi/pension (va)/pension (usps)||ssi c#526619845a||ssi disability va pe||ssi benefit||ssi di||ca disability||disabled vet veterans pension||pendind disability||social security disability opm postal retirement||social security / disability||social seurity disab||socialsecurity disability||ss disabilty||disability network wayne county||social security disability benefits||copes. /dshs s.s.a disability||i am disabled||ny dissabilitay||ssdi.org - social security disability information||sc disability||disability income and social security income||social security / disability||no longer emp as of dec||self employment expo||officeemploye||myofficeemploye||self employed baby sitter||umemployment||self manufacturer||self contract||ssi 2nd wednesday||ssi retirement||ssi husband||ssipension||ssid||ssi 00000-0000||ssinew horizon||disabled ssi||pension ssi||retirement and ssi||penion ssi||ssi retirement||ssipension||retiredssi||ssi grossed up||ssid||ssi 00000-0000||ssissd||soc ssi||ssi   ssd||ssi 00000-0000||disabled ssi||reitred ssi||ssi ssa||ssi/ consultant||ssissdchild support||ssi survivors benefits||retired-ssi-va||ssi||ssi and child support||the ssi group||get ssi||ssi and dis||ssi - 1 child||ssi- dis||olympic diner  ssi||unemployed-ssi||retiredssissdpension||ssi and alimony||ssi 122||ssi/social security||social security disability /ssi||ssi ssdi||va compensation||workmans compensation||widows pension||retired pension ss||retired spfld city sch||retired-city of lngv||u.s navy retirement||sprintretired||retired ss||retird||retired 00000-0000||retired - dmv||caretaker||retired- va benefits||retired-disability||us army retired||fedex retirement||social security 00000-0000||disability-social secur||social security disabil||us soc sec disability||social security disabil||social security disab||disability and socail security||disability-soc sec||social vocational services||soc sec-widows benefits||soc. sec. dis.||social security dis||social security - disab||social||social security room 2||social security 00000-0000||social security disabil||social security and dis||disability-social secur||disability-social secur||socsecben||disability-social secur||social security 00000-0000||social security admi||social security   disab||disability-social secur||social security adminis||social security ha||social security 00000-0000||social3||disability-social secur||social security 00000-0000||social security dis||social security disabil||social security adminis||disability-social secur||social secrutiy||disability-social secur||receive social security||self employed recyclin||sekf employed||unemploymet||selfemployedx2f1099 emp||self employed legally||selfemployedx2f1099 emp||disemployed||self-employed caregiver||self-employedx2f1099 e||slef employed||wi unemployment||unempoloyed||temp disability||self-employedx2f1099 e||self employeed||not currenly employoed||self employeed||self employedlogger||self - employed||tempstaff||selfemployedx2f1099 emp||unemplyed||employer||unemployed take care of||self employed - it spec||self employeed||temporary fill ins||unemployed with income||cmo title loan noemploy||self employed barbershop||not employed as of yet||cmo title loan noemploy||self funeral director||self- silvercreek reali||my self my mother||self one stop auto||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income 00000-0000||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||work||workers comp||work at home||work||work||isabled||private daycare||foster care||caregiver services||care givers||licensed care givers||selfemployed||self employee||selfemploy||self-employee||self_employee||home maker||personal trainer||self employeed||selfemployeed||self-employeed||creditors collection||creditors collection service||aarons||aaron's||champion financial services||champion financial||barium chemicals inc||barium & chemicals inc||BARIUM AND CHEMICAL||Anderson-Shea Insurance||Premier Retirement Services||Premier Retirement Services Inc||ICE BAR ORLANDO||Crest Office Furniture||Champion Financial Services||SIMOS||Teleperformance||Teleperformance USA||TELEPERFORMANCE USA||TELEPERFORMANCE||Springpoint Senior Living ATT HR AMY||SCHOLAR CRAFT PRODUCTS||farm bureau insurance||ASPECT SOFTWARE||Tech-Synergy||COMMUNITY COLLEGE OF BALTIMORE||Odgers Berndtson Personnel Consultants||ENDOCRINOLOGY AND DIABETES CENTER||DYERSBURG VA CLINIC||Acuff & Acuff Inc||WURTH REVCAR FASTENERS||The UPS Store||Surrey Vacation Resort||FOOTHILLS ANIMAL SHE||woodbridge cusano inc cpa||ELY ECHO||PENASCO HIGH SCHOOL||VERO DENTAL SPA||IBEW||BCL TECHNOLOGIES||MISSION PEDIATRICS INC||Sweet P Enterprises Inc||Ideal Stair Parts Inc||PERSONAL TOUCH HOME HEALTH||WAGNERS OUTDOOR EXPRESS||Nelson Dermatology Manassas Dermatologist||Solstice Sleep Products, Inc||CROSLEY BROTHERS MOVING||STILBON CORP||ServiceMaster||INDIGO TRADE SOLUTIONS||Summerville Catholic School";
			
			$badpoear=explode('||',$badpoe);
$expq=mysql_query("SELECT * FROM `b_all_employers` WHERE EMPL_NAME!=''");
while($sr=mysql_fetch_assoc($expq))
{
	$nmm=strtolower($sr['EMPL_NAME']);
	if(strstr($badpoe,$nmm))
	{
		echo $sr['EMPL_NAME'].'<br/>';
		$dq=mysql_query("Delete from b_all_employers where ID='".$sr['ID']."'");
	}
}

die();
$sq=mysql_query("Select * from caseduedates where pcode like 'POEVER%' and start_date > '2019-08-27 00:00:00' and start_date < '$chkd'");
while($sr=mysql_fetch_assoc($sq))
{
	$chq=mysql_query("Select * from case_history where case_no='".$sr['case_no']."' and event='Assigned to InternalPOEFilters'");
	if(mysql_num_rows($chq)==0)
	{
		$chq=mysql_query("Select count(id) as tot from verify_case_inputs where caseno='".$sr['case_no']."'");
		$chr=mysql_fetch_assoc($chq);
		echo $sr['case_no'].'|'.$chr['tot'].'|'.$sr['start_date'].'<br/>';
	}
}

die();
$expq=mysql_query("SELECT * FROM `b_all_employers` WHERE UID='' OR UID=0 order by ID desc limit 1000");
while($sr=mysql_fetch_assoc($expq))
{
	$chk='';
	//echo "Select ID as IID from b_active_accounts where ACCT_ID='".$sr['ACCT_ID']."'".'<br/>';
	$chq=mysql_query("Select ID as IID from b_active_accounts where ACCT_ID='".$sr['ACCT_ID']."'");
	if(mysql_num_rows($chq)==0)
	{
		$chq=mysql_query("Select UID as IID from b_closed_accounts where ACCT_ID='".$sr['ACCT_ID']."'");
		if(mysql_num_rows($chq)==0)
		{
			$chk='no';
			$nf++;
		}
	}
	
	if($chk=='')
	{
		$chr=mysql_fetch_assoc($chq);
		$upq=mysql_query("Update b_all_employers SET UID='".$chr['IID']."' where ID='".$sr['ID']."'");
		$cc++;
		$cg=$cg+mysql_affected_rows();
	}
}
echo $cc.'-->'.$cg.'-->'.$nf;
die();
$expq=mysql_query("SELECT * FROM `auto_ftp_files` WHERE ( client LIKE '1971-%' OR client LIKE '1498-%' OR client like '2252-%') and db='Done' AND fetchtime > '2019-08-19 00:00:00' and casetime='dup' AND products LIKE 'AUTOMATION' ORDER BY `auto_ftp_files`.`fetchtime` ASC limit 100");
while($sr=mysql_fetch_assoc($expq))
{
	$upq=mysql_query("Update auto_ftp_files SET casetime='dupp' where id ='".$sr['id']."'");
	
	$poepos='';$poephn1pos='';$poephn2pos='';$poeadd1pos='';$poeadd2pos='';$poecitypos='';$poestatepos='';$poezippos='';$poeex1pos='';$cpos='';$table='';
	$chk='';$source='';
	if($sr['client']=='2252-TU Premium')
	{
		$table='TU_Premium';
		$source='144';
		$cpos=18;
		$poepos=19;$poephn1pos=24;$poephn2pos='';$poeadd1pos=20;$poeadd2pos='';$poecitypos=21;$poestatepos=22;$poezippos=23;$poeex1pos='';
		$sno=0;
	}
	if($sr['client']=='1498-EXP Clarity POE Waterfall')
	{
		$table='Clarity';
		$cpos=1;
		$source='106';
		$poepos=65;$poephn1pos=46;$poephn2pos=51;$poeadd1pos=66;$poeadd2pos='';$poecitypos=67;$poestatepos=68;$poezippos='';$poeex1pos=59;
		$sno=25;
	}
	if($sr['client']=='1971-Experian POE Waterfall')
	{
		$table='Experian';
		$cpos=5;
		$firstfive='yes';
		$source='133';
		$nflname=basename($sr['destination']);
		$poepos=59;$poephn1pos='';$poephn2pos='';$poeadd1pos=60;$poeadd2pos='';$poecitypos=61;$poestatepos=61;$poezippos=62;$poeex1pos=63;
		$sno=6;
		if(strstr($nflname,'STMT'))
		{
			$chk='no';
		}
	}
	
	$ofpath=$sr['destination'];
	$ofname=basename($sr['destination']);
	$nfname='Good_'.basename($sr['destination']);
	$nfpath=str_replace($ofname,$nfname,$ofpath);
	
	if(!file_exists($nfpath))
	{
		$nfpath=$ofpath;
		if(!file_exists($nfpath))
		{
			$bad.=$nfpath.'</br/>';	
			$chk='no';
		}
	}
	
	if($chk=='')
	{
		$handle = fopen($nfpath, "r");
		$i=0;$adelc=0;
		$insc=0;$in=0;$nf=0;$nl=0;
		while (($data = fgetcsv($handle, 100000, ",")) !== FALSE) 
		{
			$qu2="";
			$data = array_map(
				function($data) {
				$x=str_replace("'", "", $data);
				$x=str_replace("\n", " ", $x);
				$x=str_replace("/", "RNNSLASH", $x);
				$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
				$x=str_replace("RNNSLASH", "/", $x);
$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
				return str_replace(",", "", $x);
			},
			$data
			);
			if($i==0)
			{
				$rhead=implode(',',$data);
			}
			if($i>0)
			{
				$sreason='';$cno='';$ifssn='';
				$poe=$data[$poepos];$poephn1=$data[$poephn1pos];$poephn2=$data[$poephn2pos];$poeadd1=$data[$poeadd1pos];$poeadd2=$data[$poeadd2pos];$poecity=$data[$poecitypos];$poestate=$data[$poestatepos];$poezip=$data[$poezippos];$poeex1=$data[$poeex1pos];$htype='';
				
				$cno=substr($data[$cpos],0,5);
				$ifsn = preg_replace("/[^0-9]/", "", $data[$sno]);
				$ischeck=intval($ifsn);
				if($ischeck>0)
				{
					$ifssn=str_pad($ischeck, 9, '0', STR_PAD_LEFT);
				}
				else
				{
					$chk='no';
				}
				
				$poephn3=$data[$poephn3pos];
				if($poephn1=='' && $poephn2!='')
				{
					$poephn1=$poephn2;
				}
				
				if($chk=='')
				{
					if($poe!='' || $poephn1!='')
					{
						$in++;
					}
					else
					{
						$chk='no';
						$nl++;
					}
					if($chk=='')
					{
						$chq=mysql_query("Select id from a_intoRNN_POE_completed where social_security_number='$ifssn' and case_no='$cno'");
						if(mysql_num_rows($chq)==0)
						{
							$chq=mysql_query("Select id from a_intoRNN_POE where social_security_number='$ifssn' and case_no='$cno'");
							if(mysql_num_rows($chq)==0)
							{
								$chk='no';
								$nf++;
							}
						}
					}
				}
				
				if($chk=='')
				{
					$chr=mysql_fetch_assoc($chq);
					
					$insq=mysql_query("INSERT INTO `b_all_employers`(`ID`, `UID`, `ACCT_SSN`, `ACCT_CASE`, `ADD_FILE`, `ADD_DATE`, `ACCT_DUE_DATE`, `ACCT_SOURCE`, `ACCT_ID`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_PHONE1_NMBR`, `EMPL_PHONE2_NMBR`) VALUES ('', '', '$ifssn', '$cno', 'Dups', '20190829', '', '$source', '".$chr['id']."', '".mysql_real_escape_string(trim($poe))."', '".mysql_real_escape_string(trim($poeadd1))."', '".mysql_real_escape_string(trim($poeadd2))."', '".mysql_real_escape_string(trim($poecity))."', '".mysql_real_escape_string(trim($poestate))."', '".mysql_real_escape_string(trim($poezip))."', '".mysql_real_escape_string(trim($poephn1))."', '".mysql_real_escape_string(trim($poephn2))."')");
					
					$insc=$insc+mysql_affected_rows();
				}
			}
			$i++;
		}
	}
	if($insc!=$in)
	{
		echo $nfpath.'>';
		echo $insc.'|'.$in.'|'.$nf.'|'.$nl.'<br/>';
	}
}
echo 'Bad Files: <br/>'.$bad;
die();
$agent="2643218-6003,2644076-6003,2598615-6003,2642543-6003,2602286-6003,2602984-6003,2603168-6003,2645337-6003,2596965-6002,2627928-6002,2601454-6002,2626202-6002,2599149-6002,2596470-6002,2596938-6002,2597869-6002,2600061-6002,2602335-6002,2603312-6002,2603880-6002,2599719-6002,2599829-6002,2599943-6002,2600333-6002,2633532-6002,2622617-6004,2602101-6004,2626876-6004,2593816-6004,2596878-6004,2598263-6004,2592844-6004,2596431-6004,2597471-6004,2597964-6004,2602765-6004,2627897-6004,2593866-6004,2632530-6004,2597827-6004,2622711-6004,2598132-6005,2599858-6005,2601858-6005,2598131-6005,2601900-6005,2602600-6005,2603412-6005,2599717-6005,2627099-6005,2602646-6005,2631177-6005,2600022-6005,2592679-6005,2597584-6005,2603637-6005,2633752-6005,2600129-6007,2599529-6007,2598871-6007,2598883-6007,2598901-6007,2631969-6007,2596693-6007,2597851-6007,2602181-6007,2601774-6007,2601793-6007,2640444-6007,2596485-6007,2624062-6007,2593918-6007,2594043-6007,2598183-6002,2599129-6002,2627152-6002,2600240-6002,2601252-6003,2641021-6003,2598760-6003,2598203-6003,2592462-6003,2601979-6005,2640435-6005,2602652-6005,2628783-6005,2598935-6005,2600187-6005,2645124-6005,2596445-6005,2597133-6005,2602695-6005,2599910-6005,2626319-6005,2600932-6005,2602502-6005,2624043-6005,2640193-6005,2643468-6005,2597109-6005,2601160-6005,2645101-6005,2645826-6011,2601927-6011,2596550-6011,2600206-6011,2600966-6011,2601158-6011,2603051-6011,2603577-6011,2626762-6011,2632636-6011,2640763-6011,2639975-6011,2597413-6011,2601552-6011,2603270-6011,2631436-6011,2639680-6011,2641151-6011,2644014-6011,2645276-6011,2597211-6011,2597670-6011,2598375-6011,2599848-6011,2600538-6011,2601541-6011,2622777-6011,2628119-6011,2629169-6011,2639735-6011,2597221-6011,2644768-6012,2597245-6012,2594851-6012,2596487-6012,2596661-6012,2597430-6012,2561397-6012,2592291-6012,2597618-6012,2599466-6012,2601337-6012,2592358-6012,2597047-6012,2598060-6012,2627379-6012,2635663-6012,2596454-6012,2600618-6012,2602990-6012,2561455-6012,2602548-6013,2597153-6018,2603498-6018,2603957-6018,2593870-6018,2594115-6018,2600649-6018,2565165-6018,2600189-6018,2601141-6018,2603108-6018,2640661-6018,2644736-6018,2600469-6018,2629763-6013,2597301-6013,2592459-6013,2600788-6013,2603163-6013,2603531-6013,2598742-6013,2599316-6013,2601962-6013,2602364-6013,2602988-6013,2626697-6013,2602109-6013,2625393-6013,2625627-6013,2628409-6013,2642958-6013,2644857-6013,2602220-6013,2602604-6013,2640427-6013,2592994-6013,2602561-6013,2599892-6013,2602636-6013,2603985-6013,2641172-6013,2650573-6013,2594160-6013,2597683-6013,2601553-6013,2602268-6013,2625267-6013,2602670-6013,2597019-6013,2592836-6013,2596597-6013,2598476-6013,2598352-6018,2600579-6018,2597024-6018,2631068-6018,2638876-6018,2597445-6018,2599932-6018,2600365-6018,2602831-6018,2631252-6018,2597353-6018,2601276-6018,2597874-6019,2603929-6019,2598165-6019,2630304-6019,2598652-6019,2598339-6019,2601895-6019,2629715-6019,2632481-6019,2603064-6019,2632306-6019,2644821-6019,2638913-6019,2596771-6019,2597027-6019,2597363-6019,2598248-6019,2598360-6019,2600270-6019,2593530-6019,2602299-6019,2629678-6019,2635350-6021,2643547-6021,2597948-6021,2599119-6021,2641768-6021,2598046-6021,2601414-6021,2631201-6021,2597201-6021,2597252-6021,2597593-6021,2602869-6021,2604023-6021,2598508-6021,2602544-6021,2602012-6021,2593637-6021,2631299-6022,2599955-6022,2622780-6022,2627141-6022,2598327-6022,2633531-6022,2632143-6022,2623320-6022,2633306-6022,2603434-6022,2603702-6022,2602969-6022,2594150-6022,2597785-6022,2599562-6022,2600324-6025,2604034-6025,2631894-6025,2599580-6025,2602521-6025,2599325-6025,2600474-6025,2601583-6025,2603059-6025,2640461-6025,2633275-6025,2600559-6025,2602265-6025,2600477-6025,2602614-6025,2598348-6025,2597762-6025,2601353-6025,2603268-6023,2603296-6023,2626625-6023,2650313-6023,2596934-6023,2644871-6023,2597088-6023,2598251-6023,2602478-6023,2597322-6023,2601644-6023,2645306-6023,2596599-6023,2593652-6023,2600464-6023,2603366-6023,2632222-6023,2597679-6023,2602884-6023,2603313-6023,2594162-6023,2597761-6023,2603305-6023,2642823-6023,2593396-6023,2599975-6023,2603080-6023,2647945-6023";
$agentqar=explode(',',$agent);

foreach($agentqar as $tt)
{
	$cx=explode('-',$tt);
	$uid=$cx[0];
	$agn=$cx[1];
	$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='$agn' where ID='$uid'");
}
die();
$sq=mysql_query("Select * from b_active_accounts where ACCT_AGENT='7720' and POESCORE>'6'");
while($sr=mysql_fetch_assoc($sq))
{
	$chq=mysql_query("Select ACCT_AGENT from b_work_history where UID='".$sr['ID']."' and ACCT_AGENT Like '6%' order by ID DESC limit 1");
	$chr=mysql_fetch_assoc($chq);
	echo $sr['ID'].','.$chr['ACCT_AGENT'].'<br/>';	
}
die();

$tdd=date("Y-m-d");
$ydd=date("Y-m-d", strtotime($tdate. ' - 1 weekday'));

$strCommandLine = "unzip -P WjU4lWYVcE To_LCI_08-23-2019_ADD_BKRET_BK.zip";
echo system($strCommandLine);

die();

echo system('zip -P WjU4lWYVcE To_LCI_08-23-2019_78787.zip To_LCI_08-23-2019_78787.csv');
die();


$strCommandLine = "unzip -P 1UwEuM5xszft3FWGzmXCngbWHz4IOEq6 To_LCI_08-23-2019_ADD_BKRET_BK.zip";
echo system($strCommandLine);

die();

echo system('zip -P 1UwEuM5xszft3FWGzmXCngbWHz4IOEq6 To_LCI_08-23-2019_78787.zip To_LCI_08-23-2019_78787.csv');
die();


echo '<br/>Closed Verified:<br/>';
echo $tdd.'<br/>';
$hits='';
$qw=mysql_query("SELECT ACCT_COE, Count( Distinct UID ) as tot FROM rnnginc_webapp.`b_closed_accounts` WHERE CAPCODE LIKE '1%' AND CLOSED_ON LIKE '$tdd%' GROUP BY ACCT_COE");

while($sr=mysql_fetch_assoc($qw))
{
	echo $sr['ACCT_COE'].' -> '.$sr['tot'];
	$hits=$sr['tot']+$hits;
	echo '<br/>';
}
echo $hits;

echo '<br/><br/>'.$ydd.'<br/>';
$hits='';
$qw=mysql_query("SELECT ACCT_COE, Count( Distinct UID ) as tot FROM rnnginc_webapp.`b_closed_accounts` WHERE CAPCODE LIKE '1%' AND CLOSED_ON LIKE '$ydd%' GROUP BY ACCT_COE");

while($sr=mysql_fetch_assoc($qw))
{
	echo $sr['ACCT_COE'].' -> '.$sr['tot'];
	$hits=$sr['tot']+$hits;
	echo '<br/>';
}
echo $hits;

echo '<br/><br/>';

die();

//UPDATE `b_active_accounts` SET ACCT_AGENT = concat( 'HOLDls-', ACCT_AGENT ) WHERE ACCT_COE = '5C' AND ACCT_CASE != '72162' AND length( ACCT_AGENT ) = '4' AND ACCT_AGENT LIKE '6%'

mysql_query("Update `b_active_accounts` SET ACCT_AGENT=REPLACE(ACCT_AGENT,'HOLDls-','') WHERE ACCT_COE='COL' and ACCT_AGENT NOT LIKE '%RCALL%' and ACCT_AGENT not like '%PPOF%' and POESCORE>1");
echo 'COL '.mysql_affected_rows().'<br/><br/>';

die();


$sqq=mysql_query("Update `b_active_accounts` SET ACCT_AGENT=REPLACE(ACCT_AGENT,'HOLDls-','') WHERE POESCORE>5 and ACCT_AGENT like '%Holdls%'");
die();
while($r=mysql_fetch_assoc($sqq))
{
	$score=$r['POESCORE']-4;
	$upq=mysql_query("Update b_active_accounts SET POESCORE='$score' where ACCT_SOURCE='324' and POESCORE='".$r['POESCORE']."'");
	echo '<br/>'.$r['toto'].' -> '.$r['POESCORE'].' - '.mysql_affected_rows();
}
die();

$nxhead="social_security_number,first_name,last_name,street_address_1,street_address_2,city,state,zip_code,date_of_birth,phone_1,phone_2,phone_3,client_field_1,client_field_2,client_field_3,client_field_4,client_field_5,account_open_date,rnn_id,due_date,state_in_scope,Source,Match_Type"."\n";
	
	$coehead="ACCT_AGENT,ACCT_CLIENT1,ACCT_SOR_DATE,ACCT_SSNUM,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,ACCT_DOB,ACCT_ID,ACCT_SCORE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_AREA,EMPL_PHONE1_NMBR"."\n";
	
	$coefile='To_ROCKY_Cus'.$wcase.'.csv';
	echo $coefpath='files/Admin/'.$coefile;
	$sendrc=0;
	//$coeupsq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='RAW' where case_no='$wcase' and Source_Code='122'");
	$coesq=mysql_query("Select * from rnnginc_webapp.a_intoRNN_POE where case_no IN ('71784','71805','71851','71849','71607') and status='RAW' group by social_security_number");
	if(mysql_num_rows($coesq)>0)
	{
		$coehandle = fopen($coefpath, "w");
		fwrite($coehandle,$coehead);
		
		$badpoe="hair dresser||army, navy, etc. ||ssa||va benefits||day care||freelancer||dept of defense||us air force||missing phone #'s||retired||ssi||benefits||disability||disabled||disabled veteran||home worker||homemaker||pension||self||self employed||selfemployed||slf||social security||ss||s.s.||s.s||ssd||ssdi||ssi||va||none||n/a ||na||widow ||military ret||unemployment||disabled veteran||daycare||benfits||veterans administration||self emp||us army||us congress||us marines||social security administration||social security-disability||us navy||retired ssi||n/a||social security disability||n/a||n/a||retired disabled||n/a||n/a||retired verizon||n/a||retireddeptofdef||social security/disability||social security adm||retired / part -time||social security & ravens store||self-employeed||soc sec va||sef employed||n/a||n/a||disabiled||ssi disabled||soc sec disab||ssi & ssd||disability ssi||n/a||home maker||retired - self employed||retired ssd||retired/ssi||disability income||ssi/ rail road||retssi||disabilityssi||ssi & pension||home maker||disabled vet||disabilty ssi||social security widow benefit||n-a||disability pending||disabilaty||retired pension business||home maker||ssd and child support||va local 322||ssi disb||n/a||retired city of wincheste||retired disable vet||ssdi pension||retirement rental||soc sec/dis||ue||ssid / alimony||ss va pension||home maker||social sec||social security desability||disabiltiy||retired state of california||ue||retired trucking||retired cbr||disability income||ss disability insurance||retired/us army||social security/disability||retired ssi||ssi pension||veterans admin||veterans pension||ue||n/a||va & federal government||ssdi pension||retirement and disability||retired disabled||ssi/pension||disability - ssd||va disability||soc security||ssi/retired||home/self||social security disability||disablilty||une||ssi retiment||veterans affair disa||social secuity||social security/disability||social security/disability||social security disability||social security/disability||social security ssi||retirement survivor annuity||social security/disability||social security administr||social security/disability||unemployed||social sercuity||social security/disability||disability/social security||socail security||ssi/retirement||disability/social security||social security disability||social security - disability||disability/social security||socialsecurityadministration||disable||social security administr||no job||ssi/disabilty||self employee||disability/social security||ssi social security||disability/social security||retired from d. m. v.||n/a||na sitter||no employer||retirement-va hosp||retired pers le||veterans of foreign wars department of montana||veterabn||disability 582||ss heating nle||veterans with dignity||ssi retirer||retired 67||soc sec 718 00||ssi and self emp landscaper||homemaker sdt||ssi 1070 00||ssi 4th wed of month||retired legal profes||self employed full time||social security retiremen||social security disab.||soc sec||retired from rent control||ss retirement||ssi and pension||va retirement||ssdi self employed||no poe||social securitu||no poe||retirement/pension/ss death||veterans affairs||socail security||ssi$ssa||va disabilaty||no job||retirement||retirement||ssi 766||retirement/pension||socialsecurity_disability||retirement||social security income||ss disability||unemployed||disability ss||ss & disability||ssi/dis||soc sec dis||ssi and di||social secuity disability||ss pension||retired sos sec||disabily||ssi retirement pension||not working||u e||soc sec & wife||u e||u e||retired johnson co sheriff||ss/retired||ssi and disability||soc sec disability||umemployed||social security ad||s s i disability||ss/ penison||retirement income||na on cbr||retired per cbr||social security disabilit||retrried pention||retired per cbr||u e||retired gm||soc sec & pension||retired veteran||ssi vad dfas||retired- pension||u e||retired gm||disablity ssi||ss retired||social security-retirement||retired per cbr||retired chrysler||ret||ss/retired||unemloyed||soc sec disability||ssidisability||disabililty||self emploed||self-employed||disabity||ssi/employed||unemployment benefits||disablity||ssidisability||retire||socialsecurity||unemploment||ss and va||not applicable||ssi & d||dissability||self emplyed||u e almst a yr||ssi 73 years old||ssi dob 10 1938||disability 1574||ssi 1115 mon||retired born 11 37||retired ssi pensio||ssi 600 month||ssi /pension||disbale||ssi (retired)||retired 08 31 05||retired military||disab||retired state of florida||na ssi||social security adm.||ssa disability||ssci||ssi/674||ssi/visiting anger||retired sub docs||retired from gm per cbr||retired-hopper constructi||disabilty||retired kansas building trades||veterans a||ssi/ssdi||retired us military||veteran s administration||ssd dss grant||disability benefits||soc sec benefits||ssi income||ssd ssi||social security retirement||disability/ workers comp||social security & annuity||ssd/pension||social security rec||ssd and comp||ss plus pension||ssi / pension||veterans disability||ss i||ssa recipient||soc sec recipient||retirement/ss||soc sec benefits||retired social security||socailsocarity||social security/ daycare||retired_benefits||retired/pension||social security/ self employed||disability benefits||self-employer||disbled||my self||social securtity||selfemployer||va disbility and retireme||scoial security||home||home||self emloyed||social security & ssi||retired and ssi||retired civil servic||retired boeing aircr||ssi & retirement||benefits admin corp||social security benefits||unknown||uber||ssi disabilty||ssi / widows pension||social security admin||soc||ssdi/pension-net||ssi monthly on 1st||ssn||ssi disab||ss recipient||ssdi benefits||ssi disability benefits||ssi/ pension||soc scc||social socurity||ssi 674 00 each month||ssi benefits||diabled||segura social/ssi||uber||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown||other ||disabled vet||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi pension va||ssi va pension||retired nypd||ss / workers comp||ssi and retirement||ss dis||retired pension||soc sec pension||ssi penson||ssd pension||soc sec / pen||retired social secur||retired nyc police officer||retired nyc corrections||retired ny dept corrections||ssi dissability||ss benefits||social sec recipient||social security recipient||retired from nyc law dept||social sec income||ssdssi||ssi recipient||social security recipient||social security recipient||ssd pension||ssi recipient||retired us army||soc security admin||ssi pension investments||retired transit worker||social security recipient||socai security||ssi/ssd||waiter||waitress||bartender||taxi driver||cab driver||disabled/ssi||un employed||disability self employed||ssdi social security||retiired||someone||adult and child||clean houses||sss disability||soical security||housewife||on disability||u.s. government||ss- $507.00||socical sercurity||ssbeneifits||daycare provider||mother||soical security||nothing||disabllty||soc sec retirement||retired general elec||retired city of cleveland||retired disabilty||house wife||no poe on cbr||retired - alcoa||disabilitly||child provider||retirement housing||social security / annuity||us social security administration||on ssa||my own buisiness||ssa.gov||social security disabilty||unemployed/going on disability||self employer||retired-social security||ssi diabilaty||i dont work||disabeled||retired from comprehensive care center||retired disablity||i am disable||retirment||disability and social security||husbands income||retired/ disabiliabled||ssid & childcare||self employed andcsocial security||self employment||child support||none-retired||catholic charities||social secuirty/disabilty||fedgoverment||na company||retired -ssa||pers retired/pension||disabled and child support||dis||ssdi/ssidi||united states army||retirement systems of alabama||social security administration benefits||ss administration||retired receive retirement/ss||ssaandstudent||s.s. disabled||ssi benifits||unemployment state of ohio||social serurity||social security di||retied||us disability||selfempl||s s i||ssldc||social security 1391||self imployed||unemploed||ssc||fedgovernment||husband on va disablity & socisal securty||ssa treas 31o xxsoc sec||ssi collect for myself||retired/disables||retired teacher||i am on security||not workng||sis||disibility||disability/pension||ssa & ltd||on social security disability||on disability||don't work||rertirment||retired and disability||social security widow||soc. sec.||gov\\||na company||social security and ssi||disabillity||military- army||house wifr||social security and disability||not specified||nonameyet||self support personal care||retiredselfemployedssdi||my cleaning co||on s.s,i > disibitiy||housewife my husband works at walmart||ss53rm disability||ssi/disability||fed government||selfempoled||ret army.||federal government||disability (ssi)||social security administrator||disabilitly||united states army||child care provider (paid by the state)||retired u s army||socail secretary||social securuty benefits||social securit||not collected||retited||currently disabled||s.s. disabilty||not available||notemployed||us army benefits||b||unmpolyment||not employed||home address||diability||army||missouri unemployment||social security disablity||ssi ss child support||dissablitity||na/receives disability||ssi unemployment||social securtiy beneifits||ssdi soc sec||none at this time||retired vet||ss benifits||not provided||n a between jobs who wants me i want to work||training up a child||no poe per cbr||hairstylist||ssissa||babysitting||miltary||retyirement||ssi civil service||retirement/disability||retired us navy||us navy va disability||usarmy||natalys home salon||employer name||not provided||ssi and benefits||none listed on cbr||ssi food asst||ssi per consumer||united states military||none cbr||retired)||pending disability||no poe cbr||ssi per cbr||disblty||not listed||no poe listed||none listed on cbr||usps retired||retired ny dept of correc||no poe onc br||retired-pension||ssa/ssi disability||house keeping||na/receives disability||usnavy||child care||ssdi soc sec||sst||remax/self employed||disabilityva||socal security||us military||permanently disabled||army ret||retired disable||usd 259 retired||dont work ssi||navy||court ordered child support||swlf employed||800-772-1213||disbilty||none on cbr||cbr says student||us military army||disabilitysocial sec||l aid of f||retired disability||retired from kroger 2007||retired navy||benefits||va disablity||ssi + pension||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||avon||veteran s benefits||non employed ||ssi/benefits||sitter||pension||retiree||diabled||segura social/ssi||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown(has no #'s) ||other (has no #'s)||disabled vet||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi||workman s comp||at home mom ||disabled-soc sec||worker comp||retored||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||veteran s benefits||non employed ||sitter||segura social||u s army||retired ssi disabili||u.s. army||caregiver||n a||care taker||disability pension||babysitter||u s gov dept of army||retired nurse||social sacerity||childcare||ssi (0) (401)||survivors benefits ss||socaial security||va disibility||retired/disability||right at home||care taker||dept of defense - air firce...||ssi va||retired pera||disability per cnsmr||wendys no tlx hit||fmc retired||department of veterans af||ssi/chrysler||retired delphi||no record||retired val ss wife has busin||not listed in cbr||gm retired pension||disaiblityssi||mary kay||per cb approved mfg no info||ssi disability per cbr||i am retired||social secur||macys no tlx hit||avon||cbr na||i am christ minstry||net social security||disable with no income yet||ssi va||ssi-disability||retired/disabled||not employed-retired||retirement benefits||s s disabiltiy||ss disablity||no poe listed cbr||social security pension||mcdonalds mgr no tlx hit||retired ssi disability||cbr self emp||s s disability||us government no tlx hit||no po on cbr||us postal service no tlx||gm no tlx hit||disabled vetetan||ssoe group||ssidisablity &heartsidefoods||n\a||1099 self employed||us social security administration / gm||disabled homemaker||no||disiablity||retired postal worker||retired and social security||i am disabled vet collecting a check please help||gov assistance||self (was)now retired on s.s.||ssi / retirement / pension||ssi 647 00||government benefits||desempleo edd||ssi (0) (401)||retirement benefits||reteried||disability check||va/ssi||retired usps, and military retired||retired/social secuity||not employed at this time||ssid, disabled||retired army||department of defense||social security administration office of disability operations||social /death benifits||retired(deptof defense||disibiy||social sercurity administ||ssid||retierd||disability-social secur||social security pays her||disabled ssi||ssid||ssa and ssi||disabled ssi||va ssi||daughters ssi||ssisuplement||ssi - tanf||ssi dissabiluty||oregon ssi||retired-ssi-va||ssdi and ssi||ssi incom||pension ssi||ssi 00000-0000||ssi3rd1569||ssi death benefit||ssi- disability||ssi disablity||ssi 00000-0000||ssi office||ssi-1st 00000-0000||ssi and child support||ssid||vassi||ssi-3rd||ssi subsidy||fargo ssi||ssi baby sitter||ssidiss||ssi for daughter||ssi3rd1279.00||ssi grossed up||ssiannuity||retired dissability||retiredusarmy||retired-disb||retired us.army||retired and pension||retireddisa||retired-disabled||us army retired||retired spartan stores||social disability||disability-social secur||social securitydisabili||disability-social secur||social security pays her||disability-social secur||disability-social secur||social securitydisabili||social security office||social security adminis||disability-social secur||social security--1st||disability social secur||disability-social secur||disability-social secur||social worker||disability-social secur||social security 3rd of every 0||disability-social secur||socialsecuritybenefits||social securty disabili||disability-social secur||disability-social secur||social security adminis||socialional||social security disab||disability-social secur||disability-social secur||social security disabil||disability-social secur||social studies school ser||social media consult serv||social security admini||disability-social secur||disability-social secur||disability-social secur||self emploted||self empolyed||self employed ryans rod s||work for myself||self employeed- barber||self employeed||self employed schilling||self kennedy corp||self employeed||self employeed||self employed self empl||self employed nanny||selfemployedx2f1099 emp||self-employee||craig moore - self||self employed dover dowry.com||self employeed||self employed home heal||self direct||self employeed||self-billie walker||uberself employed||self employed care take||selfemployedx2f1099 emp||self employed barber||self employeed||self employed-owner||self emplooyed||workers compensation||housekeeping||housekeeping||baby sitter||cleaning and baby sitti||babysitterefri 300||social security/pension||disability social security||disability social security||recv ssi disability||disabled ss workman com||retired united states a||ss dis 00000-0000||ssid||retired - ssi||social sec disabity||homemaker and take care of elderly||ssi 3rd||ssid||pssi||ssi government pay||ssi/disabitly||ssd &ssi||ssi/child support/tafdc||i am on ssi||ssi/adoption||disssi**1st & 3rd**||ssi 1st||ssi (1st)||disibiltyssi||ssi\ssa||ssi (1st)||retiredssi||ssi dis net||retirement-ssi||social securiy||social security disabilities||social security state of||socail securty||soci||disability social se||disability social security||social security admi||social sercurity||social secuirty||socialecurity||security social||social secruity||social security '||us social security a||socjal security||disability-social secur||social security disabil||social security retirem||social security 00000-0000||soc secdaycare||disabled social securit||social security disabi||social securites||socjal security||social security disabil||soc security (1st3rd)||soc sec admin||social securitydisabili||social security disabi||disability-social secur||social security disabil||social securitydisability||va retired||disabled retired vetera||retired-hilton hawaiian||retiredpention||railroad retirement disability||disability and retirement||us army - military retired||retired us air force||us army retired||disability & retired||fred thornton/ retired||retired va||retired-shipyard||retired 00000-0000||retiredd - military||retired 00000-0000||retired with pension||retired smco||retired 00000-0000||self employed retired||gm retired||retieed||caretaker||retier||disibity||disabled/mgr burger king||ssa disablity||disability rights center-kansas||state disability||la. disability determinat||va disability and ssdi||disiblity||permanent dissability||disabilities rights||disabale||unemployeement dis||ss disable||disabled miltary veteran||dis. 1st||s.s.idisability||disability - 2 checks   730||dis (3rd)||sosial security disabil||disablitiy||disabiloity||disabilty from aflac||disability1st 00000-0000||self - daycare||self employed massage t||self employeed||self employed-toolz n t||self daycare||self-rental property||selfemployeed-mkt||self-daycare||self employedowner||self employeed||self-employed uber driver||self - home remodel||self employed (painter)||nys unemployment||child support/unempl||layoff unemployment  47||ssi benefits||diabled||segura social/ssi||uber||ssi an retired||disability & child support||social security disability||as disability||disability va||ssi disability||disability/va pension||disability since||ss disability/state retirement||socialsecuritydisability||military||husband||myself||fixed income||retired||per cbr no poe info||va pension||nle||unknown(has no #'s) ||other (has no #'s)||disabled vet||hope community||vet||not asked||ssi dis||penn/ssi/child support||retired & ss||ssi||workman s comp||at home mom ||disabled-soc sec||worker comp||retored||secure security||new york pension||ssd&worekrs comp||retire-annuity||disablity rights ssi ||welfare||court ordered chils support ||socsecurity disability||disability-income||ssdsability benefits||dont work||foster mom||soc.||no income rcvs fia||social service||care giver||avon||veteran s benefits||non employed ||ssi/benefits||sitter||pension||retiree||unknown ||segura social||international pension||social secretirement||2nd income ||home maker||home maker mom||lyft||permanent disability||ssi/da||ssi/pns||foster grandparents||self employed/musician ||ssi income ||full time student ||funded by parents ||privatecaregiver||care giver||social security 4||military pension||ssdi||dlsability||self employed2||unemployed ||2nd income||2nd income||2nd income||2nd income||military disability||dis from metlife||disabled va benefits||disability-sondaughter||disablety||disabled mth.||dis veteran 00000-0000||dis3rd931||disability on 2 kids||dis3rd1194||dis 3rd 1072 00000-0000||social security-disabil||dis 00000-0000||ssi disabled 00000-0000||disability 3rd wed 00000-0000||social security dis||disability 00000-0000||dis-third dd to mutual saving||disabss||ssi disability 00000-0000||disability rights||dis-safeway||social security-disabil||retired nfl||retirementssi||retirementss||retirement  ss||retiredinv||retirement-||social security benefit||ssi her 00000-0000||ssi-child support||ssi for a child||perm dis ssi||ssi-ssa||ssipension||ssi benefits ||pension and ssi||ssdi ssi||ihss and ssi||ssi f||ssa 2nd wed 1257.00 00000-0000||other||other||other income||self emp - seven day beau||self employed construction 000||selfgraphic designer||selfgardener||self-landscaping||hcc construction self||self employee avonjoyas||self employedserigio fi||self emplolyeed||ssi/pension (va)/pension (usps)||ssi c#526619845a||ssi disability va pe||ssi benefit||ssi di||ca disability||disabled vet veterans pension||pendind disability||social security disability opm postal retirement||social security / disability||social seurity disab||socialsecurity disability||ss disabilty||disability network wayne county||social security disability benefits||copes. /dshs s.s.a disability||i am disabled||ny dissabilitay||ssdi.org - social security disability information||sc disability||disability income and social security income||social security / disability||no longer emp as of dec||self employment expo||officeemploye||myofficeemploye||self employed baby sitter||umemployment||self manufacturer||self contract||ssi 2nd wednesday||ssi retirement||ssi husband||ssipension||ssid||ssi 00000-0000||ssinew horizon||disabled ssi||pension ssi||retirement and ssi||penion ssi||ssi retirement||ssipension||retiredssi||ssi grossed up||ssid||ssi 00000-0000||ssissd||soc ssi||ssi   ssd||ssi 00000-0000||disabled ssi||reitred ssi||ssi ssa||ssi/ consultant||ssissdchild support||ssi survivors benefits||retired-ssi-va||ssi||ssi and child support||the ssi group||get ssi||ssi and dis||ssi - 1 child||ssi- dis||olympic diner  ssi||unemployed-ssi||retiredssissdpension||ssi and alimony||ssi 122||ssi/social security||social security disability /ssi||ssi ssdi||va compensation||workmans compensation||widows pension||retired pension ss||retired spfld city sch||retired-city of lngv||u.s navy retirement||sprintretired||retired ss||retird||retired 00000-0000||retired - dmv||caretaker||retired- va benefits||retired-disability||us army retired||fedex retirement||social security 00000-0000||disability-social secur||social security disabil||us soc sec disability||social security disabil||social security disab||disability and socail security||disability-soc sec||social vocational services||soc sec-widows benefits||soc. sec. dis.||social security dis||social security - disab||social||social security room 2||social security 00000-0000||social security disabil||social security and dis||disability-social secur||disability-social secur||socsecben||disability-social secur||social security 00000-0000||social security admi||social security   disab||disability-social secur||social security adminis||social security ha||social security 00000-0000||social3||disability-social secur||social security 00000-0000||social security dis||social security disabil||social security adminis||disability-social secur||social secrutiy||disability-social secur||receive social security||self employed recyclin||sekf employed||unemploymet||selfemployedx2f1099 emp||self employed legally||selfemployedx2f1099 emp||disemployed||self-employed caregiver||self-employedx2f1099 e||slef employed||wi unemployment||unempoloyed||temp disability||self-employedx2f1099 e||self employeed||not currenly employoed||self employeed||self employedlogger||self - employed||tempstaff||selfemployedx2f1099 emp||unemplyed||employer||unemployed take care of||self employed - it spec||self employeed||temporary fill ins||unemployed with income||cmo title loan noemploy||self employed barbershop||not employed as of yet||cmo title loan noemploy||self funeral director||self- silvercreek reali||my self my mother||self one stop auto||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income 00000-0000||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||2nd income||work||workers comp||work at home||work||work||isabled||private daycare||foster care||caregiver services||care givers||licensed care givers||selfemployed||self employee||selfemploy||self-employee||self_employee||self employeed||selfemployeed||self-employeed||creditors collection||creditors collection service||aarons||aaron's||champion financial services||champion financial";
		$badpoear=explode('||',$badpoe);
		
		while($coerow=mysql_fetch_assoc($coesq))
		{
			$coerow = array_map(
			function($coerow) {
				$x=str_replace("'", "", $coerow);
				$x=str_replace("\n", " ", $x);
				$x=str_replace("/", "RNNSLASH", $x);
				$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
				$x=str_replace("RNNSLASH", "/", $x);
				return str_replace(",", "", $x);
			},
			$coerow
			);
			
			$chkphn=preg_replace("/[^0-9]+/", "", $coerow['employer1_telephone']);
			if($chkphn!='')
			{
				$chkphn=substr($chkphn,-10);
			}
			if(in_array(strtolower($coerow['employer1_name']),$badpoear))
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='TRASHED' where id='".$coerow['id']."'");
			}
			else if($chkphn=='6784023000')
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='TRASHED' where id='".$coerow['id']."'");	
			}
			else if($chkphn=='8007221213' && $coerow['employer1_name']=='')//SSI Phone Trash
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='TRASHED' where id='".$coerow['id']."'");
			}
			else
			{
				$trashq=mysql_query("Update rnnginc_webapp.a_intoRNN_POE Set status='RAW' where id='".$coerow['id']."'");
				
				$dued=date('Ymd', strtotime($coerow['Due_Date'].' - 2 Weekday'));
				$phnar='';
				$phnnm=$chkphn;
				$dcheck=preg_replace("/[^0-9]+/", "", $coerow['date_of_birth']);
				if(strlen($dcheck)>6)
				{
					$dob=date('Ymd', strtotime($coerow['date_of_birth']));
				}
				else
				{
					$dob='';	
				}
				
				$insrow=''.','.$coerow['case_no'].','.$dued.','.$coerow['social_security_number'].','.$coerow['first_name'].','.$coerow['last_name'].','.$coerow['street_address_1'].','.$coerow['street_address_2'].','.$coerow['city_name'].','.$coerow['state_name'].','.$coerow['zip_code'].','.$dob.','.$coerow['id'].','.$coerow['Source_Code'].','.$coerow['employer1_name'].','.$coerow['employer1_address'].','.$coerow['employer1_address2'].','.$coerow['employer1_city'].','.$coerow['employer1_state'].','.$coerow['employer1_zip'].','.$phnar.','.$phnnm."\n";
				$sendrc++;
				fwrite($coehandle,$insrow);
			}
		}
		fclose($coehandle);
	}

die();

$sq=mysql_query("Select * from b_active_accounts where ACCT_CASE='70950' AND ACCT_AGENT NOT LIKE 'RCAL%'");
while($row=mysql_fetch_assoc($sq))
{
	$vq=mysql_query("Select client_field_5 from verify_case_inputs where social_security_number='".$row['ACCT_SSN']."' and caseno='70950'");
	if(mysql_num_rows($vq))
	{
		$rc='';
		$vrow=mysql_fetch_assoc($vq);
		$buzzname  =  $row['EMPL_NAME'];			
		$empmatchname  = str_ireplace(array('  incorporation',' inc',' llc',' ltd',' llp',' s-corp',' corp',' corporation'),'',$buzzname);
		$empmatchname  = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));
		if(strlen($vrow['client_field_5'])>0 && strlen($row['EMPL_NAME'])>0)
		{
			$clientdup  =  $vrow['client_field_5'];			
			$clientdup  = str_ireplace(array('  incorporation',' inc',' llc',' ltd',' llp',' s-corp',' corp',' corporation'),'',$clientdup);
			$clientdup  = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $clientdup));
		
			if(strstr($clientdup,$empmatchname) || strstr($empmatchname,$clientdup))
			{
				$rc='yes';
			}
			if($rc=='yes')
			{
				$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT=CONCAT('RCALL-',ACCT_AGENT) where ID='".$row['ID']."'");
				$aa=$aa+mysql_affected_rows();
				echo '<br>'.$row['ACCT_SSN'].'|Yes|'.$clientdup.'|'.$empmatchname;
			}
			else
			{
				echo '<br>'.$row['ACCT_SSN'].'|No|'.$clientdup.'|'.$empmatchname;
			}
		}
	}
	else
	{
		echo '<br/>NotFound|'.$row['ACCT_SSN'];
	}
}
echo '<br/>Recalled '.$aa;
die();



//$sq=mysql_query("Select * from b_closed_accounts where AEMPL_EMAIL IN ('3074', '3072', '3080', '3091', '3030', '3073', '3023', '3089', '3093', '3028', '3106', '3013', '3094', '3045', '3100', '3041', '3099') and CAPCODE='' and POESCORE>7");
$sq=mysql_query("SELECT *
FROM `b_closed_accounts`
WHERE AEMPL_EMAIL LIKE '3%' AND ACCT_COE = 'COL'");
while($row=mysql_fetch_assoc($sq))
{
	//$insq="Insert into b_active_accounts(`ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `PL_MATCH`, `WORK_COMMENTS`, `POESCORE`, `TOSS`) SELECT `UID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, 'EBC' as `ACCT_COE`, '8888' as `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, '' as `CAPCODE`, '' as `LAST_WORKED`, '' as `LAST_COMMENTS`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, `AEMPL_PHONE1E`, `ACCT_AGENT` as `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `PL_MATCH`, '' as `WORK_COMMENTS`, `POESCORE`, `TOSS` FROM `b_closed_accounts` WHERE ID='".$row['ID']."'";
	$insq="Insert into b_active_accounts(`ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `PL_MATCH`, `WORK_COMMENTS`, `POESCORE`, `TOSS`) SELECT `UID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, 'COL' as `ACCT_COE`, '9999' as `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, '' as `CAPCODE`, '' as `LAST_WORKED`, '' as `LAST_COMMENTS`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `PL_MATCH`, '' as `WORK_COMMENTS`, `POESCORE`, `TOSS` FROM `b_closed_accounts` WHERE ID='".$row['ID']."'";
	mysql_query($insq);
	if(mysql_affected_rows()>0)
	{
		$dq=mysql_query("Delete from b_closed_accounts where ID='".$row['ID']."'");
		$ddq=mysql_query("Delete from b_work_history where UID='".$row['UID']."' and CAPCODE='4405'");
		$aa=$aa+1;
	}
//	die();
}
			
echo $aa;

die();

mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '7783' WHERE ACCT_COE = '5C' AND CAPCODE = '0' AND ACCT_AGENT != '7783' AND length( ACCT_AGENT ) = '4'");
echo '5C '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '4444' WHERE ACCT_COE = 'ATL' AND CAPCODE = '0' AND ACCT_AGENT != '4444' AND length( ACCT_AGENT ) = '4'");
echo 'ATL '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '9999' WHERE ACCT_COE = 'COL' AND CAPCODE = '0' AND ACCT_AGENT != '9999' AND length( ACCT_AGENT ) = '4'");
echo 'COL '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '8888' WHERE ACCT_COE = 'EBC' AND CAPCODE = '0' AND ACCT_AGENT != '8888' and ACCT_AGENT != '8887' AND length( ACCT_AGENT ) = '4'");
echo 'EBC '.mysql_affected_rows().'<br/><br/>';

die();

$fullpath='oldscorenow.csv';
$chandle = fopen($fullpath, "r");$i=0;
while (($data = fgetcsv($chandle, 10000000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$upq=mysql_query("Update b_active_accounts SET POESCORE='".$data[2]."', TOSS='POESCORE' where ID ='".$data[0]."'");
	}	$as=$as+mysql_affected_rows();
	$i++;
}
echo $as;
die();


mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '7783' WHERE ACCT_COE = '5C' AND CAPCODE = '0' AND ACCT_AGENT != '7783' AND length( ACCT_AGENT ) = '4' and TIER!='9'");
echo '5C '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '4444' WHERE ACCT_COE = 'ATL' AND CAPCODE = '0' AND ACCT_AGENT != '4444' AND length( ACCT_AGENT ) = '4' and TIER!='9'");
echo 'ATL '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '9999' WHERE ACCT_COE = 'COL' AND CAPCODE = '0' AND ACCT_AGENT != '9999' AND length( ACCT_AGENT ) = '4' and TIER!='9'");
echo 'COL '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '8888' WHERE ACCT_COE = 'EBC' AND CAPCODE = '0' AND ACCT_AGENT != '8888' and ACCT_AGENT != '8887' AND length( ACCT_AGENT ) = '4' and TIER!='9'");
echo 'EBC '.mysql_affected_rows().'<br/><br/>';
die();



/*

Update `b_active_accounts` SET ACCT_AGENT=REPLACE(ACCT_AGENT,'HOLDls-','') WHERE ACCT_COE in ('EBC','COL') and ACCT_AGENT NOT LIKE '%RCALL%' and ACCT_AGENT not like '%PPOF%' and POESCORE>2

Update `b_active_accounts` SET ACCT_AGENT=REPLACE(ACCT_AGENT,'HOLDls-','') WHERE TIER='5' and ACCT_AGENT NOT LIKE '%RCALL%' and ACCT_AGENT not like '%PPOF%' and POESCORE>2

Update rnnginc_webapp.`b_active_accounts` SET ACCT_AGENT=CONCAT('HOLDls-',ACCT_AGENT) WHERE length(ACCT_AGENT)=4 and ACCT_COE in ('ATL','5C','EBC','COL') and POESCORE<3 and TIER!='5'

Update `b_active_accounts` SET ACCT_AGENT=REPLACE(ACCT_AGENT,'HOLDls-','') WHERE ACCT_COE='EBC' and ACCT_AGENT NOT LIKE '%RCALL%' and ACCT_AGENT not like '%PPOF%' and POESCORE>2

UPDATE `b_active_accounts` SET ACCT_COE = 'COL',
ACCT_AGENT = '9999' WHERE POESCORE = '5' AND ACCT_COE = 'COL' AND ACCT_AGENT NOT LIKE '%PPOF%' AND ACCT_AGENT NOT LIKE '%RCALL%'

SELECT ACCT_AGENT,count(ID) FROM `b_active_accounts` WHERE POESCORE = '5' AND ACCT_COE != '5C' and ACCT_COE!='EMP' AND ACCT_AGENT NOT LIKE '%PPOF%' AND ACCT_AGENT NOT LIKE '%RCALL%' and length(ACCT_AGENT)!=4 and CAPCODE=0 group by ACCT_AGENT

SELECT POESCORE, count(ID) FROM `b_active_accounts` WHERE ACCT_COE IN ('EMP') and ACCT_CLIENT NOT IN ('1266', '1272', '1359', '1362', '1573', '1403', '1405', '1454', '1485', '1487', '1521', '1546', '1560', '1582', '1586', '1647', '1648', '1649', '1658', '1674', '1700', '1756', '1770', '1832', '1875', '1919', '1976', '2038', '2097', '2101', '2118', '2124', '2178', '2168', '2316', '2412', '2459', '2653', '3147', '2232', '3000') and ACCT_AGENT not like '%RCALL%' and CAPCODE=0 group by POESCORE

Update `b_active_accounts` SET ACCT_AGENT=CONCAT('HOLDls-',ACCT_AGENT) WHERE ACCT_AGENT not like 'HOLDls%' and length(ACCT_AGENT)=4 and ACCT_COE!='EMP' and POESCORE<6 and CAPCODE=''

mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '7783' WHERE ACCT_COE = '5C' AND CAPCODE = '0' AND ACCT_AGENT != '7783' AND length( ACCT_AGENT ) = '4'");
echo '5C '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '4444' WHERE ACCT_COE = 'ATL' AND CAPCODE = '0' AND ACCT_AGENT != '4444' AND length( ACCT_AGENT ) = '4'");
echo 'ATL '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '9999' WHERE ACCT_COE = 'COL' AND CAPCODE = '0' AND ACCT_AGENT != '9999' AND length( ACCT_AGENT ) = '4'");
echo 'COL '.mysql_affected_rows().'<br/><br/>';
mysql_query("UPDATE `b_active_accounts` SET ACCT_AGENT = '8888' WHERE ACCT_COE = 'EBC' AND CAPCODE = '0' AND ACCT_AGENT != '8888' and ACCT_AGENT != '8887' AND length( ACCT_AGENT ) = '4'");
echo 'EBC '.mysql_affected_rows().'<br/><br/>';

UPDATE `b_active_accounts` SET ACCT_AGENT = '7783' WHERE ACCT_COE = '5C' AND CAPCODE = '0' AND ACCT_AGENT != '7783' AND length( ACCT_AGENT ) = '4';
UPDATE `b_active_accounts` SET ACCT_AGENT = '4444' WHERE ACCT_COE = 'ATL' AND CAPCODE = '0' AND ACCT_AGENT != '4444' AND length( ACCT_AGENT ) = '4';
UPDATE `b_active_accounts` SET ACCT_AGENT = '9999' WHERE ACCT_COE = 'COL' AND CAPCODE = '0' AND ACCT_AGENT != '9999' AND length( ACCT_AGENT ) = '4';
UPDATE `b_active_accounts` SET ACCT_AGENT = '8888' WHERE ACCT_COE = 'EBC' AND CAPCODE = '0' AND ACCT_AGENT != '8888' and ACCT_AGENT != '8887' AND length( ACCT_AGENT ) = '4';

SELECT POESCORE, count(ID) as atot FROM `b_active_accounts` where length( `ACCT_AGENT` ) ='4' and ACCT_COE='5C' and CAPCODE=0 group by POESCORE order by POESCORE DESC

SELECT POESCORE, count(ID) as atot FROM `b_active_accounts` where length( `ACCT_AGENT` ) ='4' and ACCT_COE='EBC' and ACCT_AGENT!='8887' group by POESCORE order by POESCORE DESC

SELECT ID, ADD_DATE, ACCT_CLIENT, ACCT_COE, ACCT_AGENT, ACCT_CASE, ACCT_DUE_DATE, ACCT_SSN, ACCT_FIRST_NAME, ACCT_LAST_NAME, ACCT_AD1, ACCT_AD2, ACCT_CITY, ACCT_ST, ACCT_ZIP, ACCT_DOB, ACCT_SOURCE, EMPL_NAME, EMPL_ADDR1, EMPL_ADDR2, EMPL_CITY, EMPL_ST, EMPL_ZIP, EMPL_HR_ADDR, EMPL_PHONE1_AREA, EMPL_PHONE1_NMBR, EMPL_PH_SOURCE, EMPL_FAX, EMPL_EMAIL, EMPL_TITLE, EMPL_CONTACT, EMPL_CONTACT_TITLE, CAPCODE, POEPRED as LAST_SEEN, CLOSED_ON, POESCORE FROM `b_closed_accounts` WHERE CLOSED_ON > '2019-01-'

SELECT ACCT_AGENT, UID, ACCT_ID, `EMPL_PHONE1_NMBR` , count( `ID` ) FROM `b_work_history` WHERE EMPL_PHONE1_NMBR != '' AND ADD_DATE LIKE '2019-03-%' AND CAPCODE = '2210' AND ACCT_COE != 'EMP' GROUP BY UID, ACCT_AGENT ORDER BY count( `ID` ) DESC limit 75

*/


$qw=mysql_query("SELECT UID, ADD_DATE, ACCT_AGENT, EMPL_PH_SOURCE FROM rnnginc_webapp.`b_work_history`
WHERE CAPCODE LIKE '1%'
AND ADD_DATE LIKE '2019-02-08%' and ACCT_COE='COL'");

while($sr=mysql_fetch_assoc($qw))
{
	echo implode(',',$sr).'<br/>';
}

echo '<br/><br/>';echo '<br/>CLOSED:<br/>';

$hits='';
$qw=mysql_query("SELECT UID, CLOSED_ON, ACCT_AGENT, EMPL_PH_SOURCE, LAST_WORKED FROM rnnginc_webapp.`b_closed_accounts` WHERE CAPCODE LIKE '1%' AND CLOSED_ON LIKE '2019-02-08%' and ACCT_COE='COL'");

while($sr=mysql_fetch_assoc($qw))
{
	echo implode(',',$sr).'<br/>';
}
echo '<br/><br/>';

die();	

$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='AUTO', ACCT_COE='' where CAPCODE=0 and ACCT_AGENT IN ('8888','9999', 'AUTO')");

$coegblankq=mysql_query("Select count(ID) as totals, POESCORE from rnnginc_webapp.b_active_accounts where CAPCODE=0 and ACCT_AGENT='AUTO' group by POESCORE order by POESCORE DESC");
		
while($coegblankr=mysql_fetch_assoc($coegblankq))
{
	$g50=$coegblankr['totals']*50/100;
	$g50=intval($g50);
	
	$g502=$coegblankr['totals']-$g50;
	
	$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='8888', ACCT_COE='EBC' where ACCT_AGENT='AUTO' and POESCORE='".$coegblankr['POESCORE']."' limit $g50");
	
	$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='9999', ACCT_COE='COL' where ACCT_AGENT='AUTO' and POESCORE='".$coegblankr['POESCORE']."' limit $g502");
	
	$_SESSION['coenotes'].='Auto Assign to Queue: COL:'.$g502.' - EBC:'.$g50.' - Score:'.$coegblankr['POESCORE'].' <br/>';
}
echo $_SESSION['coenotes'];		
die();



$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='AUTO', ACCT_COE='' where CAPCODE=0 and ACCT_AGENT IN ('8888','9999', 'AUTO')");

$coegblankq=mysql_query("Select count(ID) as totals, POESCORE from rnnginc_webapp.b_active_accounts where CAPCODE=0 and ACCT_AGENT='AUTO' group by POESCORE order by POESCORE DESC");
		
while($coegblankr=mysql_fetch_assoc($coegblankq))
{
	$g50=$coegblankr['totals']*50/100;
	$g50=intval($g50);
	
	$g502=$coegblankr['totals']-$g50;
	
	$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='8888', ACCT_COE='EBC' where ACCT_AGENT='AUTO' and POESCORE='".$coegblankr['POESCORE']."' limit $g50");
	
	$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='9999', ACCT_COE='COL' where ACCT_AGENT='AUTO' and POESCORE='".$coegblankr['POESCORE']."' limit $g502");
	
	$_SESSION['coenotes'].='Auto Assign to Queue: COL:'.$g502.' - EBC:'.$g50.' - Score:'.$coegblankr['POESCORE'].' <br/>';
}
echo $_SESSION['coenotes'];		
die();

$agentq=mysql_query("Select Count(Distinct ACCT_AGENT) as totalag, ACCT_COE from b_work_history where ADD_DATE Like '$lastdt%' and (ACCT_AGENT Like '3%' or ACCT_AGENT Like '4%' or ACCT_AGENT Like '5%' or ACCT_AGENT Like '6%') and  group by ACCT_COE");
$agentar=array();
while($agentrow=mysql_fetch_assoc($agentq))
{
	$agentar[$agentrow['ACCT_COE']]=$agentrow['totalag'];
}

die();


$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='AUTO', ACCT_COE='' where CAPCODE=0 and ACCT_AGENT IN ('8888','9999', 'AUTO')");

$coegblankq=mysql_query("Select count(ID) as totals, POESCORE from rnnginc_webapp.b_active_accounts where CAPCODE=0 and ACCT_AGENT='AUTO' group by POESCORE order by POESCORE DESC");
		
while($coegblankr=mysql_fetch_assoc($coegblankq))
{
	$g50=$coegblankr['totals']*50/100;
	$g50=intval($g50);
	
	$g502=$coegblankr['totals']-$g50;
	
	$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='8888', ACCT_COE='EBC' where ACCT_AGENT='AUTO' and POESCORE='".$coegblankr['POESCORE']."' limit $g50");
	
	$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='9999', ACCT_COE='COL' where ACCT_AGENT='AUTO' and POESCORE='".$coegblankr['POESCORE']."' limit $g502");
	
	$_SESSION['coenotes'].='Auto Assign to Queue: COL:'.$g502.' - EBC:'.$g50.' - Score:'.$coegblankr['POESCORE'].' <br/>';
}
echo $_SESSION['coenotes'];		
die();

$fullpath='1234.csv';
$chandle = fopen($fullpath, "r");$i=0;
while (($data = fgetcsv($chandle, 10000000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$upq=mysql_query("Update b_active_accounts SET POESCORE='".$data[2]."' where ID ='".$data[0]."'");
	}	$as=$as+mysql_affected_rows();
	$i++;
}
echo $as;
die();



$fullpath='123.csv';
$chandle = fopen($fullpath, "r");$i=0;
while (($data = fgetcsv($chandle, 10000000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$upq=mysql_query("Update b_active_accounts SET POESCORE='".$data[2]."' where ID ='".$data[0]."'");
	}	$as=$as+mysql_affected_rows();
	$i++;
}
echo $as;
die();




$sq=mysql_query("Select ID, ACCT_SSN, ACCT_CASE from rnnginc_webapp.b_closed_accounts where ACCT_SOURCE ='324' and POEPRED!='' order by ID DESC Limit 30000");
while($sr=mysql_fetch_assoc($sq))
{
	$cr=mysql_query("Select TloEmployerDateLastSeen from rnnginc_vendors.TU_Extended where rnn_id='".$sr['ACCT_CASE']."' and SSN='".$sr['ACCT_SSN']."'");
	if(mysql_num_rows($cr)>0)
	{
		$ssr=mysql_fetch_assoc($cr);
		$ssr['TloEmployerDateLastSeen']=substr($ssr['TloEmployerDateLastSeen'],-4);
		$upq=mysql_query("Update rnnginc_webapp.b_closed_accounts SET POEPRED='".$ssr['TloEmployerDateLastSeen']."' where ID='".$sr['ID']."'");
		$fn++;
	}
	else
	{
		$nf++;
	}
}
echo 'NotFound: '.$nf;
echo '<br/>Found: '.$fn;

echo '<br/>';

$fullpath='Scored_20190128.csv';
$chandle = fopen($fullpath, "r");$i=0;
while (($data = fgetcsv($chandle, 10000000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$upq=mysql_query("Update b_work_history SET POESCORE='".$data[2]."' where UID ='".$data[0]."'");
	}	
	$i++;
}
echo $as;
die();
$tdate=date("Y-m-d H:i:s");
echo $duedate=date('Ymd', strtotime($tdate.'+ 2 weeks'));
die();

$tdate=date("Y-m-d H:i:s");$closednotes='Unverified';
$sq=mysql_query("Select ID, ACCT_ID, ACCT_AGENT from b_active_accounts where CAPCODE >'2999' and LAST_WORKED like '2019-01-29%'");
while($sr=mysql_fetch_assoc($sq))
{
		$insq="Insert into b_closed_accounts (`UID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `CLOSED_ON`, `CLOSED_NOTES`, `EMP_DIR_CAPCODE`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `TOSS`, `PL_MATCH`, `WORK_COMMENTS`, POESCORE) SELECT `ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `LAST_WORKED` as `CLOSED_ON`, '$closednotes' as `CLOSED_NOTES`, `EMP_DIR_CAPCODE`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, 'dupes' as `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `TOSS`, `PL_MATCH`, `WORK_COMMENTS`, POESCORE FROM `b_active_accounts` WHERE ID='".$sr['ID']."'";
		
		mysql_query($insq);
		if(mysql_affected_rows()>0)
		{
			$dq=mysql_query("Delete from b_active_accounts where ID='".$sr['ID']."'");
			echo $insq;
			echo '<br/><br/>';
		}
}

die();

$fullpath='Scored_20190128.csv';
$chandle = fopen($fullpath, "r");$i=0;
while (($data = fgetcsv($chandle, 10000000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$upq=mysql_query("Update b_work_history SET POESCORE='".$data[2]."' where UID ='".$data[0]."'");
	}	
	$i++;
}
echo $as;
die();

$fullpath='Employer-EIN-Address.csv';
$chandle = fopen($fullpath, "r");$i=0;
while (($data = fgetcsv($chandle, 10000000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$buzzname  =  $data[1];			
		$empmatchname  = str_ireplace(array('  incorporation',' inc',' llc',' ltd',' llp',' s-corp',' corp',' corporation'),'',$buzzname);
		$empmatchname  = strtolower(preg_replace("/[^a-zA-Z0-9]+/", "", $empmatchname));
		
		$nsq=mysql_query("INSERT INTO `payroll_address`(`id`, `ein`, `emp_name`, `add1`, `add2`, `city`, `state`, `zip`, `emp_short`) VALUES ('', '".mysql_real_escape_string(trim($data[0]))."', '".mysql_real_escape_string(trim($data[1]))."', '".mysql_real_escape_string(trim($data[2]))."', '".mysql_real_escape_string(trim($data[3]))."', '".mysql_real_escape_string(trim($data[4]))."', '".mysql_real_escape_string(trim($data[5]))."', '".mysql_real_escape_string(trim($data[6]))."', '".mysql_real_escape_string(trim($empmatchname))."')");
	}
	$i++;
}

die();

require_once 'conn.php';
$fullpath='OtherProcesses_Combined_70160_70125.csv';
$chandle = fopen($fullpath, "r");
$i=0;
$act=0;$clo=0;
$rr=fopen('To_ROCKY_70160_70125_138.csv','w');

$coehead="ACCT_AGENT,ACCT_CLIENT1,ACCT_SOR_DATE,ACCT_SSNUM,ACCT_FIRST_NAME,ACCT_LAST_NAME,ACCT_AD1,ACCT_AD2,ACCT_CITY,ACCT_ST,ACCT_ZIP,ACCT_DOB,ACCT_ID,ACCT_SCORE,EMPL_NAME,EMPL_ADDR1,EMPL_ADDR2,EMPL_CITY,EMPL_ST,EMPL_ZIP,EMPL_PHONE1_AREA,EMPL_PHONE1_NMBR"."\n";
fwrite($rr,$coehead);
while (($data = fgetcsv($chandle, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$fsn = preg_replace("/[^0-9]/", "", $data[0]);
		$scheck=intval($fsn);
		$fssn=str_pad($scheck, 9, '0', STR_PAD_LEFT);
		$sq=mysql_query("SELECT `social_security_number`, `employer_name`, `employer_address_1`, `employer_address_2`, `employer_city`, `employer_state`, `employer_zip`, `employer_phone`, `employer_phone_1`, `corp_phone` FROM `a_intoRNN_EMPPH_completed` where social_security_number='$fssn' order by id desc limit 1");
		if(mysql_num_rows($sq)>0)
		{
			$coerow=mysql_fetch_assoc($sq);
			$dued='20190213';
			
			$dcheck=preg_replace("/[^0-9]+/", "", $data[8]);
			if(strlen($dcheck)>6)
			{
				$dob=date('Ymd', strtotime($data[8]));
			}
			else
			{
				$dob='';	
			}
			$phnnm=$coerow['employer_phone_1'];$phnar='';
			$coesq=mysql_query("Select * from rnnginc_webapp.a_intoRNN_POE where case_no='".$data[18]."' and social_security_number='$fssn'");
			$coesr=mysql_fetch_assoc($coesq);
			
			$insrow=''.','.$data[18].','.$dued.','.$fssn.','.$data[1].','.$data[2].','.$data[3].','.$data[4].','.$data[5].','.$data[6].','.$data[7].','.$dob.','.$coesr['id'].','.$coesr['Source_Code'].','.$coerow['employer_name'].','.$coerow['employer_address_1'].','.$coerow['employer_address_2'].','.$coerow['employer_city'].','.$coerow['employer_state'].','.$coerow['employer_zip'].','.$phnar.','.$phnnm."\n";

			//$row=implode(',',$data).','.$id."\n";
			fwrite($rr,$insrow);
		}		
	}
	$i++;
	
}
fclose($rr);
fclose($chandle);
die();


$iqq=mysql_query("SELECT ID, EMPL_PHONE1_AREA, EMPL_PHONE1_NMBR FROM `b_active_accounts` WHERE `ADD_FILE` Like '20190123-POEVER3-COMBINED-2492-RNN COE APP.csv' and EMPL_PHONE1_AREA!=''");
while($sr=mysql_fetch_assoc($iqq))
{
	$area='';$chkphn='';$phn='';
	$area=preg_replace("/[^0-9]+/", "", $sr['EMPL_PHONE1_AREA']);
	$phn=preg_replace("/[^0-9]+/", "", $sr['EMPL_PHONE1_NMBR']);
	
	$chkphn=$area.$phn;
	if($chkphn!='')
	{
		$chkphn=substr($chkphn,-10);
		$upq=mysql_query("Update b_active_accounts SET EMPL_PHONE1_AREA='', EMPL_PHONE1_NMBR='$chkphn' where ID ='".$sr['ID']."'");
		$as=$as+mysql_affected_rows();
	}	
}
echo $as;
die();

$tdate=date("Y-m-d H:i:s");$closednotes='ClosedActives';
$sq=mysql_query("Select ID, ACCT_ID, ACCT_AGENT from b_active_accounts where LENGTH(ACCT_AGENT)=4 and ACCT_COE!='EMP' and ACCT_AGENT NOT IN ('7701', '7702')");
while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Select CAPCODE from b_work_history where UID='".$sr['ID']."' and CAPCODE>2999 order by ID DESC limit 1");
	if(mysql_num_rows($qw)>0)
	{
		$qr=mysql_fetch_assoc($qw);
		$closednotes='ClosedActive-'.$qr['CAPCODE'];
		echo $sr['ACCT_AGENT'].' - ';
		echo $insq="Insert into b_closed_accounts (`UID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, `CLOSED_ON`, `CLOSED_NOTES`, `EMP_DIR_CAPCODE`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `TOSS`, `PL_MATCH`, `WORK_COMMENTS`) SELECT `ID`, `ADD_DATE`, `ADD_FILE`, `ADDED_BY`, `ACCT_CLIENT`, `ACCT_COE`, `ACCT_AGENT`, `ACCT_CASE`, `ACCT_DUE_DATE`, `ACCT_SSN`, `ACCT_FIRST_NAME`, `ACCT_LAST_NAME`, `ACCT_AD1`, `ACCT_AD2`, `ACCT_CITY`, `ACCT_ST`, `ACCT_ZIP`, `ACCT_DOB`, `ACCT_ID`, `ACCT_SOURCE`, `EMPL_NAME`, `EMPL_ADDR1`, `EMPL_ADDR2`, `EMPL_CITY`, `EMPL_ST`, `EMPL_ZIP`, `EMPL_HR_ADDR`, `EMPL_PHONE1_AREA`, `EMPL_PHONE1_NMBR`, `EMPL_PH_SOURCE`, `EMPL_FAX`, `EMPL_EMAIL`, `EMPL_TITLE`, `EMPL_CONTACT`, `EMPL_CONTACT_TITLE`, `CAPCODE`, `LAST_WORKED`, `LAST_COMMENTS`, '$tdate' as `CLOSED_ON`, '$closednotes' as `CLOSED_NOTES`, `EMP_DIR_CAPCODE`, `AEMPL_3RD_PARTY`, `AEMPL_3RD_PARTY_NUMBER`, `AEMPL_FAX`, `AEMPL_PHONE1`, 'dupes' as `AEMPL_PHONE1E`, `AEMPL_EMAIL`, `DIR_REF`, `COE_RULE`, `TOSS`, `PL_MATCH`, `WORK_COMMENTS` FROM `b_active_accounts` WHERE ID='".$sr['ID']."'";
		echo '<br/><br/>';
		mysql_query($insq);
		if(mysql_affected_rows()>0)
		{
			$dq=mysql_query("Delete from b_active_accounts where ID='".$sr['ID']."'");
		}
	}
}

die();

$fullpath='OtherProcesses_Combined_70160_70125.csv';
$chandle = fopen($fullpath, "r");
$i=0;
$act=0;$clo=0;
$rr=fopen('rrrsa.csv','w');
while (($data = fgetcsv($chandle, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$fsn = preg_replace("/[^0-9]/", "", $data[0]);
		$scheck=intval($fsn);
		$fssn=str_pad($scheck, 9, '0', STR_PAD_LEFT);
		
		$sq=mysql_query("Select id from a_intoRNN_POE where case_no='70160' and social_security_number='$fssn'");
		if(mysql_num_rows($sq)>0)
		{
			$row=implode(',',$data).','.$id."\n";
			fwrite($rr,$row);
		}		
	}
	$i++;
	
}
fclose($rr);
fclose($chandle);
die();


$tdate=date("Y-m-d H:i:s");$closednotes='OLD EMP Overflow';
$sq=mysql_query("Select UID, EMPL_FAX, EMPL_EMAIL, ACCT_AGENT, CUSTOM4 from b_powerlead_closed where CAPCODE='999'");
while($sr=mysql_fetch_assoc($sq))
{
	if($sr['EMPL_FAX']!='')
	{
		$pltxt=$sr['ACCT_AGENT'].'-'.'Fax-'.$sr['EMPL_FAX'];
	}
	else if($sr['EMPL_EMAIL']!='')
	{
		$pltxt=$sr['ACCT_AGENT'].'-'.'Email-'.$sr['EMPL_EMAIL'];
	}
	else
	{
		$pltxt=$sr['ACCT_AGENT'].'-'.'Phone-'.$sr['PHONE_CORP'];
	}
	
	//$pltxt=$sr['CUSTOM4'].'-'.'NoInfo-';
	
	$aq=mysql_query("Update b_active_accounts SET PL_MATCH='".$pltxt."' where ID='".$sr['UID']."'");
	$aaq=mysql_query("Update b_closed_accounts SET PL_MATCH='".$pltxt."' where UID='".$sr['UID']."'");
	
}

die();


$sq=mysql_query("Select ID, ACCT_ID from b_active_accounts where ACCT_AGENT='7783' and CAPCODE!='0'");
while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Select * from b_work_history where UID='".$sr['ID']."' and CAPCODE>0 order by ID DESC limit 1");
	if(mysql_num_rows($qw)>0)
	{
		$qr=mysql_fetch_assoc($qw);
		$upt=mysql_query("Update b_active_accounts SET ACCT_AGENT='".$qr['ACCT_AGENT']."' where ID='".$sr['ID']."'");
	}
}
die();

$duph=fopen('1newcoedupes.csv','w');

$sq=mysql_query("Select ID, ACCT_ID from b_active_accounts where CAPCODE='0' and ACCT_COE!='EMP' and LENGTH(ACCT_AGENT)='4' and ACCT_AGENT!='6565'");
while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Select * from b_work_history where UID='".$sr['ID']."' and CAPCODE>0 order by ID DESC limit 1");
	if(mysql_num_rows($qw)>0)
	{
		$qr=mysql_fetch_assoc($qw);
		$qr = array_map(
		function($qr) {
			$x=str_replace("'", "", $qr);
			$x=str_replace("\n", " ", $x);
			$x=str_replace("/", "RNNSLASH", $x);
			$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
			$x=str_replace("RNNSLASH", "/", $x);
			$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
			return str_replace(",", "", $x);
		},
		$qr
		);
		if($qr['CAPCODE']>2999 || $qr['CAPCODE']<2000)
		{
			$wh=implode(',',$qr);
			$row=$sr['ID'].','.$sr['ACCT_ID'].','.$wh."\n";
			fwrite($duph,$row);
			
			$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='6566' where ID ='".$sr['ID']."'");
		}
		else if ($qr['CAPCODE']!='2208' && $qr['CAPCODE']!='2209' && $qr['CAPCODE']!='2210')
		{
			$wh=implode(',',$qr);
			$row=$sr['ID'].','.$sr['ACCT_ID'].','.$wh."\n";
			fwrite($duph,$row);
			$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='6566' where ID ='".$sr['ID']."'");	
		}
	}
}

die();
$sq=mysql_query("Select ID, ACCT_ID from b_active_accounts where ACCT_AGENT='6565'");
while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Select * from b_work_history where UID='".$sr['ID']."' and CAPCODE>0 order by ID DESC limit 1");
	if(mysql_num_rows($qw)>0)
	{
		$qr=mysql_fetch_assoc($qw);
		$upt=mysql_query("Update b_active_accounts SET CAPCODE='".$qr['CAPCODE']."' where ID='".$sr['ID']."'");
	}
}
die();

$duph=fopen('newcoedupes.csv','w');
$sq=mysql_query("Select ID, ACCT_ID from b_active_accounts where CAPCODE='0' and ACCT_COE!='EMP' and LENGTH(ACCT_AGENT)='4' and ACCT_AGENT!='6565'");
while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Select * from b_work_history where UID='".$sr['ID']."' and CAPCODE>0 order by ID DESC limit 1");
	if(mysql_num_rows($qw)>0)
	{
		$qr=mysql_fetch_assoc($qw);
		$qr = array_map(
		function($qr) {
			$x=str_replace("'", "", $qr);
			$x=str_replace("\n", " ", $x);
			$x=str_replace("/", "RNNSLASH", $x);
			$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
			$x=str_replace("RNNSLASH", "/", $x);
			$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
			return str_replace(",", "", $x);
		},
		$qr
		);
		if($qr['CAPCODE']>2999 || $qr['CAPCODE']<2000)
		{
			$wh=implode(',',$qr);
			$row=$sr['ID'].','.$sr['ACCT_ID'].','.$wh."\n";
			fwrite($duph,$row);
			
			$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='6565' where ID ='".$sr['ID']."'");
		}
		else if ($qr['CAPCODE']!='2208' && $qr['CAPCODE']!='2209' && $qr['CAPCODE']!='2210')
		{
			$wh=implode(',',$qr);
			$row=$sr['ID'].','.$sr['ACCT_ID'].','.$wh."\n";
			fwrite($duph,$row);
			$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='6565' where ID ='".$sr['ID']."'");	
		}
	}
}

die();
$cfilename='20190111-POEVER1-COMBINED-2492-RNN COE APP.csv';$assignID='2492';
if($assignID='2492')
	{
		//$updatecentralS=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='7783', ACCT_COE='ATL' where ADD_FILE='$cfilename' and ACCT_CLIENT='2653'");// AUTO 5C Holding Queue RULE FOR Client CentralResearch
		
		$sql=mysql_query("Select * from rnnginc_webapp.rnnwusers where coerestrict!=''");
		while($sqr=mysql_fetch_assoc($sql))
		{
			if($sqr['coerestrict']=='ATL'){ $coeaid='4444'; }
			if($sqr['coerestrict']=='5C'){ $coeaid='7783'; }
			if($sqr['coerestrict']=='EBC'){ $coeaid='8888'; }
			if($sqr['coerestrict']=='COL'){ $coeaid='9999'; }
			
			if($sqr['coerestrict']=='ATL')
			{
				$upq="Update rnnginc_webapp.b_active_accounts SET ACCT_COE='ATL', ACCT_AGENT='$coeaid' where ACCT_CLIENT='".$sqr['id']."' and ACCT_COE NOT IN ('ATL','EMP')";
			}
			else if($sqr['coerestrict']=='5C')
			{
				$upq="Update rnnginc_webapp.b_active_accounts SET ACCT_COE='5C', ACCT_AGENT='$coeaid' where ACCT_CLIENT='".$sqr['id']."' and ACCT_COE != '5C'";
			}
			else
			{
				$upq="Update rnnginc_webapp.b_active_accounts SET ACCT_COE='".$sqr['coerestrict']."', ACCT_AGENT='$coeaid' where ACCT_CLIENT='".$sqr['id']."' and ACCT_COE!='".$sqr['coerestrict']."'";
			}
			mysql_query($upq);
		}
		
		//$lowperformq="UPDATE `b_active_accounts` SET ACCT_COE = 'ATL', ACCT_AGENT = '7782' WHERE ADD_FILE='$cfilename' and ACCT_SOURCE IN ('122','124','324') AND ACCT_COE != 'EMP' AND CAPCODE != '0'";
		//mysql_query($lowperformq);
		
		//Fix Default DOB
		$dobfixq="UPDATE `b_active_accounts` SET ACCT_DOB = '' WHERE ADD_FILE='$cfilename' and ACCT_DOB='19691231'";
		mysql_query($dobfixq);
	}
	
	if($autobalance='Yes')//EBC COL 50%
	{
		$coegblankq=mysql_query("Select count(ID) as totalsource, ACCT_SOURCE, ACCT_CASE from rnnginc_webapp.b_active_accounts where ADD_FILE='$cfilename' and ACCT_AGENT='' group by ACCT_SOURCE, ACCT_CASE");
		
		while($coegblankr=mysql_fetch_assoc($coegblankq))
		{
			$g50=$coegblankr['totalsource']/2;
			$ebval=intval($g50);
			
			$colval=$coegblankr['totalsource']-$ebval;
			
			$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='8888', ACCT_COE='EBC' where ADD_FILE='$cfilename' and ACCT_AGENT='' and ACCT_SOURCE ='".$coegblankr['ACCT_SOURCE']."' and ACCT_CASE='".$coegblankr['ACCT_CASE']."' limit $ebval");
			
			$upq=mysql_query("Update rnnginc_webapp.b_active_accounts SET ACCT_AGENT='9999', ACCT_COE='COL' where ADD_FILE='$cfilename' and ACCT_AGENT='' and ACCT_SOURCE ='".$coegblankr['ACCT_SOURCE']."' and ACCT_CASE='".$coegblankr['ACCT_CASE']."' limit $colval");
			
			$_SESSION['coenotes'].='Auto Assign to Queue: COL:'.$colval.' - EBC:'.$ebval;
		}
	}
	echo $_SESSION['coenotes']; 
die();
$duph=fopen('coedupes.csv','w');
$sq=mysql_query("Select ID, ACCT_ID from b_active_accounts where CAPCODE='0' and ACCT_COE!='EMP' and LENGTH(ACCT_AGENT)='4' and ACCT_AGENT!='6565'");
while($sr=mysql_fetch_assoc($sq))
{
	$qw=mysql_query("Select * from b_work_history where UID='".$sr['ID']."' and CAPCODE>0 order by ID DESC limit 1");
	if(mysql_num_rows($qw)>0)
	{
		$qr=mysql_fetch_assoc($qw);
		$qr = array_map(
		function($qr) {
			$x=str_replace("'", "", $qr);
			$x=str_replace("\n", " ", $x);
			$x=str_replace("/", "RNNSLASH", $x);
			$x=preg_replace("/[^a-zA-Z0-9\s_@.-]+/", "", $x);
			$x=str_replace("RNNSLASH", "/", $x);
			$x=preg_replace('/[ \t]+/', ' ', preg_replace('/[\r\n]+/', " ", $x));
			return str_replace(",", "", $x);
		},
		$qr
		);
		if($qr['CAPCODE']>2999 || $qr['CAPCODE']<2000)
		{
			$wh=implode(',',$qr);
			$row=$sr['ID'].','.$sr['ACCT_ID'].','.$wh."\n";
			fwrite($duph,$row);
			
			$upq=mysql_query("Update b_active_accounts SET ACCT_AGENT='6565' where ID ='".$sr['ID']."'");
		}
	}
}

die();
$fullpath='Scored_20190104.csv';
$chandle = fopen($fullpath, "r");
$i=0;
$act=0;$clo=0;
$rr=fopen('rrrsa.txt','w');
while (($data = fgetcsv($chandle, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$qq=mysql_query("Update b_active_accounts SET POESCORE='".$data[2]."', POEPRED='".$data[1]."' where ID='".$data[0]."'");
		$ed=mysql_affected_rows();
		if($ed==0)
		{
			$qq=mysql_query("Update b_closed_accounts SET POESCORE='".$data[2]."', POEPRED='".$data[1]."' where UID='".$data[0]."'");
		}
	}
	$i++;
	$a=$i.'-'.$data[0].'-'.$ed."\n";
	fwrite($rr,$a);
}
fclose($rr);
die();

$fullpath='test-1_result.csv';
$chandle = fopen($fullpath, "r");
$i=0;
$act=0;$clo=0;
$rr=fopen('test-1_ssn_result.csv','w');
while (($data = fgetcsv($chandle, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$ssn='';$ver='';$source='';$cap='';$date='';
		$ssn=str_pad($data[4], 9, '0', STR_PAD_LEFT);
		$qq=mysql_query("Select id, vendor, source_code, Final_Capture_Code, import_time from all_incoming_vpoe_hits where social_security_number='".$ssn."' order by id desc limit 1");
		if(mysql_num_rows($qq)>0)
		{
			$qr=mysql_fetch_assoc($qq);
			$source=$qr['source_code'];
			$cap=$qr['Final_Capture_Code'];
			$date=$qr['import_time'];
			
			if($qr['vendor']=='1947-BFrame')
			{
				$ver='InternalVerified';
			}
			else
			{
				$ver='ExternalVerified';	
			}
		}
		else
		{
			$qq=mysql_query("Select ACCT_SOURCE, CAPCODE, CLOSED_ON from b_closed_accounts where ACCT_SSN='".$ssn."' order by ID desc limit 1");
			if(mysql_num_rows($qq)>0)
			{
				$qr=mysql_fetch_assoc($qq);
				$source=$qr['ACCT_SOURCE'];
				$cap=$qr['CAPCODE'];
				$date=$qr['CLOSED_ON'];
				if(substr($cap,0,1)==1)
				{
					$ver='InternalVerified';
				}
				else if(substr($cap,0,1)==0)
				{
					$ver='Closed Not Worked/Sent to External Overflow';	
				}
				else
				{
					$ver='Unverified';
				}
			}
		}
	}
	$i++;
	$a=implode(',',$data).",".$ver.",".$source.",".$cap.",".$date."\n";
	fwrite($rr,$a);
}
fclose($rr);
fclose($chandle);

die();
$fullpath='test-1.csv';
$chandle = fopen($fullpath, "r");
$i=0;
$act=0;$clo=0;
$rr=fopen('test-1_result.csv','w');
while (($data = fgetcsv($chandle, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$ssn='';
		$qq=mysql_query("Select ACCT_SSN from b_closed_accounts where UID='".$data[0]."'");
		if(mysql_num_rows($qq)>0)
		{
			$qr=mysql_fetch_assoc($qq);
			$ssn=$qr['ACCT_SSN'];
		}
		else
		{
			$qq=mysql_query("Select ACCT_SSN from b_active_accounts where ID='".$data[0]."'");
			if(mysql_num_rows($qq)>0)
			{
				$qr=mysql_fetch_assoc($qq);	
				$ssn=$qr['ACCT_SSN'];
			}
		}
	}
	$i++;
	$a=implode(',',$data).",".$ssn."\n";
	fwrite($rr,$a);
}
fclose($rr);
fclose($chandle);

die();
$cq=mysql_query("Select * from b_powerlead_active");
while($cr=mysql_fetch_assoc($cq))
{
	$cs=mysql_query("Select * from b_closed_accounts where UID='".$cr['UID']."'");	
	$csr=mysql_fetch_assoc($cs);
	$upq=mysql_query("Update b_powerlead_active SET ACCT_FNAME='".$csr['ACCT_FIRST_NAME']."', ACCT_LNAME='".$csr['ACCT_LAST_NAME']."', ACCT_CITY='".$csr['ACCT_CITY']."', ACCT_ST='".$csr['ACCT_ST']."', ACCT_ZIP='".$csr['ACCT_ZIP']."', ACCT_DOB='".$csr['ACCT_DOB']."', ACCT_SOURCE='".$csr['ACCT_SOURCE']."', EMPL_NAME='', PHONE_CORP='', ADDR_CORP='', ADDR_LOC1='', ADDR_LOC2='' where ID='".$cr['ID']."'");
}
		

die();
$fullpath='poescore.csv';
$chandle = fopen($fullpath, "r");
$i=0;
$act=0;$clo=0;
$rr=fopen('rrrsa.txt','w');
while (($data = fgetcsv($chandle, 100000, ",")) !== FALSE) 
{
	if($i>0)
	{
		$qq=mysql_query("Update b_active_accounts SET POESCORE='".$data[1]."', POEPRED='".$data[2]."' where ID='".$data[0]."'");
		$ed=mysql_affected_rows();
	}
	$i++;
	$a=$i.'-'.$data[0].'-'.$ed."\n";
	fwrite($rr,$a);
}
fclose($rr);


die();
$q="SELECT *
FROM `b_work_history`
WHERE `ACCT_AGENT` ='Admin-1854'";
$q=mysql_query($q);
while($r=mysql_fetch_assoc($q))
{
	$cq=mysql_query("Select ACCT_AGENT, ACCT_COE from b_closed_accounts where UID='".$r['UID']."'");
	if(mysql_num_rows($cq)>0)
	{
		$cr=mysql_fetch_assoc($cq);
		$upq="Update b_work_history SET ACCT_AGENT='".$cr['ACCT_AGENT']."', ACCT_COE='".$cr['ACCT_COE']."', EMPL_PH_SOURCE='Admin-1854' where ID='".$r['ID']."'";
		mysql_query($upq);
		echo $r['UID'].'|||'.$cr['ACCT_AGENT'].'|||'.$cr['ACCT_COE']."<br/>";
	}
	else
	{
		echo $r['UID'].'|||NOTFOUND'."<br/>";
	}
}

die();

?>