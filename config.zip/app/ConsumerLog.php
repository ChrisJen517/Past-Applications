<?php

namespace App;

use App\Traits\CompanyIDTrait;
use Illuminate\Database\Eloquent\Model;

class ConsumerLog extends Model
{
    protected $fillable = [
        'id',
        'company_id',
        'user_id',
        'consumer_id',
        'log_message',
        'created_at',
        'updated_at',
    ];

    public function consumer()
    {
        return $this->belongsTo('App\Consumer', 'consumer_id', 'id');
    }
}