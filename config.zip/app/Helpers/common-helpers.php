<?php

if (!function_exists('createTemplateContent')) {
    function createTemplateContent($content, $consumer, $date = null, $campaign = null)
    {
        $createdContent = strtr($content, [
            '[First Name]' => $consumer->first_name,
            '[Last Name]' => $consumer->last_name,
            '[Account Number]' => $consumer->account_number,
            '[Master Company Name]' => $consumer->company->company_name,
            '[Sub Client 1 Name]' => $consumer->getActualSubclient1Name(),
            '[Sub Client 2 Name]' => $consumer->getActualSubclient2Name(),
//            '[Loan Originator Name]' => $company->name,
            '[Account Balance]' => number_format($consumer->current_balance, 2),
            '[Payment Set up Discount %]' => number_format($consumer->actualPSD(), 2) . '%',
            '[Payment Set up Discount Amount]' => number_format($consumer->actualPSDamount(), 2),
            '[Pay in Full Discount %]' => number_format($consumer->actualPIF(), 2) . '%',
            '[Pay in Full Discount Amount]' => number_format($consumer->actualPIFamount(), 2),
            '[You Negotiate Link]' => $consumer->invitation_link . ($campaign ? "/".$campaign->id : ""),
            '[Pass Through 1]' => $consumer->pass_through1,
            '[Pass Through 2]' => $consumer->pass_through2,
            '[Pass Through 3]' => $consumer->pass_through3,
            '[Pass Through 4]' => $consumer->pass_through4,
            '[Pass Through 5]' => $consumer->pass_through5,
            '[Date]' => $date,
            '[Current creditor name]' => $consumer->company->company_name,
            '[Current creditor account number]' => $consumer->account_number,
            '[Original creditor name]' => $consumer->getMasterName(), 
            '[Original creditor account number]' => $consumer->account_number, 
            '[Master name]' => $consumer->company->company_name, 
            '[Master account number]' => $consumer->account_number, 
        ]);
        return $createdContent;
    }
}

if(!function_exists('decodeBase64')){
    function decodeBase64($content, $company, $name = "customTemplate", $path = 'public/assets/images/emailTemplate/'){
        //finds all cases of base 64
        preg_match_all('@src="([^"]+)"@', $content, $matches);

        //makes sure the filepathExists
        if (!file_exists(public_path($path.$company))) {
            mkdir(public_path($path.$company), 0777, true);
        }

        //takes each instance of the base 64 and replaces it
        foreach($matches[0] as $key => $base64_string){
            $fileName = $path.$company.'/'.str_replace(" ", "_", $name).'_'.date('Y_m_d_H_i_s').'_'.$key.'.jpg';
            if(base64_to_jpeg($base64_string, public_path($fileName))){
                if(isset($_SERVER['HTTPS'] )) 
                    $http = 'https';
                else
                    $http = 'http';
                $content = str_replace($base64_string, ' style="display:block" alt="'.str_replace(" ", "_", $name).$key.'" title="'.str_replace(" ", "_", $name).$key.'" src="'.$http.'://'.$_SERVER['HTTP_HOST'].'/'.$fileName.'"', $content);
            }
        }
        return $content;
    }
}

if (!function_exists('base64_to_jpeg')) {
    function base64_to_jpeg($base64_string, $output_file) {
        // split the string on commas
        // $data[ 0 ] == "data:image/png;base64"
        // $data[ 1 ] == <actual base64 string>
        $data = explode( ',', $base64_string );

        //checks the file is base 64
        if(strpos($data[0], 'base64') == false && strpos($data[0], 'data:image') == false)
            return false;

        // open the output file for writing
        $ifp = fopen( $output_file, 'w+'); 

        // we could add validation here with ensuring count( $data ) > 1
        //fwrite( $ifp, base64_decode( $data[ 1 ] ) );

        $decoded = base64_decode( $data[ 1 ] );
        fwrite( $ifp,  $decoded);

        // clean up the file resource
        fclose( $ifp ); 

        return true; 
    }
}

if (!function_exists('formatAmount')) {
    function formatAmount($amount, $currency = null, $toDecimal = 2)
    {
        if(!empty(auth()->user()->company->country) && $currency == null)
            $currency = getCurrencySymbol(auth()->user()->company->country ??'');
        return $currency . number_format($amount, $toDecimal);
    }
}

if (!function_exists('getCurrencySymbol')) {
    function getCurrencySymbol($country = "United States"){
        if(in_array($country, ["United States", "Canada"]))
            return "$";
        elseif(in_array($country, ["Akrotiri", "Dhekelia", "Andorra", "Austria", "Belgium", "Cyprus", "Estonia", "Finland", "France", "Germany", "Greece", "Ireland", "Italy", "Kosovo", 
            "Latvia", "Lithuania", "Luxembourg", "Malta", "Monaco", "Montenegro", "Netherlands", "Portugal", "San-Marino", "Slovakia", "Slovenia", "Spain", "Vatican"]))
            return "€"; 

        return "$";
    }
}
