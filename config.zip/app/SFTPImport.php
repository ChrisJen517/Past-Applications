<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SFTPImport extends Model
{
    protected $table = 'sftp_import_settings';

}
