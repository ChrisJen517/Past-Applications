<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ImportSettings extends Model
{
   protected $table = "sftp_import_settings";
}
