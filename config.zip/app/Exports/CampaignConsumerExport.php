<?php

namespace App\Exports;

use App\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CampaignConsumerExport implements FromCollection, WithHeadings
{
    private $data;

    public function __construct($data)
    {
        $this->data = $data;     //Inject data
    }

    public function headings(): array
    {
        return ['account_number','first_name', 'last_name', 'gender', 'address1', 'address2', 'city', 'state', 'zip', 'sub_client1_id', 'sub_client1_name', 'sub_client2_id', 'sub_client2_name', 'mobile1', 'mobile2', 'mobile3', 'land1', 'land2', 'land3', 'email1', 'email2', 'email3', 'invitation_link'];
    }

    public function collection()
    {
        return collect($this->data);
    }
}