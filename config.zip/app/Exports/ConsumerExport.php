<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class ConsumerExport implements FromCollection, WithHeadings
{
    private $consumers;

    public function __construct($consumers)
    {
        $this->consumers = $consumers;
    }

    public function headings(): array
    {
        return ['First Name', 'Last Name', 'Gender', 'Email', 'Mobile', 'Sub Client1 ID', 'Sub Client2 ID', 'Account No', 'Current Balance', 'Failed Reason'];
    }

    public function collection()
    {
        return $this->consumers;
    }
}
