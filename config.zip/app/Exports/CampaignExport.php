<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class CampaignExport implements FromCollection, WithHeadings
{
    private $campaigns;

    public function __construct($campaigns)
    {
        $this->campaigns = $campaigns;
    }

    public function headings(): array
    {
        return [
            "Sent On",
            "Type",
            "Template Name",
            "Group Name",
            "Subject Line",
            "Total Sent",
            "Total Delivered",
            "% Delivered",
            "% Clicked Link",
            "% Entered PII",
            "PIF %",
            "PPL %",
            "Sent Custom Offer %"
        ];
    }

    public function collection()
    {
        return $this->campaigns;
    }
}