<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class APIHistory extends Model
{
    protected $table = 'api_histories';

    protected $fillable = [
        'company_id', 'total_uploaded', 'accounts_successful', 'accounts_failed', 'accounts_processed',
        'type', 'status', 'failed_list'
    ];
}