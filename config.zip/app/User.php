<?php

namespace App;

use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Notifications\Notifiable;
use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Spatie\Permission\Traits\HasRoles;
use Illuminate\Support\Facades\Hash;

class User extends Authenticatable implements MustVerifyEmail
{
    use Notifiable, HasRoles, SoftDeletes;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'phone_no', 'subclient_id','rnn_user_type'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /*public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }*/

    public function getUserTypeAttribute()
    {
        if ($this->subclient_id == null) {
            return 'company';
        } else {
            return $this->subclient->subclient_type;
        }
    }

    public function company()
    {
        return $this->belongsTo('App\Company');
    }

    public function subclient()
    {
        return $this->belongsTo('App\Subclient')->withDefault();
    }

    public function blockedStatus()
    {
        return $this->blocked_at == null ? 'unblocked' : 'blocked';
    }

    public function setUserDetails($name, $phone_no)
    {
        $this->name = $name;
        $this->phone_no = $phone_no;
        $this->save();
    }

    public function parentCompany()
    {
        $company = null;
        if ($this->subclient_id != null) {
            $company = $this->subclient;
        } else {
            $company = $this->company;
        }
        return $company;
    }

    public function registerCompany($company)
    {
        $this->company_id = $company->id;
        $this->save();
    }

    public function isCompanyUser()
    {
        return $this->user_type == 'company';
    }

    public function isSubclient1User()
    {
        return strtolower($this->user_type) == 'subclient1';
    }

    public function isSubclient2User()
    {
        return strtolower($this->user_type) == 'subclient2';
    }

}
