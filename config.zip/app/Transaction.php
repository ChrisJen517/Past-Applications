<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Transaction extends Model
{
   protected $fillable = ['transaction_id', 'consumer_login_id', 'transaction_type', 'consumer_id', 'company_id',
							'payment_profile_id','status','gateway_respnse_raw','status','status_code','amount',
							'flat_transaction_charges','rnn_share','company_share','subclient1_share','	subclient2_share'
							,'payment_mode','	last4digit', 'sub_client1_id', 'sub_client2_id', 'processing_charges',
                            'rnn_invoice_id'
					  	];

	protected $appends = ['rnn_share_amount'];

	public function consumer()
    {
        return $this->belongsTo('App\Consumer', 'consumer_id', 'id');
    }

    public function getRnnShareAmountAttribute()
    {
    	return $this->rnn_share;
    }
}
