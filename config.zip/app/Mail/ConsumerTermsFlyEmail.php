<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ConsumerTermsFlyEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    private $consumer;

    public function __construct($consumer)
    {
        $this->consumer = $consumer;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this
            ->from($this->consumer->from_details['from_email'], $this->consumer->from_details['from_name'])
            ->view('yn.emails.consumer-terms-fly', ['consumer' => $this->consumer]);
    }
}
