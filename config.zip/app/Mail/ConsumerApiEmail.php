<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ConsumerApiEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $company, $errorList, $type, $processed, $failed, $time;

    public function __construct($company, $errorList, $type, $processed, $failed, $time)
    {
        $this->company = $company;
        $this->errorList = $errorList;
        $this->type = $type;
        $this->processed = $processed;
        $this->failed = $failed;
        $this->time = $time;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('info@younegotiate.com', 'YouNegotiate')->subject('Consumer API Results')->view('yn.emails.consumer-api')->with(['company' => $this->company, 'errorList' => $this->errorList, 'type' => $this->type, 'processed' => $this->processed, 'failed' => $this->failed, 'time' => $this->time]);
    }
}