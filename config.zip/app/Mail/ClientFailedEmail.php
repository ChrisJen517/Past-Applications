<?php

namespace App\Mail;

use App\Consumer;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ClientFailedEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    private $consumer, $tid;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($consumer, $tid)
    {
        $this->consumer = Consumer::find($consumer->id);
        $this->consumer->amount = $consumer->amount;
        $this->consumer->processing_charges = $consumer->processing_charges;
        $this->tid = $tid;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject("YouNegotiate: Payment Failed! Accoun# " . $this->consumer->account_number)
            ->from($this->consumer->from_details['from_email'], $this->consumer->from_details['from_name'])
            ->view('yn.emails.client_failed', ['consumer' => $this->consumer, 'tid' => $this->tid]);
    }
}
