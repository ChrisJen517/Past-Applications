<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Consumer;

class SendPaymentProfileMail extends Mailable
{
    use Queueable, SerializesModels;

    public $scheduleTransaction;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($scheduleTransaction)
    {
        $this->scheduleTransaction = $scheduleTransaction;
        $this->consumer = Consumer::find($scheduleTransaction->consumer_id);
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject("[Action Needed] Reminder: Please Complete Your Payment Profie")
            ->from($this->consumer->from_details['from_email'], $this->consumer->from_details['from_name'])
            ->view('yn.emails.sendPaymentProfile', ['consumer' => $this->consumer, 'scheduleTransaction' => $this->scheduleTransaction]);
        
    }
}
