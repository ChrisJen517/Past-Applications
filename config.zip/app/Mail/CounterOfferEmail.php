<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CounterOfferEmail extends Mailable
{
    use Queueable, SerializesModels;

    public $consumer;

    public function __construct($consumer)
    {
        $this->consumer = $consumer;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject(" Action Needed! We Have a Counter Offer from Your Creditor!")
            ->from($this->consumer->from_details['from_email'], $this->consumer->from_details['from_name'])
            ->view('yn.emails.counter-offer', ['consumer' => $this->consumer]);
    }
}
