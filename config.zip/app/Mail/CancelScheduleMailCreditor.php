<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CancelScheduleMailCreditor extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    public $scheduledTransaction;

    public function __construct($scheduledTransaction)
    {
        $this->scheduledTransaction = $scheduledTransaction;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $account_number = $this->scheduledTransaction->consumer->account_number;
        $schedule_date = $this->scheduledTransaction->schedule_date;

        return $this->subject("Schedule Cancelled for Account" . $account_number . " for The date of " . $schedule_date)
            ->from('info@younegotiate.com', 'YouNegotiate')
            ->view('yn.emails.cancelScheduleMailConsumer', ['scheduledTransaction' => $this->scheduledTransaction]);
    }
}
