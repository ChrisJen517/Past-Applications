<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ConsumerJoinedEmail extends Mailable
{
    use Queueable, SerializesModels;

    private $consumer, $password;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($consumer, $password)
    {
        $this->consumer = $consumer;
        $this->password = $password;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('You have joined successfully to YouNegotiate')
            ->from('info@younegotiate.com', 'YouNegotiate')
            ->view('yn.emails.consumer-joined', ['consumer' => $this->consumer, 'password' => $this->password]);
    }
}
