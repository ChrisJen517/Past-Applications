<?php

namespace App\Mail;

use App\Consumer;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class SuccessClientEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    private $consumer, $tid;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($consumer, $tid)
    {
        $this->consumer = $consumer;
        $this->tid = $tid;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $actualConsumer = Consumer::find($this->consumer->id);
        $this->consumer->account_number = $actualConsumer->account_number;
        return $this->subject("YouNegotiate: Payment Success Account# " . $this->consumer->account_number)
            ->from($actualConsumer->from_details['from_email'], $actualConsumer->from_details['from_name'])
            ->view('yn.emails.client_success_payment', ['consumer' => $this->consumer, 'tid' => $this->tid]);
    }
}
