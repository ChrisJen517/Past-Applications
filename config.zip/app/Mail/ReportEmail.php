<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Excel;
use App\Export\ReportExport;
class ReportEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    private $attachment, $name;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($attachment, $name)
    {
        $this->attachment = $attachment;
        $this->name = $name;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject("YouNegotiate:  Report ")->view('yn.emails.report')->
            from('info@younegotiate.com', 'YouNegotiate')->attach(Excel::download(
                                                new ReportExport( $this->attachment), 
                                                $this->name
                                                )->getFile(), ['as' => $this->name]);
    }
}
