<?php

namespace App\Mail;

use App\Consumer;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CompanyFailedEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    private $consumer,$tid;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($consumer,$tid)
    {
        $this->consumer = Consumer::find($consumer->id);
        $this->consumer->amount = $consumer->amount;
        $this->consumer->processing_charges = $consumer->processing_charges;
        $this->tid =$tid;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject("YouNegotiate: Payment Failed! Accoun#".$this->consumer->account_number)
            ->from('info@younegotiate.com', 'YouNegotiate')
            ->view('yn.emails.company_failed', ['consumer' => $this->consumer,'tid'=>$this->tid]);
    }
}
