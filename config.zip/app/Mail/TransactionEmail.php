<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class TransactionEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    public $tstatus, $rnnTransaction, $transactionAmount, $pdf, $rnn_id, $credit;

    public function __construct($tstatus, $rnnTransaction, $transactionAmount, $pdf, $rnn_id, $credit)
    {
        $this->tstatus = $tstatus;
        $this->rnnTransaction = $rnnTransaction;
        $this->transactionAmount = $transactionAmount;
        $this->pdf = $pdf;
        $this->rnn_id = $rnn_id;
        $this->credit = $credit;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $tstatus = $this->tstatus;
        $rnnTransaction = $this->rnnTransaction;
        $transactionAmount = $this->transactionAmount;
        $pdf = $this->pdf;
        $rnn_id = $this->rnn_id;
        $credit = $this->credit;

        $start_date = date('Y-m-d', strtotime($rnnTransaction->billing_cycle_start));
        $end_date = date('Y-m-d', strtotime($rnnTransaction->billing_cycle_end));

        $address = 'info@younegotiate.com';
        $name = 'YouNegotiate';

        return $this->view('yn.emails.rnn-transaction', compact('tstatus', 'rnnTransaction', 'transactionAmount', 'rnn_id', 'credit'))->from($address, $name)->attachData($pdf->output(), 'RNN_YN_Invoice_'.$rnnTransaction->rnn_invoice_id.'.pdf')->subject('RNN - YouNegotiate Invoice for Period '.$rnnTransaction->billing_cycle_start.' - '.$rnnTransaction->billing_cycle_end);
    }
}
