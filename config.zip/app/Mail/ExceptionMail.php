<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ExceptionMail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    protected $ex,$source;

    public function __construct($ex,$source)
    {
         $this->ex = $ex;
         $this->source = $source;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
       return $this->subject("YouNegotiate: Exception Mail#")
            ->from('info@younegotiate.com', 'YouNegotiate')
            ->view('yn.emails.exception', ['ex' => $this->ex,'source'=>$this->source]);
    }
}
