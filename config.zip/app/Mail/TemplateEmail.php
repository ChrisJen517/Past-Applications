<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TemplateEmail extends Mailable
{
    use Queueable, SerializesModels;

    protected $content, $consumer, $company;
    public $subject;

    public function __construct($content, $subject, $consumer, $company, $campaign = null)
    {
        $this->subject = $subject;
        $this->consumer = $consumer;
        $this->company = $company;
        $this->content = createTemplateContent($content, $consumer, null, $campaign);
        /*$this->callbacks[] = (function ($message) use ($consumer_id, $company_id) {
            $message->getHeaders()->addTextHeader('consumer', $consumer_id);
            $message->getHeaders()->addTextHeader('company', $company_id);
        });*/
    }

    public function build()
    {
        return $this->subject($this->subject)
            ->from($this->consumer->from_details['from_email'], $this->consumer->from_details['from_name'])
            ->view('yn.emails.template', ['body' => $this->content, 'consumer' => $this->consumer]);
    }
}