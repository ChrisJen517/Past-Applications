<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CancelScheduleMailConsumer extends Mailable
{
    use Queueable, SerializesModels;

    public $scheduledTransaction;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($scheduledTransaction)
    {
        $this->scheduledTransaction = $scheduledTransaction;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        $account_number = $this->scheduledTransaction->consumer->account_number;
        $schedule_date = $this->scheduledTransaction->schedule_date;
        $consumer = $this->scheduledTransaction->consumer;

        return $this->subject("Schedule Cancelled for Account" . $account_number . " for The date of " . $schedule_date)
            ->from($consumer->company->account_contact_email, $consumer->company->name)
            ->view('yn.emails.cancelScheduleMailConsumer', ['scheduledTransaction' => $this->scheduledTransaction, 'consumer' => $consumer]);
    }
}
