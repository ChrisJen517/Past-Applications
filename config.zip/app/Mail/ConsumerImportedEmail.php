<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ConsumerImportedEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $fuh, $user, $errorList;

    public function __construct($user, $fuh, $errorList)
    {
        $this->fuh = $fuh;
        $this->user = $user;
        $this->errorList = $errorList;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('info@younegotiate.com', 'YouNegotiate')->subject('Consumer Imported Successfully')->view('yn.emails.consumer-imported')->with(['user' => $this->user, 'fuh' => $this->fuh, 'errorList' => $this->errorList]);
    }
}
