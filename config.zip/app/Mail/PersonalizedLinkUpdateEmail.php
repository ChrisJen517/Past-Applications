<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PersonalizedLinkUpdateEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */

    private $old_link, $new_link, $company;

    public function __construct($old_link, $new_link, $company)
    {
        $this->old_link = $old_link;
        $this->new_link = $new_link;
        $this->company = $company;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->view('yn.emails.personalized-link-update',
            ['old_link' => $this->old_link, 'new_link' => $this->new_link, 'company' => $this->company]);
    }
}
