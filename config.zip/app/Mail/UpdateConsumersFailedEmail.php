<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class UpdateConsumersFailedEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $user, $errorList, $fileUploadHistory;

    public function __construct($user, $errorList, $fileUploadHistory)
    {
        $this->user = $user;
        $this->errorList = $errorList;
        $this->fileUploadHistory = $fileUploadHistory;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('info@younegotiate.com', 'YouNegotiate')->subject('Updated Consumers Failed Email')->view('yn.emails.consumers-updated')->with(['user' => $this->user, 'fileUploadHistory' => $this->fileUploadHistory, 'errorList' => $this->errorList]);
    }
}
