<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Consumer;

class SettledEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    private $consumer, $amount;
    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($consumer, $amount)
    {
        $this->consumer =  Consumer::find($consumer->id);
        $this->amount = $amount;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject("YouNegotiate: Account Settled Forever! Account# " . $this->consumer->account_number)
            ->from($this->consumer->from_details['from_email'], $this->consumer->from_details['from_name'])
            ->view('yn.emails.Settled', ['consumer' => $this->consumer, 'amount' => $this->amount]);
    }
}
