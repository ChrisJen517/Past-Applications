<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class ConsumerUnmergedHeaderEmail extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public $user, $unmarged_header;

    public function __construct($user, $unmarged_header)
    {
        $this->user = $user; 
        $this->unmarged_header = $unmarged_header;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->from('info@younegotiate.com', 'YouNegotiate')->subject('Error Mapped Headers')->view('yn.emails.error-mapped-headers')->with(['user' => $this->user, 'unmarged_header' => $this->unmarged_header]);
    }
}
