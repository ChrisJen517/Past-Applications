<?php

namespace App\Traits;

use App\Company;
use App\Subclient;
use DB;

trait CreditorReportTrait
{
    private $currency = "$";

    //calls the function to get the reports information of the same name
    public function getCreditorReport($type, $company_id, $subclient, $from, $to, $group){
        $this->currency = getCurrencySymbol(Company::where('id', $company_id)->first()->country ?? "United States");

        switch($type){
            case "Transaction_History":
                return $this->transactionHistoryReport($company_id, $subclient, $from, $to, $group);
            case "Reconciliation_Report":
                return $this->reconciliationReport($company_id, $subclient, $from, $to, $group);
            case "Scheduled_Transactions":
                return $this->scheduledTransactionsReport($company_id, $subclient, $from, $to, $group);
            case "Customer_Login":
                return $this->customerLoginReport($company_id, $subclient, $from, $to, $group);
            case "Customer_Status":
                return $this->customerStatusReport($company_id, $subclient, $group);
            case "Customer_Current_Balance":
                return $this->customerCurrentBalanceReport($company_id, $subclient, $group);
            default:
                return [];
        }
    }

    private function transactionHistoryReport($company_id, $subclient, $from, $to, $group){
        $consumers = DB::table('consumers')
                ->join('transactions', 'consumers.id', '=', 'transactions.consumer_id')
                ->join('companies', 'companies.id', '=', 'consumers.company_id')
                ->whereBetween(DB::raw('DATE(transactions.created_at)'), [$from, $to])
                ->when($group != 'all', function($query) use ($group){
                    return $this->getGroup($query, $group);
                })->when($company_id != 'all', function($query) use ($company_id){
                    return $query->where('companies.id', $company_id);
                })->when($subclient != 'all', function($query) use ($subclient){
                    return $this->getSubclient($query, $subclient);
                })->selectRaw("
                    consumers.account_number,
                    consumers.first_name,
                    consumers.last_name,
                    CASE
                        WHEN consumers.status = 'payment_setup'
                            THEN 'Offer Accepted - Pending Payment Setup'
                        WHEN consumers.status = 'joined'
                            THEN 'Joined YouNegotiate'
                        WHEN consumers.status = 'uploaded'
                            THEN 'Not Joined Yet'
                        WHEN consumers.status = 'payment_accepted'
                            THEN 'Payment Plan In Place'
                        WHEN consumers.status = 'payment_declined'
                            THEN 'Payment Declined'
                        WHEN consumers.status = 'payment_failed'
                            THEN 'Have Failed Payment'
                        WHEN consumers.status = 'renegotiate'
                            THEN 'Re-Negotiating'
                        WHEN consumers.status = 'settled'
                            THEN 'Account Settled'
                        WHEN consumers.status = 'visited'
                            THEN 'Visited, SSN not Verified'
                        WHEN consumers.status = 'deactivated'
                            THEN 'Deactivated'
                        WHEN consumers.status = 'not_verified'
                            THEN 'SSN not Verified'
                    END AS consumer_status,
                    transactions.transaction_id, transactions.transaction_type,
                    DATE(transactions.created_at) date, TIME(transactions.created_at) time,
                    consumers.sub_client1_id, consumers.sub_client2_id,
                    transactions.status, transactions.amount,
                    consumers.pass_through1, consumers.pass_through2, consumers.pass_through3, consumers.pass_through4, consumers.pass_through5

                ")->orderby('transactions.created_at', 'DESC')->get();

        return $this->formatMoneyFields($consumers, ['amount']);
    }

    private function reconciliationReport($company_id, $subclient, $from, $to, $group){
        $consumers = DB::table('consumers')
            ->join('transactions', 'consumers.id', '=', 'transactions.consumer_id')
            ->join('companies', 'companies.id', '=', 'consumers.company_id')
            ->whereBetween(DB::raw('DATE(transactions.created_at)'), [$from, $to])
            ->when($group != 'all', function($query) use ($group){
                return $this->getGroup($query, $group);
            })->when($company_id != 'all', function($query) use ($company_id){
                return $query->where('companies.id', $company_id);
            })->when($subclient != 'all', function($query) use ($subclient){
                return $this->getSubclient($query, $subclient);
            })->selectRaw("
                transactions.transaction_id,
                transactions.transaction_type,
                DATE(transactions.created_at) date, TIME(transactions.created_at) time,
                transactions.status,
                transactions.amount,
                transactions.processing_charges,
                transactions.rnn_share,
                consumers.sub_client1_id, consumers.sub_client2_id
            ")->orderby('transactions.created_at', 'DESC')->get();
        
        return $this->formatMoneyFields($consumers, ['amount']);
    }

    private function scheduledTransactionsReport($company_id, $subclient, $from, $to, $group){
        $consumers = DB::table('consumers')
            ->join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
            ->join('companies', 'companies.id', '=', 'consumers.company_id')
            ->join('payment_profiles', 'payment_profiles.id', '=', 'schedule_transactions.payment_profile_id')
            ->whereBetween(DB::raw('DATE(schedule_transactions.schedule_date)'), [$from, $to])
            ->when($group != 'all', function($query) use ($group){
                return $this->getGroup($query, $group);
            })->when($company_id != 'all', function($query) use ($company_id){
                return $query->where('companies.id', $company_id);
            })->when($subclient != 'all', function($query) use ($subclient){
                return $this->getSubclient($query, $subclient);
            })->where('payment_complete', '0')
            ->selectRaw("
                consumers.account_number,
                consumers.first_name,
                consumers.last_name,
                DATE(schedule_transactions.schedule_date) payment_processing_date,
                consumers.sub_client1_id, consumers.sub_client2_id,
                schedule_transactions.amount,
                schedule_transactions.status,
                payment_profiles.method payment_profile_type,
                consumers.pass_through1, consumers.pass_through2, consumers.pass_through3, consumers.pass_through4, consumers.pass_through5
            ")->orderby('schedule_transactions.created_at', 'DESC')->get();

        return $this->formatMoneyFields($consumers, ['amount']);
    }

    private function customerLoginReport($company_id, $subclient, $from, $to, $group){
        $consumers = DB::table('consumers')
            ->join('consumer_activities', 'consumers.consumer_login_id', '=', 'consumer_activities.user_id')
            ->join('companies', 'companies.id', '=', 'consumers.company_id')
            ->when(!empty($from) && !empty($to), function($query) use ($from, $to){
                return $query->whereBetween(DB::raw('DATE(consumer_activities.created_at)'), [$from, $to]);
            })->when($group != 'all', function($query) use ($group){
                return $this->getGroup($query, $group);
            })->when($company_id != 'all', function($query) use ($company_id){
                return $query->where('companies.id', $company_id);
            })->when($subclient != 'all', function($query) use ($subclient){
                return $this->getSubclient($query, $subclient);
            })->selectRaw("
                consumers.account_number,
                DATE(consumer_activities.created_at) date,
                TIME(consumer_activities.created_at) time,
                consumers.first_name, consumers.middle_name,
                consumers.last_name,
                consumers.total_balance account_open_balance,
                consumers.current_balance,
                consumers.sub_client1_id, consumers.sub_client2_id,
                consumers.pass_through1, consumers.pass_through2, consumers.pass_through3,consumers.pass_through4, consumers.pass_through5
            ")->orderby('consumer_activities.created_at', 'DESC')->get();

        return $this->formatMoneyFields($consumers, ['account_open_balance', 'current_balance']);
    }

    private function customerStatusReport($company_id, $subclient, $group){
        $select = "consumers.status, consumers.first_name, consumers.last_name, consumers.total_balance account_open_balance, consumers.current_balance, ";
        return $this->conusumerReports($select, $company_id, $subclient, $group);
    }

    private function customerCurrentBalanceReport($company_id, $subclient, $group){
        $select = "consumers.total_balance account_open_balance, consumers.current_balance, consumers.first_name, consumers.last_name, consumers.status,";
        return $this->conusumerReports($select, $company_id, $subclient, $group);
    }

    private function conusumerReports($select,$company_id, $subclient, $group){
        $consumers = DB::table('consumers')
                ->join('companies', 'companies.id', '=', 'consumers.company_id')
                //->whereBetween(DB::raw('DATE(consumers.created_at)'), [$from, $to])
                ->when($group != 'all', function($query) use ($group){
                    return $this->getGroup($query, $group);
                })->when($company_id != 'all', function($query) use ($company_id){
                    return $query->where('companies.id', $company_id);
                })->when($subclient != 'all', function($query) use ($subclient){
                    return $this->getSubclient($query, $subclient);
                })->selectRaw("consumers.account_number, ".$select."
                    DATE('consumers.account_open_date') account_open_date, DATE('consumers.placement_date') placement_date, DATE('consumers.expiry_date') expiry_date,
                    consumers.sub_client1_id, consumers.sub_client2_id,
                    consumers.pass_through1, consumers.pass_through2, consumers.pass_through3, consumers.pass_through4, consumers.pass_through5
                ")->orderby('consumers.created_at', 'DESC')->get();

        //updates the status to a more readable name
        foreach($consumers as $consumer){
            switch($consumer->status){
                case "payment_setup":
                    $consumer->status = "Successfull Payment Setup";
                break;
                case "joined":
                    $consumer->status = "Joined but No Deal";
                break;
                case "uploaded":
                    $consumer->status = "Not Joined Yet";
                break;
                case "payment_accepted":
                    $consumer->status = "Payment Plan In Place";
                break;
                case "payment_declined":
                    $consumer->status = "Payment Declined";
                break;
                case "payment_failed":
                    $consumer->status = "Have Failed Payment";
                break;
                case "renegotiate":
                    $consumer->status = "Renegotiating";
                break;
                case "settled":
                    $consumer->status = "Paid in Full";
                break;
                case "visited":
                    $consumer->status = "Visited, SSN not Verified";
                break;
                case "deactivated":
                    $consumer->status = "Deactivated Account";
                break;
                case "not_verified":
                    $consumer->status = "SSN not Verified";
                break;
            }
        }
        return $this->formatMoneyFields($consumers, ['account_open_balance', 'current_balance']);
    }

    //gets the group name based on the information passed in
    private function getGroup($query, $group){
        switch($group){
            case "notjoin":
                return $query->where('consumers.status', 'uploaded');
            case "joinnodeal":
                return $query->where('consumers.status', 'joined');
            case "success":
                return $query->where('consumers.status', 'payment_setup');
            case "paidfull":
                return $query->where('consumers.status', 'settled');
            default:
                return $query->where('consumers.status', 'uploaded');
        }
    }

    //gets the subclient based on their type
    private function getSubclient($query, $subclient){
        $type = strtolower(Subclient::where('id', $subclient)->first()->subclient_type ?? '');
        if($type == "subclient1")
            return $query->where('consumers.sub_client1_id', $subclient);
        else
            return $query->where('consumers.sub_client2_id', $subclient);
    }

    //formats the money fields from the $connsumers, array $fields name of the fields to be formated
    private function formatMoneyFields($consumers, $fields){
        foreach($consumers as $consumer){
            foreach($fields as $field){
                $consumer->{$field} = formatAmount($consumer->{$field}, $this->currency);
            }
        }
        return $consumers;
    }
}