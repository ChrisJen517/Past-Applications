<?php


namespace App\Traits;


trait RepositoryTrait
{
    public function model()
    {
        return app()->make($this->model);
    }

    public function create($param)
    {
        return $this->model()::create($param);
    }

    public function get($key, $value, $with = [])
    {
        return $this->model()::with($with)->where($key, $value)->first();
    }

    public function getByID($id, $with = [])
    {
        return $this->model()->findOrFail($id);
    }

    public function update($identifier_key, $identifier_value, $params)
    {
        return $this->get($identifier_key, $identifier_value)->update($params);
    }

    public function delete($id)
    {
        return $this->get('id', $id)->delete();
    }

}
