<?php

namespace App\Traits;

use App\Campaign;
use App\CommunicationHistory;
use App\Company;
use App\Consumer;
use App\FileUploadHistory;
use App\PaymentProfile;
use App\RnnCommission;
use App\RnnTransaction;
use App\ScheduleTransaction;
use App\Subclient;
use App\Transaction;
use App\User;
use DB;


trait SuperAdminReportsTrait
{
    private $currency = "$";
    private $company_list = [];

    public function getSuperAdminReport($type, $company_id, $from, $to, $user_id = null){
        //gets the list of companies the user can see
        $this->company_list = $this->companyList($user_id);

        if($company_id != "all")
            $this->currency = getCurrencySymbol(Company::where('id', $company_id)->first()->country ?? "United States");

        switch($type){
            case 'Commission_Reporting_RNN':
                $return =  $this->CommissionReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Master Account Name", "Contract date", "RNN Client ID", "RNN Set up Collected", "RNN Rev Share % revenue", "RNN SMS Revenue", "RNN Email revenue", "RNN e-Letter Revenue", "Total Gross Revenue", "RNN Account Manager", "AM % commission ", "AM Commission Due", "RNN Sales Exec", "RNN SE Commission %", "SE Commission Due ", "Reseller/Agent Name", "Reseller % Commission on RNN Rev", "Reseller Commission Due", "YN fees %", "YN fees Due", "Net RNN Revenue", "% Gross Profit Margin"];
            break;
            case 'Accounting_Reconciliation':
                $return =  $this->ReconciliationReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Master Client name", "RNN Client ID", "RNN Rev Share Fee", "RNN SMS Revenue", "RNN Email Revenue", "RNN e-Letter Revenue", "RNN Total Gross Deposit ", "Master Payment Method", "Payment reference", "Date"];
            break;
            case 'Client_Profile':
                $return =  $this->ClientProfileReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Master Name","Date of contract","RNN % ","RNN per Email ","RNN per SMS","RNN eLetter","RNN Client ID","RNN Account Manager","Reseller/Agent","RNN Sales Exec","Pay Term (daily, weekly, monthly)","Pay Method (auto ACH, auto CC)","Current # of accounts in YN","Current Balances in YN","RNN gross revenue to date", "Total Consumer Payments Received", "Total Upcoming Transactions"];
            break;
            case 'Master_Client_Current_Snapshot':
                $return =  $this->MasterClientCurrentSnapshotReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Master name", 
                "YN total Accounts", "YN Tot. Account Balance", 
                "Unique SMS Sent",  "Unique SMS Sent %",  
                "SMS Delivered",  "SMS Delivered %", "SMS Delivered Balance",
                "Unique Email Sent",  "Unique Email Sent %", 
                "Email Delivered",  "Email Delivered %", "Email Delivered Balance",
                "Unique Accounts Clicked on Link",  "Unique Accounts Clicked on Link %", "Unique Accounts Clicked on Link Balance", 
                "Entered PII Data",  "Entered PII Data %",
                "PII Mismatch",  "PII Mismatch %", 
                "PIF", "PIF Balance", "PIF % of Bal",
                'Successfully Negotiate',  "%", 'Negotiate Bal',
                'PayProfile Set Up',  'PayProfile Set Up %', 'PayProfile Set Up Balance', 
            ];
            break;
            case 'Master_Client_Activity':
                $return =  $this->MasterClientActivityReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Master Name", "Contract date","RNN Sales Exec","RNN AM","Reseller Name","Gross consumer payments made to date","Last upload date","# of accounts uploaded","Last communication date","Type of communication","# of Consumers in Last Communication"];
            break;
            case 'Investor_Snapshot':
                $return =  $this->InvestorSnapshotReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Total Balances in YN", "Average Acct Bal", "# of consumer accounts in YN","# Creditor Client Accts","# Sub Accounts", "Total ($) Payments Made in YN","Total ($) Pay Plan Payments Set up","Countries transacting"];
            break;
            case 'Weekly_Exec_Email_Summary':
                $return =  $this->WeeklyExecEmailSummaryReport($company_id, $from, $to);
                $data = $return[0];
                $totals = $return[1];
                $headers = ["Name of Master Client"," # Accounts ","Total Balances","Total Comm Sent","Total Consumer Payments MTD","Total Consumer Payments YTD" , "RNN Revenue MTD", "RNN Revenue YTD"  ];
            break;
            default:
                $data =  [];
                $totals = [];
                $headers = [];
        }
        return [$data, $totals, $headers];
    }

    //needs to fill the YN_fees feilds
    public function CommissionReport($company_id, $from, $to){
        
        $companies = DB::table('companies')->selectRaw("companies.id, companies.company_name as Master_Name, companies.contract_date as Contract_date, 
            companies.rnn_id as RNN_Client_ID, 
            0 as RNN_Set_Up_Collected,
            0 as RNN_Rev_Share_Revenue,
            0 as SMS_Revenue,
            0 as Email_Revenue,
            0 as eLetter_Revenue,
            0 as Total_Gross_Revenue,
            companies.send_commission, 
            '' as RNN_AM, 0 as AM_Commission, 0 as AM_Commission_Due,
            '' as RNN_Sales_Exec, 0 as RNN_SE_Commission, 0 as Sales_Commission_Due,
            '' as Reseller, 0 as Reseller_Commission, 0 as Reseller_Commission_Due,
            0 as YN_Fees_Percent, 0 as YN_Fees_Due,
            0 as RNN_Net_Revenue,
            100 as gross_profit_margin")
            ->join('transactions', 'transactions.company_id', '=', 'companies.id')
            ->join('rnn_transactions', 'rnn_transactions.company_id', '=', 'companies.id')
            ->whereBetween(DB::raw('DATE(rnn_transactions.created_at)'), [$from, $to])
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('companies.id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('companies.id', $this->company_list);
            })->where('companies.id','!=', 1)->groupBy('companies.id')->get();

        $transactions = DB::table('rnn_transactions')->selectRaw("company_id,
            SUM(rnn_transactions.amount) as RNN_Rev_Share_Revenue,
            SUM(rnn_transactions.sms_cost) as SMS_Revenue,
            SUM(rnn_transactions.email_cost) as Email_Revenue,
            SUM(rnn_transactions.eletter_cost) as eLetter_Revenue
            ")->whereBetween(DB::raw('DATE(rnn_transactions.created_at)'), [$from, $to])
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        foreach($companies as $company)
        {
            $transaction =  $transactions->where('company_id', $company->id)->first();
            $company->RNN_Rev_Share_Revenue = $transaction->RNN_Rev_Share_Revenue - ($transaction->SMS_Revenue + $transaction->Email_Revenue + $transaction->eLetter_Revenue);
            $company->SMS_Revenue = $transaction->SMS_Revenue;
            $company->Email_Revenue = $transaction->Email_Revenue;
            $company->eLetter_Revenue = $transaction->eLetter_Revenue;
            $company->Total_Gross_Revenue = $company->RNN_Rev_Share_Revenue + $company->SMS_Revenue + $company->Email_Revenue + $company->eLetter_Revenue;
            unset($company->id);
        }

        return $this->sendComission($companies, true);
    }

    public function ReconciliationReport($company_id, $from, $to){
        $transactions = DB::table('rnn_transactions')->selectRaw("
            company_id, 
            '' as Master_name,
            0 as RNN_Client_ID,
            0 as RNN_Rev_Share_Fee,
            rnn_transactions.sms_cost as SMS_Revenue, 
            rnn_transactions.email_cost as Email_Revenue, 
            rnn_transactions.eletter_cost as eLetter_Revenue,
            amount as RNN_Total_Gross_Deposit, 
            'ACH' as Master_Payment_Method, 
            rnn_invoice_id as Payment_reference_Number,
            Date(rnn_transactions.created_at) as date"
        )->whereBetween(DB::raw('DATE(rnn_transactions.created_at)'), [$from, $to])
        ->when($company_id != "all", function ($query) use ($company_id) {
            return $query->where('company_id', $company_id);
        })->when(!empty($this->company_list), function ($query) {
            return $query->whereIn('company_id', $this->company_list);
        })->where('company_id','!=', 1)->get();

        $companies = DB::table('companies')->selectRaw("companies.id as company_id, 
            companies.company_name as Master_name, companies.rnn_id as RNN_Client_ID, 
            companies.rnn_share as RNN_Rev_Share_Fee")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('companies.id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('companies.id', $this->company_list);
            })->where('companies.id','!=', 1)->get();

        $totals = [ 'Total', '', '', 0, 0, 0, 0, '', '', '' ];
        foreach($transactions as $transaction){
            $company = $companies->where('company_id', $transaction->company_id)->first();
            $transaction->Master_name = $company->Master_name ?? '';
            $transaction->RNN_Client_ID = $company->RNN_Client_ID ?? '';
            $transaction->RNN_Rev_Share_Fee = $transaction->RNN_Total_Gross_Deposit - ($transaction->SMS_Revenue + $transaction->Email_Revenue + $transaction->eLetter_Revenue) ?? 0;

            $transaction->Payment_reference_Number = $transaction->Payment_reference_Number.'-'.($company->RNN_Client_ID ?? '');
            foreach(['SMS_Revenue', 'Email_Revenue', 'eLetter_Revenue', 'RNN_Total_Gross_Deposit'] as $dollars){
                if(!is_numeric($transaction->{$dollars}))
                    $transaction->{$dollars} = 0;
            }
            
            $totals[3] += $transaction->SMS_Revenue ?? 0;
            $totals[4] += $transaction->Email_Revenue ?? 0;
            $totals[5] += $transaction->eLetter_Revenue ?? 0;
            $totals[6] += $transaction->RNN_Total_Gross_Deposit ?? 0;

            $transaction->RNN_Rev_Share_Fee = round($transaction->RNN_Rev_Share_Fee ?? 0,2)."%";
            foreach(['SMS_Revenue', 'Email_Revenue', 'eLetter_Revenue', 'RNN_Total_Gross_Deposit'] as $dollars)
                    $transaction->{$dollars} = formatAmount($transaction->{$dollars} ?? 0, $this->currency);  
            unset($transaction->company_id);
        }

        $totals[3] = formatAmount($totals[3], $this->currency);
        $totals[4] = formatAmount($totals[4], $this->currency);
        $totals[5] = formatAmount($totals[5], $this->currency);
        $totals[6] = formatAmount($totals[6], $this->currency);
        
        return [$transactions, $totals];
    }

    public function ClientProfileReport($company_id, $from, $to){
        $companies = DB::table('companies')->selectRaw("companies.id, companies.company_name as Master_name, companies.contract_date as Date_of_contract,
            companies.rnn_share as RNN_Percent, companies.email_rate as RNN_per_Email, companies.sms_rate as RNN_per_SMS, companies.eletter_rate as RNN_per_eLetter,
             companies.rnn_id as RNN_Client_ID, companies.send_commission,
            '' as RNN_AM, '' as Reseller, '' as RNN_Sales_Exec,
            billing_schedule as Pay_Term, 'ACH' as Pay_Method, count(distinct consumers.id) as Current_Number_of_accounts_in_YN, 
            0 as current_balances, 
            0 as Rnn_Gross_Revenue_To_Date,
            0 as Total_Consumer_Payments_Received,
            0 as Total_Upcoming_Transactions")
            ->join('consumers', 'consumers.company_id', '=', 'companies.id')
            ->where('companies.status', 'approved')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('companies.id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('companies.id', $this->company_list);
            })->where('companies.id','!=', 1)->groupBy('companies.id')->get();

        $transactions = DB::table('rnn_transactions')->selectRaw("company_id,
                sum(rnn_transactions.amount) as Rnn_Gross_Revenue_To_Date")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        $consumerCurrentBalances = Consumer::selectRaw("company_id,
                sum(consumers.current_balance) as current_balance")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        $paymentsMade = Transaction::selectRaw("company_id,
                sum(amount) as Total_Consumer_Payments_Received")->where('status', 'Successful')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        $upcoming = ScheduleTransaction::selectRaw("company_id, sum(amount) as Total_Upcoming_Transactions")->where('status', 'scheduled')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();;

        $totals = ["Total","","","","","","","","","","","",0,0,0,0,0];

        foreach($companies as $company){
            $company->RNN_per_Email = $company->RNN_per_Email ?? 0;
            $company->RNN_per_SMS = $company->RNN_per_SMS ?? 0;
            $company->RNN_per_eLetter = $company->RNN_per_eLetter ?? 0;

            $company->current_balances = $consumerCurrentBalances->where('company_id', $company->id)->first()->current_balance ?? 0;
            $company->Total_Consumer_Payments_Received = $paymentsMade->where('company_id', $company->id)->first()->Total_Consumer_Payments_Received ?? 0;
            $company->Total_Upcoming_Transactions = $upcoming->where('company_id', $company->id)->first()->Total_Upcoming_Transactions ?? 0;

            $transaction =  $transactions->where('company_id', $company->id)->first();
            $company->Rnn_Gross_Revenue_To_Date = $transaction->Rnn_Gross_Revenue_To_Date ?? 0;

            $totals[12] += $company->Current_Number_of_accounts_in_YN;
            $totals[13] += $company->current_balances;
            $totals[14] += $company->Rnn_Gross_Revenue_To_Date;
            $totals[15] += $company->Total_Consumer_Payments_Received;
            $totals[16] += $company->Total_Upcoming_Transactions;

            $company->current_balances = formatAmount($company->current_balances, $this->currency);
            $company->Rnn_Gross_Revenue_To_Date = formatAmount($company->Rnn_Gross_Revenue_To_Date, $this->currency);
            $company->Total_Consumer_Payments_Received = formatAmount($company->Total_Consumer_Payments_Received, $this->currency);
            $company->Total_Upcoming_Transactions = formatAmount($company->Total_Upcoming_Transactions, $this->currency);

            $company->RNN_Percent = ($company->RNN_Percent ?? 0)."%";
            $company->Current_Number_of_accounts_in_YN = number_format($company->Current_Number_of_accounts_in_YN);

            unset($company->id);
        }

        $totals[12] = number_format($totals[12]);
        $totals[13] = formatAmount($totals[13], $this->currency);
        $totals[14] = formatAmount($totals[14], $this->currency);
        $totals[15] = formatAmount($totals[15], $this->currency);
        $totals[16] = formatAmount($totals[16], $this->currency);

        return [$this->sendComission($companies, false), $totals];
    }

    public function MasterClientCurrentSnapshotReport($company_id, $from, $to){
        $companies = DB::table('consumers')->selectRaw("consumers.company_id as company_id, '' as Master_name,
                count(distinct consumers.id) as Current_Consumers, sum(total_balance) as Current_Consumers_Total_Balance,
                
                0 as SMS_Comm_Sent, '0.00%' as SMS_Comm_Sent_Percent,
                0 as SMS_Delivered, '0.00%' as SMS_Delivered_Percent, 0 as SMS_Delivered_Balance,
                0 as Email_Comm_Sent, '0.00%' as Email_Comm_Sent_Percent, 
                0 as Email_Delivered, '0.00%' as Email_Delivered_Percent, 0 as Email_Delivered_Balance,

                0  as Clicked_On_Link, '0.00%' as Clicked_On_Link_Percent, 0 as Clicked_On_Link_Balance,

                0  as Entered_PII_Data, '0.00%' as Entered_PII_Data_Percent,

                count(distinct if(consumers.status = 'not_verified', consumers.id, null)) as PII_Mismatch, '0.00%' as PII_Mismatch_Percent,

                0 as Settled_In_Full, 0  as Settled_In_Full_Balance, '0.00%' as Settled_In_Full_Of_Balance_Delivered_Comission,
                0 as Successfully_Negotiated, '0.00%' as Successfully_Negotiated_Percent, 0 as Successfully_Negotiated_Balance,

                count(distinct if(payment_setup = 1 AND status = 'settled', consumers.id, null)) as PayProfile_Set_Up, '0.00%' as  PayProfile_Set_Up_Percent, 
                sum(if(payment_setup = 1 AND status = 'settled', consumers.total_balance, null)) as PayProfile_Set_Up_Balance
            ")->where('consumers.status', "!=", 'deactivated')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('consumers.company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('consumers.company_id', $this->company_list);
            })->where('consumers.company_id','!=', 1)->groupBy('consumers.company_id')->get();

        $totalSent = Consumer::selectRaw("consumers.id, consumers.company_id as company, consumers.status, consumers.total_balance as balance, 
            count(if(template_type = 'email', 1, null)) as email_sent,
            count(if(template_type = 'email' and communication_histories.status = 'success', 1, null)) as email_delivered,

            count(if(template_type = 'sms', 1, null)) as sms_sent,
            count(if(template_type = 'sms' and communication_histories.status = 'success', 1, null)) as sms_delivered
            ")->join('communication_histories', 'communication_histories.consumer_id', 'consumers.id')
            ->where('consumers.status', "!=", 'deactivated')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('consumers.company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('consumers.company_id', $this->company_list);
            })->where('consumers.company_id','!=', 1)->groupBy('consumers.id')->get();

        $negotiations = Consumer::selectRaw("consumers.id, consumers.company_id as company, consumers.status, consumers.total_balance as balance, 
            count(if(negotiation_type = 'pif', 1, null)) as pif,
            count(if(consumer_negotiations.offer_accepted = 1, 1, null)) as negotiated
            ")->join('communication_histories', 'communication_histories.consumer_id', 'consumers.id')
            ->join('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
            ->where('consumers.status', "!=", 'deactivated')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('consumers.company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('consumers.company_id', $this->company_list);
            })->where('consumers.company_id','!=', 1)->groupBy('consumers.id')->get();

        $placeHolders = [
            'negotiated' => ['Successfully_Negotiated', 'Successfully_Negotiated_Balance', $negotiations->where('negotiated', '>', 0)],
            'Settled_In_Full' => ['Settled_In_Full', 'Settled_In_Full_Balance', $negotiations->where('pif', '>', 0)],
            'sms' => ['SMS_Comm_Sent', "", $totalSent->where('sms_sent', '>', 0)],
            'sms_delivered' => ['SMS_Delivered', "SMS_Delivered_Balance", $totalSent->where('sms_delivered', '>', 0)],
            'email' => ['Email_Comm_Sent', "", $totalSent->where('email_sent', '>', 0)],
            'email_delivered' => ['Email_Delivered', "Email_Delivered_Balance", $totalSent->where('email_delivered', '>', 0)],
            'Clicked_On_Link' => ['Clicked_On_Link', 'Clicked_On_Link_Balance', $totalSent->whereNotIn('status', ['uploaded', 'disabled'])],
            'Entered_PII_Data' => ['Entered_PII_Data', '', $totalSent->whereNotIn('status', ['uploaded', 'disabled', 'not_verified'])],
        ];

        $company_names = Company::select('company_name', 'id')->when($company_id != "all", function ($query) use ($company_id) {
                            return $query->where('id', $company_id);
                        })->when(!empty($this->company_list), function ($query) {
                            return $query->whereIn('id', $this->company_list);
                        })->where('id','!=', 1)->get();

        //lists the totals for all fields in the order they appear
        $totals = ["Total", 
            'Current_Consumers' => 0, 'Current_Consumers_Total_Balance' => 0,
            'SMS_Comm_Sent' => 0,  "SMS_Comm_Sent_Percent" => 0,  
            'SMS_Delivered' => 0, "SMS_Delivered_Percent" => 0, 'SMS_Delivered_Balance' => 0,  
            'Email_Comm_Sent' => 0,  "Email_Comm_Sent_Percent" => 0, 
            'Email_Delivered' => 0,  "Email_Delivered_Percent" => 0, 'Email_Delivered_Balance' => 0, 
            'Clicked_On_Link' => 0,  "Clicked_On_Link_Percent" => 0, 'Clicked_On_Link_Balance' => 0,  
            'Entered_PII_Data' => 0,  "Entered_PII_Data_Percent" => 0,  
            'PII_Mismatch' => 0,  "PII_Mismatch_Percent" => 0,  
            'Settled_In_Full' => 0,  'Settled_In_Full_Balance' =>  0, "Settled_In_Full_Of_Balance_Delivered_Comission" => "0.00%", 
            'Successfully_Negotiated' => 0,  "Successfully_Negotiated_Percent" => "0.00%", 'Successfully_Negotiated_Balance' =>  0,  
            'PayProfile_Set_Up' => 0,  'PayProfile_Set_Up_Percent' => 0, 'PayProfile_Set_Up_Balance' => 0, 
        ];

        //lists all the collums that need to be formated for percentages, grouped by their divisor then the name of the field followed by the value to be diveded
        $percents = [
            'Current_Consumers' => [
                ['Clicked_On_Link_Percent', 'Clicked_On_Link'], ['SMS_Comm_Sent_Percent','SMS_Comm_Sent'], ['Email_Comm_Sent_Percent','Email_Comm_Sent'],  
            ],
            'Current_Consumers_Total_Balance' => [['Settled_In_Full_Of_Balance_Delivered_Comission','Settled_In_Full_Balance']],
            'SMS_Comm_Sent' =>[['SMS_Delivered_Percent','SMS_Delivered']],
            'Email_Comm_Sent' =>[['Email_Delivered_Percent','Email_Delivered']],
            'SMS_Comm_Sent_Balance' => [['SMS_Delivered_Balance_Percent','SMS_Delivered_Balance']],
            'Email_Comm_Sent_Balance' => [['Email_Delivered_Balance_Percent','Email_Delivered_Balance']],
            'Clicked_On_Link' => [['Entered_PII_Data_Percent', 'Entered_PII_Data']],
            'Entered_PII_Data' => [['PII_Mismatch_Percent', 'PII_Mismatch']],
            'Successfully_Negotiated' => [['PayProfile_Set_Up_Percent', 'PayProfile_Set_Up']],
        ];

        $balances = ['Current_Consumers_Total_Balance', 'Clicked_On_Link_Balance', 'Settled_In_Full_Balance', 'SMS_Delivered_Balance', 'Email_Delivered_Balance', 'Successfully_Negotiated_Balance', 'PayProfile_Set_Up_Balance',];
        $numbers = ['Current_Consumers', 'SMS_Comm_Sent', 'Email_Comm_Sent', 'SMS_Delivered', 'Email_Delivered', 'Clicked_On_Link', 'Entered_PII_Data', 'PII_Mismatch', 'Settled_In_Full', 'Successfully_Negotiated', 'PayProfile_Set_Up',];

        //sets up the percentages and merges in the communication results
        foreach($companies as $company){
            $company->Master_name = $company_names->where('id', $company->company_id)->first()->company_name ?? '';

            //passes in the values gained from other queries to the company object's placeholders
            foreach($placeHolders as $values){
                $companyPlaceHolders = $values[2]->where('company', $company->company_id);
                $company->{$values[0]} = $companyPlaceHolders->count();

                if($values[1] != ''){
                    foreach($companyPlaceHolders as $sent)
                        $company->{$values[1]} += $sent->balance;
                }
            }

            //gets the percentages based on the array above
            foreach($percents as $divisor => $values){
                //if the divisor is empty or is zero skips the section
                if(empty($company->{$divisor}))
                    continue;

                //otherwise gets the value of the percentage
                foreach($values as $value)
                    $company->{$value[0]} = number_format(($company->{$value[1]}/$company->{$divisor})*100,2)."%";
            }

            $PIITotal = $company->Entered_PII_Data - $company->PII_Mismatch;
            if($PIITotal > 0)
                $company->Successfully_Negotiated_Percent = number_format(($company->Successfully_Negotiated/$PIITotal)*100,2)."%";

            $commTotal = $totalSent->where('company', $company->company_id)->count();
            if($commTotal > 0)
                $company->Clicked_On_Link_Percent = number_format(($company->Clicked_On_Link/$commTotal)*100,2)."%";

            //formats all balance fields and gives a $ 
            foreach($balances as $balance){
                $totals[$balance] += $company->{$balance};
                $company->{$balance} = formatAmount($company->{$balance}, $this->currency);
            }
            
            foreach($numbers as $number){
                $totals[$number] += $company->{$number};
                $company->{$number} = number_format($company->{$number});
            }    
            
            unset($company->company_id);
        }
        
        foreach($percents as $divisor => $values){
            //if the divisor is empty or is zero skips the section
            if(empty($totals[$divisor]))
                continue;

            //otherwise gets the value of the percentage
            foreach($values as $value)
                $totals[$value[0]] = number_format(($totals[$value[1]]/$totals[$divisor])*100,2)."%";
        }

        $PIITotal = $totals['Entered_PII_Data'] - $totals['PII_Mismatch'];
        if($PIITotal > 0)
            $totals['Successfully_Negotiated_Percent'] = number_format(($totals['Successfully_Negotiated']/$PIITotal)*100,2)."%";

        $commTotal = $totalSent->count();
        if($commTotal > 0)
            $totals['Clicked_On_Link_Percent'] = number_format(($totals['Clicked_On_Link']/$commTotal)*100,2)."%";

        foreach($balances as $balance)
            $totals[$balance] = formatAmount($totals[$balance], $this->currency);
    
        foreach($numbers as $number)
            $totals[$number] = number_format($totals[$number]);

        return [$companies, $totals];
    }

    public function MasterClientActivityReport($company_id, $from, $to){
        $companies = DB::table('companies')->selectRaw("companies.id as company_id, companies.company_name as Master_name, companies.contract_date as Date_of_contract,
            companies.send_commission, 'N/A' as RNN_Sales_Exec, 'N/A' as RNN_AM, 'N/A' as Reseller, 
            0 as Gross_Consumer_Payments_Made_To_Date,
            'N/A' as Last_Upload_Date, 0 as Number_Of_Accounts_Uploaded, 'N/A' as Last_Communication_Date, 'N/A' as Type_Of_Communication,
            0 as Number_Of_Consumers")->where('status', 'approved')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('companies.id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('companies.id', $this->company_list);
            })->where('companies.id','!=', 1)->groupBy('companies.id')->get();

        $transactions = DB::table('transactions')->selectRaw("company_id, SUM(if(transactions.status = 'Successful', transactions.amount, null)) as Gross_Consumer_Payments_Made_To_Date
            ")->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        $communications = Campaign::selectRaw("campaigns.company_id, campaigns.sent_at as Last_Communication_Date, templates.type as Type_Of_Communication, campaigns.total_sent as Number_Of_Consumers")
            ->join('templates', 'template_id', 'templates.id')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('campaigns.company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('campaigns.company_id', $this->company_list);
            })->where('campaigns.company_id','!=', 1)->orderby('sent_at', 'desc')->get();

        $uploads = FileUploadHistory::SelectRaw("company_id, created_at as Last_Upload_Date, processed_count as Number_Of_Accounts_Uploaded")
            ->where("type", 'add')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->orderby('created_at', 'desc')->get();

        $totals = ["Total","","","","","Gross_Consumer_Payments_Made_To_Date" => 0,"","Number_Of_Accounts_Uploaded" => 0,"","","Number_Of_Consumers" => 0];
        $totals_headers = ["Gross_Consumer_Payments_Made_To_Date", "Number_Of_Accounts_Uploaded", "Number_Of_Consumers"];
        
        foreach($companies as $company){
            $transaction =  $transactions->where('company_id', $company->company_id)->first();
            $company->Gross_Consumer_Payments_Made_To_Date = $transaction->Gross_Consumer_Payments_Made_To_Date ?? 0;

            $communication = $communications->where('company_id', $company->company_id)->first();
            $upload = $uploads->where('company_id', $company->company_id)->first();

            $totals["Gross_Consumer_Payments_Made_To_Date"] += $company->Gross_Consumer_Payments_Made_To_Date ?? 0;
            $totals["Number_Of_Accounts_Uploaded"] += $upload->Number_Of_Accounts_Uploaded ?? 0;
            $totals["Number_Of_Consumers"] += $communication->Number_Of_Consumers ?? 0;

            $company->Last_Upload_Date = $upload->Last_Upload_Date ?? 'N/A';
            $company->Number_Of_Accounts_Uploaded = number_format($upload->Number_Of_Accounts_Uploaded ?? 0);
            $company->Last_Communication_Date = $communication->Last_Communication_Date ?? 'N/A';
            $company->Type_Of_Communication = $communication->Type_Of_Communication ?? 'N/A';
            $company->Number_Of_Consumers = number_format($communication->Number_Of_Consumers ?? 0);
            $company->Gross_Consumer_Payments_Made_To_Date = formatAmount($company->Gross_Consumer_Payments_Made_To_Date, $this->currency);

            unset($company->company_id);
        }

        $totals["Gross_Consumer_Payments_Made_To_Date"] = formatAmount($totals["Gross_Consumer_Payments_Made_To_Date"], $this->currency);
        $totals["Number_Of_Accounts_Uploaded"]  = number_format($totals["Number_Of_Accounts_Uploaded"]);
        $totals["Number_Of_Consumers"] = number_format($totals["Number_Of_Consumers"]);


        return [$this->sendComission($companies, false), $totals];
    }

    public function InvestorSnapshotReport($company_id, $from, $to){
        $companies = DB::table('companies')->selectRaw("0 as Total_balance_value,
            0 as Average_balance,
            0 as Number_Of_Consumer_Accounts_In_YN, 
            count(distinct companies.id) as Number_of_unique_Creditor_clients_in_YN,
            0 as Number_of_sub_accounts,
            0 as Total_Consumer_Payments_Made_In_YN,
            0 as Total_Upcoming_Recurring_consumer_payments_set_up,
            'USA' as Countries_Transacting")
            ->where('companies.status', 'approved')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('companies.id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('companies.id', $this->company_list);
            })->where('companies.id','!=', 1)->get();

        $consumers = Consumer::selectRaw("sum(current_balance) as Total_balance_value, count(*) as Number_Of_Consumer_Accounts_In_YN, sum(current_balance)/count(*) Average_balance")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->first();

        $subclients = Subclient::selectRaw('count(*) as Subclients')
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->first();

        $totals = ["Total balance value ","# of consumer accounts in YN","Number of unique Creditor clients in YN (master and sub) ","Total consumer payments made in YN","Total upcoming/recurring consumer payments set up","Average balance if a way to calculate","# Creditors ACH Master Payment Method ","# Creditors Credit Card Master Payment Method ","Countries transacting"];
        $totals = [];

        $companies->first()->Number_Of_Consumer_Accounts_In_YN = number_format($consumers->Number_Of_Consumer_Accounts_In_YN ?? 0);
        $companies->first()->Number_of_unique_Creditor_clients_in_YN = number_format($companies->first()->Number_of_unique_Creditor_clients_in_YN);
        $companies->first()->Number_of_sub_accounts = number_format(($subclients->Subclients ?? 0));

        $companies->first()->Average_balance = formatAmount($consumers->Average_balance ?? 0, $this->currency);
        $companies->first()->Total_balance_value = formatAmount($consumers->Total_balance_value ?? 0, $this->currency);

        $companies->first()->Total_Upcoming_Recurring_consumer_payments_set_up = formatAmount(ScheduleTransaction::selectRaw("sum(amount) as amount")->where('status', 'scheduled')->first()->amount);
        $companies->first()->Total_Consumer_Payments_Made_In_YN = formatAmount(Transaction::selectRaw("sum(amount) as amount")->where('status', 'Successful')->first()->amount);
        return [$companies, $totals];
    }

    public function WeeklyExecEmailSummaryReport($company_id, $from, $to){
        $companies = DB::table('companies')->selectRaw("companies.company_name as Master_Client,
            0 as Number_Of_Accounts, 0 as Total_Balances, 0 as Total_Comm_Sent, 
            0 as Total_Consumer_Payments_MTD, 0 as Total_Consumer_Payments_YTD, 
            0 as RNN_Revenue_MTD, 0 as RNN_Revenue_YTD, 
            id as company_id
            ")->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('companies.id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('companies.id', $this->company_list);
            })->where('companies.id','!=', 1)->groupBy('companies.id')->get();

        $consumers = Consumer::SelectRaw("count(*) as Number_Of_Accounts, sum(total_balance) as Total_Balances, company_id")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        $communications = CommunicationHistory::selectRaw("count(*) as Total_Comm_Sent, consumers.company_id")
            ->join('consumers', 'consumers.id', 'communication_histories.consumer_id')
            ->where("communication_histories.created_at", '>', date('Y-m-d', strtotime('-1 week')))
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('consumers.company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('consumers.company_id', $this->company_list);
            })->where('consumers.company_id','!=', 1)->groupBy('consumers.company_id')->get();

        $payments = Transaction::selectRaw("company_id, sum(if(Year(created_at) = YEAR(CURDATE()),amount,null)) as Total_Consumer_Payments_YTD, 
            sum(if(Year(created_at) = YEAR(CURDATE()) AND Month(created_at) = Month(CURDATE()),amount,null)) as Total_Consumer_Payments_MTD")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->where('status', 'Successful')->groupBy('company_id')->get();

        $rnnPayments = RnnTransaction::selectRaw("company_id, sum(if(Year(created_at) = YEAR(CURDATE()),amount,null)) as YTD, 
            sum(if(Year(created_at) = YEAR(CURDATE()) AND Month(created_at) = Month(CURDATE()),amount,null)) as MTD")
            ->when($company_id != "all", function ($query) use ($company_id) {
                return $query->where('company_id', $company_id);
            })->when(!empty($this->company_list), function ($query) {
                return $query->whereIn('company_id', $this->company_list);
            })->where('company_id','!=', 1)->groupBy('company_id')->get();

        $totals = ["Total","Number_Of_Accounts" => 0,"Total_Balances" => 0,"Total_Comm_Sent" => 0,"Total_Consumer_Payments_MTD" => 0,"Total_Consumer_Payments_YTD" => 0, 'RNN_Revenue_MTD' => 0, 'RNN_Revenue_YTD' => 0];

        foreach($companies as $company){

            $Total_Comm_Sent = $communications->where('company_id', $company->company_id)->first()->Total_Comm_Sent ?? 0;
            $Total_Consumer_Payments_YTD = $payments->where('company_id', $company->company_id)->first()->Total_Consumer_Payments_YTD ?? 0;
            $Total_Consumer_Payments_MTD = $payments->where('company_id', $company->company_id)->first()->Total_Consumer_Payments_MTD ?? 0;
            $Number_Of_Accounts = $consumers->where('company_id', $company->company_id)->first()->Number_Of_Accounts ?? 0;
            $Total_Balances = $consumers->where('company_id', $company->company_id)->first()->Total_Balances ?? 0;
            $RNN_Revenue_MTD = $rnnPayments->where('company_id', $company->company_id)->first()->MTD ?? 0;
            $RNN_Revenue_YTD = $rnnPayments->where('company_id', $company->company_id)->first()->YTD ?? 0;

            $totals["Number_Of_Accounts"] += $Number_Of_Accounts;
            $totals["Total_Balances"] += $Total_Balances;
            $totals["Total_Comm_Sent"] += $Total_Comm_Sent;
            $totals["Total_Consumer_Payments_MTD"] += $Total_Consumer_Payments_MTD;
            $totals["Total_Consumer_Payments_YTD"] += $Total_Consumer_Payments_YTD;
            $totals["RNN_Revenue_MTD"] += $RNN_Revenue_MTD;
            $totals["RNN_Revenue_YTD"] += $RNN_Revenue_YTD;

            $company->Total_Comm_Sent = number_format($Total_Comm_Sent);
            $company->Total_Consumer_Payments_YTD = formatAmount($Total_Consumer_Payments_YTD, $this->currency);
            $company->Total_Consumer_Payments_MTD = formatAmount($Total_Consumer_Payments_MTD, $this->currency);
            
            $company->RNN_Revenue_MTD = formatAmount($RNN_Revenue_MTD, $this->currency);
            $company->RNN_Revenue_YTD = formatAmount($RNN_Revenue_YTD, $this->currency);
            $company->Number_Of_Accounts = number_format($Number_Of_Accounts);
            $company->Total_Balances = formatAmount($Total_Balances, $this->currency);

            unset($company->company_id);
        }

        $totals["Number_Of_Accounts"] = number_format($totals["Number_Of_Accounts"]);
        $totals["Total_Balances"] = formatAmount($totals["Total_Balances"], $this->currency);
        $totals["Total_Comm_Sent"] = number_format($totals["Total_Comm_Sent"]);
        $totals["Total_Consumer_Payments_MTD"] = formatAmount($totals["Total_Consumer_Payments_MTD"], $this->currency);
        $totals["Total_Consumer_Payments_YTD"] = formatAmount($totals["Total_Consumer_Payments_YTD"], $this->currency);
        $totals["RNN_Revenue_MTD"] = formatAmount($totals["RNN_Revenue_MTD"], $this->currency);
        $totals["RNN_Revenue_YTD"] = formatAmount($totals["RNN_Revenue_YTD"], $this->currency);

        return [$companies, $totals];
    }

    private function sendComission($companies, $commissionReport){
        $totals = ["Total", "", "", "RNN_Set_Up_Collected" => 0, "RNN_Rev_Share_Revenue" => 0, "SMS_Revenue" => 0, "Email_Revenue" => 0 , "eLetter_Revenue" => 0, "Total_Gross_Revenue" => 0, "", "AM_Commission" => '', "AM_Commission_Due" => 0, "", "RNN_SE_Commission" => '', "Sales_Commission_Due" => 0,
        "", "Reseller_Commission" => '', "Reseller_Commission_Due" => 0, "YN_Fees_Percent" => '', "YN_Fees_Due" => 0, "RNN_Net_Revenue" => 0, "gross_profit_margin" => 0];

        $commission_ids = [];
        foreach($companies as $company){
            if(empty($company->send_commission))
                continue;

            $commissions = json_decode($company->send_commission);
            
            foreach($commissions as $commission){
                if(!empty($commission->rnn_user_id))
                    $commission_ids[] = $commission->rnn_user_id;
            }
        }

        $users = User::select('id', 'name', 'rnn_user_type')->whereIn('id', $commission_ids)->get();

        foreach($companies as $company){
            if($commissionReport){
                $company->RNN_Net_Revenue = $company->Total_Gross_Revenue;
            }

            //if there is no send commission jumps to the end
            if(empty($company->send_commission))
                goto remove_send_commission;

            $commissions = json_decode($company->send_commission);

            foreach($commissions as $commission){
                $user = $users->where('id', $commission->rnn_user_id ?? 0)->first();
                $usertype = $user->rnn_user_type ?? '';
                switch($usertype){
                    case "salesRep":
                        $company->RNN_Sales_Exec = $user->name ?? '';
                        if($commissionReport){
                            $company->RNN_SE_Commission = $commission->commission_on_rnn_share;
                            $company->Sales_Commission_Due = ($commission->commission_on_rnn_share * $company->Total_Gross_Revenue)/100;
                        }
                    break;
                    case "accountManager":
                        $company->RNN_AM = $user->name ?? '';
                        if($commissionReport){
                            $company->AM_Commission = $commission->commission_on_rnn_share;
                            $company->AM_Commission_Due = ($commission->commission_on_rnn_share * $company->Total_Gross_Revenue)/100;
                        }
                    break;
                    case "reseller":
                        $company->Reseller = $user->name ?? '';
                        if($commissionReport){
                            $company->Reseller_Commission = $commission->commission_on_rnn_share;
                            $company->Reseller_Commission_Due = ($commission->commission_on_rnn_share * $company->Total_Gross_Revenue)/100;
                        }
                    break;
                }
            }

            if($commissionReport){
                $company->YN_Fees_Percent = $company->Reseller_Commission + $company->AM_Commission + $company->RNN_SE_Commission;
                $company->YN_Fees_Due = $company->Reseller_Commission_Due + $company->AM_Commission_Due + $company->Sales_Commission_Due;
                $company->RNN_Net_Revenue = $company->RNN_Net_Revenue - $company->Reseller_Commission_Due - $company->AM_Commission_Due - $company->Sales_Commission_Due;
                if(!empty($company->Total_Gross_Revenue))
                    $company->gross_profit_margin = ($company->RNN_Net_Revenue/$company->Total_Gross_Revenue)*100;
            }

            remove_send_commission:
            unset($company->send_commission);
            if($commissionReport){
                foreach(['YN_Fees_Percent', 'gross_profit_margin', 'Reseller_Commission', 'AM_Commission', 'RNN_SE_Commission'] as $percent)
                    $company->{$percent} = round($company->{$percent},2)."%";

                foreach(['Total_Gross_Revenue', 'YN_Fees_Due', 'RNN_Rev_Share_Revenue', 'Reseller_Commission_Due', 'AM_Commission_Due', 'Sales_Commission_Due', 'RNN_Net_Revenue', 'RNN_Set_Up_Collected', 'SMS_Revenue', 'Email_Revenue', 'eLetter_Revenue'] as $dollars)
                {
                    $totals[$dollars] += $company->{$dollars};
                    $company->{$dollars} = formatAmount($company->{$dollars}, $this->currency);    
                }
            }
        }
        if($commissionReport)
        {
            if($totals["Total_Gross_Revenue"] != 0)
                $totals["gross_profit_margin"] = round(($totals["RNN_Net_Revenue"]/$totals["Total_Gross_Revenue"])*100,2)."%";
            else
                $totals["gross_profit_margin"] = '0.00%';
            $totals["YN_Fees_Due"] = formatAmount($totals["YN_Fees_Due"], $this->currency);

            foreach(['Total_Gross_Revenue', 'RNN_Rev_Share_Revenue', 'Reseller_Commission_Due', 'AM_Commission_Due', 'Sales_Commission_Due', 'RNN_Net_Revenue', 'RNN_Set_Up_Collected', 'SMS_Revenue', 'Email_Revenue', 'eLetter_Revenue'] as $dollars)
                $totals[$dollars] = formatAmount($totals[$dollars], $this->currency);
            return [$companies, $totals];
        }
        return $companies;
    }

    public function companyList($user_id = null){
        if($user_id == null)
            $user = auth()->user();
        else
            $user = User::find($user_id);
        
        if($user->rnn_user_type == 'admin')
            return [];

        $companies = Company::whereNotNull('send_commission')->select('id', 'send_commission')->get();
        $company_ids = [];
        foreach($companies as $company){
            $commissions = json_decode($company->send_commission);
            foreach($commissions as $commission){
                if(empty($commission->rnn_user_id))
                    continue;
                if($commission->rnn_user_id == $user->id)
                    $company_ids[] = $company->id;
            }
        }

        //if the user has no companies, sends a 0 to prevent any from being shown
        if(empty($company_ids))
            return [0];

        return $company_ids;
    }
}