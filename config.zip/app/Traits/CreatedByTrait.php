<?php

namespace App\Traits;

trait CreatedByTrait
{
    public function createdBy()
    {
        return $this->belongsTo('App\User', 'created_by', 'id');
    }
}
