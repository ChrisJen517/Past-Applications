<?php

namespace App\Traits;

trait CompanyIDTrait
{
    public function company()
    {
        return $this->belongsTo('App\Company');
    }
}
