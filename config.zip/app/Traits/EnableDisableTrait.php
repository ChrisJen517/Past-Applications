<?php

namespace App\Traits;

trait EnableDisableTrait
{

    public function enable($id)
    {
        $item = $this->repository->getByID($id);
        $item->enabled = true;
        $item->save();
        return redirect()->back();
    }

    public function disable($id)
    {
        $item = $this->repository->getByID($id);
        $item->enabled = false;
        $item->save();
        return redirect()->back();
    }
}
