<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomContent extends Model
{
    protected $fillable = [
        'company_id', 'subclient_id', 'title', 'content',
    ];

    public function company(){
    	return $this->belongsTo('App\Company'); 
    }

    public function subclient()
    {
        return $this->belongsTo('App\Subclient')->withDefault(['name' => '']);
    }
}
