<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PersonalizedLogo extends Model
{
    protected $fillable = ['company_id', 'primary_color', 'secondary_color', 'background_color', 'customer_communication_link','logo_name'];
}
