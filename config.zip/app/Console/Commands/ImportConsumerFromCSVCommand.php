<?php

namespace App\Console\Commands;

use App\Consumer;
use App\ConsumerActivity;
use App\ConsumerNegotiation;
use App\CsvHeader;
use App\FileUploadHistory;
use App\Imports\CsvDataImport;
use App\Jobs\ImportConsumerJob;
use App\PaymentProfile;
use App\Subclient;
use App\User;
use App\ScheduleTransaction;
use App\Transaction;
use App\ConsumerUnsubscription;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Storage;
use Maatwebsite\Excel\Facades\Excel;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\ConsumerUnmergedHeaderEmail;
use App\Mail\DeleteConsumersFailed;
use App\Mail\UpdateConsumersFailedEmail;
use Throwable;

class ImportConsumerFromCSVCommand extends Command
{
    protected $signature = 'import:yn-consumers {filename} {user_id} {upload_type} {fuh_id} {header_id}';

    protected $description = 'Import consumers from a csv file';

    private $user_id, $filename;

    public function __construct()
    {
        parent::__construct();
    }

    public function handle()
    {
        $user_id = $this->argument('user_id');
        $filename = $this->argument('filename');
        $upload_type = $this->argument('upload_type');
        $fuh_id = $this->argument('fuh_id');
        $header_id = $this->argument('header_id');

        Log::channel('import_consumer_command')->info('Starting file import: user_id: ' . $user_id . ' filename: ' . $filename . ' upload_type: ' . $upload_type . ', fuh_id:' . $fuh_id . ', header_id:' . $header_id . '----------------------------');

        $user = User::find($user_id);

        $data = Excel::toArray(new CsvDataImport, storage_path('app/protected/imports/' . $filename));
        $num_of_records = count($data[0]) - 1;

        Log::channel('import_consumer_command')->info('Num of Records: '.$num_of_records.' user_id: '.$user_id);

        if (count($data[0]) > 0) {
            if ($user->isCompanyUser()) {
                $saved_header = CsvHeader::where('company_id', $user->company->id)->where('id', $header_id)->get();
            } else {
                $saved_header = CsvHeader::where('subclient_id', $user->subclient_id)->where('id', $header_id)->get();
            }
            $db_headers = json_decode($saved_header[0]->saved_headers);

            //Log::channel('import_consumer_command')->info("User ID: ".$user_id." Db headers -> ".(string)($db_headers) );

            $csv_data = array_slice($data[0], 1, count($data[0]));
            $header = $data[0][0];

            $marge_header = [];
            $unmarged_header = [];
            $account_number_field = "";
            foreach ($db_headers as $db_key => $db_value) {
                if (in_array($db_key, $header)) {
                    foreach ($header as $key => $value) {
                        if ($db_key == $value) {
                            $marge_header[$key] = $db_value;
                            if($db_value == "account_number")
                                $account_number_field = $key;
                        }
                    }
                } else {
                    $unmarged_header[] = $db_key;
                }
            }

            if (count($unmarged_header) > 0) {
                Log::channel('import_consumer_command')->info('Unmarged headers: '.(string)(json_encode($unmarged_header,true)) );
                Mail::to($user->email)->send(new ConsumerUnmergedHeaderEmail($user, $unmarged_header));
            } else {

                $fileUploadHistory = FileUploadHistory::find($fuh_id);
                $user = User::find($user_id);
                $errorList = "";

                switch ($upload_type) {
                    case 'add':
                        $this->addConsumers($user, $fileUploadHistory, $csv_data, $marge_header, $errorList, $account_number_field);
                        break;
                    case 'update':
                        $this->updateConsumers($user, $fileUploadHistory, $csv_data, $marge_header);
                        break;
                    case 'delete':
                        $this->deleteConsumers($user, $fileUploadHistory, $csv_data, $marge_header);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    public function addConsumers($user, $fileUploadHistory, $csv_data, $marge_header, $errorList, $account_number_field)
    {
        foreach ($csv_data as $row) {
            ImportConsumerJob::dispatch($row, $marge_header, $user, $fileUploadHistory->id, $errorList, $account_number_field)->onQueue('import');
        }
    }

    public function updateConsumers($user, $fileUploadHistory, $csv_data, $marge_header)
    {
        $processed = 0;
        $failed = 0;
        $errorList = [];

        foreach ($csv_data as $row) {
            $account_number = null;
            foreach ($marge_header as $index => $field) {
                if ($field == 'account_number') {
                    $account_number = $row[$index];
                    if ($user->isCompanyUser()) {
                        $consumer = Consumer::where('company_id', $user->company->id)
                            ->where('account_number', '=', $account_number)
                            ->first();
                        if ($consumer == null) {
                            continue;
                        }

                        $consumer->company_id = $user->company->id;
                    } else if ($user->isSubclient1User()) {
                        $consumer = Consumer::where('sub_client1_id', $user->subclient_id)
                            ->where('account_number', '=', $account_number)
                            ->first();
                        if ($consumer == null) {
                            continue;
                        }

                        $consumer->company_id = $user->company_id;
                        $consumer->sub_client1_id = $user->subclient_id;
                    } else if ($user->isSubclient2User()) {
                        $consumer = Consumer::where('sub_client2_id', $user->subclient_id)
                            ->where('account_number', '=', $account_number)
                            ->first();
                        if ($consumer == null) {
                            continue;
                        }
                        $subclient = Subclient::find($user->subclient_id);
                        $consumer->company_id = $user->company_id;
                        $consumer->sub_client1_id = $subclient->parent_id;
                        $consumer->sub_client2_id = $user->subclient_id;
                    }
                }
                if ($field != 'Select' && $consumer != null) {
                    if ($field == "total_balance" || $field == "current_balance") {
                        $consumer->current_balance = $row[$index];
                        $consumer->total_balance = $row[$index];
                    } else {
                        if ($consumer->$field != $row[$index]) {
                            $consumer->$field = $row[$index]; //$row
                        }
                    }
                }
            }
            if ($consumer) {
                $consumer->save();
                $processed++;
                Log::channel('import_consumer_command')->info('Consumer with account no: ' . $consumer->account_number . ' updated');
            } else {
                Log::channel('import_consumer_command')->error('Consumer with account no: ' . $account_number . ' not updated');
                $failed++;
                $errorList[] = 'Consumer with account no: ' . $account_number . ' not updated';
            }
        }

        $fileUploadHistory->processed_count = $processed;
        $fileUploadHistory->failed_count = $failed;
        if ($fileUploadHistory->totalProcessed() == $fileUploadHistory->num_of_records) {
            $fileUploadHistory->status = 'Complete';
        }
        $fileUploadHistory->save();

        if(count($errorList) > 0){
            $fileUploadHistory->failed_list = $errorList;
            $fileUploadHistory->save();

            Log::channel('import_consumer_command')->info('Error File ID: '.$fileUploadHistory->id);

            Mail::to($user->email)->send(new UpdateConsumersFailedEmail($user, $fileUploadHistory, $errorList));
        }
    }

    public function deleteConsumers($user, $fileUploadHistory, $csv_data, $marge_header)
    {
        $processed = 0;
        $failed = 0;
        $errorList = [];

        foreach ($csv_data as $row) {
            $account_number = '';
            foreach ($marge_header as $index => $field) {
                if ($field == 'account_number') {
                    $account_number = $row[$index];
                }
            }
            try {
                if ($account_number != '') {
                    $consumer = null;
                    if ($user->isCompanyUser()) {
                        $consumer = Consumer::where('company_id', $user->company->id)
                            ->where('account_number', '=', $account_number)->first();
                    } else if ($user->user_type == 'subclient1') {
                        $consumer = Consumer::where('subclient_id', $user->subclient_id)
                            ->where('account_number', '=', $account_number)
                            ->first();
                    } else if ($user->isSubclient2User()) {
                        $consumer = Consumer::where('subclient_id', $user->subclient_id)
                            ->where('account_number', '=', $account_number)
                            ->first();
                    }

                    if ($consumer) {
                        if($consumer->status != 'uploaded'){
                            $consumer->status = 'deactivated';
                            $consumer->save();

                            //add consumer to unsubscription list
                            $consumerUnsubscription = new ConsumerUnsubscription();
                            $consumerUnsubscription->consumer_id = $consumer->id;
                            $consumerUnsubscription->company_id = $consumer->company_id;
                            $consumerUnsubscription->email = $consumer->email1;
                            $consumerUnsubscription->phone = $consumer->mobile1;
                            $consumerUnsubscription->save();

                        }
                        else{
                            ConsumerNegotiation::where('consumer_id', $consumer->id)->delete();
                            ConsumerActivity::where('consumer_id', $consumer->id)->delete();
                            PaymentProfile::where('consumer_id', $consumer->id)->delete();
                            ScheduleTransaction::where('consumer_id', $consumer->id)->delete();
                            Transaction::where('consumer_id', $consumer->id)->delete();
                            ConsumerUnsubscription::where('consumer_id', $consumer->id)->delete();

                            $consumer->delete();
                        }

                        $processed++;
                        Log::channel('import_consumer_command')->info('Consumer with account no: ' . $account_number . ' deleted');
                    } else {
                        $failed++;
                        Log::channel('import_consumer_command')->error('Consumer with account no: ' . $account_number . ' not found in database');
                        $errorList[] = 'Consumer with account no: ' . $account_number . ' not found in database. ';
                    }
                } else {
                    Log::channel('import_consumer_command')->error('Account no not present in csv file');
                    $failed++;
                    $errorList[] = 'Account no not present in csv file. ';
                }
            } catch (Throwable $e) {
                Log::channel('import_consumer_command')->error('Error occured while deleting consumer');
                $failed++;
                $errorList[] = 'Error occured while deleting consumer. ';
            }
        }

        $fileUploadHistory->processed_count = $processed;
        $fileUploadHistory->failed_count = $failed;
        if ($fileUploadHistory->totalProcessed() == $fileUploadHistory->num_of_records) {
            $fileUploadHistory->status = 'Complete';
        }
        $fileUploadHistory->save();

        if(count($errorList) > 0){
            $fileUploadHistory->failed_list = $errorList;
            $fileUploadHistory->save();

            Log::channel('import_consumer_command')->info('Error File ID: '.$fileUploadHistory->created_at);

            Mail::to($user->email)->send(new DeleteConsumersFailed($user, $fileUploadHistory, $errorList));
        }
    }

}