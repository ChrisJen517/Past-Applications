<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Consumer;
use Carbon\Carbon;
use DB;
use App\Transaction;
use App\ScheduleTransaction;
use App\Repositories\CommunicationRepository;
use Log;
class SettledMail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'settled:mail';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Settled Email every 30 minutes';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $communicationRepository;

    public function __construct(CommunicationRepository $communicationRepository)
    {
        parent::__construct();
        $this->communicationRepository = $communicationRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        try{
            Log::channel('settled_command')->info('Sattled Mail Starting------');
            $_sconsumers = DB::table('consumers')
                    ->join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
                    ->where('schedule_transactions.payment_complete','=',1)
                    ->select('consumers.id','consumers.first_name','consumers.account_number','consumers.total_balance','consumers.email1')
                    ->groupBy('consumers.id','consumers.first_name','consumers.account_number','consumers.total_balance','consumers.email1')
                    ->get();

            foreach($_sconsumers as $con){
                try{
                    Log::channel('settled_command')->info('********************Inside Loop**************************');
                    Log::channel('settled_command')->info('Consumer ID:'.$con->id);
                    Log::channel('settled_command')->info('Consumer Account Number:'.$con->account_number);

                    //Check if any schedule failed or pending
                    $checkSchedule = ScheduleTransaction::where('consumer_id', $con->id)->whereIn('payment_complete', [0, 2])->get();  

                    if(count($checkSchedule) == 0){

                        $mail= DB::table('setteled_mail_status')->where('consumer_id',$con->id)->count();
                        $consumer = Consumer::find($con->id);

                        if( $mail == 0){
                            Log::channel('settled_command')->info('Sent Settled Mail');
                            
                            DB::table('setteled_mail_status')->insert(['consumer_id'=>$con->id,'created_at'=>now(),'updated_at'=>now()]);

                            
                            $consumer->status = 'settled';
                            $consumer->current_balance = 0;
                            $consumer->save();

                            $amount = ScheduleTransaction::where('consumer_id', $con->id)->where('payment_complete', 1)->select(DB::raw("SUM(amount) as amount"))->first(); 

                            $this->SettledEmail($con,$amount->amount);

                        }
                        else{
                            Log::channel('settled_command')->info('Transaction is Not Settled');
                        }
                    }
                    else{
                        Log::channel('settled_command')->info('Transaction is Not Settled');
                    }
                }
                catch(\Throwable $ex){
                    Log::channel('settled_command')->error($ex);
                   continue;
                }
                 Log::channel('settled_command')->info('********************Loop End**************************');
            }
        }
        catch(\Throwable $ex){
            Log::channel('settled_command')->error($ex);
            $this->communicationRepository->sendExceptionEmail($ex->getMessage(),"Settled Mail Job");
        }
        Log::channel('settled_command')->info('Sattled Mail Ending------');
    }

    public function SettledEmail($client,$amount){
        $this->communicationRepository->sendSettledEmail($client,$amount);
    }
}
