<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Consumer;
use App\ConsumerAccount;
use App\CsvData;
use App\CsvHeader;
use App\FileUploadHistory;
use App\Subclient;

use App\Http\Requests\CsvImportRequest;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Imports\CsvDataImport;
use DB;
use League\Flysystem\Filesystem;
use League\Flysystem\Sftp\SftpAdapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Jobs\ImportConsumerJob;
use Exception;
use Illuminate\Auth\Events\Failed;
use App\SFTPImport;
use Auth;
use App\ImportSettings;
use App\User;
use Log; 

class SFTPImportCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sftp:import';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import File From SFTP Server';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        Log::channel('sftp_import_command')->info('SFTP Import Command  Starting ------');

        $sftp_details = ImportSettings::get();
        try{
            foreach ($sftp_details as $data) {

                Log::channel('sftp_import_command')->info('############## Import Start #############');
                Log::channel('sftp_import_command')->info('SFTP Details:'. $data);

                config(['filesystems.disks.sftp' => ['driver' => 'sftp'] +
                $data->only(['host', 'port', 'username', 'password', 'root', 'timeout'])]);

                $disk = Storage::disk('sftp');
                $files = Storage::disk('sftp')->files('/.');

                Log::channel('sftp_import_command')->info('All Files In Directory:'.json_encode($files));
                if (count($files) > 1) {
                    //$contents = Storage::disk('sftp')->get($files[0]);

                        foreach ($files as $file) {
                            $type = $disk->mimeType($file);
                            $modified = date('Y-m-d', $disk->lastModified($file));
                            if($type  == "text/csv" && $modified == Carbon::today()->toDateString() ){
                            Log::channel('sftp_import_command')->info('Read File:'.basename($file));
                            Log::channel('sftp_import_command')->info('Created Date:'.$modified );
                                $this->sftpFileImport($file,$data);
                                    
                            }
                        }
                   
                    }
                Log::channel('sftp_import_command')->info('############## Import End #############');
            }
        }
        catch(\Throwable $ex){
            Log::channel('sftp_import_command')->error($ex);
        }
        Log::channel('sftp_import_command')->info('SFTP Import Command End------');
    }


    public function sftpFileImport($file ,$sftp_details){
            
            $email = $account_number = '';
            $update_consumers = 0;

            if ($sftp_details->company_id !="" && $sftp_details->subclient_id =="") {
                 $user = User::where('company_id',$sftp_details->company_id)
                                ->where('subclient_id',null)->first();
            }
            else{
                $user = User::where('subclient_id',$sftp_details->subclient_id)->first();
            }

            $filedata = Storage::disk('sftp')->get($file);
            Storage::disk('public')->put('temp.csv', $filedata);
            $tempfile =Storage::disk('public')->get('temp.csv');

            $data = Excel::toArray(new CsvDataImport,Storage::disk('public')->path('temp.csv'));

            $num_of_records = count($data[0]) - 1;
            if (count($data[0]) > 0) {

                if ($sftp_details->company_id !="" && $sftp_details->subclient_id =="") {
                    $saved_header = CsvHeader::where('company_id', $sftp_details->company_id )->get();
                } else {
                    $saved_header = CsvHeader::where('subclient_id', $sftp_details->subclient_id)->get();
                }
                $db_headers = json_decode($saved_header[0]->saved_headers);

                $csv_data = array_slice($data[0], 1, count($data[0]));
                $header = $data[0][0];

                $marge_header = [];
                $account_number_field = "";
                foreach ($db_headers as $db_key => $db_value) {
                    if (in_array($db_key, $header)) {
                        foreach ($header as $key => $value) {
                            if ($db_key == $value) {
                                $marge_header[$key] = $db_value;
                            }
                            if($db_value == "account_number")
                                $account_number_field = $key;
                        }
                    }
                }



                if ($sftp_details->type == 'add') {
                    $fileUploadHistory = null;
                    $filename = date('YmdHis') .basename($file);
                    if ($user->isCompanyUser()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'filename' => $filename,
                            'type' => "add",
                            'num_of_records' => $num_of_records,
                        ]);
                    } else if ($user->isSubclient1User()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'subclient_id' => $user->subclient_id,
                            'filename' => $filename,
                            'type' => "add",
                            'num_of_records' => $num_of_records,
                        ]);
                    } else if ($user->isSubclient2User()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'subclient_id' => $user->subclient_id,
                            'filename' => $filename,
                            'type' => "add",
                            'num_of_records' => $num_of_records,
                        ]);
                    }

                    foreach ($csv_data as $row) {
                        ImportConsumerJob::dispatch($row, $marge_header, $user, $fileUploadHistory->id, $account_number_field);
                    }
                    //$path = $request->file('csv_file')->storeAs('public/imported_files',$request->file('csv_file')->getClientOriginalName());

                    $contents = Storage::disk('public')->put("imports/" . $filename,$tempfile);

                }
                elseif ($sftp_details->type == 'update') {


                    $count = 0;
                    $failed = 0;
                    $num_of_records = count($csv_data);
                    $consumer = "";
                    foreach ($csv_data as $row) {
                        foreach ($marge_header as $index => $field) {
                          try{
                                if ($field == 'account_number') {

                                    $account_number = $row[$index];
                                    if ($user->isCompanyUser()) {
                                        $consumer = Consumer::where('company_id', $user->company->id)
                                            ->where('account_number', '=', $account_number)
                                            ->first();

                                        $consumer->company_id = $user->company->id;
                                    } else if ($user->isSubclient1User()) {
                                        $consumer = Consumer::where('subclient_id', $user->subclient_id)
                                            ->where('account_number', '=', $account_number)
                                            ->first();

                                        $consumer->company_id = $user->company_id;
                                        $consumer->sub_client1_id = $user->subclient_id;
                                    } else if ($user->isSubclient2User()) {

                                        $consumer = Consumer::where('subclient_id', $user->subclient_id)
                                            ->where('account_number', '=', $account_number)
                                            ->first();

                                        $subclient = Subclient::find($user->subclient_id);
                                        $consumer->company_id = $user->company_id;
                                        $consumer->sub_client1_id = $subclient->parent_id;
                                        $consumer->sub_client2_id = $user->subclient_id;

                                    }
                                }
                            }
                            catch(\Throwable $ex){
                                Log::channel('sftp_import_command')->info('Account number not matched!!');
                                return;
                            }
                            if($consumer == ""){
                                continue;
                            }
                            if ($field != 'Select') {

                                if ($field == "total_balance" || $field == "current_balance") {
                                    if($consumer->current_balance != $row[$index]){
                                        $consumer->current_balance = $row[$index];
                                        $update_consumers += 1;
                                    }

                                } else {
                                    if($consumer->$field != $row[$index]){
                                        $consumer->$field = $row[$index]; //$row
                                        $update_consumers += 1;
                                    }
                                }
                            }
                        }
                        if($consumer == ""){
                            return;
                        }
                        try{
                            $consumer->save();
                            $count++;
                        }catch(Exception $e){
                            $failed++;
                        }
                    }

                    $filename = date('YmdHis') . basename($file);

                    if ($user->isCompanyUser()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'filename' => $filename,
                            'type' => "update",
                            'num_of_records' => $num_of_records,
                            'processed_count' => $count,
                            'failed_count' => $failed,
                        ]);
                    } else if ($user->isSubclient1User()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company_id,
                            'subclient_id' => $user->subclient_id,
                            'filename' => $filename,
                            'type' => "update",
                            'num_of_records' => $num_of_records,
                            'processed_count' => $count,
                            'failed_count' => $failed,
                        ]);
                    } else if ($user->isSubclient2User()) {

                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company_id,
                            'subclient_id' => $user->subclient_id,
                            'filename' => $filename,
                            'type' => "update",
                            'num_of_records' => $num_of_records,
                            'processed_count' => $count,
                            'failed_count' => $failed,
                        ]);

                    }
                    //$path = $request->file('csv_file')->storeAs('public/imported_files',$request->file('csv_file')->getClientOriginalName());

                    $contents = Storage::disk('public')->put("imports/" . $filename, $tempfile);


                }
                elseif ($sftp_details->type == 'delete') {
                    $count = 0;
                    $failed = 0;
                    $num_of_records = count($csv_data);
                    foreach ($csv_data as $row) {
                        foreach ($marge_header as $index => $field) {

                            if ($field == 'account_number') {
                                $account_number = $row[$index];
                            }
                        }

                        try{
                            if ($account_number != '') {

                                if ($user->isCompanyUser()) {
                                    $consumer = Consumer::where('company_id', $user->company->id)
                                        ->where('account_number', '=', $account_number)
                                        ->delete();
                                } else if ($user->isSubclient1User()) {
                                    $consumer = Consumer::where('subclient_id', $user->subclient_id)
                                        ->where('account_number', '=', $account_number)
                                        ->delete();

                                } else if ($user->isSubclient2User()) {
                                    $consumer = Consumer::where('subclient_id', $user->subclient_id)
                                        ->where('account_number', '=', $account_number)
                                        ->delete();

                                }

                                $update_consumers += 1;
                                $count++;
                            }
                        }catch (Exception $e){
                            $failed++;
                        }


                    }

                    if ($user->isCompanyUser()) {

                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'filename' => date('YmdHis') . basename($file),
                            'type' => "delete",
                            'num_of_records' => $num_of_records,
                            'processed_count' => $count,
                            'failed_count' => $failed,
                        ]);
                    } else if ($user->isSubclient1User()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'subclient_id' => $user->subclient_id,
                            'filename' => date('YmdHis') . basename($file),
                            'type' => "delete",
                            'num_of_records' => $num_of_records,
                            'processed_count' => $count,
                            'failed_count' => $failed,
                        ]);

                    } else if ($user->isSubclient2User()) {
                        $fileUploadHistory = FileUploadHistory::create([
                            'uploaded_by' => "SFTP Server",
                            'company_id' => $user->company->id,
                            'subclient_id' => $user->subclient_id,
                            'filename' => date('YmdHis') . basename($file),
                            'type' => "delete",
                            'num_of_records' => $num_of_records,
                            'processed_count' => $count,
                            'failed_count' => $failed,
                        ]);
                    }


                    //$path = $request->file('csv_file')->storeAs('public/imported_files',$request->file('csv_file')->getClientOriginalName());
                    $filename = date('YmdHis') . basename($file);
                    $contents = Storage::disk('public')->put("imports/" . $filename, $tempfile);

                    return redirect()->back()->with('success', $update_consumers . ' Consumers Deleted Successfully');
                }
            }
       }

}