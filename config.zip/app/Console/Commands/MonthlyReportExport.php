<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use Illuminate\Http\Request;
use App\Company;
use DB;
use PDF, Auth;
use Mail;
use Excel;
use App\ScheduleExport;
use Carbon\Carbon;
use League\Flysystem\Sftp\SftpAdapter;
use Illuminate\Support\Facades\Storage;
use App\Export\ReportExport;
use App\ReportExportError;
use App\Repositories\CommunicationRepository;
use Maatwebsite\Excel\Excel as BaseExcel;
use Log;
use App\Traits\CreditorReportTrait;

class MonthlyReportExport extends Command
{
    use CreditorReportTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'monthly:export';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'export report monthly';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $communicationRepository;

    private $fromDate, $toDate;

    public function __construct(CommunicationRepository $communicationRepository)
    {
            parent::__construct();
            $this->communicationRepository = $communicationRepository;

            $this->fromDate = new Carbon('first day of last month');
            $this->toDate = new Carbon('last day of last month');
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle(){
        Log::channel('report_command')->info('Monthly Report Export Starting ------');
        try{
            $sftp_details = ScheduleExport::where('frequency','monthly')->where('push',0)->where('admin', 0)->get();

            foreach($sftp_details as $sftp_detail){
                try{
                    Log::channel('report_command')->info('***************start*****************');
                    Log::channel('report_command')->info('Company Export Details :'.json_encode($sftp_detail));
                    
                    $consumers = $this->getCreditorReport($sftp_detail->report_type, $sftp_detail->company_id, $sftp_detail->subclient_id, $this->fromDate, $this->toDate, $sftp_detail->customer_group);
                    
                    if($sftp_detail->delivery_type == "sftp"){
                        config(['filesystems.disks.sftp' => ['driver' => 'sftp'] +
                        $sftp_detail->only(['host','keyfile', 'port', 'username', 'password', 'folder_path', 'timeout'])]);
                        $date = Carbon::now()->format('Y-m-d');
                        $attachment = Excel::raw(new  ReportExport( $consumers),BaseExcel::XLSX);
                        //$contents = Storage::disk('sftp')->get('myfile.txt');
                       $files = Storage::disk('sftp')->put($sftp_detail->folder_path.'/'.$sftp_detail->report_type.'YNreport'.$date.'.csv',$attachment);

                        Log::channel('report_command')->info('Report file uploaded On:'.$sftp_detail->folder_path);
                    }
                    else{
                        $date = Carbon::now()->format('Y-m-d');
                        $this->communicationRepository->sendReportEmail($consumers,$sftp_detail->email_id, $date."_report.csv");
                        Log::channel('report_command')->info('File Sent To :'.$sftp_detail->email_id);
                    }
                }
                catch(\Throwable $ex){
                    Log::channel('report_command')->Error($ex);
                    $error = new ReportExportError();
                    $error->schedule_export_id  = $sftp_detail->id;
                    $error->error = $ex->getMessage();
                    $error->save();
                    continue;


                }
            Log::channel('report_command')->info('****************end****************');
            }
        }
        catch(\Throwable $ex){
            Log::channel('report_command')->error($ex);
            $this->communicationRepository->sendExceptionEmail($ex->getMessage(),"Monthly Report Job");
        }
        Log::channel('report_command')->info('Monthly Report Export End ------');
    }
}