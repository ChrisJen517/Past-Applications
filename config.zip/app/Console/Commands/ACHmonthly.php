<?php

namespace App\Console\Commands;

use App\Mail\TransactionEmail;
use Illuminate\Console\Command;

use App\Company;
use App\Transaction;
use Carbon\Carbon;
use App\RnnTransaction;
use App\Repositories\CommunicationRepository;
use App\Repositories\CampaignRepository;
use Illuminate\Support\Facades\Mail;
use Log;
use PDF;

class ACHmonthly extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'ach:monthly';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Charcge rnn share monthly';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $communicationRepository, $campaignRepository;

    public function __construct(CommunicationRepository $communicationRepository, CampaignRepository $campaignRepository)
    {
        $this->communicationRepository = $communicationRepository;
        $this->campaignRepository = $campaignRepository;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        Log::channel('transaction_command')->info('Monthly ACH Transaction Starting ------');
        try {
            
            $start = new Carbon('first day of last month');
            $from = $start->toDateString();
            $end = new Carbon('last day of last month');
            $to = $end->toDateString();


            $companies = Company::where('billing_schedule', 'Monthly')->get();

            foreach ($companies as $company) {
                try{
                    Log::channel('transaction_command')->info('############## Bill Start #############');
                    Log::channel('transaction_command')->info('Company Name :'. $company->name);
                    Log::channel('transaction_command')->info('Company ID :'. $company->id);
                    Log::channel('transaction_command')->info('From Date :'. $from);
                    Log::channel('transaction_command')->info('To Date :'. $to);

                    $this->chargeCompany($company, $from, $to);

                    Log::channel('transaction_command')->info('############## Bill End ##############');
                }
                catch(\Throwable $ex){
                     Log::channel('transaction_command')->error($ex);
                     continue;
                }
            }
        } 
        catch (\Throwable $ex) {
             Log::channel('transaction_command')->error($ex);
            $this->communicationRepository->sendExceptionEmail($ex->getMessage(), "ACH Weekly Transaction Job");
        }
        Log::channel('transaction_command')->info('Monthly ACH Transaction End  ------');
    }

    public function chargeCompany($company, $from, $to)
    {
        $credit = 0.00;

        $transactionAmount = $company->transactionCharge($from, $to);
        $rnnShare = $company->rnnShareAmount($from, $to);

        $emailcount = $company->communicationCount('email', $from, $to);
        $smscount = $company->communicationCount('sms', $from, $to);

        $emailCharge = $company->communicationCharge('email', $from, $to);
        $smsCharge = $company->communicationCharge('sms', $from, $to);

        $routing = $company->bank1_routing;
        $account = $company->bank1_account_number;

        $firstname = strtoupper(strtok($company->billing_name, ' '));
        $lastname = strtoupper(strstr($company->billing_name, ' '));

        $totalRnnShare = $rnnShare + $emailCharge + $smsCharge;
        $totalRnnShare = number_format($totalRnnShare, 2);


        $date = str_replace("-", "", now()->toDateString());

        Log::channel('transaction_command')->info('------------------');
        Log::channel('transaction_command')->info('Rnn share :'. $rnnShare);
        Log::channel('transaction_command')->info('Email count :'. $emailcount);
        Log::channel('transaction_command')->info('Email Charge  :'. $emailCharge);
        Log::channel('transaction_command')->info('SMS count :'. $smscount);
        Log::channel('transaction_command')->info('SMS Charge :'. $smsCharge);
        Log::channel('transaction_command')->info('------------------');
        Log::channel('transaction_command')->info('Total Amount :'. $totalRnnShare);

        if($totalRnnShare > 0){
            
           if($company->bank1_account_type == 'Checking'){
                $secc = 'CCD';
                $acct = 'C';
                $type = 'B';
            }
            else{
                $secc = 'PPD';
                $acct = 'S';
                $type = 'P';
            }

            $tdtime=date("YmdHis");
            $rand_value = mt_rand(100000000,999999999);

            $packet = "20<FS>2010<FS>10<FS>".$tdtime."<FS><FS>85G01<FS>[NAME]" . strtoupper($company->billing_name) . " [/NAME][PAYER]" . $firstname . "|" . $lastname . "|" . strtoupper($company->bank1_company_address) . "|CITYNAME|" . strtoupper($company->bank1_company_city) . "|" . strtoupper($company->bank1_company_state) . "|" . $company->bank1_company_zip . "[/PAYER][LOCATION]YNFee[/LOCATION][SECC]".$secc."[/SECC][ACCT]".$acct."[/ACCT][TYPE]".$type."[/TYPE][OTHER]".$rand_value."[/OTHER]<FS><FS>" . preg_replace('/\s+/', '', $routing) . "<FS>" . preg_replace('/\s+/', '', $account) . "<FS>9999<FS>" . $totalRnnShare . "<FS>".$rand_value."<FS><FS><FS><FS><FS>EV<FS><FS>CA<FS><FS>" . $company->billing_phone;           


            Log::channel('transaction_command')->info('Packet:'.$packet);

            $curl = curl_init();

            curl_setopt_array($curl, array(
                CURLOPT_URL => "https://spaysys.com/cgi-bin/cgiwrap-noauth/dl4ub/tinqpstpbf.cgi",
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_ENCODING => "",
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 0,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => "POST",
                CURLOPT_POSTFIELDS => array('packet' => $packet),
            ));

            $response = curl_exec($curl);
            curl_close($curl);


            $lastTransaction = RnnTransaction::orderby('created_at','desc')->first();

            if($lastTransaction){
                $rnn_invoice_id = $lastTransaction->rnn_invoice_id +1;
            }
            else{
                $rnn_invoice_id=5000;
            }

            $rnnTransaction = new RnnTransaction();
            $rnnTransaction->company_id = $company->id;
            $rnnTransaction->amount = $totalRnnShare;
            $rnnTransaction->responce = json_encode($response);
            $rnnTransaction->packet = $packet;
            $rnnTransaction->billing_cycle_start = $from;
            $rnnTransaction->billing_cycle_end = $to;
            $rnnTransaction->email_count = $emailcount;
            $rnnTransaction->sms_count = $smscount;
            $rnnTransaction->email_cost = $emailCharge;
            $rnnTransaction->sms_cost = $smsCharge;
            $rnnTransaction->rnn_invoice_id = $rnn_invoice_id;
            $rnnTransaction->reference_number = $rand_value;
            $rnnTransaction->save();

            $transactions = $company->transactions($from, $to);

            foreach ($transactions as $transaction) {
                $transaction->rnn_share_pass = now();
                $transaction->rnn_transaction_id = $rnnTransaction->id;
                $transaction->save();
            }

            $rnn_id = $company->rnn_id;

            if (strpos($rnnTransaction->responce, 'OKAY') != false) {

                Log::channel('transaction_command')->info('Responce:'.$rnnTransaction->responce);
                $rnnTransaction->status = "Successful";
                $rnnTransaction->save();

                $pdf = PDF::loadView('yn.emails.rnn-transaction', compact('rnnTransaction', 'transactionAmount','rnn_id','credit'));

                Mail::to($company->billing_email)->send(new TransactionEmail('Success', $rnnTransaction, $transactionAmount, $pdf, $rnn_id, $credit));
                Mail::to('accounting@rnngroup.com')->send(new TransactionEmail('Success', $rnnTransaction, $transactionAmount, $pdf, $rnn_id, $credit));
                Mail::to('prateekg@rnngroup.com')->send(new TransactionEmail('Success', $rnnTransaction, $transactionAmount, $pdf, $rnn_id, $credit));
                Mail::to('soumabha.sunny1987@gmail.com')->send(new TransactionEmail('Success', $rnnTransaction, $transactionAmount, $pdf, $rnn_id, $credit));

            } 
            else {

                Log::channel('transaction_command')->info('Responce:'.$rnnTransaction->responce);
                $rnnTransaction->status = "Failed";
                $rnnTransaction->save();

                $pdf = PDF::loadView('yn.emails.rnn-transaction', compact('rnnTransaction', 'transactionAmount'));

                Mail::to('soumabha.sunny1987@gmail.com')->send(new TransactionEmail('Failed', $rnnTransaction, $transactionAmount, $pdf));
               
            }
        }
        else{
            Log::channel('transaction_command')->info('Transaction is not initiated because Company payable amount is  0');
        }
    }
}
