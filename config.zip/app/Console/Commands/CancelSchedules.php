<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\ScheduleTransaction;
use Log;

class CancelSchedules extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'cancel:schedules';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Cancel all schedules if consumer have 2 failed payments';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $consumers = ScheduleTransaction::where('status', 'Failed')->select('consumer_id')->groupBy('consumer_id')->get();

        foreach($consumers as $row){

            $failed_count = ScheduleTransaction::where('status', 'Failed')->where('consumer_id', $row->consumer_id)->count();
            
            // If consumer have more than or equal to 2 failed payment cancelled all the payments
            if($failed_count >= 2){
                Log::channel('payment_command')->info('Consumer ID: '.$row->consumer_id.' have more than 2 failed payment');
                $remaining_schedules = ScheduleTransaction::where('status', 'scheduled')->where('consumer_id', $row->consumer_id)->get();
                if(count($remaining_schedules) > 0){
                    foreach ($remaining_schedules as $schedule) {
                        $schedule->status = "Cancelled";
                        $schedule->payment_complete = 3;
                        $schedule->save();

                        Log::channel('payment_command')->info('Schedule ID: '.$schedule->id.' cancelled payment');
                    }
                }
            }
        }

    }
}
