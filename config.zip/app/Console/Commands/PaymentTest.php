<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;


use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;

use App\Consumer;
use Carbon\Carbon;
use DB;
use App\Transaction;
use SoapClient;
use App\Repositories\CommunicationRepository;
use App\Merchant;
use Log;

class PaymentTest extends Command

{

    protected $signature = 'payment:test';

    protected $description = 'Test payment for scheduled transactions';

    public function __construct(CommunicationRepository $communicationRepository)
    {
        $this->communicationRepository = $communicationRepository;
        parent::__construct();
    }

    public function handle()
    {
        Log::channel('payment_command')->info('Payment Command Starting ------');
        try {
            $consumers = DB::table('consumers')
                ->join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
                ->join('companies', 'companies.id', '=', 'consumers.company_id')
                ->join('payment_profiles', 'payment_profiles.id', '=', 'schedule_transactions.payment_profile_id')
                ->whereRaw('DATE(schedule_transactions.schedule_date) = DATE(now())')
                ->where('schedule_transactions.payment_complete', '=', '0')
                ->selectRaw("
            DATE(schedule_transactions.schedule_date) payment_processing_date,
            consumers.id,
            consumers.first_name,
            consumers.last_name,
            consumers.middle_name,
            consumers.company_id,
            consumers.sub_client1_id,
            consumers.sub_client2_id,
            consumers.first_name,
            consumers.last_name,
            consumers.address1,
            consumers.address2,
            consumers.city,
            consumers.state,
            consumers.zip,
            consumers.email1,
            consumers.mobile1,
            consumers.consumer_login_id,
            companies.company_name,
            consumers.current_balance,
            schedule_transactions.amount,
            schedule_transactions.id stid,
            schedule_transactions.transaction_type,
            schedule_transactions.subclient1_share,
            schedule_transactions.subclient2_share,
            schedule_transactions.rnn_share,
            schedule_transactions.processing_charges,
            schedule_transactions.flat_transaction_charges,
            schedule_transactions.company_share,
            schedule_transactions.payment_profile_id,
            payment_profiles.profile_id profileid,
            payment_profiles.payment_profile_id paymentprofileid,
            payment_profiles.shipping_profile_id,
            payment_profiles.account_number,
            payment_profiles.routing_number,
            payment_profiles.method
            ")->limit(5)->get();

            foreach ($consumers as $client) {
                try {
                    Log::channel('payment_command')->info('Payment for consumer Id:' . $client->id);
                    Log::channel('payment_command')->info('Payment initiate --------------------');

                    if ($client->merchant_id) {
                        $merchent = Merchant::where('verified_at', '<>', null)->where('id', $client->merchant_id)->where('merchant_type', $client->method)->first();
                    } else {
                        $merchent = Merchant::when(true, function($query) use ($client) {
                            if($client->sub_client2_id)
                                return $query->where('subclient_id', $client->sub_client2_id);
                            elseif($client->sub_client1_id)
                                return $query->where('subclient_id', $client->sub_client1_id);
                            else
                                return $query->where('company_id', $client->company_id);
                            })->where('verified_at', '!=', null)
                            ->where('merchant_type', $client->method)
                            ->first();
                    }

                    if($client->sub_client2_id)
                        $pay_to = "subclient2";
                    elseif($client->sub_client1_id)
                        $pay_to = "subclient1";
                    else
                        $pay_to = "company";
                    
                    if ($merchent) {
                        Log::channel('payment_command')->info('Paid To: ' . $pay_to);

                        if ($merchent->merchant_name == "authorize") {

                            Log::channel('payment_command')->info('Payment Gateway: authorize.net');
                            $login_id = $merchent->authorize_login_id;
                            $key = $merchent->authorize_transaction_key;

                            Log::channel('payment_command')->info('Key:' . $key . '  Loginid:' . $login_id);

                            if (strtolower($client->method) == "cc") {
                                Log::channel('payment_command')->info('Payment Method: CC');
                                $this->chargeCustomerProfileAuthorizednet($client, $login_id, $key, $pay_to);
                            } elseif (strtolower($client->method) == "ach") {
                                Log::channel('payment_command')->info('Payment Method: ACH');
                                $this->chargeACHAuthorizednet($client, $login_id, $key, $pay_to);
                            }
                            Log::channel('payment_command')->info('Payment Completed consumer Id:' . $client->id);
                            continue;
                        }
                        if ($merchent->merchant_name == "usaepay") {

                            $key = $merchent->usaepay_key;
                            $pin = $merchent->usaepay_pin;

                            Log::channel('payment_command')->info('Payment Gateway: usaepay');
                            Log::channel('payment_command')->info('Key:' . $key . '  Pin:' . $pin);
                            if (strtolower($client->method) == "cc") {
                                Log::channel('payment_command')->info('Payment Method: CC');
                                $this->chargeCustomerProfileUsaEpay($client, $key, $pin, $pay_to);
                            } elseif (strtolower($client->method) == "ach") {
                                Log::channel('payment_command')->info('Payment Method: ACH');
                                $this->chargeACHUsaEpay($client, $key, $pin, $pay_to);
                            }
                            Log::channel('payment_command')->info('Payment Completed consumer Id:' . $client->id);
                            continue;
                        }
                        if ($merchent->merchant_name == "paidyet") {
                            Log::channel('payment_command')->info('Payment Gateway: paidyet');

                            if (strtolower($client->method) == "cc") {
                                Log::channel('payment_command')->info('Payment Method: CC');
                                $this->chargeCustomerProfilePaidYet($client, $pay_to, $merchent->paidyet_subdomain, $merchent->paidyet_key);
                            }
                            elseif (strtolower($client->method) == "ach") {
                                Log::channel('payment_command')->info('Payment Method: CC');
                                $this->chargeACHProfilePaidYet($client, $pay_to, $merchent->paidyet_subdomain, $merchent->paidyet_key);
                            }

                            Log::channel('payment_command')->info('Payment Completed consumer Id:' . $client->id);
                            continue;
                        }
                    }
                } catch (\Throwable $ex) {
                    Log::channel('payment_command')->error('Consumers ID:' . $client->id . ' ' . $ex);
                    $this->communicationRepository->sendExceptionEmail($ex->getMessage(), "Payment Job");
                    continue;
                }
            }
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error($ex);
        }
        Log::channel('payment_command')->info('Payment Command End ------');

    }

    public function chargeCustomerProfileUsaEpay($consumer, $key, $pin, $pay_to)
    {
        try {
            Log::channel('payment_command')->info('usaepay initiate transaction with profile---------');

            $Parameters = array(
                'Command' => 'Sale',
                'Details' => array(
                    'Invoice' => mt_rand(100000000, 999999999),
                    'PONum' => '',
                    'OrderID' => '',
                    'Description' => 'Credit Card Sale',
                    'Amount' => $consumer->amount + $consumer->processing_charges
                )
            );
            $CustNum = $consumer->profileid;

            $Verify = true;
            // instantiate SoapClient object as $client
            $wsdl='https://sandbox.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
//            $wsdl = 'https://www.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
            $client = new SoapClient($wsdl);
            $token = $this->getToken($key, $pin);
            // dd($CustNum);
            $paymethods = $client->getCustomerPaymentMethods($token, $consumer->profileid);

            $PayMethod = $paymethods[0]->MethodID;

            //$res=$client->runCustomerTransaction($token, $CustNum, $Details, $Command, $PayMethod);

            $res = $client->runCustomerTransaction($token, $CustNum, $PayMethod, $Parameters);
            $tid = $res->RefNum;
            if ($res->ResultCode == "A") {
                $status_code = "A";
                $status = "Successful";
                //Update schedule transaction table
            } else {
                $status_code = "";
                $status = "Failed";
            }
            Log::channel('payment_command')->info('Transaction Responce:' . (string)(json_encode($res)));

            //default code
            // $tid = rand(1111111,9999999);
            $this->transferToTransactionTable($consumer, $tid, $res, $status, $status_code, $pay_to);

            Log::channel('payment_command')->info('usaepay Completed transaction with profile-------');
        } catch (\Throwable $ex) {
            //dd($ex);
            Log::channel('payment_command')->error('Consumers ID:' . $consumer->id . ' ' . $ex);
        }
    }

    public function chargeACHUsaEpay($consumer, $key, $pin, $pay_to)
    {
        try {
            Log::channel('payment_command')->info('usaepay initiate transaction with ACH---------');
            $Request = array(
                'AccountHolder' => $consumer->first_name . ' ' . $consumer->last_name,
                'Details' => array(
                    'Description' => 'Transaction',
                    'Amount' => $consumer->amount + $consumer->processing_charges,
                    'Invoice' => mt_rand(100000000, 999999999)
                ),
                'CheckData' => array(
                    'CheckNumber' => mt_rand(100, 9999999),
                    'Routing' => $consumer->routing_number,
                    'Account' => $consumer->account_number,
                    'AccountType' => '',
                    'DriversLicense' => '',
                    'DriversLicenseState' => '',
                    'RecordType' => ''
                )
            );

            $wsdl='https://sandbox.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
//            $wsdl = 'https://www.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
            $client = new SoapClient($wsdl);
            $token = $this->getToken($key, $pin);
            $res = $client->runCheckCredit($token, $Request);

            $tid = $res->RefNum;
            if ($res->ResultCode == "A") {
                $status_code = "A";
                $status = "Successful";
                //Update schedule transaction table
            } else {
                $status_code = "";
                $status = "Failed";
            }
            Log::channel('payment_command')->info('Transaction Responce:' . (string)(json_encode($res)));

            $this->transferToTransactionTable($consumer, $tid, $res, $status, $status_code, $pay_to);

            Log::channel('payment_command')->info('usaepay Completed transaction with ACH-------');
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error('Consumers ID:' . $consumer->id . ' ' . $ex);
        }
    }

    public function chargeCustomerProfileAuthorizednet($client, $login_id, $key, $pay_to)
    {
        try {
            Log::channel('payment_command')->info('authorize.net initiate transaction with profile---------');

            $tresponse = "";
            /* Create a merchantAuthenticationType object with authentication details
            retrieved from the constants file */
            $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
            $merchantAuthentication->setName($login_id);
            $merchantAuthentication->setTransactionKey($key);

            // Set the transaction's refId
            $refId = 'ref' . time();

            $profileToCharge = new AnetAPI\CustomerProfilePaymentType();
            $profileToCharge->setCustomerProfileId($client->profileid);
            $paymentProfile = new AnetAPI\PaymentProfileType();
            $paymentProfile->setPaymentProfileId($client->paymentprofileid);
            $profileToCharge->setPaymentProfile($paymentProfile);

            $order = new AnetAPI\OrderType();
            $order->setInvoiceNumber(mt_rand(100000000, 999999999));
            $order->setDescription("Transaction");

            $transactionRequestType = new AnetAPI\TransactionRequestType();
            $transactionRequestType->setTransactionType("authCaptureTransaction");
            $transactionRequestType->setOrder($order);
            $transactionRequestType->setAmount($client->amount + $client->processing_charges);
            $transactionRequestType->setProfile($profileToCharge);


            $request = new AnetAPI\CreateTransactionRequest();
            $request->setMerchantAuthentication($merchantAuthentication);
            $request->setRefId($refId);
            $request->setTransactionRequest($transactionRequestType);
            $controller = new AnetController\CreateTransactionController($request);
//            $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::PRODUCTION);

            $response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);

            Log::channel('payment_command')->info('Transaction Responce:' . (string)(json_encode($response)));

            if ($response != null) {
                if ($response->getMessages()->getResultCode() == "Ok") {
                    $tresponse = $response->getTransactionResponse();

                    if ($tresponse != null && $tresponse->getMessages() != null) {
                        //Update schedule transaction table
                        $status_code = $tresponse->getResponseCode();
                        $status = "Successful";
                    } else {
                        $status_code = "";
                        $status = "Failed";
                        if ($tresponse->getErrors() != null) {
                            $status_code = $tresponse->getErrors()[0]->getErrorCode();
                            $status = "Failed";
                        }
                    }
                } else {
                    $status_code = "";
                    $status = "Failed";
                    $tresponse = $response->getTransactionResponse();
                    if ($tresponse != null && $tresponse->getErrors() != null) {
                        $status_code = $tresponse->getErrors()[0]->getErrorCode();
                        $status = "Failed";
                    } else {
                        $status_code = $tresponse->getErrors()[0]->getErrorCode();
                        $status = "Failed";
                    }
                }
            } else {
                $status_code = "";
                $status = "Failed";
            }
            $tid = $tresponse->getTransId();

            $this->transferToTransactionTable($client, $tid, $tresponse, $status, $status_code, $pay_to);

            Log::channel('payment_command')->info('authorize.net completed transaction with profile---------');
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error('Consumers ID:' . $client->id . ' ' . $ex);
        }
    }

    public function chargeACHAuthorizednet($client, $login_id, $key, $pay_to)
    {
        try {

            Log::channel('payment_command')->info('authorize.net initiate transaction with ACH---------');

            $tresponse = "";
            /* Create a merchantAuthenticationType object with authentication details
            retrieved from the constants file */
            $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
            $merchantAuthentication->setName($login_id);
            $merchantAuthentication->setTransactionKey($key);

            // Set the transaction's refId
            $refId = 'ref' . time();
            $tid = "";
            // $randomAccountNumber= $clint->account_number;

            // Create the payment data for a Bank Account
            $bankAccount = new AnetAPI\BankAccountType();
            $bankAccount->setAccountType('checking');
            // see eCheck documentation for proper echeck type to use for each situation
            $bankAccount->setEcheckType('WEB');
            $bankAccount->setRoutingNumber($client->routing_number);

            $bankAccount->setAccountNumber($client->account_number);

            $bankAccount->setNameOnAccount($client->first_name . ' ' . $client->last_name);
            $bankAccount->setBankName('NA');

            $paymentBank = new AnetAPI\PaymentType();
            $paymentBank->setBankAccount($bankAccount);

            // Order info
            $order = new AnetAPI\OrderType();
            $order->setInvoiceNumber(mt_rand(100000000, 999999999));
            $order->setDescription("Transaction");

            //create a bank debit transaction

            $transactionRequestType = new AnetAPI\TransactionRequestType();
            $transactionRequestType->setTransactionType("authCaptureTransaction");
            $transactionRequestType->setAmount($client->amount + $client->processing_charges);
            $transactionRequestType->setPayment($paymentBank);
            $transactionRequestType->setOrder($order);
            $request = new AnetAPI\CreateTransactionRequest();
            $request->setMerchantAuthentication($merchantAuthentication);
            $request->setRefId($refId);
            $request->setTransactionRequest($transactionRequestType);
            $controller = new AnetController\CreateTransactionController($request);
//            $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::PRODUCTION);
            $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);

            //dd($response);
            Log::channel('payment_command')->info('Transaction Responce:' . (string)(json_encode($response)));

            if ($response != null) {
                if ($response->getMessages()->getResultCode() == "Ok") {
                    $tresponse = $response->getTransactionResponse();

                    if ($tresponse != null && $tresponse->getMessages() != null) {
                        $status_code = $tresponse->getResponseCode();
                        $status = "Successful";
                        $tid = $tresponse->getTransId();
                    } else {

                        if ($tresponse->getErrors() != null) {
                            $status_code = $tresponse->getErrors()[0]->getErrorCode();
                            $status = "Failed";
                        }
                    }
                } else {
                    $tresponse = $response->getTransactionResponse();
                    if ($tresponse != null && $tresponse->getErrors() != null) {
                        $status_code = $tresponse->getErrors()[0]->getErrorCode();
                        $status = "Failed";
                    } else {
                        $status_code = 'null';
                        $status = "Failed";
                    }
                }
            } else {
                $status_code = "error";
                $status = "Failed";;
            }

            $this->transferToTransactionTable($client, $tid, $tresponse, $status, $status_code, $pay_to);

            Log::channel('payment_command')->info('authorize.net completed  transaction with profile---------');
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error('Consumers ID:' . $client->id . ' ' . $ex);
        }
    }

    public function chargeCustomerProfilePaidYet($client, $pay_to, $subdomain, $key)
    {
        try {
            $token = $this->getPaidYetToken($subdomain, $key);

            $ch = curl_init();

            //gets the card token for the charge
            $url =  "https://api.paidyet.com/v2/searchcontacts";
            $postdata =   ['contact'=> json_encode(['fName' => $client->first_name, 'lName' => $client->last_name, 'email'=> $client->email1])];
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER,array("Authorization: Bearer ".$token));
            curl_setopt($ch, CURLINFO_HEADER_OUT, true);
            $output = curl_exec($ch);


            if(!empty(json_decode($output)->result->contacts[0]->cards[0]->token)){
                $card_token = json_decode($output)->result->contacts[0]->cards[0]->token;

                //charges the card
                $url =  "https://api.paidyet.com/v2/runsale";
                $postdata =   ['token'=> $card_token, 'email'=> $client->email, 'amount' => $client->amount + $client->processing_charges]; 
                curl_setopt($ch, CURLOPT_URL, $url);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER,array("Authorization: Bearer ".$token));
                curl_setopt($ch, CURLINFO_HEADER_OUT, true);
                $output = json_decode(curl_exec($ch));
                curl_close($ch);

                $tid = $output->result->transaction->TRN ?? '';
                $status = $output->result->transaction->result ?? 'failed';
            }
            else {
                $tid = '';
                $status = "Failed";
            }

            $tresponse = $output;

            $this->transferToTransactionTable($client, $tid, $tresponse, $status, "", $pay_to);

            Log::channel('payment_command')->info('PaidYet completed transaction with CC profile---------');
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error('Consumers ID:' . $client->id . ' ' . $ex);
        }
    }

    public function chargeACHProfilePaidYet($client, $pay_to, $subdomain, $key)
    {
        try {
            $token = $this->getPaidYetToken($subdomain, $key);

            $ch = curl_init();
            $url =  "https://api.paidyet.com/v2/runsale";
            $postdata = ['amount'=> $client->amount + $client->processing_charges,'email'=>$client->email1, 
                        'accountholder'=>$client->first_name.' '.$client->last_name, 
                        'account' =>$client->account_number, 
                        'routing'=>$client->routing_number
                        ];
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
            curl_setopt($ch, CURLOPT_HTTPHEADER,array("Authorization: Bearer ".$token  ));
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $output = json_decode(curl_exec($ch));


            $tid = $output->result->transaction->TRN ?? '';
            $status = $output->result->transaction->result ?? 'failed';
            $tresponse = $output;

            $this->transferToTransactionTable($client, $tid, $tresponse, $status, "", $pay_to);

            Log::channel('payment_command')->info('PaidYet completed transaction with ACH profile---------');
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error('Consumers ID:' . $client->id . ' ' . $ex);
        }
    }

    public function getPaidYetToken($subdomain, $key){
        //logs in to the api
        $postdata =   [
            'subdomain' => $subdomain,
            'key' => $key,
            'nonce'   => rand(154678, 10000000),
            'time'=> time()
        ];
        $ch = curl_init();
        $url =  "https://api.paidyet.com/v2/login";
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $output = curl_exec($ch);
        $token = json_decode($output)->result->token;
        curl_close($ch);

        return $token;
    }

    //Transfer and update table
    public function transferToTransactionTable($client, $tid, $tresponse, $status, $status_code, $pay_to)
    {
        try {

            Log::channel('payment_command')->info('Update all tables in database and send mail********');
            $lastTransaction = Transaction::orderby('created_at', 'desc')->first();

            if ($lastTransaction) {
                $rnn_invoice_id = $lastTransaction->rnn_invoice_id + 1;
            } else {
                $rnn_invoice_id = 9000;
            }

            $subclient2 = null;
            $subclient1 = null;

            if ($pay_to == "subclient2")
                $subclient2 = $client->sub_client2_id;
            if ($pay_to == "subclient1")
                $subclient1 = $client->sub_client1_id;

            Transaction::create([
                'transaction_id' => $tid,
                'transaction_type' => $client->transaction_type,
                'consumer_login_id' => $client->consumer_login_id,
                'consumer_id' => $client->id,
                'company_id' => $client->company_id,
                'payment_profile_id' => $client->payment_profile_id,
                'gateway_respnse_raw' => (string)(json_encode($tresponse, true)),
                'status_code' => $status_code,
                'status' => $status,
                'amount' => $client->amount,
                'payment_mode' => $client->method,
                'processing_charges' => $client->processing_charges,
                'flat_transaction_charges' => $client->flat_transaction_charges,
                'rnn_share' => $client->rnn_share,
                'company_share' => $client->company_share,
                'subclient1_share' => $client->subclient1_share,
                'subclient2_share' => $client->subclient2_share,
                'sub_client1_id' => $subclient1,
                'sub_client2_id' => $subclient2,
                'created_at' => now(),
                'updated_at' => now(),
                'rnn_invoice_id' => $rnn_invoice_id
            ]);
            if ($status == "Successful") {
                Log::channel('payment_command')->info('Consumer payment successful **********');

                Log::channel('payment_command')
                    ->info('Consumer Old Current balance:' . $client->current_balance);

                $currentBalance = $client->current_balance - $client->amount;

                Log::channel('payment_command')->info('Consumer New Current balance:' . $currentBalance);

                //update consumer balance and payment compleate status
                DB::table('consumers')->where('id', $client->id)->update(['current_balance' => $currentBalance]);
                DB::table('schedule_transactions')->where('id', $client->stid)
                    ->update(['transaction_id' => $tid,
                        'status' => $status,
                        'payment_complete' => 1]);
                $this->successClient($client, $tid);
                $this->successCompany($client, $tid);
                $this->successSubclient1($client, $tid);
                $this->successSubclient2($client, $tid);

            } else {

                Log::channel('payment_command')->info('Consumer payment failed **********');
                $currentBalance = $client->current_balance;

                DB::table('consumers')->where('id', $client->id)->update(['has_failed_payment' => 1]);

                DB::table('schedule_transactions')->where('id', $client->stid)
                    ->update(['transaction_id' => $tid,
                        'status' => $status,
                        'payment_complete' => 2]);
                $this->failedClient($client, $tid);
                $this->failedCompany($client, $tid);
                $this->failedSubclient1($client, $tid);
                $this->failedSubclient2($client, $tid);
            }
            Log::channel('payment_command')->info('Update completed tables in database and sent mail*****');
        } catch (\Throwable $ex) {
            Log::channel('payment_command')->error('Consumers ID:' . $client->id . ' ' . $ex);
        }
    }

    //Token for usaepay
    public function getToken($key, $pin)
    {
        $sourcekey = $key;
        // generate random seed value
        $seed = time() . rand();
        // make hash value using sha1 function
        $clear = $sourcekey . $seed . $pin;
        $hash = sha1($clear);
        // assembly ueSecurityToken as an array
        $token = array(
            'SourceKey' => $sourcekey,
            'PinHash' => array(
                'Type' => 'sha1',
                'Seed' => $seed,
                'HashValue' => $hash
            ),
            'ClientIP' => '',
        );
        return $token;
    }


    public function successClient($client, $tid)
    {
        $this->communicationRepository->sendSuccessClientEmail($client, $tid);
    }

    public function successCompany($client, $tid)
    {
        $company = DB::table('companies')->where('id', $client->company_id)->first();

        if ($company)
            $this->communicationRepository->sendSuccessCompanyEmail($client, $company, $tid);
    }

    public function successSubclient1($client, $tid)
    {

        $subclient = DB::table('subclients')->where('id', $client->sub_client1_id)->first();

        if ($subclient)
            $this->communicationRepository->sendSuccessCompanyEmail($client, $subclient, $tid);
    }

    public function successSubclient2($client, $tid)
    {
        $subclient = DB::table('subclients')->where('id', $client->sub_client2_id)->first();
        if ($subclient)
            $this->communicationRepository->sendSuccessCompanyEmail($client, $subclient, $tid);
    }

    public function failedClient($client, $tid)
    {
        $this->communicationRepository->sendFailedClientEmail($client, $tid);
    }

    public function failedCompany($client, $tid)
    {
        $company = DB::table('companies')->where('id', $client->company_id)->first();

        if ($company)
            $this->communicationRepository->sendFailedCompanyEmail($client, $company, $tid);
    }

    public function failedSubclient1($client, $tid)
    {
        $subclient = DB::table('subclients')->where('id', $client->sub_client1_id)->first();

        if ($subclient)
            $this->communicationRepository->sendFailedCompanyEmail($client, $subclient, $tid);
    }

    public function failedSubclient2($client, $tid)
    {
        $subclient = DB::table('subclients')->where('id', $client->sub_client2_id)->first();

        if ($subclient)
            $this->communicationRepository->sendFailedCompanyEmail($client, $subclient, $tid);
    }
}

