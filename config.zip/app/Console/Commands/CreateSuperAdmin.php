<?php

namespace App\Console\Commands;

use App\User;
use Illuminate\Console\Command;
use Spatie\Permission\Models\Role;

class CreateSuperAdmin extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'create:superadmin';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Creates a superadmin';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        if(Role::where('name', 'superadmin')->first() == null){
            Role::create(['name' => 'superadmin']);
        }
        $email = $this->ask('Enter email address whom you want to make superadmin');
        $user = User::where('email', $email)->first();
        if($user != null){
            $user->assignRole('superadmin');
            $this->info('User has been made superadmin');
        }else{
            $this->error('User does not exists!');
        }
    }
}
