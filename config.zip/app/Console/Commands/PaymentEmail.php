<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;

use App\Repositories\CommunicationRepository;

use App\Consumer;
use App\ConsumerLogin;
use App\ScheduleTransaction;
use Carbon\Carbon;
use DB;
use Log;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendPaymentReminderMail;
use App\Mail\SendPaymentProfileMail;


class PaymentEmail extends Command
{
    /**
     * To send mail day before schedule 
     */
    protected $signature = 'payment:email';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'schedule-payment mail send ';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $communicationRepository;

    public function __construct(CommunicationRepository $communicationRepository)
    {
        parent::__construct();
        $this->communicationRepository = $communicationRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {

        Log::channel('payment_command')->info('Advance Payment Reminder Starting ------');
        try{

            $tomorrow = date('Y-m-d', strtotime(' +1 day'));
            $scheduleTransactions = ScheduleTransaction::where('schedule_date', $tomorrow)->get();

            foreach($scheduleTransactions as $row){
                Log::channel('payment_command')->info('--------------');
                Log::channel('payment_command')->info('Schedule ID: '.$row->id);
                Log::channel('payment_command')->info('Consumer ID: '.$row->consumer_id);
                $consumerLogin = ConsumerLogin::find($row->consumer->consumer_login_id);

                if($row->payment_profile_id){                 
                    Mail::to($consumerLogin->email)->send(new SendPaymentReminderMail($row));
                }
                else{
                    Log::channel('payment_command')->info('Consumer needs to setup payment profile');
                    Mail::to($consumerLogin->email)->send(new SendPaymentProfileMail($row));
                }
                Log::channel('payment_command')->info('--------------');
            }

        }
        catch(\Throwable $e){
            Log::channel('payment_command')->error($e);
        }

        Log::channel('payment_command')->info('Advance Payment Reminder End ------');
    }
    
}
