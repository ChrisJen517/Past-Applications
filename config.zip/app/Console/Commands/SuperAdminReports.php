<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use App\Export\ReportExport;
use Log;
use App\Traits\SuperAdminReportsTrait;
use Maatwebsite\Excel\Excel as BaseExcel;
use App\ScheduleExport;
use App\Repositories\CommunicationRepository;
use App\Repositories\CampaignRepository;

class SuperAdminReports extends Command
{
    use SuperAdminReportsTrait;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'export:SuperAdminReports {frequency}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Calls the report on a {frequency} basis';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $communicationRepository, $campaignRepository;

    public function __construct(CommunicationRepository $communicationRepository, CampaignRepository $campaignRepository)
    {
        $this->communicationRepository = $communicationRepository;
        $this->campaignRepository = $campaignRepository;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $frequency = $this->argument('frequency');

        switch($frequency){
            case 'daily':
                $from = date('Y-m-d', strtotime('- 1 day'));
            break;
            case 'weekly':
                $from = date('Y-m-d', strtotime('- 1 week'));
            break;
            case 'monthly':
                $from = date('Y-m-d', strtotime('- 1 month'));
            break;
        }
        $to = date('Y-m-d');

        $sftp_details = ScheduleExport::where('frequency', $frequency)->where('push', 0)->where('admin', 1)->get();

        foreach($sftp_details as $sftp_detail){
            $reportData = $this->getSuperAdminReport($sftp_detail->report_type, $sftp_detail->company_id, $from, $to, $sftp_detail->user_id);

            if ($sftp_detail->delivery_type == "sftp") {

                config(['filesystems.disks.sftp' => ['driver' => 'sftp'] +
                $sftp_detail->only(['host', 'keyfile', 'port', 'username', 'password', 'folder_path', 'timeout'])]);

                $date = Carbon::now()->format('Y-m-d');

                $attachment = Excel::raw(new  ReportExport((empty($reportData[0]) ? $reportData[1] : $reportData[0])), BaseExcel::XLSX);
                //$contents = Storage::disk('sftp')->get('myfile.txt');
                $files = Storage::disk('sftp')->put($sftp_detail->folder_path.'/'.$sftp_detail->report_type.'YNreport'.$date.'.csv',$attachment);

                Log::channel('report_command')->info('Report file uploaded On:'.$sftp_detail->folder_path);
            } else {
                $emails = explode(',', $sftp_detail->email_id);
                foreach($emails as $email){
                    $date = Carbon::now()->format('Y-m-d');
                    $this->communicationRepository->sendReportEmail($reportData[0], $email, $sftp_detail->report_type.'_'.$date.'.csv');
                    Log::channel('report_command')->info('File Sent To :"'.$email.'"');
                }
            }
        }
    }
}