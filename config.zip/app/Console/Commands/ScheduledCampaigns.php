<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;
use App\Export\ReportExport;
use Log;
use Maatwebsite\Excel\Excel as BaseExcel;
use App\ScheduledCampaign;
use App\Repositories\CommunicationRepository;
use App\Repositories\CampaignRepository;

class ScheduledCampaigns extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'export:ScheduledCampaigns {frequency}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Calls the campagins on a {frequency} basis';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    protected $communicationRepository, $campaignRepository;

    public function __construct(CommunicationRepository $communicationRepository, CampaignRepository $campaignRepository)
    {
        $this->communicationRepository = $communicationRepository;
        $this->campaignRepository = $campaignRepository;
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $frequency = $this->argument('frequency');

        $campaigns = ScheduledCampaign::where('frequency', $frequency)->where('enabled', true)->get();

        foreach($campaigns as $campaign){
            $running = $this->campaignRepository->createCampaign($campaign->group_id, $campaign->template_id);
            $running->company_id = $campaign->company_id;
            $running->save();
            $running->run();
        }
    }
}