<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
      'App\Console\Commands\PaymentRedirect',
      'App\Console\Commands\DailyReportExport',
      'App\Console\Commands\MonthlyReportExport',
      'App\Console\Commands\WeeklyReportExport',
      'App\Console\Commands\SettledMail',
      'App\Console\Commands\ACHmonthly',
      'App\Console\Commands\ACHweekly',
      'App\Console\Commands\SuperAdminReports'
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        $schedule->command('payment:send')->everyFiveMinutes();

        $schedule->command('payment:email')->dailyAt('7:00');

        $schedule->command('cancel:schedules')->dailyAt('7:15');
                  
        // $schedule->command('monthly:export')
        //           ->monthlyOn(1, '7:00');

        // $schedule->command('weekly:export')
        //           ->weeklyOn(1, '6:30');

        // $schedule->command('daily:export')
        //           ->dailyAt('6:00');

        // $schedule->command('settled:mail')
        //           ->everyThirtyMinutes();

        //$schedule->command('ach:weekly')->weeklyOn(1, '8:00');

        //$schedule->command('ach:monthly')->monthlyOn(1, '9:30');


        //$schedule->command('export:SuperAdminReports daily')->dailyAt('6:00');
        //$schedule->command('export:SuperAdminReports weekly')->weeklyOn(1, '8:00');
        //$schedule->command('export:SuperAdminReports monthly')->monthly(); 
        
        //$schedule->command('export:ScheduledCampaigns daily')->dailyAt('6:00');
        //$schedule->command('export:ScheduledCampaigns weekly')->weeklyOn(1, '8:00');
        //$schedule->command('export:ScheduledCampaigns monthly')->monthly(); 
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
