<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScheduledCampaign extends Model
{
    protected $table = "scheduled_campaigns";

    public function company()
    {
        return $this->belongsTo('App\Company');
    }
}
