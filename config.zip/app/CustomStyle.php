<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CustomStyle extends Model
{
    protected $fillable = [
        'company_id', 'logo_path', 'bg_color', 'button_color', 'font_color'
    ];

    public function company()
    {
        return $this->belongsTo('App\Company');
    }
}
