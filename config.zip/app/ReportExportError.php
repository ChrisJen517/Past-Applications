<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReportExportError extends Model
{
    protected $table = "export_reort_error";
}
