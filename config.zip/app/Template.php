<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Template extends Model
{
    use SoftDeletes;

    protected $guarded = ['id', 'created_at', 'updated_at', 'company_id', 'created_by'];

    public function createdBy()
    {
        return $this->belongsTo('App\User', 'created_by', 'id')->withDefault(['name' => $this->created_by]);
    }

    public function campaigns()
    {
        return $this->hasMany('App\Campaign');
    }

    public function getType()
    {
        $type = '';
        switch (strtolower($this->type)){
            case "email":
                $type = 'Email';
                break;
            case "sms":
                $type = 'SMS';
                break;
            default:
                break;
        }
        return $type;
    }

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($item) {
            $item->company_id = auth()->user()->company_id;
            $item->created_by = auth()->user()->id;
        });
        self::deleting(function ($item) {
            $item->campaigns()->delete();
        });
    }
}
