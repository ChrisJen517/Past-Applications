<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\ToCollection;
use App\CsvData;

class CsvDataImport implements ToCollection
{
    /**
    * @param Collection $collection
    */
    public function collection(Collection $data)
    {
        return $data;

    }
}
