<?php

namespace App\Imports;

use Illuminate\Support\Collection;
use App\Consumer;
use App\ConsumerAccount;

use Maatwebsite\Excel\Concerns\ToCollection;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ConsumerDataImport implements ToCollection, WithHeadingRow
{
    /**
    * @param Collection $collection
    */
    public function collection(Collection $rows)
    {
        foreach($rows as $row){
            Consumer::create([
                'company_profile_id' => $row['company_profile_id'],
                'sub_creditor_id'	 => $row['sub_creditor_id'],
                'sub_creditor_name'	 => $row['sub_creditor_name'],
                'reference_number'	 => $row['reference_number'],
                'account_number'	 => $row['account_number'],
                'unique_customer_id' => $row['unique_customer_id'],
                'full_ssn'	 => \Hash::make($row['full_ssn']),
                'last4ssn'	 => \Hash::make($row['last4ssn']),
                'first_name'	 => $row['first_name'],
                'middle_name'	 => $row['middle_name'],
                'last_name'	    => $row['last_name'],
                'dob'	        => $row['dob'],
                'gender'	 => $row['gender'],
                'address1'	 => $row['address1'],
                'address2'	 => $row['address2'],
                'city'	    => $row['city'],
                'state'	    => $row['state'],
                'zip'	    => $row['zip'],
                'mobile1'	 => $row['mobile1'],
                'mobile2'	 => $row['mobile2'],
                'mobile3'	 => $row['mobile3'],
                'land1'	    => $row['land1'],
                'land2'	    => $row['land2'],
                'land3'	    => $row['land3'],
                'email1'	 => $row['email1'],
                'email2'	 => $row['email2'],
                'email3'	 => $row['email3'],
            ]);

            ConsumerAccount::create([
                'company_id' => $row['company_profile_id'],
                'unique_customer_id' => $row['unique_customer_id'],
                'total_balance'	 => $row['total_balance'],
                'principle_balance'	 => $row['principle_balance'],
                'fees_balance'	 => $row['fees_balance'	],
                'daily_interest_add'	 => $row['daily_interest_add'	],
                'monthly_interest_add'	 => $row[	'monthly_interest_add'	],
                'current_balance'	 => $row[	'current_balance'	],
                'min_one_time_percent'	 => $row[	'min_one_time_percent'	],
                'pif_discount_balance'	 => $row[	'pif_discount_balance'	],
                'pif_discount_percent'	 => $row[	'pif_discount_percent'	],
                'negotiation_rule'	 => $row[	'negotiation_rule'	],
                'pay_setup_discount_percent'	 => $row[	'pay_setup_discount_percent'	],
                'min_monthly_pay_percent'	 => $row[	'min_monthly_pay_percent'	],
                'min_monthly_pay_amount'	 => $row[	'min_monthly_pay_amount'	],
                'max_days_first_pay'	 => $row[	'max_days_first_pay'	],
                'pass_through1'	 => $row[	'pass_through1'	],
                'pass_through2'	 => $row[	'pass_through2'	],
                'pass_through3'	 => $row[	'pass_through3'	],
                'pass_through4'	 => $row[	'pass_through4'	],
                'pass_through5'	 => $row[	'pass_through5'	],

            ]);
        }
    }
}
