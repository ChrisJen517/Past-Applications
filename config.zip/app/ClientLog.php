<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ClientLog extends Model
{
    protected $table = 'client_logs';

    protected $fillable = [
        'id', 'company_id', 'user_id', 'log_message', 'consumer_id'
    ];
}