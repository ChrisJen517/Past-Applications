<?php

namespace App;

use Illuminate\Database\Eloquent\Model;


class ClientApiKey extends Model
{
    protected $table = 'client_api_keys';

    protected $fillable = [
        'company_id', 'api_key'
    ];
    
    public function company()
    {
        return $this->belongsTo('App\Company');
    }
}