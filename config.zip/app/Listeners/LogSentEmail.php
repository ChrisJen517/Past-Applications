<?php

namespace App\Listeners;

use App\CommunicationHistory;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class LogSentEmail
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param object $event
     * @return void
     */
    public function handle($event)
    {
        $to_array = array_keys($event->message->getTo());
        $type = 'email';
        $source = array_key_first($event->message->getFrom());
        $subject = $event->message->getSubject();
        $content = $event->message->getBody();
        $consumer_id =$event->message->getHeaders()->get('consumer')->getValue();
        $company_id = $event->message->getHeaders()->get('company')->getValue();
        $status = 'sent';
        foreach ($to_array as $destination) {
            CommunicationHistory::create(compact('type', 'source', 'destination', 'subject', 'content', 'subject', 'status', 'company_id', 'consumer_id'));
        }
    }
}
