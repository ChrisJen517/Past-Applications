<?php

namespace App;

use App\Jobs\RunCampaignJob;
use App\Jobs\SendEmailJob;
use App\Jobs\SendSMSJob;
use App\Mail\TemplateEmail;
use App\Traits\CompanyIDTrait;
use App\Traits\CreatedByTrait;
use App\Traits\RepositoryTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Facades\Log;

class Campaign extends Model
{
    use SoftDeletes, CompanyIDTrait, CreatedByTrait;

    protected $dates = ['sent_at'];

    protected $fillable = ['group_id', 'template_id'];

    public function template()
    {
        return $this->belongsTo('App\Template');
    }

    public function group()
    {
        return $this->belongsTo('App\Group');
    }

    public function run()
    {
        $this->sent_at = now();
        $this->group_member_count = $this->group->member_count;
        $this->save();
        RunCampaignJob::dispatch($this, auth()->user());
        if ($this->template->type == 'email') {
            $message = "Email Template Sent to Group!";
        }

        if ($this->template->type == 'sms') {
            $message = "SMS Template Sent to Group!";
        }
        return $message;
    }

    public function runBackup()
    {
        $consumers = $this->group->members();
        $template = $this->template;
        $company = auth()->user()->company;
        $this->group_member_count = $this->group->member_count;
        $failed_consumers = $message = '';

        foreach ($consumers as $consumer) {
            if ($template->type == 'email') {
                if ($consumer->email1 != null) {
                    if ($consumer->emailSubscribed()) {
                        Log::channel('communication_command')->info('Sending email to: ' . $consumer->email1 . ' Campaign ID: ' . $this->id);
                        $email = new TemplateEmail($template->content, $template->subject, $consumer, $company);
                        SendEmailJob::dispatch($email, trim($consumer->email1), $consumer, $this);
                        $this->total_sent = $this->total_sent + 1;
                        $this->total_balance_delivered = $this->total_balance_delivered + $consumer->current_balance;
                    } else {
                        Log::channel('communication_command')->error('Error: Sending email to: ' . $consumer->email1 . ' Campaign ID: ' . $this->id . ' Reason: Unsubscribed');
                        $failed_consumers .= ($consumer->id . '<>Consumer has unsubscribed from receiving emails,');
                    }
                } else {
                    Log::channel('communication_command')->error('Error: Sending email to: ' . $consumer->email1 . ' Campaign ID: ' . $this->id . ' Reason: Blank email');
                    $failed_consumers .= ($consumer->id . '<>Consumer does not have email address,');
                }
                $message = "Email Template Sent to Group!";
            }
            if ($template->type == 'sms') {
                if ($consumer->mobile1 != null) {
                    if ($consumer->smsSubscribed()) {
                        Log::channel('communication_command')->info('Sending sms to: ' . $consumer->mobile1 . ' Campaign ID: ' . $this->id);
                        SendSMSJob::dispatch($template->content, trim($consumer->mobile1), $consumer, $this, $company);
                        $this->total_sent = $this->total_sent + 1;
                        $this->total_balance_delivered = $this->total_balance_delivered + $consumer->current_balance;
                    } else {
                        Log::channel('communication_command')->error('Error: Sending sms to: ' . $consumer->mobile1 . ' Campaign ID: ' . $this->id . ' Reason: Unsubscribed');
                        $failed_consumers .= ($consumer->id . '<>Consumer unsubscribed from receiving sms,');
                    }
                } else {
                    Log::channel('communication_command')->error('Error: Sending sms to: ' . $consumer->mobile1 . ' Campaign ID: ' . $this->id . ' Reason: Blank Mobile No');
                    $failed_consumers .= ($consumer->id . '<>Consumer mobile number not present,');
                }
                $message = "SMS Template Sent to Group!";
            }
        }
        $this->failed_consumers = trim($failed_consumers, ',');
        $this->sent_at = now();
        $this->save();
        return $message;
    }

    public function failedConsumers()
    {
        $consumers = [];
        $messages = [];
        $arr = null;

        foreach (explode(',', $this->failed_consumers) as $data) {
            $arr = explode('<>', $data);
            array_push($consumers, $arr[0]);
            if (count($arr) == 2) {
                array_push($messages, $arr[1]);
            } else {
                array_push($messages, '');
            }
        }
        $consumers = Consumer::whereIn('id', $consumers)->get();

        foreach ($consumers as $index => $consumer) {
            $consumer->failed_reason = $messages[$index];
        }
        return $consumers;
    }

    public function failedConsumersCount()
    {
        $consumers = [];
        $messages = [];
        $arr = null;

        foreach (explode(',', $this->failed_consumers) as $data) {
            $arr = explode('<>', $data);
            array_push($consumers, $arr[0]);
            if (count($arr) == 2) {
                array_push($messages, $arr[1]);
            } else {
                array_push($messages, '');
            }
        }
        return  Consumer::whereIn('id', $consumers)->count();
    }

    protected static function boot()
    {
        parent::boot();
        static::creating(function ($item) {
            if(!empty(auth()->user())){
                $item->company_id = auth()->user()->company_id;
                $item->created_by = auth()->user()->id;
            }
        });
    }
}