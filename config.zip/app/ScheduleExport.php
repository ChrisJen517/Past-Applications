<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ScheduleExport extends Model
{ 
	protected $table = "schedule_export";
}
