<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConsumerUnsubscription extends Model
{
    protected $table = 'consumer_unsubscribes';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    public function Consumer()
    {
        return $this->belongsTo('App\Consumer', 'consumer_id', 'id');
    }

    public function Company()
    {
        return $this->belongsTo('App\Company', 'company_id', 'id');
    }

    public function emailSubscribed()
    {
        return ($this->email != null);
    }

    public function smsSubscribed()
    {
        return ($this->phone != null);
    }

}


