<?php

namespace App;

use App\Traits\CompanyIDTrait;
use Illuminate\Database\Eloquent\Model;

class ConsumerActivity extends Model
{
    use CompanyIDTrait;

    protected $fillable = [
    	'user_id',
        'ip_address',
        'session_id',
        'user_agent',
        'logged_out_at',
        'company_id',
        'consumer_id',
        'sub_client1_id',
        'sub_client2_id',
        'event_title',
        'event_desc',
    ];

    public function consumer()
    {
        return $this->belongsTo('App\Consumer', 'consumer_id', 'id');
    }
}
