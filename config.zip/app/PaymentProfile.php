<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PaymentProfile extends Model
{
    protected $fillable = [
    	'consumer_id',
		'company_id',
		'subclient1_id',
		'subclient2_id',
		'method',
		'last4digit',
		'gateway_token',
		'routing_number',
		'account_number',
		'expirity',
    ];

}
