<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConsumerNegotiation extends Model
{
    protected $fillable = [
    	'consumer_id',
		'company_id',
		'negotiation_type',
		'negotiate_amount',
		'monthly_amount',
		'no_of_installments',
		'last_month_amount',
		'installment_type',
		'first_pay_date',
		'one_time_settlement',
		'communication_type',
        'email',
        'phone',
        'reason',
        'note',
        'active_negotiation',
        'counter_monthly_amount',
        'counter_one_time_amount',
        'counter_first_pay_date',
        'counter_negotiate_amount',
        'offer_accepted',
        'counter_offer_accepted',
        'approved_by',
    ];

    public function consumer()
    {
        return $this->belongsTo('App\Consumer');
    }
}
