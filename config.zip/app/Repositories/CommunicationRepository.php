<?php

namespace App\Repositories;

use App\CommunicationHistory;
use App\Jobs\SendEmailJob;
use App\Mail\CompanyApproveEmail;
use App\Mail\CompanyRejectEmail;
use App\Mail\PasswordResetEmail;
use App\Mail\PersonalizedLinkUpdateEmail;
use App\Mail\ProfileCompleteEmail;
use App\Mail\ProfileCompleteNotificationEmail;
use App\Mail\RegistrationEmail;
use App\Mail\RegistrationNotificationEmail;
use App\Mail\SubclientCreationNotification;
use App\Mail\Transaction;
use App\Mail\TransactionEmail;
use App\Mail\UserCreateEmail;
use App\Mail\CounterOfferEmail;
use App\Mail\SuccessClientEmail;
use App\Mail\CompanyPaymentSuccess;
use App\Mail\ClientFailedEmail;
use App\Mail\CompanyFailedEmail;
use App\Mail\SettledEmail;
use App\Mail\AcceptOfferEmail;
use App\Mail\DeclineOfferEmail;
use App\Mail\ReportEmail;
use App\Mail\ExceptionMail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Twilio\Rest\Client;

class CommunicationRepository
{

    public function sendUserCreateEmail($user, $password)
    {
        SendEmailJob::dispatch(new UserCreateEmail($user, $password), $user->email);
    }

    public function sendPasswordResetEmail($user, $password)
    {
        SendEmailJob::dispatch(new PasswordResetEmail($user, $password), $user->email);
    }

    public function sendCompanyApproveEmail($company)
    {
        SendEmailJob::dispatch(new CompanyApproveEmail($company), $company->account_contact_email);
    }

    public function sendCompanyRejectEmail($company)
    {
        SendEmailJob::dispatch(new CompanyRejectEmail($company), $company->account_contact_email);
    }

    public function sendProfileCompleteEmail($company)
    {
        SendEmailJob::dispatch(new ProfileCompleteEmail($company), $company->account_contact_email);
        SendEmailJob::dispatch(new ProfileCompleteNotificationEmail($company), config('app.common.rnn-admin-email'));
    }

    public function sendRegistrationEmail($user)
    {
        SendEmailJob::dispatch(new RegistrationEmail($user), $user->email);
        SendEmailJob::dispatch(new RegistrationNotificationEmail($user), config('app.common.rnn-admin-email'));
    }

    public function sendCounterOfferEmail($consumer)
    {
        SendEmailJob::dispatch(new CounterOfferEmail($consumer), $consumer->email1);
    }

    public function sendSuccessClientEmail($consumer, $tid)
    {
        SendEmailJob::dispatch(new SuccessClientEmail($consumer, $tid), $consumer->email1);
        SendEmailJob::dispatch(new SuccessClientEmail($consumer, $tid), 'soumabha.sunny1987@gmail.com');
    }

    //This is for company and subclient


    public function sendSuccessCompanyEmail($consumer, $company, $tid)
    {
        SendEmailJob::dispatch(new CompanyPaymentSuccess($consumer, $tid), $company->account_contact_email);
    }

    public function sendFailedClientEmail($consumer, $tid)
    {
        SendEmailJob::dispatch(new ClientFailedEmail($consumer, $tid), $consumer->email1);
        SendEmailJob::dispatch(new ClientFailedEmail($consumer, $tid), 'soumabha.sunny1987@gmail.com');
    }

    public function sendFailedCompanyEmail($consumer, $company, $tid)
    {
        SendEmailJob::dispatch(new CompanyFailedEmail($consumer, $tid), $company->account_contact_email);
    }

    public function sendSettledEmail($consumer, $amount)
    {
        SendEmailJob::dispatch(new SettledEmail($consumer, $amount), $consumer->email1);
        SendEmailJob::dispatch(new SettledEmail($consumer, $amount), 'soumabha.sunny1987@gmail.com');
    }

    public function sendAcceptOfferEmail($consumer)
    {
        SendEmailJob::dispatch(new AcceptOfferEmail($consumer), $consumer->email1);
    }

    public function sendDeclineOfferEmail($consumer)
    {
        SendEmailJob::dispatch(new DeclineOfferEmail($consumer), $consumer->email1);
    }

    public function sendPersonalizedLinkUpdateEmail($old_link, $new_link, $company)
    {
        SendEmailJob::dispatch(new PersonalizedLinkUpdateEmail($old_link, $new_link, $company), config('app.common.rnn-admin-email'));
    }

    public function sendReportEmail($attachment, $email, $name = "report.csv")
    {
        SendEmailJob::dispatch(new ReportEmail($attachment, $name), $email);
    }

    public function sendSubclientCreationEmail($subclient)
    {
        SendEmailJob::dispatch(new SubclientCreationNotification($subclient), config('app.common.rnn-admin-email'));
    }

    //Exception Mail
    public function sendExceptionEmail($ex, $source)
    {
        SendEmailJob::dispatch(new ExceptionMail($ex, $source), 'soumabha.sunny1987@gmail.com');
        //SendEmailJob::dispatch(new ExceptionMail($ex, $source), 'prateekg@rnngroup.com');
    }

    public static function createCommunicationHistory($type, $email, $phone, $content, $status, $subject = null, $consumer = null, $campaign = null)
    {
        $comm = new CommunicationHistory();
        $comm->fill([
            'company_id' => $consumer ? $consumer->company_id : null,
            'consumer_id' => $consumer ? $consumer->id : null,
            'sub_client1_id' => $consumer ? $consumer->sub_client1_id : null,
            'sub_client2_id' => $consumer ? $consumer->sub_client2_id : null,
            'group_id' => $campaign ? $campaign->group_id : null,
            'template_id' => $campaign ? $campaign->template_id : null,
            'email' => $email,
            'phone' => $phone,
            'status' => $status,
            'template_type' => $type,
            'content' => $content,
            'subject' => $subject,
            'campaign_id' => $campaign ? $campaign->id : null,
        ]);

        if($type=='sms'){
            $comm->smssegment = ceil(strlen($content) / config('app.template.max_sms_length'));
        }

        $comm->save();
    }

}