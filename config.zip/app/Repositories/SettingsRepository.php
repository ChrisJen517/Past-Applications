<?php

namespace App\Repositories;

use App\Group;
use App\SFTPDetails;
use App\Traits\RepositoryTrait;

class SettingsRepository
{

    public function sftpUpdateValidationRules()
    {
        return config('app.sftp.update_validation_rules');
    }

    public function createSFTPDetails($type, $company_id)
    {
        $sd = SFTPDetails::where('type', $type)->where('company_id', $company_id)->first();
        if ($sd == null) {
            SFTPDetails::create(['type' => $type]);
        }
    }

    public function getSFTPDetails($type, $company_id)
    {
        return SFTPDetails::where('type', $type)->where('company_id', $company_id)->first();
    }

    public function updateSFTPDetails($company_id, $params)
    {
        return SFTPDetails::where('company_id', $company_id)->where('type', $params['type'])->first()->update($params);
    }

}
