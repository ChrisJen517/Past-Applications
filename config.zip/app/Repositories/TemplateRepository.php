<?php

namespace App\Repositories;

use App\Template;
use App\Traits\CompanyIDTrait;
use App\Traits\RepositoryTrait;
use App\User;

class TemplateRepository
{
    use RepositoryTrait, CompanyIDTrait;

    protected $model = 'App\Template';

    protected $campaignRepository, $communicationRepository;

    public function __construct(CampaignRepository $campaignRepository, CommunicationRepository $communicationRepository)
    {
        $this->campaignRepository = $campaignRepository;
        $this->communicationRepository = $communicationRepository;
    }

    public function creationValidationRules()
    {
        return config('app.template.creation_validation_rules');
    }

    public function updateValidationRules()
    {
        return config('app.template.update_validation_rules');
    }

    public function templates($company_id)
    {
        return Template::with(['createdBy'])->where('company_id', $company_id)->latest()->get();
    }

    public function enabledTemplates($company_id)
    {
        return Template::with(['createdBy'])->where('enabled', true)->where('company_id', $company_id)->latest()->get();
    }

    public function disabledTemplates($company_id)
    {
        return Template::with(['createdBy'])->where('enabled', false)->where('company_id', $company_id)->latest()->get();
    }

    public function attachGroup($attach_group, $template_id)
    {
        $message = '';
        if ($attach_group) {
            $campaign = $this->campaignRepository->createCampaign($attach_group, $template_id);
            $message = $campaign->run();
        }
        return $message;
    }

}
