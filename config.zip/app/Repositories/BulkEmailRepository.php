<?php

namespace App\Repositories;

use App\BulkEmail;
use App\CommunicationHistory;
use App\Mail\TemplateEmail;
use App\Template;
use App\Traits\RepositoryTrait;
use App\User;
use Illuminate\Support\Facades\Mail;
use Twilio\Rest\Client;

class BulkEmailRepository
{
    use RepositoryTrait;

    protected $model = 'App\BulkEmail';

    public function creationValidationRules()
    {
        return config('app.bulk-email.creation_validation_rules');
    }

    public function updateValidationRules()
    {
        return config('app.bulk-email.update_validation_rules');
    }

    public function bulkEmails($company_id)
    {
        return BulkEmail::where('company_id', $company_id)->paginate(config('app.bulk-email.paginate_rows'));
    }

    public function send($id)
    {
        $bulkEmail = $this->get('id', $id, ['group.members', 'template', 'company']);
        foreach ($bulkEmail->group->members as $member) {
            $consumer = $member->consumer;
            $content = strtr($bulkEmail->template->content, [':company_name' => $bulkEmail->company->company_name, ':consumer_name' => $consumer->first_name]);
            $subject = $bulkEmail->template->subject;
            Mail::to($consumer->email1)->send(new TemplateEmail($content, $subject, $consumer->id, $bulkEmail->company_id));
        }
    }

    public function sendSMS()
    {
        $twillio_sid = env('TWILIO_SID');
        $twilio_auth_token = env('TWILIO_AUTH_TOKEN');
        $twilio_number = env('TWILIO_PHONE_NO');

        $client = new Client($twillio_sid, $twilio_auth_token);
        $client->messages->create(
        // Where to send a text message (your cell phone?)
            '+919674119708',
            array(
                'from' => $twilio_number,
                'body' => 'Good Lord!'
            )
        );
    }

}
