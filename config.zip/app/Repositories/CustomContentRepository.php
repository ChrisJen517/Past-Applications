<?php

namespace App\Repositories;

use App\CustomContent;
use App\Group;
use App\Subclient;
use App\Traits\RepositoryTrait;
use DB;

class CustomContentRepository
{
    use RepositoryTrait;

    protected $model = 'App\CustomContent';

    public function updateTermsConditionsValidationRules()
    {
        return [
            'subclient_id' => 'required',
            'content' => 'required',
        ];
    }

    public function getTermsConditions($company_id)
    {
        return CustomContent::where('company_id', $company_id)->where('title', 'terms-conditions')->get();
    }

    public function updateTermsConditions($company, $params)
    {
        if ($params['subclient_id'] == 'all') {
            $custom_content = CustomContent::where('company_id', $company->id)->where('subclient_id', null)->first();
            if ($custom_content == null) {
                CustomContent::create(['company_id' => $company->id, 'subclient_id' => null,
                    'title' => 'terms-conditions', 'content' => $params['content']]);
            } else {
                $custom_content->update(['content' => $params['content']]);
            }
        }

        if ($params['subclient_id'] == 'all') {
            $subclients = $company->subclients;
        } else {
            $subclients = Subclient::where('id', $params['subclient_id'])->get();
        }

        if (count($subclients) > 0) {
            foreach ($subclients as $subclient) {
                $custom_content = CustomContent::where('company_id', $company->id)->where('subclient_id', $subclient->id)->first();
                if ($custom_content == null) {
                    CustomContent::create(['company_id' => $company->id, 'subclient_id' => $subclient->id,
                        'title' => 'terms-conditions', 'content' => $params['content']]);
                } else {
                    $custom_content->update(['content' => $params['content']]);
                }
            }
        }
    }

    public function customContentValidationRules()
    {
        return ['title' => 'required', 'content' => 'required'];
    }

    public function getCustomContent($company_id)
    {
        return CustomContent::where('company_id', $company_id)->whereIn('title', config('app.company.content_titles'))->get();
    }

    public function updateCustomContent($params, $company_id)
    {
        $content = CustomContent::where('company_id', $company_id)->where('title', $params['title'])->first();
        if ($content) {
            $content->update($params);
        } else {
            CustomContent::create($params + ['company_id' => $company_id]);
        }
        return back()->with('success', 'Content has been updated!');
    }

}