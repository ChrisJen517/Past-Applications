<?php

namespace App\Repositories;

use App\Group;
use App\Traits\RepositoryTrait;

class GroupRepository
{
    use RepositoryTrait;

    protected $model = 'App\Group';

    protected $campaignRepository;

    public function __construct(CampaignRepository $campaignRepository)
    {
        $this->campaignRepository = $campaignRepository;
    }

    public function creationValidationRules()
    {
        return config('app.group.creation_validation_rules');
    }

    public function updateValidationRules()
    {
        return config('app.group.update_validation_rules');
    }

    public function groups($company_id)
    {
        return Group::with(['createdBy'])->where('company_id', $company_id)->latest()->get();
    }

    public function enabledGroups($company_id)
    {
        return Group::with(['createdBy'])->where('enabled', true)->where('company_id', $company_id)->latest()->get();
    }

    public function disabledGroups($company_id)
    {
        return Group::with(['createdBy'])->where('enabled', false)->where('company_id', $company_id)->latest()->get();
    }

    public function attachTemplate($group_id, $attach_template)
    {
        $message = '';
        if($attach_template){
            $campaign = $this->campaignRepository->createCampaign($group_id, $attach_template);
            $message = $campaign->run();
        }
        return $message;
    }

    public function createMembers($group, $params)
    {
        if (count($params) > 0) {
            $group->members()->delete();
            $params = array_map(function ($item) {
                return ['consumer_id' => $item];
            }, $params['consumer_id']);
            $group->members()->createMany($params);
        }
    }

    public function createNotJoinedGroup($company)
    {
        $this->create(['name' => 'Not Joined', 'description' => 'Customers who are yet to join',
            'customer_status_rule' => json_encode(['not_joined']), 'customer_custom_rule' => json_encode([])]);
    }
}
