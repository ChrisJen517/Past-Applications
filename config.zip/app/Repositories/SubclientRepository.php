<?php

namespace App\Repositories;

use App\Company;
use App\Subclient;
use App\Traits\RepositoryTrait;

class SubclientRepository
{
    use RepositoryTrait;

    /**
     * @var MerchantRepository
     */
    private $merchantRepository, $communicationRepository;

    /**
     * @var MerchantRepository
     */

    public function __construct(MerchantRepository $merchantRepository, CommunicationRepository $communicationRepository)
    {
        $this->merchantRepository = $merchantRepository;
        $this->communicationRepository = $communicationRepository;
    }

    protected $model = 'App\Subclient';

    public function types()
    {
        return config('app.subclient.types');
    }

    public function updateValidationRules()
    {
        return config('app.subclient.update_validation_rules');
    }

    public function creationValidationRules($step = null)
    {
        if ($step) {
            return config('app.subclient.creation_validation_rules.' . $step);
        } else {
            $res = [];
            foreach (config('app.subclient.creation_validation_rules') as $arr => $value) {
                $res += $value;
            }
            return $res;
        }
    }

    public function updateTermValidationRules()
    {
        return config('app.subclient.term_validation_rules');
    }

    public function parentIds($subclient_type, $company_id)
    {
        if ($subclient_type == 'subclient2') {
            return Subclient::where('company_id', $company_id)->where('subclient_type', 'subclient1')->get()->pluck('subclient_name', 'id');
        }
        return [];
    }

    public function subclients($company_id, $paginate = true)
    {
        $query = Subclient::where('company_id', $company_id);
        if ($paginate) {
            return $query->paginate(config('app.subclient.paginate_rows'));
        } else {
            return $query->get();
        }
    }

    public function createSubclient($params)
    {
        $subclient_params = collect($params)->except(array_keys($this->merchantRepository->creationRulesSubclient()))->toArray();
        $subclient = $this->create($subclient_params);
        if (collect($params)->has('merchant_name_cc')) {
            if ($params['merchant_name_cc']) {
                $merchant_params = collect($params)->only(array_keys($this->merchantRepository->ccRules()))->toArray();
                $filtered_params = [];
                foreach($merchant_params as $key => $value){
                    $filtered_params[str_replace('_cc', '', $key)] = $value;
                }
                $this->merchantRepository->registerMerchant($subclient->company_id, $filtered_params + ['subclient_id'
                => $subclient->id]);
            }
        }
        if (collect($params)->has('merchant_name_ach')) {
            if ($params['merchant_name_ach']) {
                $merchant_params = collect($params)->only(array_keys($this->merchantRepository->achRules()))->toArray();
                $filtered_params = [];
                foreach($merchant_params as $key => $value){
                    $filtered_params[str_replace('_ach', '', $key)] = $value;
                }
                $this->merchantRepository->registerMerchant($subclient->company_id, $filtered_params + ['subclient_id' =>
                $subclient->id]);
            }
        }
        $this->communicationRepository->sendSubclientCreationEmail($subclient);
        return $subclient;
    }

    public function getSuccessMessage($subclient)
    {
        $message = 'Subclient: ' . $subclient->name . ' has been successfully created';
        if ($subclient->subclient_type == 'Subclient1') {
            $message = "Please use Unique Sub Client 1 ID: " . $subclient->id . " in your import file to auto assign customers to this client";
        }
        if ($subclient->subclient_type == 'Subclient2') {
            $message = "Please use Unique Sub Client 1 ID: " . $subclient->parent_id . " & Sub CLient 2 ID: " . $subclient->id . " in your import file to auto assign customers to this sub client";
        }
        return $message;
    }

    // Superadmin methods
    public function getAllSubclients()
    {
        return Subclient::withTrashed()->latest()->paginate(config('app.subclients.paginate_rows'));
    }
}
