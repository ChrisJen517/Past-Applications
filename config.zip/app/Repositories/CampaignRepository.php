<?php

namespace App\Repositories;

use App\Campaign;
use App\Traits\RepositoryTrait;

class CampaignRepository
{
    use RepositoryTrait;

    protected $model = 'App\Campaign';

    public function creationValidationRules()
    {
        return config('app.campaign.creation_validation_rules');
    }

    public function createCampaign($group_id, $template_id)
    {
        $campaign = ['group_id' => $group_id, 'template_id' => $template_id];
        return $this->create($campaign);
    }

    public function clone($campaign)
    {
        return $this->createCampaign($campaign->group_id, $campaign->template_id);
    }

    public function all($company_id)
    {
        return Campaign::with(['template', 'group'])->where('company_id', $company_id)->latest()->get();
    }

    public static function filterCampaigns($company_id, $type, $from, $to)
    {
        return Campaign::whereHas('template', function($query) use ($type){
            $query->where('type', $type);
        })->whereRaw("date(sent_at) between '$from' and '$to'")->where('company_id', $company_id)->get();
    }

}
