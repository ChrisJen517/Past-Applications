<?php

namespace App\Repositories;

use App\Traits\RepositoryTrait;
use App\User;
use Illuminate\Support\Facades\Hash;

class UserRepository
{
    use RepositoryTrait;

    protected $model = 'App\User';

    protected $communicationRepository;

    public function __construct(CommunicationRepository $communicationRepository)
    {
        $this->communicationRepository = $communicationRepository;
    }

    public function registrationValidationRules()
    {
        return config('app.user.registration_validation_rules');
    }

    public function creationValidationRules()
    {
        return config('app.user.creation_validation_rules');
    }

    public function updateValidationRules()
    {
        return config('app.user.update_validation_rules');
    }

    public function companyUsers($user)
    {
        if ($user->isCompanyUser()) {
            $users = User::where('company_id', $user->company_id)->paginate(config('app.user.paginate_rows'));
        } else {
            $users = User::where('company_id', $user->company_id)->where('subclient_id', $user->subclient_id)->paginate(config('app.user.paginate_rows'));
        }
        return $users;
    }

    public function createUser($params, $company)
    {
        $password = str_random(8);
        if (!auth()->user()->isCompanyUser()) {
            $params['subclient_id'] = auth()->user()->subclient_id;
        }
        $user = $this->create(['password' => Hash::make($password)] + $params);
        $user->registerCompany($company);
        $this->communicationRepository->sendUserCreateEmail($user, $password);
        return $user;
    }

    public function resetPassword($id)
    {
        $password = str_random(10);
        $user = User::findOrFail($id);
        if (!auth()->user()->isCompanyUser()) {
            if($user->subclient_id != auth()->user()->subclient_id){
                return false;
            }
        }
        $user->fill(['password' => Hash::make($password)])->save();
        $this->communicationRepository->sendPasswordResetEmail($user, $password);
        return true;
    }

    public function toggleBlock($id, $blocked_by)
    {
        $user = User::findOrFail($id);
        if ($user->blocked_at != null) {
            $user->blocked_at = null;
        } else {
            $user->blocked_at = now();
        }
        $user->blocked_by = $blocked_by;
        $user->save();
    }

    //Superadmin methods
    public function getAllUsers()
    {
        return User::withTrashed()->latest()->paginate(config('app.user.paginate_rows'));
    }

}
