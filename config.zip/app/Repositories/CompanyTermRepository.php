<?php

namespace App\Repositories;

use App\CompanyTerm;
use App\Group;
use App\Traits\RepositoryTrait;

class CompanyTermRepository
{
    use RepositoryTrait;

    protected $model = 'App\CompanyTerm';

    public function updateValidationRules()
    {
        return config('app.company-term.update_validation_rules');
    }

    public function companyTerms($company_id, $paginate = true)
    {
        $terms = null;
        if ($paginate) {
            $terms = CompanyTerm::where('company_id', $company_id)->paginate(config('app.group.paginate_rows'));
        } else {
            $terms = CompanyTerm::where('company_id', $company_id)->get();
        }
        return $terms;
    }
}
