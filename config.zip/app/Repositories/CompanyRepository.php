<?php

namespace App\Repositories;

use App\Company;
use App\Traits\RepositoryTrait;
use function array_only;

class CompanyRepository
{
    use RepositoryTrait;

    protected $model = 'App\Company';

    private $merchantRepository;

    public function __construct(MerchantRepository $merchantRepository)
    {
        // TODO - Add functionality
        $this->merchantRepository  = $merchantRepository;
    }

    public function registrationValidationRules()
    {
        return config('app.company.registration_validation_rules');
    }

    public function profileValidationRules($step)
    {
        return config('app.company.profile_validation_rules.'.$step);
    }

    public function registrationFields()
    {
        return array_keys(config('app.company.registration_validation_rules'));
    }

    public function masterTermsRules()
    {
        return config('app.company.master_terms_validation_rule');
    }

    public function groupMasterTermsRules()
    {
        return config('app.company.group_master_terms_validation_rule');
    }

    public function companies()
    {
        return Company::where('id', auth()->user()->company_id)->paginate(config('app.company.paginate_rows'));
    }

    public function createCompanyTerms($id, $params)
    {
        $company = $this->get('id', $id);
        $company->companyTerm()->create($params);
    }

    public function updateProfile($company_id, $params)
    {
        if(collect($params)->has('merchant_name')){
            if($params['merchant_name']){
                $merchant_params = collect($params)->only(array_keys($this->merchantRepository->creationValidationRules()))->toArray();
                $this->merchantRepository->registerMerchant($company_id, $merchant_params);
            }
            return;
        }
        $status = $this->update('id', $company_id, $params);
    }

    public function updateCommunicationLimit($company_id, $sms_limit, $email_limit)
    {
        $company = $this->getByID($company_id);
        $company->sms_limit = $sms_limit;
        $company->email_limit = $email_limit;
        $company->save();
    }

    // Superadmin Methods

    public function getAllCompanies()
    {
        return Company::withTrashed()->latest()->get();
    }

}