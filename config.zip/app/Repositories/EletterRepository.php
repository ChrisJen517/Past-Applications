<?php

namespace App\Repositories;

use App\Eletter;
use App\Traits\CompanyIDTrait;
use App\Traits\RepositoryTrait;
use App\User;

class EletterRepository
{
    use RepositoryTrait, CompanyIDTrait;

    protected $model = 'App\Eletter';

    protected $campaignRepository, $communicationRepository;

    public function __construct(CampaignRepository $campaignRepository, CommunicationRepository $communicationRepository)
    {
        $this->campaignRepository = $campaignRepository;
        $this->communicationRepository = $communicationRepository;
    }

    public function creationValidationRules()
    {
        return config('app.eletter.creation_validation_rules');
    }

    public function updateValidationRules()
    {
        return config('app.eletter.update_validation_rules');
    }

    public function eletters($company_id)
    {
        return Eletter::where('company_id', $company_id)->latest()->get();
    }

    public function enabledEletters($company_id)
    {
        return Eletter::where('enabled', true)->where('company_id', $company_id)->latest()->get();
    }

    public function disabledEletters($company_id)
    {
        return Eletter::where('enabled', false)->where('company_id', $company_id)->latest()->get();
    }

    public function attachGroup($attach_group, $eletter_id)
    {
        $message = '';
        if ($attach_group) {
            $campaign = $this->campaignRepository->createCampaign($attach_group, $eletter_id);
            $message = $campaign->run();
        }
        return $message;
    }

}