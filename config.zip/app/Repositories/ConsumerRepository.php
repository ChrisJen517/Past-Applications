<?php

namespace App\Repositories;

use App\Consumer;
use App\Template;
use App\Traits\RepositoryTrait;
use App\User;

class ConsumerRepository
{
    use RepositoryTrait;

    protected $model = 'App\Consumer';

    public function searchConsumers($params)
    {
        $query = Consumer::with([]);
        foreach ($params as $key => $value) {
            if($value != null){
                $query->where($key, 'like', "%$value%");
            }
        }
        return $query->get();
    }
}
