<?php

namespace App\Repositories;

use App\Merchant;
use App\Template;
use App\Traits\RepositoryTrait;
use App\User;

class MerchantRepository
{
    use RepositoryTrait;

    protected $model = 'App\Merchant';

    public function creationValidationRules()
    {
        return config('app.company.profile_validation_rules.step-3');
    }

    public function creationRulesSubclient()
    {
        return $this->ccRules() + $this->achRules();
    }

    public function ccRules()
    {
        return [
            'merchant_name_cc' => 'nullable',
            'merchant_type_cc' => 'nullable',
            'usaepay_key_cc' => 'nullable',
            'usaepay_pin_cc' => 'nullable',
            'authorize_login_id_cc' => 'nullable',
            'authorize_transaction_key_cc' => 'nullable',
            'authorize_key_cc' => 'nullable',
            'paidyet_subdomain_cc' => 'nullable',
            'paidyet_key_cc' => 'nullable',
        ];
    }

    public function achRules()
    {
        return [
            'merchant_name_ach' => 'nullable',
            'merchant_type_ach' => 'nullable',
            'usaepay_key_ach' => 'nullable',
            'usaepay_pin_ach' => 'nullable',
            'authorize_login_id_ach' => 'nullable',
            'authorize_transaction_key_ach' => 'nullable',
            'authorize_key_ach' => 'nullable',
            'paidyet_subdomain_ach' => 'nullable',
            'paidyet_key_ach' => 'nullable',
        ];
    }

    public function registerMerchant($company_id, $params)
    {
        $params = $params + ['company_id' => $company_id];
        if (collect($params)->has('subclient_id')) {
            $merchant = Merchant::where('company_id', $company_id)->where('subclient_id',
            $params['subclient_id'])->where('merchant_type', $params['merchant_type'])->first();
        } else {
            $merchant = Merchant::where('company_id', $company_id)->where('merchant_type', $params['merchant_type'])
            ->where('subclient_id', null)->first();
        }

        if ($merchant) {
            $merchant->update($params);
        } else {
            $merchant = Merchant::create($params);
        }
    }
}