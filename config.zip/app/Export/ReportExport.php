<?php 
namespace App\Export;
use App\User;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
class ReportExport implements FromCollection,WithHeadings  
{
    private $data;


    public function __construct($data)
    {   
        $this->data = $data;     //Inject data 
    }
  public function headings(): array {
    $a=array();
    $i=0;
    foreach($this->data as $user){
    if($i==1){
    	break;
    }
    foreach($user as $key => $value)		
	{
		array_push($a,$key);		
    }
    $i++;
	}
     return $a;	
  	}
  public function collection()
  {
    return collect($this->data);
  }
}
?>