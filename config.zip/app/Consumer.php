<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Consumer extends Model
{
//    protected $appends = ['full_name', 'fromDetails'];

    protected $fillable = [
        'company_id',
        'sub_client1_id',
        'sub_client1_name',
        'sub_client2_id',
        'sub_client2_name',
        'reference_number',
        'account_number',
        'unique_customer_id',
        'full_ssn',
        'last4ssn',
        'first_name',
        'middle_name',
        'last_name',
        'dob',
        'gender',
        'address1',
        'address2',
        'city',
        'state',
        'zip',
        'mobile1',
        'mobile2',
        'mobile3',
        'land1',
        'land2',
        'land3',
        'email1',
        'email2',
        'email3',
        'total_balance',
        'principle_balance',
        'fees_balance',
        'daily_interest_add',
        'monthly_interest_add',
        'current_balance',
        'min_one_time_percent',
        'pif_discount_balance',
        'pif_discount_percent',
        'negotiation_rule',
        'pay_setup_discount_percent',
        'min_monthly_pay_percent',
        'min_monthly_pay_amount',
        'max_days_first_pay',
        'pass_through1',
        'pass_through2',
        'pass_through3',
        'pass_through4',
        'pass_through5',
        'ppa_amount',
        'counter_monthly_amount',
        'counter_first_pay_date',
        'counter_pif_amount',
        'counter_ppa_amount',
        'offer_accepted',
        'accrued_interest_rate',
        'account_open_date',
        'placement_date',
        'expiry_date',
        'token',
    ];

    public function company()
    {
        return $this->belongsTo('App\Company');
    }

    public function getFullNameAttribute()
    {
        return $this->first_name . ($this->middle_name ? ' ' . $this->middle_name : '') . ' ' . $this->last_name;
    }

    public function invitationLink()
    {
        $personalizedLogo = PersonalizedLogo::where('company_id', $this->company->id)->first();

        if ($personalizedLogo->customer_communication_link) {
            $surl = "https://" . $personalizedLogo->customer_communication_link . ".younegotiate.com/login?token=" . $this->token;

            //add 29-06-2020 for short url

            //$json = file_get_contents("https://cutt.ly/api/api.php?key=768de173a8247017159509533f1ca077b0c49&short=".$surl);

            $json = file_get_contents("http://yng.link/api.php?key=47ow042ax9338amxhqp&short="
                . $surl);

            $data = json_decode($json, true);
            return $data["url"]["shortLink"];

        } else {
            $surl = "https://consumer.younegotiate.com/login?token=" . $this->token;
            //$json = file_get_contents("https://cutt.ly/api/api.php?key=768de173a8247017159509533f1ca077b0c49&short=".$surl);
            $json = file_get_contents("http://yng.link/api.php?key=47ow042ax9338amxhqp&short=" . $surl);
            $data = json_decode($json, true);
            return $data["url"]["shortLink"];
        }
    }

    public function shortLink()
    {
        $characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = $randomString2 = '';

        for ($i = 0; $i < 2; $i++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }

        $consumer_id = $this->id;
        $first = $randomString;

        for ($i = 0; $i < 2; $i++) {
            $randomString2 .= $characters[rand(0, $charactersLength - 1)];
        }
        $last = $randomString2;

        $short_tag = $first . $consumer_id . $last;
        $shortlink = 'https://yng.link/' . $short_tag;

        return $shortlink;
    }

    public function saveInvitationLink()
    {
        $this->invitation_link = $this->shortLink();
        $this->save();
    }

    public function createLogin()
    {
        $password = str_random(8);
        $cl = ConsumerLogin::create(['email' => $this->email, 'password' => $password]);
        $this->consumer_login_id = $cl->id;
        $this->save();
        return $password;
    }

    public function paymentProfile()
    {
        return $this->belongsTo('App\PaymentProfile', 'id', 'consumer_id');
    }

    public function subclient2()
    {
        return $this->belongsTo('App\Subclient', 'sub_client2_id', 'id');
    }

    public function subclient1()
    {
        return $this->belongsTo('App\Subclient', 'sub_client1_id', 'id');
    }

    //All offer percentage calculation

    public function actualPSD()
    {
        $pay_setup_discount_percent = null;
        if ($this->pay_setup_discount_percent != null) {
            $pay_setup_discount_percent = $this->pay_setup_discount_percent;
        } else {
            if ($this->sub_client2_id != null) {
                if ($this->subclient2->ppa_balance_discount_percent) {
                    $pay_setup_discount_percent = $this->subclient2->ppa_balance_discount_percent;
                } elseif ($this->subclient1->ppa_balance_discount_percent) {
                    $pay_setup_discount_percent = $this->subclient1->ppa_balance_discount_percent;
                } else {
                    $pay_setup_discount_percent = $this->company->ppa_balance_discount_percent;
                }

            } elseif ($this->sub_client1_id != null) {
                if ($this->subclient1->ppa_balance_discount_percent) {
                    $pay_setup_discount_percent = $this->subclient1->ppa_balance_discount_percent;
                } else {
                    $pay_setup_discount_percent = $this->company->ppa_balance_discount_percent;
                }

            } else {
                $pay_setup_discount_percent = $this->company->ppa_balance_discount_percent;
            }
        }
        return $pay_setup_discount_percent;
    }

    public function actualPIF()
    {
        $pif_discount_percent = null;
        if ($this->pif_discount_percent != null) {
            $pif_discount_percent = $this->pif_discount_percent;
        } else {
            if ($this->sub_client2_id != null) {
                if ($this->subclient2->pif_balance_discount_percent) {
                    $pif_discount_percent = $this->subclient2->pif_balance_discount_percent;
                } elseif ($this->subclient1->pif_balance_discount_percent) {
                    $pif_discount_percent = $this->subclient1->pif_balance_discount_percent;
                } else {
                    $pif_discount_percent = $this->company->pif_balance_discount_percent;
                }
            } elseif ($this->sub_client1_id != null) {
                if ($this->subclient1->pif_balance_discount_percent) {
                    $pif_discount_percent = $this->subclient1->pif_balance_discount_percent;
                } else {
                    $pif_discount_percent = $this->company->pif_balance_discount_percent;
                }
            } else {
                $pif_discount_percent = $this->company->pif_balance_discount_percent;
            }
        }
        return $pif_discount_percent;
    }

    public function actualMonthlyPercent()
    {
        $min_monthly_pay_percent = null;
        if ($this->min_monthly_pay_percent != null) {
            $min_monthly_pay_percent = $this->min_monthly_pay_percent;
        } else {
            if ($this->sub_client2_id != null) {
                if ($this->subclient2->min_monthly_pay_percent) {
                    $min_monthly_pay_percent = $this->subclient2->min_monthly_pay_percent;
                } elseif ($this->subclient1->min_monthly_pay_percent) {
                    $min_monthly_pay_percent = $this->subclient1->min_monthly_pay_percent;
                } else {
                    $min_monthly_pay_percent = $this->company->min_monthly_pay_percent;
                }
            } elseif ($this->sub_client1_id != null) {
                if ($this->subclient1->min_monthly_pay_percent) {
                    $min_monthly_pay_percent = $this->subclient1->min_monthly_pay_percent;
                } else {
                    $min_monthly_pay_percent = $this->company->min_monthly_pay_percent;
                }
            } else {
                $min_monthly_pay_percent = $this->company->min_monthly_pay_percent;
            }
        }
        return $min_monthly_pay_percent;
    }

    public function actualPSDamount()
    {
        $actualPSDamount = null;

        if ($this->ppa_amount) {
            $actualPSDamount = $this->ppa_amount;
        } else {
            $actualPSDamount = $this->current_balance - ($this->current_balance * $this->actualPSD() / 100);
        }

        return $actualPSDamount;
    }

    public function actualPIFamount()
    {
        $actualPIFamount = null;

        if ($this->pif_discount_balance) {
            $actualPIFamount = $this->pif_discount_balance;
        } else {
            $actualPIFamount = $this->current_balance - ($this->current_balance * $this->actualPIF() / 100);
        }

        return $actualPIFamount;
    }

    public function actualMonthlyAmount()
    {
        $actualMonthlyAmount = null;

        if ($this->min_monthly_pay_amount) {
            $actualMonthlyAmount = $this->min_monthly_pay_amount;
        } else {
            $actualMonthlyAmount = $this->actualPIFamount() * $this->actualMonthlyPercent() / 100;
        }

        return $actualMonthlyAmount;
    }

    public function actualMaxDaysFirstPay()
    {
        $max_days_first_pay = null;
        if ($this->max_days_first_pay != null) {
            $max_days_first_pay = $this->max_days_first_pay;
        } else {
            if ($this->sub_client2_id != null) {
                if ($this->subclient2->max_days_first_pay) {
                    $max_days_first_pay = $this->subclient2->max_days_first_pay;
                } elseif ($this->subclient1->max_days_first_pay) {
                    $max_days_first_pay = $this->subclient1->max_days_first_pay;
                } else {
                    $max_days_first_pay = $this->company->max_days_first_pay;
                }
            } elseif ($this->sub_client1_id != null) {
                if ($this->subclient1->max_days_first_pay) {
                    $max_days_first_pay = $this->subclient1->max_days_first_pay;
                } else {
                    $max_days_first_pay = $this->company->max_days_first_pay;
                }
            } else {
                $max_days_first_pay = $this->company->max_days_first_pay;
            }
        }
        return $max_days_first_pay;
    }

    public function getMasterName()
    {
        $master = $this->company->name;

        if ($this->sub_client2_id != null) {
            $master = $this->subclient2->name;
        } elseif ($this->sub_client2_name != null) {
            $master = $this->sub_client2_name;
        } elseif ($this->sub_client1_id != null) {
            $master = $this->subclient1->name;
        } elseif ($this->sub_client1_name != null) {
            $master = $this->sub_client1_name;

        }
        return $master;
    }

    public function getActualSubclient1Name()
    {
        $name = '';
        if ($this->sub_client1_name != null) {
            $name = $this->sub_client1_name;
        } elseif ($this->sub_client1_id != null) {
            $name = $this->subclient1->name;
        } else {
            $name = '-';
        }
        return $name;
    }

    public function getActualSubclient2Name()
    {
        $name = '';
        if ($this->sub_client2_name != null) {
            $name = $this->sub_client2_name;
        } elseif ($this->sub_client2_id != null) {
            $name = $this->subclient2->name;
        } else {
            $name = '-';
        }
        return $name;
    }

    public function unsubscribeLink()
    {
        $pl = $this->company->personalized;
        return "https://" . $pl->customer_communication_link . ".younegotiate.com/unsubscribe";
    }

    public function unsubscription()
    {
        return $this->hasOne('App\ConsumerUnsubscription');
    }

    public function scheduledTransactions()
    {
        return $this->hasMany('App\ScheduleTransaction');
    }
    
    public function emailSubscribed()
    {
        if($this->unsubscription){
            return $this->unsubscription->email == null;
        }
        return true;
    }

    public function smsSubscribed()
    {
        if($this->unsubscription){
            return $this->unsubscription->email == null;
        }
        return true;
    }

    public function subscribed()
    {
        $us = $this->unsubscription;
        if ($us) {
            return false;
        }
        return true;
    }

    public function unsubscribed(){
        return !$this->subscribed();
    }

    public function getFromDetailsAttribute()
    {
        $details = [];

        if($this->company->consumer_company_name != null){
            $from_name = $this->company->consumer_company_name;
        }
        else{
            $from_name = $this->company->name;
        }
        
        $from_email = $this->company->account_contact_email;
        if ($this->sub_client1_id != null) {
            if($this->subclient1->consumer_company_name != null){
                $from_name = $this->subclient1->consumer_company_name;
            }  
            elseif($this->subclient1->name != null){
                $from_name = $this->subclient1->name;
            }     

            if($this->subclient1->account_contact_email != null){
                $from_email = $this->subclient1->account_contact_email;
            }
        }
        if ($this->sub_client2_id != null) {
            if($this->subclient2->consumer_company_name != null){
                $from_name = $this->subclient2->consumer_company_name;
            }  
            elseif($this->subclient2->name != null){
                $from_name = $this->subclient2->name;
            }  

            if($this->subclient2->account_contact_email != null){
                $from_email = $this->subclient2->account_contact_email;
            }
            
        }
        $details['from_name'] = $from_name;
        $details['from_email'] = $from_email;

        return $details;
    }

    public function consumerNegotiation()
    {
        $consumerNegotiation = ConsumerNegotiation::where('consumer_id', $this->id)->where('active_negotiation', 1)->first();
        return $consumerNegotiation;

    }

    public function allConsumerNegotiation()
    {
        return $this->belongsTo('App\ConsumerNegotiation', 'id', 'consumer_id');

    }


    public function getMerchant()
    {

        if ($this->sub_client2_id) {
            $select_merchant = Merchant::join('subclients', 'merchants.subclient_id', 'subclients.id')->where('subclient_id', $this->sub_client2_id)->where('subclients.default_payment_account', 1)->select('merchants.*')->first();
            if (!$select_merchant) {
                $select_merchant = Merchant::join('subclients', 'merchants.subclient_id', 'subclients.id')->where('subclient_id', $this->sub_client1_id)->where('subclients.default_payment_account', 1)->select('merchants.*')->first();

                if (!$select_merchant) {
                    $select_merchant = Merchant::where('company_id', $this->company_id)->whereNull('subclient_id')->first();
                }
            }
        } elseif ($this->sub_client1_id) {
            $select_merchant = Merchant::join('subclients', 'merchants.subclient_id', 'subclients.id')->where('subclient_id', $this->sub_client1_id)->where('subclients.default_payment_account', 1)->select('merchants.*')->first();

            if (!$select_merchant) {
                $select_merchant = Merchant::where('company_id', $this->company_id)->whereNull('subclient_id')->first();
            }
        } elseif ($this->company_id) {
            $select_merchant = Merchant::where('company_id', $this->company_id)->whereNull('subclient_id')->first();
        }

        return $select_merchant;
    }

    public function profileLink()
    {
        return url('consumer-profile', $this->id);
    }

}
