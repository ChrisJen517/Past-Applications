<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConsumerLogin extends Model
{
    protected $fillable = ['email', 'password'];

    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

}
