<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class RnnTransaction extends Model
{
    protected $table = "rnn_transactions";

    public function company()
    {
        return $this->belongsTo('App\Company');
    }
}
