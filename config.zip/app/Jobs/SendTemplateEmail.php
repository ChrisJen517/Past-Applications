<?php

namespace App\Jobs;

use App\CommunicationHistory;
use App\Consumer;
use App\Mail\TemplateEmail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;

class SendTemplateEmail implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    private $email, $recipient, $consumer, $campaign;

    public function __construct($recipient, $consumer = null, $campaign = null)
    {
        $this->recipient = $recipient;
        $this->consumer = $consumer;
        $this->campaign = $campaign;
    }

    /**
     * Execute the job.
     *
     * @param $failed_consumers
     * @return void
     */
    public function handle()
    {
        try {
            $this->email = new TemplateEmail($this->campaign->template->content, $this->campaign->template->subject, $this->consumer, $this->consumer->company);
            Mail::to($this->recipient)->send($this->email);
            CommunicationHistory::create([
                'company_id' => $this->consumer ? $this->consumer->company_id : null,
                'consumer_id' => $this->consumer ? $this->consumer->id : null,
                'sub_client1_id' => $this->consumer ? $this->consumer->sub_client1_id : null,
                'sub_client2_id' => $this->consumer ? $this->consumer->sub_client2_id : null,
                'group_id' => $this->campaign ? $this->campaign->group_id : null,
                'template_id' => $this->campaign ? $this->campaign->template_id : null,
                'phone' => null,
                'email' => $this->recipient,
                'smssegment' => null,
                'status' => 'success',
            ]);
        } catch (\Exception $e) {
            CommunicationHistory::create([
                'company_id' => $this->consumer ? $this->consumer->company_id : null,
                'consumer_id' => $this->consumer ? $this->consumer->id : null,
                'sub_client1_id' => $this->consumer ? $this->consumer->sub_client1_id : null,
                'sub_client2_id' => $this->consumer ? $this->consumer->sub_client2_id : null,
                'group_id' => $this->campaign ? $this->campaign->group_id : null,
                'template_id' => $this->campaign ? $this->campaign->template_id : null,
                'phone' => null,
                'email' => $this->recipient,
                'smssegment' => null,
                'status' => 'failed',
            ]);
        }
    }
}
