<?php

namespace App\Jobs;

use App\CommunicationHistory;
use App\Repositories\CommunicationRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class SendEmailJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    private $email, $recipient, $consumer, $campaign;

    public function __construct($email, $recipient, $consumer = null, $campaign = null)
    {
        $this->email = $email;
        $this->recipient = $recipient;
        $this->consumer = $consumer;
        $this->campaign = $campaign;
    }

    public function handle()
    {
        try {
            Mail::to($this->recipient)->send($this->email);
            if ($this->campaign) {
                $content = createTemplateContent($this->campaign->template->content, $this->consumer, null, $this->campaign);
                $this->campaign->total_delivered = $this->campaign->total_delivered + 1;
                $this->campaign->save();
                CommunicationRepository::createCommunicationHistory('email', $this->recipient, null, $content, 'success', $this->campaign->template->subject, $this->consumer, $this->campaign);
            }
        } catch (\Exception $e) {
            if ($this->campaign) {
                $content = createTemplateContent($this->campaign->template->content, $this->consumer, null, $this->campaign);
                $this->campaign->total_failed = $this->campaign->total_failed + 1;
                $this->campaign->failed_consumers = $this->campaign->failed_consumers . " Consumer " . $this->consumer->id . " campaign email failed. ";
                $this->campaign->save();
                CommunicationRepository::createCommunicationHistory('email', $this->recipient, null, $content, 'failed', $this->campaign->template->subject, $this->consumer, $this->campaign);
            }
        }
    }

}