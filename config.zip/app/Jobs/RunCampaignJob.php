<?php

namespace App\Jobs;

use App\Consumer;
use App\Mail\TemplateEmail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class RunCampaignJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    private $campaign, $user;

    public function __construct($campaign, $user)
    {
        $this->campaign = $campaign;
        $this->user = $user;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $consumers = $this->campaign->group->getMemberIDs($this->campaign->company_id ?? $this->user->company_id);
        $template = $this->campaign->template;
        $company = $this->campaign->company_id ?? $this->user->company_id;
        $this->campaign->group_member_count = count($consumers);
        $failed_consumers = $message = '';

        foreach ($consumers as $item) {
            $consumer = Consumer::with(['company', 'unsubscription', 'subclient1', 'subclient2'])->where('id', $item->id)->first();

            //if consumer is deactivated, skips them
            if($consumer->status == 'deactivated'){
                Log::channel('communication_command')->error('Error: Sending to: ' . $consumer->id . ' Campaign ID: ' . $this->campaign->id.' Reason: deactivated');
                $failed_consumers .= ($consumer->id . '<>Consumer has been deactivated,');
                continue;
            }
            
            if ($template->type == 'email') {
                if ($consumer->email1 != null) {
                    if ($consumer->emailSubscribed()) {
                        Log::channel('communication_command')->info('Sending email to: ' . $consumer->email1 . ' Campaign ID: ' . $this->campaign->id);
                        $email = new TemplateEmail($template->content, $template->subject, $consumer, $company, $this->campaign);
                        SendEmailJob::dispatch($email, trim($consumer->email1), $consumer, $this->campaign);
                        $this->campaign->total_sent = $this->campaign->total_sent + 1;
                        $this->campaign->total_balance_delivered = $this->campaign->total_balance_delivered + $consumer->current_balance;
                        $email = null;
                    } else {
                        Log::channel('communication_command')->error('Error: Sending email to: ' . $consumer->email1 . ' Campaign ID: ' . $this->campaign->id.' Reason: Unsubscribed');
                        $failed_consumers .= ($consumer->id . '<>Consumer has unsubscribed from receiving emails,');
                    }
                } else {
                    Log::channel('communication_command')->error('Error: Sending email to: ' . $consumer->email1 . ' Campaign ID: ' . $this->campaign->id.' Reason: Blank email');
                    $failed_consumers .= ($consumer->id . '<>Consumer does not have email address,');
                }
            }
            if ($template->type == 'sms') {
                if ($consumer->mobile1 != null) {
                    if ($consumer->smsSubscribed()) {
                        Log::channel('communication_command')->info('Sending sms to: ' . $consumer->mobile1 . ' Campaign ID: ' . $this->campaign->id);
                        SendSMSJob::dispatch($template->content, trim($consumer->mobile1), $consumer, $this->campaign, $company);
                        $this->campaign->total_sent = $this->campaign->total_sent + 1;
                        $this->campaign->total_balance_delivered = $this->campaign->total_balance_delivered + $consumer->current_balance;
                    } else {
                        Log::channel('communication_command')->error('Error: Sending sms to: ' . $consumer->mobile1 . ' Campaign ID: ' . $this->campaign->id.' Reason: Unsubscribed');
                        $failed_consumers .= ($consumer->id . '<>Consumer unsubscribed from receiving sms,');
                    }
                } else {
                    Log::channel('communication_command')->error('Error: Sending sms to: ' . $consumer->mobile1 . ' Campaign ID: ' . $this->campaign->id.' Reason: Blank Mobile No');
                    $failed_consumers .= ($consumer->id . '<>Consumer mobile number not present,');
                }
                $message = "SMS Template Sent to Group!";
            }
            $consumer = null;
        }
        $this->campaign->total_failed = ($this->campaign->group_member_count - $this->campaign->total_sent);
        $this->campaign->failed_consumers = trim($failed_consumers, ',');
        $this->campaign->sent_at = now();
        $this->campaign->save();
    }
}