<?php

namespace App\Jobs;

use App\Consumer;
use App\Mail\TemplateEmail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Log;

class SendEletterReminderJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * When new eletter is sent out, sends a text and email to all consumers to inform them.
     *
     * @return void
     */

    private $consumer_ids, $company, $content, $userEmail, $smsContent;

    public function __construct($consumer_ids, $company, $userEmail)
    {
        $this->consumer_ids = $consumer_ids;
        $this->company = $company;
        $this->userEmail = $userEmail;
        //email message
        $this->content = "Hi [First Name],
        <br>
        <br>
        <br>We’re reaching out from the YouNegotiate team to let you know [Master Company Name] has sent you a digital eLetter (replacing USPS) and uploaded your account on You Negotiate.
        <br> 
        <br>
        <br>You can quickly and easily set up a profile to receive all collection eLetters and settle, Negotiate, send offers and manage your payment plans from your single profile YouNegotiate account <span style='color:red;'> by visiting your unique quick acess link [You Negotiate Link] </span>
        <br>
        <br>
        <br>YouNegotiate was launched in July 2020 and proud to say we are helping over 500,000 consumers eliminate the stress of collection accounts.
        <br>
        <br>
        <br>We will soon be adding the ability to send Offers on the fly if your the creditor isn’t yet enrolled so we can help eliminate mail, collection calls and stress from your life.
        <br>
        <br>
        <br>Your data is protected by bank-level security and creditors do not have access to any of your payment details, ever.
        <br>
        <br>
        <br>We look forward to working together to offer you a free and friendly place to manage your debt! <span style='color:red;'> For more information log on to www.younegotiate.com </span>
        <br>
        <br>
        <br>Have a super day!
        <br>YouNegotiate Team
        <br>";

        $this->smsContent = "[Original creditor name] has sent you an eLetter regarding your collection account on YouNegotiate.com eMailbox. Please visit [You Negotiate Link]";
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        //turns the ids into an array to gert the consumers
        $ids = [];
        foreach($this->consumer_ids as $consumer_id){
            $ids[] = $consumer_id->id;
        }
        $consumers = Consumer::whereIn('id', $ids)->get();

        //goes through and sends every consumer and email and/or text
        foreach($consumers as $consumer){

            if($consumer->status == 'deactivated'){
                Log::channel('communication_command')->error('Error: Sending Eletter reminder to: ' . $consumer->id . ' Reason: deactivated');
                continue;
            }

            //if the consumer has neither sends an email to the dev support before continuing 
            if(!array_filter([$consumer->mobile1, $consumer->mobile2, $consumer->mobile3]) && !array_filter([$consumer->email1, $consumer->email2, $consumer->email3])){
                $email = new TemplateEmail("This consumer, account number:".$consumer->account_number." does not have any email or phone numbers associated with it.", "No Email or phone number!", $consumer, $this->company);
                SendEmailJob::dispatch($email, trim($this->userEmail), $consumer, null);
                continue;
            }
            if(array_filter([$consumer->mobile1, $consumer->mobile2, $consumer->mobile3])){
                $number = $consumer->mobile1 ?? $consumer->mobile2 ?? $consumer->mobile3;
                SendSMSJob::dispatch($this->smsContent, trim($number), $consumer, null, $this->company);
            }
            if(array_filter([$consumer->email1, $consumer->email2, $consumer->email3])){
                $address = $consumer->email1 ?? $consumer->email2 ?? $consumer->email3;
                $email = new TemplateEmail($this->content, "You Got an eLetter!", $consumer, $this->company);
                SendEmailJob::dispatch($email, trim($address), $consumer, null);
            }
        }
    }
}