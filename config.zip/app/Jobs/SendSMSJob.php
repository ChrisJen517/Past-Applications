<?php

namespace App\Jobs;

use App\CommunicationHistory;
use App\ClientApiKey;
use App\Repositories\CommunicationRepository;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Twilio\Rest\Client;
use Log; 

class SendSMSJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    private $phone_no, $content, $twillio_sid, $twilio_auth_token, $twilio_number, $campaign, $consumer, $company_id;

    public function __construct($content, $phone_no, $consumer = null, $campaign = null, $company_id)
    {
        $this->phone_no = $phone_no;
        $this->content = createTemplateContent($content, $consumer, null, $campaign);
        $this->twillio_sid = env('TWILIO_SID');
        $this->twilio_auth_token = env('TWILIO_AUTH_TOKEN');
        $this->twilio_number = env('TWILIO_PHONE_NO');
        $this->campaign = $campaign;
        $this->consumer = $consumer;
        $this->company_id = $company_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        try {
            $from_number = (ClientApiKey::where("company_id", $this->company_id)->exists()
            ? ClientApiKey::where("company_id", $this->company_id)->first()->twilio_phone_no
            : "+14702881902");
            $client = new Client('ACad1460c6dd44e9c8725844cfa4675e10', '39e4c316e3b6b6a9fe428d340cca0b5c');
            $client->messages->create($this->phone_no, ['from' => $from_number, 'body' => $this->content]);
            if ($this->campaign) {
                $this->campaign->total_delivered = $this->campaign->total_delivered + 1;
                $this->campaign->save();
                CommunicationRepository::createCommunicationHistory('sms', null, $this->phone_no, $this->content, 'success', null, $this->consumer, $this->campaign);
            }
        } catch (\Exception $e) {
            if ($this->campaign) {
                $this->campaign->total_failed = $this->campaign->total_failed + 1;
                $this->campaign->failed_consumers = $this->campaign->failed_consumers . " Consumer " . $this->consumer->id . " campaign SMS failed. ";
                $this->campaign->save();
                CommunicationRepository::createCommunicationHistory('sms', null, $this->phone_no, $this->content, 'success', null, $this->consumer, $this->campaign);
            }
            Log::channel('sms')->info($e);
        }

    }
}