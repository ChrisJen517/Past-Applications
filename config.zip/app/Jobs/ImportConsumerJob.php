<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

use App\Consumer;
use App\ConsumerAccount;
use App\CsvData;
use App\CsvHeader;
use App\FileUploadHistory;
use App\Subclient;
use App\Mail\ConsumerImportedEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use ZipStream\File;

class ImportConsumerJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    private $row, $marge_header, $user, $fileUploadHistory_id, $errorList, $account_number_field;

    public function __construct($row, $marge_header, $user, $fileUploadHistory_id, $errorList, $account_number_field)
    {
        $this->row = $row;
        $this->marge_header = $marge_header;
        $this->user = $user;
        $this->fileUploadHistory_id = $fileUploadHistory_id;
        $this->errorList = $errorList;
        $this->account_number_field = $account_number_field;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $row = $this->row;
        $marge_header = $this->marge_header;
        $user = $this->user;
        $consumer = new Consumer();
        $error = false;
        $fuh = FileUploadHistory::find($this->fileUploadHistory_id);
        $errorList = $this->errorList;
        $account_number_field = $this->account_number_field;
        

        foreach ($marge_header as $index => $field) {
            if ($field != 'Select') {
                if ($field == "dob") {
                    $transformedDate = date("Y-m-d", strtotime($row[$index]));
                    if ($transformedDate != "1970-01-01")
                        $consumer->$field = $transformedDate;
                    else
                        $consumer->$field = "";
                } elseif ($field == "account_open_date") {
                    $transformedDate = date("Y-m-d", strtotime($row[$index]));
                    if ($transformedDate != "1970-01-01")
                        $consumer->$field = $transformedDate;
                    else
                        $consumer->$field = "";
                } elseif ($field == "placement_date") {
                    $transformedDate = date("Y-m-d", strtotime($row[$index]));
                    if ($transformedDate != "1970-01-01")
                        $consumer->$field = $transformedDate;
                    else
                        $consumer->$field = "";
                } elseif ($field == "expiry_date") {
                    $transformedDate = date("Y-m-d", strtotime($row[$index]));
                    if ($transformedDate != "1970-01-01")
                        $consumer->$field = $transformedDate;
                    else
                        $consumer->$field = "";
                } elseif ($field == "account_number") {
                    $consumers = Consumer::where('account_number', $row[$index])
                        ->where('company_id', $user->company_id)->get();
                    if (count($consumers) > 0) {
                        $error = true;
                        Log::channel('import_consumer_command')->warning('Account Number: '.$row[$account_number_field].', Consumer already exists with account no: ' . $row[$index] .
                            ' and company_id: ' . $user->company_id . ', not importing');
                        $errorList =  'Account Number: '.$row[$account_number_field].', Consumer already exists with account no: ' . $row[$index].'<br>';
                        break;
                    } else {
                        $consumer->$field = $row[$index]; //$row
                    }
                } elseif ($field == "email1") {
                    if ($row[$index]) {
                        if (filter_var($row[$index], FILTER_VALIDATE_EMAIL)) {
                            $consumer->$field = $row[$index];
                        } else {
                            Log::channel('import_consumer_command')->error('Account Number: '.$row[$account_number_field].', Consumer email: ' . $row[$index] . ' is not a valid email. Not importing this consumer.');
                            $errorList = 'Account Number: '.$row[$account_number_field].', Consumer email: ' . $row[$index] . ' is not a valid email. <br>';
                            $error = true;
                            break;
                        }
                    }
                } elseif ($field == "mobile1" || $field == "mobile2" || $field == "mobile3") {
                    if ($row[$index]) {
                        $mobile = preg_replace("/[^0-9]/", "", $row[$index]);
                        $mobile = substr($mobile, -10);
                        $consumer->$field = $mobile;
                    }
                } elseif ($field == "last4ssn") {
                    if ($row[$index]) {
                        $last4ssn = preg_replace("/[^0-9]/", "", $row[$index]);
                        $last4ssn = substr($last4ssn, -4);
                        $consumer->$field = $last4ssn;
                    }
                    else{
                        Log::channel('import_consumer_command')->error('Account Number: '.$row[$account_number_field].', Consumer last4ssn: ' . $row[$index] . ' is empty. Not importing this consumer.');
                            $errorList = 'Account Number: '.$row[$account_number_field].', Consumer last4ssn empty. <br>';
                            $error = true;
                            break;
                    }
                } 
                elseif ($field == "current_balance") {
                    if ($row[$index]) {
                        $current_balance = preg_replace("/[^0-9.]/", "", $row[$index]);
                        $consumer->$field = $current_balance;
                    }
                    
                }
                elseif ($field == "total_balance") {
                    if ($row[$index]) {
                        $total_balance = preg_replace("/[^0-9.]/", "", $row[$index]);
                        $consumer->$field = $total_balance;
                    }
                }
                elseif ($field == "state") {
                    if (strlen($row[$index]) == 2) {
                        $state = strtoupper($row[$index]);
                        $consumer->$field = $state;
                    }
                }
                elseif ($field == "sub_client1_id") {
                    if ($row[$index]) {
                        $subclient = Subclient::where('id', $row[$index])->where('company_id', $user->company->id)->first();
                        if($subclient){
                            $consumer->$field = $row[$index];
                        }
                        else{
                            $errorList = 'Account Number: '.$row[$account_number_field].', Subclient ID:'.$row[$index].' is not mapped with your account. <br>';
                            $error = true;
                            break;
                        }
                    }
                }
                elseif ($field == "sub_client2_id") {
                    if ($row[$index]) {
                        $subclient = Subclient::where('id', $row[$index])->where('company_id', $user->company->id)->first();
                        if($subclient){
                            $consumer->$field = $row[$index];
                        }
                        else{
                            $errorList = 'Account Number: '.$row[$account_number_field].', Subclient ID:'.$row[$index].' is not mapped with your account. <br>';
                            $error = true;
                            break;
                        }
                    }
                } else {
                    $consumer->$field = $row[$index]; //$row
                }
            }
        }
        //check current user type
        if (!$error) {
            if ($user->isCompanyUser()) {
                $consumer->company_id = $user->company->id;
            } else if ($user->isSubclient1User()) {
                $consumer->company_id = $user->company_id;
                $consumer->sub_client1_id = $user->subclient_id;
            } else if ($user->isSubclient2User()) {
                $subclient = Subclient::find($user->subclient_id);
                $consumer->company_id = $user->company_id;
                $consumer->sub_client1_id = $subclient->parent_id;
                $consumer->sub_client2_id = $user->subclient_id;
            }

            if (!$consumer->total_balance) {
                $consumer->total_balance = $consumer->current_balance;
            } elseif (!$consumer->current_balance) {
                $consumer->current_balance = $consumer->total_balance;
            }

            $token = $consumer->id . $consumer->company_id . $consumer->account_number;
            $token = Hash::make($token);
            $consumer->token = $token;
            $consumer->save();
            Log::channel('import_consumer_command')->info('Account Number: '.$row[$account_number_field].', Consumer created with account no: ' . $consumer->account_number .
                ', company_id: ' . $consumer->company_id .
                ', Subclient1: ' . $consumer->sub_client1_id .
                ', Subclient2: ' . $consumer->sub_client2_id
            );

            Log::channel('import_consumer_command')->info("Error List: ".(string)(json_encode($errorList,true)) );

            $consumer->saveInvitationLink();
            $fuh->processed_count = $fuh->processed_count + 1;
            $fuh->save();
        } else {
            $fuh->failed_count = $fuh->failed_count + 1;
            if($fuh->failed_list){
                $fuh->failed_list = $fuh->failed_list.", ".$errorList;
            }else{
                $fuh->failed_list = $errorList;
            }
            Log::channel('import_consumer_command')->info("Error List: ".$fuh->failed_list );
            
            $fuh->save();
        }

        if ($fuh->totalProcessed() == $fuh->num_of_records) {
            $fuh->status = 'Complete';
            $fuh->save();
        }

        if ($fuh->status == 'Complete') {
            $errorList = $fuh->failed_list;
            $this->sendMailAfterComplete($this->user, $fuh, $errorList);
        }

    }

    public function failed()
    {
        $fuh = FileUploadHistory::find($this->fileUploadHistory_id);
        $fuh->failed_count = $fuh->failed_count + 1;
        if ($fuh->totalProcessed() == $fuh->num_of_records) {
            $fuh->status = 'Complete';
        }
        $fuh->save();
        $errorList = $fuh->failed_list;

        if ($fuh->status == 'Complete') {
            $this->sendMailAfterComplete($this->user, $fuh, $errorList);
        }
    }

    public function sendMailAfterComplete($user, $fuh, $errorList)
    {
        Mail::to($user->email)->send(new ConsumerImportedEmail($user, $fuh, $errorList));
        Mail::to('soumabha.sunny1987@gmail.com')->send(new ConsumerImportedEmail($user, $fuh, $errorList));
    }
}