<?php

namespace App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

use App\Consumer;
use App\ConsumerAccount;
use App\CsvData;
use App\CsvHeader;
use App\FileUploadHistory;
use App\Subclient;
use App\APIHistory;
use App\Mail\ConsumerImportedEmail;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use ZipStream\File;

class ApiConsumerJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    private $account_number, $company_id;

    public function __construct($account_number, $company_id)
    {
        $this->account_number = $account_number;
        $this->company_id = $company_id;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle(){
        try{
        $consumer = Consumer::where('account_number', $this->account_number)->where('company_id', $this->company_id)->first();
        // if(empty($consumer))
        //     return;

        if (!$consumer->total_balance)
            $consumer->total_balance = $consumer->current_balance;
        elseif (!$consumer->current_balance)
            $consumer->current_balance = $consumer->total_balance;

        $token = $consumer->id . $consumer->company_id . $consumer->account_number;
        $token = Hash::make($token);
        $consumer->token = $token;
        $consumer->saveInvitationLink();
        $consumer->save();

        } catch (\throwable $e) {
            Log::channel('consumers_api')->error($e);
        }
    }
}