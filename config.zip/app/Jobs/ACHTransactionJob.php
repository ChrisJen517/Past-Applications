<?php

namespace App\Jobs;

use App\Mail\TransactionEmail;
use App\RnnTransaction;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Mail;

class ACHTransactionJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    /**
     * Create a new job instance.
     *
     * @return void
     */

    private $company, $from, $to;

    public function __construct($company, $from, $to)
    {
        $this->company = $company;
        $this->from = $from;
        $this->to = $to;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {

        $company = $this->company;
        $from = $this->from;
        $to = $this->to;

        $transactionAmount = $company->transactionCharge($from, $to);
        $rnnShare = $company->rnnShareAmount($from, $to);

        $emailcount = $company->communicationCount('email', $from, $to);
        $smscount = $company->communicationCount('sms', $from, $to);

        $emailCharge = $company->communicationCharge('email', $from, $to);
        $smsCharge = $company->communicationCharge('sms', $from, $to);

        $routing = $company->bank1_routing;
        $account = $company->bank1_account_number;

        $firstname = strtoupper(strtok($company->billing_name, ' '));

        $lastname = strtoupper(strstr($company->billing_name, ' '));

        $totalRnnShare = $rnnShare + $emailCharge + $smsCharge;
        //dd($transactionAmount,$rnnShare,$rnnAmount);
        $date = str_replace("-", "", now()->toDateString());

        /*$packet ="20<FS>2010<FS>10<FS>".$date."125959<FS><FS>85G01<FS>[NAME]".$company->billing_name."[/NAME][PAYER]".$company->bank1_company_address.$company->bank1_company_city.$company->bank1_company_state."[/PAYER][LOCATION]"
            .$company->bank1_company_state."[/LOCATION]<FS><FS>".preg_replace('/\s+/', '',$routing)."<FS>".preg_replace('/\s+/', '',$account)."<FS>9999<FS>".$totalRnnShare."<FS><FS><FS><FS><FS><FS>EV<FS><FS>CA<FS><FS>".$company->account_contact_phone;*/

        $packet ="20<FS>2010<FS>10<FS>".$date."125959<FS><FS>85G01<FS>[NAME]".strtoupper($company->billing_name)." [/NAME][PAYER]".$firstname."|".$lastname."|".strtoupper($company->bank1_company_address)."|CITYNAME|".strtoupper($company->bank1_company_city)."|".strtoupper($company->bank1_company_state)."|".$company->bank1_company_zip."[/PAYER][LOCATION]".strtoupper($company->bank1_company_state)."[/LOCATION]<FS><FS>".preg_replace('/\s+/', '',$routing)."<FS>".preg_replace('/\s+/', '',$account)."<FS>9999<FS>".$totalRnnShare."<FS><FS><FS><FS><FS><FS>EV<FS><FS>CA<FS><FS>".$company->billing_phone;

        /*$packet = "20<FS>2010<FS>10<FS>" . $date . "125959<FS><FS>ZYZ63<FS>[NAME]" . $company->billing_name . "[/NAME][PAYER]" . $company->bank1_company_address . $company->bank1_company_city . $company->bank1_company_state . "[/PAYER][LOCATION]"
            . $company->bank1_company_state . "[/LOCATION]<FS><FS>" . $routing . "<FS>" . $account . "<FS><FS>" . $totalRnnShare . "<FS><FS><FS><FS><FS><FS>PV<FS>A7777777<FS>CA<FS>19760704<FS>6468512166";*/

        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => "https://spaysys.com/cgi-bin/cgiwrap-noauth/dl4ub/tinqpstpbf.cgi",
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => "POST",
            CURLOPT_POSTFIELDS => array('packet' => $packet),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $rnnTransaction = new RnnTransaction();
        $rnnTransaction->company_id = $company->id;
        $rnnTransaction->amount = $totalRnnShare;
        $rnnTransaction->responce = json_encode($response);
        $rnnTransaction->packet = $packet;
        $rnnTransaction->billing_cycle_start = $from;
        $rnnTransaction->billing_cycle_end = $to;
        $rnnTransaction->email_count = $emailcount;
        $rnnTransaction->sms_count = $smscount;
        $rnnTransaction->email_cost = $emailCharge;
        $rnnTransaction->sms_cost = $smsCharge;
        $rnnTransaction->save();

        $transactions = $company->transactions($from, $to);

        foreach ($transactions as $transaction) {
            $transaction->rnn_share_pass = now();
            $transaction->rnn_transaction_id = $rnnTransaction->id;
            $transaction->save();
        }

        if (strpos($rnnTransaction->responce, 'OKAY') != false) {

            $rnnTransaction->status = "Successful";
            $rnnTransaction->save();
            Mail::to($company->billing_email)->send(new TransactionEmail('Success', $rnnTransaction));
            Mail::to('info@rnngroup.com')->send(new TransactionEmail('Success', $rnnTransaction));
        } else {
            $rnnTransaction->status = "Failed";
            $rnnTransaction->save();
            Mail::to('soumabha.sunny1987@gmail.com')->send(new TransactionEmail('Failed', $rnnTransaction));
            Mail::to('prateekg@rnngroup.com')->send(new TransactionEmail('Failed', $rnnTransaction));
        }
    }
}
