<?php

namespace App\Http\Controllers;

use App\Repositories\SettingsRepository;
use Illuminate\Http\Request;

class SettingsController extends Controller
{
    protected $repository;

    public function __construct(SettingsRepository $repository)
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:import-export');
        $this->repository = $repository;
    }

    public function createSFTP($type)
    {
        $this->repository->createSFTPDetails($type, auth()->user()->company_id);
        return redirect()->back();
    }

    public function editSFTP()
    {
        $import_details = $this->repository->getSFTPDetails('import', auth()->user()->company_id);
        $export_details = $this->repository->getSFTPDetails('export', auth()->user()->company_id);
        return view('settings.sftp', compact('import_details', 'export_details'));
    }

    public function updateSFTP(Request $request)
    {
        $this->repository->updateSFTPDetails(auth()->user()->company_id, $request->validate($this->repository->sftpUpdateValidationRules()));
        return redirect()->back();
    }
}