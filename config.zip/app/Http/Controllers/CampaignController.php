<?php

namespace App\Http\Controllers;

use App\Campaign;
use App\Exports\ConsumerExport;
use App\Exports\CampaignExport;
use App\Exports\CampaignConsumerExport;
use App\Group;
use App\Consumer;
use App\CommunicationHistory;
use App\ConsumerNegotiation;
use App\Repositories\CampaignRepository;
use App\Template;
use App\Export\ReportExport;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Carbon\Carbon;
use DB;
use Exception;

class CampaignController extends Controller
{
    protected $repository;

    public function __construct(CampaignRepository $repository)
    {
        $this->middleware(['auth', 'check-profile-completed', 'redirect-if-subclient-user']);
        $this->middleware('sidebar-menu:communication');
        $this->repository = $repository;
    }

    public function index()
    {
        $company_id = auth()->user()->company_id;
        $campaigns = $this->repository->all($company_id);

        $consumers = DB::table('consumers')
        ->leftjoin('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
        ->selectRaw("campaign_id,
            COUNT(IF(consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified'), 1, NULL)) AS clicked,
            COUNT(IF(consumers.status NOT IN ('uploaded', 'deactivated', 'visited'), 1, NULL)) AS entered_pii,
            COUNT(IF(negotiation_type = 'pif' AND consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified', 'visited'), 1, NULL)) AS pif,
            COUNT(IF(negotiation_type = 'installment' AND consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified', 'visited'), 1, NULL)) AS ppl,
            COUNT(IF(consumers.custom_offer = 1 AND consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified', 'visited'), 1, NULL)) as custom_offer
        ")->whereNotNull('campaign_id')->groupBy('campaign_id')->get();

        foreach($campaigns as $campaign)
        {
            $campaign->delivered_percent = $campaign->total_sent != 0 ? number_format($campaign->total_delivered / $campaign->total_sent * 100, 2) : 0.00;
            $campaign->clicked_link = 0.00;
            $campaign->entered_PII = 0.00;
            $campaign->entered_PIF = 0.00;
            $campaign->entered_PPL = 0.00;
            $campaign->custom_offer_percent = 0.00;

            if($consumers->where('campaign_id', $campaign->id)->count() > 0)
                $consumer = $consumers->where('campaign_id', $campaign->id)->first();
            else
                continue;

            $campaign->clicked_link =  $campaign->total_delivered != 0 ? number_format($consumer->clicked / $campaign->total_delivered * 100, 2)  : 0.00;
            $campaign->entered_PII =  $consumer->clicked != 0 ? number_format($consumer->entered_pii / $consumer->clicked * 100, 2)  : 0.00;
            $campaign->entered_PIF = $consumer->entered_pii != 0 ? number_format($consumer->pif / $consumer->entered_pii * 100, 2) : 0.00;
            $campaign->entered_PPL = $consumer->entered_pii != 0 ? number_format($consumer->ppl / $consumer->entered_pii * 100, 2) : 0.00;
            $campaign->custom_offer_percent = $consumer->entered_pii != 0 ? number_format($consumer->custom_offer / $consumer->entered_pii * 100, 2) : 0.00;
        }

        return view('yn.modules.communication.campaign', compact('campaigns'));
    }

    public function reRun($id)
    {
        $campaign = $this->repository->getByID($id);
        if ($campaign->group->enabled && $campaign->template->enabled) {
            $new_campaign = $this->repository->clone($campaign);
            $message = $new_campaign->run();
            return redirect()->back()->with('success', $message);
        } else {
            session()->flash('error', "Campaign could not be created template/group is disabled");
            return redirect()->to(url('campaign'));
        }

    }

    public function run($id)
    {
        $campaign = $this->repository->getByID($id);
        if ($campaign->group->enabled && $campaign->template->enabled) {
            $message = $campaign->run();
            return redirect()->back()->with('success', $message);
        } else {
            session()->flash('error', "Campaign could not be created template/group is disabled");
            return redirect()->to(url('campaign'));
        }
    }

    public function create(Request $request)
    {    
        $params = $request->validate($this->repository->creationValidationRules());
        $group = Group::find($params['group_id']);
        
        if (!$group->enabled){
            session()->flash('error', "Campaign could not be created group is disabled");
            return redirect()->to(url('campaign'));
        }
        if (empty($params['template_id']) && empty($params['email_template']) && empty($params['sms_template'])){
            session()->flash('error', "At least one template must be selected");
            return redirect()->to(url('campaign'));
        }

        foreach(['template_id', 'email_template', 'sms_template'] as $templateType){
            if (!empty($params[$templateType])) {
                if ($params[$templateType] != null) {
                    $template = Template::find($params[$templateType]);
                    if ($template->enabled) {
                        $campaign = $this->repository->createCampaign($group->id, $params[$templateType]);
                        $campaign->run();
                    } else {
                        session()->flash('error', 'Cannot create campaign because the template is disabled');
                        return redirect()->back();
                    }
                }
            }
        }

        session()->flash('success', 'Campaign(s) has been created and started!');
        return redirect()->to(url('campaign'));
    }

    public function exportFailed($id)
    {
        $campaign = $this->repository->getByID($id);
        $date = date('Y-m-d', strtotime($campaign->sent_at ?? $campaign->created_at));
        $members = $campaign->failedConsumers();
        $subset = $members->map->only(['first_name', 'last_name', 'gender', 'email1', 'mobile1', 'sub_client1_id', 'sub_client2_id', 'account_number', 'current_balance', 'failed_reason']);
        return Excel::download(new ConsumerExport($subset), $date . "_Campaign_Failed_List.csv");
    }

    public function createFailedGroup(Request $request){
        $campaign = $this->repository->getByID($request->id);
        $members = $campaign->failedConsumers()->map->only(['account_number']);
        $accountNumbers = [];
        foreach($members as $member){
            $accountNumbers[] = $member['account_number'];
        }
        if(empty($accountNumbers))
            return back()->with('error', 'No failed Consumers in the campaign!');

        $customRule  = new \stdClass();
        $customRule->field_name = "failed_list"; 
        $customRule->value_start = $accountNumbers;

        $group = new Group();
        $group->name = $request->name;
        $group->description = $request->description;
        $group->company_id = auth()->user()->company_id;
        $group->created_by = auth()->user()->id;
        $group->customer_status_rule = '[]';
        $group->customer_custom_rule = json_encode([$customRule]); 
        $group->save(); 

        return back()->with('success', 'New Group '.$request->name.' was created!');
    }

    public function exportAll(Request $request)
    {
        $campaigns = $this->repository->all(auth()->user()->company_id);

        $consumers = DB::table('consumers')
        ->leftjoin('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
        ->selectRaw("campaign_id,
            COUNT(DISTINCT IF(consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified'), 1, NULL)) AS clicked,
            COUNT(DISTINCT IF(consumers.status NOT IN ('uploaded', 'deactivated', 'visited'), 1, NULL)) AS entered_pii,
            COUNT(IF(negotiation_type = 'pif', 1, NULL)) AS pif,
            COUNT(IF(negotiation_type = 'installment', 1, NULL)) AS ppl,
            COUNT(IF(consumers.custom_offer = 1, 1, NULL)) as custom_offer
        ")->where('campaign_id', '!=', NULL)->groupBy('campaign_id')->get();

        foreach($campaigns as $campaign)
        {
            $campaign->delivered_percent = $campaign->total_sent != 0 ? number_format($campaign->total_delivered / $campaign->total_sent * 100, 2)."%" : 0.00."%";
            $campaign->clicked_link = 0.00."%";
            $campaign->entered_PII = 0.00."%";
            $campaign->entered_PIF = 0.00."%";
            $campaign->entered_PPL = 0.00."%";
            $campaign->custom_offer_percent = 0.00."%";


            $campaign->sent_on = $campaign->sent_at ? $campaign->sent_at->format('Y-m-d H:i') : '';
            $campaign->template_type = strtoupper($campaign->template->type);
            $campaign->template_name = $campaign->template->name;
            $campaign->group_name = $campaign->group->name; 
            
            if($consumers->where('campaign_id', $campaign->id)->count() > 0)
                $consumer = $consumers->where('campaign_id', $campaign->id)->first();
            else
                continue;
                
                $campaign->clicked_link =  $campaign->total_delivered != 0 ? number_format($consumer->clicked / $campaign->total_delivered * 100, 2) ."%" : 0.00 ."%";
                $campaign->entered_PII =  $consumer->clicked != 0 ? number_format($consumer->entered_pii / $consumer->clicked * 100, 2) ."%" : 0.00."%";
                $campaign->entered_PIF = $consumer->entered_pii != 0 ? number_format($consumer->pif / $consumer->entered_pii, 2)."%" : 0.00."%";
                $campaign->entered_PPL = $consumer->entered_pii != 0 ? number_format($consumer->ppl / $consumer->entered_pii, 2)."%" : 0.00."%";
                $campaign->custom_offer_percent = $consumer->entered_pii != 0 ? number_format($consumer->custom_offer / $consumer->entered_pii, 2)."%" : 0.00."%";
            } 

        $date = Carbon::now()->format('Y-m-d');
        $subset = $campaigns->map->only(['sent_on', 'template_type', 'template_name', 'group_name', 'subject', 'total_sent', 'total_delivered', 'delivered_percent', 'clicked_link', 'entered_PII', 'entered_PIF', 'entered_PPL', 'custom_offer_percent']);
        return Excel::download(new CampaignExport($subset), 'Campaigns_'.$date.'.csv');
    }

    public function exportConsumers($campaign_id)
    {
        $campaign = Campaign::where('id', $campaign_id)->with('group')->first();
        $date = date('Y-m-d', strtotime($campaign->sent_at ?? $campaign->created_at));
        $group_ids = $campaign->group->getMemberIDs(auth()->user()->company_id);
        $consumers = Consumer::wherein("id", $group_ids)->where('created_at', "<=", $campaign->created_at)->get();
        $subset = $consumers->map->only(['account_number', 'first_name', 'last_name', 'gender', 'address1', 'address2', 'city', 'state', 'zip', 'sub_client1_id', 'sub_client1_name', 'sub_client2_id', 'sub_client2_name', 'mobile1', 'mobile2', 'mobile3', 'land1', 'land2', 'land3', 'email1', 'email2', 'email3', 'invitation_link']);

        return Excel::download(new CampaignConsumerExport($subset), 'Campaign_Consumers_'.$date.'.csv');
    }

    public function getTable(Request $request){
        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'sent_at',
            1 => 'templates.type',
            2 => 'templates.name',
            3 => 'groups.name',
            4 => 'templates.subject',
            5 => 'total_sent',
            6 => 'total_delivered'
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $queries = "(sent_at LIKE '%".$search."%'";
        foreach(['total_sent', 'total_failed', 'total_delivered', 'groups.name', 'templates.name', 'templates.subject'] as $query)
            $queries = $queries." OR ".$query." LIKE '%".$search."%'";
        $queries = $queries.")";

        $total_campaigns = Campaign::selectRaw('id, group_id, template_id')
        ->join('templates', 'template_id', '=', 'templates.id')
        ->join('groups', 'group_id', '=', 'groups.id')->where('campaigns.company_id', $user->company_id)->count();

        $filtered_campaigns = Campaign::selectRaw('id, group_id, template_id')
        ->join('templates', 'template_id', '=', 'templates.id')
        ->join('groups', 'group_id', '=', 'groups.id')->where('campaigns.company_id', $user->company_id)->whereRaw($queries)->count();

        $consumers = DB::table('consumers')
        ->leftjoin('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
        ->selectRaw("campaign_id,
            COUNT(IF(consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified'), 1, NULL)) AS clicked,
            COUNT(IF(consumers.status NOT IN ('uploaded', 'deactivated', 'visited'), 1, NULL)) AS entered_pii,
            COUNT(IF(negotiation_type = 'pif' AND consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified', 'visited'), 1, NULL)) AS pif,
            COUNT(IF(negotiation_type = 'installment' AND consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified', 'visited'), 1, NULL)) AS ppl,
            COUNT(IF(consumers.custom_offer = 1 AND consumers.status NOT IN ('uploaded', 'deactivated', 'not_verified', 'visited'), 1, NULL)) as custom_offer
        ")->whereNotNull('campaign_id')->where('consumers.company_id', $user->company_id)->groupBy('campaign_id')->get();

        $campaigns = Campaign::selectRaw('
            campaigns.id, group_id, template_id, total_sent, total_failed, sent_at,
            0 as enabled, templates.enabled as template_enabled, groups.enabled as group_enabled, "" as format_date,
            templates.type as type, templates.name as template_name, groups.name as group_name, templates.subject as template_subject,
            total_sent, total_delivered, 0 as delivered_percent, 0 as clicked_link, 
            0 as entered_PII, 0 as entered_PIF, 0 as entered_PPL, 0 custom_offer_percent, failed_consumers, 0 as failed_count
        ')->join('templates', 'template_id', '=', 'templates.id')
        ->join('groups', 'group_id', '=', 'groups.id')
        ->where('campaigns.company_id', $user->company_id)
        ->whereRaw($queries)
        ->orderBy('campaigns.sent_at', 'DESC')          
        ->limit($request->input("length"))
        ->offset($request->input("start"))
        ->get();

        foreach($campaigns as $campaign)
        {
            if(!empty($campaign->sent_at) && $campaign->sent_at != null)
                $campaign->format_date = date('Y-m-d H:i', strtotime($campaign->sent_at));

            if($campaign->group_enabled && $campaign->template_enabled)
                $campaign->enabled = 1;

            $campaign->delivered_percent = $campaign->total_sent != 0 ? number_format($campaign->total_delivered / $campaign->total_sent * 100, 2) : 0.00;

            if($consumers->where('campaign_id', $campaign->id)->count() > 0)
                $consumer = $consumers->where('campaign_id', $campaign->id)->first();
            else
                continue;

            $campaign->clicked_link =  $campaign->total_delivered != 0 ? number_format($consumer->clicked / $campaign->total_delivered * 100, 2)."%"  : 0.00."%";
            $campaign->entered_PII =  $consumer->clicked != 0 ? number_format($consumer->entered_pii / $consumer->clicked * 100, 2)."%"  : 0.00."%";
            $campaign->entered_PIF = $consumer->entered_pii != 0 ? number_format($consumer->pif / $consumer->entered_pii * 100, 2)."%" : 0.00."%";
            $campaign->entered_PPL = $consumer->entered_pii != 0 ? number_format($consumer->ppl / $consumer->entered_pii * 100, 2)."%" : 0.00."%";
            $campaign->custom_offer_percent = $consumer->entered_pii != 0 ? number_format($consumer->custom_offer / $consumer->entered_pii * 100, 2)."%" : 0.00."%";
            $campaign->failed_count = $campaign->failedConsumersCount();
        }

        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_campaigns),
            "recordsFiltered" => intval($filtered_campaigns),
            "data"            => $campaigns
            );

        echo json_encode($json_data);
    }
}