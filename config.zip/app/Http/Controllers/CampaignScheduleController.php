<?php

namespace App\Http\Controllers;

use App\Campaign;
use App\Group;
use App\ScheduledCampaign;
use App\Template;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use DB;

class CampaignScheduleController extends Controller
{
    public function index($id = null){
        $edit = ScheduledCampaign::where('id', $id)->first();
        $scheduled = ScheduledCampaign::where('company_id', auth()->user()->company_id)->get();
        $groups = Group::where('enabled', true)->where('company_id', auth()->user()->company_id)->latest()->get();
        $templates = Template::where('company_id', auth()->user()->company_id)->where('enabled', true)->get();

        return view('yn.modules.communication.scheduleCampaign', compact('edit', 'scheduled', 'groups', 'templates'));
    }

    public function store(Request $request){
        if($request->id != null){
            $schedule = ScheduledCampaign::find($request->id);
            $message = "Schedule Updated";
        }
        else{
            $schedule = new ScheduledCampaign;
            $message = "Campaign has been scheduled";
        }

        $schedule->company_id = auth()->user()->company_id;
        $schedule->group_id = $request->group_id;
        $schedule->template_id = $request->template_id;
        $schedule->frequency = $request->frequency;
        $schedule->save();

        session()->flash('success', $message);
        return redirect()->to(route('ScheduleCampaign'));
    }

    public function delete($id){
        ScheduledCampaign::where('id', $id)->delete();
        session()->flash('success', "Schedule was deleted");
        return redirect()->back();
    }

    public function togglePause($id){
        $schedule = ScheduledCampaign::find($id);

        if($schedule->enabled){
            $schedule->enabled = false;
            $message = "Schedule is now paused";
        }
        else{
            $schedule->enabled = true;
            $message = "Schedule is now unpaused";
        }
        $schedule->save();

        session()->flash('success', $message);
        return redirect()->back();
    }
}