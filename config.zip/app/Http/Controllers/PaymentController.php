<?php

namespace App\Http\Controllers;

use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;

use App\Consumer;
use Carbon\Carbon;
use DB;
use App\Transaction;
use SoapClient;

class PaymentController extends Controller {

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct() {
        //$this->middleware('auth'); // later enable it when needed user login while payment
    }
   
   /////////////////////////////////////////////////////////authorize.net///////////////////////////
    // start page form after start
    public function pay() {
       try{
         $consumers = DB::table('consumers')
         ->join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
         ->join('companies', 'companies.id', '=', 'consumers.company_id')
         ->join('payment_profiles', 'payment_profiles.id', '=', 'schedule_transactions.payment_profile_id')
         ->whereRaw('DATE(schedule_transactions.schedule_date) = DATE(now())')
         ->whereRaw('schedule_time between now() - interval 55 minute and now()') //add 5 minute on time  
         ->where('schedule_transactions.payment_complete','=','0')
         ->selectRaw("
            DATE(schedule_transactions.schedule_date) payment_processing_date,
            consumers.account_number,
            consumers.id,
            consumers.company_id,
            consumers.sub_client1_id,
            consumers.sub_client1_id,
            consumers.first_name,
            consumers.last_name,
            consumers.address1,
            consumers.address2,
            consumers.city,
            consumers.state,
            consumers.zip,
            consumers.email1,
            consumers.mobile1,
            consumers.consumer_login_id,
            companies.company_name,
            consumers.current_balance,
            schedule_transactions.amount,
            schedule_transactions.id stid,
            schedule_transactions.transaction_type,
            schedule_transactions.transaction_type,
            schedule_transactions.subclient1_share,
            schedule_transactions.subclient2_share,
            schedule_transactions.rnn_share,
            schedule_transactions.processing_charges,
            schedule_transactions.flat_transaction_charges,
            schedule_transactions.company_share,
            schedule_transactions.payment_profile_id,
            schedule_transactions.transaction_type, 
            payment_profiles.profile_id profileid,
            payment_profiles.payment_profile_id paymentprofileid,
            payment_profiles.shipping_profile_id,
            payment_profiles.gateway_type           
            ")
            ->get();
            //dd($consumers);
            foreach($consumers as $clint){
                if($clint->gateway_type == "authorize_net") //athorize.net payment 
                    $this->chargeCustomerProfileAuthorizednet($clint);
                else
                    $this->chargeCustomerProfileUsaEpay($clint);  //Usepay
                }
        }
        catch (Throwable $e) {
            report($e);
        }
    }
    //create profile
    public function create(){
     //create  profile using umail
      $this->createCustomerProfile('soumabha.sunny1987@gmail.com');
    }
    //////////////////////////////////////////////////////////////////////////////////////
    /////////////////////////////////Authorize.net payment ///////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////
    //Card Payment
    public function CCpayment($clint) {
        try{
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName("48uRVjm5N5V");
        $merchantAuthentication->setTransactionKey("2993qcA2xRKCDj6q");

        // Set the transaction's refId
        $refId = 'ref' . time();
        //$cardNumber = preg_replace('/\s+/', '', '4111 1111 1111 '.$clint->last4digit);
        $cardNumber = preg_replace('/\s+/', '', '4111 1111 1111 1111');
        // Create the payment data for a credit card
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber($cardNumber);
        $creditCard->setExpirationDate($clint->expirity);
        $creditCard->setCardCode($clint->cvv);

        // Create order information
        $order = new AnetAPI\OrderType();
        $order->setInvoiceNumber(mt_rand(10000, 99999));
        $order->setDescription("Test Transaction");

        // Set the customer's Bill To address
        $customerAddress = new AnetAPI\CustomerAddressType();
        $customerAddress->setFirstName($clint->first_name);
        $customerAddress->setLastName($clint->last_name);
        $customerAddress->setCompany($clint->company_name);
        $customerAddress->setAddress($clint->address1.' '.$clint->address2);
        $customerAddress->setCity($clint->city);
        $customerAddress->setState($clint->state);
        $customerAddress->setemail($clint->email1);
        $customerAddress->setphoneNumber($clint->email1);
        $customerAddress->setZip($clint->zip);
        $customerAddress->setCountry("USA");

        //shipping address
        $customerShipppingAddress = new AnetAPI\CustomerAddressType();
        $customerShipppingAddress->setFirstName($clint->first_name);
        $customerShipppingAddress->setLastName($clint->last_name);
        $customerShipppingAddress->setCompany($clint->company_name);
        $customerShipppingAddress->setAddress($clint->address1.' '.$clint->address2);
        $customerShipppingAddress->setCity($clint->city);
        $customerShipppingAddress->setState($clint->state);
        $customerShipppingAddress->setZip($clint->zip);
        $customerShipppingAddress->setCountry("USA");

        // Set the customer's identifying information
        $customerData = new AnetAPI\CustomerDataType();
        $customerData->setType("individual");
        $customerData->setId($clint->id);
        $customerData->setEmail($clint->email1);


        // Add the payment data to a paymentType object
        $paymentOne = new AnetAPI\PaymentType();
        $paymentOne->setCreditCard($creditCard);

        // Create a TransactionRequestType object and add the previous objects to it
        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($clint->amount);
        $transactionRequestType->setPayment($paymentOne);
        $transactionRequestType->setOrder($order);
        $transactionRequestType->setPayment($paymentOne);
        $transactionRequestType->setBillTo($customerAddress);
        $transactionRequestType->setCustomer($customerData);
        $transactionRequestType->setShipTo($customerShipppingAddress);

        // Assemble the complete transaction request
        $requests = new AnetAPI\CreateTransactionRequest();
        $requests->setMerchantAuthentication($merchantAuthentication);
        $requests->setRefId($refId);
        $requests->setTransactionRequest($transactionRequestType);

        // Create the controller and get the response
        $controller = new AnetController\CreateTransactionController($requests);
        $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
        // dd($response);
        if ($response != null) {
            // Check to see if the API request was successfully received and acted upon
        if ($response->getMessages()->getResultCode() == "Ok") {
                // Since the API request was successful, look for a transaction response
                // and parse it to display the results of authorizing the card
            $tresponse = $response->getTransactionResponse();

            if ($tresponse != null && $tresponse->getMessages() != null) {

                $status_code=$tresponse->getResponseCode();
                $status="Successful";
               // $codemsg=$tresponse->getMessages()[0]->getCode();

            } else {
                $status_code = 'There were some issue with the payment. Please try again later.';
                $status = "Failed";                                    

                if ($tresponse->getErrors() != null) {
                    $status_code = $tresponse->getErrors()[0]->getErrorText();
                    $status = "Failed";                                    
                }
            }
                // Or, print errors if the API request wasn't successful
            } else {
            $status_code = 'There were some issue with the payment. Please try again later.';
            $status = "Failed";                                    

            $tresponse = $response->getTransactionResponse();

            if ($tresponse != null && $tresponse->getErrors() != null) {
                $status_code = $tresponse->getErrors()[0]->getErrorText();
                $status = "Failed";                    
            } else {
                $status_code = $response->getMessages()->getMessage()[0]->getText();
                $status = "Failed";
            }                
            }
        } else {
        $status_code = "null";
        $status = "Failed";
        }
        $transaction = $this->transferToTransactionTable($clint,$tresponse,$status,$status_code);
        return true;
        }
        catch (Throwable $e) {
            report($e);
            return false;
            }
    }
    //Account Payment 
    public function AccountPayment($clint) {
        try{
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName("48uRVjm5N5V");
        $merchantAuthentication->setTransactionKey("2993qcA2xRKCDj6q");

        // Set the transaction's refId
        // Set the transaction's refId
        $refId = 'ref' . time();

        //Generate random bank account number
        $randomAccountNumber= $clint->account_number;

        // Create the payment data for a Bank Account
        $bankAccount = new AnetAPI\BankAccountType();
        $bankAccount->setAccountType('checking');
        // see eCheck documentation for proper echeck type to use for each situation
        $bankAccount->setEcheckType('WEB');
        $bankAccount->setRoutingNumber('122000661');

        $bankAccount->setAccountNumber('00001252525');

        $bankAccount->setNameOnAccount($clint->first_name .' '.$clint->last_name);
        $bankAccount->setBankName('Wells Fargo Bank NA');

        $paymentBank= new AnetAPI\PaymentType();
        $paymentBank->setBankAccount($bankAccount);

        // Order info
        $order = new AnetAPI\OrderType();
        $order->setInvoiceNumber(mt_rand(100,9999999));
        $order->setDescription("Test Transaction");

        //create a bank debit transaction

        $transactionRequestType = new AnetAPI\TransactionRequestType();
        $transactionRequestType->setTransactionType("authCaptureTransaction");
        $transactionRequestType->setAmount($clint->amount);
        $transactionRequestType->setPayment($paymentBank);
        $transactionRequestType->setOrder($order);
        $request = new AnetAPI\CreateTransactionRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setRefId($refId);
        $request->setTransactionRequest($transactionRequestType);
        $controller = new AnetController\CreateTransactionController($request);
        $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
        //dd($response);
        if ($response != null) {
            if ($response->getMessages()->getResultCode() == "Ok") {
                $tresponse = $response->getTransactionResponse();

                if ($tresponse != null && $tresponse->getMessages() != null) {
                    $status_code=$tresponse->getResponseCode();
                    $status="Successful";
                } else {

                    if ($tresponse->getErrors() != null) {
                      $status_code = $tresponse->getErrors()[0]->getErrorCode() ;
                      $status ="Failed";
                  }
              }
          } 
          else {
                $tresponse = $response->getTransactionResponse();
                if ($tresponse != null && $tresponse->getErrors() != null) {
                    $status_code = $tresponse->getErrors()[0]->getErrorCode() ;
                    $status ="Failed";
                    }
                else {
                    $status_code ='null' ;
                    $status ="Failed";
                    }
            }
        } 
        else {
            $status_code ="error" ;
            $status ="Failed";;
        }
        $transaction = $this->transferToTransactionTable($clint,$tresponse,$status,$status_code);
        return true;
        }
        catch (Throwable $e) {
            report($e);
            return false;
        }
    }
    //Transfer data to transaction table and update others tables
    public function transferToTransactionTable($clint,$tid,$tresponse,$status,$status_code){
            try{

             Transaction::create([                                         
                    'transaction_id' => $tid,
                    'transaction_type' => $clint->transaction_type,
                    'consumer_login_id' => $clint->consumer_login_id,
                    'consumer_id' =>$clint->id,
                    'company_id'  =>$clint->company_id,
                    'payment_profile_id' =>$clint->payment_profile_id,
                    'gateway_respnse_raw'=>(string)( json_encode($tresponse,true)),
                    'status_code' => $status_code,
                    'status' => $status,
                    'amount' => $clint->amount,
                    'processing_charges' => $clint->processing_charges,
                    'flat_transaction_charges' => $clint->flat_transaction_charges,
                    'rnn_share' =>$clint->rnn_share,
                    'company_share' => $clint->company_share,
                    'subclient1_share' =>$clint->subclient1_share,
                    'subclient2_share' =>$clint->subclient2_share,
                    'created_at' => carbon::now(),
                    'updated_at' => carbon::now()
                ]);

            }
            catch (Throwable $e) {
               dd($e);
            }
        }
    //create customer profile
    public function createCustomerProfile()
    {
        /* Create a merchantAuthenticationType object with authentication details
        retrieved from the constants file */
   
        $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
        $merchantAuthentication->setName('48uRVjm5N5V');
        $merchantAuthentication->setTransactionKey('2993qcA2xRKCDj6q');
    
        // Set the transaction's refId
        $refId = 'ref' . time();

        // Create a Customer Profile Request
        //  1. (Optionally) create a Payment Profile
        //  2. (Optionally) create a Shipping Profile
        //  3. Create a Customer Profile (or specify an existing profile)
        //  4. Submit a CreateCustomerProfile Request
        //  5. Validate Profile ID returned

       // Set credit card information for payment profile
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber("4242424242424242");
        $creditCard->setExpirationDate("2038-12");
        $creditCard->setCardCode("142");
        $paymentCreditCard = new AnetAPI\PaymentType();
        $paymentCreditCard->setCreditCard($creditCard);


        // $bankAccount = new AnetAPI\BankAccountType();
        // $bankAccount->setAccountType('checking');
        // // see eCheck documentation for proper echeck type to use for each situation
        // $bankAccount->setEcheckType('WEB');
        // $bankAccount->setRoutingNumber('122000661');

        // $bankAccount->setAccountNumber('00001252825');

        // $bankAccount->setNameOnAccount("SUNNY PAL");
        // $bankAccount->setBankName('Wells Fargo Bank NA');

        // $paymentBank= new AnetAPI\PaymentType();
        // $paymentBank->setBankAccount($bankAccount);

        // Create the Bill To info for new payment type
        $billTo = new AnetAPI\CustomerAddressType();
        $billTo->setFirstName("Ellen");
        $billTo->setLastName("Johnson");
        $billTo->setCompany("Souveniropolis");
        $billTo->setAddress("14 Main Street");
        $billTo->setCity("Pecan Springs");
        $billTo->setState("TX");
        $billTo->setZip("44628");
        $billTo->setCountry("USA");
        $billTo->setPhoneNumber("888-888-8888");
        $billTo->setfaxNumber("999-999-9999");

        // Create a customer shipping address
        $customerShippingAddress = new AnetAPI\CustomerAddressType();
        $customerShippingAddress->setFirstName("James");
        $customerShippingAddress->setLastName("White");
        $customerShippingAddress->setCompany("Addresses R Us");
        $customerShippingAddress->setAddress(rand() . " North Spring Street");
        $customerShippingAddress->setCity("Toms River");
        $customerShippingAddress->setState("NJ");
        $customerShippingAddress->setZip("08753");
        $customerShippingAddress->setCountry("USA");
        $customerShippingAddress->setPhoneNumber("888-888-8888");
        $customerShippingAddress->setFaxNumber("999-999-9999");

        // Create an array of any shipping addresses
        $shippingProfiles[] = $customerShippingAddress;


        // Create a new CustomerPaymentProfile object
        $paymentProfile = new AnetAPI\CustomerPaymentProfileType();
        $paymentProfile->setCustomerType('individual');
        $paymentProfile->setBillTo($billTo);
        //$paymentProfile->setPayment($paymentCreditCard);
        $paymentProfile->setPayment($paymentCreditCard);
        $paymentProfiles[] = $paymentProfile;


        // Create a new CustomerProfileType and add the payment profile object
        $customerProfile = new AnetAPI\CustomerProfileType();
        $customerProfile->setDescription("Customer 2 Test PHP");
        $customerProfile->setMerchantCustomerId("M_" . time());
        $customerProfile->setEmail("soumabha.sunny1987@mail.com");
        $customerProfile->setpaymentProfiles($paymentProfiles);
        $customerProfile->setShipToList($shippingProfiles);


        $validationmode = "liveMode";

        // Assemble the complete transaction request
        $request = new AnetAPI\CreateCustomerProfileRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setRefId($refId);
        $request->setProfile($customerProfile);
        $request->setValidationMode($validationmode);

        // Create the controller and get the response
        $controller = new AnetController\CreateCustomerProfileController($request);
        $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::SANDBOX);
        dd($response);
        if (($response != null) && ($response->getMessages()->getResultCode() == "Ok")) {
          
          $profile_id = $response->getCustomerProfileId();
          $payment_profile_id =  $response->getCustomerPaymentProfileIdList()[0];
          $shipping_id =  $response->getcustomerShippingAddressIdList()[0];
            //Payment Profile created
        } else {
            //Payment filed
        }
        dd($response);
    }
    //Update Payment Profile

    public function updateCustomerPaymentProfile($customerProfileId = "1916322670", $customerPaymentProfileId = "1829639667") 
        {
            /* Create a merchantAuthenticationType object with authentication details
               retrieved from the constants file */
            $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
            $merchantAuthentication->setName("48uRVjm5N5V");
            $merchantAuthentication->setTransactionKey("2993qcA2xRKCDj6q");
    
            // Set the transaction's refId
            $refId = 'ref' . time();

            $request = new AnetAPI\GetCustomerPaymentProfileRequest();
            $request->setMerchantAuthentication($merchantAuthentication);
            $request->setRefId( $refId);
            $request->setCustomerProfileId($customerProfileId);
            $request->setCustomerPaymentProfileId($customerPaymentProfileId);
      
            $controller = new AnetController\GetCustomerPaymentProfileController($request);
            $response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);
            if (($response != null) && ($response->getMessages()->getResultCode() == "Ok"))
            {
        $billto = new AnetAPI\CustomerAddressType();
        $billto = $response->getPaymentProfile()->getbillTo();
        
        $creditCard = new AnetAPI\CreditCardType();
        $creditCard->setCardNumber( "4242424242424242" );
        $creditCard->setExpirationDate("2038-12");
        $creditCard->setCardCode("142");
        
        $paymentCreditCard = new AnetAPI\PaymentType();
        $paymentCreditCard->setCreditCard($creditCard);
        $paymentprofile = new AnetAPI\CustomerPaymentProfileExType();
        $paymentprofile->setBillTo($billto);
        $paymentprofile->setCustomerPaymentProfileId($customerPaymentProfileId);
        $paymentprofile->setPayment($paymentCreditCard);    

        // We're updating the billing address but everything has to be passed in an update
        // For card information you can pass exactly what comes back from an GetCustomerPaymentProfile
        // if you don't need to update that info
          
        // Update the Bill To info for new payment type
        $billto->setFirstName("Mrs Mary");
        $billto->setLastName("Doe");
        $billto->setAddress("9 New St.");
        $billto->setCity("Brand New City");
        $billto->setState("WA");
        $billto->setZip("98004");
        $billto->setPhoneNumber("000-000-0000");
        $billto->setfaxNumber("999-999-9999");
        $billto->setCountry("USA");
         
        // Update the Customer Payment Profile object
        $paymentprofile->setBillTo($billto);

        // Submit a UpdatePaymentProfileRequest
        $request = new AnetAPI\UpdateCustomerPaymentProfileRequest();
        $request->setMerchantAuthentication($merchantAuthentication);
        $request->setCustomerProfileId($customerProfileId);
        $request->setPaymentProfile( $paymentprofile );

        $controller = new AnetController\UpdateCustomerPaymentProfileController($request);
        $response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);
        if (($response != null) && ($response->getMessages()->getResultCode() == "Ok") )
        {
            $Message = $response->getMessages()->getMessage();
            $msg= "Success";
        }
        else if ($response != null)
        {
            $errorMessages = $response->getMessages()->getMessage();
            $msg= "Failed";
        }
    
        return $response;
            }
            else
            {
                 $msg= "Failed";
            }

            return $response;
        }
    //customer profile payment 
    public function chargeCustomerProfileAuthorizednet($clint)
    {
        dd($clint);
        try{
            $tresponse ="";
            /* Create a merchantAuthenticationType object with authentication details
            retrieved from the constants file */
            $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
            $merchantAuthentication->setName('48uRVjm5N5V');
            $merchantAuthentication->setTransactionKey('2993qcA2xRKCDj6q');
        
            // Set the transaction's refId
            $refId = 'ref' . time();

            $profileToCharge = new AnetAPI\CustomerProfilePaymentType();
            $profileToCharge->setCustomerProfileId($clint->profileid);
            $paymentProfile = new AnetAPI\PaymentProfileType();
            $paymentProfile->setPaymentProfileId($clint->paymentprofileid);
            $profileToCharge->setPaymentProfile($paymentProfile);

            $transactionRequestType = new AnetAPI\TransactionRequestType();
            $transactionRequestType->setTransactionType( "authCaptureTransaction"); 
            $transactionRequestType->setAmount($clint->amount);
            $transactionRequestType->setProfile($profileToCharge);

            $request = new AnetAPI\CreateTransactionRequest();
            $request->setMerchantAuthentication($merchantAuthentication);
            $request->setRefId( $refId);
            $request->setTransactionRequest( $transactionRequestType);
            $controller = new AnetController\CreateTransactionController($request);
            $response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);
            if ($response != null)
                {
                    if($response->getMessages()->getResultCode() == "Ok")
                        {
                            $tresponse = $response->getTransactionResponse();
        
                            if ($tresponse != null && $tresponse->getMessages() != null)   
                                {
                                    //Update schedule transaction table 
                                    DB::table('schedule_transactions')->where('id', $clint->stid)->update(['payment_complete' => 1]);
                                    $status_code=$tresponse->getResponseCode();
                                    $status="Successful";
                                }
                            else
                                {
                                    $status_code = "";
                                    $status = "Failed";      
                                    if($tresponse->getErrors() != null)
                                        {
                                            $status_code = $tresponse->getErrors()[0]->getErrorCode();
                                            $status = "Failed";               
                                        }
                                }
                        }
                    else
                        {
                            $status_code = "";
                            $status = "Failed";   
                            $tresponse = $response->getTransactionResponse();
                                if($tresponse != null && $tresponse->getErrors() != null)
                                    {
                                        $status_code = $tresponse->getErrors()[0]->getErrorCode();
                                        $status = "Failed";                     
                                    }
                                else
                                    {
                                        $status_code = $tresponse->getErrors()[0]->getErrorCode();
                                        $status = "Failed";    
                                    }
                        }     
                }
            else
                {
                    $status_code = "";
                    $status = "Failed";
                }
            $tid= $tresponse->getTransId();
            $transaction = $this->transferToTransactionTable($clint,$tid,$tresponse,$status,$status_code);
            dd($transaction);
            return true;
        }
        catch (Throwable $e) {
            report($e);
            return false;
        }
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////
    ////////////////////////////////////////useaepay///////////////////////////////////////////////
    ///////////////////////////////////////////////////////////////////////////////////////////////
    public function UseAePay(){

        // $sourcekey = '_801Q6Z0hS6P07jJ2lD3AoZ9Q2EeEFv8';
        // $sourcepin = '2525';
        // $sandbox = true;
        // $options = [
        // 'debug' => true,
        // ];

        // $usaepay = new \PhpUsaepay\Client($sourcekey, $sourcepin, $sandbox);
        //dd($usaepay);
        //$profile = $this->updateCustomer();

         $profile = $this->customerTransaction();

        //$profile = $this->customerTransaction();
    }
    //create useaepay 
    public function createProfile(){
            try {
            $CustomerData=array(
            'BillingAddress'=>array(
            'FirstName'=>'TEST',
            'LastName'=>'TEST',
            'Company'=>'Acme Corp',
            'Street'=>'1234 main st',
            'Street2'=>'Suite #123',
            'City'=>'Los Angeles',
            'State'=>'CA',
            'Zip'=>'12345',
            'Country'=>'US',
            'Email'=>'charlie@usaepay.com',
            'Phone'=>'333-333-3333',
            'Fax'=>'333-333-3334'),
            'PaymentMethods' =>array(          
                            'CreditCardData' => array( 
                            'CardNumber'=>'4444555566667779', 
                            'CardExpiration'=>'2025-12', 
                            'MethodName'=>'CC', 
                            'SecondarySort'=>1,
                            "Expires"=>""
                            )  
            ), 
            //new added
            'CustomFields'=>array(
                                array('Field'=>'Foo', 'Value'=>'Testing'),
                                 array('Field'=>'Bar', 'Value'=>'Tested')
                                ),  

            'CustomData'=>base64_encode(serialize(array("mydata"=>"We could put anything in here!"))),
            'CustomerID'=>123123 + rand(),
            'Description'=>'test',
            'Enabled'=>false,
            'Amount'=>'0.0',
            'Tax'=>'0',
            'Next'=>'',
            'Notes'=>'Testing the soap addCustomer Function',
            'NumLeft'=>'50',
            'OrderID'=>rand(),
            'ReceiptNote'=>'addCustomer test Created Charge',
            'SendReceipt'=>true,
            'Source'=>'Recurring',
            'CustNum'=>'C'.rand(),
            'Schedule'=>'',
            'User' =>''  //new added
            );
 
            //production mode need to rempve $verify bool
            $Default=true; 
            $verify=true; 
            $wsdl='https://www.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
            $client = new SoapClient($wsdl);
            $token = $this->getToken();
            //dd($CustomerData);
            $result=$client->addCustomer($token,$CustomerData); // need to save db
            dd($result);
            if($result){
                $type = "CC"; //
                $res = $this->updateCustomerPaymentDetails($result,$type);
                dd($res);
                // responce customer number need to save
            }
            else{
             // null return (error to setup customer profile)
            }


            }

            catch(\Throwable $e) {
            dd($e);
            }
    }
    public function updateCustomerPaymentDetails(){
         try {
                $custNum ="11236761"; 
                $wsdl='https://sandbox.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
                $client = new SoapClient($wsdl);
                $token = $this->getToken();
                $paymethods = $client->getCustomerPaymentMethods($token, $custNum );
                $methodId= $paymethods[0]->MethodID;
                $PaymentMethod=array(
                        'MethodID' =>  $methodId,
                        'MethodName'=>'cc',
                        'CardNumber'=>'4444555566667779',
                        'CardExpiration'=>'2021-02',
                        'CardType'=>'',    
                        'CardCode'=>'',
                        'SecondarySort'=>0,
                    );
              
                $Verify=true; 
             

                $res=$client->updateCustomerPaymentMethod($token, $PaymentMethod, $Verify);
                if($res == true){
                    dd( $res);
                }
                else
                {
                    dd( $res);
                }

           }
        catch(\Throwable $e) {
            dd($e->getMessage());
        }
    }
    public function chargeCustomerProfileUsaEpay($clint){
        try {
                $Details=array( 
                'Invoice' => rand(), 
                'PONum' => '', 
                'OrderID' => rand(), 
                'Description' => 'sample Test', 
                'Amount'=>-2
                ); 

                $CustNum='11239401';
                $Command='cd::Sale'; 
                $PayMethod='0'; 
                $Verify=false;     
                // instantiate SoapClient object as $client
                $wsdl='https://sandbox.usaepay.com/soap/gate/3213EA2A/usaepay.wsdl';
                $client = new SoapClient($wsdl);
                $token = $this->getToken();
                $res=$client->runCustomerTransaction($token, $CustNum, $Details, $Command, $PayMethod); 
                $tid= $res->RefNum;
                if($res->ResultCode == "A"){
                    $status_code = "A";
                    $status = "Successful"; 
                    //Update schedule transaction table 
                    DB::table('schedule_transactions')->where('id', $clint->stid)->update(['payment_complete' => 1]);
                  
                }
                else {
                    $status_code = "";
                    $status = "Failed"; 
                }
            $this->transferToTransactionTable($clint,$tid,$res,$status,$status_code);
        }

        catch (\Throwable $e) {
            dd($e);
        }
    }
    public function getToken(){
        $sourcekey = '_801Q6Z0hS6P07jJ2lD3AoZ9Q2EeEFv8';
        $pin = '2525'; 
        // generate random seed value
        $seed=time() . rand();
        // make hash value using sha1 function
        $clear= $sourcekey . $seed . $pin;
        $hash=sha1($clear);
        // assembly ueSecurityToken as an array
        $token=array(
        'SourceKey'=>$sourcekey,
        'PinHash'=>array(
       'Type'=>'sha1',
       'Seed'=>$seed,
       'HashValue'=>$hash
        ),
        'ClientIP'=>$_SERVER['REMOTE_ADDR'],
        );
     return $token;
    }

}

