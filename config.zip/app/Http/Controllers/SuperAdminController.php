<?php

namespace App\Http\Controllers;

use App\Repositories\CommunicationRepository;
use App\Repositories\CompanyRepository;
use App\Repositories\SubclientRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use App\Merchant;
use App\User;
use App\RnnCommission;

class SuperAdminController extends Controller
{

    private $companyRepository, $subclientRepository, $userRepository, $communicationRepository;

    public function __construct(CompanyRepository $companyRepository, SubclientRepository $subclientRepository,
                                UserRepository $userRepository, CommunicationRepository $communicationRepository)
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:superadmin');
        // $this->middleware('role:superadmin');
        $this->companyRepository = $companyRepository;
        $this->subclientRepository = $subclientRepository;
        $this->userRepository = $userRepository;
        $this->communicationRepository = $communicationRepository;
    }

    public function companies()
    {
        $companies = $this->companyRepository->getAllCompanies();
        $company_users = $this->userRepository->companyUsers(auth()->user());
        return view('yn.superadmin.company', compact('companies', 'company_users'));
    }

    public function approve($id)
    {
        $company = $this->companyRepository->getByID($id);
        $company->approve();
        $this->communicationRepository->sendCompanyApproveEmail($company);
        return redirect()->back()->with('success', 'Company Approved!');
    }

    public function reject($id)
    {
        $company = $this->companyRepository->getByID($id);
        $company->reject();
        $this->communicationRepository->sendCompanyRejectEmail($company);
        return redirect()->back()->with('success', 'Application for ' . $company->name . ' Rejected!');
    }

    public function sendCommission(Request $request)
    {   
        $this->companyRepository->update('id', $request->get('company_id'), $request->only('send_commission'));
        return redirect()->back()->with('success', 'Send Commission Records Saved!');
    }

    public function configure(Request $request)
    {
        $this->companyRepository->update('id', $request->get('company_id'), $request->only(config('app.company.config_fields')));
        if($this->companyRepository->getByID($request->get('company_id'))->merchant->status() == 'Verified'){
            $status = $this->companyRepository->getByID($request->get('company_id'))->approve();
            if ($status) {
                return redirect()->back()->with('success', 'Configuration updated and company approved!');
            } else {
                return redirect()->back()->with('warning', 'Configuration updated but profile not approved as profile is not complete!');
            }
        }
        else{
            return redirect()->to(url('superadmin', 'merchants'))->with('warning', 'Please verify merchant details before approving company!');
        }
    }

    public function updateCommunicationLimit(Request $request)
    {
        $this->companyRepository->updateCommunicationLimit($request->get('company_id'), $request->get('sms_limit'), $request->get('email_limit'));
        return redirect()->to(url('superadmin', ['companies']))->with('success', 'SMS, Email, and E-Letter Limit Updated');
    }

    public function subclients()
    {
        $subclients = $this->subclientRepository->getAllSubclients();
        return view('yn.superadmin.subclient', compact('subclients'));
    }

    public function users()
    {
        $users = $this->userRepository->getAllUsers();
        return view('yn.superadmin.users', compact('users'));
    }

    public function merchant()
    {
        $merchants = Merchant::with(['subclient', 'company'])->orderBy('created_at','desc')->get();
        return view('yn.superadmin.merchants', compact('merchants'));
    }

    public function verifyMerchant(Request $request)
    {
        $merchant = Merchant::find($request->get('merchant_id'));
        $type = $request->get('merchant_type');

        if($merchant->name == "authorize") {                          //check for authorized .net merchant type
            $request['merchant_type'] =$type[0];
        } else if($merchant->name == 'usaepay') {                     //check for usaEpay  merchant type
            $request['merchant_type'] =$type[1];
        } else {                                                      //check for paidyet merchant type
            $request['merchant_type'] =$type[2];
        }

        // if($request['merchant_type']=="Select Type"){
        //     return redirect()->back()->with('warning', 'Please Select Payment Type for merchant!! ');
        // }

        $merchant->update($request->except(['merchant_id', '_token']));
        $status = $merchant->verify();
        if($status){
            Merchant::where('id', $request->get('merchant_id'))->update(['verified_at' => now()]);
            return redirect()->back()->with('success', 'Merchant verified successfully!');
        }else{
            Merchant::where('id', $request->get('merchant_id'))->update(['verified_at' => null]);
            return redirect()->back()->with('error', 'Merchant not valid. Please check merchant details!');
        }

    }

    public function rnnUsers(){
        $company_id  = auth()->user()->company_id;
        $rnnUsers = User::where('company_id', $company_id)->get();
        return view('yn.superadmin.rnn-users', compact('rnnUsers'));
    }

}