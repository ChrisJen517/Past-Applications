<?php

namespace App\Http\Controllers;

use App\Repositories\CommunicationRepository;
use App\Repositories\EmailRepository;
use App\Repositories\SubclientRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use App\Company;

class UserController extends Controller
{

    protected $repository, $communicationRepository, $subclientRepository;

    public function __construct(UserRepository $repository, CommunicationRepository $communicationRepository, SubclientRepository $subclientRepository)
    {
        $this->middleware(['auth', 'check-profile-completed']);
        $this->middleware('sidebar-menu:account');
        $this->repository = $repository;
        $this->communicationRepository = $communicationRepository;
        $this->subclientRepository = $subclientRepository;
    }

    public function index()
    {
        $users = $this->repository->companyUsers(auth()->user());
        $subclients = $this->subclientRepository->subclients(auth()->user()->company_id, false);
        $companies = Company::all();
        return view('yn.modules.account.user', compact('users', 'subclients', 'companies'));
    }

    public function store(Request $request)
    {
        $user = $this->repository->createUser($request->validate($this->repository->creationValidationRules()), auth()->user()->company);
        session()->flash('success', "User: " . $user->name . " has been created");
        return redirect()->to(route('user'));
    }

    public function edit($id)
    {
        $user = $this->repository->get('id', $id);
        $users = $this->repository->companyUsers(auth()->user());
        $subclients = $this->subclientRepository->subclients(auth()->user()->company_id, false);
        $companies = Company::all();
        return view('yn.modules.account.user', compact('user', 'users', 'subclients', 'companies'));
    }

    public function update($id, Request $request)
    {
        $params = $request->validate($this->repository->updateValidationRules());
        $this->repository->update('id', $id, $params);
        $user = $this->repository->getByID($id);
        session()->flash('success', "User: " . $user->name . " has been updated!");
        return redirect()->back();
    }

    public function resetPassword(Request $request)
    {
        $request->get('user_id');
        $status = $this->repository->resetPassword($request->get('user_id'));
        if ($status) {
            session()->flash('success', "Password has been reset and sent to user email!");
        } else {
            session()->flash('error', "You are not authorized to change this user's password!");
        }
        return redirect()->back();
    }

    public function toggleBlock(Request $request)
    {
        $this->repository->toggleBlock($request->get('user_id'), auth()->user()->id);
        $user = $this->repository->getByID($request->get('user_id'));
        session()->flash('success', "The user: " . $user->name . " has been " . $user->blockedStatus() . " successfully!");
        return redirect()->back();
    }

    public function delete($id)
    {
        $user = $this->repository->getByID($id);
        $this->repository->delete($id);
        session()->flash('success', "User: " . $user->name . " has been deleted!");
        return redirect()->back();
    }

}