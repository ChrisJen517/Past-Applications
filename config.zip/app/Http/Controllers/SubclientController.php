<?php

namespace App\Http\Controllers;

use App\Repositories\MerchantRepository;
use App\Repositories\SubclientRepository;
use Illuminate\Http\Request;

class SubclientController extends Controller
{
    private $repository, $merchantRepository;

    public function __construct(SubclientRepository $repository, MerchantRepository $merchantRepository)
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:users-clients');
        $this->repository = $repository;
        $this->merchantRepository = $merchantRepository;
    }

    public function index()
    {
        $subclients = $this->repository->subclients(auth()->user()->company_id);
        return view('subclient.index', compact('subclients'));
    }

    public function create($subclient_type)
    {
        $parent_ids = $this->repository->parentIds($subclient_type, auth()->user()->company_id);
        return view('subclient.create', compact('parent_ids', 'subclient_type'));
    }

    public function store(Request $request)
    {
        $params = $request->validate($this->repository->creationValidationRules() +
            $this->merchantRepository->creationValidationRules());
        $subclient = $this->repository->createSubclient($params);
        $message = $this->repository->getSuccessMessage($subclient);
        return redirect()->to('subclient')->with('success', $message);
    }

    public function edit($id)
    {
        $subclient = $this->repository->get('id', auth()->user()->id);
        $subclient_type = $subclient->subclient_type;
        $parent_ids = $this->repository->parentIds($subclient_type, auth()->user()->company_id);
        return view('subclient.edit', compact('subclient', 'subclient_type', 'parent_ids'));
    }

    public function update($id, Request $request)
    {
        $params = $request->validate($this->repository->updateValidationRules());
        $status = $this->repository->update('id', $id, $params);
        return redirect()->to('/subclient');
    }

    public function delete($id)
    {
        $this->repository->delete($id);
        return redirect()->back();
    }

}
