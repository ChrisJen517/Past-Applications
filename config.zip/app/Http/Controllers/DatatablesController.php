<?php

namespace App\Http\Controllers;

use App\Consumer;
use Illuminate\Http\Request;
use Datatables;

class DatatablesController extends Controller
{
    public function consumers(Request $request)
    {
        $consumers = Consumer::with(['unsubscription'])->where('company_id', auth()->user()->company_id)
        ->where('status', '<>', 'deactivated');

        return datatables()->of($consumers)
        ->addColumn('consumer_details', function($row){
            return $row->full_name;
        })
        ->addColumn('action', function($row){
            $btn = '<a href="'.url('report', ['delete-consumer', $row->id]).'" class="m-1 btn btn-sm btn-danger swal-confirm">Delete</a>';
            if($row->subscribed()){
                $subscribe = '<a class="m-1 btn btn-sm btn-warning swal-confirm" href="'.url('consumer-unsubscribe',$row->id).'">Unsubscribe</a>';
            }else{
                $subscribe = '<a class="m-1 btn btn-sm btn-success swal-confirm" href="'.url('consumer-subscribe',$row->id).'">Subscribe</a>';
            }
            return $btn .$subscribe;
        })
        ->rawColumns(['action'])
        ->make(true);
    }
}
