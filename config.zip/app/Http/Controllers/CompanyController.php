<?php

namespace App\Http\Controllers;

use App\Repositories\CompanyRepository;
use Illuminate\Http\Request;

class CompanyController extends Controller
{

    protected $repository;

    public function __construct(CompanyRepository $companyRepository)
    {
        $this->middleware(['auth']);
        $this->middleware('check-profile-completed')->except(['registrationForm', 'completeRegistration']);
        $this->repository = $companyRepository;
    }

    public function index()
    {
        try{
            $companies = $this->repository->companies();
            return view('company.index', compact('companies'));
        }
        catch (Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while view this data!');
        }
        
    }

    public function edit($id)
    {
        try{
            $company = $this->repository->get('id', auth()->user()->id);
            return view('company.edit', compact('company'));
        }
        catch (Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
    }

    public function update($id, Request $request)
    {
        try{
            $params = $request->validate($this->repository->updateValidationRules());
            $status = $this->repository->update('id', auth()->user()->id, $params);
            return redirect()->to('/company');
        }
        catch (Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
        
    }

}
