<?php

namespace App\Http\Controllers;

use App\Repositories\CampaignRepository;
use App\Repositories\ConsumerRepository;
use App\Repositories\CompanyRepository;
use App\Repositories\GroupRepository;
use App\Repositories\TemplateRepository;
use App\Template;
use App\Traits\EnableDisableTrait;
use Illuminate\Http\Request;
use App\Group;
use App\Export\GroupExport;
use Excel;
use DB;
use Carbon\Carbon;

class GroupTermsController extends Controller
{
    protected $repository, $consumerRepository, $companyRepository;

    public function __construct(GroupRepository $repository, ConsumerRepository $consumerRepository, CompanyRepository $companyRepository)
    {
        $this->middleware(['auth', 'check-profile-completed', 'redirect-if-subclient-user']);
        $this->middleware('sidebar-menu:communication');
        $this->repository = $repository;
        $this->consumerRepository = $consumerRepository;
        $this->companyRepository = $companyRepository;
    }

    public function index(TemplateRepository $templateRepository)
    {
        try{
            session()->forget('warn-msg');
            if(auth()->user()->isCompanyUser()){
                $company = auth()->user()->company;
            }else{
                $company = auth()->user()->subclient;
            }
            $groups = $this->repository->groups(auth()->user()->company_id);
            $group_terms = Group::where('company_id', $company->id)->whereNotNull ('pif_balance_discount_percent')->latest()->get();

            return view('yn.modules.account.group-terms', compact('company', 'groups', 'group_terms'));
        }
        catch (Exception $e) {
            return redirect()->back();
        }
    }



    public function delete($id)
    {
        $group = $this->repository->get('id', $id);
        $group->pif_balance_discount_percent = null;
        $group->ppa_balance_discount_percent = null;
        $group->min_monthly_pay_percent = null;
        $group->max_days_first_pay = null;
        $group->save();

        $consumer_ids = $group->getMemberIDs(auth()->user()->company_id);
        $consumer_ids_update = "";
        if(count($consumer_ids) > 0)
        {
            foreach($consumer_ids as $consumer){
                if($consumer_ids_update == "")
                    $consumer_ids_update = $consumer->id;
                else
                    $consumer_ids_update .= ", ".$consumer->id;
            }
            DB::select(DB::raw("UPDATE `consumers` SET 
            pif_discount_percent = NULL, 
            pay_setup_discount_percent = NULL, 
            min_monthly_pay_percent = NULL,
            max_days_first_pay = NULL
            WHERE id IN ($consumer_ids_update)
            ;"));
        }

        session()->flash('success', "Terms for group ". $group->name . " have been defaulted to company terms!");
        return redirect()->route('group-master-terms');
    }

    public function edit($id, GroupRepository $repository)
    {
        try{
            session()->forget('warn-msg');
            if(auth()->user()->isCompanyUser()){
                $company = auth()->user()->company;
            }else{
                $company = auth()->user()->subclient;
            }
            $groups = $this->repository->groups(auth()->user()->company_id);
            $group_terms = Group::where('company_id', $company->id)->whereNotNull('pif_balance_discount_percent')->latest()->get();
            $group = $this->repository->get('id', $id);

            return view('yn.modules.account.group-terms', compact('company', 'group', 'groups', 'group_terms'));
        }
        catch (Exception $e) {
            return redirect()->back();
        }
    }

    public function update(Request $request)
    {
        try{
            if(auth()->user()->isCompanyUser()){
                $company = auth()->user()->company;
            }else{
                $company = auth()->user()->subclient;
            }
            $params = $request->validate($this->companyRepository->groupMasterTermsRules());
            $this->repository->update('id', $request->group, array_except($params, ['email_template', 'sms_template', 'group']));
            $groups = $this->repository->groups(auth()->user()->company_id);
            $group_terms = Group::where('company_id', auth()->user()->company_id)->whereNotNull ('pif_balance_discount_percent')->latest()->get();
            $group = $this->repository->get('id', $request->group);
            $consumer_ids = $group->getMemberIDs(auth()->user()->company_id);
            $consumer_ids_update = "";
            if(count($consumer_ids) > 0)
            {
                foreach($consumer_ids as $consumer){
                    if($consumer_ids_update == "")
                        $consumer_ids_update = $consumer->id;
                    else
                        $consumer_ids_update .= ", ".$consumer->id;
                }
                DB::select(DB::raw("UPDATE `consumers` SET 
                pif_discount_percent = $request->pif_balance_discount_percent, 
                pay_setup_discount_percent = $request->ppa_balance_discount_percent, 
                min_monthly_pay_percent = $request->min_monthly_pay_percent,
                max_days_first_pay = $request->max_days_first_pay
                WHERE id IN ($consumer_ids_update)
                ;"));
            }
            $warning = app('App\Http\Controllers\HomeController')->validationIndex();
            $arr = explode(",",$warning);
            if($arr[0] != ""){
                session()->flash('warn-msg', $warning);
                return view('yn.modules.account.group-terms', compact('company', 'group', 'groups', 'group_terms'));
            }
            else
                session()->flash('success', "Master terms has been updated!");

            return redirect()->route('group-master-terms');
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating term');
        }
        
    }
}