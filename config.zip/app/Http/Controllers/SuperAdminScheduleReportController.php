<?php

namespace App\Http\Controllers;

use App\Repositories\CommunicationRepository;
use App\Repositories\CompanyRepository;
use App\Repositories\SubclientRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use App\ScheduleExport;
use App\Company;
use App\Traits\SuperAdminReportsTrait;
use Auth;
use DB;

class SuperAdminScheduleReportController extends Controller
{
    use SuperAdminReportsTrait;

    public function __construct(CompanyRepository $companyRepository, SubclientRepository $subclientRepository,
                                UserRepository $userRepository, CommunicationRepository $communicationRepository)
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:superadmin');
        // $this->middleware('role:superadmin');
        $this->companyRepository = $companyRepository;
        $this->subclientRepository = $subclientRepository;
        $this->userRepository = $userRepository;
        $this->communicationRepository = $communicationRepository;
    }

    public function scheduleReport($id = null){
        try{
            $companyList = $this->companyList();
            $companies = Company::when(!empty($companyList), function ($query) use ($companyList) {
                return $query->whereIn('id', $companyList);
            })->orderBy('company_name')->get();
        }
        catch (\Throwable $e) {
            Log::channel('superAdmin_report')->error($e);
            return redirect()->back()->with('error-msg', 'Oh no something went wrong');
        }

        $schedule = ScheduleExport::where('schedule_export.user_id',Auth::user()->id)->orderBy('created_at', 'desc')->where('admin', 1)->get();
        $sftp = $schedule->where('delivery_type', 'sftp')->first();
        $email = $schedule->where('delivery_type', 'email')->first();

        $edit = $schedule->where('id', $id)->first();
        if($edit == null)
            $edit = new ScheduleExport();

        return view('yn.superadmin.report.schedule', compact('companies', 'schedule', 'edit', 'sftp', 'email'));
    }

    public function setSchedule(Request $request){
        $request->validate([
            'type' => 'required|string',
            'company' => 'required|string',
            'frequency' => 'required|string',
            'temptype' => 'required|string',
        ]);
        if($request->id == "")
            $schedule = new ScheduleExport();
        else
            $schedule = ScheduleExport::where('id', $request->id)->first();
        $schedule->user_id = Auth::user()->id;
        $schedule->report_type = $request->get('type');
        $schedule->company_id = $request->get('company');
        $schedule->customer_group = "N/A";
        $schedule->frequency = $request->get('frequency');
        $schedule->delivery_type = $request->get('temptype');

        $schedule->host = $request->get('host');
        $schedule->username = $request->get('username');
        $schedule->password = $request->get('password');
        $schedule->keyfile = $request->get('keyfile');
        $schedule->port = $request->get('port');

        $schedule->folder_path = $request->get('folder_path');
        $schedule->email_id = str_replace(' ', '',$request->get('email_id'));
        $schedule->subclient_id = $request->get('subclient');
        $schedule->admin = 1;
        $schedule->save();

        return redirect()->back()->with('success', 'Your export is scheduled!');
    }

    protected function pauseSchedule($id){
        try{
            DB::table('schedule_export')->where('id',$id)->update([
                'push' => 1,
            ]);
            return redirect()->back()->with('success', 'Your schedule export is paused!');
        }
        catch (\Throwable $e) {
            dd($e);
        }
    }
    protected function resumeSchedule($id){
        try{
            DB::table('schedule_export')->where('id',$id)->update([
                'push' => 0,
            ]);
            return redirect()->back()->with('success', 'Your schedule export is resumed!');
        }
        catch (\Throwable $e) {
            dd($e);
        }
    }
    protected function deleteSchedule($id){
        try{
            DB::table('schedule_export')->where('id',$id)->delete();
            return redirect()->back()->with('success', 'Your schedule  is deleted!');
        }
        catch (\Throwable $e) {
            dd($e);
        }
    }
}