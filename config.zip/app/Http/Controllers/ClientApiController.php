<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Company;
use App\Consumer;
use App\ClientApiKey;
use App\APIHistory;
use App\Subclient;
use App\Mail\ConsumerApiEmail;
use App\Mail\ExceptionMail;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\Mail;
use App\Jobs\ApiConsumerJob;
use DB;
use DateTime;


class ClientApiController extends Controller
{
    
    public function addConsumers(Request $request)
    {
        try
        {
            $json = json_decode($request->getContent(), true);
            $api_key = $json["api_key"];
            $sandbox= $json["sandbox"];
            $company_id = $json["company_id"];
            $errors = [];
            $response_code = 0;
            $accounts_uploaded = 0;
            $accounts_successful = 0;
            $accounts_failed = 0;
            $insert_header = "";
            $insert_statements = [];
            $mandatory_fields_included = true;
            $accounts = [];
            
            $api_history = new APIHistory();
            $api_history->company_id = $company_id;
            $api_history->type = "Create";

            $table_columns = Schema::getColumnListing('consumers');

            $columns = ["account_number", "first_name", "last_name", "dob", "sub_client1_id", "sub_client2_id", "sub_client1_name",
            "sub_client2_name", "sub_client1_account_number", "sub_client2_account_number", "status", "full_ssn", "last4ssn", "gender", "address1", "address2", "city",
        "state", "zip", "mobile1", "email1", "total_balance", "current_balance", "min_one_time_percent", "pif_discount_balance",
            "pif_discount_percent", "pay_setup_discount_percent", "min_monthly_pay_percent", "min_monthly_pay_amount", "max_days_first_pay",
            "ppa_amount", "pass_through1", "pass_through2", "pass_through3", "pass_through4", "pass_through5", "account_open_date", "placement_date",
            "expiry_date", "accrued_interest_rate"];
            
            $mandatory_fields = ["account_number", "first_name", "last_name", "last4ssn", "dob", "current_balance", "mobile1", "email1"];
            if(!ClientApiKey::where("company_id", $company_id)->where('api_key', $api_key)->exists() || !Company::where("id", $company_id)->exists())
            {
                $api_history->status = 3;
                $api_history->save();
                return json_encode([
                    'response code' => 3,
                    "total_accounts_uploaded" => count($json["data"]),
                    "total_accounts_processed" => 0,
                    "total_accounts_failed" => count($json["data"]),
                    "failed_reason" => ['Invalid API Credentials']
                ]);
            }
                
            $accounts_uploaded = count($json["data"]);
            
            foreach($json["data"] as $row)
            {            
                $good_row = true;

                if($insert_header == "") {
                    $insert_header = implode(array_keys($row), ", ");
                }
                
                foreach($mandatory_fields as $mandatory_field)
                    if(!array_key_exists($mandatory_field, $row) || is_null($row[$mandatory_field]) || empty($row[$mandatory_field]) || in_array($row[$mandatory_field], ["", " "]))
                    {
                        $errors[] = $mandatory_field." not provided";
                        $mandatory_fields_included = false;
                    }
                foreach($row as $index => $header)
                    if(!in_array($index, $table_columns)){
                        $errors[] = [$index." is not a valid header."];
                        $mandatory_fields_included = false;
                    }

                if(!$mandatory_fields_included)
                {
                    $accounts_failed = $accounts_uploaded;
                    break;
                }

                $data = $this->consumerFields($row, $company_id, $errors, $good_row, "Create", $columns, $accounts);
                $errors = $data[0];
                $good_row = $data[1];
                if($data[2] != ""){
                    $insert_statements[] = $data[2];
                    $accounts[] = $data[3];
                }
                
                if(!$good_row){
                    $response_code = 1;
                    $accounts_failed++;
                    continue;
                }
            }
            
            if($accounts_failed == $accounts_uploaded)
                $response_code = 2;

            if($sandbox != true) {
                $api_history->failed_list = json_encode($errors);
                $api_history->total_uploaded = $accounts_uploaded - $accounts_failed;    
                $api_history->accounts_successful = $accounts_uploaded - $accounts_failed;
                $api_history->accounts_failed = $accounts_failed;
                $api_history->status = $response_code;
                $api_history->save();

                if($response_code != 2)
                {
                    DB::select( DB::raw('INSERT IGNORE INTO consumers 
                        ('.implode($columns, ', ').', created_at, updated_at, company_id )
                        VALUES 
                        '.implode($insert_statements, ', ')));

                    foreach($accounts as $account)
                        ApiConsumerjob::dispatch($account, $company_id);   
                }             
                $this->sendMailAfterComplete(Company::find($company_id), $errors, 'Create', $api_history->accounts_successful, $api_history->accounts_failed, $api_history->created_at);
            }
            
            if($accounts_failed == 0)
                return json_encode([
                        "response_code" => $response_code,
                        "total_accounts_uploaded" => $accounts_uploaded,
                        "total_accounts_processed" => $accounts_uploaded - $accounts_failed,
                        "total_accounts_failed" => $accounts_failed
                    ]);
            else 
                return json_encode([
                        "response_code" => $response_code,
                        "total_accounts_uploaded" => $accounts_uploaded,
                        "total_accounts_processed" => $accounts_uploaded - $accounts_failed,
                        "total_accounts_failed" => $accounts_failed,
                        "failed_reason" => $errors
                    ]);
        } catch (\throwable $e) {
            Log::channel('consumers_api')->error($e);
            // Mail::to("sunnyp@rnngroup.com")->send(new ExceptionMail($e->getMessage(), "Create Consumers API"));
            return json_encode([
                "error" => "Something went wrong, please check your json request."
            ]);
        }
   }

    public function updateConsumers(Request $request)
    {
        try
        {
            $json = json_decode($request->getContent(), true);
            $api_key = $json["api_key"];
            $sandbox= $json["sandbox"];
            $company_id = $json["company_id"];
            $errors = [];
            $response_code = 0;
            $accounts_uploaded = 0;
            $accounts_failed = 0;
            $mandatory_fields_included = true;

            $api_history = new APIHistory();
            $api_history->company_id = $company_id;
            $api_history->type = "Update";

            $table_columns = Schema::getColumnListing('consumers');
            
            if(!ClientApiKey::where("company_id", $company_id)->where('api_key', $api_key)->exists() || !Company::where("id", $company_id)->exists())
            {
                $api_history->status = 3;
                $api_history->save();
                return json_encode([
                    'response code' => 3,
                    "total_accounts_uploaded" => count($json["data"]),
                    "total_accounts_processed" => 0,
                    "total_accounts_failed" => count($json["data"]),
                    "failed_reason" => ['Invalid API Credentials']
                ]);
            }
            $accounts_uploaded = count($json["data"]);
            foreach($json["data"] as $row)
            {
                $good_row = true;

                $row = array_filter($row);
                $insert_header = array_keys($row);

                if(!array_key_exists("account_number", $row))
                {
                    $errors[] = ["Account number not provided for account"];
                    $mandatory_fields_included = false;
                }

                foreach($row as $index => $header)
                    if(!in_array($index, $table_columns)){
                        $errors[] = [$index." is not a valid header."];
                        $mandatory_fields_included = false;
                    }

                if(!$mandatory_fields_included)
                {
                    $accounts_failed = $accounts_uploaded;
                    break;
                }

                $data = $this->consumerFields($row, $company_id, $errors, $good_row, "Update", $insert_header, []);
                $errors = $data[0];
                $good_row = $data[1];
                $insert_statements = "";
                if($data[2] != ""){
                    $insert_statements = explode(", ", $data[2]);
                    $account = $data[3];
                }

                if(!Consumer::where("account_number", $row['account_number'])->exists())
                {
                    $good_row = false;
                    $errors[] = $row["account_number"]." this account is invalid";
                }    
                    
                if($good_row){
                    if($sandbox != "true")
                    {
                        $insert = "";
                        $insert_header[] = "updated_at";
                        for($i = 0; $i < count($insert_header); $i++)
                        {
                            $insert .= $insert_header[$i]." = ".$insert_statements[$i].", ";
                        }
        
                        $insert = substr_replace($insert, "", -2);
        
                        DB::select( DB::raw('UPDATE consumers SET
                            '.$insert.'
                            WHERE account_number = '.$account));
                    }
                }
                else{
                    $accounts_failed++;
                    $response_code = 1;
                }
            }
            $api_history->status = $response_code; // Processing
            $api_history->failed_list = json_encode($errors);
            $api_history->total_uploaded = $accounts_uploaded - $accounts_failed;
            $api_history->accounts_successful = $accounts_uploaded - $accounts_failed;
            $api_history->accounts_failed = $accounts_failed;
            $api_history->save();

            if($accounts_failed == $accounts_uploaded)
            {
                $response_code = 2;
            }
            
            $api_history->status = $response_code;

            if($sandbox != "true")
            {
                $api_history->save();
                $this->sendMailAfterComplete(Company::find($company_id), $errors, 'Edit', $api_history->accounts_successful, $api_history->accounts_failed, $api_history->created_at);
            }
            if($accounts_failed == 0)
                return json_encode([
                        "response_code" => $response_code,
                        "total_accounts_uploaded" => $accounts_uploaded,
                        "total_accounts_processed" => $accounts_uploaded - $accounts_failed,
                        "total_accounts_failed" => $accounts_failed
                    ]);
            else 
                return json_encode([
                        "response_code" => $response_code,
                        "total_accounts_uploaded" => $accounts_uploaded,
                        "total_accounts_processed" => $accounts_uploaded - $accounts_failed,
                        "total_accounts_failed" => $accounts_failed,
                        "failed_reason" => $errors
                    ]);
        } catch (\throwable $e) {
            Log::channel('consumers_api')->error($e);
            Mail::to("sunnyp@rnngroup.com")->send(new ExceptionMail($e->getMessage(), "Edit Consumers API"));
            return json_encode([
                "error" => "Something went wrong, please check your json request."
            ]);
        }
   }

   private function consumerFields($row, $company_id, $errors, $good_row, $type, $columns, $accounts){

        $insert_statement = "";
        foreach($columns as $field)
        {   
            if (in_array($field, ["dob", "account_open_date", "placement_date", "expiry_date"])) {
                if(array_key_exists($field, $row)){
                    if($row[$field]){
                        $invalid_date = date('Y-m-d', strtotime('invalid date'));
                        $date = date('Y-m-d', strtotime($row[$field]));
                        if( $date == $invalid_date){
                            $errors[] = "Account: ".$row["account_number"]." Invalid Date";
                            $good_row = false;                
                        } else {
                            $insert_statement .= date('Y-m-d', strtotime($row[$field]))."', '";
                        }
                    }else
                        $insert_statement .= "', '";
                }else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "account_number" && $type != 'Update') {                
                //Added double check for pre existing account numbers, only on creation
                if(in_array($row[$field], $accounts)){
                    $errors[] = "Account: ".$row["account_number"]." Account number already exists.";
                    $good_row = false;
                } elseif(array_key_exists($field, $row)){
                    if($row[$field]){
                        if (!is_numeric($row[$field])) {
                            $errors[] = "Account: ".$row["account_number"]." Account number must be a number";
                            $good_row = false;
                        } else if (Consumer::where('account_number', $row[$field])->where('company_id', $company_id)->exists())  {
                            $errors[] = "Account: ".$row["account_number"]." Account number already exists";
                            $good_row = false;
                        } else {
                            $insert_statement .= $row[$field]."', '";
                        }
                    }else
                        $insert_statement .="', '";
                }else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "sub_client1_id") {                
                if(array_key_exists($field, $row)){
                    if($row[$field]){
                        if (!is_numeric($row[$field])) {
                            $errors[] = "Account: ".$row["account_number"]." Subclient id must be a number";
                            $good_row = false;
                        } else if (!Subclient::where('id', $row[$field])->where('company_id', $company_id)->where('subclient_type', 'Subclient1')->exists())  {
                            $errors[] = "Account: ".$row["account_number"]." Subclient 1 ".$row[$field]." does not exist.";
                            $good_row = false; 
                        } else {
                            $insert_statement .= $row[$field]."', '";
                        }
                    }else
                        $insert_statement .="', '";
                }else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "sub_client2_id") {                
                if(array_key_exists($field, $row)){
                    if($row[$field]){
                        if (!is_numeric($row[$field])) {
                            $errors[] = "Account: ".$row["account_number"]." Subclient id must be a number";
                            $good_row = false;
                        } else if (!Subclient::where('id', $row[$field])->where('company_id', $company_id)->where('subclient_type', 'Subclient2')->exists())  {
                            $errors[] = "Account: ".$row["account_number"]." Subclient 2 ".$row[$field]." does not exist.";
                            $good_row = false; 
                        } else {
                            $insert_statement .= $row[$field]."', '";
                        }
                    }else
                        $insert_statement .="', '";
                }else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "email1") {
                if (array_key_exists($field, $row)) {
                    if($row[$field]){
                        if (filter_var($row[$field], FILTER_VALIDATE_EMAIL))
                            $insert_statement .= $row[$field]."', '";
                        else
                        {
                            $errors[] = "Account: ".$row["account_number"]." Invalid Email";
                            $good_row = false;
                        }
                    }else
                        $insert_statement .= "', '";
                } else {
                    $insert_statement .= "', '";
                }
            } elseif (in_array($field, ["mobile1", "mobile2", "mobile3"])) {
                if (array_key_exists($field, $row)) {
                    if($row[$field]){
                        if(!is_numeric($row[$field]))
                        {
                            $errors[] = "Account: ".$row["account_number"]." Phone number must be a number";
                            $good_row = false;
                        }
                        $mobile = preg_replace("/[^0-9]/", "", $row[$field]);
                        $insert_statement .= substr($mobile, -10)."', '";
                    }else
                        $insert_statement .= "', '";
                } else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "last4ssn") {
                if (array_key_exists($field, $row)) {
                    if($row[$field]){
                        if(!is_numeric($row[$field])) {
                            $errors[] = "Account: ".$row["account_number"]." SSN must be a number";
                            $good_row = false;
                        } else if(strlen($row[$field]) != 4){
                            $errors[] = "Account: ".$row["account_number"]." Include only the last 4 digits of the SSN";
                            $good_row = false;
                        } else {
                            $insert_statement .= $row[$field]."', '";
                        }
                    }else
                        $insert_statement .= "', '";
                } else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "state") {
                if (array_key_exists($field, $row)) {
                    if($row[$field]){
                        if (strlen($row[$field]) == 2) 
                            $insert_statement .= strtoupper($row[$field])."', '";
                        else {
                            $errors[] = "Account: ".$row["account_number"]." State must be appreviated";
                            $good_row = false;
                        }
                    }else
                        $insert_statement .= "', '";
                } else {
                    $insert_statement .= "', '";
                }
            } elseif ($field == "zip") {
                if (array_key_exists($field, $row)) {
                    if($row[$field]){

                        if (!is_numeric($row[$field])) {
                            $errors[] = "Account: ".$row["account_number"]." Zipcode must be a number";
                            $good_row = false;
                        } else
                            $insert_statement .= $row[$field]."', '";
                    }else
                    $insert_statement .= "', '";
                } else {
                    $insert_statement .= "', '";
                }
            }
            elseif (strpos($field, "amount") !== false || strpos($field, "balance") !== false || strpos($field, "percent") !== false) {
                if (array_key_exists($field, $row)) {
                    if($row[$field]){

                        if(!is_numeric($row[$field])) {
                            $errors[] = "Account: ".$row["account_number"]." ".$field." must be a number";
                            $good_row = false;
                        } else if (strpos($field, "percent") !== false && intval($row[$field]) > 100) {
                            $errors[] = "Account: ".$row["account_number"]." Percentage cannot exceed 100";
                            $good_row = false;
                        }
                        else
                            $insert_statement .= $row[$field]."', '";
                    }else
                        $insert_statement .= "', '";
                } else {
                    $insert_statement .= "', '";
                }
            } else {
                if(array_key_exists($field, $row)) {
                    $insert_statement .= $row[$field]."', '";
                }else {
                    $insert_statement .= "', '";
                }
            } 
        }

        $insert_statement = str_replace("''", 'NULL', $insert_statement);
        if($good_row == false)
            $insert_statement = "";
        else if($type == "Create")
            $insert_statement = "( '".substr_replace($insert_statement, "", -3).", '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."', '".$company_id."' )";
        else
            $insert_statement = "'".substr_replace($insert_statement, "", -3).", '".date('Y-m-d H:i:s')."' ";

        
        return [$errors, $good_row, $insert_statement, $row["account_number"]];
    }

    public function deleteConsumers(Request $request)
    {
        try
        {
            $json = json_decode($request->getContent(), true);
            
            $api_key = $json["api_key"];
            $sandbox= $json["sandbox"];
            $company_id = $json["company_id"];
                
            $api_history = new APIHistory();
            $api_history->company_id = $company_id;
            $api_history->type = "Delete";

            if(!ClientApiKey::where("company_id", $company_id)->where('api_key', $api_key)->exists() || !Company::where("id", $company_id)->exists())
            { 
                $api_history->status = 3;
                $api_history->save();
                return json_encode([
                    'response code' => 3,
                    'total_accounts_deleted' => 0,
                    'total_accounts_failed' => 0,
                    'failed_reason' => 'Invalid API Credentials'
                ]);
            }

            $tobeDeleted = [];
            foreach($json["data"] as $row){
                foreach(array_keys($row) as $index => $field){ 
                    if ($field == "account_number")
                        $tobeDeleted[] = $row[$field];
                }
            }
            
            //gets accounts that do not exist
            $checkForErrors = Consumer::whereIn('account_number', $tobeDeleted)->where("company_id", $company_id)->select('account_number')->get();
            $errors = array_diff($tobeDeleted, $checkForErrors->pluck('account_number')->toArray());
            foreach($errors as $index => $accountNumber)
                $errors[$index] = $accountNumber." this account is invalid";

            if($sandbox != "true")
            {
                //deletes 
                $delete = Consumer::whereIn('account_number', $tobeDeleted)->where("company_id", $company_id)->whereIn('status', ['uploaded', 'visited']);
                $delete_ids = $delete->pluck('id');
                $delete->delete();
                ConsumerNegotiation::whereIn('consumer_id', $delete_ids)->delete();
                ConsumerActivity::whereIn('consumer_id', $delete_ids)->delete();
                PaymentProfile::whereIn('consumer_id', $delete_ids)->delete();
                ScheduleTransaction::whereIn('consumer_id', $delete_ids)->delete();
                Transaction::whereIn('consumer_id', $delete_ids)->delete();
                ConsumerUnsubscription::whereIn('consumer_id', $delete_ids)->delete();
                Consumer::whereIn('account_number', $tobeDeleted)->where("company_id", $company_id)->whereNotIn('status', ['uploaded', 'visited', 'deactivated'])->update(['status' => 'deactivated']);
            }

            if(count($checkForErrors) == 0)
                $code = 2;
            elseif(count($errors) != 0)
                $code = 1;
            else
                $code = 0;

            if($sandbox != "true")
            {
                $api_history->status = $code;
                $api_history->accounts_successful = count($checkForErrors);
                $api_history->accounts_failed =  count($errors);
                $api_history->accounts_processed = count($checkForErrors) + count($errors);
                $api_history->total_uploaded = $api_history->accounts_processed;
                $api_history->failed_list = json_encode($errors);
                $api_history->save();
                $this->sendMailAfterComplete(Company::find($company_id), $errors, 'Delete', $api_history->accounts_successful, $api_history->accounts_failed, $api_history->created_at);
            }
            return json_encode([
                'response code' => $code,
                'total_accounts_deleted' => count($checkForErrors),
                'total_accounts_failed' => count($errors),
                'failed_reason' => $errors
            ]);

        } catch (\throwable $e) {
            Log::channel('consumers_api')->error($e);
            Mail::to("sunnyp@rnngroup.com")->send(new ExceptionMail($e->getMessage(), "Delete Consumers API"));
            return json_encode([
                "error" => "Something went wrong, please check your json request."
            ]);
        }
    }

    public function sendMailAfterComplete($company, $errorList, $type, $processed, $failed, $time)
    {
        Mail::to($company->account_contact_email)->send(new ConsumerApiEmail($company, $errorList, $type, $processed, $failed, $time));
    }
}