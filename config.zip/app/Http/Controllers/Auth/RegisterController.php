<?php

namespace App\Http\Controllers\Auth;

use App\Repositories\CommunicationRepository;
use App\Repositories\CompanyRepository;
use App\Http\Controllers\Controller;
use App\Repositories\GroupRepository;
use App\Repositories\MerchantRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Foundation\Auth\RegistersUsers;

class RegisterController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Register Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users as well as their
    | validation and creation. By default this controller uses a trait to
    | provide this functionality without requiring any additional code.
    |
    */

    use RegistersUsers;

    /**
     * Where to redirect users after registration.
     *
     * @var string
     */
    protected $redirectTo = 'email/verify';

    private $userRepository, $companyRepository, $communicationRepository, $merchantRepository, $groupRepository;

    public function __construct(UserRepository $userRepository, CompanyRepository $companyRepository,
                                CommunicationRepository $communicationRepository,
                                MerchantRepository $merchantRepository, GroupRepository $groupRepository)
    {
        $this->middleware('auth')->only(['profileForm', 'completeProfile', 'update']);
        $this->userRepository = $userRepository;
        $this->companyRepository = $companyRepository;
        $this->communicationRepository = $communicationRepository;
        $this->merchantRepository = $merchantRepository;
        $this->merchantRepository = $merchantRepository;
        $this->groupRepository = $groupRepository;
    }

    public function showRegistrationForm()
    {
        return redirect()->to(route('login'));
    }

    protected function validator(array $data)
    {
        return Validator::make($data, $this->userRepository->registrationValidationRules()
            + $this->companyRepository->registrationValidationRules());
    }

    protected function create(array $data)
    {
        $data['password'] = Hash::make($data['password']);
        return $this->userRepository->create($data);
    }

    public function registered(Request $request, $user)
    {
        $company = $this->companyRepository->create($request->only($this->companyRepository->registrationFields()));
        $company->registerAccountContact($user)->createCustomStyle();
        $user->registerCompany($company);
//        $this->communicationRepository->sendRegistrationEmail($user);
        $this->groupRepository->createNotJoinedGroup($company);
    }

    public function profileForm()
    {
        $company = auth()->user()->company;
        $industry_type_options = config('app.common.industry_types');
        $state_options = config('app.common.states');
        $bank_account_type_options = config('app.company.bank_account_types');
        return view('yn.registration.profile', compact('company', 'industry_type_options', 'state_options', 'bank_account_type_options'));
    }

    public function updateProfile(Request $request, $step)
    {
        $params = $request->validate($this->companyRepository->profileValidationRules($step));
        $this->companyRepository->updateProfile(auth()->user()->company_id, $params);
        return ['message' => $step . ' saved'];
    }

    public function completeProfile()
    {
        $company = auth()->user()->company;
        if ($company->checkProfileComplete()) {
            $company->doComplete();
            auth()->user()->setUserDetails($company->billing_name, $company->billing_phone);
//            $this->communicationRepository->sendProfileCompleteEmail(auth()->user()->company);
        }
        if ($company->approved()) {
            return redirect()->back()->with('success', 'Profile updated successfully!');
        }
        return redirect()->to(route('home'))->with('success', 'Profile completed successfully!');
    }

    public function changePasswordForm()
    {
        return view('yn.modules.account.change-password');
    }

    public function changePassword(Request $request)
    {
        $params = $request->validate(['current_password' => 'required', 'new_password' => 'required|string|min:8|confirmed|regex:/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/']);
        if (Hash::check($params['current_password'], auth()->user()->password)) {
            $request->user()->fill([
                'password' => Hash::make($params['new_password'])
            ])->save();
            return redirect()->back()->with('success', 'Password changes successfully!');
        }
        return redirect()->back()->with('error', 'Please provide correct current password!');
    }

}
