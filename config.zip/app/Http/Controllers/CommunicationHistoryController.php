<?php

namespace App\Http\Controllers;

use App\CommunicationHistory;
use Illuminate\Http\Request;

class CommunicationHistoryController extends Controller
{
    public function __construct()
    {
        $this->middleware(['auth', 'check-profile-completed']);
        $this->middleware('sidebar-menu:communication');
    }
    public function index()
    {
        try{
            $data_list = CommunicationHistory::where('company_id', auth()->user()->company_id)->latest()->paginate(12);
            return view('communication-history.index', compact('data_list'));
        }
        catch(Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while view this page!');
        }
    }
}
