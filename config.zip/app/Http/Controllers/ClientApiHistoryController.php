<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\APIHistory;
use Log;


class ClientApiHistoryController extends Controller
{
    public function index()
    {
        return view('yn.modules.api-history');
    }

    public function getHistories(Request $request)
    {
        $api_histories = APIHistory::where('company_id', auth()->user()->company_id)->get();

        $user = auth()->user();

        $search = $request->input('search.value');

        $total_histories = APIHistory::where('company_id', auth()->user()->company_id)->count();

        $api_histories = APIHistory::where('company_id', auth()->user()->company_id)
        ->whereRaw("created_at LIKE '%".$search."%'")
        ->orderBy("created_at", "desc")
        ->limit($request->input("length"))
        ->offset($request->input("start"))    
        ->get();


        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_histories),
            "recordsFiltered" => intval($total_histories),
            "data"            => $api_histories
            );

        echo json_encode($json_data);  
    }

}