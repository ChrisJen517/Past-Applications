<?php

namespace App\Http\Controllers;

use App\PersonalizedLogo;
use App\Repositories\CommunicationRepository;
use Illuminate\Http\Request;
use Illuminate\Database\Eloquent\Collection\fill;
use Illuminate\Support\Facades\Storage;

class PersonalizedLogoController extends Controller
{

    private $communcationRepository;

    public function __construct()
    {
        $this->middleware(['auth', 'check-profile-completed']);
    }

    public function index()
    {
        try{
            session()->forget('warn-msg');
            $data = PersonalizedLogo::where('company_id', auth()->user()->company->id)->first();
            return view('personalized.index', compact('data'));
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while view this page!');
        }
        
    }

    public function update(Request $request)
    {
        try{
            $data = PersonalizedLogo::where('company_id', auth()->user()->company->id)->first();
            if ($data != null) {
                $data->primary_color = $request->input('primary_color');
                $data->secondary_color = $request->input('secondary_color');
                $data->background_color = $request->input('background_color');
                $data->customer_communication_link = 'consumer';
                $data->save();
            } else {
                $data = PersonalizedLogo::create([
                    'company_id' => auth()->user()->company->id,
                    'primary_color' => $request->input('primary_color'),
                    'secondary_color' => $request->input('secondary_color'),
                    'background_color' => $request->input('background_color'),
                    'customer_communication_link' => 'consumer',
                ]);
            }
            auth()->user()->company->setYouNegotiateUrl($data->customer_communication_link);
            return back()->with('success', 'Logo updated successfully');
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while update this page!');
        }
        
    }

    public function reset()
    {
        try{
            $data = PersonalizedLogo::where('company_id', auth()->user()->company->id)->first();
            $data->primary_color = '#0079f2';
            $data->secondary_color = '#000000';
            $data->background_color = '#ffffff';
            $data->customer_communication_link = 'consumer';
            $data->save();
            auth()->user()->company->setYouNegotiateUrl($data->customer_communication_link);
            //return view('personalized.index', compact('data'))->with('success', 'Reset to Default');
            return back()->with('success', 'Reset successfully');
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while update this page!');
        }
    }


    public function saveLogo(Request $request)
    {
        try{
            $personalized = PersonalizedLogo::where('customer_communication_link', $request->input('customer_communication_link') )->whereNotIn('company_id', [auth()->user()->company->id])->first();

            if($personalized){
                return back()->with('error-msg', 'Communication Link Already Exist! Please create unique communication link');   
            }
            else{
                $filteredData = substr($request->input('img_val'), strpos($request->input('img_val'), ",") + 1);
                //Decode the string
                $unencodedData = base64_decode($filteredData);
                $companyName = auth()->user()->company->company_name;
                //Save the image
                $contents = Storage::disk('public')->put('logo/' . str_slug($companyName) . '.png', $unencodedData);
                
                $data = PersonalizedLogo::where('company_id', auth()->user()->company->id)->first();
                $data->logo_name = str_slug($companyName) . '.png';
                $data->old_communication_link = $data->customer_communication_link;
                $data->customer_communication_link = $request->input('customer_communication_link');
                $data->save();

                $repository = new CommunicationRepository();
                $old_link = 'https://' . $data->old_communication_link . '.younegotiate.com';
                $new_link = 'https://' . $data->customer_communication_link . '.younegotiate.com';
                $repository->sendPersonalizedLinkUpdateEmail($old_link, $new_link, auth()->user()->company);

                $warning = app('App\Http\Controllers\HomeController')->validationIndex();
                $arr = explode(",",$warning);
                if($arr[0] != ""){
                    session()->flash('warn-msg', $warning);
                    $data = PersonalizedLogo::where('company_id', auth()->user()->company->id)->first();
                    return view('personalized.index', compact('data'));
                    //return redirect()->back();
                }                
                else{
                    return back()->with('success', 'Content updated successfully');
                }

            }
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while update this page!');
        }
    }

}
