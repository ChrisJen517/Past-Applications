<?php

namespace App\Http\Controllers;

use App\CommunicationHistory;
use App\Consumer;
use App\Group;
use App\Repositories\CommunicationRepository;
use App\Repositories\ConsumerRepository;
use App\Template;
use App\ClientApiKey;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Twilio\Rest\Client;
use Log; 

class AjaxController extends Controller
{
    protected $consumerRepository;

    public function __construct(ConsumerRepository $consumerRepository)
    {
        $this->consumerRepository = $consumerRepository;
    }

    public function consumers(Request $request)
    {
        return $this->consumerRepository->searchConsumers($request->all())->toJson();
    }

    public function upload(Request $request)
    {
        $validatedData = $request->validate([
            'file' => 'required|file',
        ]);

        $path = $request->file('file')->store('uploads/editor', 'public');
        return ['location' => asset('storage/' . $path)];
    }

    public function groupMemberCount(Request $request)
    {
        $group = new Group();
        $group->customer_status_rule = $request->get('customer_status_rule');
        $group->customer_custom_rule = $request->get('customer_custom_rule');
        return $group->member_count;
    }

    public function commHistory($id)
    {
        $comm = CommunicationHistory::with(['template', 'consumer'])->find($id);

        if ($comm->content == null) {
            $comm->content = createTemplateContent($comm->template->content, $comm->consumer);
        }
        if ($comm->subject == null) {
            $comm->subject = $comm->template->subject;
        }

        $comm->template_type = $comm->templateType();

        return $comm->toArray();
    }

    public function sendMessage(Request $request)
    {
        $consumer = Consumer::with(['company'])->find($request->get('consumer_id'));
        if($request->template == "")
            $body = decodeBase64($request->get('content'), auth()->user()->company_id);
        else{
            $template = Template::where('id', $request->get('template'))->first();
            $body = createTemplateContent($template->content, $consumer);
        }
        $subject = $request->get('subject');
        $toEmail = $request->get('email');
        $toPhone = $request->get('phone');

        if ($request->get('type') == 'email') {
            try {
                Mail::send('yn.emails.template', compact('body', 'consumer'), function ($message) use ($toEmail, $consumer, $subject) {
                    $message->from($consumer->from_details['from_email'], $consumer->from_details['from_name']);
                    $message->subject($subject);
                    $message->to($toEmail);
                });
                CommunicationRepository::createCommunicationHistory('email', $toEmail, null, $body, 'success', $subject, $consumer);
                return "Success";
            } catch (\Exception $e) {
                CommunicationRepository::createCommunicationHistory('email', $toEmail, null, $body, 'failed', $subject, $consumer);
                return "Failure";
            }
        }
        if ($request->get('type') == 'sms') {
            try {
                $from_number = (ClientApiKey::where("company_id", auth()->user()->company_id)->exists()
                 ? ClientApiKey::where("company_id", auth()->user()->company_id)->first()->twilio_phone_no
                 : "+14702881902");
                $client = new Client('ACad1460c6dd44e9c8725844cfa4675e10', '39e4c316e3b6b6a9fe428d340cca0b5c');
                $client->messages->create($toPhone, ['from' => $from_number, 'body' => $body]);
                CommunicationRepository::createCommunicationHistory('sms', null, $toPhone, $body, 'success', null, $consumer);
                return "Success";
            } catch (\Exception $e) {
                CommunicationRepository::createCommunicationHistory('sms', null, $toPhone, $body, 'failed', null, $consumer);
                Log::channel('sms')->info($e);
                return "Failure";
            }
        }
    }

    public function decodeBase64($content, $company){
        //finds all cases of base 64
        preg_match_all('@src="([^"]+)"@', $content, $matches);

        //makes sure the filepathExists
        if (!file_exists(public_path('public/assets/images/emailTemplate/'.$company))) {
            mkdir(public_path('public/assets/images/emailTemplate/'.$company), 0777, true);
        }

        //takes each instance of the base 64 and replaces it
        foreach($matches[0] as $key => $base64_string){
            $fileName = 'public/assets/images/emailTemplate/'.$company.'/customTemplate_'.date('Y_m_d_H_i_s').'_'.$key.'.jpg';
            base64_to_jpeg($base64_string, public_path($fileName));
            $content = str_replace($base64_string, 'content="image/jpg;" src="http://'.$_SERVER['HTTP_HOST'].'/'.$fileName.'"', $content);
        }
        return $content;
    }
}