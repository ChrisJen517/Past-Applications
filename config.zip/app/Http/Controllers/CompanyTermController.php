<?php

namespace App\Http\Controllers;

use App\Repositories\CompanyTermRepository;
use Illuminate\Http\Request;

class CompanyTermController extends Controller
{

    protected $repository;

    public function __construct(CompanyTermRepository $repository)
    {
        $this->middleware(['auth', 'check-profile-completed']);
        $this->middleware('sidebar-menu:terms');
        $this->repository = $repository;
    }

    public function index()
    {
        try{
            $data_list = $this->repository->companyTerms(auth()->user()->company_id);
            return view('company-term.index', compact('data_list'));
        }
        catch (Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
    }

    public function edit($id)
    {
        try{
            $companyTerm = $this->repository->get('id', $id);
            return view('company-term.edit', compact('companyTerm'));
        }
        catch (Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
    }

    public function update(Request $request, $id)
    {
        try{
            $companyTerm = $this->repository->update('id', $id, $request->validate($this->repository->updateValidationRules()));
            return redirect()->to(route('term'));
        }
        catch (Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
    }

}
