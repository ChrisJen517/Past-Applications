<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use App\Consumer;
use Illuminate\Support\Facades\DB;

class CumulativeReportController extends Controller
{
    public function cumulativeReport(){

        $company_id = auth()->user()->company_id;

        $company = DB::table('consumers')->selectRaw("
            count(distinct consumers.id) as Current_Consumers, 
            sum(total_balance) as Current_Consumers_Total_Balance,
            '100% Accounts in YN' as Current_Consumers_Percent, '100% $$ in YN' as Current_Consumers_Total_Balance_Percent,
        
            0 as SMS_Comm_Sent, 0 as SMS_Comm_Sent_Balance, 0 as SMS_Comm_Sent_Percent, 0 as SMS_Comm_Sent_Balance_Percent,
            0 as SMS_Delivered, 0 as SMS_Delivered_Balance, 0 as SMS_Delivered_Percent, 0 as SMS_Delivered_Balance_Percent,
            0 as Email_Comm_Sent, 0 as Email_Comm_Sent_Balance, 0 as Email_Comm_Sent_Percent, 0 as Email_Comm_Sent_Balance_Percent, 
            0 as Email_Delivered, 0 as Email_Delivered_Balance, 0 as Email_Delivered_Percent, 0 as Email_Delivered_Balance_Percent,

            0 as Clicked_On_Link, 0 as Clicked_On_Link_Percent,
            0 as Clicked_On_Link_Balance, 0 as Clicked_On_Link_Of_Balance_Delivered_Comission,

            0  as Entered_PII_Data, 0 as Entered_PII_Data_Balance,
            0 as Entered_PII_Data_Percent, 0 as Entered_PII_Data_Of_Balance_Delivered_Comission,

            count(distinct if(consumers.status = 'not_verified', consumers.id, null)) as PII_Mismatch,
            sum(if(consumers.status = 'not_verified', consumers.total_balance, null)) as PII_Mismatch_Balance,
            0 as PII_Mismatch_Percent, 0 as PII_Mismatch_Of_Balance_Delivered_Comission,

            0 as Successfully_Negotiated, 0 as Successfully_Negotiated_Balance, 0 as Successfully_Negotiated_Percent, 0 as Successfully_Negotiated_Of_Balance_Delivered_Comission,
            0 as Settled_In_Full, 0  as Settled_In_Full_Balance, 0 as Settled_In_Full_Percent, 0 as Settled_In_Full_Of_Balance_Delivered_Comission,

            count(distinct if(payment_setup = 1, consumers.id, null)) as PayProfile_Set_Up,
            sum(if(payment_setup = 1, consumers.total_balance, null)) as PayProfile_Set_Up_Balance,
            0 as  PayProfile_Set_Up_Percent, 0 as PayProfile_Set_Up_Of_Balance_Delivered_Comission,

            0 as Settled_In_Full_Paid, 0  as Settled_In_Full_Paid_Balance, 0 as Settled_In_Full_Paid_Percent, 0 as Settled_In_Full_Paid_Of_Balance_Delivered_Comission
            ")->where('consumers.status', "!=", 'deactivated')
            ->where('consumers.company_id', $company_id)->first();

        $totalSent = Consumer::selectRaw("consumers.id, consumers.company_id as company, consumers.status, consumers.total_balance as balance, 
            count(if(negotiation_type = 'pif', 1, null)) as pif,
            count(if(consumer_negotiations.offer_accepted = 1, 1, null)) as negotiated, 

            count(if(template_type = 'email', 1, null)) as email_sent,
            count(if(template_type = 'email' and communication_histories.status = 'success', 1, null)) as email_delivered,

            count(if(template_type = 'sms', 1, null)) as sms_sent,
            count(if(template_type = 'sms' and communication_histories.status = 'success', 1, null)) as sms_delivered
            ")->join('communication_histories', 'communication_histories.consumer_id', 'consumers.id')
            ->leftjoin('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
            ->where('consumers.status', "!=", 'deactivated')
            ->where('consumers.company_id', $company_id)->groupBy('consumers.id')->get();

        $placeHolders = [
            'negotiated' => ['Successfully_Negotiated', 'Successfully_Negotiated_Balance', $totalSent->where('negotiated', '>', 0)],
            'Settled_In_Full' => ['Settled_In_Full', 'Settled_In_Full_Balance', $totalSent->where('pif', '>', 0)],
            'paid' => ['Settled_In_Full_Paid', 'Settled_In_Full_Paid_Balance', $totalSent->where('pif', '>', 0)->where('status', 'settled')],
            'sms' => ['SMS_Comm_Sent', "SMS_Comm_Sent_Balance", $totalSent->where('sms_sent', '>', 0)],
            'sms_delivered' => ['SMS_Delivered', "SMS_Delivered_Balance", $totalSent->where('sms_delivered', '>', 0)],
            'email' => ['Email_Comm_Sent', "Email_Comm_Sent_Balance", $totalSent->where('email_sent', '>', 0)],
            'email_delivered' => ['Email_Delivered', "Email_Delivered_Balance", $totalSent->where('email_delivered', '>', 0)],
            'Clicked_On_Link' => ['Clicked_On_Link', 'Clicked_On_Link_Balance', $totalSent->whereNotIn('status', ['uploaded', 'disabled'])],
            'Entered_PII_Data' => ['Entered_PII_Data', 'Entered_PII_Data_Balance', $totalSent->whereNotIn('status', ['uploaded', 'disabled', 'not_verified'])],
        ];

        //passes in the values gained from other queries to the company object's placeholders
        foreach($placeHolders as $values){
            $companyPlaceHolders = $values[2]->where('company', $company_id);
            $company->{$values[0]} = $companyPlaceHolders->count();
            foreach($companyPlaceHolders as $sent)
                $company->{$values[1]} += $sent->balance;
        }

        //lists all the collums that need to be formated for percentages, grouped by their divisor then the name of the field followed by the value to be diveded
        $percents = [
            'Current_Consumers' => [
                ['SMS_Comm_Sent_Percent','SMS_Comm_Sent'], ['Email_Comm_Sent_Percent','Email_Comm_Sent'],  
            ],
            'Current_Consumers_Total_Balance' => [
                ['SMS_Comm_Sent_Balance_Percent','SMS_Comm_Sent_Balance'], 
                ['Email_Comm_Sent_Balance_Percent', 'Email_Comm_Sent_Balance'], 
            ],
            'SMS_Comm_Sent' =>[['SMS_Delivered_Percent','SMS_Delivered']],
            'Email_Comm_Sent' =>[['Email_Delivered_Percent','Email_Delivered']],
            'SMS_Comm_Sent_Balance' => [['SMS_Delivered_Balance_Percent','SMS_Delivered_Balance']],
            'Email_Comm_Sent_Balance' => [['Email_Delivered_Balance_Percent','Email_Delivered_Balance']],
            'Clicked_On_Link' => [['Entered_PII_Data_Percent', 'Entered_PII_Data']],
            'Clicked_On_Link_Balance' => [['Entered_PII_Data_Of_Balance_Delivered_Comission','Entered_PII_Data_Balance']],
            'Entered_PII_Data' => [['PII_Mismatch_Percent', 'PII_Mismatch']],
            'Entered_PII_Data_Balance' => [['PII_Mismatch_Of_Balance_Delivered_Comission','PII_Mismatch_Balance']],
            'Settled_In_Full' => [['Settled_In_Full_Paid_Percent', 'Settled_In_Full_Paid']],
            'Settled_In_Full_Balance' => [['Settled_In_Full_Paid_Of_Balance_Delivered_Comission', 'Settled_In_Full_Paid_Balance']],
            'Successfully_Negotiated' => [['PayProfile_Set_Up_Percent', 'PayProfile_Set_Up']],
            'Successfully_Negotiated_Balance' => [['PayProfile_Set_Up_Of_Balance_Delivered_Comission', 'PayProfile_Set_Up_Balance']],
        ];

        //gets the percentages based on the array above
        foreach($percents as $divisor => $values){
            //if the divisor is empty or is zero skips the section
            if(empty($company->{$divisor}))
                continue;

            //otherwise gets the value of the percentage
            foreach($values as $value)
                $company->{$value[0]} = ($company->{$value[1]}/$company->{$divisor})*100;
        }

        $PIITotal = $company->Entered_PII_Data - $company->PII_Mismatch;
        if($PIITotal > 0){
            $company->Settled_In_Full_Percent = ($company->Settled_In_Full/$PIITotal)*100;
            $company->Successfully_Negotiated_Percent = ($company->Successfully_Negotiated/$PIITotal)*100;
        }
        $PIITotal = $company->Entered_PII_Data_Balance - $company->PII_Mismatch_Balance;
        if($PIITotal > 0){
            $company->Settled_In_Full_Of_Balance_Delivered_Comission = ($company->Settled_In_Full_Balance/$PIITotal)*100;
            $company->Successfully_Negotiated_Of_Balance_Delivered_Comission = ($company->Successfully_Negotiated_Balance/$PIITotal)*100;
        }

        $commTotal = $totalSent->count();
        if($commTotal > 0)
            $company->Clicked_On_Link_Percent = ($company->Clicked_On_Link/$commTotal)*100;

        $commTotal = $totalSent;
        $totalBalance = 0;
        foreach($commTotal as $sent)
            $totalBalance += $sent->balance;
        if($totalBalance > 0)
            $company->Clicked_On_Link_Of_Balance_Delivered_Comission = ($company->Clicked_On_Link_Balance/$totalBalance)*100;

        return view('yn.modules.report.performance', compact('company'));
    }
}