<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Company;
use DB;
use Auth;
use App\ScheduleExport;
use App\Subclient;
use App\Repositories\CommunicationRepository;

class ExportController extends Controller
{
    public function __construct(CommunicationRepository $communicationRepository)
    {
        $this->communicationRepository = $communicationRepository;
    }

    protected function index($id = null){
        $user = auth()->user();

        if ($user->user_type == 'company') {
            $subclients = Subclient::where('company_id',$user->company_id)->get();
            $companies = DB::table('companies')->where('id', $user->company_id)->get();
            $all = true;
        }
        elseif (strtolower($user->user_type) == 'subclient1' || strtolower($user->user_type) == 'subclient2') {
            $companies = Company::where('id', $user->company_id)->get();
            $subclients = Subclient::where('id', $user->subclient_id )->get();
            $all = false;
        }

        $schedule = DB::table('schedule_export')
            ->leftjoin('companies', 'companies.id', 'schedule_export.company_id')
            ->where('schedule_export.user_id', $user->id)
            ->select('schedule_export.id','companies.company_name','schedule_export.customer_group'
                ,'schedule_export.created_at','schedule_export.report_type','schedule_export.delivery_type', 'schedule_export.subclient_id' , 'schedule_export.company_id'
                ,'schedule_export.email_id','schedule_export.folder_path','schedule_export.push', 'schedule_export.frequency'
            )->where('admin', 0)
            ->get();

        $edit = $schedule->where('id', $id)->first();
        if($edit == null)
            $edit = new ScheduleExport();

        return view('yn.modules.report.schedule-export', compact('companies', 'schedule', 'edit', 'all', 'subclients'));
    }

    protected function scheduleExport(Request $request){
        try{
            $request->validate([
                'report_type' => 'required|string',
                'company' => 'required|string',
                'group' => 'required|string',
                'frequency' => 'required|string',
                'temptype' => 'required|string',
            ]);

            if(empty($request->id))
                $schedule = new ScheduleExport();
            else
                $schedule = ScheduleExport::where('id',$request->id)->first();

            $schedule->user_id = Auth::user()->id;
            $schedule->report_type = $request->get('report_type');
            $schedule->company_id = $request->get('company');
            $schedule->customer_group = $request->get('group');
            $schedule->frequency = $request->get('frequency');
            $schedule->delivery_type = $request->get('temptype');
            $schedule->host = $request->get('host');
            $schedule->username = $request->get('username');
            $schedule->password = $request->get('password');
            $schedule->keyfile = $request->get('keyfile');
            $schedule->port = $request->get('port');
            $schedule->folder_path = $request->get('folder_path');
            $schedule->email_id = $request->get('email_id');
            $schedule->subclient_id = $request->get('subclient');
            $schedule->save();

            return redirect()->back()->with('success', 'Your export is scheduled!');
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating the schedule');
        }
    }

    protected function pause($id){
        try{
            DB::table('schedule_export')->where('id',$id)->update([
                'push' => 1,
            ]);
            return redirect()->back()->with('success', 'Your schedule export is paused!');
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating the schedule');
        }
    }

    protected function restart($id){
        try{
            DB::table('schedule_export')->where('id',$id)->update([
                'push' => 0,
            ]);
            return redirect()->back()->with('success', 'Your schedule export is resumed!');
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating the schedule');
        }
    }

    protected function delete($id){
        try{
            DB::table('schedule_export')->where('id',$id)->delete();
            return redirect()->back()->with('success', 'Your schedule  is deleted!');
        }
        catch (\Throwable $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating the schedule');
        }
    }
}
