<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Company;
use App\Export\ReportExport;
use PDF, Auth;
use Excel;
use Carbon\Carbon;
use App\Subclient;
use Throwable;
use App\Traits\CreditorReportTrait;

class ReportController extends Controller
{
    use CreditorReportTrait;

    public function __construct()
    {
        $this->middleware(['auth', 'check-profile-completed']);
        $this->middleware('sidebar-menu:report');
    }

    protected function index()
    {
        try {
            $user = auth()->user();
            $cid = Auth::user()->company_id;
            if (!$user->hasRole('superadmin')) {
                $allcompany = false;
                $companis = Company::where('id', $cid)->get();
                if (strtolower($user->user_type) == 'company') {
                    $subclients = Subclient::where('company_id', $cid)->get();
                    $sub = "all";
                }
                if (strtolower($user->user_type) == 'subclient1') {
                    $subclients = Subclient::where('id', $user->subclient_id)->get();
                    $sub = 'sub1';                    
                }
                if (strtolower($user->user_type) == 'subclient2') {
                    $subclients = Subclient::where('id', $user->subclient_id)->get();
                    $sub = 'sub2';
                }
            } else {
                $companis = Company::All();
                $subclients = Subclient::All();
                $allcompany = true;
                $sub = "all";
            }
            return view('yn.modules.report.index', [
                'companis' => $companis,
                'allcompany' => $allcompany,
                'allsubclient' => $sub,
                'subclients' => $subclients
            ]);
        } catch (Throwable $e) {
            report($e);
            return false;
        }
    }

    protected function generateRepot(Request $request)
    {
        $validation = [
            'report_type' => 'required|string',
            'company' => 'required|string',
            'group' => 'required|string',
            'temptype' => 'required'
        ];
        if(in_array($request->type, ["Scheduled_Transactions", "Reconciliation_Report", "Transaction_History"])){
            $validation['from'] = 'required|date';
            $validation['to'] = 'required|date';
        }
        $request->validate($validation);

        try{
            $date = Carbon::now()->format('Y-m-d');
            $type = $request->get('report_type');
            $consumers = $this->getCreditorReport($type, $request->get('company'), $request->get('subclient'), $request->get('from'), $request->get('to'), $request->get('group'));

            if ($request->get('temptype') == "pdf") 
                return View('yn.modules.report.preview', ['consumers' => $consumers, 'type' => $type, 'date' => $date]);
            else 
                return Excel::download(new ReportExport($consumers), $type . '_' . $date . '.csv');

        } catch (Throwable $e) {
            return redirect()->back()->with('error-msg', 'Report generation Failed');
        } 
    }
}