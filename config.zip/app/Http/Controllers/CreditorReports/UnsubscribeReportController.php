<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use App\Consumer;
use App\CsvHeader;
use App\Export\ReportExport;
use PDF, Auth;
use Excel;
use Illuminate\Http\Request;
use DB;
use Carbon\Carbon;

class UnsubscribeReportController extends Controller
{
    public function unsubscribe(){
        try {
            $headers = $this->consumerReportTableHeaders();
            $headers[] = 'Unsubscribed_Date_and_Time';
            return View('yn.modules.report.unsubscribe', compact('headers'));
        } catch (\Throwable $ex) {
            return Redirect()->back()->with('error', 'Header have not set!!');
        }
    }

    public function getHeaders(){
        $headers = $this->consumerReportTableHeaders();
        $headers[] = 'Unsubscribed_Date_and_Time';
        echo json_encode($headers);
    }

    public function getTableData(Request $request){
        $user = auth()->user();

        //gets the report headers 
        $headers = $this->consumerReportTableHeaders();
        $selects = [];
        foreach($headers as $header)
            $selects[] = 'consumers.'.$header.' as '.$header;
        $headers[] = 'consumer_unsubscribes.created_at'; 
        $selects[] = 'consumer_unsubscribes.created_at as Unsubscribed_Date_and_Time';

        $order = $headers[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $consumers_total = DB::table('consumers')->where(function($query) use ($user){
            if (strtolower($user->user_type) == 'company')
                return $query->where('consumers.company_id', $user->company_id);
            elseif(strtolower($user->user_type) == 'subclient1')
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            else
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
        })->join('consumer_unsubscribes', 'consumers.id', '=', 'consumer_unsubscribes.consumer_id')->count();

        $consumers = Consumer::where(function ($query) use($user){
            if (strtolower($user->user_type) == 'company')
                return $query->where('consumers.company_id', $user->company_id);
            elseif(strtolower($user->user_type) == 'subclient1')
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            else
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
        })->when($search != "", function($query) use ($search){
            return $query->whereRaw("concat(ifnull(account_number, ''), ifnull(first_name, ''), ifnull(last_name, ''), ifnull(email1, ''), ifnull(mobile1, ''),
                                         ifnull(last4ssn, ''), ifnull(sub_client1_id, ''), ifnull(sub_client2_id, ''), ifnull(pass_through1, ''),
                                         ifnull(pass_through2, ''), ifnull(pass_through3, ''), ifnull(pass_through4, ''), ifnull(pass_through5, ''),
                                         ifnull(state, '')) like '%" . $search . "%'");
        })->join('consumer_unsubscribes', 'consumers.id', '=', 'consumer_unsubscribes.consumer_id')
        ->selectRaw(implode(',', $selects))->orderBy($order, $dir)->limit($request->input('length'))->offset($request->input('start'))->get();

        foreach($consumers as $consumer)
        {
            foreach($headers as $field){
                if(strpos($field, 'percent') !== false || $field == 'accrued_interest_rate')
                    $consumer->{$field} = $consumer->{$field}."%";
                else if(strpos($field, 'amount') !== false || strpos($field, 'balance') !== false)
                    $consumer->{$field} = '$'.number_format($consumer->{$field}, 2);
            }
        }        
        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($consumers_total),
            "recordsFiltered" => intval($consumers_total),
            "data"            => $consumers
            );

        echo json_encode($json_data);
    }

    public function downloadUnsubscribe()
    {
        try{
            $user = auth()->user();

            //gets the report headers 
            $headers = $this->consumerReportTableHeaders();
            $selects = [];
            foreach($headers as $header)
                $selects[] = 'consumers.'.$header.' as '.$header;
            $headers[] = 'Unsubscribed_Date_and_Time';
            $selects[] = 'consumer_unsubscribes.created_at as Unsubscribed_Date_and_Time';

            $data = Consumer::where(function ($query) use($user){
                if (strtolower($user->user_type) == 'company')
                    return $query->where('consumers.company_id', $user->company_id);
                elseif(strtolower($user->user_type) == 'subclient1')
                    return $query->where('consumers.sub_client1_id', $user->subclient_id);
                else
                    return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })->join('consumer_unsubscribes', 'consumers.id', '=', 'consumer_unsubscribes.consumer_id')
            ->selectRaw(implode(',', $selects))->get();
            foreach($data as $consumer)
            {
                foreach($headers as $field){
                    if(strpos($field, 'percent') !== false || $field == 'accrued_interest_rate')
                        $consumer->$field = $consumer->$field."%";
                    else if(strpos($field, 'amount') !== false || strpos($field, 'balance') !== false)
                        $consumer->$field = '$'.number_format($consumer->$field, 2);
                }
            }     
            $data = $data->map->only($headers);

        $date = Carbon::now()->format('Y-m-d');

        return Excel::download(new ReportExport($data), 'unsubscribe_'.$date.'.csv');
        
        }catch (\Throwable $ex) {
            return Redirect()->back()->with('error', 'Report Generation Failed!!');
        }
    }

    public function consumerReportTableHeaders(){
        $user = auth()->user();
        $csv_header = CsvHeader::where('company_id', auth()->user()->company_id)
            ->where(function ($query) use ($user){
                if(strtolower($user->user_type) == 'company')
                    return $query->where('subclient_id', null);
                else
                    return $query->where('subclient_id', $user->subclient_id);
            })->first();

        $json = (array)json_decode($csv_header->saved_headers);
        $data = array_values($json);
        $to_remove = array('Select');
        $result = array_diff($data, $to_remove);
        //push id and invitation_link
        array_push($result, 'invitation_link');
        return $result;
    }
}