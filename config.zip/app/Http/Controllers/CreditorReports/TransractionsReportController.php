<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use PDF, Auth;
use App\Transaction;
use App\ScheduleTransaction;
use App\Subclient;
use Illuminate\Support\Facades\DB;

class TransractionsReportController extends Controller
{
    public function transactions()
    {
        $all = false;
        $user = auth()->user();

        if (strtolower($user->user_type) == 'Subclient1'){
            $field = ["id","sub_client1_id"];
            $id = $user->subclinet_id;
        } elseif (strtolower($user->user_type) == 'Subclient2') {
            $field = ["id","sub_client2_id"];
            $id = $user->subclinet_id;
        } elseif (strtolower($user->user_type) == 'company') {
            $field = ["company_id","company_id"];
            $id = $user->company_id;
            $all = true;
        }

        $subclients = Subclient::where($field[0], $id)->get();

        $Scheduled_Transactions = ScheduleTransaction::where($field[1], $user->subclient_id)->get();
        $upcoming_transactions = DB::table('consumers')
            ->join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
            ->join('payment_profiles', 'schedule_transactions.payment_profile_id', '=', 'payment_profiles.id')
            ->where('consumers.'.$field[1], $id)
            ->where('schedule_transactions.schedule_date', '>', now())
            ->whereIn('consumers.status', ['payment_accepted'])
            ->select(
                'schedule_transactions.*',
                'consumers.first_name',
                'consumers.last_name',
                'consumers.account_number',
                'consumers.id',
                'schedule_transactions.id as schedule_id',
                'schedule_transactions.payment_profile_id',
                'payment_profiles.id',
                'payment_profiles.method'
            )->orderBy('schedule_transactions.schedule_date')->get();

        $transactions = Transaction::where($field[1], $id)->whereIn('status', ["Failed", "Successful"])->with('consumer')->get();
        $failed_transaction = $transactions->where('status', "Failed");
        $succesfull_transaction = $transactions->where('status', "Successful");

        return view('yn.modules.report.transactions', compact(['upcoming_transactions', 'failed_transaction', 'succesfull_transaction', 'subclients', 'all']));
    }

    public function transactionsReport(Request $request)
    {
        $request->validate([
            'subclient' => 'required|string',
            'from' => 'required|date',
            'to' => 'required|date',
        ]);
        try {
            $user = auth()->user();
            $from = $request->get('from');
            $to = $request->get('to');
            $subclient = $request->get('subclient');
            $sub = Subclient::where('id', $subclient)->first();
            $all = false;

            $upcoming_transactions = DB::table('consumers')
                    ->join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
                    ->join('payment_profiles', 'schedule_transactions.payment_profile_id', '=', 'payment_profiles.id')
                    ->when(true, function($query) use ($subclient, $sub){
                        if ($subclient == "all")
                            return $query->where('consumers.company_id', auth()->user()->company->id);
                        elseif(strtolower($sub->subclient_type) == "subclient1")
                            return $query->join('subclients', 'subclients.id', '=', 'schedule_transactions.sub_client1_id');
                        else 
                            return $query->join('subclients', 'subclients.id', '=', 'schedule_transactions.sub_client2_id');
                    })->whereBetween(DB::raw('DATE(schedule_transactions.schedule_date)'), [$from, $to])
                    ->whereIn('consumers.status', ['payment_accepted'])
                    ->select(
                        'schedule_transactions.*',
                        'consumers.first_name',
                        'consumers.last_name',
                        'consumers.account_number',
                        'consumers.id',
                        'schedule_transactions.id as schedule_id',
                        'schedule_transactions.payment_profile_id',
                        'payment_profiles.id',
                        'payment_profiles.method'
                    )->orderBy('schedule_transactions.schedule_date')->get();

            $transaction = Transaction::when(true, function($query) use ($subclient, $sub){
                    if ($subclient == "all")
                        return $query->where('company_id', Auth::user()->company_id);
                    elseif(strtolower($sub->subclient_type) == "subclient1")
                        return $query->where('sub_client1_id', $sub->id)->join('subclients', 'subclients.id', '=', 'transactions.sub_client1_id');
                    else 
                        return $query->where('sub_client2_id', $sub->id)->join('subclients', 'subclients.id', '=', 'transactions.sub_client2_id');
                })->whereBetween(DB::raw('DATE(created_at)'), [$from, $to])->whereIn('status', ["Successfull", "Failed"])->get();

            $failed_transaction = $transaction->where('status', "Failed");
            $succesfull_transaction = $transaction->where('status', "Successfull");

            if (strtolower($user->user_type) == 'company') {
                $subclients = Subclient::where('company_id', Auth::user()->company_id)->get();
                $all = true;
            }
            else
                $subclients = $sub;

            return view('yn.modules.report.transactions', compact(['upcoming_transactions', 'failed_transaction', 'succesfull_transaction', 'subclients', 'all']));
        } catch (\Throwable $ex) {
            dd($ex);
        }
    }
}