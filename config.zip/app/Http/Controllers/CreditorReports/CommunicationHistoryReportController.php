<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\CommunicationHistory;
use App\Export\ReportExport;
use Excel;
use Carbon\Carbon;

class CommunicationHistoryReportController extends Controller
{
    public function communicationHistory(Request $request)
    {
        $search = $request->get('search');
        $option = $request->get('option');

        if ($option == 'download') {
            $data = [];
            $comm_histories = CommunicationHistory::with(['consumer', 'company', 'group', 'template'])
            ->whereHas('consumer', function ($query) use ($search) {
                $query->where('account_number', 'like', '%' . $search . '%');
            })
            ->where('company_id', auth()->user()->company_id)->latest()->get();
            foreach ($comm_histories as $ch) {
                array_push($data, [
                    'Sent At' => $ch->created_at->format('Y-m-d H:i'), 'Account Number' => $ch->consumer->account_number,
                    'Consumer Name' => $ch->consumer->full_name, 'Email ID' => $ch->consumer->email1, 'Phone' => $ch->consumer->mobile1,
                    'SMS Segment' => $ch->smssegment, 'Group' => $ch->group->name, 'Template' => $ch->template->name,
                    'Template Type' => $ch->template->getType()
                ]);
            }
            $date = Carbon::now()->format('Y-m-d');

            return Excel::download(new ReportExport($data), 'Communication_History_'.$date.'.csv');
        } else {
            return view('yn.modules.report.comm-history', compact('search'));
        }
    }

    public function getCommunicationHistory(Request $request)
    {
        
        $user = auth()->user();

        $search = $request->input('search.value');

        // Get the count of the unfiltered data for pagination
        $total_communication_histories = CommunicationHistory::with(['consumer', 'company', 'group', 'template'])
        ->whereHas('consumer', function ($query) use ($search) {
            $query->where('account_number', 'like', '%' . $search . '%');
        })
        ->where('company_id', auth()->user()->company_id)
            ->count();

        $communication_histories = CommunicationHistory::with(['consumer', 'company', 'group', 'template'])
            ->whereHas('consumer', function ($query) use ($search) {
                $query->where('account_number', 'like', '%' . $search . '%');
            })
            ->where('company_id', auth()->user()->company_id)->latest()
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();

        // Get the master name for each entry
        foreach($communication_histories as $history)
        {
            $history->sent_at = $history->created_at->format('Y-m-d H:i');
            $history->profile_link = $history->consumer->profileLink();
            $history->account_number = $history->consumer->account_number;
            $history->full_name = $history->consumer->full_name;
            $history->group_name = $history->group->name;
            $history->template_name = $history->template->name;
            $history->template_type = strtoupper($history->templateType());
        }

        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_communication_histories),
            "recordsFiltered" => intval($total_communication_histories),
            "data"            => $communication_histories
            );

        echo json_encode($json_data);
    }

    public function downloadCommunicationHistory()
    {
        $comm_histories = CommunicationHistory::with(['consumer' => function ($query) {
            $query->select('account_number', 'first_name', 'middle_name', 'last_name');
        }, 'company', 'group', 'template'])
            ->where('company_id', auth()->user()->company_id)
            ->first()->toArray();
        $date = Carbon::now()->format('Y-m-d');
        dd($comm_histories);
        return Excel::download(new ReportExport($comm_histories), 'comm-history_'.$date.'.csv');
    }
}