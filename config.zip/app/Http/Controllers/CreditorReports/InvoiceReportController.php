<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use App\Company;
use PDF, Auth;
use App\RnnTransaction;

class InvoiceReportController extends Controller
{
    public function invoiceReport()
    {
        $transactions = RnnTransaction::where('company_id', auth()->user()->company_id)->latest()->get();

        return view('yn.modules.report.invoices')->with('transactions', $transactions);
    }

    public function downloadInvoice($id)
    {
        $credit = 0.00;

        $company = Company::find(auth()->user()->company_id);
        $rnnTransaction = RnnTransaction::where('company_id', auth()->user()->company_id)->find($id);

        $from = $rnnTransaction->billing_cycle_start;
        $to = $rnnTransaction->billing_cycle_end;
        
        $transactions = $company->transactions($from, $to);
        $transactionAmount = $company->transactionCharge($from, $to);

        $rnn_id = $company->rnn_id;

        if (strpos($rnnTransaction->responce, 'OKAY') != false) {

            return PDF::loadView('yn.emails.rnn-transaction', compact('rnnTransaction', 'transactionAmount','rnn_id','credit'))->download($from.'_'.$to.'_invoice.pdf');

        } 
        else {

            return PDF::loadView('yn.emails.rnn-transaction', compact('rnnTransaction', 'transactionAmount'))->download($from.'_'.$to.'_invoice.pdf');
            
        }
    }
}