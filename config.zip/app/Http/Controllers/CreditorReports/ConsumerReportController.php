<?php

namespace App\Http\Controllers\CreditorReports;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Export\ReportExport;
use Excel;
use Carbon\Carbon;
use App\Transaction;
use App\ScheduleTransaction;
use App\Consumer;
use App\ConsumerUnsubscription;
use App\ConsumerNegotiation;
use App\ConsumerActivity;
use App\PaymentProfile;
use Illuminate\Support\Facades\DB;
use App\CsvHeader;

class ConsumerReportController extends Controller
{
    public function consumerReport(Request $request)
    {
        try {
            $result = $this->consumerReportTableHeaders();
            return View('yn.modules.report.consumer', compact('result'));
        } catch (\Throwable $ex) {
            return Redirect()->back()->with('error', 'Header have not set!!');
        }
    }

    public function deactivatedConsumerReport()
    {
        try {
            $result = $this->consumerReportTableHeaders();
            return View('yn.modules.report.deactivatedConsumers', compact('result'));
        } catch (\Throwable $ex) {
            return Redirect()->back()->with('error', 'Header have not set!!');
        }
    }

    public function getConsumerReportTableHeaders(){
        $result = $this->consumerReportTableHeaders();
        echo json_encode($result);
    }

    public function consumerReportTable($type = null, Request $request)
    {  
        if($type == 'deactivated')
            $type = '=';
        else
            $type = '!=';
        
        $user = auth()->user();
        $result = $this->consumerReportTableHeaders();

        $order = $result[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $consumers_total = DB::table('consumers')->where(function($query) use ($user){
                if(strtolower($user->user_type) == 'company')
                    return $query->where('company_id', $user->company_id);
                elseif(strtolower($user->user_type) == 'subclient1')
                    return $query->where('sub_client1_id', $user->subclient_id);
                elseif(strtolower($user->user_type) == 'subclient2')
                    return $query->where('sub_client2_id', $user->subclient_id);
            })->where('status', $type, 'deactivated')->count();

        $consumers_before = DB::table('consumers')->where(function($query) use ($user){
                if(strtolower($user->user_type) == 'company')
                    return $query->where('company_id', $user->company_id);
                elseif(strtolower($user->user_type) == 'subclient1')
                    return $query->where('sub_client1_id', $user->subclient_id);
                elseif(strtolower($user->user_type) == 'subclient2')
                    return $query->where('sub_client2_id', $user->subclient_id);
            })->when($search != "", function($query) use ($search, $result){
                return $query->whereRaw("concat(ifnull(account_number, ''), ifnull(first_name, ''), ifnull(last_name, ''), ifnull(email1, ''), ifnull(mobile1, ''),
                                             ifnull(last4ssn, ''), ifnull(sub_client1_id, ''), ifnull(sub_client2_id, ''), ifnull(pass_through1, ''),
                                             ifnull(pass_through2, ''), ifnull(pass_through3, ''), ifnull(pass_through4, ''), ifnull(pass_through5, ''),
                                             ifnull(state, '')) like '%" . $search . "%'");
            })->where('status', $type, 'deactivated')
            ->selectRaw( implode(',', $result).', id as id_consumer, (select count(*) from consumer_unsubscribes where consumer_id = id_consumer) as unsubscribed, (select count(*) from schedule_transactions where consumer_id = id_consumer and status = "scheduled" limit 1) as scheduled_payments, status');
        $consumers = $consumers_before->orderBy($order, $dir)->limit($request->input('length'))->offset($request->input('start'))->get();

        foreach($consumers as $consumer)
        {
            switch($consumer->status)
            {
                case 'uploaded':
                    $consumer->status = 'Not Joined Yet';
                    break;
                case 'visited':
                    $consumer->status = 'Visited, SNN not verified';
                    break;
                case 'joined':
                    $consumer->status = 'Joined YouNegotiate';
                    break;
                case 'payment_setup':
                    $consumer->status = 'Offer Accepted - Pending Payment Setup';
                    break;
                case 'payment_accepted':
                    $consumer->status = 'Payment Plan In Place';
                    break;
                case 'settled':
                    $consumer->status = 'Account Settled';
                    break;
                case 'payment_failed':
                    $consumer->status = 'Have Failed Payment';
                    break;
                case 'payment_declined':
                    $consumer->status = 'Payment Declined';
                    break;
                case 'payment_made':
                    $consumer->status = 'Payment Made';
                    break;
                case 'renegotiate':
                    $consumer->status = 'Re-Negotiating';
                    break;
                case 'deactivated':
                    $consumer->status = 'Deactivated';
                    break;              
            }
            foreach($result as $field)
                if($consumer->$field)
                {
                    if(strpos($field, 'percent') !== false || $field == 'accrued_interest_rate')
                        $consumer->$field = $consumer->$field."%";
                    else if(strpos($field, 'amount') !== false || strpos($field, 'balance') !== false)
                        $consumer->$field = '$'.number_format($consumer->$field, 2);
                }
        }        
        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($consumers_total),
            "recordsFiltered" => intval($consumers_total),
            "data"            => $consumers
            );

        echo json_encode($json_data);
    }

    //Generate Report Excel
    public function consumerReportCsv($deactivated){
        try {
            $user = auth()->user();
            $result = $this->consumerReportTableHeaders();

            $consumers = Consumer::where(function ($query) use($user){
                if (strtolower($user->user_type) == 'company')
                    return $query->where('company_id', $user->company_id);
                elseif(strtolower($user->user_type) == 'subclient1')
                    return $query->where('sub_client1_id', $user->subclient_id);
                else
                    return $query->where('sub_client2_id', $user->subclient_id);
            })->where(function ($query) use($deactivated){
                if($deactivated)
                    $query->where('status', 'deactivated');
                else
                    $query->where('status', '!=', 'deactivated');
            })->get();
            $_consumers = $consumers->map->only($result);
            $date = Carbon::now()->format('Y-m-d');

            if($deactivated)
                $deactivated = 'deactivated_';
            else
                $deactivated = 'current_';

            return Excel::download(new ReportExport($_consumers), $deactivated.'consumers_'.$date.'.csv');
        } catch (\Throwable $ex) {
            return Redirect()->back()->with('error', 'Header have not set!!');
        }
    }

    public function deleteConsumer($consumer_id)
    {
        //Consumer::where('id', $id)->delete();
        $consumer = Consumer::find($consumer_id);

        if($consumer->status != 'uploaded'){
            if(ScheduleTransaction::where('consumer_id', $consumer->id)->whereBetween('schedule_date', [date('y-m-d'), date('y-m-d', strtotime('+30 days'))])->exists())
                return Redirect()->back()->with('error-msg', "Cannot delete a consumer that has a payment scheduled in the next 30 days!");

            $consumer->status = 'deactivated';
            $consumer->save();

            //add consumer to unsubscription list
            $consumerUnsubscription = new ConsumerUnsubscription();
            $consumerUnsubscription->consumer_id = $consumer->id;
            $consumerUnsubscription->company_id = $consumer->company_id;
            $consumerUnsubscription->email = $consumer->email1;
            $consumerUnsubscription->phone = $consumer->mobile1;
            $consumerUnsubscription->save();
        }
        else{ 
            ConsumerNegotiation::where('consumer_id', $consumer->id)->delete();
            ConsumerActivity::where('consumer_id', $consumer->id)->delete();
            PaymentProfile::where('consumer_id', $consumer->id)->delete();
            ScheduleTransaction::where('consumer_id', $consumer->id)->delete();
            Transaction::where('consumer_id', $consumer->id)->delete();
            ConsumerUnsubscription::where('consumer_id', $consumer->id)->delete();

            $consumer->delete();
        }

        return redirect('home')->with('success', 'Consumer has been deleted !!');
    }

    public function cancelConsumer($consumer_id)
    {
        ScheduleTransaction::where('consumer_id', $consumer_id)->where('status', 'scheduled')->where('company_id', auth()->user()->company_id)->update(['status' => 'Cancelled', 'payment_complete' => '3']);

        return Redirect()->back()->with('success', "Consumer's scheduled payments has been canceled!!");
    }
    /////////////////////////End Consumer //////////////////////////////////////

    public function consumerV2()
    {
        return view('yn.modules.report.consumer-v2');
    }

    function consumerReportTableHeaders(){
        $user = auth()->user();
        $csv_header = CsvHeader::where('company_id', auth()->user()->company_id)
            ->where(function ($query) use ($user){
                if(strtolower($user->user_type) == 'company')
                    return $query->where('subclient_id', null);
                else
                    return $query->where('subclient_id', $user->subclient_id);
            })->first();

        $json = (array)json_decode($csv_header->saved_headers);
        $data = array_values($json);
        $result = array_diff($data, ['Select']);
        //push id and invitation_link
        array_push($result, 'invitation_link');
        array_push($result, 'status');
        return $result;
    }
}