<?php

namespace App\Http\Controllers;

use App\Consumer;
use Illuminate\Http\Request;
use App\Transaction;
use Illuminate\Support\Facades\Log;
use App\Merchant;
use SoapClient;

use net\authorize\api\contract\v1 as AnetAPI;
use net\authorize\api\controller as AnetController;

class RefundController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:consumers');
    }

    public function refundPayment(Request $request){
        $transaction = Transaction::where('id', $request->id)->first();
        $consumer = Consumer::where('id', $transaction->consumer_id)->first();

        if ($consumer->merchant_id) {
            $merchent = Merchant::where('verified_at', '<>', null)->where('id', $consumer->merchant_id)->where('merchant_type', $consumer->method)->first();
        } else {
            $merchent = Merchant::when(true, function($query) use ($consumer) {
                if($consumer->sub_client2_id)
                    return $query->where('subclient_id', $consumer->sub_client2_id);
                elseif($consumer->sub_client1_id)
                    return $query->where('subclient_id', $consumer->sub_client1_id);
                else
                    return $query->where('company_id', $consumer->company_id);
                })->where('verified_at', '!=', null)
                ->where('merchant_type', $consumer->method)
                ->first();
        }

        if ($merchent) {
            Log::channel('refund_command')->info('Refunding consumer: '.$consumer->id);

            if ($merchent->merchant_name == "authorize") {

                Log::channel('refund_command')->info('Refund Gateway: authorize.net');
                $login_id = $merchent->authorize_login_id;
                $key = $merchent->authorize_transaction_key;

                $result = $this->refundAuthorize($transaction, $consumer, $login_id, $key, $transaction->amount);

                Log::channel('refund_command')->info('Key:' . $key . '  Loginid:' . $login_id);
                
            }
            if ($merchent->merchant_name == "usaepay") {

                $key = $merchent->usaepay_key;
                $pin = $merchent->usaepay_pin;

                Log::channel('refund_command')->info('Refund Gateway: usaepay');
                Log::channel('refund_command')->info('Key:' . $key . '  Pin:' . $pin);

                $result = $this->refundUsaepay($transaction, $consumer, $pin, $key, $transaction->amount);

                Log::channel('refund_command')->info('Refund Completed consumer Id:' . $consumer->id);
                
            }
            if ($merchent->merchant_name == "paidyet") {
                Log::channel('refund_command')->info('Refund Gateway: paidyet');

                $result = $this->refundPaidyet($transaction, $consumer, $merchent->paidyet_subdomain, $merchent->paidyet_key, $transaction->amount);

                Log::channel('refund_command')->info('Refund Completed consumer Id:' . $consumer->id);
                
            }
        }

        if($result == "success"){
            $transaction->status = "refunded";
            $transaction->save();
            return back()->with('success', 'The Payment Was Refunded.');
        }
        else{
            return back()->with('error-msg', 'Oh No something went wrong! Try again and if it persists contact a developer.');
        }
    }

    private function refundAuthorize($transaction, $consumer, $login_id, $key, $amount){
        try{
            /* Create a merchantAuthenticationType object with authentication details
            retrieved from the constants file */
            $merchantAuthentication = new AnetAPI\MerchantAuthenticationType();
            $merchantAuthentication->setName($login_id);
            $merchantAuthentication->setTransactionKey($key);
            
            // Set the transaction's refId
            $refId = 'ref' . time();

            if(strtolower($consumer->method) == "cc"){
                Log::channel('refund_command')->info('Refund Method: CC');
                // Create the payment data for a credit card
                $profileToCharge = new AnetAPI\CustomerProfilePaymentType();
                $profileToCharge->setCustomerProfileId($consumer->profileid);
                $paymentProfile = new AnetAPI\PaymentProfileType();
                $paymentProfile->setPaymentProfileId($consumer->paymentprofileid);
                $profileToCharge->setPaymentProfile($paymentProfile);
            }
            else{
                Log::channel('refund_command')->info('Refund Method: ACH');
                // see eCheck documentation for proper echeck type to use for each situation
                $bankAccount = new AnetAPI\BankAccountType();
                $bankAccount->setAccountType('checking');
                $bankAccount->setEcheckType('WEB');
                $bankAccount->setRoutingNumber($consumer->routing_number);
                $bankAccount->setAccountNumber($consumer->account_number);
                $bankAccount->setNameOnAccount($consumer->first_name . ' ' . $consumer->last_name);
                $bankAccount->setBankName('NA');
                $paymentOne = new AnetAPI\PaymentType();
                $paymentOne->setBankAccount($bankAccount);
            }

            //create a transaction
            $transactionRequest = new AnetAPI\TransactionRequestType();
            $transactionRequest->setTransactionType( "refundTransaction"); 
            $transactionRequest->setAmount($amount);

            if(strtolower($consumer->method) == "cc")
                $transactionRequest->setProfile($profileToCharge);
            else
                $transactionRequest->setPayment($paymentOne);

            $transactionRequest->setRefTransId($transaction->transaction_id);
        
            $request = new AnetAPI\CreateTransactionRequest();
            $request->setMerchantAuthentication($merchantAuthentication);
            $request->setRefId($refId);
            $request->setTransactionRequest( $transactionRequest);
            $controller = new AnetController\CreateTransactionController($request);
            $response = $controller->executeWithApiResponse(\net\authorize\api\constants\ANetEnvironment::PRODUCTION);
            //$response = $controller->executeWithApiResponse( \net\authorize\api\constants\ANetEnvironment::SANDBOX);

            if ($response != null){
                if($response->getMessages()->getResultCode() == "Ok"){
                    $tresponse = $response->getTransactionResponse();
                    if ($tresponse != null && $tresponse->getMessages() != null){
                        Log::channel('refund_command')->info('Refund Completed consumer Id:' . $consumer->id);
                        return "success";
                    }
                }      
            }

            Log::channel('refund_command')->info('Refund failed consumer Id:' . $consumer->id);
            return "failed";
        }
        catch (\Throwable $ex) {
            Log::channel('refund_command')->error('Consumers ID:' . $consumer->id . ' ' . $ex);
            return "failed";
        }
    }

    private function refundUsaepay($transaction, $consumer, $pin, $key, $amount){
        try {
            Log::channel('refund_command')->info('usaepay initiate transaction with profile---------');

            $Parameters = array(
                'Command' => 'refund',
                'amount' => $amount,
                'refnum' => $transaction->transaction_id,
            );
            $CustNum = $consumer->profileid;

            $Verify = true;
            // instantiate SoapClient object as $client
            //$wsdl='https://sandbox.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
            $wsdl = 'https://www.usaepay.com/soap/gate/0AE595C1/usaepay.wsdl';
            $client = new SoapClient($wsdl);
            $token = $this->getToken($key, $pin);
            // dd($CustNum);
            $paymethods = $client->getCustomerPaymentMethods($token, $consumer->profileid);

            $PayMethod = $paymethods[0]->MethodID;

            //$res=$client->runCustomerTransaction($token, $CustNum, $Details, $Command, $PayMethod);

            $res = $client->runCustomerTransaction($token, $CustNum, $PayMethod, $Parameters);
            $tid = $res->RefNum;
            if ($res->ResultCode == "A") {
                $status_code = "A";
                $status = "success";
                //Update schedule transaction table
            } else {
                $status_code = "";
                $status = "failed";
            }

            Log::channel('refund_command')->info('Transaction Responce:' . (string)(json_encode($res)));
            Log::channel('refund_command')->info('usaepay Completed transaction with profile-------');

            return $status;
        } catch (\Throwable $ex) {
            //dd($ex);
            Log::channel('refund_command')->error('Consumers ID:' . $consumer->id . ' ' . $ex);
            return "failed";
        }
    }

    private function refundPaidyet($transaction, $consumer, $subdomain, $key, $amount){
        try{
            $postdata =   [
                'subdomain' => $subdomain,
                'key' => $key,
                'nonce'   => rand(154678, 10000000),
                'time'=> time()
            ];
            $ch = curl_init();
            $url =  "https://api.paidyet.com/v2/login";
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $output = curl_exec($ch);
            $token = json_decode($output)->result->token;

            $url =  "https://api.paidyet.com/v2/transaction/".$transaction->transaction_id;
            $postdata = ['action'=>'refund', 'amount'=>[$amount]];
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_POSTFIELDS,$postdata);
            $headerarray[] = "Authorization: Bearer ".$token;
            curl_setopt($ch, CURLOPT_HTTPHEADER,$headerarray);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
            $output = curl_exec($ch);
            return "success";
        }
        catch(\Exception $e) {
            Log::channel('refund_command')->error('Consumers ID:' . $consumer->id . ' ' . $e);
            return "failed";
        }
    }
}