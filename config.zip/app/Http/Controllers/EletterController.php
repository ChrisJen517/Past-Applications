<?php

namespace App\Http\Controllers;

use App\Group;
use App\Repositories\CampaignRepository;
use App\Repositories\GroupRepository;
use App\Repositories\EletterRepository;
use App\Jobs\SendEletterReminderJob;
use App\Eletter;
use DB;
use Illuminate\Http\Request;
use App\Consumer;

class EletterController extends Controller
{

    protected $repository;

    public function __construct(EletterRepository $repository)
    {
        $this->middleware(['auth', 'check-profile-completed', 'redirect-if-subclient-user']);
        $this->middleware('sidebar-menu:communication');
        $this->repository = $repository;
    }

    public function index(GroupRepository $groupRepository)
    {
        $type = request()->get('type') ? request()->get('type') : 'email';
        $eletters = $this->repository->eletters(auth()->user()->company_id);
        $groups = $groupRepository->enabledGroups(auth()->user()->company_id);
        return view('yn.modules.communication.e-letter.main', compact('eletters', 'groups', 'type'));
    }

    public function store(Request $request){
        $params = $request->validate($this->repository->creationValidationRules());  
        $params['message'] = decodeBase64($request->message,  auth()->user()->company_id, $request->name, 'public/assets/images/eletterTemplate/');
        $eletter = $this->repository->create(array_except($params, ['attach_group']));
        if ($eletter) {
            $message = 'Your e-Letter has been saved!';
        }

        if ($request->has('attach_group')) {
            if ($params['attach_group'] != null) {
                $group = Group::find($params['attach_group']);
                $this->repository->update('id', $eletter->id, ['group_id' => $params['attach_group']]);
                if ($group->enabled) {
                    $this->sendToConsumers($group, $eletter->id);
                    $message = "Your e-Letter was sent to ".$group->name;
                } else {
                    session()->flash('error', 'Cannot create campaign because the group is disabled');
                    return redirect()->back();
                }
            }
        }
        session()->flash('success', $message);
        return redirect()->back();
    }

    public function edit($id, GroupRepository $groupRepository)
    {
        $eletter = $this->repository->get('id', $id);
        $eletters = $this->repository->eletters(auth()->user()->company_id);
        $groups = $groupRepository->enabledGroups(auth()->user()->company_id);
        return view('yn.modules.communication.e-letter.main', compact('eletter', 'eletters', 'groups'));
    }

    public function update($id, Request $request)
    {
        $params = $request->validate($this->repository->updateValidationRules());
        $params['message'] = decodeBase64($request->message,  auth()->user()->company_id, $request->name, 'public/assets/images/eletterTemplate/');
        $this->repository->update('id', $id, array_except($params, ['attach_group']));

        if ($request->has('attach_group')) {
            if ($params['attach_group'] != null) {
                $group = Group::find($params['attach_group']);
                $this->repository->update('id', $id, ['group_id' => $params['attach_group']]);
                if ($group->enabled) {
                    $this->sendToConsumers($group, $id);
                } else {
                    session()->flash('error', 'Cannot create campaign because the group is disabled');
                    return redirect()->back();
                }
            }
        }

        session()->flash('success', 'Your template has been updated!');
        return redirect()->to(url('eletter'));
    }

    public function delete($id)
    {
        $item = $this->repository->getByID($id);
        $this->repository->delete($id);
        session()->flash('success', $item->name . " has been deleted!");
        return redirect()->back();
    }

    public function enable($id)
    {
        $item = $this->repository->getByID($id);
        $item->disabled = false;
        $item->save();
        return redirect()->back()->with(['success' => 'e-Letter: '.$item->name.' has been enabled!']);
    }

    public function disable($id)
    {
        $item = $this->repository->getByID($id);
        $item->disabled = true;
        $item->save();
        return redirect()->back()->with(['success' => 'e-Letter: '.$item->name.' has been disabled!']);
    }

    public function create(Request $request){
        $group = Group::find($request->group_id);
        if (!$group->enabled){
            session()->flash('error', 'Cannot send Eletter because the group is disabled');
            return redirect()->back();
        }

        $this->sendToConsumers($group, $request->eletter_id);
        $message = "Your e-Letter was sent to ".$group->name;
        session()->flash('success', $message);

        return redirect()->back();
    }

    public function sendToConsumers($group, $eletter_id){
        $consumer_ids = $group->getMemberIDs(auth()->user()->company_id);
        $insertValues = "";
        foreach($consumer_ids as $consumer){
            $insertValues = $insertValues."('".$eletter_id."', '".$consumer->id."', '1', CURRENT_TIMESTAMP(), CURRENT_TIMESTAMP()),";
        }
        if($insertValues == "")
            return;
        $insertValues = substr_replace($insertValues,"", -1);

        DB::select(DB::raw("INSERT INTO `eletters_consumers_map`(eletters_id, consumer_id, enabled, created_at, updated_at) VALUES ".$insertValues.";"));
        SendEletterReminderJob::dispatch($consumer_ids, auth()->user()->company, auth()->user()->email);
        return;
    }

    public function eletterTracker(GroupRepository $groupRepository){
        $eletters = Eletter::leftJoin('eletters_consumers_map', 'eletters_consumers_map.eletters_id', 'eletters.id')->where('company_id', auth()->user()->company_id)
        ->selectRaw('eletters.*, count(eletters_consumers_map.id) as total_sent, count(IF(read_by_consumer = 1, eletters_consumers_map.id, null)) as total_read')
        ->groupBy('eletters.id')->get();

        $groups = $groupRepository->enabledGroups(auth()->user()->company_id);
        return view('yn.modules.communication.e-letter.tracker', compact('eletters', 'groups'));
    }
}