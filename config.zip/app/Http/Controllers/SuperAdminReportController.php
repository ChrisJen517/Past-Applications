<?php

namespace App\Http\Controllers;

use App\Company;
use App\RnnTransaction;
use App\Repositories\CommunicationRepository;
use App\Repositories\CompanyRepository;
use App\Repositories\SubclientRepository;
use App\Repositories\UserRepository;
use Illuminate\Http\Request;
use App\Traits\SuperAdminReportsTrait;
use Illuminate\Support\Facades\Log;
use Carbon\Carbon;
use PDF;

class SuperAdminReportController extends Controller
{
    use SuperAdminReportsTrait;

    public function __construct(CompanyRepository $companyRepository, SubclientRepository $subclientRepository,
                                UserRepository $userRepository, CommunicationRepository $communicationRepository)
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:superadmin');
        // $this->middleware('role:superadmin');
        $this->companyRepository = $companyRepository;
        $this->subclientRepository = $subclientRepository;
        $this->userRepository = $userRepository;
        $this->communicationRepository = $communicationRepository;
    }

    public function index(Request $request){
        $name = $request->type ?? '';
        $name .= "_".Carbon::now()->format('Y-m-d');
        $companyList = $this->companyList();
        $companies = Company::when(!empty($companyList), function ($query) use ($companyList) {
            return $query->whereIn('id', $companyList);
        })->orderBy('company_name')->where('id','!=', 1)->get();
        try{
            $reportData = $this->getSuperAdminReport($request->type, $request->company, $request->from, $request->to);
            $data = $reportData[0];
            $totals = $reportData[1];
            $headers = $reportData[2];
        }
        catch (\Throwable $e) {
            Log::channel('superAdmin_report')->error($e);
            return redirect()->back()->with('error-msg', 'Report generation Failed');
        }
        return view('yn.superadmin.report.report', compact('companies', 'totals', 'data', 'headers', 'name'));
    }

    public function invoiceReport()
    {
        $transactions = RnnTransaction::with('company')->latest()->get();

        return view('yn.superadmin.report.invoices')->with('transactions', $transactions);
    }

    public function downloadInvoice($id)
    {
        $credit = 0.00;

        $rnnTransaction = RnnTransaction::find($id);
        $company = Company::find($rnnTransaction->company_id);

        $from = $rnnTransaction->billing_cycle_start;
        $to = $rnnTransaction->billing_cycle_end;
        
        $transactions = $company->transactions($from, $to);
        $transactionAmount = $company->transactionCharge($from, $to);

        $rnn_id = $company->rnn_id;

        if (strpos($rnnTransaction->responce, 'OKAY') != false) {

            return PDF::loadView('yn.emails.rnn-transaction', compact('rnnTransaction', 'transactionAmount','rnn_id','credit'))->download($from.'_'.$to.'_invoice.pdf');

        } 
        else {

            return PDF::loadView('yn.emails.rnn-transaction', compact('rnnTransaction', 'transactionAmount'))->download($from.'_'.$to.'_invoice.pdf');
            
        }
    }
}