<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ConsumerActivity;
use App\Consumer;
use App\ConsumerLog;
use Yajra\DataTables\Facades\DataTables;

class ConsumerActivityController extends Controller
{
    public function index(){
        //$consumers = Consumer::where('company_id', auth()->user()->company->id)->where('consumer_login_id','!=',null)->select('consumer_login_id')->get();

        // foreach ($consumers as $row) {
        //  $logins[] = $row->consumer_login_id;
        // }
        if(auth()->user()->isCompanyUser()){
           $activites = ConsumerActivity::where('company_id', auth()->user()->company->id)->latest()->limit(100)
                    ->get()->unique('session_id');
        }
        elseif(auth()->user()->isSubclient1User()){
            $activites = ConsumerActivity::where('sub_client1_id', auth()->user()->company->id)->latest()->limit(100)
                    ->get()->unique('session_id');
        }
        elseif(auth()->user()->isSubclient2User()){
            $activites = ConsumerActivity::where('sub_client2_id', auth()->user()->company->id)->latest()->limit(100)
                    ->get()->unique('session_id');
        }


        return view('yn.modules.customer-activities', compact('activites'));
    }

    public function showActivities($session_id){
        $activites = ConsumerActivity::where('session_id', $session_id)
                    ->get();

        return json_encode($activites);
    }

    public function historyTable($id){
        $logs = ConsumerLog::select('created_at', 'log_message')->where('consumer_id', 'like', '%'.$id.'%')->get();

        foreach($logs as $log){
            $log->log_message = preg_replace('/{(.*?)}/', '', $log->log_message);
            if(substr($log->log_message, -1) == '/')
                $log->log_message = substr($log->log_message, 0, -1);
        }

        return DataTables::of($logs)->make(true);
    }
}
