<?php

namespace App\Http\Controllers;

use App\Repositories\CampaignRepository;
use App\Repositories\ConsumerRepository;
use App\Repositories\GroupRepository;
use App\Repositories\TemplateRepository;
use App\Template;
use App\Traits\EnableDisableTrait;
use Illuminate\Http\Request;
use App\Group;
use App\Export\GroupExport;
use Excel;
use Carbon\Carbon;

class GroupController extends Controller
{
    protected $repository, $consumerRepository;

    public function __construct(GroupRepository $repository, ConsumerRepository $consumerRepository)
    {
        $this->middleware(['auth', 'check-profile-completed', 'redirect-if-subclient-user']);
        $this->middleware('sidebar-menu:communication');
        $this->repository = $repository;
        $this->consumerRepository = $consumerRepository;
    }

    public function index(TemplateRepository $templateRepository)
    {
        //$groups = $this->repository->groups(auth()->user()->company_id);
        $templates = $templateRepository->enabledTemplates(auth()->user()->company_id);
        return view('yn.modules.communication.group', compact('templates'));
    }

    public function getTable(Request $request){
        $columns = array(
            0 => 'name',
            1 => 'created_date',
            2 => 'madeBy',
            3 => 'description',
        );

        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $total_groups = Group::where('company_id', auth()->user()->company_id)->count();

        if($search){
            $filtered = Group::where('groups.company_id', auth()->user()->company_id)->leftjoin('users', 'users.id', '=', 'groups.created_by')
                ->whereRaw("(
                (groups.name LIKE '%".$search."%') OR
                (groups.created_at LIKE '%".$search."%') OR
                (users.name LIKE '%".$search."%') OR
                (groups.description LIKE '%".$search."%')
                )")->count();
        }
        else
            $filtered = $total_groups;

        $groups = Group::where('groups.company_id', auth()->user()->company_id)
        ->leftjoin('users', 'users.id', '=', 'groups.created_by')
        ->selectRaw('
            groups.id as id, groups.name as name, groups.created_at as created_date, users.name as madeBy, groups.description, 0 as user_count, 0 as balance, enabled,
            customer_status_rule, customer_custom_rule, 1 as editable
        ')->when($search, function($query, $search){
            return $query->whereRaw("(
                (groups.name LIKE '%".$search."%') OR
                (groups.created_at LIKE '%".$search."%') OR
                (users.name LIKE '%".$search."%') OR
                (groups.description LIKE '%".$search."%')
                )");
        })->limit($request->input("length"))->offset($request->input("start"))->orderBy($order, $dir)->get();

        foreach($groups as $group){
            $group->created_date = date('Y-m-d H:i', strtotime($group->created_date));
            $group->user_count = $group->getMemberCountAttribute() ?? 0;
            $group->balance = "$".number_format($group->getTotalBalanceAttribute() ?? 0, 2);

            if(!empty($group->customer_custom_rule) && $group->customer_custom_rule != "[]"){
                $customRules = json_decode($group->customer_custom_rule);
                if($customRules[0]->field_name == "failed_list")
                    $group->editable = 0;
            }
        }

        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_groups),
            "recordsFiltered" => intval($filtered),
            "data"            => $groups
        );

        echo json_encode($json_data);
    }

    public function store(Request $request, CampaignRepository $campaignRepository)
    {
        $params = $request->validate($this->repository->creationValidationRules());
        $group = $this->repository->create(array_except($params, ['email_template', 'sms_template']));
        if ($group && !$params['email_template'] && !$params['sms_template']) 
            $message = "Your group has been saved!";
        else
            $message = '';

        foreach(['email_template', 'sms_template'] as $templateType){
            if ($params[$templateType]) {
                if ($params[$templateType] != null) {
                    $template = Template::find($params[$templateType]);
                    if ($template->enabled) {
                        $message = $message.' '.$this->repository->attachTemplate($group->id, $params[$templateType]);
                    } else {
                        session()->flash('error', 'Cannot create campaign because the template is disabled');
                        return redirect()->back();
                    }
                }
            }
        }
        session()->flash('success', $message);
        return redirect()->to(url('group'));
    }

    public function edit($id, TemplateRepository $templateRepository)
    {
        $group = $this->repository->get('id', $id);
        $groups = $this->repository->groups(auth()->user()->company_id);
        $templates = $templateRepository->enabledTemplates(auth()->user()->company_id);
        return view('yn.modules.communication.group', compact('group', 'groups', 'templates'));
    }

    public function update($id, Request $request)
    {
        $params = $request->validate($this->repository->updateValidationRules());
        $this->repository->update('id', $id, array_except($params, ['email_template', 'sms_template']));

        if (!$params['email_template'] && !$params['sms_template']) 
            $message = 'Your group has been updated!';
        else
            $message = '';
        
        foreach(['email_template', 'sms_template'] as $templateType){
            if ($params[$templateType]) {
                if ($params[$templateType] != null) {
                    $template = Template::find($params[$templateType]);
                    if ($template->enabled) {
                        $message = $message.' '.$this->repository->attachTemplate($id, $params[$templateType]);
                    } else {
                        session()->flash('error', 'Cannot create campaign because the template is disabled');
                        return redirect()->back();
                    }
                }
            }
        }
        session()->flash('success', $message);
        return redirect()->to(url('group'));
    }

    public function delete($id)
    {
        $item = $this->repository->getByID($id);
        $this->repository->delete($id);
        session()->flash('success', $item->name . " has been deleted!");
        return redirect()->back();
    }

    public function deleteConsumers($id)
    {
        $group = $this->repository->getByID($id);
        $members = $group->members();
        $count = $members->count();
        foreach ($members as $member) {
            $member->status = "deactivated";
            $member->save();
        }
        session()->flash('success', "$count no of members has been deleted!");
        return redirect()->back();
    }

    public function getGroupMember($gid)
    {
        $date = Carbon::now()->format('Y-m-d');
        $group = Group::find($gid);
        $members = $group->members();
        //dd($members);
        $subset = $members->map->only(['account_number', 'first_name', 'last_name', 'gender', 'address1', 'address2', 'city', 'state', 'zip', 'sub_client1_id', 'sub_client1_name', 'sub_client2_id', 'sub_client2_name', 'mobile1', 'mobile2', 'mobile3', 'land1', 'land2', 'land3', 'email1', 'email2', 'email3', 'invitation_link']);
        return Excel::download(new GroupExport($subset), 'group_'.$group->name.'_members_'.$date.'_.csv');
    }

    public function enable($id)
    {
        $item = $this->repository->getByID($id);
        $item->enabled = true;
        $item->save();
        return redirect()->back()->with(['Group' => 'Template: '.$item->name.' has been enabled!']);
    }

    public function disable($id)
    {
        $item = $this->repository->getByID($id);
        $item->enabled = false;
        $item->save();
        return redirect()->back()->with(['success' => 'Group: '.$item->name.' has been disabled!']);
    }
}