<?php

namespace App\Http\Controllers;

use App\CustomStyle;
use Illuminate\Http\Request;

class CustomStyleController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('check-profile-completed');
        $this->middleware('sidebar-menu:account');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CustomStyle  $customStyle
     * @return \Illuminate\Http\Response
     */
    public function show(CustomStyle $customStyle)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CustomStyle  $customStyle
     * @return \Illuminate\Contracts\View\Factory|\Illuminate\View\View
     */
    public function edit()
    {
        $customStyle = auth()->user()->company->custom_style;
        return view('yn.modules.account.custom-style', compact('customStyle'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CustomStyle  $customStyle
     * @return \Illuminate\Http\RedirectResponse
     */
    public function update(Request $request, $id)
    {

        $customStyle = CustomStyle::find($id);
        $customStyle->fill($request->all());

        if($request->hasfile('image_file'))
        {
          $file = $request->file('image_file');
          $extension = $file->getClientOriginalExtension(); // getting image extension
          $filename =time().'.'.$extension;
          $file->move('public/assets/images/logos/', $filename);
          $customStyle->logo_path = 'public/assets/images/logos/'.$filename;
        }

        $customStyle->save();

        return back()->with('success', 'Style updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CustomStyle  $customStyle
     * @return \Illuminate\Http\Response
     */
    public function destroy(CustomStyle $customStyle)
    {
        //
    }
}
