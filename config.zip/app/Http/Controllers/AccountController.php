<?php

namespace App\Http\Controllers;

use App\CustomContent;
use App\Repositories\CompanyRepository;
use App\Repositories\CustomContentRepository;
use App\Repositories\MerchantRepository;
use App\Repositories\SubclientRepository;
use Illuminate\Http\Request;
use App\Company;
use App\Subclient;
use Session;


class AccountController extends Controller
{
    protected $companyRepository, $subclientRepository, $customContentRepository, $merchantRepository;

    public function __construct(CompanyRepository $companyRepository, SubclientRepository $subclientRepository,
                                CustomContentRepository $customContentRepository, MerchantRepository $merchantRepository)
    {
        $this->middleware(['auth', 'check-profile-completed']);
        $this->middleware(['redirect-if-subclient-user'])->except(['masterTerms', 'updateMasterTerms']);
        $this->middleware('sidebar-menu:account');
        $this->companyRepository = $companyRepository;
        $this->subclientRepository = $subclientRepository;
        $this->customContentRepository = $customContentRepository;
        $this->merchantRepository = $merchantRepository;
    }

    public function masterTerms()
    {
        try{
            session()->forget('warn-msg');
            if(auth()->user()->isCompanyUser()){
                $company = auth()->user()->company;
            }else{
                $company = auth()->user()->subclient;
            }
            return view('yn.modules.account.terms', compact('company'));
        }
        catch (Exception $e) {
            return redirect()->back();
        }
    }

    public function updateMasterTerms(Request $request)
    {
        try{
            $params = $request->validate($this->companyRepository->masterTermsRules());
            if(auth()->user()->isCompanyUser()){
                auth()->user()->company->update($params);
                $company = auth()->user()->company;
            }else{
                auth()->user()->subclient->update($params);
                $company = auth()->user()->subclient;
            }

            $warning = app('App\Http\Controllers\HomeController')->validationIndex();
            $arr = explode(",",$warning);
            if($arr[0] != ""){
                session()->flash('warn-msg', $warning);
                return view('yn.modules.account.terms', compact('company'));
                //return redirect()->back()->with('warn-msg', $warning);
            }
            else
                session()->flash('success', "Master terms has been updated!");

            return redirect()->back();
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating term');
        }
        
    }

    public function subclient()
    {
        try{
            $parent_ids = $this->subclientRepository->parentIds('subclient2', auth()->user()->company_id);
            $subclients = $this->subclientRepository->subclients(auth()->user()->company_id, false);
            return view('yn.modules.account.subclients', compact('parent_ids', 'subclients'));
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while view this page');
        }
        
    }

    public function validateSubclientStep(Request $request, $step)
    {
        $request->validate($this->subclientRepository->creationValidationRules($step));
        return ['message' => 'success'];
    }

    public function saveSubclient(Request $request)
    {
        try{
            $subclient = $this->subclientRepository->createSubclient($request->validate($this->subclientRepository->creationValidationRules()));
            $message = $this->subclientRepository->getSuccessMessage($subclient);
            return redirect()->back()->with('success', $message);
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating this page');
        }
        
    }

    public function saveSubclientTerm(Request $request)
    {
        try{
            $params = $request->validate($this->subclientRepository->updateTermValidationRules());
            $subclient = $this->subclientRepository->get('id', $params['id']);
            $subclient->update($request->except('id'));
            session()->flash('success', "Terms for " . $subclient->name . " has been updated!");
            return redirect()->back();
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while updating this page');
        }
        
    }

    public function deleteSubclient($id)
    {
        try{
            $item = $this->subclientRepository->getByID($id);
            $this->subclientRepository->delete($id);
            session()->flash('success', "Subclient: " . $item->name . " has been deleted!");
            return redirect()->back();
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while delete subclient');
        }
        
    }

    // Terms and conditions

    public function showTermsConditions($id = null)
    {
        session()->forget('warn-msg');
        $data = null;
        if ($id) {
            $data = $this->customContentRepository->getByID($id);
        }
        $company = auth()->user()->company;
        $subclients = $this->subclientRepository->subclients(auth()->user()->company_id, false);
        $data_list = $this->customContentRepository->getTermsConditions(auth()->user()->company_id);
        return view('yn.modules.account.terms-conditions', compact('data_list', 'subclients', 'company', 'data'));
    }

    public function updateTermsConditions(Request $request)
    {
        try{
            $params = $request->validate($this->customContentRepository->updateTermsConditionsValidationRules());
            $params['content'] = decodeBase64($params['content'], auth()->user()->company_id, "terms", "public/assets/images/termsConditions/");
            $this->customContentRepository->updateTermsConditions(auth()->user()->company, $params);

            $warning = app('App\Http\Controllers\HomeController')->validationIndex();
            $arr = explode(",",$warning);
            if($arr[0] != ""){
                session()->flash('warn-msg', $warning);
                return redirect()->back();
            }                
            else{
                return redirect()->to(route('terms-conditions'))->with('success', 'Terms and conditions updated!');
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while update Terms Conditions');
        }
        
    }

    // Custom content - about and contact page
    public function showCustomContent()
    {
        $data_list = $this->customContentRepository->getCustomContent(auth()->user()->company_id);
        return view('yn.modules.account.custom-content', compact('data_list'));
    }

    public function updateCustomContent(Request $request)
    {
        $params = $request->validate($this->customContentRepository->customContentValidationRules());
        $params['content'] = decodeBase64($params['content'], auth()->user()->company_id, $params['title'], "public/assets/images/customContent/");
        $this->customContentRepository->updateCustomContent($params, auth()->user()->company_id);
        return back()->with('success', 'Custom content updated successfully!');
    }

    public function deleteContent($id)
    {
        $this->customContentRepository->getByID($id)->delete();
        return back()->with('success', 'Content has been deleted!');
    }
}
