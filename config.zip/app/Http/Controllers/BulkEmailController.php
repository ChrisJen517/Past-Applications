<?php

namespace App\Http\Controllers;

use App\Mail\TemplateEmail;
use App\Repositories\BulkEmailRepository;
use App\Repositories\GroupRepository;
use App\Repositories\TemplateRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\View;

class BulkEmailController extends Controller
{
    protected $repository, $templateRepository, $groupRepository;

    public function __construct(BulkEmailRepository $repository, TemplateRepository $templateRepository, GroupRepository $groupRepository)
    {
        $this->middleware(['auth', 'check-profile-completed']);
        $this->middleware('sidebar-menu:communication');
        $this->repository = $repository;
        $this->templateRepository = $templateRepository;
        $this->groupRepository = $groupRepository;
    }

    public function index()
    {
        $bulkEmails = $this->repository->bulkEmails(auth()->user()->company_id);
        return view('bulk-email.index', compact('bulkEmails'));
    }

    public function create()
    {
        try{
            $templates = $this->templateRepository->templates(auth()->user()->company_id, false)->pluck('name', 'id');
            $groups = $this->groupRepository->groups(auth()->user()->company_id, false)->pluck('name', 'id');
            return view('bulk-email.create', compact('templates', 'groups'));
        }
        catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while create!');
        }
    }

    public function store(Request $request)
    {
        try{
            $bulkEmail = $this->repository->create($request->validate($this->repository->creationValidationRules()));
            return redirect()->to(url('bulk-email'));
        }
        catch(Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while update data!');
        }
    }

    public function edit($id)
    {
        try{
            $bulkEmail = $this->repository->get('id', $id);
            $templates = $this->templateRepository->templates(auth()->user()->company_id, false)->pluck('name', 'id');
            $groups = $this->groupRepository->groups(auth()->user()->company_id, false)->pluck('name', 'id');
            return view('bulk-email.edit', compact('bulkEmail', 'templates', 'groups'));
        }
        catch(Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
    }

    public function update($id, Request $request)
    {
        try{
            $params = $request->validate($this->repository->updateValidationRules());
            $this->repository->update('id', $id, $params);
            return redirect()->to('/bulk-email');
        }
        catch(Exception $e){
            return redirect()->back()->with('error-msg', 'There is an error while edit this data!');
        }
    }

    public function delete($id)
    {
        $this->repository->delete($id);
        return redirect()->back();
    }

    public function send($id)
    {
        $this->repository->send($id);
        return redirect()->back();
    }

    public function sendSMS()
    {
        $this->repository->sendSMS();
    }

}
