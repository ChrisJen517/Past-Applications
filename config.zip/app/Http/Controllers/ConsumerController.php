<?php

namespace App\Http\Controllers;

use App\CommunicationHistory;
use App\Consumer;
use App\ConsumerUnsubscription;
use App\Jobs\SendEmailJob;
use App\Mail\ConsumerJoinedEmail;
use App\Mail\ConsumerTermsFlyEmail;
use Illuminate\Http\Request;
use App\Transaction;
use App\ScheduleTransaction;
use App\Template;
use DB;
use Illuminate\Support\Facades\Mail;
use App\Merchant;

class ConsumerController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:consumers');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if (auth()->user()->hasRole('superadmin')) {
            $consumers = Consumer::all();
        } else {
            $consumers = auth()->user()->company->consumers;
        }

        return view('consumers.index', compact('consumers'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param \App\Consumer $consumer
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param \App\Consumer $consumer
     * @return \Illuminate\Http\Response
     */
    public function edit($consumer_id)
    {
        $consumer = Consumer::find($consumer_id);
        return view('consumers.edit')->with('consumer', $consumer);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param \Illuminate\Http\Request $request
     * @param \App\Consumer $consumer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $consumer_id)
    {
        //dd($request->all());
        $consumer = Consumer::findOrFail($consumer_id);

        $consumer->fill($request->all());
        $result = $consumer->save();
        //$consumer->save($request->all());

        return redirect('\consumers')->with('success', 'User updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param \App\Consumer $consumer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Consumer $consumer)
    {
        //
    }

    public function allconsumers(Request $request)
    {

        $columns = array(
            0 => 'first_name',
            1 => 'account_number',
            2 => 'email1',
            3 => 'status',
            4 => 'id',
        );

        $totalData = Consumer::count();
        $totalFiltered = $totalData;

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');


        if (empty($request->input('search.value'))) {
            $consumers = Consumer::offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();
        } else {
            $search = $request->input('search.value');

            $consumers = Consumer::where('first_name', 'LIKE', "%{$search}%")
                ->orWhere('last_name', 'LIKE', "%{$search}%")
                ->orWhere('account_number', 'LIKE', "%{$search}%")
                ->orWhere('email1', 'LIKE', "%{$search}%")
                ->offset($start)
                ->limit($limit)
                ->orderBy($order, $dir)
                ->get();

            $totalFiltered = Consumer::where('first_name', 'LIKE', "%{$search}%")
                ->orWhere('last_name', 'LIKE', "%{$search}%")
                ->orWhere('account_number', 'LIKE', "%{$search}%")
                ->orWhere('email1', 'LIKE', "%{$search}%")
                ->count();
        }

        $data = array();
        if (!empty($consumers)) {
            foreach ($consumers as $row) {
                $edit = route('edit_consumer', $row->id);

                $nestedData['name'] = $row->first_name . " " . $row->last_name;
                $nestedData['account_number'] = $row->account_number;
                $nestedData['email1'] = $row->email1;
                $nestedData['status'] = '<span class="badge badge-success">Active</span>';
                $nestedData['action'] = "&emsp;<a href='{$edit}' title='EDIT' ><i class='nav-icon i-Pen-2 font-weight-bold'></i></a>";
                $data[] = $nestedData;
            }
        }

        $json_data = array(
            "draw" => intval($request->input('draw')),
            "recordsTotal" => intval($totalData),
            "recordsFiltered" => intval($totalFiltered),
            "data" => $data
        );

        echo json_encode($json_data);
    }

    public function termsonfly(Request $request)
    {       
        return view('yn.modules.terms-on-fly');
    }

    public function getMasterTerms(Request $request)
    {
        $user = auth()->user();
        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'account_number',
            1 => 'consumers.id',
            2 => 'company_name',
            3 => 'current_balance',
            4 => 'pif_amount',
            5 => 'psd_amount',
            6 => 'monthly_amount',
            7 => 'max_days_first_pay',
            8 => 'status',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $total_consumers = Consumer::where(function($query){
            if (auth()->user()->isCompanyUser())
                return $query->where('company_id', auth()->user()->company_id);
            elseif (auth()->user()->isSubclient1User()) 
                return $query->where('sub_client1_id', auth()->user()->subclient_id);
            elseif (auth()->user()->isSubclient2User()) 
                return $query->where('sub_client2_id', auth()->user()->subclient_id);
        })->with(['company', 'unsubscription'])
        ->count();

        $consumers = Consumer::where(function($query){
            if (auth()->user()->isCompanyUser())
                return $query->where('company_id', auth()->user()->company_id);
            elseif (auth()->user()->isSubclient1User()) 
                return $query->where('sub_client1_id', auth()->user()->subclient_id);
            elseif (auth()->user()->isSubclient2User()) 
                return $query->where('sub_client2_id', auth()->user()->subclient_id);
        })->with(['company', 'unsubscription'])
        ->whereRaw("concat(account_number, first_name, current_balance) like '%" . $search . "%'")
        ->orderBy($order, $dir)          
        ->limit($request->input("length"))
        ->offset($request->input("start"))    
        ->get();


        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($consumers as $consumer)
        {
            $consumer->company_name = $consumer->getMasterName();
            
            $consumer->currency = $currency;
            $consumer->pif_amount = $consumer->actualPIFamount();
            $consumer->pif = $consumer->actualPIF();
            $consumer->psd_amount = $consumer->actualPSDamount();
            $consumer->psd = $consumer->actualPSD();
            $consumer->monthly_amount = $consumer->actualMonthlyAmount();
            $consumer->monthly_percent = $consumer->actualMonthlyPercent();
            $consumer->max_days_first_pay = $consumer->actualMaxDaysFirstPay();
            $consumer->subscribed = $consumer->subscribed();
            $consumer->url = ($consumer->subscribed() ? url('consumer-unsubscribe',$consumer->id) : url('consumer-subscribe',$consumer->id) );
        }

        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_consumers),
            "recordsFiltered" => intval($total_consumers),
            "data"            => $consumers
            );

        echo json_encode($json_data);        

    }

    public function update_term(Request $request, $consumer_id)
    {
        $consumer = Consumer::find($consumer_id);
        //dd($request->all());
        $consumer->pif_discount_balance = $request->input('pif_discount_balance');
        $consumer->ppa_amount = $request->input('ppa_amount');
        $consumer->min_monthly_pay_amount = $request->input('min_monthly_pay_amount');
        $consumer->max_days_first_pay = $request->input('max_days_first_pay');
        $consumer->save();

        if ($request->get('customer_email') == 'yes') {
            Mail::to($consumer->email1)->send(new ConsumerTermsFlyEmail($consumer));
            // $emailJob = SendEmailJob::dispatch($email, $consumer->email1);
        }

        return redirect('termsonfly')->with('success', 'Your new terms have been applied!');
    }


    public function profileIndex($consumer_id)
    {
        $id = $consumer_id;
        $consumer = Consumer::where('id', $id)->first();
        $schedule = DB::table('schedule_transactions')
            ->join('consumers', 'consumers.id', '=', 'schedule_transactions.consumer_id')
            ->join('payment_profiles', 'schedule_transactions.payment_profile_id', '=', 'payment_profiles.id')
            ->where('schedule_transactions.consumer_id', $id)
            ->where('schedule_transactions.payment_complete', '!=', 1)
            ->select(
                'schedule_transactions.schedule_date',
                'schedule_transactions.schedule_time',
                'payment_profiles.method',
                'schedule_transactions.amount',
                'consumers.account_number',
                'schedule_transactions.id',
                'schedule_transactions.payment_complete'
            )
            ->get();

        $transactions = DB::table('transactions')->where('consumer_id', $id)
            ->join('consumers', 'consumers.id', '=', 'transactions.consumer_id')
            ->where('consumer_id', $id)
            ->select('consumers.first_name', 'consumers.last_name', 'consumers.account_number', 'transactions.transaction_type', 'transactions.id', 'transactions.transaction_id', 'transactions.payment_mode', 'transactions.last4digit', 'transactions.created_at', 'transactions.amount', 'transactions.status')
            ->get();

        $eletters = DB::table('eletters_consumers_map')->where('eletters_consumers_map.consumer_id', $id)
        ->join('eletters', 'eletters_consumers_map.eletters_id', '=', 'eletters.id')
        ->join('groups', 'groups.id', '=', 'eletters.group_id')
        ->select('eletters_consumers_map.created_at', 'eletters_consumers_map.read_by_consumer', 'eletters_consumers_map.enabled', 
        'groups.name', 
        'eletters.id', 'eletters.title', 'eletters.subject', 'eletters.message')
        ->get();

        $communications = CommunicationHistory::with(['consumer', 'group', 'template'])->where('company_id', auth()->user()->company_id)->where('consumer_id', $id)->latest()->get();

        $templates = Template::where('company_id', auth()->user()->company_id)->where('enabled', 1)->whereIn('type', ['email', 'sms'])
            ->select('id', 'name', 'type')->get();

        return view('yn.modules.consumer-profile', [
            'consumer' => $consumer, 'schedule' => $schedule,
            'transactions' => $transactions,
            'communications' => $communications,
            'templates' => $templates,
            'eletters' => $eletters
        ]);
    }

    public function editConsumer(Request $request){
        $validation = [
            'first_name' => 'required',
            'last_name' => 'required',
            'account_number' => 'required',
            'total_balance' => 'required',
            'current_balance' => 'required',
            'dob' => 'required',
        ];

        $consumer = Consumer::find($request->id);

        //only sets mobile or email to required if they are not null
        foreach(['email1', 'mobile1'] as $field){
            if(!empty($consumer->{$field}))
                $validation[$field] = 'required'; 
        }

        $request->validate($validation);

        //validates the email
        if (!filter_var($request->email1, FILTER_VALIDATE_EMAIL) && !empty($request->email1))
            return back()->with('error-msg', 'Please use a valid email.');

        //checks if the account number is used elsewhere within the comapny
        if(Consumer::where('company_id', auth()->user()->company_id)->where('account_number', $request->account_number)->where('id', '!=', $request->id)->exists())
            return back()->with('error-msg', 'That Account Number is currently in use.');

        //updates the balances to be numeric only
        foreach(['total_balance', 'current_balance'] as $balance)
            $request->{$balance} = preg_replace('/[^\\d.]+/', '',$request->{$balance});

        //edits the fields
        foreach(['first_name', 'middle_name', 'last_name', 'account_number', 'total_balance', 'current_balance', 'email1', 'mobile1', 'dob'] as $field)
            $consumer->{$field} = $request->{$field};
        $consumer->save();

        return back()->with('success', 'The consumer has been updated.');
    }

    public function reschedule_failed_payment(Request $request){
        if($request->date < date('Y-m-d'))
            return redirect()->back()->with('error', "You can't reschedule with a date before today");

        $schedule = ScheduleTransaction::where('transaction_id', $request->id)->first();
        
        if($schedule){
            if($schedule->payment_complete == 2){
                $reschedule = new ScheduleTransaction();
                $reschedule->schedule_date = $request->date;
                $reschedule->consumer_id = $schedule->consumer_id;
                $reschedule->company_id = $schedule->company_id;
                $reschedule->sub_client1_id = $schedule->sub_client1_id;
                $reschedule->sub_client2_id = $schedule->sub_client2_id;
                $reschedule->payment_profile_id = $schedule->payment_profile_id;
                $reschedule->status = 'scheduled';
                $reschedule->amount = $schedule->amount;
                $reschedule->processing_charges = $schedule->processing_charges;
                $reschedule->rnn_share = $schedule->rnn_share;
                $reschedule->company_share = $schedule->company_share;
                $reschedule->payment_complete = 0;
                $reschedule->previous_schedule_date = $schedule->schedule_date;
                $reschedule->save();
                
                $remove_transaction = Transaction::where('transaction_id', $request->id)->delete();
                
                return redirect()->back()->with('error', "Your payment is rescheduled, you will get email notification once payment processed");
            }
            else{
                return redirect()->back()->with('error', "You can't reschedule this payment");
            }
        }
        else{
            return redirect()->back()->with('error', "You can't reschedule this payment");
        }
        
    }

    public function joinConsumer(Request $request)
    {
        $consumer = Consumer::where('token', $request->get('token'))->first();
        $password = $consumer->createLogin();
        Mail::to($consumer->email1)->send(new ConsumerJoinedEmail($consumer, $password));
    }

    public function unsubscribe($consumer_id)
    {
        $consumer = Consumer::with(['unsubscription'])->findOrFail($consumer_id);
        if ($consumer->company_id == auth()->user()->company_id) {
            if ($consumer->subscribed()) {
                ConsumerUnsubscription::create([
                    'consumer_id' => $consumer->id, 'company_id' => $consumer->company_id,
                    'email' => $consumer->email1, 'phone' => $consumer->mobile1
                ]);
                return redirect('report/reportUnsubscribe')->with('success', 'Consumer: ' . $consumer->full_name . ' unsubscribed');
            }
            return redirect('report/reportUnsubscribe')->with('success', 'Consumer: ' . $consumer->full_name . ' is already subscribed!');
        } else {
            return redirect('report/reportUnsubscribe')->with('error', 'Consumer is not registered with your company');
        }
    }

    public function subscribe($consumer_id, Request $request)
    {
        $consumer = Consumer::findOrFail($consumer_id);
        if ($consumer->company_id == auth()->user()->company_id) {
            if ($consumer->unSubscribed()) {
                ConsumerUnsubscription::where('consumer_id', $consumer->id)->delete();
                return redirect('home')->with('success', 'Consumer: ' . $consumer->full_name . ' subscribed again');
            }
            return redirect('home')->with('success', 'Consumer: ' . $consumer->full_name . ' is already subscribed!');
        } else {
            return redirect('home')->with('error', 'Consumer is not registered with your company');
        }
    }
}