<?php

namespace App\Http\Controllers;

use App\Company;
use App\Jobs\SendEmailJob;
use App\Repositories\CompanyRepository;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\CustomStyle;
use App\Consumer;
use App\ConsumerNegotiation;
use App\ScheduleTransaction;
use App\PaymentProfile;
use DB;
use Carbon\Carbon;
use App\Services\PayUService\Exception;
use App\Repositories\CommunicationRepository;
use Mail;
use App\Mail\CancelScheduleMailConsumer;
use App\Mail\CancelScheduleMailCreditor;

class ConsumerOfferController extends Controller
{
    protected $communicationRepository;

    public function __construct(CommunicationRepository $communicationRepository)
    {
        $this->communicationRepository = $communicationRepository;
    }


    // Customer offers
    public function customerOffers(Request $request)
    {
        $consumers = Consumer::with(['company', 'paymentProfile'])
                    ->where('consumers.company_id', auth()->user()->company->id)->limit(1)->get();
        return view('yn.modules.customer-offers', compact('consumers'));
    }

    public function getConsumerTable(Request $request){

        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'consumers.account_number',
            1 => 'consumers.first_name',
            2 => 'consumers.current_balance',
            3 => 'placement_date',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $total_consumers = Consumer::with(['company', 'paymentProfile'])->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
                    ->when(auth()->user()->user_type == 'Subclient2', function($query){
                        return $query->where('consumers.sub_client2_id', auth()->user()->subclient_id);
                    })
                    ->when(auth()->user()->user_type == 'Subclient1', function($query){
                        return $query->where('consumers.sub_client1_id', auth()->user()->subclient_id);
                    })
                    ->where('consumer_negotiations.company_id', auth()->user()->company->id)
                    ->whereIn('consumers.status', ['payment_setup'])
                    ->where('consumers.custom_offer', 1)
                    ->where('active_negotiation', 1)->count();

        $filtered_consumers = Consumer::with(['company', 'paymentProfile'])
                ->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
                ->when(auth()->user()->user_type == 'Subclient2', function($query){
                    return $query->where('consumers.sub_client2_id', auth()->user()->subclient_id);
                })
                ->when(auth()->user()->user_type == 'Subclient1', function($query){
                    return $query->where('consumers.sub_client1_id', auth()->user()->subclient_id);
                })
                ->where('consumer_negotiations.company_id', auth()->user()->company->id)
                ->whereRaw("concat(consumers.account_number, consumers.first_name, consumers.current_balance, consumers.last_name ) like '%" . $search . "%'")
                ->whereIn('consumers.status', ['payment_setup'])
                ->where('consumers.custom_offer', 1)
                ->where('active_negotiation', 1)->count();

        $consumers = Consumer::with(['company', 'paymentProfile'])->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
                    ->when(auth()->user()->user_type == 'Subclient2', function($query){
                        return $query->where('consumers.sub_client2_id', auth()->user()->subclient_id);
                    })
                    ->when(auth()->user()->user_type == 'Subclient1', function($query){
                        return $query->where('consumers.sub_client1_id', auth()->user()->subclient_id);
                    })
                    ->where('consumer_negotiations.company_id', auth()->user()->company->id)
                    ->whereIn('consumers.status', ['payment_setup'])
                    ->where('consumers.custom_offer', 1)
                    ->where('active_negotiation', 1)
                    ->whereRaw("concat(consumers.account_number, consumers.first_name) like '%" . $search . "%'")
                    ->select('consumers.*',
                        'consumer_negotiations.negotiation_type',
                        'consumer_negotiations.negotiate_amount',
                        'consumer_negotiations.monthly_amount',
                        'consumer_negotiations.no_of_installments',
                        'consumer_negotiations.last_month_amount',
                        'consumer_negotiations.installment_type',
                        'consumer_negotiations.first_pay_date',
                        'consumer_negotiations.one_time_settlement',
                        'consumer_negotiations.communication_type',
                        'consumer_negotiations.email',
                        'consumer_negotiations.phone',
                        'consumer_negotiations.reason',
                        'consumer_negotiations.note',
                        'consumer_negotiations.counter_note',
                        'consumer_negotiations.active_negotiation',
                        'consumer_negotiations.created_at', 'counter_monthly_amount',
                        'counter_one_time_amount', 'counter_first_pay_date', 'counter_negotiate_amount')
                    ->whereRaw("concat(consumers.account_number, consumers.first_name, consumers.current_balance, consumers.last_name ) like '%" . $search . "%'")
                    ->orderBy($order, $dir)          
                    ->limit($request->input("length"))
                    ->offset($request->input("start"))
                    ->get();

                    // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($consumers as $consumer)
        {
            $consumer->company_name = $consumer->getMasterName();
            $consumer->actual_psd_amount = formatAmount($consumer->actualPSDamount(), $currency, 2);
            $consumer->actual_monthly_amount = formatAmount($consumer->actualMonthlyAmount(), $currency, 2);
            $consumer->actual_pif_amount = formatAmount($consumer->actualPIFamount(), $currency, 2);
            $consumer->max_days_first_pay = now()->addDays($consumer->actualMaxDaysFirstPay())->format('Y-m-d');
            $consumer->counter_first_pay_date = date('Y-m-d', strtotime($consumer->counter_first_pay_date));
            $consumer->first_pay_date = date('Y-m-d', strtotime($consumer->first_pay_date));
            $consumer->current_balance = formatAmount($consumer->current_balance, $currency, 2);
            $consumer->account_open_date = $consumer->account_open_date?date('Y-m-d', strtotime($consumer->account_open_date)):"-";
            $consumer->updated_at = strtotime($consumer->consumerNegotiation()['updated_at']);
            $consumer->payment_profile = ($consumer->paymentProfile ? true : false);
            $consumer->placement_date_formated = date('Y-m-d', strtotime($consumer->placement_date));
            $consumer->negotiate_amount = formatAmount($consumer->negotiate_amount, $currency, 2);
            $consumer->monthly_amount = formatAmount($consumer->monthly_amount, $currency, 2);

            if($consumer->sub_client2_id) {
                $consumer->sub_client = 2;
                $consumer->subclient_name = $consumer->subclient2->subclient_name;
                $consumer->account_contact_email = $consumer->subclient2->account_contact_email;
                $consumer->account_contact_phone = $consumer->subclient2->account_contact_phone;
            } else if($consumer->sub_client1_id){
                $consumer->sub_client = 1;
                $consumer->subclient_name = $consumer->subclient1->subclient_name;
                $consumer->account_contact_email = $consumer->subclient1->account_contact_email;
                $consumer->account_contact_phone = $consumer->subclient1->account_contact_phone;
            } else {
                $consumer->sub_client = 0;
                $consumer->subclient_name = "";
                $consumer->account_contact_email = "";
                $consumer->account_contact_phone = "";
            }
        }

        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_consumers),
            "recordsFiltered" => intval($filtered_consumers),
            "data"            => $consumers
            );

        echo json_encode($json_data);
    }

    public function getNegotiatedTable(Request $request){
        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'consumers.account_number',
            1 => 'consumers.first_name',
            3 => 'consumers.current_balance',
            4 => 'placement_date',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        $offer_accepted_count = Consumer::join('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
            ->where('consumer_negotiations.company_id', auth()->user()->company->id)
            ->where('active_negotiation', 1)
            ->whereRaw('(consumer_negotiations.offer_accepted IN (1, 2) OR consumer_negotiations.counter_offer_accepted IN (1, 2))')
            ->count();

        $filtered_offer_accepted_count = Consumer::join('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
            ->where('consumer_negotiations.company_id', auth()->user()->company->id)
            ->where('active_negotiation', 1)
            ->whereRaw('(consumer_negotiations.offer_accepted IN (1, 2) OR consumer_negotiations.counter_offer_accepted IN (1, 2))')
            ->when($search, function($query, $search){
                return $query->whereRaw("concat(consumers.account_number, consumers.first_name, consumers.current_balance, consumers.last_name ) like '%" . $search . "%'");
            })->count();

        $pending_payment_setups = Consumer::
            selectRaw('consumers.*, 
                "" as negotiation_term,
                "" as one_time_settlement, 
                "" as first_pay_date,
                "" as negotiation_type,
                "" as approved_by,
                "" as monthly_amount,
                "" as last_month_amount,
                "" as no_of_installments,
                "" as completed_on,
                consumer_negotiations.created_at as negotiation_date
            ')
            ->join('consumer_negotiations', 'consumer_negotiations.consumer_id', 'consumers.id')
            ->where('consumers.company_id', $user->company->id)
            ->where('active_negotiation', 1)
            ->whereRaw('(consumer_negotiations.offer_accepted IN (1, 2) OR consumer_negotiations.counter_offer_accepted IN (1, 2))')
            ->when($search, function($query, $search){
                return $query->whereRaw("concat(consumers.account_number, consumers.first_name, consumers.current_balance, consumers.last_name ) like '%" . $search . "%'");
            })
            ->orderBy($order, $dir)          
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();

        // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($pending_payment_setups as $pending_payment_setup)
        {
            $pending_payment_setup->company_name = $pending_payment_setup->getMasterName();
            $pending_payment_setup->current_balance = formatAmount($pending_payment_setup->current_balance, $currency, 2);
            $pending_payment_setup->negotiation_date = date('Y-m-d', strtotime($pending_payment_setup->negotiation_date));
            
            if($pending_payment_setup->status != 'payment_accepted')
                continue;

            $consumerNegotiation = $pending_payment_setup->consumerNegotiation();
            $pending_payment_setup->negotiation_type = $consumerNegotiation->negotiation_type;
            $pending_payment_setup->completed_on = date('Y-m-d', strtotime($consumerNegotiation->updated_at));

            if($consumerNegotiation['offer_accepted']){
                $pending_payment_setup->approved_by = "Auto Approve";
                $pending_payment_setup->first_pay_date = date('Y-m-d', strtotime($pending_payment_setup->first_pay_date));

                if($consumerNegotiation->negotiation_type == 'pif'){
                    $pending_payment_setup->negotiation_term = "Discounted Payoff Plan";
                    $pending_payment_setup->one_time_settlement = formatAmount($consumerNegotiation->one_time_settlement, $currency, 2);
                }
                else{
                    $pending_payment_setup->negotiation_term = "Discounted Payment Plan";

                    $pending_payment_setup->no_of_installments = $consumerNegotiation->no_of_installments;
                    $pending_payment_setup->monthly_amount = formatAmount($consumerNegotiation->monthly_amount, $currency, 2);
                    if($consumerNegotiation->last_month_amount)
                        $pending_payment_setup->last_month_amount = "& 1 Last Payment of ".formatAmount($consumerNegotiation->last_month_amount, $currency, 2);
                }
            }
            else{
                $pending_payment_setup->approved_by = $pending_payment_setup->first_name." ".$pending_payment_setup->last_name;
                $pending_payment_setup->first_pay_date = date('Y-m-d', strtotime($pending_payment_setup->counter_first_pay_date));

                if($consumerNegotiation->negotiation_type == 'pif'){
                    $pending_payment_setup->negotiation_term = "Discounted Counter PayOff Plan";
                    $pending_payment_setup->one_time_settlement = formatAmount($consumerNegotiation->counter_one_time_settlement, $currency, 2);
                }
                else{ 
                    $pending_payment_setup->negotiation_term = "Discounted Counter Payment Plan";

                    $pending_payment_setup->no_of_installments = $consumerNegotiation->no_of_installments;
                    $pending_payment_setup->monthly_amount = formatAmount($consumerNegotiation->monthly_amount, $currency, 2);
                    if($consumerNegotiation->last_month_amount)
                        $pending_payment_setup->last_month_amount = "& 1 Last Payment of ".formatAmount($consumerNegotiation->last_month_amount, $currency, 2);
                }
            }
        }

        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($offer_accepted_count),
            "recordsFiltered" => intval($filtered_offer_accepted_count),
            "data"            => $pending_payment_setups
            );

        echo json_encode($json_data);
    }

    //accept consumer payment
    public function acceptPayment($consumer_id)
    {
        try {
            $consumer = Consumer::find($consumer_id);
            $consumerNegotiation = ConsumerNegotiation::where('consumer_id', $consumer_id)->where('active_negotiation', 1)->get()->first();
            $paymentProfile = PaymentProfile::where('consumer_id', $consumer->id)->first();

            $select_merchant = $consumer->getMerchant();

            $scheduled = ScheduleTransaction::where('consumer_id', $consumer->id)->get();

            if ($consumerNegotiation->negotiation_type == 'pif') {
                $installment_amount = $consumerNegotiation->one_time_settlement;

                $rnn_share = $installment_amount * $consumer->company->rnn_share / 100;
                $rnn_share = number_format((float)$rnn_share, 2, '.', '');
                $company_share = $installment_amount - $rnn_share;

                $p_charges = 0;
                if($select_merchant->processing_charge_percentage || $select_merchant->processing_charge_amount){
                    $p_charges = $select_merchant->processing_charge($installment_amount);
                }

                if(count($scheduled) == 0){
                    ScheduleTransaction::create([
                        'consumer_id' => $consumer->id,
                        //'consumer_login_id' => '',
                        'company_id' => $consumer->company->id,
                        'schedule_date' => date('Y-m-d', strtotime($consumerNegotiation->first_pay_date)),
                        'payment_profile_id' => $paymentProfile ? $paymentProfile->id : null,
                        'status' => "scheduled",
                        'status_code' => '111',
                        'amount' => $installment_amount,
                        'transaction_type' => $consumerNegotiation->negotiation_type,
                        'processing_charges' => $p_charges,
                        'flat_transaction_charges' => "",
                        'rnn_share' => $rnn_share,
                        'company_share' => $company_share,
                        //'subclient1_share' => $subclient1_share,
                        //'subclient2_share' => $subclient2_share,
                        'schedule_time' => date("H:i:s", strtotime("+30 minutes")),
                    ]);
                }

                
            } elseif ($consumerNegotiation->negotiation_type == 'installment') {

                $no_of_installments = $consumerNegotiation->no_of_installments;
                $last_installment = $consumerNegotiation->last_month_amount;
                $firstdate_payment = $consumerNegotiation->first_pay_date;
                $installment_amount = $consumerNegotiation->monthly_amount;
                $frequency = $consumerNegotiation->installment_type;

                for ($i = 0; $i < $no_of_installments; $i++) {

                    $installments[$i]['date'] = $firstdate_payment;
                    $installments[$i]['amount'] = $installment_amount;

                    $p_charges = 0;
                    if($select_merchant->processing_charge_percentage || $select_merchant->processing_charge_amount){
                        $p_charges = $select_merchant->processing_charge($installment_amount);
                    }
                    $installments[$i]['p_charges'] = $p_charges;

                    if ($frequency == 'weekly') {
                        $firstdate_payment = date('M d, Y', strtotime($firstdate_payment . ' + 1 week'));
                    } elseif ($frequency == 'bimonthly') {
                        $firstdate_payment = date('M d, Y', strtotime($firstdate_payment . ' + 2 week'));
                    } elseif ($frequency == 'monthly') {
                        $firstdate_payment = date('M d, Y', strtotime($firstdate_payment . ' + 1 month'));
                    }
                }

                if ($last_installment > 0) {
                    $installments[$i]['date'] = $firstdate_payment;
                    $installments[$i]['amount'] = $last_installment;

                    $p_charges = 0;
                    if($select_merchant->processing_charge_percentage || $select_merchant->processing_charge_amount){
                        $p_charges = $select_merchant->processing_charge($last_installment);
                    }
                    $installments[$i]['p_charges'] = $p_charges;
                }

                if(count($scheduled) == 0){

                    foreach ($installments as $installment) {

                        $installment_amount = $installment['amount'];
                        $installment_date = $installment['date'];
                        $p_charges = $installment['p_charges'];

                        $rnn_share = $installment_amount * $consumer->company->rnn_share / 100;
                        $rnn_share = number_format((float)$rnn_share, 2, '.', '');
                        $company_share = $installment_amount - $rnn_share;

                        ScheduleTransaction::create([
                            'consumer_id' => $consumer->id,
                            //'consumer_login_id' => '',
                            'company_id' => $consumer->company->id,
                            'schedule_date' => date('Y-m-d', strtotime($installment_date)),
                            'payment_profile_id' => $paymentProfile ? $paymentProfile->id : null,
                            'status' => "scheduled",
                            'status_code' => '111',
                            'amount' => $installment_amount,
                            'processing_charges' => $p_charges,
                            'flat_transaction_charges' => "",
                            'rnn_share' => $rnn_share,
                            'company_share' => $company_share,
                            //'subclient1_share' => $subclient1_share,
                            //'subclient2_share' => $subclient2_share,
                        ]);
                    }
                }
            }

            //$consumerNegotiation->active_negotiation = 0;
            $consumerNegotiation->offer_accepted = 1;
            $consumerNegotiation->approved_by = auth()->user()->name;
            $consumerNegotiation->save();

            $consumer->status = 'payment_accepted';
            $consumer->offer_accepted = 1;
            $consumer->save();

            $name = $consumer->getFullNameAttribute();

            $this->communicationRepository->sendAcceptOfferEmail($consumer);
            return redirect()->back()->with('success', 'Negotiation Accepted for ' . $name);
        } catch (\Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while accept this payment!');
        }

    }

    //submit conter offer
    public function submitConterOffer(Request $request, $consumer_id)
    {
        try{
            $consumerNegotiation = ConsumerNegotiation::where('consumer_id', $consumer_id)->where('active_negotiation', 1)->get()->first();
            if ($consumerNegotiation) {

                $negotiate_amount = $request->input('counter_ppa_amount');
                $monthly_amount = $request->input('counter_monthly_amount');
                $no_of_installments = intval($negotiate_amount / $monthly_amount);

                if (($no_of_installments * $monthly_amount) > $negotiate_amount) {
                    $no_of_installments = $no_of_installments - 1;
                }

                $last_installment = $negotiate_amount - ($monthly_amount * $no_of_installments);
                // if($last_installment != 0){
                //     $no_of_installments = $no_of_installments + 1;
                // }

                $consumerNegotiation->counter_monthly_amount = $request->input('counter_monthly_amount');
                $consumerNegotiation->counter_first_pay_date = $request->input('counter_first_pay_date');
                $consumerNegotiation->counter_one_time_amount = $request->input('counter_pif_amount');
                $consumerNegotiation->counter_negotiate_amount = $request->input('counter_ppa_amount');
                $consumerNegotiation->counter_note = $request->input('counter_note');
                $consumerNegotiation->counter_last_month_amount = $last_installment ? $last_installment : 0;
                $consumerNegotiation->counter_no_of_installments = $no_of_installments;
                $consumerNegotiation->save();

                $consumer = Consumer::find($consumer_id);
                $consumer->counter_offer = 1;
                $consumer->save();

                $this->communicationRepository->sendCounterOfferEmail($consumer);

                $name = $consumer->first_name . " " . $consumer->last_name;
                return Redirect()->back()->with('success', 'Counter offer placed for ' . $name);
            }
            else{
                return redirect()->back()->with('error-msg', 'There is no active negotiation present for this consumer!');
            }
        } catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while counter this offer!');
        }
        

    }

    //decline consumer payment
    public function declinePayment($consumer_id)
    {

        $consumer = Consumer::find($consumer_id);


        $consumerNegotiation = ConsumerNegotiation::where('consumer_id', $consumer_id)->where('active_negotiation', 1)->first();
        if ($consumerNegotiation) {
            $consumerNegotiation->offer_accepted = 2;
            $consumerNegotiation->save();

            $consumer->status = 'payment_declined';
            $consumer->save();

            $this->communicationRepository->sendDeclineOfferEmail($consumer);
        }


        $name = $consumer->first_name . " " . $consumer->last_name;
        return Redirect()->back()->with('success', 'Counter offer declined for ' . $name);
    }

    //reschedule payment
    public function reschedulePayment(Request $request)
    {
        try{
            $date = $request->input('newdate');

            if ($date <= Carbon::now()) {
                return redirect()->back()->with('error-msg', 'You can not update past date');
            }

            // $time = $request->input('newtime'); //new time field

            $schedule_id = $request->input('schedule_id');
            $existingSchedule = ScheduleTransaction::find($schedule_id);

            if ($existingSchedule) {
                $existingSchedule->previous_schedule_date = $existingSchedule->schedule_date;
                $existingSchedule->schedule_date = date('Y-m-d', strtotime($date));
                // $existingSchedule->schedule_time = $time;
                $existingSchedule->save();
            }

            $consumer = Consumer::find($existingSchedule->consumer_id);
            $name = $consumer->first_name . " " . $consumer->last_name;
            return redirect()->back()->with('success', 'Schedule updated for ' . $name);
        }
        catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while reschedule this payment!');
        }
        
    }

    //Cancel Schedule
    public function cancelSchedule($id)
    {
        try{
            ScheduleTransaction::where('id', $id)->update(['payment_complete' => '2']);
            $scheduledTransaction = ScheduleTransaction::with('consumer.company')->where('id', $id)->where(['payment_complete' => '2'])->first();
            if($scheduledTransaction){
                if($scheduledTransaction->consumer){
                    SendEmailJob::dispatch(new CancelScheduleMailConsumer($scheduledTransaction), $scheduledTransaction->consumer->email1);
                    SendEmailJob::dispatch(new CancelScheduleMailCreditor($scheduledTransaction), $scheduledTransaction->consumer->company->account_contact_email);
                    return redirect()->back()->with('success', 'Schedule has been canceled');
                }
            }
            return redirect()->back()->with('success', 'Schedule has been canceled');
        }
        catch (Exception $e) {
            return redirect()->back()->with('error-msg', 'There is an error while cancel this payment!');
        }
    }
}