<?php

namespace App\Http\Controllers;

use App\Consumer;
use App\ConsumerAccount;
use App\CsvData;
use App\CsvHeader;
use App\FileUploadHistory;
use App\Jobs\RunArtisanCommandJob;
use App\Subclient;
use App\ConsumerNegotiation;
use App\ConsumerActivity;
use App\PaymentProfile;

use App\Http\Requests\CsvImportRequest;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Artisan;
use Maatwebsite\Excel\Facades\Excel;
use Maatwebsite\Excel\HeadingRowImport;
use App\Imports\CsvDataImport;
use DB;
use League\Flysystem\Filesystem;
use League\Flysystem\Sftp\SftpAdapter;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use Carbon\Carbon;
use App\Jobs\ImportConsumerJob;
use Exception;
use Illuminate\Auth\Events\Failed;
use App\SFTPImport;
use Auth;
use App\ImportSettings;
use App\User;

class ImportController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('sidebar-menu:consumers');
    }

    public function getImport()
    {

        if (auth()->user()->isCompanyUser()) {
            $header = DB::table('csv_headers')->where('company_id', auth()->user()->company_id)->first();
            $csvHeaders = CsvHeader::where('company_id', auth()->user()->company->id)->get();
        } elseif (auth()->user()->isSubclient1User()) {
            $header = DB::table('csv_headers')->where('subclient_id', auth()->user()->subclient_id)->first();
            $csvHeaders = CsvHeader::where('subclient_id', auth()->user()->subclient_id)->get();
        } elseif (auth()->user()->isSubclient2User()) {
            $header = DB::table('csv_headers')->where('subclient_id', auth()->user()->subclient_id)->first();
            $csvHeaders = CsvHeader::where('subclient_id', auth()->user()->subclient_id)->get();
        }

        if (isset($header)) {
            $data = json_decode($header->saved_headers);
        } else {
            $data = Null;
        }

        return view('import.import', ['header' => $header, 'data' => $data, 'csvHeaders' => $csvHeaders]);

    }

    public function parseImport(CsvImportRequest $request)
    {
        try{
            $user = auth()->user();
            $mimes = array('csv');
            $extension = pathinfo($request->file('csv_file')->getClientOriginalName(), PATHINFO_EXTENSION);
            $name = $request->input('name');
            if (in_array($extension, $mimes)) {
                $path = $request->file('csv_file')->getRealPath();
                if ($request->has('header')) {
                    $data = (new HeadingRowImport)->toArray(request()->file('csv_file'));
                } else {
                    $data = array_map('str_getcsv', file($path));
                }
                if (count($data[0]) > 0) {
                    if ($request->has('header')) {
                        $csv_header_fields = [];
                        foreach ($data[0] as $key => $value) {
                            $csv_header_fields[] = $key;
                        }
                    }
                    //$csv_data = $data[0];
                    $csv_data = array_slice($data[0], 0, 1);
                    $header = $data[0][0];

                    if (isset($header[0])) {

                        if ($user->isCompanyUser()) {
                            $csv_data_file = CsvData::create([
                                'company_id' => auth()->user()->company_id,
                                'csv_filename' => $request->file('csv_file')->getClientOriginalName(),
                                'csv_header' => json_encode($header),
                                'csv_data' => json_encode($data[0])
                            ]);
                        } else {
                            $csv_data_file = CsvData::create([
                                'company_id' => auth()->user()->company_id,
                                'subclient_id' => auth()->user()->subclient_id,
                                'csv_filename' => $request->file('csv_file')->getClientOriginalName(),
                                'csv_header' => json_encode($header),
                                'csv_data' => json_encode($data[0])
                            ]);
                        }

                        $lastInsertedId = $csv_data_file->id;

                    } else {
                        return redirect()->back()->with('error-msg', 'First Column of your CSV file is Blank, Unable to Map your Headers');
                    }


                } else {
                    return redirect()->back();
                }

                return view('import.import_fields', compact('csv_header_fields', 'csv_data', 'csv_data_file', 'lastInsertedId', 'name'));
            } else {
                return redirect()->back()->with('error-msg', 'Please upload CSV formatted file');
            }
        }
        catch (\Throwable $e) {
            //Log::channel('daily')->error($e);
            return redirect()->back()->with('error-msg', 'Please upload correct CSV formatted file');
        }

    }


    //save mapped headers
    public function saveImportHeaders(Request $request)
    {
        $user = auth()->user();
        $name = $request->input('name');

        if ($user->isCompanyUser()) {

            $csvHeader = CsvHeader::where('company_id', auth()->user()->company->id)->where('name', $name)->get()->first();

            if (!$csvHeader) {
                $fields = $request->input('fields');

                $fields = array_flip($fields);
                unset($fields['Select']);
                //dd($fields);

                $csv_header_data = new CsvHeader();
                $csv_header_data->company_id = auth()->user()->company_id;
                $csv_header_data->saved_headers = json_encode($fields);
                $csv_header_data->name = $request->input('name');
                $csv_header_data->save();
            } else {
                $fields = $request->input('fields');

                $fields = array_flip($fields);
                unset($fields['Select']);
                //dd($fields);

                $csvHeader->saved_headers = json_encode($fields);
                $csvHeader->save();
            }

        } else {

            $csvHeader = CsvHeader::where('subclient_id', auth()->user()->subclient_id)->where('name', $name)->get()->first();

            if (!$csvHeader) {
                $fields = $request->input('fields');
                $fields = array_flip($fields);

                $csv_header_data = new CsvHeader();
                $csv_header_data->company_id = auth()->user()->company_id;
                $csv_header_data->subclient_id = auth()->user()->subclient_id;
                $csv_header_data->saved_headers = json_encode($fields);
                $csv_header_data->name = $request->input('name');
                $csv_header_data->save();
            } else {
                $fields = $request->input('fields');
                $fields = array_flip($fields);

                $csvHeader->saved_headers = json_encode($fields);
                $csvHeader->save();
            }
        }

        // Check if any steps are not completed
        $warning = app('App\Http\Controllers\HomeController')->validationIndex();

        $arr = explode(",", $warning);
        if (count($arr) != 0) {
            session()->flash('warn-msg', $warning);
        }

        //return redirect('/import/csvData')->with('success-msg', 'Thank you! YouNegotiate has saved your File Layout Profile! All you need to do now is upload files!');
        return json_encode($csvHeader);

    }

    public function deleteImportHeader($id)
    {
        try{
            $csv_header_data = CsvHeader::where('id', $id)->where('company_id', auth()->user()->company->id);
            $csv_header_data->delete();
            session()->flash('success', "Header deleted!");
            return redirect()->back();
        } catch (\Throwable $e) {
            return redirect()->back()->with('error-msg', 'Error while deleting header, if this continues please contact support.');
        }

    }

    //Show uploaded files
    public function csvData()
    {
        session()->forget('warn-msg');
        $user = auth()->user();
        if ($user->isCompanyUser()) {
            $fileUploadHistory = FileUploadHistory::where('company_id', auth()->user()->company->id)
                ->orderBy('created_at', 'DESC')->get();
            $uploadHeaders = CsvHeader::where('company_id', auth()->user()->company->id)->select('id', 'name', 'saved_headers')->orderBy('name', 'DESC')->get();
        } else if ($user->isSubclient1User()) {
            $fileUploadHistory = FileUploadHistory::where('subclient_id', auth()->user()->subclient_id)->orderBy('created_at', 'DESC')->get();
            $uploadHeaders = CsvHeader::where('subclient_id', auth()->user()->subclient_id)->select('id', 'name', 'saved_headers')->orderBy('name', 'DESC')->get();
        } else if ($user->isSubclient2User()) {
            $fileUploadHistory = FileUploadHistory::where('subclient_id', auth()->user()->subclient_id)->orderBy('created_at', 'DESC')->get();
            $uploadHeaders = CsvHeader::where('subclient_id', auth()->user()->subclient_id)->select('id', 'name', 'saved_headers')->orderBy('name', 'DESC')->get();
        }

        return view('import.upload', compact('fileUploadHistory', 'uploadHeaders'));
    }

    //Import Consumers
    public function uploadCsvData(CsvImportRequest $request)
    {

        $mimes = array('csv');
        $extension = pathinfo($request->file('csv_file')->getClientOriginalName(), PATHINFO_EXTENSION);
        $header_id = $request->input('upload_header');
        
        if (in_array($extension, $mimes)) {

            // Validation Check For Import Excel data  (11-06-2020)
            $personalized = DB::table('personalized_logos')->where('company_id', auth()->user()->company_id)->count();
            $marchent = DB::table('merchants')->where('company_id', auth()->user()->company_id)->count();
            $csv_headers = DB::table('csv_headers')->where('company_id', auth()->user()->company_id)->count();

            if ($personalized == 0 && $marchent = 0 && $csv_headers == 0) {
                return redirect()->back()->with('error-msg', 'Your personalized url,merchant data,header map are  not set !!');
            }
            if ($personalized == 0 && $marchent == 0) {
                return redirect()->back()->with('error-msg', 'Your personalized url,merchant data are not set !!');
            }
            if ($csv_headers == 0 && $marchent == 0) {
                return redirect()->back()->with('error-msg', 'Your  header map and merchant data are not set !!');
            }
            if ($csv_headers == 0 && $personalized == 0) {
                return redirect()->back()->with('error-msg', 'Your personalized url and header map are not set !!');
            }
            if ($personalized == 0) {
                return redirect()->back()->with('error-msg', 'Your personalized url is not set !! ');
            }
            if ($marchent == 0) {
                return redirect()->back()->with('error-msg', 'Your merchant data is not set !! ');
            }
            if ($csv_headers == 0) {
                return redirect()->back()->with('error-msg', 'Your header map is not set !! ');
            }
            //End validation code
            $user = auth()->user();
            $user_id = $user->id;
            $upload_type = $request->input('temptype');
            $filename = date('YmdHis') . $request->file('csv_file')->getClientOriginalName();
            $filename = str_replace(' ', '_', $filename);
            Storage::disk('protected')->put("imports/" . $filename, file_get_contents($request->file('csv_file')));

            $data = Excel::toArray(new CsvDataImport, storage_path('app/protected/imports/' . $filename));
            $num_of_records = count($data[0]) - 1;

            $fileUploadHistory = FileUploadHistory::create([
                'uploaded_by' => $user->name,
                'company_id' => $user->company_id,
                'subclient_id' => $user->subclient_id,
                'filename' => $filename,
                'type' => $upload_type,
                'num_of_records' => $num_of_records,
                'status' => 'Validating'
            ]);

            $fuh_id = $fileUploadHistory->id;

            if (count($data[0]) > 0) {
                if ($user->isCompanyUser()) {
                    $saved_header = CsvHeader::where('company_id', $user->company->id)->where('id', $header_id)->first();
                } else {
                    $saved_header = CsvHeader::where('subclient_id', $user->subclient_id)->where('id', $header_id)->first();
                }
                $db_headers = json_decode($saved_header->saved_headers);
                $name = $saved_header->name;

                //Log::channel('import_consumer_command')->info("User ID: ".$user_id." Db headers -> ".(string)($db_headers) );

                $csv_data = array_slice($data[0], 1, count($data[0]));
                $header = $data[0][0];

                $marge_header = [];
                $unmarged_header = [];
                $send_headers = [];
                foreach ($db_headers as $db_key => $db_value) {
                    $send_headers[$db_value] = $db_key;

                    if (in_array($db_key, $header)) {
                        foreach ($header as $key => $value) {
                            if ($db_key == $value) {
                                $marge_header[$key] = $db_value;
                            }
                        }
                    } else {
                        $unmarged_header[] = $db_key;
                    }
                }

                //dd($header);

                if (count($unmarged_header) > 0) {
                    $fileUploadHistory->delete();
                    $csv_data = $data[0];
                    return view('import.import_fields', compact('csv_data','header','send_headers', 'unmarged_header', 'name'));

                } else {

                    Artisan::queue("import:yn-consumers $filename $user_id $upload_type $fuh_id $saved_header->id")->onQueue('import');
                }
            }
            

            return redirect()->back()->with('success', 'Your CSV file is being processed in the background! Please make sure your Header mapped correctly to complete validation! ');
        } else {
            return redirect()->back()->with('error-msg', 'Please upload CSV formatted file');
        }

    }

    public function download($filename)
    {
        $fuh = FileUploadHistory::where('company_id', auth()->user()->company_id)
            ->where('filename', $filename)->first();
        if ($fuh == null) {
            return abort(404, 'The file you are looking for is not available!');
        }
        return response()->download(storage_path('app/protected/imports/' . $filename));
    }

    public
    function processImport(Request $request)
    {
        //$data = CsvData::find($request->csv_data_file_id);
        $data = DB::table('csv_data')->orderBy('id', 'DESC')->first();
        $csv_data = json_decode($data->csv_data, true);
        $csv_data = array_slice($csv_data, 1, count($csv_data));
        foreach ($csv_data as $row) {
            //dd($request->get('fields'));
            $consumer = new Consumer();
            foreach ($request->get('fields') as $index => $field) {
                if ($field != 'Select') {
                    $consumer->$field = $row[$index]; //$row
                }
            }
            $consumer->company_id = auth()->user()->company->id;
            $consumer->save();
        }
        return view('import.import')->with('success', 'Imported Successfully');
    }

    public
    function sftpSettings()
    {
        $user = auth()->user();
        if ($user->user_type == "company")
            $sftp = SFTPImport::where('company_id', $user->company_id)->where('subclient_id', null)->get();
        if ($user->user_type == "subclient")
            $sftp = SFTPImport::where('subclient_id', $user->subclient_id)->get();

        return view('import.sftp_settings', compact('sftp'));
    }

    public
    function addSftpSettings(Request $request)
    {

        $user = auth()->user();

        $sftp = new SFTPImport();
        $sftp->host = $request["host"];
        $sftp->username = $request["username"];
        $sftp->password = $request["password"];
        $sftp->keyfile = $request["key"];
        $sftp->port = $request["port"];
        $sftp->root = $request["path"];
        $sftp->type = $request["temptype"];
        $sftp->pause = 0;
        $sftp->company_id = $user->company_id;
        if ($user->user_type == "subclient")
            $sftp->subclient_id = $user->subclient_id;
        $sftp->save();

        return redirect()->back()->with('success', 'Your sftp details added!');
    }


    public
    function updateSftpSettings(Request $request)
    {

        $user = auth()->user();

        $sftp = SFTPImport::where('id', $request["id"])->first();
        $sftp->host = $request["host"];
        $sftp->username = $request["username"];
        $sftp->password = $request["password"];
        $sftp->keyfile = $request["key"];
        $sftp->port = $request["port"];
        $sftp->root = $request["path"];
        $sftp->type = $request["temptype"];
        $sftp->pause = 0;
        $sftp->company_id = $user->company_id;
        if ($user->user_type == "subclient")
            $sftp->subclient_id = $user->subclient_id;
        $sftp->save();

        return redirect()->back()->with('success', 'Your sftp details updated!');
    }

    public
    function editSftpSettings($id)
    {
        $sftpdata = SFTPImport::where('id', $id)->first();

        $user = auth()->user();
        if ($user->user_type == "company")
            $sftp = SFTPImport::where('company_id', $user->company_id)->where('subclient_id', null)->get();
        if ($user->user_type == "subclient")
            $sftp = SFTPImport::where('subclient_id', $user->subclient_id)->get();

        return view('import.sftp_settings', compact('sftp', 'sftpdata'));

    }

    public
    function pauseSftpSettings($id)
    {
        SFTPImport::where('id', $id)->update(['pause' => 1]);
        return redirect()->back()->with('success', 'Your sftp sync is pause!');
    }

    public
    function continueSftpSettings($id)
    {
        SFTPImport::where('id', $id)->update(['pause' => 0]);
        return redirect()->back()->with('success', 'Your sftp sync is resume!');
    }

    public
    function deleteSftpSettings($id)
    {
        SFTPImport::where('id', $id)->delete();
        return redirect()->back()->with('success', 'Your sftp details is deleted!');
    }

    public
    function validateCompanyDetails()
    {


    }

    public
    function progress($fuh_id)
    {
        $count = 0;
        $fuh = FileUploadHistory::find($fuh_id);
        if ($fuh->company_id == auth()->user()->company_id) {
            $count = $fuh->totalProcessed();
        }
        return $count;
    }
}