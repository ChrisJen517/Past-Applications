<?php

namespace App\Http\Controllers;

use App\CustomContent;
use Illuminate\Http\Request;

class CustomContentController extends Controller
{

    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('check-profile-completed');
        $this->middleware('sidebar-menu:account');
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(!auth()->user()->hasRole('superadmin')){
            $customContents = auth()->user()->company->custom_contents;
        }
        else{
            $customContents = CustomContent::all();
        }
        return view('yn.modules.account.custom-content', compact('customContents'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('custom.content.add-content');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required|max:50',
            'content' => 'required|min:100',
        ]);

        $customContent = CustomContent::create([
            'company_id' => auth()->user()->company->id,
            'title' => $request->get('title'),
            'content' => $request->get('content'),
        ]);

        return redirect('\contents')->with('success', 'Content created successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\CustomContent  $customContent
     * @return \Illuminate\Http\Response
     */
    public function show(CustomContent $customContent)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\CustomContent  $customContent
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $content = CustomContent::find($id);
        return view('custom.content.edit', compact('content'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\CustomContent  $customContent
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'title' => 'required|max:50',
            'content' => 'required|min:100',
        ]);
        
        $content = CustomContent::find($id);
        $content->fill($request->all());
        $content->save();

        return back()->with('success', 'Content updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\CustomContent  $customContent
     * @return \Illuminate\Http\Response
     */
    public function destroy(CustomContent $customContent)
    {
        //
    }
}
