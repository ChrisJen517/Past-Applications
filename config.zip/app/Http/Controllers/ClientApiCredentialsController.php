<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\ClientApiKey;
use Log;


class ClientApiCredentialsController extends Controller
{
    public function index()
    {
        $api_credentials = ClientApiKey::where('company_id', auth()->user()->company_id)->get();
        return view('yn.modules.api-credentials', compact('api_credentials'));
    }

    public function generate(Request $request)
    {
        // try {
            
            if(ClientApiKey::where('company_id', auth()->user()->company_id)->exists())
            {
                $api_credentials = ClientApiKey::where('company_id', auth()->user()->company_id)->first();
                $api_credentials->api_key = bin2hex(openssl_random_pseudo_bytes(20));
                $api_credentials->save();
            } else {
                $api_credentials = new ClientApiKey();
                $api_credentials->company_id = auth()->user()->company_id;
                $api_credentials->api_key = bin2hex(openssl_random_pseudo_bytes(20));
                $api_credentials->save();
            }

        // } catch (\throwable $e) {
        //     Log::channel('generate api key')->error($e);
        //     return redirect()->back()->with("error-msg", "Something went wrong.");
        // }   
        
        return redirect()->back()->with("success", "Api key generated");
    }

}