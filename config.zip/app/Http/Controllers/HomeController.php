<?php

namespace App\Http\Controllers;

use App\Company;
use App\Repositories\CompanyRepository;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Role;
use Spatie\Permission\Models\Permission;
use App\CustomStyle;
use App\Consumer;
use App\ConsumerNegotiation;
use App\ScheduleTransaction;
use App\PaymentProfile;
use DB;
use App\Transaction;
use App\Services\PayUService\Exception;
use Session;
use Carbon\Carbon;
use Yajra\DataTables\Facades\DataTables;

class HomeController extends Controller
{

    public function __construct()
    {
        $this->middleware(['auth', 'check-profile-completed']);
    }

    public function index(Request $request)
    {
        session(['layout' => 'vertical']);

        if (auth()->user()->hasRole('superadmin')) {
            if(auth()->user()->rnn_user_type == 'admin'){
                return redirect()->to(url('superadmin', 'company'));
            }
            else{
                return redirect()->to(url('superadmin', 'report'));
            }
        }

        $total_uploaded_consumers =$successful_payments = $connected_consumers = $scheduled_payments = $transactions = array();

        $user = auth()->user();
        if (!$user->hasRole('superadmin')) {
            $total_uploaded_consumers = Consumer::selectRaw("count(if(status != 'deactivated', 1, null)) as total_uploaded_consumers, count(if(payment_setup = 1 and offer_accepted = 1,1,null)) as connected_consumers")
                ->where('company_id', $user->company->id)
                ->when($user->user_type != 'company', function($query, $subclientType, $user){
                    return $query->where($subclientType, $user->subclient_id);
                })->first();

            $scheduled_payments = ScheduleTransaction::selectRaw("sum(amount) as scheduled_payments")
                ->where('company_id', $user->company->id)->where('payment_complete', 0)
                ->when($user->user_type != 'company', function($query, $subclientType, $user){
                    return $query->where($subclientType, $user->subclient_id);
                })
                ->whereRaw("date(schedule_date) between '".Carbon::now()->toDateString()."' and '".Carbon::now()->addDays(30)->toDateString()."'")
                ->first();

            $transactions = Transaction::selectRaw("sum(amount) as total_consumer_payment, sum(if(status = 'Successful',amount, null)) as successful_payments")
                ->where('company_id', $user->company->id)
                ->when($user->user_type != 'company', function($query, $subclientType, $user){
                    return $query->where($subclientType, $user->subclient_id);
                })
                ->where('status', "Successful")->where('created_at','>=',Carbon::today()->subDays(30))
                ->first();

            if ($user->user_type == 'company'){
                $warning = $this->validationIndex();
                if ($warning != "")
                    Session::flash('warn-msg', $warning);
            }
        } else {
            $total_uploaded_consumers = Consumer::selectRaw("count(*) as total_uploaded_consumers, count(if(payment_setup = 1 and offer_accepted = 1)) as connected_consumers")->first();
            $connected_consumers = Consumer::selectRaw("count(*) as connected_consumers")->where('status', 'payment_accepted')->where('offer_accepted', 1)->first();
            $transactions = Transaction::selectRaw("sum(amount) as total_consumer_payment, sum(if(status = 'Successful',amount, null) as successful_payments")->where('created_at','>=',Carbon::today()->subDays(30))->where('status', "Successful")->first();
            $scheduled_payments = ScheduleTransaction::selectRaw("sum(amount) as scheduled_payments")->whereRaw("date(schedule_date) between '".Carbon::now()->toDateString()."' and '".Carbon::now()->addDays(30)->toDateString()."'")->first();
        }

        $header_box_data['total_uploaded_consumers'] = $total_uploaded_consumers->total_uploaded_consumers ?? 0;
        $header_box_data['connected_consumers'] = $total_uploaded_consumers->connected_consumers ?? 0;
        $header_box_data['scheduled_payments'] = $scheduled_payments->scheduled_payments ?? 0;
        $header_box_data['total_consumer_payment'] = $transactions->total_consumer_payment ?? 0;
        $header_box_data['successful_payments'] = $transactions->successful_payments ?? 0;


        $consumers = $negotiated_consumers = $upcoming_transactions = array();

        $currency = getCurrencySymbol(auth()->user()->company->country ?? '');

        return view('yn.modules.dashboard', compact('consumers', 'header_box_data', 'currency'));
    }

    public function getConsumers(Request $request){

        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'consumers.account_number',
            1 => 'consumers.id',
            2 => 'company_name',
            3 => 'current_balance',
            4 => 'account_open_date',
            5 => 'consumer_negotiations.updated_at',
            6 => 'status'
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        // Get the count of the unfiltered data for pagination
        $total_consumers = Consumer::when($user->user_type == 'company', function($query){
                return $query->with('company');
            })->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
            ->when($user->user_type == 'Subclient1', function($query, $user){
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            })
            ->when($user->user_type == 'Subclient2', function($query, $user){
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })
            ->where('consumers.company_id', $user->company->id)
            ->whereIn('consumers.status', ['payment_setup'])
            ->where('consumers.custom_offer', 1)
            ->where('active_negotiation', 1)
            ->count();

        $consumers = Consumer::when($user->user_type == 'company', function($query){
                return $query->with('company');
            })->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
            ->when($user->user_type == 'Subclient1', function($query, $user){
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            })
            ->when($user->user_type == 'Subclient2', function($query, $user){
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })
            ->where('consumers.company_id', $user->company->id)
            ->whereIn('consumers.status', ['payment_setup'])
            ->where('consumers.custom_offer', 1)
            ->where('active_negotiation', 1)
            ->whereRaw("concat(consumers.account_number, consumers.first_name) like '%" . $search . "%'")
            ->select('consumers.*',
                'consumer_negotiations.negotiation_type',
                'consumer_negotiations.negotiate_amount',
                'consumer_negotiations.monthly_amount',
                'consumer_negotiations.no_of_installments',
                'consumer_negotiations.last_month_amount',
                'consumer_negotiations.installment_type',
                'consumer_negotiations.first_pay_date',
                'consumer_negotiations.one_time_settlement',
                'consumer_negotiations.communication_type',
                'consumer_negotiations.email',
                'consumer_negotiations.phone',
                'consumer_negotiations.reason',
                'consumer_negotiations.note',
                'consumer_negotiations.counter_note',
                'consumer_negotiations.active_negotiation',
                'consumer_negotiations.created_at', 'counter_monthly_amount',
                'counter_one_time_amount', 'counter_first_pay_date', 'counter_negotiate_amount')
            ->orderBy($order, $dir)          
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();

        // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($consumers as $consumer)
        {
            $consumer->company_name = $consumer->getMasterName();
            $consumer->actual_psd_amount = formatAmount($consumer->actualPSDamount(), $currency, 2);
            $consumer->actual_monthly_amount = formatAmount($consumer->actualMonthlyAmount(), $currency, 2);
            $consumer->actual_pif_amount = formatAmount($consumer->actualPIFamount(), $currency, 2);
            $consumer->max_days_first_pay = now()->addDays($consumer->actualMaxDaysFirstPay())->format('Y-m-d');
            $consumer->counter_first_pay_date = date('Y-m-d', strtotime($consumer->counter_first_pay_date));
            $consumer->first_pay_date = date('Y-m-d', strtotime($consumer->first_pay_date));
            $consumer->current_balance = formatAmount($consumer->current_balance, $currency, 2);
            $consumer->account_open_date = $consumer->account_open_date?date('Y-m-d', strtotime($consumer->account_open_date)):"-";
            $consumer->updated_at = strtotime($consumer->consumerNegotiation()['updated_at']);
            $consumer->payment_profile = ($consumer->paymentProfile ? true : false);

            if($consumer->sub_client2_id) {
                $consumer->sub_client = 2;
                $consumer->subclient_name = $consumer->subclient2->subclient_name;
                $consumer->account_contact_email = $consumer->subclient2->account_contact_email;
                $consumer->account_contact_phone = $consumer->subclient2->account_contact_phone;
            } else if($consumer->sub_client1_id){
                $consumer->sub_client = 1;
                $consumer->subclient_name = $consumer->subclient1->subclient_name;
                $consumer->account_contact_email = $consumer->subclient1->account_contact_email;
                $consumer->account_contact_phone = $consumer->subclient1->account_contact_phone;
            } else {
                $consumer->sub_client = 0;
                $consumer->subclient_name = "";
                $consumer->account_contact_email = "";
                $consumer->account_contact_phone = "";
            }
            $consumer->negotiate_amount = formatAmount($consumer->negotiate_amount, $currency, 2);
            $consumer->monthly_amount = formatAmount($consumer->monthly_amount, $currency, 2);
        }
        
        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_consumers),
            "recordsFiltered" => intval($total_consumers),
            "data"            => $consumers
            );

        echo json_encode($json_data);
    }

    public function resetNegotiations($consumer_id){
        $consumer = Consumer:: where('id', $consumer_id)->first();
        ScheduleTransaction::where('consumer_id', $consumer->id)->delete();
        ConsumerNegotiation::where('consumer_id', $consumer->id)->delete();
        PaymentProfile::where('consumer_id', $consumer->id)->delete();
        $consumer->status = 'joined';
        $consumer->counter_offer = false;
        $consumer->offer_accepted = false;
        $consumer->payment_setup = false;
        $consumer->has_failed_payment = false;
        $consumer->custom_offer = false;
        $consumer->save();

        return back()->with('success', 'Consumer Negotiation Reset');
    }

    public function deativateNegotiation($conusmer_id){
        ConsumerNegotiation::where('consumer_id', $conusmer_id)->where('company_id', auth()->user()->company->id)->update(['active_negotiation' => 0]);

        Consumer::where('id', $consumer_id)->where('company_id', auth()->user()->company->id)->update(['status' => 'deactivated']);

        return back()->with('success', 'Consumer Negotiation Deactivated');
    }

    public function getPendingPaymentSetup(Request $request){

        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'account_number',
            1 => 'consumers.id',
            2 => 'company_name',
            3 => 'sub_client1_id',
            4 => 'sub_client2_id',
            5 => 'current_balance',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        // Get the count of the unfiltered data for pagination
        $total_pending_payment_setups = Consumer::where('status', 'payment_accepted')
            ->where('payment_setup', 0)
            ->where('consumers.company_id', $user->company->id)
            ->when($user->user_type == 'Subclient1', function($query, $user){
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            })
            ->when($user->user_type == 'Subclient2', function($query, $user){
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })
            ->count();

        $pending_payment_setups = Consumer::where('status', 'payment_accepted')
            ->selectRaw('consumers.*, 
                "" as negotiation_term,
                "" as one_time_settlement, 
                "" as negotiation_type,
                "" as approved_by,
                "" as monthly_amount,
                "" as last_month_amount,
                "" as completed_on,
                consumer_negotiations.negotiation_type,
                consumer_negotiations.updated_at as negotiation_updated_at,
                consumer_negotiations.one_time_settlement,
                consumer_negotiations.no_of_installments,
                consumer_negotiations.last_month_amount,
                consumer_negotiations.monthly_amount,
                consumer_negotiations.counter_one_time_amount,
                consumer_negotiations.first_pay_date,
                consumer_negotiations.counter_first_pay_date
            ')
            ->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
            ->where('active_negotiation', 1)
            ->where('payment_setup', 0)
            ->where('consumers.company_id', $user->company->id)
            ->when($user->user_type == 'Subclient1', function($query, $user){
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            })
            ->when($user->user_type == 'Subclient2', function($query, $user){
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })
            ->when($search, function($query, $search){
                return $query->whereRaw("concat(consumers.account_number, consumers.first_name) like '%" . $search . "%'");
            })
            ->orderBy($order, $dir)          
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();

        // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($pending_payment_setups as $pending_payment_setup)
        {
            $pending_payment_setup->company_name = $pending_payment_setup->getMasterName();
            $pending_payment_setup->current_balance = formatAmount($pending_payment_setup->current_balance, $currency, 2);

            if($pending_payment_setup->status != 'payment_accepted')
                continue;

            $pending_payment_setup->completed_on = date('Y-m-d', strtotime($pending_payment_setup->negotiation_updated_at));

            if($pending_payment_setup->offer_accepted == 1){
                $pending_payment_setup->approved_by = "Auto Approve";
                $pending_payment_setup->first_pay_date = date('Y-m-d', strtotime($pending_payment_setup->first_pay_date));

                if($pending_payment_setup->negotiation_type == 'pif'){
                    $pending_payment_setup->negotiation_term = "Discounted Payoff Plan";
                    $pending_payment_setup->one_time_settlement = formatAmount($pending_payment_setup->one_time_settlement, $currency ,2);
                }
                else{
                    $pending_payment_setup->negotiation_term = "Discounted Payment Plan";

                    $pending_payment_setup->monthly_amount = formatAmount($pending_payment_setup->monthly_amount, $currency ,2);
                    if($pending_payment_setup->last_month_amount)
                        $pending_payment_setup->last_month_amount = "& 1 Last Payment of ".formatAmount($pending_payment_setup->last_month_amount, $currency, 2);
                }
            }
            else{
                $pending_payment_setup->approved_by = $pending_payment_setup->first_name." ".$pending_payment_setup->last_name;
                $pending_payment_setup->first_pay_date = date('Y-m-d', strtotime($pending_payment_setup->counter_first_pay_date));

                if($pending_payment_setup->negotiation_type == 'pif'){
                    $pending_payment_setup->negotiation_term = "Discounted Counter PayOff Plan";
                    $pending_payment_setup->one_time_settlement = formatAmount($pending_payment_setup->counter_one_time_amount, $currency ,2);
                }
                else{ 
                    $pending_payment_setup->negotiation_term = "Discounted Counter Payment Plan";

                    $pending_payment_setup->monthly_amount = formatAmount($pending_payment_setup->monthly_amount, $currency ,2);
                    if($pending_payment_setup->last_month_amount)
                        $pending_payment_setup->last_month_amount = "& 1 Last Payment of ".formatAmount($pending_payment_setup->last_month_amount, $currency, 2);
                }
            }
        }
        
        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_pending_payment_setups),
            "recordsFiltered" => intval($total_pending_payment_setups),
            "data"            => $pending_payment_setups
            );

        echo json_encode($json_data);
    }
        
    public function getNegotiatedConsumers(Request $request){

        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'transactions.created_at',
            1 => 'account_number',
            2 => 'consumers.id',
            3 => 'transactions.id',
            4 => 'payment_mode',
            5 => 'amount',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        // Get the count of the unfiltered data for pagination
        $total_negotiated_consumers = Consumer::join('transactions', 'consumers.id', '=', 'transactions.consumer_id')
            ->where('consumers.company_id', $user->company->id)
            ->whereIn('consumers.status', ['payment_accepted','settled'])
            ->when($user->user_type == 'Subclient2', function($query, $user){
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })
            ->when($user->user_type == 'Subclient1', function($query, $user){
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            })
            ->count();

        $negotiated_consumers = Consumer::join('transactions', 'consumers.id', '=', 'transactions.consumer_id')
            ->where('consumers.company_id', $user->company->id)
            ->whereIn('consumers.status', ['payment_accepted','settled'])
            ->when($user->user_type == 'Subclient2', function($query, $user){
                return $query->where('consumers.sub_client2_id', $user->subclient_id);
            })
            ->when($user->user_type == 'Subclient1', function($query, $user){
                return $query->where('consumers.sub_client1_id', $user->subclient_id);
            })
            ->when($search, function($query, $search){
                return $query->whereRaw("concat(consumers.account_number, consumers.first_name) like '%" . $search . "%'");
            })
            ->orderBy($order, $dir)          
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();
  
        // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($negotiated_consumers as $negotiated_consumer)
        {
            $negotiated_consumer->amount = formatAmount($negotiated_consumer->amount, $currency, 2);

            if(!empty($negotiated_consumer->gateway_respnse_raw) && $negotiated_consumer->status == 'Failed'){
                $error = json_decode($negotiated_consumer->gateway_respnse_raw);
                $negotiated_consumer->gateway_respnse_raw = $error->Error ?? '';
            }
            else
                $negotiated_consumer->gateway_respnse_raw = "";
        }

        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_negotiated_consumers),
            "recordsFiltered" => intval($total_negotiated_consumers),
            "data"            => $negotiated_consumers
            );

        echo json_encode($json_data);
    }

    public function getCounterOffer(Request $request){
        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'consumers.account_number',
            1 => 'consumers.first_name',
            2 => 'consumers.mobile1',
            3 => 'consumers.email1',
            4 => 'consumers.current_balance',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        // Get the count of the unfiltered data for pagination
        $total_counter_offer = Consumer::
            where('consumers.company_id', $user->company->id)
            ->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
            ->where('consumers.counter_offer', 1)
            ->where('status', '!=',  'deactivated')
            ->count();

        $counter_offers = Consumer::
            where('consumers.company_id', $user->company->id)
            ->join('consumer_negotiations', 'consumers.id', '=', 'consumer_negotiations.consumer_id')
            ->where('consumers.counter_offer', 1)
            ->where('status', '!=',  'deactivated')
            ->selectRaw('consumers.id, consumers.account_number, consumers.mobile1, consumers.email1, consumers.current_balance, consumers.first_name, consumers.last_name,
            "" as actualPIFamount, "" as actualPSDamount, "" as actualMonthlyAmount, "" as actualMaxDaysFirstPay, counter_note, first_pay_date, counter_first_pay_date,
            consumers.company_id, consumers.sub_client1_id, consumers.sub_client2_id, consumers.sub_client2_name, consumers.sub_client2_name,
            negotiate_amount, monthly_amount')
            ->when($search, function($query, $search){
                return $query->whereRaw("(
                    (consumers.mobile1 LIKE '%".$search."%') OR
                    (consumers.email1 LIKE '%".$search."%') OR
                    (consumers.current_balance LIKE '%".$search."%') OR
                    (CONCAT(consumers.first_name, ' ', consumers.last_name) LIKE '%".$search."%') OR
                    (consumers.id LIKE '%".$search."%')
                    )
                ");
            })
            ->orderBy($order, $dir)          
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();

        // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($counter_offers as $counter_offer)
        {
            $counter_offer->actualPIFamount = formatAmount($counter_offer->actualPIFamount(), $currency ,2);
            $counter_offer->actualPSDamount = formatAmount($counter_offer->actualPSDamount(), $currency ,2);
            $counter_offer->actualMonthlyAmount = formatAmount($counter_offer->actualMonthlyAmount(), $currency ,2);
            $counter_offer->actualMaxDaysFirstPay = now()->addDays($counter_offer->actualMaxDaysFirstPay())->format('Y-m-d');
            if($counter_offer->counter_first_pay_date)
                $counter_offer->counter_first_pay_date = date('Y-m-d', strtotime($counter_offer->counter_first_pay_date));
            else
                $counter_offer->counter_first_pay_date = now()->addDays($counter_offer->actualMaxDaysFirstPay())->format('Y-m-d');
                
            $counter_offer->first_pay_date = ($counter_offer->first_pay_date ? date('Y-m-d', strtotime($counter_offer->first_pay_date)) : "-");
            $counter_offer->current_balance = formatAmount($counter_offer->current_balance, $currency ,2);
            $counter_offer->one_time_settlement = formatAmount($counter_offer->one_time_settlement, $currency ,2);
            $counter_offer->negotiate_amount = formatAmount($counter_offer->negotiate_amount, $currency ,2);
            $counter_offer->monthly_amount = formatAmount($counter_offer->monthly_amount, $currency ,2);
        }

        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_counter_offer),
            "recordsFiltered" => intval($total_counter_offer),
            "data"            => $counter_offers
            );

        echo json_encode($json_data);
    }

    public function getUpcomingTransaction(Request $request){

        $user = auth()->user();

        // List of columns in the array to order by - some of these are not enabled to be orderabled but must be included for the column number to be correct
        $columns = array(
            0 => 'schedule_date',
            1 => 'account_number',
            2 => 'consumers.id',
            3 => 'company_name',
            4 => 'amount',
            5 => 'method',
        );

        // These values are automatically passed in via the datatable ajax call
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');
        $search = $request->input('search.value');

        // Get the count of the unfiltered data for pagination
        $total_uploaded_transactions = Consumer::
            join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
            ->join('payment_profiles', 'schedule_transactions.payment_profile_id', '=', 'payment_profiles.id')
            ->where('consumers.company_id', $user->company->id)
            ->whereIn('consumers.status', ['payment_accepted'])
            ->where('schedule_transactions.payment_complete', 0)
            ->count();

        $upcoming_transactions = Consumer::
            join('schedule_transactions', 'consumers.id', '=', 'schedule_transactions.consumer_id')
            ->join('payment_profiles', 'schedule_transactions.payment_profile_id', '=', 'payment_profiles.id')
            ->where('consumers.company_id', $user->company->id)
            ->whereIn('consumers.status', ['payment_accepted'])
            ->where('schedule_transactions.payment_complete', 0)
            ->selectRaw('consumers.id, consumers.company_id, consumers.sub_client1_id, consumers.sub_client2_id, consumers.sub_client2_name, consumers.sub_client2_name,
            consumers.first_name, consumers.last_name, consumers.account_number, schedule_transactions.schedule_date, schedule_transactions.amount,
            schedule_transactions.consumer_id, schedule_transactions.id as schedule_id, schedule_transactions.payment_profile_id,
            payment_profiles.id, payment_profiles.method, "" as company_name')
            ->when($search, function($query, $search){
                return $query->whereRaw("(
                    (schedule_transactions.schedule_date LIKE '%".$search."%') OR
                    (consumers.account_number LIKE '%".$search."%') OR
                    (CONCAT(consumers.first_name, ' ', consumers.last_name) LIKE '%".$search."%') OR
                    (consumers.id LIKE '%".$search."%') OR
                    (schedule_transactions.amount LIKE '%".$search."%') OR
                    (payment_profiles.method LIKE '%".$search."%')
                    )
                ");
            })
            ->orderBy($order, $dir)          
            ->limit($request->input("length"))
            ->offset($request->input("start"))
            ->get();

        // Get the master name for each entry
        $currency = getCurrencySymbol($user->company->country ?? '');
        foreach($upcoming_transactions as $upcoming_transaction)
        {
            $upcoming_transaction->company_name = $upcoming_transaction->getMasterName();
            $upcoming_transaction->amount = formatAmount($upcoming_transaction->amount, $currency ,2);
        }
        // This draws the table, cannot use Datatables:: model unless you can find a "draw" setting
        $json_data = array(
            "draw"            => intval($request->input('draw')),
            "recordsTotal"    => intval($total_uploaded_transactions),
            "recordsFiltered" => intval($total_uploaded_transactions),
            "data"            => $upcoming_transactions
            );

        echo json_encode($json_data);
    }

    //accept consumer payment
    public function acceptPayment($id)
    {
        try {
            $consumer = Consumer::find($id);
            $consumerNegotiation = ConsumerNegotiation::where('consumer_id', $id)->where('active_negotiation', 1)->get()->first();
            $paymentProfile = PaymentProfile::where('consumer_id', $consumer->id)->get()->first();

            if ($consumerNegotiation->negotiation_type == 'pif') {
            } elseif ($consumerNegotiation->negotiation_type == 'installment') {
                $no_of_installments = $consumerNegotiation->no_of_installments;
                $last_installment = $consumerNegotiation->last_month_amount;
                $firstdate_payment = $consumerNegotiation->first_pay_date;
                $installment_amount = $consumerNegotiation->monthly_amount;
                $frequency = $consumerNegotiation->installment_type;

                for ($i = 0; $i < $no_of_installments; $i++) {
                    $installments[$i]['date'] = $firstdate_payment;
                    $installments[$i]['amount'] = $installment_amount;

                    if ($frequency == 'weekly') {
                        $firstdate_payment = date('M d, Y', strtotime($firstdate_payment . ' + 1 week'));
                    } elseif ($frequency == 'bimonthly') {
                        $firstdate_payment = date('M d, Y', strtotime($firstdate_payment . ' + 2 week'));
                    } elseif ($frequency == 'monthly') {
                        $firstdate_payment = date('M d, Y', strtotime($firstdate_payment . ' + 1 month'));
                    }
                }

                if ($last_installment > 0) {
                    $installments[$i]['date'] = $firstdate_payment;
                    $installments[$i]['amount'] = $last_installment;
                }

                //dd($installments);

                foreach ($installments as $installment) {
                    $installment_amount = $installment['amount'];
                    $installment_date = $installment['date'];
                    $rnn_share = $installment_amount * 3 / 100;
                    // $processing_charges = $installment_amount * $company_terms[0]->processing_charges_percent / 100;

                    $subclient2_share = $installment_amount * 97 / 100;

                    //$company_share = $installment_amount - ($rnn_share + $processing_charges + $subclient1_share + $subclient2_share);

                    ScheduleTransaction::create([
                        'consumer_id' => $consumer->id,
                        //'consumer_login_id' => '',
                        'company_id' => $consumer->company->id,
                        'schedule_date' => date('yymd', strtotime($installment_date)),
                        'payment_profile_id' => $paymentProfile->id,
                        'status' => "scheduled",
                        'status_code' => '111',
                        'amount' => $installment_amount,
                        //'processing_charges' => $processing_charges,
                        'flat_transaction_charges' => "",
                        'rnn_share' => $rnn_share,
                        //'company_share' => $company_share,
                        //'subclient1_share' => $subclient1_share,
                        'subclient2_share' => $subclient2_share,
                    ]);
                }
            }

            $consumerNegotiation->offer_accepted = 1;
            $consumerNegotiation->save();

            $consumer->status = 'payment_accepted';
            $consumer->offer_accepted = 1;
            $consumer->save();

            $name = $consumer->getFullNameAttribute();
            return Redirect()->back()->with('success', 'Negotiation Accepted for ' . $name);
        } catch (Exception $e) {
            return $e->getMessage();
        }
    }

    //submit conter offer
    public function submitConterOffer(Request $request, $id)
    {
        $consumerNegotiation = ConsumerNegotiation::where('consumer_id', $id)->where('active_negotiation', 1)->get()->first();
        if ($consumerNegotiation) {
            $consumerNegotiation->counter_monthly_amount = $request->input('counter_monthly_amount');
            $consumerNegotiation->counter_first_pay_date = $request->input('counter_first_pay_date');
            $consumerNegotiation->counter_one_time_amount = $request->input('counter_pif_amount');
            $consumerNegotiation->counter_negotiate_amount = $request->input('counter_ppa_amount');
            $consumerNegotiation->counter_note = $request->input('counter_note');
            $consumerNegotiation->save();

            $consumer = Consumer::find($id);
            $consumer->counter_offer = 1;
            $consumer->save();

            $name = $consumer->first_name . " " . $consumer->last_name;
            return Redirect()->back()->with('success', 'Counter offer placed for ' . $name);
        }
    }

    //decline consumer payment
    public function declinePayment($id){
        $consumer = Consumer::find($id);
        $consumer->status = 'payment_declined';
        $consumer->save();

        $name = $consumer->first_name . " " . $consumer->last_name;
        return Redirect()->back()->with('success', 'Counter offer declined for ' . $name);
    }

    public function customerActivities(){
        return view('yn.modules.customer-activities');
    }

    public function consumerTerms(){
        return view('yn.modules.consumer-terms');
    }

    //Validation check in home page

    public static function validationIndex()
    {
        $personalized = DB::table('personalized_logos')->where('company_id', auth()->user()->company_id)->count();
        $consumers = DB::table('consumers')->where('company_id', auth()->user()->company_id)->count();
        $csv_headers = DB::table('csv_headers')->where('company_id', auth()->user()->company_id)->count();
        $company_terms = DB::table('companies')->where('id', auth()->user()->company_id)->first();
        $terms_conditons = DB::table('custom_contents')->where('company_id', auth()->user()->company_id)->where('title', 'terms-conditions')->count();
        $templates = auth()->user()->company->templates()->count();

        $warn = "";
        if ($personalized == 0) {
            $warn = "personalized,";

        }
        if ($consumers == 0) {
            $warn = $warn . "consumers,";
        }
        if ($csv_headers == 0) {
            $warn = $warn . "csv_headers,";
        }
        // if ($subclients == 0) {
        //     $warn = $warn . "nosubclient,";
        // }
        if ($templates == 0) {
            $warn = $warn . "notemplate,";
        }
        // if ($subclients == 0) {
        //     $warn = $warn . "nosubclient,";
        // }
        if (!$company_terms->pif_balance_discount_percent) {
            $warn = $warn . "company_terms,";

        }
        if ($terms_conditons == 0) 
            $warn = $warn . "terms_conditons";

        //dd($warn);

        return $warn;
        //End validation code
    }


    public function paymentPlan()
    {
        $user = auth()->user();

        $connected_consumers = Consumer::where('offer_accepted', 1)
            ->when(!$user->hasRole('superadmin'), function($query) use ($user){
                $query->where('company_id', $user->company->id);
                if ($user->user_type == 'Subclient1')
                    return $query->where('sub_client1_id',$user->subclient_id);
                elseif($user->user_type == 'Subclient2')
                    return $query->where('sub_client2_id',$user->subclient_id);
            })->get();

        return view('yn.modules.payment-plan', compact('connected_consumers'));
    }

    public function paymentForecast()
    {
        $user = auth()->user();
        $transactions = ScheduleTransaction::
            when(!$user->hasRole('superadmin'), function($query) use ($user){
                $query->where('company_id', $user->company->id);
                if ($user->user_type == 'Subclient1')
                    return $query->where('sub_client1_id',$user->subclient_id);
                elseif($user->user_type == 'Subclient2')
                    return $query->where('sub_client2_id',$user->subclient_id);
            })->where('payment_complete', 0)
            ->whereRaw("date(schedule_date) between '". Carbon::now()->toDateString()."' and '".Carbon::now()->addDays(30)->toDateString()."'")->get();

        return view('yn.modules.forecast-payment', compact('transactions'));
    }

    public function paymentSuccess()
    {

        $user = auth()->user();
        $transactions = Transaction::
            when(!$user->hasRole('superadmin'), function($query) use ($user){
                $query->where('company_id', $user->company->id);
                if ($user->user_type == 'Subclient1')
                    return $query->where('sub_client1_id',$user->subclient_id);
                elseif($user->user_type == 'Subclient2')
                    return $query->where('sub_client2_id',$user->subclient_id);
            })
            ->where('status','Successful')
            ->where('created_at','>=',Carbon::today()->subDays(30))
            ->get();

        return view('yn.modules.success-payment', compact('transactions'));
    }

    public function searchConsumer(Request $request){
        $search = $request->input('search');
        $user = auth()->user();


        if(strpos($search, ' ') !== false){
            $searchArray = explode(' ', $search);
            $query = Consumer::where('first_name', $searchArray[0])->where('last_name', $searchArray[1])->where('status', '!=', 'deactivated');
            
        }
        else{
            $query = Consumer::whereRaw("concat(ifnull(account_number, ''), ifnull(first_name, ''), ifnull(last_name, ''), ifnull(email1, ''), ifnull(mobile1, ''),
                                             ifnull(last4ssn, ''), ifnull(sub_client1_id, ''), ifnull(sub_client2_id, ''), ifnull(pass_through1, ''),
                                             ifnull(pass_through2, ''), ifnull(pass_through3, ''), ifnull(pass_through4, ''), ifnull(pass_through5, ''),
                                             ifnull(state, '')) like '%" . $search . "%'")->where('status', '!=', 'deactivated');
        }
        
        $query->selectRaw('consumers.*, id as id_consumer, (select count(*) from consumer_unsubscribes where consumer_id = id_consumer) as unsubscribed');

        if(strtolower($user->user_type) == 'company')
             $query->where('company_id', $user->company_id);
        elseif(strtolower($user->user_type) == 'subclient1')
            $query->where('sub_client1_id', $user->subclient_id);
        elseif(strtolower($user->user_type) == 'subclient2')
            $query->where('sub_client2_id', $user->subclient_id);

        $consumers = $query->get();

        if(count($consumers)>0)
            return view('yn.modules.search-consumer', compact('consumers'));
        else
            return Redirect()->back()->with('error-msg', 'No Consumer Found');
    }
}