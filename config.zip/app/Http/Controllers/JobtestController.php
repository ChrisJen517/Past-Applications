<?php

namespace App\Http\Controllers;

use App\Company;
use App\Transaction;
use Carbon\Carbon;
use App\RnnTransaction;

class JobtestController extends Controller
{
    public function handle()
    {
        $companies = Company::join('transactions','transactions.company_id','companies.id')
                                ->where('billing_schedule','Weekly')
                                ->where('rnn_share_pass',null)
                                ->where('transactions.updated_at','>=',Carbon::now()->subdays(7))
                                ->where('transactions.status','Successful')->get();

        foreach ($companies as  $value) {
           $this->charcgeCompany($value);
        }
    }

    public function charcgeCompany($company){

        $routing = $company->bank1_routing;
        $account = $company->bank1_account_number;
        $rnnShare = $company->rnn_share;
        $transactionAmount = $company->amount;

        $rnnAmount= ($transactionAmount *$rnnShare)/100;
        //dd($transactionAmount,$rnnShare,$rnnAmount);
        $date = str_replace("-", "",now()->toDateString());

        $packet ="20<FS>2010<FS>10<FS>".$date."125959<FS><FS>ZYZ63<FS>[NAME]".$company->billing_name."[/NAME][PAYER]".$company->bank1_company_address.$company->bank1_company_city.$company->bank1_company_state."[/PAYER][LOCATION]"
            .$company->bank1_company_state."[/LOCATION]<FS><FS>".$routing."<FS>".$account."<FS><FS>".$rnnAmount."<FS><FS><FS><FS><FS><FS>PV<FS>A7777777<FS>CA<FS>19760704<FS>6468512166";
        dd($packet);
        // $ch = curl_init();

        // curl_setopt($ch, CURLOPT_URL,"https://spaysys.com/cgi-bin/cgiwrap-noauth/dl4ub/tinqpstpbf.cgi");
        // curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS,
        //     $packet);
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // $server_output = curl_exec($ch);
        // dd($server_output);

        // curl_close ($ch);

       $curl = curl_init();

        curl_setopt_array($curl, array(
        CURLOPT_URL => "https://spaysys.com/cgi-bin/cgiwrap-noauth/dl4ub/tinqpstpbf.cgi",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 0,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => array('packet' => $packet),
        ));

        $response = curl_exec($curl);
        curl_close($curl);

        $rnnTransaction = new RnnTransaction();
        $rnnTransaction->company_id = $company->id;
        $rnnTransaction->transaction_id = $company->transaction_id;
        $rnnTransaction->amount = $rnnAmount;
        $rnnTransaction->responce = json_encode($response);
        $rnnTransaction->save();

        Transaction::where('transaction_id',$company->transaction_id)->update(['rnn_share_pass' =>now()]);
        
        }
}