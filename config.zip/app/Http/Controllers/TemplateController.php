<?php

namespace App\Http\Controllers;

use App\Group;
use App\Repositories\CampaignRepository;
use App\Repositories\GroupRepository;
use App\Repositories\TemplateRepository;
use App\Template;
use App\Traits\EnableDisableTrait;
use Illuminate\Http\Request;

class TemplateController extends Controller
{

    protected $repository;

    public function __construct(TemplateRepository $repository)
    {
        $this->middleware(['auth', 'check-profile-completed', 'redirect-if-subclient-user']);
        $this->middleware('sidebar-menu:communication');
        $this->repository = $repository;
    }

    public function index(GroupRepository $groupRepository)
    {
        $type = request()->get('type') ? request()->get('type') : 'email';
        $templates = $this->repository->templates(auth()->user()->company_id);
        $groups = $groupRepository->enabledGroups(auth()->user()->company_id);
        return view('yn.modules.communication.template', compact('templates', 'groups', 'type'));
    }

    public function store(Request $request, CampaignRepository $campaignRepository)
    {
        $params = $request->validate($this->repository->creationValidationRules());
        $template = Template::create([
                    'name' => $request->name,
                    'type' => $request->type,
                    'subject' => $request->subject,
                    'content' => decodeBase64($request->content,  auth()->user()->company_id, $request->name)
                ]);
        if ($template) {
            $message = 'Your template has been saved!';
        }

        if ($request->has('attach_group')) {
            if ($params['attach_group'] != null) {
                $group = Group::find($params['attach_group']);
                if ($group->enabled) {
                    $message = $this->repository->attachGroup($params['attach_group'], $template->id);
                } else {
                    session()->flash('error', 'Cannot create campaign because the group is disabled');
                    return redirect()->back();
                }
            }
        }
        session()->flash('success', $message);
        return redirect()->back();
    }

    public function edit($id, GroupRepository $groupRepository)
    {
        $template = $this->repository->get('id', $id);
        $templates = $this->repository->templates(auth()->user()->company_id);
        $groups = $groupRepository->enabledGroups(auth()->user()->company_id);
        return view('yn.modules.communication.template', compact('template', 'templates', 'groups'));
    }

    public function update($id, Request $request)
    {
        $params = $request->validate($this->repository->updateValidationRules());

        Template::where('id', $id)->update([
            'name' => $request->name,
            'type' => $request->type,
            'subject' => $request->subject,
            'content' => decodeBase64($request->content, auth()->user()->company_id, $request->name)
        ]);
        
        $message = 'Your template has been updated!';

        if ($request->has('attach_group')) {
            if ($params['attach_group'] != null) {
                $group = Group::find($params['attach_group']);
                if ($group->enabled) {
                    $message = $this->repository->attachGroup($params['attach_group'], $id);
                } else {
                    session()->flash('error', 'Cannot create campaign because the group is disabled');
                    return redirect()->back();
                }
            }
        }

        session()->flash('success', $message);
        return redirect()->to(url('template'));
    }

    public function delete($id)
    {
        $item = $this->repository->getByID($id);
        $this->repository->delete($id);
        session()->flash('success', $item->name . " has been deleted!");
        return redirect()->back();
    }

    public function enable($id)
    {
        $item = $this->repository->getByID($id);
        $item->enabled = true;
        $item->save();
        return redirect()->back()->with(['success' => 'Template: '.$item->name.' has been enabled!']);
    }

    public function disable($id)
    {
        $item = $this->repository->getByID($id);
        $item->enabled = false;
        $item->save();
        return redirect()->back()->with(['success' => 'Template: '.$item->name.' has been disabled!']);
    }
}
