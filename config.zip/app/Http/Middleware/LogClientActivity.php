<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Log;
use Illuminate\Routing\Route;
use Illuminate\Contracts\Routing\Middleware;
use App\ClientLog;
use Auth;

class LogClientActivity
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $response = $next($request);

        $user = Auth::user();

        if(!empty($user) && !$request->ajax()){
            $consumerId = $this->testForConsumerId($request);

            ClientLog::create([
                'company_id' => $user->company_id,
                'user_id' => $user->id, 
                'log_message' => 'User went to route: '.$request->route()->uri,
                'consumer_id' => $consumerId
            ]);
        }

        return $response;
    }

    private function testForConsumerId($request){
        $parameters = $request->route()->parameters();

        if(!empty($parameters['consumer_id']))
            return $parameters['consumer_id'];
        
        return null;
    }
}
