<?php

namespace App\Http\Middleware;

use Closure;

class RedirectIfSubclientUser
{
    public function handle($request, Closure $next)
    {
        if ($request->user()->user_type != 'company') {
            return redirect()->back()->with('error', 'You are not authorized for the route!');
        }
        return $next($request);
    }
}
