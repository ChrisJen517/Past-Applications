<?php

namespace App\Http\Middleware;

use Closure;

class CheckSubdomainAccess
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $subdomain = (explode('.', request()->getHost()))[0];

        if ($request->user()->company->younegotiate_url == $subdomain) {
            return $next($request);
        } else {
            return redirect()->to(url('redirect', [request()->getHost()]));
        }
    }
}
