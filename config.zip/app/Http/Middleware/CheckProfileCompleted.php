<?php

namespace App\Http\Middleware;

use Closure;

class CheckProfileCompleted
{
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if (auth()->user()->company->approved()) {
            return $next($request);
        }
        $message = 'Please complete your application to get started';
        if (auth()->user()->company->complete()) {
            $message = "Your profile is complete. Please wait for approval from our side.";
        }
        return redirect()->to(route('profile') . '#' . auth()->user()->company->incompleteStep())
            ->with('profile', ['title' => 'Welcome to YouNegotiate!', 'text' => $message]);
    }
}
