<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class FileUploadHistory extends Model
{
    protected $fillable = [
        'uploaded_by', 'filename', 'type', 'num_of_records', 'company_id', 'subclient_id', 'processed_count',
        'failed_count', 'status'
    ];

/*    public function getStatusAttribute()
    {
        if ($this->num_of_records == ($this->processed_count + $this->failed_count)) {
            return "Complete";
        } else {
            return "Validating";
        }
    }*/

    public function totalProcessed()
    {
        return $this->processed_count + $this->failed_count;
    }
}
