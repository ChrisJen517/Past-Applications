<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ApprovalMessage extends Model
{
    protected $table = "ApprovalMessage";
    protected $fillable = [
        'contractId', 'approval',
    ];

    public function createApprovalMessage($contract_id, $approval)
    {
        $this->contractId = $contract_id;
        $this->approval = $approval;
        $this->timestamps = false;
        $this->save();
    }
}