<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contract_Product_History extends Model
{
    protected $table = "contract_product_history";

    public function makeHistory($contract_id, $name, $price)
    {
        $this->contract_id = $contract_id;
        $this->product_name = $name;
        $this->price = $price;
        $this->save();
    }
}