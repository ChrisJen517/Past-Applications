<?php

namespace app;

use Codedge\Fpdf\Fpdf\Fpdf as BaseFPDF;

class FPDF_Custom extends BaseFPDF
{
    protected function _isascii($s)
    {
        // Test if string is ASCII
        $nb = strlen($s);
        for ($i = 0; $i < $nb; $i++) {
            if (ord($s[$i]) > 127) {
                return false;
            }
        }
        return true;
    }
    protected function _httpencode($param, $value, $isUTF8)
    {
        // Encode HTTP header field parameter
        if ($this->_isascii($value)) {
            return $param . '="' . $value . '"';
        }

        if (!$isUTF8) {
            $value = utf8_encode($value);
        }

        if (strpos($_SERVER['HTTP_USER_AGENT'], 'MSIE') !== false) {
            return $param . '="' . rawurlencode($value) . '"';
        } else {
            return $param . "*=UTF-8''" . rawurlencode($value);
        }
    }
    public function Output($dest = '', $name = '', $isUTF8 = false)
    {
        // Output PDF to some destination
        $this->Close();
        if (strlen($name) == 1 && strlen($dest) != 1) {
            // Fix parameter order
            $tmp = $dest;
            $dest = $name;
            $name = $tmp;
        }
        if ($dest == '') {
            $dest = 'I';
        }

        if ($name == '') {
            $name = 'doc.pdf';
        }

        switch (strtoupper($dest)) {
            case 'I':
                // Send to standard output
                $this->_checkoutput();
                if (PHP_SAPI != 'cli') {
                    // We send to a browser
                    header('Content-Type: application/pdf');
                    header('Content-Disposition: inline; ' . $this->_httpencode('filename', $name, $isUTF8));
                    header('Cache-Control: private, max-age=0, must-revalidate');
                    header('Pragma: public');
                }
                echo $this->buffer;
                break;
            case 'D':
                // Download file
                $this->_checkoutput();
                header('Content-Type: application/x-download');
                header('Content-Disposition: attachment; ' . $this->_httpencode('filename', $name, $isUTF8));
                header('Cache-Control: private, max-age=0, must-revalidate');
                header('Pragma: public');
                echo $this->buffer;
                break;
            case 'F':
                // Save to local file
                if (!file_put_contents($name, $this->buffer)) {
                    $this->Error('Unable to create output file: ' . $name);
                }

                break;
            case 'S':
                // Return as a string
                return $this->buffer;
            default:
                $this->Error('Incorrect output destination: ' . $dest);
        }
        return '';
    }
    public function GetPageWidth()
    {
        // Get current page width
        return $this->w;
    }

    public function GetPageHeight()
    {
        // Get current page height
        return $this->h;
    }

    public function Header()
    {
        $this->SetDrawColor(161, 0, 0);
        $this->SetFillColor(161, 0, 0);
        $this->Rect(8, 8, $this->GetPageWidth() - 16, $this->GetPageHeight() - 16, 'F');

        $this->SetDrawColor(255, 255, 255);
        $this->SetFillColor(255, 255, 255);
        $this->Rect(9.5, 9.5, $this->GetPageWidth() - 19, $this->GetPageHeight() - 19, 'F');

        $this->SetDrawColor(161, 0, 0);
        $this->SetFillColor(161, 0, 0);
        $this->Rect(10, 10, $this->GetPageWidth() - 20, $this->GetPageHeight() - 20, 'D');
        $this->setY(20);
    }
    public function GetMultiCellLineCount($w, $h, $txt, $border = null, $align = 'J')
    {
        // Calculate MultiCell with automatic or explicit line breaks height
        // $border is un-used, but I kept it in the parameters to keep the call
        //   to this function consistent with MultiCell()
        $cw = &$this->CurrentFont['cw'];
        if ($w == 0) {
            $w = $this->w - $this->rMargin - $this->x;
        }

        $wmax = ($w - 2 * $this->cMargin) * 1000 / $this->FontSize;
        $s = str_replace("\r", '', $txt);
        $nb = strlen($s);
        if ($nb > 0 && $s[$nb - 1] == "\n") {
            $nb--;
        }

        $sep = -1;
        $i = 0;
        $j = 0;
        $l = 0;
        $ns = 0;
        $height = 0;
        $count = 0;
        while ($i < $nb) {
            // Get next character
            $c = $s[$i];
            if ($c == "\n") {
                // Explicit line break
                if ($this->ws > 0) {
                    $this->ws = 0;
                    $this->_out('0 Tw');
                }
                //Increase Height
                $height += $h;
                $count++;
                $i++;
                $sep = -1;
                $j = $i;
                $l = 0;
                $ns = 0;
                continue;
            }
            if ($c == ' ') {
                $sep = $i;
                $ls = $l;
                $ns++;
            }
            $l += $cw[$c];
            if ($l > $wmax) {
                // Automatic line break
                if ($sep == -1) {
                    if ($i == $j) {
                        $i++;
                    }

                    if ($this->ws > 0) {
                        $this->ws = 0;
                        $this->_out('0 Tw');
                    }
                    //Increase Height
                    $height += $h;
                    $count++;
                } else {
                    if ($align == 'J') {
                        $this->ws = ($ns > 1) ? ($wmax - $ls) / 1000 * $this->FontSize / ($ns - 1) : 0;
                        $this->_out(sprintf('%.3F Tw', $this->ws * $this->k));
                    }
                    //Increase Height
                    $height += $h;
                    $count++;
                    $i = $sep + 1;
                }
                $sep = -1;
                $j = $i;
                $l = 0;
                $ns = 0;
            } else {
                $i++;
            }
        }
        // Last chunk
        if ($this->ws > 0) {
            $this->ws = 0;
            $this->_out('0 Tw');
        }
        //Increase Height
        $height += $h;
        $count++;

        return $count;
    }

    public function PageBreakDetermine($height)
    {
        if ($height + $this->GetY() > $this->PageBreakTrigger) {
            return true;
        }
    }


    /**
     * Builds the top part of the generated Schedule A page for MSA contracts
     *
     * @param
     */
    public function drawScheduleAHeader()
    {
        $this->AddFont('Calibri', '', 'calibri.php');
        $this->AddFont('Calibri-Bold', '', 'calibrib.php');

        $this->SetFont('Calibri-Bold', '', 10);

        $this->AddPage();

        $this->SetY(20);
        $this->SetDrawColor(0, 0, 0);
        $this->SetFillColor(241, 241, 241);

        $this->MultiCell($this->GetPageWidth() - 20, 5, 'SCHEDULE A', 0, 'C', false);
        $this->SetY(28);
        $this->MultiCell($this->GetPageWidth() - 20, 5, 'RNN Products and Services', 0, 'C', false);
        $this->SetY(33);
        $this->SetX(20);
        $this->MultiCell(160, 5, 'Contracted Services:', 0, 'L', false);

        $this->SetFont('Calibri', '', 10);
        $this->SetY(42);
        $this->SetX(20);
    }

        /**
     * Builds the top part of the generated Schedule A page for MSA contracts
     *
     * @param
     */
    public function drawAmendmentHeader()
    {
        $this->AddFont('Calibri', '', 'calibri.php');
        $this->AddFont('Calibri-Bold', '', 'calibrib.php');

        $this->SetFont('Calibri-Bold', '', 10);

        $this->AddPage();

        $this->SetY(20);
        $this->SetDrawColor(0, 0, 0);
        $this->SetFillColor(241, 241, 241);

        $this->MultiCell($this->GetPageWidth() - 20, 5, 'Amendment to Contract', 0, 'C', false);
        $this->SetY(28);
        $this->MultiCell($this->GetPageWidth() - 20, 5, 'RNN Products and Services', 0, 'C', false);
        $this->SetY(33);
        $this->SetX(20);
        $this->MultiCell(160, 5, 'Contracted Services:', 0, 'L', false);

        $this->SetFont('Calibri', '', 10);
        $this->SetY(42);
        $this->SetX(20);
    }


    /**
     * Builds the cell with the product header, which goes right above the product cells
     *
     * @param $prod_header the header for the product
     */
    public function buildProductHeader($prod_header)
    {
        $this->Cell(20, 10, '', 0, 1, 'C');
        $this->SetFont('Calibri-Bold', '', 10);
        $this->setFillColor(241, 241, 241);
        $this->Cell(10); //BORDER CELL FOR SPACING
        $this->Cell(170, 6, $prod_header->name, 1, 1, 'C', 1);
        $this->Cell(10); //BORDER CELL FOR SPACING

        if ($prod_header->description != '') {
            $this->MultiCell(170, 5, $prod_header->description, 1, 'C', false);
            $this->Cell(10); //BORDER CELL FOR SPACING
        }

        $x = $this->GetX();
        $y = $this->GetY();
        $this->MultiCell(40, 6, $prod_header->column_1, 1, 'C', false);
        $this->SetXY($x + 40, $y);
        $this->MultiCell(110, 6, $prod_header->column_2, 1, 'C', false);
        $this->SetXY($x + 150, $y);
        $this->MultiCell(20, 6, $prod_header->column_3, 1, 'C', false);
    }

    /**
     * Builds the fpdf cell(table) for the products selected
     *
     * @param $request from making a contract
     *        $i the loop index from inside the controller
     */
    public function buildProductCell($request, $i)
    {
        if ($request->prod_header_id[$i] == 11) {
            $price = floor($request->price[$i]);

            $cost_string = $price;
        } else if ($request->name[$i] == "AWG 7 Attempt") {
            $cost_string = $request->price_name[$i];
        } else if ($request->use_quote[$i] == 1)
        {
            $cost_string = $request->price[$i];
        } else {
            $price = $request->price[$i];
            $price = (float) $price;
            if ($price <= 10 || fmod($price, 1) !== 0.0) {
                if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                    $price = number_format($price, 2);
                }
            }
            $cost_string = '$' . $price . ' ' . $request->price_name[$i];
        }

        $cell_height = 5;

        $line_description = $this->GetMultiCellLineCount(110, $cell_height, $request->description[$i], 1, 'C', false);
        $line_name = $this->GetMultiCellLineCount(40, $cell_height, $request->name[$i], 1, 'C', false);
        $line_price = $this->GetMultiCellLineCount(20, $cell_height, $cost_string, 1, 'C', false);

        // Finding the max amount of lines needed to draw the box
        $max = $line_name;
        if ($max < $line_description) {
            $max = $line_description;
        }
        if ($max < $line_price) {
            $max = $line_price;
        }

        $this->Cell(10); //BORDER CELL FOR SPACING
        $x = $this->GetX();
        $y = $this->GetY();
        $this->SetFont('Calibri', '', 10);
        //LOGIC TO DETERMINE IF WE NEED A PAGE BREAK
        if ($this->PageBreakDetermine($max * $cell_height)) {
            $this->AddPage();
            $this->SetY(20);
            $this->Cell(10); //BORDER CELL FOR SPACING
        }

        $this->MultiCell(40, ($max * $cell_height) / $line_name, $request->name[$i], 1, 'C', false);
        $y = $this->GetY() - ($max * $cell_height);
        $this->SetXY($x + 40, $y);
        $this->MultiCell(110, ($max * $cell_height) / $line_description, $request->description[$i], 1, 'C', false);
        $this->SetXY($x + 150, $y);
        $this->MultiCell(20, ($max * $cell_height) / ($line_price), $cost_string, 1, 'C', false);
    }


    /**
     * Builds the top part of the generated fpdf page
     *
     * @param $client model
     *        $request from making a contract
     */
    public function FCRAHeader($client, $request)
    {
        $this->SetY(20);
        $this->SetDrawColor(0, 0, 0);
        $this->SetFillColor(241, 241, 241);
        $this->AddFont('Calibri', '', 'calibri.php');
        $this->AddFont('Calibri-Bold', '', 'calibrib.php');

        $this->SetFont('Calibri-Bold', '', 10);

        $this->AddPage();

        $this->SetFont('Calibri-Bold', '', 10);
        $this->SetTextColor(161, 0, 0);
        $this->SetY(20);
        $this->SetX(20);
        $this->MultiCell(160, 5, 'Amendment to Contract', 0, 'L', false);
        $this->SetY(25);
        $this->SetFont('Calibri', '', 10);
        $this->SetTextColor(0, 0, 0);
        $this->SetX(20);

        $this->SetFont('Calibri', '', 10);
        $this->MultiCell(160, 4, '1. This amendment (the "Amendment") is made by RNN Group and ' . iconv('UTF-8', 'windows-1252', $client->company_name) . ', parties to the agreement between RNN and  ' . iconv('UTF-8', 'windows-1252', $client->company_name) . ', dated ' . $request->original_date, 0, 'L', false);
        $currentY = $this->GetY();

        $this->SetY($currentY);
        $this->SetX(20);
        $this->MultiCell(160, 4, '2. The Agreement is amended as follows:', 0, 'L', false);

        $currentY = $this->GetY();
        $this->SetY($currentY);

        $this->SetTextColor(161, 0, 0);
        $this->SetFont('Calibri-Bold', '', 10);
        $this->SetTextColor(0, 0, 0);
    }
}