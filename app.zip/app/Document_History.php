<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Document_History extends Model
{
    protected $table = "document_history";
}
