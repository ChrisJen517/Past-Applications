<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Verified_Leads extends Model
{
    protected $table = "verified_leads";
}
