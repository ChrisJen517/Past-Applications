<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_Updates extends Model
{
    protected $table = "product_updates";
}
