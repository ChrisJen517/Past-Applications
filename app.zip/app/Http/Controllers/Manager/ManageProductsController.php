<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

use App\Http\Controllers\Controller;
use App\Product_Headers;
use App\Products;
use App\Product_Updates;
use App\Product_Header_Updates;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportAllProducts;

class ManageProductsController extends Controller
{
    /**
     * Show our list of products
     */
    public function manageProductSheet()
    {
        $product_info = Product_Headers::orderBy('order', 'asc')->with('products')->get();

        return view('manager.manageProductSheet')->with('product_info', $product_info);
    }

    /**
     * POST to update a product
     * @param $request should have
     * product header id, name, description, price name,
     * price, manager price 1(manager approval price), manager price 2(Jim approval price),
     *
     * create a new product update based on what was changed.
     */
    public function updateProduct(request $request)
    {
        $product_update = new Product_Updates();
        $message = "";
        $product = Products::find($request->idName);

        $product_update->product_Name = $product->name;
        if ($product->product_header_id != $request->product_header_id) {
            $message = $message . "Product Header was changed from '" . Product_Headers::find($product->product_header_id)->name . "' to '" . Product_Headers::find($request->product_header_id)->name . "'||";
        }
        $product->product_header_id = $request->product_header_id;

        if ($product->name != $request->name) {
            $message = $message . "Name was changed from " . strtoupper($product->name) . " to " . strtoupper($request->name) . "||";
        }
        $product->name = $request->name;

        if ($product->description != $request->description) {
            $message = $message . "Description was changed from " . strtoupper($product->description) . " to " . strtoupper($request->description) . "||";
        }
        $product->description = $request->description;

        if ($product->pricing_name != $request->price_name) {
            $message = $message . "Price Name was changed from " . strtoupper($product->pricing_name) . " to " . strtoupper($request->price_name) . "||";
        }
        $product->pricing_name = $request->price_name;

        if ($product->price != $request->price) {
            $message = $message . "Price was changed from " . $product->price . " to " . $request->price . "||";
        }
        $product->price = $request->price;

        if ($product->quote != $request->quote) {
            $message = $message . "Quote was changed from " . (empty($product->quote) ? '*unset*' : strtoupper($product->quote)) . " to " . strtoupper($request->quote) . "||";
        }
        $product->quote = $request->quote;

        if ($product->use_quote != $request->use_quote) {
            $message = $message . "Use quote was changed from " . (empty($product->use_quote) ? 'false' : 'true') . " to " . (empty($request->use_quote) ? 'false' : 'true') . "||";
        }
        $product->use_quote = $request->use_quote;

        if ($product->batch_code != $request->batch_code) {
            $message = $message . "Batch Code was changed from " . strtoupper($product->batch_code) . " to " . strtoupper($request->batch_code) . "||";
        }
        $product->batch_code = $request->batch_code;

        if ($product->vast_code != $request->vast_code) {
            $message = $message . "Vast Code was changed from " . strtoupper($product->vast_code) . " to " . strtoupper($request->vast_code) . "||";
        }
        $product->vast_code = $request->vast_code;

        if ($product->manager_price_1 != $request->manager_price_1) {
            $message = $message . "Manager Approval Price was changed from " . $product->manager_price_1 . " to " . $request->manager_price_1 . "||";
        }
        $product->manager_price_1 = $request->manager_price_1;

        if ($product->manager_price_2 != $request->manager_price_2) {
            $message = $message . "Executive Approval Price was changed from " . $product->manager_price_2 . " to " . $request->manager_price_2 . "||";
        }
        $product->manager_price_2 = $request->manager_price_2;

        if ($product->sla != $request->sla) {
            $message = $message . "SLA was changed from " . strtoupper($product->sla) . " to " . strtoupper($request->sla) . "||";
        }
        $product->sla = $request->sla;

        if ($product->show_in_list != $request->show_in_list) {
            $message = $message . "Product show in generation was changed from " . (empty($product->show_in_list) ? 'false' : 'true') . " to " . (empty($request->show_in_list) ? 'false' : 'true') . "||";
        }
        if ($request->show_in_list == 1)
            $product->show_in_list = 1;
        else
            $product->show_in_list = 0;

        $product->save();

        if (!empty($message)) {
            $product_update->description = $message;
            $product_update->product_id = $product->id;
            $user = Auth::user();
            $fullName = $user->name_first . " " . $user->name_last . ' (' . $user->id . ')';
            $product_update->user = $fullName;
            $product_update->save();
        }

        return redirect()->back()->with('message', 'Product Updated');
    }

    /**
     * Update active and non active products based off a list of product ids
     * @param $request should have:
     * a list of active product ids
     */
    public function updateActive(request $request)
    {
        foreach ($request->productId as $item) {
            $product = Products::find($item);
            $product->show_in_list = 1;
            $product->save();
        }

        $active_ids = "'" . implode("','", $request->productId) . "'";
        $products_not_active = DB::select(DB::raw(
            "SELECT
            id
            from
            products
            WHERE id NOT IN ($active_ids)"
        ));

        foreach ($products_not_active as $item) {
            $product = Products::find($item->id);
            $product->show_in_list  = 0;
            $product->save();
        }

        return redirect()->back()->with('message', 'Active Products Updated');
    }

    /**
     * Create a new product
     * @param $request should have:
     * product header id, name, description, price_name,
     * price, manager price 1 (manager approval price), manager price 2 (Jim approval price)
     *
     * Create a new product updates entry
     */
    public function addProduct(request $request)
    {
        // TODO make fillable
        $product = new Products();
        $product->product_header_id = $request->product_header_id;
        $product->name = $request->name;
        $product->description = $request->description;
        $product->pricing_name = $request->price_name;
        $product->price = $request->price;
        $product->manager_price_1 = $request->manager_price_1;
        $product->manager_price_2 = $request->manager_price_2;
        $product->sla = $request->sla;
        $product->batch_code = $request->batch_code;
        $product->vast_code = $request->vast_code;
        $product->quote = $request->quote;
        $product->use_quote = $request->use_quote;
        if ($request->show_in_list == 1)
            $product->show_in_list = 1;
        else
            $product->show_in_list = 0;
        $product->save();

        $user = Auth::user();
        $fullName = $user->name_first . " " . $user->name_last . ' (' . $user->id . ')';
        $product_update = new Product_Updates();
        $product_update->user = $fullName;
        $product_update->product_id = $product->id;
        $product_update->product_Name = $request->name;
        $product_update->description = "The product '" . strtoupper($request->name) . "' was created||";
        $product_update->save();

        return redirect()->back()->with('message', 'Product Added');
    }

    /**
     * Delete a product with id $id
     * @param $id the id of the product to be deleted
     * Create a product update entry
     */
    public function deleteProduct($id)
    {

        $product = Products::find($id);
        $product_update = new Product_Updates();
        $user = Auth::user();
        $fullName = $user->name_first . " " . $user->name_last . ' (' . $user->id . ')';
        $product_update->user = $fullName;
        $product_update->product_id = $product->id;
        $product_update->product_Name = $product->name;
        $product_update->description = "The product '" . strtoupper($product->name) . "' was deleted||";
        $product_update->save();

        $product->delete();

        return redirect()->back()->with('message', 'Product Deleted');
    }

    /**
     * Display product headers
     */
    public function showProductHeaders()
    {
        $product_headers = Product_Headers::orderBy('order', 'asc')->get();
        return view('manager.manageProductHeaders')->with('product_headers', $product_headers);
    }

    /**
     * Display product history
     */
    public function showProductHistory()
    {
        $products = Product_Updates::orderBy('id', 'desc')->get();
        $product_headers = Product_Header_Updates::orderBy('id', 'desc')->get();
        return view('manager.productHistory')->with('products', $products)->with('product_headers', $product_headers);
    }

    /**
     * Create a new product header
     * @param $request should have:
     * name, description, column 1(Product Name Label),
     * column 2(Description Label), column 3(Pricing Label)
     */
    public function addProductHeader(Request $request)
    {
        $product_header = new Product_Headers;
        $product_header->name = $request->name;
        $product_header->description = $request->description;
        $product_header->column_1 = $request->column_1;
        $product_header->column_2 = $request->column_2;
        $product_header->column_3 = $request->column_3;
        if ($request->show_in_list == 1)
            $product_header->show_in_list = 1;
        else
            $product_header->show_in_list = 0;
        $product_header->save();

        $name = $product_header->name;
        $user = Auth::user();
        $fullName = $user->name_first . " " . $user->name_last . " (" . $user->id . ")";
        $product_header_update = new Product_Header_Updates();
        $product_header_update->header_name = $name;
        $product_header_update->header_id = $product_header->id;
        $product_header_update->description = "The header '" . strtoupper($name) . "' was created||";
        $product_header_update->user = $fullName;
        $product_header_update->save();

        return redirect()->back()->with('success', 'New Product Header Created.');
    }

    /**
     * Updates a product header
     * @param $request should have:
     * name, description, column 1(Product Name Label),
     * column 2(Description Label), column 3(Pricing Label)
     */
    public function editProductHeader(Request $request)
    {
        $product_header_update = new Product_Header_Updates();
        $message = "";

        $product_header = Product_Headers::find($request->id);
        $product_header_update->header_name = $product_header->name;
        if ($product_header->name != $request->name)
            $message .= 'Name was changed from ' . strtoupper($product_header->name) . ' to ' . strtoupper($request->name) . '||';
        $product_header->name = $request->name;

        if ($product_header->description != $request->description)
            $message .= 'Description was changed from ' . strtoupper($product_header->description) . ' to ' . strtoupper($request->description) . '||';
        $product_header->description = $request->description;

        if ($product_header->column_1 != $request->column_1)
            $message .= 'Product Name Label was changed from ' . strtoupper($product_header->column_1) . ' to ' . strtoupper($request->column_1) . '||';
        $product_header->column_1 = $request->column_1;

        if ($product_header->column_2 != $request->column_2)
            $message .= 'Description Label was changed from ' . strtoupper($product_header->column_2) . ' to ' . strtoupper($request->column_2) . '||';
        $product_header->column_2 = $request->column_2;

        if ($product_header->column_3 != $request->column_3)
            $message .= 'Pricing Label was changed from ' . strtoupper($product_header->column_3) . ' to ' . strtoupper($request->column_3) . '||';
        $product_header->column_3 = $request->column_3;

        if ($product_header->show_in_list != $request->show_in_list)
            $message .= 'Show in list was changed from ' . (empty($product_header->show_in_list) ? 'false' : 'true') . ' to ' . (empty($request->show_in_list) ? 'false' : 'true') . '||';
        if ($request->show_in_list == 1)
            $product_header->show_in_list = 1;
        else
            $product_header->show_in_list = 0;

        $product_header->save();

        if (!empty($message)) {
            $user = Auth::user();
            $fullName = $user->name_first . " " . $user->name_last . " (" . $user->id . ")";
            $product_header_update->header_id = $product_header->id;
            $product_header_update->description = $message;
            $product_header_update->user = $fullName;
            $product_header_update->save();
        }

        return redirect()->back()->with('success', 'Product Header Updated.');
    }

    /**
     * Delete the product header with id $id
     * @param $id the id of the product header
     * this has front end validation to make sure a product headre can't be deleted with products
     */
    public function deleteProductHeader($id)
    {

        $product_header = Product_Headers::find($id);
        $products = Products::where('product_header_id', $id)->get()->count();
        if ($products > 0)
            return redirect()->back()->with('error', "Can't delete header with products.");

        $product_header_update = new Product_Header_Updates();

        $name = $product_header->name;
        $user = Auth::user();
        $fullName = $user->name_first . " " . $user->name_last . " (" . $user->id . ")";
        $product_header_update->header_id = $product_header->id;
        $product_header_update->header_name = $name;
        $product_header_update->description = "The header '" . strtoupper($name) . "' was deleted||";
        $product_header_update->user = $fullName;
        $product_header_update->save();

        $product_header->delete();

        return redirect()->back()->with('success', 'Product Header Deleted');
    }

    /**
     * Returns the number of products tied to product header
     * @param $id the id of the product header
     */
    public function getNumberOfProducts($id)
    {
        $products = Products::where('product_header_id', $id)->get()->count();
        return $products;
    }

    public function exportProductSheet() {
        $fileName = 'products' . time() . '.xlsx';
        Excel::store(new ExportAllProducts, $fileName, 'exports');
        return response(['fileName' => $fileName]);
    }

    public function showProductHeaderOrder()
    {
        $product_headers = Product_Headers::all()->sortBy('order');

        return view('manager.showProductHeaderOrder')->with('product_headers', $product_headers);
    }

    public function saveProductHeaderOrder(Request $request)
    {
        $ids = $request->ids;
        $orders = $request->orders;

        DB::statement('call store_header_order(?,?)', array(
            implode(',', $ids) . ',',
            implode(',', $orders) . ','
        ));

        return response(['message' => 'Successfully reordered headers']);
    }

    public function manageProductOrder($id)
    {
        $products = Products::where('product_header_id', $id)->orderBy('order', 'asc')->get();
        return view('manager.productOrder')->with('products', $products);
    }

    public function saveProductOrder(Request $request)
    {
        $ids = $request->ids;
        $orders = $request->orders;
        $headers = $request->p_headers;
        $user = Auth::user()->name_first . " " . Auth::user()->name_last . " (" . Auth::user()->id . ")";

        DB::statement('call store_product_order(?,?,?,?)', array(
            implode(',', $ids) . ',',
            implode(',', $orders) . ',',
            implode(',', $headers) . ',',
            $user
        ));


        return response(['message' => 'Successfully reordered products']);
    }
    public function ExportProductData()
    {
        $fileDestination = 'current_products.csv';
        //$fileDestination = '/public_html/contract/sync-outbound/closed_accounts.csv';
        $filename = '/home/contractrnngroup/public_html/rnngroup_finpro/Product_Sync/current_products.csv';
        $products = DB::select(DB::raw(
            "select
            (select name from product_headers where product_headers.id = products.product_header_id) as product_header,
            product_header_id,
            name,
            pricing_name,
            price,
            manager_price_1,
            manager_price_2,
            description,
            batch_code,
            vast_code,
            updated_at  from products"
        ));
        //$posts = Blog::all();


        if (file_exists($filename)) {
            unlink($filename);
        }
        $file = fopen($filename, 'w+');
        $headerString = 'product_header,product_header_id,name,pricing_name,price,manager_price_1,manager_price_2,description,batch_code,vast_code,updated_at';
        fwrite($file, $headerString);

        foreach ($products as $product) {
            $rowString = "\r\n".$product->product_header.','.//substr($myStr, 0, 5);
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->product_header_id).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->name).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->pricing_name).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->price).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->manager_price_1).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->manager_price_2).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->description).','.
                    substr(str_replace(array(",","-","/","\n","\t","\r"), "", $product->batch_code),0,15).','.
                    substr(str_replace(array(",","-","/","\n","\t","\r"), "", $product->vast_code),0,5).','.
                    str_replace(array(",","-","/","\n","\t","\r"), "", $product->updated_at);
                fwrite($file,$rowString);
        }
        // set up basic connection
        $ftp_server = '146.66.99.109';
        $conn_id = ftp_connect($ftp_server);

        // login with username and password
        $login_result = ftp_login($conn_id, 'contrac@rnngroup.com', 'Mountain2073!');
        ftp_pasv($conn_id, true);
        ftp_chdir($conn_id, '/public_html/rnngroup_finpro/Product_Sync');

        $contents = ftp_nlist($conn_id, ".");
//return ftp_nlist($conn_id, ".");
        // upload a file
        if (ftp_put($conn_id, $fileDestination, $filename, FTP_ASCII)) {
            echo "successfully uploaded $filename\n";
        } else {
            echo "There was a problem while uploading $filename\n";
        }

        // close the connection
        ftp_close($conn_id);
    }
}