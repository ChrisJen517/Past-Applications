<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer\PHPMailer;
use App\RNNMailer;
use App\User;

class ManageUsersController extends Controller
{
    /**
     * Displays the manage users page
     */
    public function showUsers()
    {
        $users = User::get();
        $managers = User::where('role', 'manager')->get();

        return view('manager.manageUsers')->with('users', $users)->with('managers', $managers);
    }

    /**
     * POST method to add new user
     * @param $request should have:
     *  first name, last name, email(unique),
     *  manager mail(if creating a manager account this will be empty),
     *  role, password_valid is always set to 0
     */
    public function addNewUser(Request $request)
    {
        $this->validate($request, [
            'name_first' => 'required',
            'name_last' => 'required',
            'email' => 'required|unique:users',
        ]);

        $user = new User();
        $user->name_first = $request->name_first;
        $user->name_last = $request->name_last;
        $user->email = $request->email;
        $user->manager_email = $request->manager_email;
        $user->role = $request->role;
        $user->password_valid = 0;
        if (isset($request->is_admin)) {
            $user->is_admin = $request->is_admin;
        }
        $password = rand();
        $user->password = bcrypt($password);
        $user->save();

        $mail = new RNNMailer(true);
        $mail->addAddresses(array('christianj@rnngroup.com', $user->email));

        $link = 'http://contract.rnngroup.com/';
        $mail->Subject = '[Contract Portal] Account Creation';
        $mail->Body    = '<p>' . $user->name_first . ', your account has been created. Username: ' . $user->email . ' Password: ' . $password . '</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Login</a>';

        $mail->send();

        return back()->with('success', 'User Created');
    }

    /**
     * GET method to archive a user
     * @param $id user id to archive
     */
    public function archiveUser($id)
    {
        $user = User::find($id);
        $user->is_archived = 1;
        $user->save();
        return back()->with('success', 'User Archived');
    }

    /**
     * GET method to unarchive a user
     * @param $id user id to unarchive
     */
    public function unarchiveUser($id)
    {
        $user = User::find($id);
        $user->is_archived = 0;
        $user->save();
        return back()->with('success', 'User Unarchived');
    }

    /**
     * Display a page with user's information
     * @param $id this is the id of the user
     */
    public function editUser($id)
    {
        $user = User::find($id);
        $managers = User::where('role', 'manager')->get();
        return view('manager.editUser')->with('user', $user)->with('managers', $managers);
    }

    /**
     * POST request to update the edited user
     * @param $request should have:
     * first name, last name, email(unique),
     *  manager mail(if creating a manager account this will be empty),
     *  role
     *  email the user after updating their account
     */
    public function updateUser(Request $request)
    {
        $this->validate($request, [
            'name_first' => 'required',
            'name_last' => 'required',
            'email' => 'required',
        ]);
        $user = User::find($request->id);
        $user->name_first = $request->name_first;
        $user->name_last = $request->name_last;
        $user->role = $request->role;
        $user->manager_email = $request->manager_email;
        if (isset($request->is_admin)) {
            $user->is_admin = $request->is_admin;
        }
        $user->save();

        if ($request->hasFile('avatar')) {
            $file = $request->file('avatar');
            $fileName = $file->getClientOriginalName();
            $fileExtension = $file->getClientOriginalExtension();
            // Declare Storage, and save accordingly
            $file->storeAs('/' . $user->id, 'avatar.png', ['disk' => 'profile_pictures']);
        }

        $mail = new RNNMailer(true);
        $mail->addAddresses(array('christianj@rnngroup.com', $user->email));
        // Attachments
        $link = 'http://contract.rnngroup.com/';
        $mail->Subject = '[Contract Portal] Account Updated';
        $mail->Body    = '<p>' . $user->name_first . ', your account has been updated by ' . Auth::user()->name_first . ' ' . Auth::user()->name_last . '<br> Username: ' . $user->email . '</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Login</a>';

        $mail->send();

        return redirect('manageUsers')->with('success', 'Account Updated');
    }

    /**
     * Reset a user's password
     * @param $id this is the user to be reset
     * email the user with the new password
     */
    public function resetPassword($id)
    {
        $user = User::find($id);
        $user->password_valid = 0;
        $password = rand(0, 9999999999999999);
        $user->password = bcrypt($password);
        $user->save();

        $mail = new RNNMailer(true);
        $mail->addAddresses(array($user->email));

        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "[Contract Portal] Password Reset";
        $mail->Body = "$user->name_first, your password has been reset by an admin. Your account email is $user->email and your temporary password is $password. Please login with the link http://contract.rnngroup.com/login and change your password.";

        // Mail Send
        $mail->send();
    }
}