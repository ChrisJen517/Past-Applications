<?php

namespace App\Http\Controllers\Manager;

use App\Http\Controllers\Controller;
use App\Contract;
use App\RNNMailer;
use App\User;
use App\History;

class ManageContractsController extends Controller
{

    /**
     * Authorize a contract
     *
     * @param id contract id
     * @return redirect with success
     */
    public function authorizeContract($id)
    {
        $contract = Contract::where('id', $id)->first();
        $contract->approval_needed = 0;
        $contract->status = 'awaiting_final_upload';
        $contract->save();

        $user = User::where('id', $contract->agent_reference)->first();

        $history = new History($contract->id, $contract->contract_name, "Contract approved.");

        $mail = new RNNMailer(true);
        $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));

        $mail->addAttachment(storage_path('app/public/' . $contract->contract_name));
        $mail->CharSet = 'UTF-8';

        $link = 'http://contract.rnngroup.com/';
        $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Has Been Approved';
        $mail->Body    = '<p>' . $user->name_first . ', your contract with id: ' . $contract->id . ' has been approved. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';

        $mail->send();
        return back()->with('message', 'Contract Approved');
    }

    public function authorizeRedline($id)
    {
        $contract = Contract::where('id', '=', $id)->first();
        $contract->approval_needed = 0;
        $contract->status = 'awaiting_product_selection';
        $contract->save();

        $history = new History($id, $contract->contract_name, "Client changes approved by Legal.");

        $user = User::where('id', '=', $contract->agent_reference)->first();

        $mail = new RNNMailer(true);
        $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));

        $mail->addAttachment(storage_path('app/public/' . $contract->contract_name));
        $mail->CharSet = 'UTF-8';

        $link = 'http://contract.rnngroup.com/';
        $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Has Been Approved by Legal';
        $mail->Body    = '<p>' . $user->name_first . ', your contract with id: ' . $contract->id . ' has been approved by legal. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';
        $mail->send();

        return back()->with('message', 'Contract Approved');
    }

    public function updateContractApi($type, $id){
        $contract = Contract::find($id);

        if(empty($contract)){
            return;
        }
        else if($type == "Approve"){
            $contract->approval_needed = 0;
            $contract->status = 'awaiting_final_upload';
            $contract->save();
            $user = User::where('id', $contract->agent_reference)->first();

            new History($contract->id, $contract->contract_name, "Contract approved.");

            $mail = new RNNMailer(true);
            $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));

            $mail->addAttachment(storage_path('app/public/' . $contract->contract_name));
            $mail->CharSet = 'UTF-8';

            $link = 'http://contract.rnngroup.com/';
            $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Has Been Approved';
            $mail->Body    = '<p>' . $user->name_first . ', your contract with id: ' . $contract->id . ' has been approved. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';

            $mail->send();
        }
        else{
            $contract->is_archived = 1;
            $contract->save();

            new History($contract->id, $contract->contract_name, "Contract Archived.");
        }

        return;
    }
}