<?php

namespace App\Http\Controllers\Manager;

use App\Contract;
use App\Exports\ExportContracts;

use App\Http\Controllers\Controller;
use App\YouNegotiateHistory;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use Yajra\DataTables\Facades\DataTables;

class DashboardController extends Controller
{
    /**
     * Show manager dashboard.
     *
     * @return view manager dashboard
     */
    public function showDashboard()
    {
        return view('manager.dashboard');
    }

    public function getCompleteContracts() {
        /* Reference
            $contracts = DB::select(DB::raw("SELECT CONCAT(users.name_first, ' ', users.name_last) AS agent_name,contracts.*
            from contracts INNER JOIN users on contracts.agent_reference = users.id WHERE contracts.status = 'complete'
            AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL) ORDER BY contracts.id DESC"));
        */

        $contracts = Contract::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.*")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("contracts.status = 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
        ->orderBy('contracts.id', 'desc')->get();

        return DataTables::of($contracts)->make(true);
    }

    public function getArchivedContracts() {
        /* Reference
            $contracts_archived = DB::select(DB::raw("SELECT CONCAT(users.name_first, ' ', users.name_last) AS agent_name,contracts.*
            from contracts INNER JOIN users on contracts.agent_reference = users.id WHERE contracts.is_archived = '1' ORDER BY contracts.id DESC"));
        */

        $contracts = Contract::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.*")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("contracts.is_archived = '1'")
        ->orderBy('contracts.id', 'desc')->get();

        return DataTables::of($contracts)->make(true);
    }

    public function getPendingContracts() {
        /* Reference
            $contracts_pending = DB::select(DB::raw("SELECT CONCAT(users.name_first, ' ', users.name_last) AS agent_name,contracts.*
            from contracts INNER JOIN users on contracts.agent_reference = users.id  WHERE contracts.status != 'complete'
            AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL) ORDER BY contracts.id DESC"));
        */

        $contracts = Contract::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.*, client_profiles.account_payable_name, client_profiles.invoice_approver_name, client_profiles.executive_contact_name")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->join('client_profiles', 'client_profiles.id', '=', 'contracts.client_id')
        ->whereRaw("contracts.status != 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
        ->orderBy('contracts.id', 'desc')->get();

        return DataTables::of($contracts)->make(true);
    }

    public function getContractsNeedingApproval() {
        /* Reference
            $contracts_approval_needed = DB::select(DB::raw("SELECT CONCAT(users.name_first, ' ', users.name_last) AS agent_name,contracts.*
            from contracts INNER JOIN users on contracts.agent_reference = users.id WHERE
            (contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND (contracts.status = 'awaiting_manager_approval' OR contracts.status = 'awaiting_jim_approval')
            AND contracts.approval_needed = 1 ORDER BY contracts.id DESC"));
        */

        $contracts = Contract::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.*")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND (contracts.status = 'awaiting_manager_approval' OR contracts.status = 'awaiting_jim_approval' OR contracts.status = 'awaiting_legal_approval') AND contracts.approval_needed = 1")
        ->orderBy('contracts.id', 'desc')->get();

        return DataTables::of($contracts)->make(true);
    }

    public function getYouNegotiateContracts() {
        /* Reference
            $negotiate = DB::select(DB::raw("SELECT CONCAT(users.name_first, ' ', users.name_last) AS agent_name,you_negotiate_history.*
            from you_negotiate_history INNER JOIN users on you_negotiate_history.agent_reference = users.id ORDER BY you_negotiate_history.id DESC"));
        */

        $contracts = YouNegotiateHistory::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, you_negotiate_history.*")
        ->join('users', 'you_negotiate_history.agent_reference', '=', 'users.id')
        ->orderBy('you_negotiate_history.id', 'desc')->get();

        return DataTables::of($contracts)->make(true);
    }


    public function getAPITables() {
        $contracts = Contract::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.*")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND (contracts.status = 'awaiting_manager_approval' OR contracts.status = 'awaiting_jim_approval') AND contracts.approval_needed = 1")
        ->orderBy('contracts.id', 'desc')->limit(5)->get();
        $approval = [];
        foreach($contracts as $contract)
            $approval[] = [$contract->id, $contract->company_name, $contract->agent_name, $contract->contract_type];

        $contracts = YouNegotiateHistory::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, you_negotiate_history.*")
            ->join('users', 'you_negotiate_history.agent_reference', '=', 'users.id')
            ->orderBy('you_negotiate_history.id', 'desc')->limit(5)->get();
        $negotiate = [];
            foreach($contracts as $contract)
                $negotiate[] = [$contract->contract_id, $contract->company_name, $contract->agent_name, $contract->setup_price, $contract->monthly_service_fee_percentage];

        $contracts = Contract::selectRaw("CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.*")
                ->join('users', 'contracts.agent_reference', '=', 'users.id')
                ->whereRaw("contracts.status != 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
                ->orderBy('contracts.id', 'desc')->limit(5)->get();
        $pending = [];
        foreach($contracts as $contract)
            $pending[] = [$contract->id, $contract->company_name, $contract->agent_name, $contract->contract_type];

        return response()->json(['Approval' => $approval, 'Negotiate' => $negotiate, 'Pending' => $pending]);
    }

    public function exportContracts(Request $request) {
        $type = $request->type;
        $search = $request->search;

        $fileName = '';
        $status = 'contracts.status';
        $whereClause = '';
        switch ($type) {
            case 'complete':
                $fileName .= 'Complete_Contracts_';
                $status = "'Complete' as status";
                $whereClause = "contracts.status = 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL)";
            break;
            case 'pending':
                $fileName .= 'Pending_Contracts_';
                $whereClause = "contracts.status != 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL)";
            break;
            case 'archived':
                $fileName .= 'Archived_Contracts_';
                $status = "'Archived' as status";
                $whereClause = "contracts.is_archived = '1'";
            break;
            case 'approval':
                $fileName .= 'Contracts_Needing_Approval_';
                $whereClause = "(contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND (contracts.status = 'awaiting_manager_approval' OR contracts.status = 'awaiting_jim_approval') AND contracts.approval_needed = 1";
                break;
        }

        if (!empty($search)) {
            $whereClause .= " AND
            (contracts.id LIKE '%$search%' OR
            company_name LIKE '%$search%' OR
            CONCAT(users.name_first, ' ', users.name_last) LIKE '%$search%' OR
            contracts.created_at LIKE '%$search%' OR
            contract_type LIKE '%$search%')";
        }

        $contracts = Contract::selectRaw("contracts.id as id, contracts.company_name, CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.created_at as created_at, contracts.contract_type, $status")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw($whereClause)
        ->orderBy('contracts.id', 'desc')->get();



        $fileName .= Carbon::now()->format('F_jS_Y') . '.xlsx';
        Excel::store(new ExportContracts($contracts), $fileName, 'exports');
        return response(['fileName' => $fileName]);
    }
}