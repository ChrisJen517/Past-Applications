<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use App\Contract;
use App\User;
use App\History;
use App\RNNMailer;
use App\ApprovalMessage;
use Illuminate\Support\Facades\Storage;

class ApproveController extends Controller
{
    /**
     * For Jim/Managers
     * Only show this page if they use the correct url
     * i.e. they have the correct key
     *
     * @param $key1
     *        $key2
     *        $id of the contract
     */
    public function showApprove($key1 = null, $key2 = null, $id = null)
    {
        if ($key1 == '$2y$10$72OFQ.ByneknikAMSeaYxu' && $key2 == 'PJW2LTdObBQsDWBagvo1sekQp.tWeO' && $id != null) {
            $contract = Contract::find($id);
            $agent = User::where('id', '=', $contract->agent_reference)->first();
            $approval = ApprovalMessage::where('contractId', '=', $contract->id)->first();
            $approval['data'] = explode("<br>", $approval->approval);

            return view('manager.approveContract')->with('contract', $contract)->with('agent', $agent)->with('approval', $approval);
        } else {
            return redirect('/')->with('error', 'Invalid Contract Key.');
        }
    }

    /**
     * Jim/Manager approved the contract
     * -> update the database and email the agent
     *
     * @param $request with contract information
     */
    public function approved(Request $request)
    {

        $contract = Contract::where('id', '=', $request->contractId)->first();
        $fileName = $contract->contract_name;
        $contract->approval_needed = 0;
        $contract->status = 'awaiting_final_upload';
        $contract->save();

        $history = new History($contract->id, $fileName, "Contract approved.");

        $user = User::where('id', '=', $contract->agent_reference)->first();

        $mail = new RNNMailer(true);
        $mail->addAddresses(array($user->email));
        $mail->addReplyTo('christianj@rnngroup.com', 'Report Server');

        $mail->addAttachment(storage_path('app/public/' . $fileName));
        $mail->CharSet = 'UTF-8';

        $link = 'http://contract.rnngroup.com/';
        $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Has Been Approved';
        $mail->Body    = '<p>' . $user->name_first . ', your contract id: ' . $contract->id . ' has been approved. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';

        $mail->send();

        return view('Includes.basicEmailResponse')->with('response', "Contract Approved");
    }

    /**
     * For legal team only
     * Only show this page if they use the correct url
     * i.e. they have the correct key
     *
     * @param $key1
     *        $key2
     *        $id of the contract
     */
    public function showLegalApprove($key1 = null, $key2 = null, $id = null)
    {
        if ($key1 == '$2y$10$72OFQ.ByneknikAMSeaYxu' && $key2 == 'PJW2LTdObBQsDWBagvo1sekQp.tWeO' && $id != null) {
            $contract = Contract::find($id);
            $agent = User::where('id', '=', $contract->agent_reference)->first();

            return view('manager.approveLegalContract')->with('contract', $contract)->with('agent', $agent);
        } else {
            return redirect('/')->with('error', 'Invalid Contract Key.');
        }
    }

    /**
     * Legal approved the contract
     * -> update the database and email the agent
     *
     * @param $request with contract information
     */
    public function legalApproved(Request $request)
    {
        if(empty($request->uploadFile))
            return back()->with('error', 'Please accept or deny the changes on the document and re-upload.');

        $contract = Contract::where('id', '=', $request->contractId)->first();
// return $request;
        if ($contract->status == 'awaiting_product_selection')
            return view('Includes.basicEmailResponse')->with('response',"Contract already approved");
        elseif($request->submit == "changes_requested")
            return $this->legalRequestChanges($request, $contract);

        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $history = new History($request->contractId, $file_name,  "Client changes approved by Legal. ".$request->comment);
        $history->file_name = 'GeneratedReports/' . $request->contractId . '/' . 'Approved/'.$history->id.'/'.$file_name;
        $history->save();

        $directoryName = 'GeneratedReports/' . $request->contractId . '/' . 'Approved/'.$history->id.'/';

        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();

        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $contract->status = 'awaiting_product_selection';
        $contract->approval_needed = 0;
        $contract->contract_name = $file_name;
        $contract->save();
        
        $user = User::where('id', '=', $contract->agent_reference)->first();

        $mail = new RNNMailer(true);
        $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));

        $mail->addAttachment(storage_path('app/public/' . $contract->contract_name));
        $mail->CharSet = 'UTF-8';

        $link = 'http://contract.rnngroup.com/';
        $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Has Been Approved by Legal';
        $mail->Body    = '<p>' . $user->name_first . ', your contract with id: ' . $contract->id . ' has been approved by legal. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';
        $mail->send();

        if(!Auth::check())
            return view('Includes.basicEmailResponse')->with('response', "Contract Approved");
        else    
            return back()->with('success', 'Redline Approved');
    }

    private function legalRequestChanges($request, $contract){
        if(strlen($request->comment) == 0)
            return back()->with('error', 'Please include a comment for denial when requesting changes.');
        if(empty($request->uploadFile))
            return back()->with('error', 'Please include a file.');

        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $history = new History($request->contractId, $contract->contract_name, "Changes requested with: ".$request->comment);
        $history->file_name = 'GeneratedReports/' . $request->contractId . '/' . 'Request_Changes/'.$history->id.'/'.$file_name;
        $history->save();
        
        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();
        $directoryName = 'GeneratedReports/' . $request->contractId . '/' . 'Request_Changes/'.$history->id.'/';
        // -----StorageUpdateV2
        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $contract->approval_needed = 0;
        $contract->status = 'changes_requested';
        $contract->save();

        $user = User::where('id', '=', $contract->agent_reference)->first();

        try {
            
            $mail = new RNNMailer(true);
            $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));

            // Attachments
            $mail->addAttachment($storage);         // Add attachment
            $mail->CharSet = 'UTF-8';
            $link = 'http://contract.rnngroup.com/';
            $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Needs Changes from Legal';
            $mail->Body    = '<p>' . $user->name_first . ', your contract with id: ' . $contract->id . ' requires changes requested by legal.</p><p>'.$request->comment.'</p><p>Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';
            $mail->send();

            if(!Auth::check())
                return view('Includes.basicEmailResponse')->with('response', "Changes Requested!");
            else    
                return back()->with('success', 'Changes Requested');
    
        } catch (\Throwable $e) {
            try {
                $mail = new RNNMailer(true);
                $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));
    
                // Attachments
                $mail->addAttachment($storage);         // Add attachment
                $mail->CharSet = 'UTF-8';
                $link = 'http://contract.rnngroup.com/';
                $mail->Subject = '[Contract Portal] ' . $contract->contract_type . ' Contract with ' . $contract->company_name . ' Needs Changes from Legal';
                $mail->Body    = '<p>' . $user->name_first . ', your contract with id: ' . $contract->id . ' requires changes requested by legal.</p><p>'.$request->comment.'</p><p>Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';
                $mail->send();
    
            } catch (\Throwable $e) {
                return back()->with('error', 'Something went wrong, submit again or reach out to christianj@rnngroup.com');
            }   
        }
    }
}