<?php

namespace App\Http\Controllers\Manager;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

use App\Http\Controllers\Controller;
use App\Document;
use App\Document_History;
use App\Client;

class ManageDocumentController extends Controller
{

    /**
     * Create a document
     *
     * @param Request POST to create a document
     * @return Redirect with success
     */
    public function createDocument(Request $request)
    {
        $this->validate($request, [
            'document_name' => 'required|max:150',
            'file_name' => 'nullable|file|max:50000',
            'type' => 'required|in:Client FCRA MSA,Trendsource Background Check,Client Non FCRA MSA,Client Product Amendment,Client FCRA Amendment,MNDA/NDA,Trend Source Audit,Data Vendor contract,Data Vendor NDA,Verified vendor contract,Verified vendor NDA,Policy,Procedure,Marketing,Deck,Presentation,FAQs,Onboarding,Certificate,End User Audit,OTHER',
        ]);

        $document = new Document();
        $document->document_name = $request->document_name;
        $document->file_name = $request->document_name;
        $document->notes = $request->notes;
        $document->type = $request->type;

        if($request->created_date != null)
            $document->created_date = date('Y-m-d', strtotime($request->created_date));
        if($request->expiration_date != null)
            $document->expiration_date = date('Y-m-d', strtotime($request->expiration_date));

        if (!empty($request->client_id)) {
            $document->client_id = $request->client_id;
            $document->client_vendor_name = Client::where('id', '=', $request->client_id)->first()->company_name;
        }

        $document->key_words = $request->key_words;
        $document->save();

        $request->document_name = preg_replace('/[^A-Za-z0-9\-]/', '', $request->document_name);

        $directoryName = 'Documents/' . $document->id . '/';
        if (!Storage::disk('local')->exists($directoryName)) {
            Storage::disk('local')->makeDirectory($directoryName);
        }

        if(pathinfo($request->document_name , PATHINFO_EXTENSION) != null)
            $fileName = $request->document_name;
        else
            $fileName = $request->document_name.'.'.pathinfo($_FILES['file_name']['name'] , PATHINFO_EXTENSION);

        $file = $request->file('file_name');
        $file->move(storage_path('app/public/') . $directoryName, $fileName);

        $document->file_name = $directoryName . $fileName;
        $document->save();

        return redirect()->back()->with('message', 'Document Added Successfully');

        // document history code
        // $documentHistory = new Document_History();
        // $documentHistory->document_reference_id = $document->id;
        // $documentHistory->description = 'File First Upload.';
        // $documentHistory->file_name = 'temp';
        // $documentHistory->save();

        // $document->file_name = $directoryName . $fileName;
        // $documentHistory->file_name = $directoryName . $fileName;
        // $document->save();
        // $documentHistory->save();
    }

    /**
     * Edit a document
     *
     * @param Request POST request with document attributes
     * @return Redirect with success
     */
    public function editDocument(Request $request)
    {
        $this->validate($request, [
            'document_name' => 'required|max:150',
            'file_name' => 'nullable|file|max:50000',
            'type' => 'required|in:Client FCRA MSA,Trendsource Background Check,Client Non FCRA MSA,Client Product Amendment,Client FCRA Amendment,MNDA/NDA,Trend Source Audit,Data Vendor contract,Data Vendor NDA,Verified vendor contract,Verified vendor NDA,Policy,Procedure,Marketing,Deck,Presentation,FAQs,Onboarding,Certificate,End User Audit,OTHER',
        ]);

        $document = Document::find($request->id);

        $newName = false;
        if($document->document_name != $request->document_name){
            $document->document_name = $request->document_name;
            $newName = true;
        }
        $document->notes = $request->notes;
        $document->type = $request->type;

        if (!empty($request->client_id)) {
            if ($document->client_id != $request->client_id) {
                $document->client_id = $request->client_id;
                $document->client_vendor_name = Client::where('id', '=', $request->client_id)->first()->company_name;
            }
        } else {
            $document->client_id = null;
            $document->client_vendor_name = null;
        }

        if($request->expiration_date != null)
            $document->expiration_date = date('Y-m-d', strtotime($request->expiration_date));
        else
            $document->expiration_date = null;

        $document->key_words = $request->key_words;

        if ($request->file_name != null) {
            $directoryName = 'Documents/' . $document->id . '/';
            if (!Storage::disk('local')->exists($directoryName)) {
                Storage::disk('local')->makeDirectory($directoryName);
            }
            $request->document_name = preg_replace('/[^A-Za-z0-9\-]/', '', $request->document_name);
            if(pathinfo($request->document_name , PATHINFO_EXTENSION) != null)
                $fileName = $request->document_name;
            else
                $fileName = $request->document_name.'.'.pathinfo($_FILES['file_name']['name'] , PATHINFO_EXTENSION);

            $file = $request->file('file_name');
            $file->move(storage_path('app/public/') . $directoryName, $fileName);

            $document->file_name = $directoryName . $fileName;
            $document->save();
        }
        else if($newName){
            $directoryName = 'Documents/' . $document->id . '/';
            if (!Storage::disk('local')->exists($directoryName)) {
                Storage::disk('local')->makeDirectory($directoryName);
            }

            if(pathinfo($request->document_name , PATHINFO_EXTENSION) != null)
                $fileName = $request->document_name;
            else
                $fileName = $request->document_name.'.'.pathinfo($document->file_name , PATHINFO_EXTENSION);

            $newFileName = $directoryName . $fileName;

            //renames the file
            rename(storage_path('app/public/').$document->file_name, storage_path('app/public/').$newFileName);

            $document->file_name = $newFileName;
            $document->save();
        }
        else
            $document->save();

        return redirect()->back()->with('message', 'Document Edited Successfully');

        // removed history code
        // $edited = '';
        // $document = Document::find($request->id);
        // $newFile = !empty($request->file_name);

        // if ($document->document_name != $request->document_name)
        //     $edited = $edited . 'name';

        // if ($document->description != $request->description)
        //     $edited = $edited . (!empty($edited) ? ', ' : '') . 'description';

        // if ($newFile)
        //     $edited = $edited . (!empty($edited) ? ', ' : '') . 'file';

        // $edited = $edited . '.';
        // $documentHistory = new Document_History();
        // $documentHistory->document_reference_id = $document->id;
        // $documentHistory->description = 'Edited document ' . $edited;
        // if ($newFile)
        //     $documentHistory->file_name = 'temp';
        // else
        //     $documentHistory->file_name = $document->file_name;
        // $documentHistory->save();
    }

    /**
     * Manage a document with a given id.
     *
     * @param id document id
     * @return view document management view
     */
    public function manageDocument($id)
    {
        $document = Document::find($id);
        $history = Document_History::where('document_reference_id', $id)->get();
        return view('manager.manageDocument')->with('document', $document)->with('history', $history);
    }

    /**
     * Archive a document with a given id.
     *
     * @param id document id
     * @return redirect back with success
     */
    public function archiveDocument($id)
    {
        $document = Document::where('id', $id)->first();
        $document->is_archived = 1;
        $document->save();

        // $documentHistory = new Document_History();
        // $documentHistory->document_reference_id = $document->id;
        // $documentHistory->description = 'Archived document.';
        // $documentHistory->file_name = $document->file_name;
        // $documentHistory->save();

        return redirect()->back()->with('message', 'Successfully archived.');
    }

    /**
     * Unarchive a document with a given id.
     *
     * @param id document id
     * @return redirect back with success
     */
    public function unarchiveDocument($id)
    {
        $document = Document::where('id', $id)->first();
        $document->is_archived = 0;
        $document->save();

        // $documentHistory = new Document_History();
        // $documentHistory->document_reference_id = $document->id;
        // $documentHistory->description = 'Unarchived document.';
        // $documentHistory->file_name = $document->file_name;
        // $documentHistory->save();

        return redirect()->back()->with('message', 'Successfully unarchived.');
    }
}