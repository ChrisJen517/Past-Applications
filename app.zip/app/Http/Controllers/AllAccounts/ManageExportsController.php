<?php

namespace App\Http\Controllers\AllAccounts;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Storage;

class ManageExportsController extends Controller
{
    public function downloadExport($fileName) {
        return response()->download(public_path() . '/Exports' . '/' . $fileName)->deleteFileAfterSend();
    }
}