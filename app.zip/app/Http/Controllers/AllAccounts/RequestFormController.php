<?php

namespace App\Http\Controllers\AllAccounts;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\PurchaseRequest;
use App\PurchaseRequestHistory;
use App\RNNMailer;
use App\User;
use Yajra\DataTables\Facades\DataTables;

class RequestFormController extends Controller
{
    //loads the page
    public function requestForm(){
        $user = Auth::user();
        $previousRequests = PurchaseRequest::when($user->role == 'agent', function($query) use ($user) {
            $query->where('submitter', $user->id);
        })->get();

        $archivedRequests = $previousRequests->where('is_archived', 1);
        $previousRequests = $previousRequests->where('is_archived', 0);

        return view('all.requestForm', compact(['previousRequests', 'archivedRequests']));
    }

    //updates and creates new requests
    public function submitForm(Request $request){
        $resend = false;
        $user = Auth::user();
        if(!empty($request->id)){
            $purchase = PurchaseRequest::where('id', $request->id)->first();
            $message = 'updated';
        }
        else{
            $purchase = new PurchaseRequest;
            $message = 'created';
            $purchase->submitter = $user->id;
        }

        $old_department = $purchase->department ?? '';

        foreach(['description', 'amount', 'username', 'password', 'justification', 'department', 'manager', 'manager_email', 'frequency', 'other', 'website'] as $field){
            $purchase->{$field} = $request->{$field};
        }

        if($purchase->manager_email == $user->email)
            $purchase->status = "awiting_final_approval";
        else if(empty($purchase->status))
            $purchase->status = "awaiting_approval";
        elseif($purchase->status == 'changes_requested' && PurchaseRequestHistory::where('purchase_request', $purchase->id)->where('history', 'like',  'Purchase request approved by%')->exists()){
            $purchase->status = "awaiting_final_approval";
            $resend = true;
        }
        elseif($purchase->status == 'changes_requested'){
            $purchase->status = "awaiting_approval";
            $resend = true;
        }
        
        $purchase->save();

        $history = new PurchaseRequestHistory;
        $history->__create($purchase->id, $purchase->submitter, "Purchase request ".$message." by ".$user->name_first." ".$user->name_last);

        if($old_department != $purchase->department || $resend){
            $mailer = new RNNMailer(true);
            $mailer->sendPurchaseRequest($purchase);
        }

        return back()->with('message', 'Purchase request successfully '.$message);
    }

    public function historyTable($id){
        $contracts = PurchaseRequestHistory::where('purchase_request', $id)->get();
        return DataTables::of($contracts)->make(true);
    }

    public function archiveForm($id){
        $purchase = PurchaseRequest::where('id', $id)->first();
        $purchase->is_archived = 1;
        $purchase->save(); 

        $user = Auth::user();

        $history = new PurchaseRequestHistory;
        $history->__create($purchase->id, $purchase->submitter, "Purchase request archived by ".$user->name_first.' '.$user->name_last);

        return back()->with('message', 'Form archived successfully.');
    }

    public function managerReviewPurchaseRequest($key1 = null, $key2 = null, $id = null, $type = null)
    {
        if ($key1 == '$2y$10$72OFQ.PJW2LTdObBQsDWBag' && $key2 == 'MSeaYxuvo1ByneknikAsekQp.tWeO' && $id != null) {
            $purchase_request = PurchaseRequest::find($id);
            $submitter = User::find($purchase_request->submitter);
            
            if($purchase_request->status == "denied")
                return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been denied");
            else if($purchase_request->status == 'changes_requested')
                return view('Includes.basicEmailResponse')->with('response',"Changes have already been requested for this purchase request");
            else if($purchase_request->status == "approved")
                return view('Includes.basicEmailResponse')->with('response',"Purchase request is already approved");
            else if($purchase_request->status == "awaiting_approval" && $type != "manager")
                return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been approved at this step");
            else if($purchase_request->status == "awaiting_final_approval" && $type != "final")
                return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been approved at this step");
            
            return view('Includes.forms.reviewPurchaseRequest', compact(['purchase_request', 'submitter', 'type']));
        } else {
            return view('Includes.basicEmailResponse')->with('response',"Invalid Key");
        }
    }

    public function managerSubmitPurchaseRequestReview(Request $request)
    {
        $purchase_request = PurchaseRequest::find($request->request_id);
        $user = User::where('id', '=', $purchase_request->submitter)->first();
        $status = $request->submit;
        $type = $request->type;

        if($purchase_request->is_archived)
            return view('Includes.basicEmailResponse')->with('response',"Purchase request has been archived and cannot be approved");
            
        if($purchase_request->status == "approved")
            return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been approved");
        else if($purchase_request->status == "denied")
            return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been denied");
        else if($purchase_request->status == "changes_requested")
            return view('Includes.basicEmailResponse')->with('response',"Changes have already been requested");
        else if($purchase_request->status == "awaiting_approval" && $type != "manager")
            return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been approved at this step");
        else if($purchase_request->status == "awaiting_final_approval" && $type != "final")
            return view('Includes.basicEmailResponse')->with('response',"Purchase request has already been approved at this step");
            
        $history = new PurchaseRequestHistory;
        $mail = new RNNMailer(true);

        $approver = $purchase_request->status == "awaiting_approval" ? $purchase_request->manager. " (manager)" : "Scott (final)";
        
        if($status == "approved"){
            
            if($purchase_request->status == "awaiting_approval" && $type == "manager")
                $purchase_request->status = "awaiting_final_approval";
            else if($purchase_request->status == "awaiting_final_approval" && $type == "final")
                $purchase_request->status = "approved";
                
            $purchase_request->save();
            
            $history->__create($purchase_request->id, $purchase_request->submitter, "Purchase request approved by " . $approver, $request->comment);

            if($purchase_request->status == "approved")
                $mail->sendApprovedPurchaseRequest($purchase_request);
            else
                $mail->sendPurchaseRequest($purchase_request);
                
        } else {

            if($request->submit != "denied" && strlen($request->comment) == 0)
                return back()->with('error', 'Please include a comment for denial when requesting changes');
                
            $purchase_request->status = $status;
            $purchase_request->save();

            $history->__create($purchase_request->id, $purchase_request->submitter, ($status == 'denied' ? "Purchase request denied by " : "Changes requested by ") . $approver, $request->comment);

            $mail->sendDeniedPurchaseRequest($purchase_request, $request->comment);
        }

        return view('Includes.basicEmailResponse')->with('response',"Purchase Request ".( $status == 'approved' ? "Approved" : "Denied" ));
    }
}