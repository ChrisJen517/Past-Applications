<?php

namespace App\Http\Controllers\AllAccounts;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Client;
use App\Client_Email; 
use App\RNNMailer;
use App\Contract;
use App\Document;
use Log;
use Yajra\DataTables\Facades\DataTables;
use Storage;

class ManageClientsController extends Controller
{
    /**
     * Shows page with table of clients
     */
    public function showClients()
    {
        return view('all.clients.manageClients');
    }

    /**
     * Shows page to add client
     */
    public function showAddClient()
    {
        return view('all.clients.addClient');
    }

    function getActiveClientsTable()
    {
        $clients = Client::selectRaw("id, company_name, company_state, company_address, company_city, company_zip, company_email, account_payable_email, invoice_approver_email, executive_contact_email")->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return DataTables::of($clients)->make(true);
    }

    function getInactiveClientsTable()
    {
        $clients = Client::selectRaw("id, company_name, company_state, company_address, company_city, company_zip, company_email")->where('is_archived', 1)->get();
        return DataTables::of($clients)->make(true);
    }

    /**
     * Look up Client by company_name
     * @param $name (==company_name)
     */
    public function findClient($name)
    {
        $client = Client::where('company_name', $name)->first();
        if ($client == null)
            return redirect()->back()->with('message', 'ERROR: Client not found');
        
        return redirect()->route('editClient', $client->id);
    }

    /**
     * POST add client to database
     * @param $request should have:
     * company name, address, city, state, zip, email, EIN, phone, url
     * optional:
     * account payable name, phone, email
     * invoice approver name, phone, email
     * executive contact name, phone, email
     */
    public function addClient(Request $request)
    {
        $this->validate($request, [
            'companyName' => 'required|max:255',
            'companyAddress' => 'required',
            'companyCity' => 'required',
            'companyState' => 'required',
            'companyZip' => 'required',
            'companyEmail' => ['required', 'unique:client_profiles,company_email'],
        ]);

        //saves the fields into the client then saves
        $client = new Client;
        $client->company_name =  strip_tags($request->input('companyName'));
        $client->company_address = $request->input('companyAddress');
        $client->company_city = $request->input('companyCity');
        $client->company_state = $request->input('companyState');
        $client->company_zip = $request->input('companyZip');
        $client->company_email = $request->input('companyEmail');
        $client->company_ein = $request->input('companyEIN');
        $client->company_phone = $request->input('companyPhone');
        $client->company_url = $request->input('companyURL');
        $client->industry = $request->input('industry');

        $client->account_payable_name = $request->input('accountPayableName');
        $client->account_payable_phone = $request->input('accountPayablePhone');
        $client->account_payable_email = $request->input('accountPayableEmail');

        $client->invoice_approver_name = $request->input('invoiceApproverName');
        $client->invoice_approver_phone = $request->input('invoiceApproverPhone');
        $client->invoice_approver_email = $request->input('invoiceApproverEmail');

        $client->executive_contact_name = $request->input('executiveContactName');
        $client->executive_contact_phone = $request->input('executiveContactPhone');
        $client->executive_contact_email = $request->input('executiveContactEmail');
        $client->save();

        return redirect('manageClients')->with('message', 'Client created.');
    }

    /**
     * Displays client information found by client id
     * @param $id
     */
    public function editClient($id)
    {
        $client = Client::find($id);

        $query = "SELECT CONCAT(users.name_first, ' ', users.name_last) AS agent_name,contracts.*
        from contracts INNER JOIN users on contracts.agent_reference = users.id WHERE (contracts.is_archived IS NULL OR contracts.is_archived = 0) AND client_id = $client->id";
        
        if(Auth::user()->role == 'agent')
            $query .= " AND agent_reference = ".Auth::user()->id;
            
        $contracts = DB::select(DB::raw($query." ORDER BY contracts.id DESC"));

        $documents = Document::where('client_id', $client->id)->where('is_archived', '!=', 1)->get();

        $name_options = "";
        if(isset($client->account_payable_name)) {
            $name_options .= "<br>" . $client->account_payable_name;
        }
        if(isset($client->invoice_approver_name)) {
            $name_options .= "<br>" . $client->invoice_approver_name;
        }
        if(isset($client->executive_contact_name)) {
            $name_options .= "<br>" . $client->executive_contact_name;
        }
        
        return view('all.clients.editClient')->with('client', $client)->with('contracts', $contracts)->with('documents', $documents)->with('isManager', Auth::user()->role == 'manager')->with('name_options',  $name_options);
    }

    /**
     * POST update client's information
     * @param $request should have:
     * company name, address, city, state, zip, email, EIN, phone, url
     * optional:
     * account payable name, phone, email
     * invoice approver name, phone, email
     * executive contact name, phone, email
     */
    public function updateClient(Request $request)
    {
        $this->validate($request, [
            'companyName' => 'required|max:255',
            'companyAddress' => 'required',
            'companyCity' => 'required',
            'companyState' => 'required',
            'companyZip' => 'required',
            'companyEmail' => 'required',
        ]);

        $client = Client::find($request->id);

        if ($request->companyEmail !== $client->company_email) {
            $this->validate($request, [
                'companyEmail' => ['unique:client_profiles,company_email'],
            ]);
        }

        //updates the fields into the client then saves
        $client->company_name = strip_tags($request->input('companyName'));
        $client->company_address = $request->input('companyAddress');
        $client->company_city = $request->input('companyCity');
        $client->company_state = $request->input('companyState');
        $client->company_zip = $request->input('companyZip');
        $client->company_email = $request->input('companyEmail');
        $client->company_ein = $request->input('companyEIN');
        $client->company_phone = $request->input('companyPhone');
        $client->company_url = $request->input('companyURL');
        $client->industry = $request->input('industry');

        $client->account_payable_name = $request->input('accountPayableName');
        $client->account_payable_phone = $request->input('accountPayablePhone');
        $client->account_payable_email = $request->input('accountPayableEmail');

        $client->invoice_approver_name = $request->input('invoiceApproverName');
        $client->invoice_approver_phone = $request->input('invoiceApproverPhone');
        $client->invoice_approver_email = $request->input('invoiceApproverEmail');

        $client->executive_contact_name = $request->input('executiveContactName');
        $client->executive_contact_phone = $request->input('executiveContactPhone');
        $client->executive_contact_email = $request->input('executiveContactEmail');
        $client->save();

        return redirect('manageClients')->with('message', 'Client updated.');
    }

    /**
     * POST archive/unarchive client found from id
     * @param $id
     *
     * Checks if it needs to be archive/unarchived based on a query
     */
    public function archiveClient($id)
    {
        $client = Client::find($id);

        if ($client->is_archived == 0 or $client->is_archived == NULL) {
            $client->is_archived = 1;
        } else if ($client->is_archived == 1) {
            $client->is_archived = 0;
        }
        $client->save();
        return back()->with('success', "Client Archived");
    }

    public function getClientsApi(){
        $clients = Client::selectRaw("company_name, CONCAT(company_state, ' ', company_address, ' ', company_city, ' ', company_zip) as address, company_email")->where('is_archived', 0)->orWhere('is_archived', NULL)->limit(100)->get();
        return response()->json(['clients' => $clients]);
    }

    public function sendEmail(Request $request){
        $email = new Client_Email();
        $email->__create($request->subject, $request->body, $request->client_email, $request->id, Auth::user()->id, isset($request->file));

        try{
            if(isset($request->file)){
                for($i = 0; $i < count($request->file); $i++)
                {
                    $request->file("file")[$i]->storeAs('/sendEmail' . '/' . $request->id . '/'.$email->id.'/originalFiles', $request->file("file")[$i]->getClientOriginalName(), ['disk' => 'local']);
                }
            }
            
            $mail = new RNNMailer(true);
            $mail->sendClientEmail($request, $email);

            return back()->with('success', "Email sent to client!");
        }
        catch (\Throwable $e) {
            Log::channel('mail')->info($e);
            $email->status = 'failed';
            $email->save();
            return redirect()->back()->with('error', 'Oh no! Something went wrong, if this persists contact a developer!');
        }
    }

    public function getEmails($id){
        $clients = Client_Email::selectRaw("id, created_at, subject, status, recipient, password")->where('archived', 0)->Where('client_id', $id)->get();
        return DataTables::of($clients)->make(true);
    }

    public function getFileNames($id, $type){
        $directoy = $this->getFolderName($id, $type);
        $audits = [];
        foreach (Storage::files($directoy) as $filename) 
            $audits[] =  str_replace($directoy.'/',"",$filename);
        echo json_encode($audits);
    }

    public function getEmailFiles($id, $type, $file){
        $directoy = $this->getFolderName($id, $type);
        $file = 'app/public/'.$directoy.'/'.$file;
        return response()->download(storage_path($file));
    }

    private function getFolderName($id, $type){
        $client = Client_Email::where('id', $id)->select('client_id')->first()->client_id;

        if($type == 'original')
            $type = 'originalFiles';
        else
            $type = "clientFiles";

        return 'sendEmail'.'/'.$client.'/'.$id.'/'.$type;
    }
}