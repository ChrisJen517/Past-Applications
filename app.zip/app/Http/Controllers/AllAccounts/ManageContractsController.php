<?php

namespace App\Http\Controllers\AllAccounts;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManageContractsController extends Controller
{

    public function downloadContract($file)
    {      
        return response()->download(storage_path('app/public/' . $file));
        
    }

}