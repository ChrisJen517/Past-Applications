<?php

namespace App\Http\Controllers\AllAccounts;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Sales_Leads;
use App\Lead_Contacts;
use App\User;
use App\Worked_History;
use App\Verified_Leads;

class LeadBoardController extends Controller
{
    public function addToQueue(Request $request){
        $this->validate($request, [
            'user_id' => 'required'
        ]);

        if (!empty($request->sales_lead_ids)) {
            $ids = $request->sales_lead_ids;
            $agent_id = $request->user_id;
            $agent = User::find($agent_id);

            Sales_Leads::whereIn('id', $ids)->update(['agent_id' => $agent_id, 'column_number' => 0, 'column_position' => 0, 'sales_agent' => $agent->name_first . ' ' . $agent->name_last]);
        } else {
            $lead = Sales_Leads::find($request->sales_lead_id);
            $lead->agent_id = $request->user_id;

            $agent = User::find($lead->agent_id);
            $lead->sales_agent = $agent->name_first . ' ' . $agent->name_last;

            $lead->column_number = 0;

            //sets it to the last position
            $lead->column_position = Sales_Leads::where('agent_id', $request->user_id)->where('column_number', 0)->max('column_position') + 1;
            $lead->save();
        }

        return back()->with('success', "Added to agent's board!");
    }

    public function createSalesLead(Request $request) {
        $company_name = $request->company_name;
        $user_id = $request->user_id;

        $lead = new Sales_Leads;
        $lead->company_name = $company_name;
        $lead->agent_id = $user_id;

        $agent = User::find($lead->agent_id);
        $lead->sales_agent = $agent->name_first . ' ' . $agent->name_last;

        $lead->column_number = 0;
        $lead->column_position = Sales_Leads::where('agent_id', $request->user_id)->where('column_number', 0)->max('column_position') + 1;
        $lead->save();

        return response(['message' => 'Successfully added card', 'lead_id' => $lead->id, 'column_position' => $lead->column_position]);
    }

    public function saveCardOrder(Request $request) {
        $ids = $request->ids;
        $orders = $request->orders;
        $columns = $request->columns;

        DB::statement('call store_card_order(?,?,?)', array(
            implode(',', $ids) . ',',
            implode(',', $orders) . ',',
            implode(',', $columns) . ','
        ));

        return response(['message' => 'Successfully reordered cards']);
    }

    public function showLeadsBoard() {
        // $statuses = ['Unworked', 'In Progress', 'Lead Complete', 'Lead Followup'];

        $statuses = [
            'Un-Worked Lead',
            'Intro Call Scheduled',
            'Deliverables Sent',
            'Deliverables Due',
            'Presentation Scheduled',
            'Contract Sent',
            'Implementation'
        ];

        $cards = Sales_Leads::select('column_position', 'column_number', "company_name", "last_worked", "industry", "id")
            ->where('agent_id', Auth::user()->id)->orderBy('column_position')->get();
        $cards = $cards->groupBy('column_number');

        for($i = 0; $i < sizeof($statuses); $i++) {
            if(!isset($cards[$i])) {
                $cards[$i] = [];
            }
        }

        return view('all.sales_leads.salesLeadsBoard')->with('statuses', $statuses)->with('cards', $cards);
    }
}
