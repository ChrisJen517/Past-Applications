<?php

namespace App\Http\Controllers\AllAccounts;

use Illuminate\Support\Facades\Auth;

use App\Http\Controllers\Controller;
use App\Document;
use App\Client;
use Yajra\DataTables\Facades\DataTables;

class SupportDocumentController extends Controller
{
    /**
     * Get the support document view.
     *
     * @return Illuminate\Support\Facades\View
     */
    function showSupportDocuments()
    {
        $isManager = Auth::user()->role == 'manager';
        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return view('all.supportDocuments')->with('isManager', $isManager)->with('clients', $clients);
    }

    function getSupportDocumentTable()
    {
        $documents = Document::selectRaw("id, document_name, client_vendor_name, type, notes, expiration_date, DATE_FORMAT(expiration_date, '%m/%d/%Y') as expiration_date_formatted, key_words, file_name, client_id, created_date")->where('is_archived', 0)->get();
        return DataTables::of($documents)->make(true);
    }

    function getArchivedSupportDocumentTable()
    {
        $documents = Document::selectRaw("id, document_name, client_vendor_name, type, notes, expiration_date, DATE_FORMAT(expiration_date, '%m/%d/%Y') as expiration_date_formatted, key_words, file_name, client_id, created_date")->where('is_archived', 1)->get();
        return DataTables::of($documents)->make(true);
    }
}