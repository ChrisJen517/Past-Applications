<?php

namespace App\Http\Controllers\AllAccounts;

use App\Contract;
use App\History;
use App\Http\Controllers\Controller;
use App\RNNMailer;
use App\User;
use DateInterval;
use DateTime;
use DocuSign\eSign\Api\EnvelopesApi\UpdateOptions;
use DocuSign\eSign\Api\EnvelopesApi\UpdateRecipientsOptions;
use DocuSign\eSign\Model\Recipients;
use Exception;
use Firebase\JWT\JWT;
use Illuminate\Database\Eloquent\ModelNotFoundException;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class DocusignController extends Controller
{
    // Generates an access token
    private function configureJwtAuthorizationFlowByKey()
    {
        $current_time = time();
        //live account url
        $aud = 'account.docusign.com';
        //integration key
        $iss = 'c45bfd77-1d15-4762-adcc-79237160c73e';
        $_token = array(
            "iss" => $iss,
            "sub" => '9db6f62c-0769-4ea4-840b-ce3aab53f444', //user id
            "aud" => $aud,
            "scope" => 'signature impersonation',
            "iat" => $current_time,
            "exp" => $current_time + 60 * 1000,
        );
        //RSA private key
        $str_priv_key = "-----BEGIN RSA PRIVATE KEY-----
        MIIEowIBAAKCAQEAhClx38NnpOt44IqP6/+u0ritEX3NlPfOSW6+iVTCpkJ8+YB4
        XN/5lcjr53y/JPZBvClXIv/HD0uOKfJmpAQAEf7uAUKJsiU9gL+zM7mSMf9jUg2D
        gnSwHUrUBa+W7mnW/sPaLEHouLw+Tr2wCYEojEe7eX5UqWUpfVAGsoYHk9n7GHut
        mxPhSyx7fGGdYhxWzG14IvsI/uF1tub1tr7uGVAjZMTaMv7Sl8ZHcJLNy3VCtYjH
        1Z2isEaLRBAn5WtIQxyz+H6s9PcbV0cDxbReQE4FlPFvJrMN5uWdIFyLNFAyZbLY
        SSTqBVeKfn2g4s9kuNu3A8QnZmTtiR/Caec9lQIDAQABAoIBAAPCjBdSH1o9SsCU
        oJiVuxsKnv3e5uDkle1X5brRewIw5Q5SHdqCkr60qyV4UpXSHbelM3Hu9fJU83P1
        Df9/j6LzbkEB7Bnx3kiR656+mk6q1eAJO2MUP8htjw+kWbZps3CnEMdujpjm3hzu
        X5o9nvIyvj4sHmt9UctbYf1lO8T0hX0OFojB9LGQKy/f5sNEjiSu4EFdUr6BsnNo
        4jJQh5bsFmGDHQUe9nKgRzRReQY6JVAip1UTHLWZMcpVzCheFmbFHG/WkXBQYrf+
        q6RMkGUv0o2vXv0+hPh1XSry3i6qz/CcTrW4DehGwIXewc0Axi0tJSesRTIZemkB
        Dv1LHQECgYEA3l8jcPxy9G/6ao4BjPAb1vcFkJfi+d+6QWy8+R17LWCahfyOSbDu
        g06ciO3t6LVYumV8nGgAkoGntFj9cV3BZBqoI8wWtcCS70K3PTNoDb5LQCiwHm35
        nTp20Bmib9keSNlwcE3p6tqN2dhncuBUvjtEREJqt0Tt+OM4Pe6ZtIECgYEAmCXw
        stupK4g3HKofuCMCbwzN/0N65tjLN7UlKqLp1UE7cWNW9qD1hr5jXaFgIMkPwgJ5
        8nws2SnlkMC0C0qZYMeEqvRRRdOMd0ULZccQAxqGEVmXp4ymMDaU4oowX+8R+Y3f
        gSw2CVnKv1LGPxFvTFvFZiYAjYgBbHJaB0hH7xUCgYAiBpS5uSct1+SNYWVDV4oq
        /mlPkq4cZetuD2FrDOPIMbvzPI3ZIMWeOe0h1qZMsVL+UoEavZ84y7YJloRRUHND
        CgEoWRYwgWL6UU8QgkktsSx6iL9KKLHFKSj89q8wRhyoMP1PcdyVHxQNfVt27HSL
        Fy5+81q46EcxijMU5umGAQKBgCaLfhYh1hLEOIoXg1+n5ubxTIK9urYe+CTNzHOn
        wCuZkhCgxRhIIMuZEh1XU74akdZpwDExSj9eAN2SJEq0BHVjNnYE3U4eUPiqUj/f
        lWvj3VEp7GSzGiseuMtHjQfQzjH1wki8RZhK2jVsJ/M0XIjwuuqs9/jjGtE5ixtL
        MYYdAoGBAKJtDk7VvKjeXrE34I2t8ea4AkYn+LRDetiqvy8A6eH7hZLOQfaL0WZ6
        rKb4vNLkeMs0D4JqZYOiRcmIxOOqpLKCJ+gpWbUwsAEf6z+lEAbi04+MbAUkEdUn
        bWcpr7eisrqsCY0XPN6SRSftp/SI4K+eA0g0lHBNyLWjfFuuyIqY
        -----END RSA PRIVATE KEY-----";

        //phpseclib private key encryption
        $private_key = new \phpseclib\Crypt\RSA();
        $private_key->loadKey($str_priv_key);

        //generate access token
        $jwt = JWT::encode($_token, $private_key, 'RS256');

        $headers = array('Accept' => 'application/json');

        $data = array('grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt);

        $body = \Unirest\Request\Body::form($data);

        $response = \Unirest\Request::post("https://{$aud}/oauth/token", $headers, $body);

        // Handle the response if it is an html page

        if (strpos($response->raw_body, '<html>') !== false) {
            throw new Exception("An error response was received!\n\n");
        }
        $json = $response->body;

        if (property_exists($json, 'error') and $json->{'error'} == 'consent_required') {

            $consent_url = "https://{$aud}/oauth/auth?response_type=code&scope={$this->permission_scopes}&client_id={$iss}&redirect_uri={$this->redirect_uri}";

            throw new Exception("\n\nC O N S E N T   R E Q U I R E D\n"

                . "Ask the user who will be impersonated to run the following url:\n"

                . "    {$consent_url}\n"

                . "It will ask the user to login and to approve access by your application.\n\n"

                . "Alternatively, an Administrator can use Organization Administration to\n"

                . "pre-approve one or more users.\n\n", 401);
        }

        if (property_exists($json, 'error') or !property_exists($json, 'access_token')) {

            throw new Exception("\n\nUnexpected error: {$json->{'error'}}\n\n");
        }

        printf("done. Continuing...");

        $access_token = $json->{'access_token'};

        $expires_in = $json->{'expires_in'};

        return $access_token;
    }

    public function sendDocumentForSigning($id, $email, $name)
    {
        # The document $fileNamePath will be sent to be signed by <signer_name>
        # Settings
        # Fill in these constants
        #
        # Obtain an OAuth access token from https://developers.docusign.com/oauth-token-generator
        $accessToken = $this->configureJwtAuthorizationFlowByKey();
        if (env('DEVELOPMENT') == 1)
            $accessToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjY4MTg1ZmYxLTRlNTEtNGNlOS1hZjFjLTY4OTgxMjIwMzMxNyJ9.eyJUb2tlblR5cGUiOjUsIklzc3VlSW5zdGFudCI6MTU5ODQ1MDUyNywiZXhwIjoxNTk4NDc5MzI3LCJVc2VySWQiOiI3YTNjMzZkZS04MTkzLTRlYzktYWY4Zi1kZjcwZjhhNDc4YmQiLCJzaXRlaWQiOjEsInNjcCI6WyJzaWduYXR1cmUiLCJjbGljay5tYW5hZ2UiLCJvcmdhbml6YXRpb25fcmVhZCIsInJvb21fZm9ybXMiLCJncm91cF9yZWFkIiwicGVybWlzc2lvbl9yZWFkIiwidXNlcl9yZWFkIiwidXNlcl93cml0ZSIsImFjY291bnRfcmVhZCIsImRvbWFpbl9yZWFkIiwiaWRlbnRpdHlfcHJvdmlkZXJfcmVhZCIsImR0ci5yb29tcy5yZWFkIiwiZHRyLnJvb21zLndyaXRlIiwiZHRyLmRvY3VtZW50cy5yZWFkIiwiZHRyLmRvY3VtZW50cy53cml0ZSIsImR0ci5wcm9maWxlLnJlYWQiLCJkdHIucHJvZmlsZS53cml0ZSIsImR0ci5jb21wYW55LnJlYWQiLCJkdHIuY29tcGFueS53cml0ZSJdLCJhdWQiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJhenAiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJpc3MiOiJodHRwczovL2FjY291bnQtZC5kb2N1c2lnbi5jb20vIiwic3ViIjoiN2EzYzM2ZGUtODE5My00ZWM5LWFmOGYtZGY3MGY4YTQ3OGJkIiwiYW1yIjpbImludGVyYWN0aXZlIl0sImF1dGhfdGltZSI6MTU5ODQ1MDUyNiwicHdpZCI6IjQ0ODViYTRlLWE5ZWQtNGQ2ZC04NDAyLWEzNTg3YjQ2ZjMzOCJ9.Yrz_ZlQLu4kwjrRkaKQr6ItaLfJ_r34Xb6PLvQzpQ6rKCKk43ns2vSXkQbAMhT0JJO3aqfPrTe0QWdIZokK0WhJL2Mqiihhu297Pp7rmrQGphUub8Qo-X77ZVCI13ue95FkGMdv_tl4RL-IeG2d6YExwgEWlXse1O7b0_DCkb7JuFWVShnybXKwjTp3KlPYe6wbK63-YbUPMEyyQMC1nsYxJuQG9xoIDFKk_hscKsJkGIIYMj2f0iUmdzP1CavGEfx5loZ8ZA7VLi5j1BniXG2EAzvzRWe442I82XIsh6tkB3JzjJ_L0Etv6qwRxIxQoaiNcoXXSNtUU-nKxxK6hjQ';

        # Obtain your accountId from demo.docusign.com -- the account id is shown in the drop down on the
        # upper right corner of the screen by your picture or the default picture.
        $accountId = '57710429';
        if (env('DEVELOPMENT') == 1)
            $accountId = '8906761';
        //The API base_path
        $basePath = 'https://NA3.docusign.net/restapi';
        if (env('DEVELOPMENT') == 1)
            $basePath = 'https://demo.docusign.net/restapi';
        //finds the contract in order to use the info for
        $contract = Contract::find($id);
        if ($contract == null)
            return redirect()->route('agentDashboard')->with('errorToast', 'The contract was not found. If you believe this to be an error, please contact a developer.');
        if (!empty($contract->envelopeId))
            return redirect()->route('agentDashboard')->with('errorToast', 'The contract has already been sent. If you believe this to be an error, please contact a developer.');

        $agent = User::find($contract->agent_reference);

        //starts by finding the file and converting it into
        $fileNamePath = $contract->contract_name;
        $extension = pathinfo($fileNamePath, PATHINFO_EXTENSION);
        $fileName = basename($fileNamePath);
        $fileNamePath = storage_path('app/public/' . $fileNamePath);
        $contentBytes = file_get_contents($fileNamePath);
        $base64FileContent = base64_encode($contentBytes);

        $pdftext = file_get_contents($fileNamePath);
        $num = preg_match_all("/\/Page\W/", $pdftext, $dummy);

        $document = new \DocuSign\eSign\Model\Document([ # create the DocuSign document object
            'document_base64' => $base64FileContent,
            'name' => $fileName, # can be different from actual file name
            'file_extension' => $extension, # many different document types are accepted
            'document_id' => $id, # a label used to reference the doc
        ]);

        if (env('DEVELOPMENT') == 1) {
            // $recipient_email = 'asd325wdjsdfkj463@gmail.com';
            $recipient_email = 'chrisjen517@gmail.com';
            $jim_email = 'chrisjen517@gmail.com';
            $agent->email = 'chrisjen517@gmail.com';
        } else {
            $recipient_email = $email;
            $jim_email = 'jimv@rnngroup.com';
        }

        //The signer object for clients
        $signer = new \DocuSign\eSign\Model\Signer([
            'email' => $recipient_email,
            'name' => substr($name, 0, 100),
            'routing_order' => '1',
            'recipient_id' => "1",
        ]);

        //The signer object for RNN's end
        $signerRNN = new \DocuSign\eSign\Model\Signer([
            'email' => $jim_email,
            'name' => 'Jim Van Schaik',
            'routing_order' => '2',
            'recipient_id' => "2",
        ]);

        $cc = new \DocuSign\eSign\Model\CarbonCopy([
            'email' => $agent->email,
            'name' => $agent->name_first . ' ' . $agent->name_last . ' CC',
            'recipient_id' => '3'
        ]);


        //an array set up for the signers to get the tabs
        $signerArray = [$signer, $signerRNN, $id, $num];

        //based on the contract type this decides what tabs are needed
        if ($contract->contract_type == "FCRA MSA" || $contract->contract_type == "MSA") {
            $signerArray = $this->setupMSA($signerArray);
        } else if ($contract->contract_type == "NDA") {
            $signerArray = $this->setupNDA($signerArray);
        } else if ($contract->contract_type == "Amendment" || $contract->contract_type == "YN Amendment") {
            $signerArray = $this->setupAmendment($signerArray);
        } else if ($contract->contract_type == "You-Negotiate") {
            $signerArray = $this->setupYouNegotiate($signerArray);
        } else if ($contract->contract_type == "MSA without FCRA") {
            $signerArray = $this->setupMSANoFCRA($signerArray);
        } else if ($contract->contract_type == "ICA") {
            $signerArray = $this->setupICA($signerArray);
        } else if ($contract->contract_type == "FCRA Certification") {
            $signerArray = $this->setupCertFCRA($signerArray);
        } else if ($contract->contract_type == "Name Change Amendment") {
            $signerArray = $this->setupNameChangeAmendment($signerArray);
        } else if ($contract->contract_type == "Reseller Agreement") {
            $signerArray = $this->setupResellerAgreement($signerArray);
        } else {
            $signerArray = $this->setupFCRA($signerArray);
        }

        if(!empty($signerArray[1])){
            # Next, create the top level envelope definition and populate it.
            $envelopeDefinition = new \DocuSign\eSign\Model\EnvelopeDefinition([
                'email_subject' => "Please sign this document",
                'documents' => [$document], # The order in the docs array determines the order in the envelope
                'recipients' => new \DocuSign\eSign\Model\Recipients(['signers' => [$signerArray[0], $signerArray[1]], 'carbon_copies' => [$cc]]), # The Recipients object wants arrays for each recipient type
                'status' => "sent", # requests that the envelope be created and sent.
            ]);
        } else {
            # Next, create the top level envelope definition and populate it.
            $envelopeDefinition = new \DocuSign\eSign\Model\EnvelopeDefinition([
                'email_subject' => "Please sign this document",
                'documents' => [$document], # The order in the docs array determines the order in the envelope
                'recipients' => new \DocuSign\eSign\Model\Recipients(['signers' => [$signerArray[0]], 'carbon_copies' => [$cc]]), # The Recipients object wants arrays for each recipient type
                'status' => "sent", # requests that the envelope be created and sent.
            ]);
        }

        #
        #  Step 2. Create/send the envelope.
        #
        $config = new \DocuSign\eSign\Configuration();
        $config->setHost($basePath);
        $config->addDefaultHeader("Authorization", "Bearer " . $accessToken);
        $apiClient = new \DocuSign\eSign\Client\ApiClient($config);
        $envelopeApi = new \DocuSign\eSign\Api\EnvelopesApi($apiClient);
        $results = $envelopeApi->createEnvelope($accountId, $envelopeDefinition);

        //updares the history
        $history = new History($contract->id, $fileName, 'Document sent to be signed.');

        //save the contract with the new status that the document sent
        $contract->envelopeId = $results->getEnvelopeId();
        $contract->status = 'awaiting_all_signature';
        $contract->docusign_email = $email;
        $contract->save();
        return redirect('dashboard')->with('message', 'Contract Sent To Be Signed.');
    }

    public function checkDocumentStatus()
    {
        $time = date('i');
        if( !( ($time >= 26 && $time <= 34) || ( $time >= 56 && $time <= 4) ) )
            return "No";
        # Settings
        # Fill in these constants
        #
        # Obtain an OAuth access token from https://developers.docusign.com/oauth-token-generator
        // $accessToken = $this->configureJwtAuthorizationFlowByKey();
        # Obtain your accountId from demo.docusign.com -- the account id is shown in the drop down on the
        # upper right corner of the screen by your picture or the default picture.
        // $accountId = '57710429';

        # The API base_path
        // $basePath = 'https://NA3.docusign.net/restapi';

        $accessToken = $this->configureJwtAuthorizationFlowByKey();
        if (env('DEVELOPMENT') == 1)
            $accessToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjY4MTg1ZmYxLTRlNTEtNGNlOS1hZjFjLTY4OTgxMjIwMzMxNyJ9.eyJUb2tlblR5cGUiOjUsIklzc3VlSW5zdGFudCI6MTU5MzYwNzcwOCwiZXhwIjoxNTkzNjM2NTA4LCJVc2VySWQiOiI3YTNjMzZkZS04MTkzLTRlYzktYWY4Zi1kZjcwZjhhNDc4YmQiLCJzaXRlaWQiOjEsInNjcCI6WyJzaWduYXR1cmUiLCJjbGljay5tYW5hZ2UiLCJvcmdhbml6YXRpb25fcmVhZCIsInJvb21fZm9ybXMiLCJncm91cF9yZWFkIiwicGVybWlzc2lvbl9yZWFkIiwidXNlcl9yZWFkIiwidXNlcl93cml0ZSIsImFjY291bnRfcmVhZCIsImRvbWFpbl9yZWFkIiwiaWRlbnRpdHlfcHJvdmlkZXJfcmVhZCIsImR0ci5yb29tcy5yZWFkIiwiZHRyLnJvb21zLndyaXRlIiwiZHRyLmRvY3VtZW50cy5yZWFkIiwiZHRyLmRvY3VtZW50cy53cml0ZSIsImR0ci5wcm9maWxlLnJlYWQiLCJkdHIucHJvZmlsZS53cml0ZSIsImR0ci5jb21wYW55LnJlYWQiLCJkdHIuY29tcGFueS53cml0ZSJdLCJhdWQiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJhenAiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJpc3MiOiJodHRwczovL2FjY291bnQtZC5kb2N1c2lnbi5jb20vIiwic3ViIjoiN2EzYzM2ZGUtODE5My00ZWM5LWFmOGYtZGY3MGY4YTQ3OGJkIiwiYW1yIjpbImludGVyYWN0aXZlIl0sImF1dGhfdGltZSI6MTU5MzYwNzcwNiwicHdpZCI6IjQ0ODViYTRlLWE5ZWQtNGQ2ZC04NDAyLWEzNTg3YjQ2ZjMzOCJ9.CSi9sMjgb0v_nCkHoFct259tPgq2ngOQp5U9h-Je6sD8nerifyrmZZEID-AJ1ayksXyXliUSFvQCeVGn-UQFDudPTqQ1Gu32YN6gW3I777X7QG9bTvm0jtfunwNeScM7_LaSHZsunSBorRPl3myiR9d_m8-aSCGWHnvL2N3ypI1gBqykuPAxhClnR0L-9bwmidX7FEtjMaNu-DSavTO_jatHmjHBp8L-gN0F7ORxvAC2YsItsJRjsq7QdRhzQy1GwC8l3VFX-0Ox2YJ3fO3Ot1h2A4kh9FfnjC3BhXC91GCqYs45Bdxup_O3nUUa6bOGSFXRRUqX5vjovM_MPRIUTQ';
        //return $accessToken;

        # Obtain your accountId from demo.docusign.com -- the account id is shown in the drop down on the
        # upper right corner of the screen by your picture or the default picture.
        $accountId = '57710429';
        if (env('DEVELOPMENT') == 1)
            $accountId = '8906761';
        //The API base_path
        $basePath = 'https://NA3.docusign.net/restapi';
        if (env('DEVELOPMENT') == 1)
            $basePath = 'https://demo.docusign.net/restapi';

        # configure the EnvelopesApi object
        $config = new \DocuSign\eSign\Configuration();
        $config->setHost($basePath);
        $config->addDefaultHeader("Authorization", "Bearer " . $accessToken);
        $apiClient = new \DocuSign\eSign\Client\ApiClient($config);
        $envelopeApi = new \DocuSign\eSign\Api\EnvelopesApi($apiClient);

        #
        # Step 1. Create the options object. We want the envelopes created 10 days ago or more recently.
        # Note to change to hours T must be placed after the P and before the number
        $date = new DateTime();
        $date->sub(new DateInterval("P1D"));
        $options = new \DocuSign\eSign\Api\EnvelopesApi\ListStatusChangesOptions();
        $options->setFromDate($date->format("Y/m/d"));

        #
        #  Step 2. Request the envelope list.
        #
        $results = $envelopeApi->listStatusChanges($accountId, $options);

        if (empty($results) || empty($results['envelopes']))
            return "empty";

        //checks all envelopes in the period
        foreach ($results['envelopes'] as $result) {
            //if they are complete it moves on
            //gets the contract id, which is the same as document id
            $listDocuments = $envelopeApi->listDocuments($accountId, $result->getEnvelopeId());
            $docId = $listDocuments['envelope_documents'][0]['document_id'];

            //if statement used for testing as docId 1 was causing errors, due to it not having a contract
            if ($docId != "1") {
                //finds the contract based on the id
                $contract = Contract::where('id',$docId)->first();
                if (!empty($contract)) {
                    if ($contract->status == 'complete')
                        continue;

                    if ($result['status'] == "completed") {
                        //checks if the document has already been finished, if not downloads the doc
                        if (($contract->is_archived != "1") && ($contract->status != 'complete')) {
                            $this->downloadDocument($result->getEnvelopeId());
                        }
                    } elseif ($result['status'] == 'voided')
                    {
                        $contract->status = 'void';
                        new History($contract->id, $contract->contract_name, 'Document voided: '.$result['voidedReason']);
                        $contract->save();
                    }
                    else {
                        $this->updateStatus($envelopeApi, $result, $accountId, $contract);
                    }
                }
            }
        }

        //returns to dashboard
        return "complete";
    }

    public static function updateStatus($envelopeApi, $result, $accountId, $contract)
    {
        $oldStatus = $contract->status;
        $envelopeId = $result->getEnvelopeId();
        $recipients = $envelopeApi->listRecipients($accountId, $envelopeId);
        $signers = $recipients->getSigners();
        $signedByClient = $signedByRNN = false;
        foreach ($signers as $signer) {
            $status = $signer->getStatus();
            if ($status == 'autoresponded') {
                $env = new \DocuSign\eSign\Model\Envelope();
                $env->setStatus('voided');
                $env->setVoidedReason('Invalid client email. Please fix and resend the contract.');

                $contract->status = "awaiting_final_upload";
                $contract->envelopeId = "";
                $contract->docusign_email = "";
                $contract->save();

                new History($contract->id, $contract->contract_name, 'Client email not found. DocuSign voided. Awaiting client signature upload.');

                $envelopeApi->update($accountId, $envelopeId, $env);

                $contractId = $contract->id;
                $signerEmail = $signer->getEmail();

                $mail = new RNNMailer(true);
                $mail->addAddresses(array(User::find($contract->agent_reference)->email));
                $mail->Subject = "[Contract Portal] Error Sending Contract Through DocuSign with ID ${contractId}";
                $mail->Body    = "<p>DocuSign is experiencing an issue trying to send the contract to the client's email. It is flagging that the email '${signerEmail}' does not exist.<br>The contract has been set back to its original status and the contract has been voided through DocuSign.<br>Please resend the contract with a valid email address for the client (either change the Client's email address in the Manage Clients page or specify a valid email in the prompt after clicking the send button).</p>";
                $mail->send();
                return;
            }
            if ($status == 'signed' || $status == 'completed' || $status == 'faxpending') {
                if ($signer->getRecipientId() == '1')
                    $signedByClient = true;
                else if ($signer->getRecipientId() == '2')
                    $signedByRNN = true;
            }
        }
        if ($signedByClient && $signedByRNN) {
            $contract->status = 'complete';
        } else if (!$signedByClient && !$signedByRNN) {
            $contract->status = 'awaiting_all_signature';
        } else if (!$signedByClient && $signedByRNN) {
            if ($contract->status != 'awaiting_client_signature') {
                $contract->status = 'awaiting_client_signature';
                new History($contract->id, $contract->contract_name, 'Document signed by Jim.');
            }
        } else if ($signedByClient && !$signedByRNN) {
            if ($contract->status != 'awaiting_jim_signature') {
                $contract->status = 'awaiting_jim_signature';
                new History($contract->id, $contract->contract_name, 'Document signed by Client.');
            }
        }
        $contract->envelopeId = $envelopeId;

        // Assume that the email it was sent to was the company email because changing that wasn't an option before.
        if ($contract->docusign_email == null) {
            $contract->docusign_email = $contract->company_email;
        }
        $contract->save();
        return 'Updated contract id = ' . $contract->id . ' by making status ' . $contract->status . ' from ' . $oldStatus . ' and added envelopeId = ' . $envelopeId . ',\n';
    }

    public function downloadDocument($results)
    {
        $accessToken = $this->configureJwtAuthorizationFlowByKey();
        if (env('DEVELOPMENT') == 1)
            $accessToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjY4MTg1ZmYxLTRlNTEtNGNlOS1hZjFjLTY4OTgxMjIwMzMxNyJ9.eyJUb2tlblR5cGUiOjUsIklzc3VlSW5zdGFudCI6MTU5MzYwNzcwOCwiZXhwIjoxNTkzNjM2NTA4LCJVc2VySWQiOiI3YTNjMzZkZS04MTkzLTRlYzktYWY4Zi1kZjcwZjhhNDc4YmQiLCJzaXRlaWQiOjEsInNjcCI6WyJzaWduYXR1cmUiLCJjbGljay5tYW5hZ2UiLCJvcmdhbml6YXRpb25fcmVhZCIsInJvb21fZm9ybXMiLCJncm91cF9yZWFkIiwicGVybWlzc2lvbl9yZWFkIiwidXNlcl9yZWFkIiwidXNlcl93cml0ZSIsImFjY291bnRfcmVhZCIsImRvbWFpbl9yZWFkIiwiaWRlbnRpdHlfcHJvdmlkZXJfcmVhZCIsImR0ci5yb29tcy5yZWFkIiwiZHRyLnJvb21zLndyaXRlIiwiZHRyLmRvY3VtZW50cy5yZWFkIiwiZHRyLmRvY3VtZW50cy53cml0ZSIsImR0ci5wcm9maWxlLnJlYWQiLCJkdHIucHJvZmlsZS53cml0ZSIsImR0ci5jb21wYW55LnJlYWQiLCJkdHIuY29tcGFueS53cml0ZSJdLCJhdWQiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJhenAiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJpc3MiOiJodHRwczovL2FjY291bnQtZC5kb2N1c2lnbi5jb20vIiwic3ViIjoiN2EzYzM2ZGUtODE5My00ZWM5LWFmOGYtZGY3MGY4YTQ3OGJkIiwiYW1yIjpbImludGVyYWN0aXZlIl0sImF1dGhfdGltZSI6MTU5MzYwNzcwNiwicHdpZCI6IjQ0ODViYTRlLWE5ZWQtNGQ2ZC04NDAyLWEzNTg3YjQ2ZjMzOCJ9.CSi9sMjgb0v_nCkHoFct259tPgq2ngOQp5U9h-Je6sD8nerifyrmZZEID-AJ1ayksXyXliUSFvQCeVGn-UQFDudPTqQ1Gu32YN6gW3I777X7QG9bTvm0jtfunwNeScM7_LaSHZsunSBorRPl3myiR9d_m8-aSCGWHnvL2N3ypI1gBqykuPAxhClnR0L-9bwmidX7FEtjMaNu-DSavTO_jatHmjHBp8L-gN0F7ORxvAC2YsItsJRjsq7QdRhzQy1GwC8l3VFX-0Ox2YJ3fO3Ot1h2A4kh9FfnjC3BhXC91GCqYs45Bdxup_O3nUUa6bOGSFXRRUqX5vjovM_MPRIUTQ';
        //return $accessToken;

        # Obtain your accountId from demo.docusign.com -- the account id is shown in the drop down on the
        # upper right corner of the screen by your picture or the default picture.
        $accountId = '57710429';
        if (env('DEVELOPMENT') == 1)
            $accountId = '8906761';
        //The API base_path
        $basePath = 'https://NA3.docusign.net/restapi';
        if (env('DEVELOPMENT') == 1)
            $basePath = 'https://demo.docusign.net/restapi';

        # configure the EnvelopesApi object
        $config = new \DocuSign\eSign\Configuration();
        $config->setHost($basePath);
        $config->addDefaultHeader("Authorization", "Bearer " . $accessToken);
        $apiClient = new \DocuSign\eSign\Client\ApiClient($config);
        $envelopeApi = new \DocuSign\eSign\Api\EnvelopesApi($apiClient);

        //gets the document and id
        $listDocuments = $envelopeApi->listDocuments($accountId, $results);
        $docId = $listDocuments['envelope_documents'][0]['document_id'];

        //sets up the directory and gets the file
        $directoryName = 'GeneratedReports/' . $docId . '/' . 'Signed_Document/';
        $fileName = $listDocuments['envelope_documents'][0]['name'];
        $file = $envelopeApi->getDocument($accountId, $docId, $results);
        $file = response()->file($file);
        $file = $file->getFile();

        // ----- StorageUpdatev2
        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);

        $file->move($storageDirectory, $fileName);
        $fileName = $directoryName . $fileName;

        //sets the contract to completed
        $contract = Contract::where('id',$docId)->first();
        $contract->status = 'complete';
        $contract->contract_name = $fileName;
        $contract->save();

        $agent = User::find($contract->agent_reference);

        $mail = new RNNMailer(true);
        $mail->CharSet = 'UTF-8';

        $mail->addAddresses(array($agent->email,'christianj@rnngroup.com'));
        $mail->addAttachment(storage_path('app/public/' . $fileName));
        $mail->Subject = '[Contract Portal] Contract with ' . $contract->company_name . ' is Signed and Completed';
        $mail->Body    = '<p>' . $agent->name_first . ',</p><p>Your contract id: ' . $contract->id . ' with ' . $contract->company_name . ' has been signed by both parties and marked as complete. Attached to this email is the completed document.</p>';
        $mail->send();

        //updares the history
        $history = new History($docId, $fileName, 'Document has been signed and completed.');
    }

    public function resendContract($id)
    {
        try {
            $contract = Contract::findOrFail($id);
        } catch (ModelNotFoundException $e) {
            return redirect()->route('agentDashboard')->with('errorToast', 'The contract could not be found.');
        }

        if (empty($contract->envelopeId)) {
            return redirect()->route('agentDashboard')->with('errorToast', 'The contract does not have a registered envelope id. If this contract has already been sent, please contact a developer.');
        }

        $accessToken = $this->configureJwtAuthorizationFlowByKey();
        if (env('DEVELOPMENT') == 1)
            $accessToken = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IjY4MTg1ZmYxLTRlNTEtNGNlOS1hZjFjLTY4OTgxMjIwMzMxNyJ9.eyJUb2tlblR5cGUiOjUsIklzc3VlSW5zdGFudCI6MTU5MzYwNzcwOCwiZXhwIjoxNTkzNjM2NTA4LCJVc2VySWQiOiI3YTNjMzZkZS04MTkzLTRlYzktYWY4Zi1kZjcwZjhhNDc4YmQiLCJzaXRlaWQiOjEsInNjcCI6WyJzaWduYXR1cmUiLCJjbGljay5tYW5hZ2UiLCJvcmdhbml6YXRpb25fcmVhZCIsInJvb21fZm9ybXMiLCJncm91cF9yZWFkIiwicGVybWlzc2lvbl9yZWFkIiwidXNlcl9yZWFkIiwidXNlcl93cml0ZSIsImFjY291bnRfcmVhZCIsImRvbWFpbl9yZWFkIiwiaWRlbnRpdHlfcHJvdmlkZXJfcmVhZCIsImR0ci5yb29tcy5yZWFkIiwiZHRyLnJvb21zLndyaXRlIiwiZHRyLmRvY3VtZW50cy5yZWFkIiwiZHRyLmRvY3VtZW50cy53cml0ZSIsImR0ci5wcm9maWxlLnJlYWQiLCJkdHIucHJvZmlsZS53cml0ZSIsImR0ci5jb21wYW55LnJlYWQiLCJkdHIuY29tcGFueS53cml0ZSJdLCJhdWQiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJhenAiOiJmMGYyN2YwZS04NTdkLTRhNzEtYTRkYS0zMmNlY2FlM2E5NzgiLCJpc3MiOiJodHRwczovL2FjY291bnQtZC5kb2N1c2lnbi5jb20vIiwic3ViIjoiN2EzYzM2ZGUtODE5My00ZWM5LWFmOGYtZGY3MGY4YTQ3OGJkIiwiYW1yIjpbImludGVyYWN0aXZlIl0sImF1dGhfdGltZSI6MTU5MzYwNzcwNiwicHdpZCI6IjQ0ODViYTRlLWE5ZWQtNGQ2ZC04NDAyLWEzNTg3YjQ2ZjMzOCJ9.CSi9sMjgb0v_nCkHoFct259tPgq2ngOQp5U9h-Je6sD8nerifyrmZZEID-AJ1ayksXyXliUSFvQCeVGn-UQFDudPTqQ1Gu32YN6gW3I777X7QG9bTvm0jtfunwNeScM7_LaSHZsunSBorRPl3myiR9d_m8-aSCGWHnvL2N3ypI1gBqykuPAxhClnR0L-9bwmidX7FEtjMaNu-DSavTO_jatHmjHBp8L-gN0F7ORxvAC2YsItsJRjsq7QdRhzQy1GwC8l3VFX-0Ox2YJ3fO3Ot1h2A4kh9FfnjC3BhXC91GCqYs45Bdxup_O3nUUa6bOGSFXRRUqX5vjovM_MPRIUTQ';

        $accountId = '57710429';
        if (env('DEVELOPMENT') == 1)
            $accountId = '8906761';

        $basePath = 'https://NA3.docusign.net/restapi';
        if (env('DEVELOPMENT') == 1)
            $basePath = 'https://demo.docusign.net/restapi';

        $config = new \DocuSign\eSign\Configuration();
        $config->setHost($basePath);
        $config->addDefaultHeader("Authorization", "Bearer " . $accessToken);
        $apiClient = new \DocuSign\eSign\Client\ApiClient($config);
        $envelopeApi = new \DocuSign\eSign\Api\EnvelopesApi($apiClient);

        $result = $envelopeApi->getEnvelope($accountId, $contract->envelopeId);
        $status = $result->getStatus();

        if ($status == 'completed' || $status == 'signed') {
            return redirect()->route('agentDashboard')->with('information', 'The contract has already been signed by both parties.');
        }

        if ($status == 'declined' || $status == 'voided') {
            return redirect()->route('agentDashboard')->with('errorToast', 'The contract has already been voided or declined.');
        }

        $recipients = $envelopeApi->listRecipients($accountId, $contract->envelopeId);
        $signers = $recipients->getSigners();
        $toRemind = array();

        foreach ($signers as $signer) {
            $status = $signer->getStatus();
            if ($status == 'signed' || $status == 'completed' || $status == 'faxpending')
                continue;
            array_push($toRemind, $signer);
        }

        $newRecipients = new Recipients(['signers' => $toRemind]);

        $updateOptions = new UpdateRecipientsOptions();
        $updateOptions->setResendEnvelope("true");

        $envelopeApi->updateRecipients($accountId, $contract->envelopeId, $newRecipients, $updateOptions);

        $fileName = basename($contract->contract_name);
        $history = new History($id, $fileName, 'Document has been resent.');

        return redirect()->route('agentDashboard')->with('successToast', 'Contract successfully resent.');
    }

    //all setup*** functions set up the proper tabs for the signers based
    //on the document type

    public function setupICA($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => '&sc',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_x_offset' => '-200',
        ]);

        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => '&sr',
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_x_offset' => '-200',
        ]);

        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => '&date',
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => '&daternn',
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
        ]);

        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '&name',
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_x_offset' => '-5',
            'anchor_y_offset' => '-1'
        ]);

        $printTitleTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '&title',
            'recipient_id' => '1',
            'tab_label' => 'PrintTitleTab',
            'anchor_x_offset' => '-5',
            'anchor_y_offset' => '-1',
            'required' => false
        ]);

        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'text_tabs' => [
                $printNameTab, $printTitleTab
            ]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN]
        ]));

        return $signerArray = [$signer, $signerRNN];
    }

    public function setupMSA($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => '(please print)',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_y_offset' => '-25',
            //'page_number' => '8',
            // 'x_position' => '350',
            //'y_position' => '10',
        ]);
        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'Jim Van Schaik, CEO',
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_y_offset' => '-25',
            'anchor_x_offset' => '15',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => 'clientdate',
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => 'jimdate',
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
        ]);

        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '(please print)',
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_x_offset' => '70',
            'anchor_y_offset' => '-5',
        ]);

        $initialHereTab = new \DocuSign\eSign\Model\InitialHere([
            'document_id' => $docId,
            'anchor_string' => 'PLEASE INITIAL',
            'anchor_x_offset' => '90',
            'anchor_y_offset' => '0',
            'recipient_id' => '1',
            'tab_label' => 'InitialHereTab',
        ]);

        $lawRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Law Firm',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'lawRadio',
            'value' => 'law',
            'required' => 'true',
        ]);

        $collectionRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Collection_Agency',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'collectionRadio',
            'value' => 'collection',
            'required' => 'true',
        ]);

        $originalRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Original Creditor',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'originalRadio',
            'value' => 'original',
            'required' => 'true',
        ]);

        $debtRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Debt Buyer',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'RadioTab',
            'value' => 'debt',
            'required' => 'true',
        ]);

        $loanRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Loan Originator',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'loanRadio',
            'value' => 'loan',
            'required' => 'true',
        ]);

        $otherRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Other (please note)',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'otherRadio',
            'value' => 'other',
            'required' => 'true',
        ]);

        $radioGroup = new \DocuSign\eSign\Model\RadioGroup([
            'document_id' => $docId,
            'recipient_id' => '1',
            'group_name' => 'BusinessTypes',
            'radios' => [$lawRadio, $collectionRadio, $originalRadio, $debtRadio, $loanRadio, $otherRadio],
        ]);

        $otherRadioReason = new \DocuSign\eSign\Model\Text([
            'conditional_parent_label' => 'BusinessTypes',
            'conditional_parent_value' => 'other',
            'document_id' => $docId,
            'anchor_string' => '(please note)',
            'anchor_x_offset' => '55',
            'anchor_y_offset' => '-5',
            'recipient_id' => '1',
            'tab_label' => 'otherRadioReasonTab',
        ]);

        $postCloseTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '(1-5)',
            'anchor_x_offset' => '30',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'PostCloseTab',
        ]);

        $companyEINTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'EIN #',
            'anchor_x_offset' => '30',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'EIN#Tab',
        ]);

        $companyPhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company Phone',
            'anchor_x_offset' => '90',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'CompanyPhoneTab',
        ]);

        $companyURLTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company URL',
            'anchor_x_offset' => '80',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'CompanyURLTab',
        ]);

        $payableNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Name:P',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'PayableNameTab',
        ]);

        $payablePhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Phone:P',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'PayablePhoneTab',
        ]);

        $payableCellTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '(cell):P',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'PayableCellTab',
        ]);

        $payableEmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Email:P',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'PayableEmailTab',
        ]);

        $invoiceApproverNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Name:I',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverNameTab',
        ]);

        $invoiceApproverPhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Phone:I',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverPhoneTab',
        ]);

        $invoiceApproverCellTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '(cell):I',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverCellTab',
        ]);

        $invoiceApproverEmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Email:I',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverEmailTab',
        ]);

        $executiveNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Name:E',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'ExecutiveNameTab',
        ]);

        $executivePhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Phone:E',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'ExecutivePhoneTab',
        ]);

        $executiveCellTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => '(cell):E',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'ExecutiveCellTab',
        ]);

        $executiveEmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Email:E',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'ExecutiveEmailTab',
        ]);
        ///////////////////////////////////////
        $companyOffersTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company offers:',
            'anchor_x_offset' => '-160',
            'anchor_y_offset' => '10',
            'recipient_id' => '1',
            'tab_label' => 'CompanyOffersTab',
            'width' => '540',
            'height' => '80',
            'font_size' => 'Size14',
        ]);

        $purposeTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company offers:',
            'anchor_x_offset' => '-160',
            'anchor_y_offset' => '-170',
            'recipient_id' => '1',
            'tab_label' => 'purposeTab',
            'width' => '540',
            'height' => '80',
            'font_size' => 'Size14',
        ]);

        $addressTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Address:',
            'anchor_x_offset' => '45',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'AddressTab',
        ]);

        $page7CompanyNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company Name:7',
            'anchor_x_offset' => '100',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'CompanyNameTab',
        ]);

        $page7ContactTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Contact:7',
            'anchor_x_offset' => '50',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'page7ContactTab',
        ]);

        $page7PhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Phone:7',
            'anchor_x_offset' => '45',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'page7PhoneTab',
        ]);

        $page7EmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Email:7',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'page7EmailTab',
        ]);

        $signHereAgain = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'Signature:7',
            'recipient_id' => '1',
            'tab_label' => 'SignHereAgainTab',
            'anchor_y_offset' => '0',
            'anchor_x_offset' => '70',
        ]);

        # DocuSign SignHere field/tab
        $dateHereAgain = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => 'Date:7',
            'recipient_id' => '1',
            'anchor_y_offset' => '0',
            'anchor_x_offset' => '40',
            'tab_label' => 'DateHereTab',
        ]);

        $headofSecurityTabName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Head of Security',
            'anchor_y_offset' => '13',
            'anchor_x_offset' => '-10',
            'recipient_id' => '1',
            'tab_label' => 'headofSecurityTab',
        ]);

        $headofSecurityTabEmail = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Head of Security',
            'anchor_y_offset' => '13',
            'anchor_x_offset' => '150',
            'recipient_id' => '1',
            'tab_label' => 'headofSecurityTabEmail',
        ]);

        $headofSecurityTabPhone = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Head of Security',
            'anchor_y_offset' => '13',
            'recipient_id' => '1',
            'anchor_x_offset' => '300',
            'tab_label' => 'headofSecurityTabPhone',
        ]);


        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere, $signHereAgain],
            'date_signed_tabs' => [$dateHere, $dateHereAgain],
            'initial_here_tabs' => [$initialHereTab],
            'radio_group_tabs' => [$radioGroup],
            'text_tabs' => [
                $printNameTab, $printNameTab, $postCloseTab, $companyEINTab, $companyPhoneTab, $companyURLTab, $payableNameTab, $payablePhoneTab, $payableCellTab, $payableEmailTab,
                $invoiceApproverNameTab, $invoiceApproverPhoneTab, $invoiceApproverCellTab, $invoiceApproverEmailTab, $executiveNameTab, $executivePhoneTab, $executiveCellTab, $executiveEmailTab,
                $purposeTab, $otherRadioReason, $companyOffersTab, $addressTab, $page7CompanyNameTab, $page7ContactTab, $page7PhoneTab, $page7EmailTab, $headofSecurityTabName, $headofSecurityTabEmail, $headofSecurityTabPhone
            ]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
        ]));

        return $signerArray = [$signer, $signerRNN];
    }

    public function setupMSANoFCRA($signerArray) {

    $signer = $signerArray[0];
    $signerRNN = $signerArray[1];
    $docId = $signerArray[2];

    # DocuSign SignHere field/tab
    $signHere = new \DocuSign\eSign\Model\SignHere([
        'document_id' => $docId,
        'anchor_string' => '(please print)',
        'recipient_id' => '1',
        'tab_label' => 'SignHereTab',
        'anchor_y_offset' => '-25',
        //'page_number' => '8',
        // 'x_position' => '350',
        //'y_position' => '10',
    ]);
    $signHereRNN = new \DocuSign\eSign\Model\SignHere([
        'document_id' => $docId,
        'anchor_string' => 'Jim Van Schaik, CEO',
        'recipient_id' => '2',
        'tab_label' => 'SignHereTab',
        'anchor_y_offset' => '-25',
        'anchor_x_offset' => '15',
    ]);

    # DocuSign SignHere field/tab
    $dateHere = new \DocuSign\eSign\Model\DateSigned([
        'document_id' => $docId,
        'anchor_string' => 'clientdate',
        'recipient_id' => '1',
        'tab_label' => 'DateHereTab',
    ]);

    $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
        'document_id' => $docId,
        'anchor_string' => 'jimdate',
        'recipient_id' => '2',
        'tab_label' => 'DateHereTab',
    ]);

    $printNameTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(please print)',
        'recipient_id' => '1',
        'tab_label' => 'PrintNameTab',
        'anchor_x_offset' => '70',
        'anchor_y_offset' => '-5',
    ]);

    $initialHereTab = new \DocuSign\eSign\Model\InitialHere([
        'document_id' => $docId,
        'anchor_string' => 'PLEASE INITIAL',
        'anchor_x_offset' => '90',
        'anchor_y_offset' => '0',
        'recipient_id' => '1',
        'tab_label' => 'InitialHereTab',
    ]);

    $postCloseTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(1-5)',
        'anchor_x_offset' => '30',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'PostCloseTab',
    ]);

    $companyEINTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'EIN #',
        'anchor_x_offset' => '30',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'EIN#Tab',
    ]);

    $companyPhoneTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Company Phone',
        'anchor_x_offset' => '90',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'CompanyPhoneTab',
    ]);

    $companyURLTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Company URL',
        'anchor_x_offset' => '80',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'CompanyURLTab',
    ]);
    $payableNameTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Name:P',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'PayableNameTab',
    ]);
    $payablePhoneTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(work):P',
        'anchor_x_offset' => '40',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'PayablePhoneTab',
    ]);

    $payableCellTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(cell):P',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'PayableCellTab',
    ]);

    $payableEmailTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Email:P',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'PayableEmailTab',
    ]);

    $invoiceApproverNameTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Name:I',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'InvoiceApproverNameTab',
    ]);

    $invoiceApproverPhoneTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(work):I',
        'anchor_x_offset' => '40',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'InvoiceApproverPhoneTab',
    ]);

    $invoiceApproverCellTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(cell):I',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'InvoiceApproverCellTab',
    ]);

    $invoiceApproverEmailTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Email:I',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'InvoiceApproverEmailTab',
    ]);

    $executiveNameTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Name:E',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'ExecutiveNameTab',
    ]);

    $executivePhoneTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(work):E',
        'anchor_x_offset' => '40',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'ExecutivePhoneTab',
    ]);

    $executiveCellTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => '(cell):E',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'ExecutiveCellTab',
    ]);

    $executiveEmailTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Email:E',
        'anchor_x_offset' => '35',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'ExecutiveEmailTab',
    ]);
    ///////////////////////////////////////
    $companyOffersTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Company offers:',
        'anchor_x_offset' => '-160',
        'anchor_y_offset' => '10',
        'recipient_id' => '1',
        'tab_label' => 'CompanyOffersTab',
        'width' => '540',
        'height' => '80',
        'font_size' => 'Size14',
    ]);

    $addressTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Address:',
        'anchor_x_offset' => '170',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'AddressTab',
    ]);

    $page7CompanyNameTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Company Name:7',
        'anchor_x_offset' => '80',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'CompanyNameTab',
    ]);

    $page7ContactTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Contact:7',
        'anchor_x_offset' => '50',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'page7ContactTab',
    ]);

    $page7PhoneTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Phone:7',
        'anchor_x_offset' => '45',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'page7PhoneTab',
    ]);

    $page7EmailTab = new \DocuSign\eSign\Model\Text([
        'document_id' => $docId,
        'anchor_string' => 'Email:7',
        'anchor_x_offset' => '40',
        'anchor_y_offset' => '-8',
        'recipient_id' => '1',
        'tab_label' => 'page7EmailTab',
    ]);

    $signHereAgain = new \DocuSign\eSign\Model\SignHere([
        'document_id' => $docId,
        'anchor_string' => 'Signature:7',
        'recipient_id' => '1',
        'tab_label' => 'SignHereAgainTab',
        'anchor_y_offset' => '0',
        'anchor_x_offset' => '70',
    ]);

    # DocuSign SignHere field/tab
    $dateHereAgain = new \DocuSign\eSign\Model\DateSigned([
        'document_id' => $docId,
        'anchor_string' => 'Date:7',
        'recipient_id' => '1',
        'anchor_y_offset' => '0',
        'anchor_x_offset' => '40',
        'tab_label' => 'DateHereTab',
    ]);


    # DocuSign DateSgined field/tab
    $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
        'sign_here_tabs' => [$signHere, $signHereAgain],
        'date_signed_tabs' => [$dateHere, $dateHereAgain],
        'initial_here_tabs' => [$initialHereTab],
        'text_tabs' => [
            $printNameTab, $printNameTab, $postCloseTab, $companyEINTab, $companyPhoneTab, $companyURLTab, $payableNameTab, $payablePhoneTab, $payableCellTab, $payableEmailTab,
            $invoiceApproverNameTab, $invoiceApproverPhoneTab, $invoiceApproverCellTab, $invoiceApproverEmailTab, $executiveNameTab, $executivePhoneTab, $executiveCellTab, $executiveEmailTab,
            $companyOffersTab, $addressTab, $page7CompanyNameTab, $page7ContactTab, $page7PhoneTab, $page7EmailTab
        ]
    ]));

    $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
        'sign_here_tabs' => [$signHereRNN],
        'date_signed_tabs' => [$dateHereRNN],
    ]));

    return $signerArray = [$signer, $signerRNN];
}

    public function setupNDA($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'CBy:',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '2',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
        ]);

        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'RNN Group, Inc. S',
            'anchor_y_offset' => '20',
            'anchor_x_offset' => '-25',
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'CBy:',
            'anchor_x_offset' => '140',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'RNN Group, Inc. S',
            'anchor_y_offset' => '20',
            'anchor_x_offset' => '110',
        ]);

        $fullNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'FullNameTab',
            'anchor_string' => 'Client:',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-5',
        ]);

        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_string' => 'CName:',
            'anchor_x_offset' => '45',
            'anchor_y_offset' => '-5',
        ]);

        $titleTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'TitleTab',
            'anchor_string' => 'CTitle:',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-7',
        ]);

        $printNameRNNTab  = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'PrintNameRNNTab',
            'anchor_string' => 'rName:',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-5',
        ]);


        $titleRNNTab  = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'TitleRNNTab',
            'anchor_string' => 'RTitle:',
            'anchor_x_offset' => '33',
            'anchor_y_offset' => '-5',
        ]);

        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'text_tabs' => [$fullNameTab, $printNameTab, $titleTab]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
            'text_tabs' => [$printNameRNNTab, $titleRNNTab]
        ]));

        return $signerArray = [$signer, $signerRNN];
    }

    public function setupAmendment($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];
        $numOfPages = $signerArray[3];

        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_string' => 'By:C',
            'anchor_x_offset' => '30',
        ]);
        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_string' => 'By:R ',
            'anchor_x_offset' => '30',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'Dated: C ',
            'anchor_x_offset' => '60',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'Dated: R ',
            'anchor_x_offset' => '60',
        ]);


        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_string' => 'Printed Name: C ',
            'anchor_x_offset' => '85',
            'anchor_y_offset' => '-8',
        ]);

        $titleTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'FullNameTab',
            'anchor_string' => 'Title: C ',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
        ]);

        $printNameRNNTab  = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'RNNTitle',
            'anchor_string' => 'Printed Name: R ',
            'anchor_x_offset' => '85',
            'anchor_y_offset' => '-8',
        ]);

        $titleRNNTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'TitleTab',
            'anchor_string' => 'Title: R ',
            'anchor_y_offset' => '-8',
            'anchor_x_offset' => '35',
        ]);

        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'text_tabs' => [$printNameTab, $titleTab]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
            'text_tabs' => [$printNameRNNTab, $titleRNNTab]
        ]));

        return $signerArray = [$signer, $signerRNN];
    }

    public function setupFCRA($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        # DocuSign SignHere field/tab
        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'page_number' => '3',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_string' => 'AUTHORIZED REPRESENTATIVE SIGNATURE',
            'anchor_y_offset' => '-17',
        ]);
        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_string' => 'JIM VAN SCHAIK',
            'anchor_y_offset' => '-30',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'AUTHORIZED REPRESENTATIVE SIGNATURE',
            'anchor_y_offset' => '-17',
            'anchor_x_offset' => '250',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'JIM VAN SCHAIK',
            'anchor_y_offset' => '-32',
            'anchor_x_offset' => '250',
        ]);


        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_string' => 'PRINTED NAME',
            'anchor_y_offset' => '-40',
        ]);

        $headofSecurityTabName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Head of Security',
            'anchor_y_offset' => '5',
            'anchor_x_offset' => '-10',
            'recipient_id' => '1',
            'tab_label' => 'headofSecurityTab',
        ]);

        $headofSecurityTabEmail = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Head of Security',
            'anchor_y_offset' => '5',
            'anchor_x_offset' => '150',
            'recipient_id' => '1',
            'tab_label' => 'headofSecurityTabEmail',
        ]);

        $headofSecurityTabPhone = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Head of Security',
            'anchor_y_offset' => '5',
            'recipient_id' => '1',
            'anchor_x_offset' => '300',
            'tab_label' => 'headofSecurityTabPhone',
        ]);


        $purposeTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'Purpose',
            'anchor_string' => 'PLEASE INITIAL:',
            'anchor_x_offset' => '-370',
            'anchor_y_offset' => '40',
            'width' => '450',
            'height' => '50',
        ]);

        $lawRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Law Firm',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'lawRadio',
            'value' => 'law',
            'required' => 'true',
        ]);

        $collectionRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Collection_Agency',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'collectionRadio',
            'value' => 'collection',
            'required' => 'true',
        ]);

        $originalRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Original Creditor',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'originalRadio',
            'value' => 'original',
            'required' => 'true',
        ]);

        $debtRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Debt Buyer',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'RadioTab',
            'value' => 'debt',
            'required' => 'true',
        ]);

        $loanRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Loan Originator',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'loanRadio',
            'value' => 'loan',
            'required' => 'true',
        ]);

        $otherRadio = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'Other (please note)',
            'anchor_x_offset' => '-20',
            'anchor_y_offset' => '-5',
            'tab_label' => 'otherRadio',
            'value' => 'other',
            'required' => 'true',
        ]);

        $radioGroup = new \DocuSign\eSign\Model\RadioGroup([
            'document_id' => $docId,
            'recipient_id' => '1',
            'group_name' => 'BusinessTypes',
            'radios' => [$lawRadio, $collectionRadio, $originalRadio, $debtRadio, $loanRadio, $otherRadio],
        ]);

        $otherRadioReason = new \DocuSign\eSign\Model\Text([
            'conditional_parent_label' => 'BusinessTypes',
            'conditional_parent_value' => 'other',
            'document_id' => $docId,
            'anchor_string' => '(please note)',
            'anchor_x_offset' => '55',
            'anchor_y_offset' => '-5',
            'recipient_id' => '1',
            'tab_label' => 'otherRadioReasonTab',
        ]);


        $initialHereTab = new \DocuSign\eSign\Model\InitialHere([
            'document_id' => $docId,
            'anchor_string' => 'PLEASE INITIAL:',
            'anchor_x_offset' => '-370',
            'anchor_y_offset' => '22',
            'recipient_id' => '1',
            'tab_label' => 'initialHereTab',
        ]);

        $companyOffers = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'companyOffers',
            'anchor_string' => 'Include what services or products your Company offers:',
            'anchor_x_offset' => '0',
            'anchor_y_offset' => '13',
        ]);

        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'initial_here_tabs' => [$initialHereTab],
            'radio_group_tabs' => [$radioGroup],
            'text_tabs' => [$printNameTab, $otherRadioReason, $headofSecurityTabName, $headofSecurityTabEmail, $headofSecurityTabPhone, $purposeTab, $companyOffers]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
        ]));


        return $signerArray = [$signer, $signerRNN];
    }

    public function setupYouNegotiate($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'By:',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_y_offset' => '-20',
        ]);

        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'Jim Van Schaik, CEO',
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_y_offset' => '-20',
            // 'anchor_x_offset' => '15',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => 'clientdate',
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => 'jimdate',
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
        ]);

        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'By:',
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_x_offset' => '15',
            'anchor_y_offset' => '-5',
        ]);

        $titleNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Title:',
            'recipient_id' => '1',
            'tab_label' => 'TitleNameTab',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '-5',
        ]);

        $companyEINTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'EIN#',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'EIN#Tab',
        ]);

        $companyPhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company Phone',
            'anchor_x_offset' => '73',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'CompanyPhoneTab',
        ]);

        $companyURLTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Company URL',
            'anchor_x_offset' => '70',
            'anchor_y_offset' => '-8',
            'recipient_id' => '1',
            'tab_label' => 'CompanyURLTab',
        ]);

        $accountPayableNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Account Payable Contact',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '20',
            'recipient_id' => '1',
            'tab_label' => 'PayableNameTab',
        ]);

        $accountPayablePhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Account Payable Contact',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '43',
            'recipient_id' => '1',
            'tab_label' => 'PayablePhoneTab',
        ]);

        $accountPayableCellTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Account Payable Contact',
            'anchor_x_offset' => '125',
            'anchor_y_offset' => '43',
            'recipient_id' => '1',
            'tab_label' => 'PayableCellTab',
        ]);

        $accountPayableEmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Account Payable Contact',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '70',
            'recipient_id' => '1',
            'tab_label' => 'PayableEmailTab',
        ]);

        $invoiceApproverNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Approver Contact',
            'anchor_x_offset' => '-8',
            'anchor_y_offset' => '20',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverNameTab',
        ]);

        $invoiceApproverPhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Approver Contact',
            'anchor_x_offset' => '-8',
            'anchor_y_offset' => '43',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverPhoneTab',
        ]);

        $invoiceApproverCellTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Approver Contact',
            'anchor_x_offset' => '90',
            'anchor_y_offset' => '43',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverCellTab',
        ]);

        $invoiceApproverEmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Approver Contact',
            'anchor_x_offset' => '-8',
            'anchor_y_offset' => '70',
            'recipient_id' => '1',
            'tab_label' => 'InvoiceApproverEmailTab',
        ]);

        $executiveNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Executive Contact Information:',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '20',
            'recipient_id' => '1',
            'tab_label' => 'ExecutiveNameTab',
        ]);

        $executivePhoneTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Executive Contact Information:',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '43',
            'recipient_id' => '1',
            'tab_label' => 'ExecutivePhoneTab',
        ]);

        $executiveCellTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Executive Contact Information:',
            'anchor_x_offset' => '125',
            'anchor_y_offset' => '43',
            'recipient_id' => '1',
            'tab_label' => 'ExecutiveCellTab',
        ]);

        $executiveEmailTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Executive Contact Information:',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '70',
            'recipient_id' => '1',
            'tab_label' => 'ExecutiveEmailTab',
        ]);

        $fullName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'authorize RNN Group',
            'recipient_id' => '1',
            'tab_label' => 'FullNameTab',
            'anchor_x_offset' => '-180',
            'anchor_y_offset' => '-5',
        ]);

        $accountType = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Checking/Saving',
            'recipient_id' => '1',
            'tab_label' => 'AccountTypeTab',
            'anchor_x_offset' => '80',
            // 'anchor_y_offset' => '5',
        ]);

        $accountName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Name on Acct',
            'recipient_id' => '1',
            'tab_label' => 'AccountNameTab',
            'anchor_x_offset' => '75',
            // 'anchor_y_offset' => '5',
        ]);

        $bankName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Bank Name',
            'recipient_id' => '1',
            'tab_label' => 'BankNameTab',
            'anchor_x_offset' => '75',
            'anchor_y_offset' => '5',
        ]);

        $routingNumber = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Bank Routing',
            'recipient_id' => '1',
            'tab_label' => 'RoutingNumberTab',
            'anchor_x_offset' => '75',
            'anchor_y_offset' => '-2',
        ]);

        $accountNumber = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Account Number',
            'recipient_id' => '1',
            'tab_label' => 'AccountNumber',
            'anchor_x_offset' => '75',
            'anchor_y_offset' => '-2',
        ]);

        $bankCityState = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Bank City/State',
            'recipient_id' => '1',
            'tab_label' => 'BankCityState',
            'anchor_x_offset' => '70',
            'anchor_y_offset' => '-2',
        ]);

        $signatureHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'SIGNATURE2',
            'recipient_id' => '1',
            'tab_label' => 'SignatureHereTab',
            'anchor_y_offset' => '-5',
            'anchor_x_offset' => '60',
        ]);

        $dateHere2 = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'anchor_string' => 'DATE2',
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_x_offset' => '60',
        ]);

        $specificPurpose = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Describe the specific purpose',
            'recipient_id' => '1',
            'tab_label' => 'SpecificPurposeTab',
            'anchor_y_offset' => '10',
            'width' => '560',
            'height' => '30',
        ]);

        $companyOffers = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Include what services or products your Company offers',
            'recipient_id' => '1',
            'tab_label' => 'CompanyOffersTab',
            'anchor_y_offset' => '10',
            'width' => '560',
            'height' => '30',
       ]);

        $initialHereTab1 = new \DocuSign\eSign\Model\InitialHere([
            'document_id' => $docId,
            'anchor_string' => '[Please initial regarding Section 1 responses.]',
            'anchor_x_offset' => '-28',
            'recipient_id' => '1',
            'tab_label' => 'InitialHereTab',
        ]);
        
        $initialHereTab2 = new \DocuSign\eSign\Model\InitialHere([
            'document_id' => $docId,
            'anchor_string' => 'By initialing,',
            'anchor_x_offset' => '-25',
            'recipient_id' => '1',
            'tab_label' => 'InitialHereTab',
        ]);

        $name = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Name:l',
            'recipient_id' => '1',
            'tab_label' => 'NameTab',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '-5',
       ]);


        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere, $signatureHere],
            'date_signed_tabs' => [$dateHere, $dateHere2],
            'initial_here_tabs' => [$initialHereTab1, $initialHereTab2],
            'text_tabs' => [
                $printNameTab, $titleNameTab,
                $fullName, $accountType, $accountName, $bankName, $routingNumber, $accountNumber, $bankCityState,
                $companyEINTab, $companyPhoneTab, $companyURLTab,
                $accountPayableNameTab, $accountPayablePhoneTab, $accountPayableCellTab, $accountPayableEmailTab,
                $invoiceApproverNameTab, $invoiceApproverPhoneTab, $invoiceApproverCellTab, $invoiceApproverEmailTab,
                $executiveNameTab, $executivePhoneTab, $executiveCellTab, $executiveEmailTab,
                $specificPurpose, $companyOffers, $name
            ]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
        ]));

        return $signerArray = [$signer, $signerRNN];
    }

    public function setupCertFCRA($signerArray)
    {
        $signer = $signerArray[0];
        $docId = $signerArray[2];


        $checkHere = new \DocuSign\eSign\Model\Radio([
            'document_id' => $docId,
            'anchor_string' => 'By checking',
            'anchor_x_offset' => '-23',
            'anchor_y_offset' => '-8',
            'tab_label' => 'SignHereTab',
            'value' => 'accept',
            'required' => 'true',
        ]);

        $radioGroup = new \DocuSign\eSign\Model\RadioGroup([
            'document_id' => $docId,
            'recipient_id' => '1',
            'group_name' => 'Check',
            'radios' => [$checkHere],
        ]);


        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'By:',
            'anchor_x_offset' => '30',
            'anchor_y_offset' => '-2',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
        ]);


        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'Date:',
            'anchor_x_offset' => '30',
        ]);


        $titleTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'TitleTab',
            'anchor_string' => 'Title:',
            'anchor_x_offset' => '30',
            'anchor_y_offset' => '-5',
        ]);

        $addressTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'AddressTab',
            'anchor_string' => 'Address:',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-5',
            'width' => '320',
            'height' => '45',
        ]);


        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'text_tabs' => [$titleTab, $addressTab],
            'radio_group_tabs' => [$radioGroup]
        ]));

        return $signerArray = [$signer];
    }

    public function setupNameChangeAmendment($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        # DocuSign SignHere field/tab
        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_string' => 'By:C',
            'anchor_x_offset' => '30',
        ]);
        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_string' => 'By:R ',
            'anchor_x_offset' => '30',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'Dated: C ',
            'anchor_x_offset' => '60',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'Dated: R ',
            'anchor_x_offset' => '60',
        ]);


        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_string' => 'Printed Name: C ',
            'anchor_x_offset' => '70',
            'anchor_y_offset' => '-8',
        ]);

        $titleTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'FullNameTab',
            'anchor_string' => 'Title: C ',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-8',
        ]);

        $printNameRNNTab  = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'RNNTitle',
            'anchor_string' => 'Printed Name: R ',
            'anchor_x_offset' => '70',
            'anchor_y_offset' => '-8',
        ]);

        $titleRNNTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'TitleTab',
            'anchor_string' => 'Title: R ',
            'anchor_y_offset' => '-8',
            'anchor_x_offset' => '35',
        ]);

        $originalName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Original Name:',
            'recipient_id' => '1',
            'tab_label' => 'originalNameTab',
            'anchor_x_offset' => '65',
            'anchor_y_offset' => '-5',
        ]);

        $newName = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'New Name:',
            'recipient_id' => '1',
            'tab_label' => 'newNameTab',
            'anchor_x_offset' => '50',
            'anchor_y_offset' => '-5',
        ]);

        $newAddress = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Address:',
            'recipient_id' => '1',
            'tab_label' => 'newAddressTab',
            'anchor_x_offset' => '35',
            'anchor_y_offset' => '-5',
        ]);

        $accessChanges = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Changes:',
            'recipient_id' => '1',
            'tab_label' => 'accessChangesTab',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-5',
        ]);

        $ownershipChange = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'of Client:',
            'recipient_id' => '1',
            'tab_label' => 'ownershipChangeTab',
            'anchor_x_offset' => '40',
            'anchor_y_offset' => '-5',
        ]);

        $contactInformationChange = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Contact Information:',
            'recipient_id' => '1',
            'tab_label' => 'contactInformationChangeTab',
            'anchor_x_offset' => '90',
            'anchor_y_offset' => '-5',
        ]);

        $useOfData = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'If client is using FCRA',
            'recipient_id' => '1',
            'tab_label' => 'useOfDataTab',
            // 'anchor_x_offset' => '-20',
            'anchor_y_offset' => '50',
        ]);



        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'text_tabs' => [
                $printNameTab, $titleTab, $originalName, $newAddress, $newName, $accessChanges, $ownershipChange, $contactInformationChange, $useOfData
               ]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
            'text_tabs' => [$printNameRNNTab, $titleRNNTab]
        ]));

        return $signerArray = [$signer, $signerRNN];
    }

    public function setupResellerAgreement($signerArray)
    {
        $signer = $signerArray[0];
        $signerRNN = $signerArray[1];
        $docId = $signerArray[2];

        $signHere = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'Name:',
            'recipient_id' => '1',
            'tab_label' => 'SignHereTab',
            'anchor_y_offset' => '-30',
            'anchor_x_offset' => '30',
        ]);

        $signHereRNN = new \DocuSign\eSign\Model\SignHere([
            'document_id' => $docId,
            'anchor_string' => 'Jim Van Schaik, CEO',
            'recipient_id' => '2',
            'tab_label' => 'SignHereTab',
            'anchor_y_offset' => '-30',
            'anchor_x_offset' => '30',
        ]);

        # DocuSign SignHere field/tab
        $dateHere = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'clientdate',
        ]);

        $dateHereRNN = new \DocuSign\eSign\Model\DateSigned([
            'document_id' => $docId,
            'recipient_id' => '2',
            'tab_label' => 'DateHereTab',
            'anchor_string' => 'jimdate',
        ]);

        $printNameTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'recipient_id' => '1',
            'tab_label' => 'PrintNameTab',
            'anchor_string' => 'Name:',
            'anchor_x_offset' => '30',
            'anchor_y_offset' => '-8',
        ]);

        $titleTab = new \DocuSign\eSign\Model\Text([
            'document_id' => $docId,
            'anchor_string' => 'Title:',
            'recipient_id' => '1',
            'tab_label' => 'TitleTab',
            'anchor_x_offset' => '25',
            'anchor_y_offset' => '-5',
        ]);

        # DocuSign DateSgined field/tab
        $signer->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHere],
            'date_signed_tabs' => [$dateHere],
            'text_tabs' => [
                $printNameTab, $titleTab
               ]
        ]));

        $signerRNN->setTabs(new \DocuSign\eSign\Model\Tabs([
            'sign_here_tabs' => [$signHereRNN],
            'date_signed_tabs' => [$dateHereRNN],
        ]));

        return $signerArray = [$signer, $signerRNN];
    }
}