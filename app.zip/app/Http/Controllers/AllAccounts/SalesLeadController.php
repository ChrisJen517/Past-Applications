<?php

namespace App\Http\Controllers\AllAccounts;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Sales_Leads;
use App\Lead_Contacts;
use App\Lead_Activity;
use App\User;
use App\Worked_History;
use App\Verified_Leads;
use Carbon\Carbon;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ExportContacts;
use App\Exports\ExportAllContacts;
use \stdClass;

class SalesLeadController extends Controller
{

    /**
     * Show the sales leads view.
     *
     * @return view sales leads
     */
    public function showSalesLeads()
    {
        $leads = Sales_Leads::get();

        return view('all.salesLeads')->with('leads', $leads);
    }

    public function showMySalesLeads()
    {
        $user_id = Auth::user()->id;
        $leads = Sales_Leads::where('agent_id',$user_id)->get();
        return view('all.salesLeads')->with('leads', $leads);
    }

    public function exportContacts(Request $request) {
        $leads = Sales_Leads::select('id', 'company_name')
        ->with(['contacts' => function($query) {
            $query->select('lead_reference_id', 'lead_title', 'first_name', 'last_name', 'phone', 'phone_ext', 'email');
        }])
        ->whereIn('id', $request->leads)
        ->get();

        $leads_and_contacts = [];
        foreach($leads as $lead) {
            foreach($lead->contacts as $contact) {
                array_push($leads_and_contacts, ['company_name' => $lead->company_name, 'lead_title' => $contact->lead_title, 'first_name' => $contact->first_name, 'last_name' => $contact->last_name, 'phone' => $contact->phone, 'phone_ext' => $contact->phone_ext, 'email' => $contact->email]);
            }
        }

        $fileName = 'contacts' . time() . '.xlsx';
        Excel::store(new ExportContacts($leads_and_contacts), $fileName, 'exports');
        return response(['fileName' => $fileName]);
    }

    public function exportAllContacts($unworked) {
        $fileName = 'contacts' . time() . '.xlsx';
        Excel::store(new ExportAllContacts($unworked), $fileName, 'exports');
        return redirect()->route('downloadExport', $fileName);
    }

    public function exportLeadsJson(Request $request, $unworked) {

        if (Auth::user()->role == 'manager') {
            $columns = array(
                0 => 'id',
                1 => 'id',
                2 => 'agent_id',
                3 => 'company_name',
                4 => 'industry',
                5 => 'company_state',
                6 => 'updated_at',
                7 => 'assign_agent',
                8 => 'action'
            );
        } else {
            $columns = array(
                0 => 'id',
                1 => 'agent_id',
                2 => 'company_name',
                3 => 'industry',
                4 => 'company_state',
                5 => 'updated_at',
                6 => 'action'
            );
        }

        $columnsToSelect = array(
            'id',
            'agent_id',
            'company_name',
            'industry',
            'company_state',
            'updated_at',
            'sales_agent'
        );

        $query = 'from sales_leads';

        if ($unworked) {
            $query .= ' where (closed != 1 or closed is null)';
            $totalData = Sales_Leads::where('closed', '!=', '1')->orWhereNull('closed')->count();
        } else {
            $query .= ' where (closed = 1)';
            $totalData = Sales_Leads::where('closed', '=', '1')->count();
        }

        $totalFiltered = $totalData;

        $limit = $request->input('length');
        $start = $request->input('start');
        $order = $columns[$request->input('order.0.column')];
        $dir = $request->input('order.0.dir');

        $search = "";

        if (empty($request->input('search.value'))) {

            $query .= "ORDER BY `${order}` ${dir}
                        LIMIT ${limit} OFFSET ${start};";

            $leads = DB::select('select ' . implode(',', $columnsToSelect) . ' ' . $query);

        } else {
            $search = str_replace("\"", "", $request->input('search.value'));
            $search = str_replace("'", "", $request->input('search.value'));

            $query .= " AND (id LIKE '%${search}%' OR agent_id LIKE '%${search}%' OR sales_agent LIKE '%${search}%' OR company_name LIKE '%${search}%' OR industry LIKE '%${search}%' OR company_state LIKE '%${search}%' OR updated_at LIKE '%${search}%')";

            $countSelected = DB::select("SELECT COUNT(*) as count ".$query.";");
            $totalFiltered = $countSelected[0]->count;

            $query .= " ORDER BY `${order}` ${dir}
                        LIMIT ${limit} OFFSET ${start};";

            $leads = DB::select('select ' . implode(',', $columnsToSelect) . ' ' . $query);
        }

        $data = array();
        if(!empty($leads)) {
            foreach ($leads as $lead) {
                $assignAgentAction = $lead->agent_id == null ? 'Assign Agent' : 'Reassign Agent';
                $assignAgentMarkup =
                "<td class=\"text-center\">
                    <button class=\"btn btn-info btn-sm\" data-toggle=\"modal\" id-name=\"{$lead->id}\"
                        company-name=\"{$lead->company_name}\" data-target=\"#addToAgent\">
                        {$assignAgentAction}
                    </button>
                </td>";

                $actionRoute = route('workLead', $lead->id);
                $actionMarkup =
                "<td class=\"text-center\">
                    <form action=\"{$actionRoute}\" method=\"GET\" id=\"showLeadForm\"
                        enctype=\"multipart/form-data\">
                        <input class=\"form-control\" type=\"hidden\" id=\"leadId\" name=\"id\"
                                value=\"{$lead->id}\">
                            <button class=\"btn btn-info text-center\" type=\"submit\"
                                style=\"color: white;\">Work</button>
                    </form>
                </td>";

                $nestedData['id'] = $lead->id;
                $nestedData['agent_id'] = empty($lead->sales_agent) ? $lead->agent_id : $lead->sales_agent . ' (' . $lead->agent_id . ')';
                $nestedData['company_name'] = $lead->company_name;
                $nestedData['industry'] = $lead->industry;
                $nestedData['company_state'] = $lead->company_state;
                $nestedData['updated_at'] = date('j M Y h:i a',strtotime($lead->updated_at));
                if (Auth::user()->role == 'manager')
                    $nestedData['assign_agent'] = $assignAgentMarkup;
                $nestedData['action'] = $actionMarkup;
                $data[] = $nestedData;
            }
        }

        $json_data = array(
                    "draw"            => intval($request->input('draw')),
                    "recordsTotal"    => intval($totalData),
                    "recordsFiltered" => intval($totalFiltered),
                    "data"            => $data,
                    "search"          => $search,
                    );

        echo json_encode($json_data);

    }

    public function showLead($id)
    {
        // $timeStart = microtime(true);

        $lead = Sales_Leads::where('id', $id)->first();
        $lead_contacts = Lead_Contacts::where('lead_reference_id', $id)->get();
        if ($lead->working == 1)
            return back()->with('error', "This account is already being worked.");

        $history = Worked_History::where('lead_reference_id', $id)
        ->orderByDesc("updated_at", "desc")
        ->get();

        $activities = new stdClass;
        $upcoming = 'Upcoming and Overdue';
        $activities->$upcoming = [];

        $statuses = [
            'Un-Worked Lead',
            'Intro Call Scheduled',
            'Deliverables Sent',
            'Deliverables Due',
            'Presentation Scheduled',
            'Contract Sent',
            'Implementation'
        ];

        $subjects = [
            "CALL",
            "EMAIL",
            "SETUP 15 MIN",
            "ZOOM PRESENTATION",
            "LAST IMPLEMENTATION CALL",
            "TECHNICAL CALL",
            "ONSITE MEETING",
            "PRODUCT LIST",
            "OTHER"
        ];

        $activitiesQuery = Lead_Activity::selectRaw(
            "id, lead_reference_id, subject, description, date, attachment,
            assigned_to, location, contacts, related_to, is_complete, type, agent_name,
            date_format(date, '%M %Y') dateFormatted, date dateDue")
            ->where('lead_reference_id', '=', $lead->id)
            ->with(['notes' => function($query) {
                $query->select('activity_reference_id', 'note', 'agent_name', 'created_at')->orderBy('created_at', 'desc');
            }])
            ->orderBy('dateDue', 'desc')->get();

        foreach($activitiesQuery as $activity) {
            $group = $activity->dateFormatted;
            if ((!($activity->type == 'task' && $activity->is_complete == '1')) && ($activity->dateDue > Carbon::now() || ($activity->dateDue < Carbon::now() && $activity->type == 'task' && $activity->is_complete == '0'))) {
                array_push($activities->$upcoming, $activity);
                if (!isset($activities->$group)) $activities->$group = [];
            }
            else if (!isset($activities->$group)) $activities->$group = [$activity];
            else array_push($activities->$group, $activity);
        }

        // $timeEnd = microtime(true);

        // return response(['activities' => $activities]);

        $agents = User::select('id', 'name_first', 'name_last')->where('is_archived', '=', '0')->orderBy('name_first')->get();

        return view('all.sales_leads.salesLeadsForm')->with('history', $history)->with('lead', $lead)->with('lead_contacts',$lead_contacts)->with('agents', $agents)->with('activities', $activities)->with('statuses', $statuses)->with('subjects', $subjects);
    }

    public function getEventWidget($id)
    {
        $lead = Sales_Leads::where('id', $id)->first();
        $lead_contacts = Lead_Contacts::where('lead_reference_id', $id)->get();
        if ($lead->working == 1)
            return back()->with('error', "This account is already being worked.");

        $history = Worked_History::where('lead_reference_id', $id)
        ->orderByDesc("updated_at", "desc")
        ->get();

        $activities = new stdClass;
        $upcoming = 'Upcoming and Overdue';
        $activities->$upcoming = [];

        $statuses = [
            'Un-Worked Lead',
            'Intro Call Scheduled',
            'Deliverables Sent',
            'Deliverables Due',
            'Presentation Scheduled',
            'Contract Sent',
            'Implementation'
        ];

        $subjects = [
            "CALL",
            "EMAIL",
            "SETUP 15 MIN",
            "ZOOM PRESENTATION",
            "LAST IMPLEMENTATION CALL",
            "TECHNICAL CALL",
            "ONSITE MEETING",
            "PRODUCT LIST",
            "OTHER"
        ];

        $activitiesQuery = Lead_Activity::selectRaw(
            "id, lead_reference_id, subject, description, date, attachment,
            assigned_to, location, contacts, related_to, is_complete, type, agent_name,
            date_format(date, '%M %Y') dateFormatted, date dateDue")
            ->where('lead_reference_id', '=', $lead->id)
            ->with(['notes' => function($query) {
                $query->select('activity_reference_id', 'note', 'agent_name', 'created_at')->orderBy('created_at', 'desc');
            }])
            ->orderBy('dateDue', 'desc')->get();

        foreach($activitiesQuery as $activity) {
            $group = $activity->dateFormatted;
            if ((!($activity->type == 'task' && $activity->is_complete == '1')) && ($activity->dateDue > Carbon::now() || ($activity->dateDue < Carbon::now() && $activity->type == 'task' && $activity->is_complete == '0'))) {
                array_push($activities->$upcoming, $activity);
                if (!isset($activities->$group)) $activities->$group = [];
            }
            else if (!isset($activities->$group)) $activities->$group = [$activity];
            else array_push($activities->$group, $activity);
        }

        $agents = User::select('id', 'name_first', 'name_last')->where('is_archived', '=', '0')->orderBy('name_first')->get();

        $html = view('Includes.widgets.eventWidget')->with('history', $history)->with('lead', $lead)->with('lead_contacts',$lead_contacts)->with('agents', $agents)->with('activities', $activities)->with('statuses', $statuses)->with('subjects', $subjects)->render();
        return response()->json(compact('html'));
    }

    public function updateLead(Request $request)
    {
        $history = new Worked_History;
        $history->agent_id = Auth::user()->id;
        $history->agent_name = Auth::user()->name_first . ' ' . Auth::user()->name_last;
        $history->capcode = $request->capcode;
        $history->notes = $request->notes;
        $history->lead_reference_id = $request->lead_id;
        $history->save();

        $lead = Sales_Leads::where('id', $request->lead_id)->first();

        $updated = "";
        if ($lead->industry != $request->industry) {
            $lead->industry = $request->industry;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed industry to ' . $request->industry;
        }
        if ($lead->employees_count != $request->employees_count) {
            $lead->employees_count = $request->employees_count;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed employees count to ' . $request->employees_count;
        }
        if ($lead->company_email != $request->company_email) {
            $lead->company_email = $request->company_email;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company email to ' . $request->company_email;
        }
        if ($lead->company_phone != $request->company_phone) {
            $lead->company_phone = $request->company_phone;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company phone to ' . $request->company_phone;
        }
        if ($lead->company_fax != $request->company_fax) {
            $lead->company_fax = $request->company_fax;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company fax to ' . $request->company_fax;
        }
        if ($lead->company_address != $request->address) {
            $lead->company_address = $request->address;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company address to ' . $request->address;
        }
        if ($lead->company_city != $request->city) {
            $lead->company_city = $request->city;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company city to ' . $request->city;
        }
        if ($lead->company_state != $request->state) {
            $lead->company_state = $request->state;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company state to ' . $request->state;
        }
        if ($lead->company_zip != $request->zip) {
            $lead->company_zip = $request->zip;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company zip to ' . $request->zip;
        }
        if ($lead->company_url != $request->company_url) {
            $lead->company_url = $request->company_url;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed company url to ' . $request->company_url;
        }
        if ($lead->capcode != $request->capcode) {
            $lead->capcode = $request->capcode;
            $updated = $updated . (empty($updated) ? '' : ', ') . 'Changed capcode to ' . $request->capcode;
        }
        $lead->last_worked = $history->created_at;
        $lead->notes = $request->notes;
        $lead->save();

        if (!empty($updated)) {
            $history->change_notes = $updated;
            $history->save();
        }

        if($request->submit == "update")
        {
            return back()->with('success', 'Lead Updated.');
        }
        else if($request->submit == "update_and_next"){

            $user_id = Auth::user()->id;
            $lead = Sales_Leads::where('agent_id',$user_id)->whereIn('capcode',array('','2000'))->whereDate('last_worked','<=',
            now()->subDays(1)->setTime(0,0,0)->toDateString())->first();
            if($lead == null){
                $leads = Sales_Leads::get();
                return view('all.salesLeads')->with('leads', $leads)->with('success', 'No leads remaining in your queue.');
                //return view('all.salesLeads');
            }

            $lead_contacts = Lead_Contacts::where('lead_reference_id',$lead->id)->get();

            $history = Worked_History::where('lead_reference_id', $lead->id)
            ->orderByDesc("updated_at", "desc")
            ->get();

            return view('all.sales_leads.salesLeadsForm')->with('history', $history)->with('lead', $lead)->with('lead_contacts',$lead_contacts);
            //return view('all.salesLeads')->with('leads', $leads);
        }






        //return redirect('/salesLeads')->with('success', $lead->capcode == 2000 ? 'Lead Closed' : 'Lead Updated');
    }

    public function addLeadContact(Request $request)
    {
        $leadContact = Lead_Contacts::where('id', $request->contact_id)->first();
        if($leadContact == null)
        {
            $leadContact = new Lead_Contacts();
            $return_status=0;
        }

        $leadContact->lead_reference_id = $request->lead_reference_id;
        $leadContact->lead_title = Strip_tags($request->lead_title);
        $leadContact->first_name = Strip_tags($request->lead_first_name);
        $leadContact->last_name = Strip_tags($request->lead_last_name);
        $leadContact->phone = Strip_tags(preg_replace('/[^0-9]/', '', $request->lead_phone));
        $leadContact->phone_ext = Strip_tags(preg_replace('/[^0-9]/', '', $request->lead_phone_ext));
        $leadContact->email = Strip_tags($request->lead_email);
        $leadContact->linked_in = Strip_tags($request->contact_linked_in);
        $leadContact->save();
        return $leadContact->id;
    }

    public function showSalesLeadQueues()
    {
        $leads = DB::select("select
        id as agent_id,
        concat(name_first,' ',name_last) as agent_name,
        (select count(*) from sales_leads where agent_id=users.id AND capcode IN('',NULL)) as new_accounts,
        (select count(*) from sales_leads where agent_id=users.id AND capcode = '2000') as worked_accounts,
        (select count(*) from sales_leads where agent_id=users.id AND capcode != '1000') as total_accounts
        from users order by total_accounts desc, agent_name asc;");

        $total_unassigned = Sales_Leads::whereNull('agent_id')->count();
        $unassigned = DB::table('sales_leads')
                ->whereNull('agent_id')
                ->select('industry', DB::raw('count(*) as total'))
                ->groupBy('industry')
                ->get();

        // $history = Worked_History::groupBy('agent_id')->get();
        return view('manager.salesLeadQueues')->with('leads', $leads)->with('total_unassigned',$total_unassigned)->with('unassigned', $unassigned);
    }

    public function showSalesLeadStats()
    {
        $statuses = [
            'Un-Worked Lead',
            'Intro Call Scheduled',
            'Deliverables Sent',
            'Deliverables Due',
            'Presentation Scheduled',
            'Contract Sent',
            'Implementation'
        ];

        $get_columns_query = '';
        for ($i = 0; $i < count($statuses); $i++) {
            $get_columns_query .= ", (select count(*) from sales_leads where agent_id=users.id AND column_number={$i}) as column{$i}";
        }

        $leads = DB::select("select
        id as agent_id,
        is_archived,
        concat(name_first,' ',name_last) as agent_name"
        . $get_columns_query .
        " FROM users WHERE is_archived=0");

        $total_unassigned = Sales_Leads::whereNull('agent_id')->count();
        $unassigned = DB::table('sales_leads')
                ->whereNull('agent_id')
                ->select('industry', DB::raw('count(*) as total'))
                ->groupBy('industry')
                ->get();

        return view('manager.salesLeadStats')->with('leads', $leads)->with('statuses', $statuses)->with('total_unassigned',$total_unassigned)->with('unassigned', $unassigned);
    }

    public function showAgentLeads(Request $request)
    {
        if(empty($request->id))
            $leads = Sales_Leads::whereNull('agent_id')->get();
        else
        $leads = Sales_Leads::where('agent_id', $request->id)->get();
        return view('manager.agentLeads')->with('leads',$leads);
    }

    public function emptyAgentQueue(Request $request)
    {
        if(empty($request->id))
            $leads = Sales_Leads::whereNull('agent_id')->get();
        else
        $leads = Sales_Leads::where('agent_id', $request->id)->get();
        return view('manager.agentLeads')->with('leads',$leads);
    }

    public function clearAgentLeads(Request $request)
    {
        Sales_Leads::where('agent_id',$request->id)->where('capcode', '!=', '1000')->update(array('agent_id' => NULL));
        return redirect()->route('showSalesLeadsQueues')->with('success', 'Queue has been un-assigned.');
    }
    public function assignAgentLeads(Request $request)
    {
        $before = count(Sales_Leads::where('agent_id', '=', $request->id)->where('capcode', '!=', '1000')->get());

        // if ($before >= $request->accounts) {
        //     return redirect()->route('showSalesLeadsQueues')->with('error', 'Agent already has the maximum amount of leads');
        // }

        // $limit = $request->accounts - $before;

        $assigned = Sales_Leads::whereNull('agent_id')->where('capcode', '!=', '1000');

        if ($request->industry != "") {
            $assigned = $assigned->where('industry', '=', $request->industry);
        }

        $assigned = $assigned->limit($request->accounts);
        $assigned->update(array('agent_id' => $request->id));
        $after = count(Sales_Leads::where('agent_id', '=', $request->id)->where('capcode', '!=', '1000')->get());

        $count = $after - $before;
        if ($count > 0)
            return redirect()->route('showSalesLeadsQueues')->with('success', 'Agents queue has been filled with ' . $count . ' lead' . ($count > 1 ? 's' : ''));
        else
            return redirect()->route('showSalesLeadsQueues')->with('error', 'No leads found');
    }


    public function closeLead(Request $request)
    {
        $sales_lead = Sales_Leads::where('id', $request->lead_id)->first();
        $sales_lead->last_worked = date('m/d/Y h:i:s a', time());

        if($request->submit == "no_info_on_business"){
            $sales_lead->status = 'no_info_on_business';
        }

        $sales_lead->closed = 1;
        $sales_lead->agent_id = Auth::user()->id;

        if ($sales_lead->column_number != $request->status) {
            $sales_lead->column_number = $request->status;
            $sales_lead->column_position = 0;
        }

        $sales_lead->industry = $request->industry;
        $sales_lead->employees_count = $request->employees_count;
        $sales_lead->company_name = $request->company_name;
        $sales_lead->company_address = $request->address;
        $sales_lead->company_address_2 = $request->address2;
        $sales_lead->company_email = $request->email;
        $sales_lead->company_phone = preg_replace('/[^0-9]/', '', $request->company_phone);
        $sales_lead->company_city = $request->city;
        $sales_lead->company_state = $request->state;
        $sales_lead->company_zip = $request->zip;
        $sales_lead->company_url = $request->company_url;
        $sales_lead->company_linkedin = $request->company_linkedin;
        $sales_lead->last_worked = date('m/d/Y h:i:s a', time());
        $sales_lead->country = $request->country;
        $sales_lead->description = $request->description;
        $sales_lead->save();

        if($request->submit == "update")
        {
            if($request->page)
                return redirect()->route('workLead', $request->lead_id);
            else{
                return back()->with('success', "Account updated!");
            }
        }
        else if($request->submit == "update_and_next"){
            return redirect()->route('workNextLead')->with('success', 'Lead Updated and new lead loaded.');
        }
        else if($request->submit == "no_info_on_business"){
            if($request->page)
                return redirect()->route('workNextLead')->with('success', 'Lead Updated and new lead loaded.');
            else{
                return back()->with('success', "Account updated!");
            }
        }

        //return redirect('/salesLeads')->with('success', $lead->capcode == 2000 ? 'Lead Closed' : 'Lead Updated');
    }

    // NOAH NEW
    public function workLead($id)
    {
        $lead = Sales_Leads::where('id', $id)->first();
        $lead_contacts = Lead_Contacts::where('lead_reference_id', $lead->id)->get();
        $verified_lead = Verified_Leads::where('lead_reference_id', $lead->id)->first();

        $agents = User::select('id', 'name_first', 'name_last')->where('is_archived', '=', '0')->orderBy('name_first')->get();

        $activities = new stdClass;
        $upcoming = 'Upcoming and Overdue';
        $activities->$upcoming = [];

        $statuses = [
            'Un-Worked Lead',
            'Intro Call Scheduled',
            'Deliverables Sent',
            'Deliverables Due',
            'Presentation Scheduled',
            'Contract Sent',
            'Implementation'
        ];

        $subjects = [
            "CALL",
            "EMAIL",
            "SETUP 15 MIN",
            "ZOOM PRESENTATION",
            "LAST IMPLEMENTATION CALL",
            "TECHNICAL CALL",
            "ONSITE MEETING",
            "PRODUCT LIST",
            "OTHER"
        ];

        $activitiesQuery = Lead_Activity::selectRaw(
            "id, lead_reference_id, subject, description, date, attachment,
            assigned_to, location, contacts, related_to, is_complete, type, agent_name,
            date_format(date, '%M %Y') dateFormatted, date dateDue")
            ->where('lead_reference_id', '=', $lead->id)
            ->with(['notes' => function($query) {
                $query->select('activity_reference_id', 'note', 'agent_name', 'created_at')->orderBy('created_at', 'desc');
            }])
            ->orderBy('dateDue', 'desc')->get();

        $notes = Lead_Activity::where('type', '=', 'note')->where('lead_reference_id', '=', $lead->id)->orderBy('created_at', 'desc')->get();

        foreach($activitiesQuery as $activity) {
            $group = $activity->dateFormatted;
            if ((!($activity->type == 'task' && $activity->is_complete == '1')) && ($activity->dateDue > Carbon::now() || ($activity->dateDue < Carbon::now() && $activity->type == 'task' && $activity->is_complete == '0'))) {
                array_push($activities->$upcoming, $activity);
                if (!isset($activities->$group)) $activities->$group = [];
            }
            else if (!isset($activities->$group)) $activities->$group = [$activity];
            else array_push($activities->$group, $activity);
        }

        return view('all.sales_leads.workLeadFormPage')->with('lead', $lead)->with('lead_contacts', $lead_contacts)->with('verified_lead', $verified_lead)
        ->with('activities', $activities)->with('agents', $agents)->with('notes', $notes)->with('statuses', $statuses)->with('subjects', $subjects)->with('page', true);
    }

    public function workLeadForm($id)
    {
        $lead = Sales_Leads::where('id', $id)->first();
        $lead_contacts = Lead_Contacts::where('lead_reference_id', $id)->get();
        $verified_lead = Verified_Leads::where('lead_reference_id', $lead->id)->first();

        if ($lead->working == 1)
            return back()->with('error', "This account is already being worked.");

        $history = Worked_History::where('lead_reference_id', $id)
        ->orderByDesc("updated_at", "desc")
        ->get();

        $activities = new stdClass;
        $upcoming = 'Upcoming and Overdue';
        $activities->$upcoming = [];

        $statuses = [
            'Un-Worked Lead',
            'Intro Call Scheduled',
            'Deliverables Sent',
            'Deliverables Due',
            'Presentation Scheduled',
            'Contract Sent',
            'Implementation'
        ];

        $subjects = [
            "CALL",
            "EMAIL",
            "SETUP 15 MIN",
            "ZOOM PRESENTATION",
            "LAST IMPLEMENTATION CALL",
            "TECHNICAL CALL",
            "ONSITE MEETING",
            "PRODUCT LIST",
            "OTHER"
        ];

        $activitiesQuery = Lead_Activity::selectRaw(
            "id, lead_reference_id, subject, description, date, attachment,
            assigned_to, location, contacts, related_to, is_complete, type, agent_name,
            date_format(date, '%M %Y') dateFormatted, date dateDue")
            ->where('lead_reference_id', '=', $lead->id)
            ->with(['notes' => function($query) {
                $query->select('activity_reference_id', 'note', 'agent_name', 'created_at')->orderBy('created_at', 'desc');
            }])
            ->orderBy('dateDue', 'desc')->get();

        $notes = Lead_Activity::where('type', '=', 'note')->where('lead_reference_id', '=', $lead->id)->orderBy('created_at', 'desc')->get();

        foreach($activitiesQuery as $activity) {
            $group = $activity->dateFormatted;
            if ((!($activity->type == 'task' && $activity->is_complete == '1')) && ($activity->dateDue > Carbon::now() || ($activity->dateDue < Carbon::now() && $activity->type == 'task' && $activity->is_complete == '0'))) {
                array_push($activities->$upcoming, $activity);
                if (!isset($activities->$group)) $activities->$group = [];
            }
            else if (!isset($activities->$group)) $activities->$group = [$activity];
            else array_push($activities->$group, $activity);
        }

        $agents = User::select('id', 'name_first', 'name_last')->where('is_archived', '=', '0')->orderBy('name_first')->get();

        return view('all.sales_leads.workLeadForm')->with('history', $history)->with('lead', $lead)->with('verified_lead', $verified_lead)->with('lead_contacts', $lead_contacts)
        ->with('agents', $agents)->with('activities', $activities)->with('notes', $notes)->with('statuses', $statuses)->with('subjects', $subjects)->with('page', false);
    }


    public function showLeads() {
        $leads = Sales_Leads::all();

        if(Auth::user()->role == 'manager')
            $agents = DB::select(DB::raw("SELECT `id` as 'user_id', `role`, `name_first`, `name_last`, `is_archived`, (SELECT count(*) FROM `sales_leads` WHERE agent_id = user_id) AS 'lead_count' FROM users WHERE is_archived=0 ORDER BY `name_first`;"));
        else
            $agents = [];

        return view('all.sales_leads.showLeads')->with('leads', $leads)->with('agents', $agents);
    }


    public function workNextAvailable() {
        $lead = Sales_Leads::whereNull('closed')->inRandomOrder()->first();
        $lead->save();
        if ($lead == null) {
            return redirect()->route('showLeads')->with('error', 'No available leads.');
        }
        $lead_contacts = Lead_Contacts::where('lead_reference_id',$lead->id)->get();
        $lead->closed = 1;
        $lead->agent_id = Auth::user()->id;

        $agent = Auth::user();
        $lead->sales_agent = $agent->name_first . ' ' . $agent->name_last;

        $lead->save();
        $verified_lead = Verified_Leads::where('lead_reference_id', $lead->id)->first();

        $agents = User::select('id', 'name_first', 'name_last')->where('is_archived', '=', '0')->orderBy('name_first')->get();

        return view('all.sales_leads.workLeadFormPage')->with('lead', $lead)->with('lead_contacts', $lead_contacts)->with('verified_lead', $verified_lead)->with('agents', $agents)->with('page', true);
    }

}