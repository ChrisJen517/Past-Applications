<?php

namespace App\Http\Controllers\AllAccounts;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PHPMailer\PHPMailer\PHPMailer;
use App\RNNMailer;
use App\User;

class ManageAccountController extends Controller
{

    /**
     * Get the account management view.
     *
     * @return Illuminate\Support\Facades\View
     */
    public function manageAccount()
    {
        return view('all.manageAccount');
    }

    /**
     * Update the current user in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $user = Auth::user();
        $user->name_first = $request->input('firstname');
        $user->name_last = $request->input('lastname');

        if ($request->filled('newPassword')) {
            $user->password = bcrypt(request('newPassword'));
        }

        if ($request->hasFile('avatar')) {
            $file = $request->file('avatar');
            $fileName = $file->getClientOriginalName();
            $fileExtension = $file->getClientOriginalExtension();

            // Declare Storage, and save accordingly
            $file->storeAs('/' . Auth::user()->id, 'avatar.png', ['disk' => 'profile_pictures']);
        }

        if($request->background_type == 1){
            if ($request->hasFile('customBackgroundInput')) {
                $file = $request->file('customBackgroundInput');
                $fileName = $file->getClientOriginalName();
                $fileExtension = $file->getClientOriginalExtension();

                // Declare Storage, and save accordingly
                $file->storeAs('/' . Auth::user()->id, 'background.png', ['disk' => 'background_pictures']);
            }
        }
        elseif($request->background_type == 2){
            $user->background_color = $request->customBackgroundColor;

            $file_pointer = public_path('/BackgroundPictures'.'/'.Auth::user()->id.'/background.png');
            if(file_exists($file_pointer))
                unlink($file_pointer);
        }
        elseif($request->background_type == 3){
            //sets the bacground to null and removes the image
            $user->background_color = null;

            $file_pointer = public_path('/BackgroundPictures'.'/'.Auth::user()->id.'/background.png');
            if(file_exists($file_pointer))
                unlink($file_pointer);
        }

        $user->save();

        return back()->with('message', 'User Information Updated Successfully!');
    }

    public function resetPassword()
    {
        return view('auth/resetPassword');
    }

    public function sendResetPassword(request $request)
    {
        $User = User::where('email', '=', $request->email)->first();
        if (empty($User)) {
            return redirect('/login')->with('message', 'If an account exists with that email, the password was reset and will be emailed to you shortly.');
        }

        $password = rand();
        $User->password = bcrypt($password);
        $User->password_valid = 0;
        $User->save();

        $mail = new RNNMailer(true);
        $mail->addAddresses(array($User->email));
        $mail->addReplyTo('christianj@rnngroup.com', 'Report Server');

        $date = date("M,d,Y h:i:s A");
        $mail->Subject = "[Contract Portal] Password Reset for the Contract Portal";
        $mail->Body    = "Your account email is $User->email and your temporary password is $password. Please login at https://contract.rnngroup.com/login and change your password.";
        $mail->send();

        return redirect('/login')->with('message', 'If an account exists with that email, the password was reset and will be emailed to you shortly.');
    }
}