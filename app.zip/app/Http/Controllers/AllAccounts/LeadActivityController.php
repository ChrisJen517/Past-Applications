<?php

namespace App\Http\Controllers\AllAccounts;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\Sales_Leads;
use App\Lead_Activity;
use App\Lead_Activity_Note;
use App\RNNMailer;
use App\User;
use Carbon\Carbon;

class LeadActivityController extends Controller
{

    public function createNextStep(Request $request, $sendInvite) {
        $activity = new Lead_Activity;
        $activity->lead_reference_id = $request->lead_reference_id;

        $agent = Auth::user();
        $activity->agent_name = $agent->name_first . ' ' . $agent->name_last;

        $activity->subject = $request->subject;
        $activity->description = $request->description;
        if(!empty($request->date)) {
            $start = Carbon::createFromFormat('m/d/Y H:i', $request->date)->timestamp;
            $activity->date = Carbon::createFromFormat('m/d/Y H:i', $request->date)->format('Y-m-d H:i');
        } else {
            $start = Carbon::now()->timestamp;
            $activity->date = Carbon::now()->toDateTimeString();
        }

        $recipients = [];
        if (is_array($request->assigned_to)) {
            $activity->assigned_to = implode(',', $request->assigned_to);
            foreach($request->assigned_to as $recipient) {
                $user = User::find($recipient);
                array_push($recipients, ['name' => $user->name_first . " " . $user->name_last, 'email' => $user->email]);
            }
        } else {
            $activity->assigned_to = $request->assigned_to;
            $user = User::find($request->assigned_to);
            array_push($recipients, ['name' => $user->name_first . " " . $user->name_last, 'email' => $user->email]);
        }

        if (is_array($request->contacts))
            $activity->contacts = implode(',', $request->contacts);
        else
            $activity->contacts = $request->contacts;

        $activity->location = $request->location;
        $activity->related_to = $request->related_to;
        $activity->save();

        if ($sendInvite) {
            $company_name = Sales_Leads::find($request->lead_reference_id)->company_name;
            $mailer = new RNNMailer(true);
            $mailer->addAddresses(array_column($recipients, 'email'));
            $mailer->sendInvite($company_name, $start, ucfirst(strtolower($activity->subject)) . ' with ' . $company_name, $request->description, $recipients, (empty($request->location) ? null : $request->location));
        }

        return response(['id' => $activity->id, 'message' => "Successfully created activity."]);
    }

    public function createNewTask(Request $request) {
        $task = new Lead_Activity;
        $task->lead_reference_id = $request->lead_reference_id;
        $task->subject = $request->subject;
        $task->due_date = Carbon::createFromFormat('m/d/Y H:i', $request->duedate)->format('Y-m-d H:i');
        $task->assigned_to = $request->assigned_to;
        $task->name = $request->name;
        $task->related_to = $request->related_to;
        $task->type = 'task';

        $agent = Auth::user();
        $task->agent_name = $agent->name_first . ' ' . $agent->name_last;

        $task->save();

        return response(['message' => 'Successfully created task.']);
    }

    public function createNewEvent(Request $request) {


        $event = new Lead_Activity;
        $event->lead_reference_id = $request->lead_reference_id;
        $event->subject = $request->subject;
        $event->description = $request->description;

        if($request->start_date != null)
        {
            if($request->end_date < $request->start_date)
                return back()->with('error', 'End Date Must Be After Start Date');
            else
            {
                $event->start_date = Carbon::createFromFormat('m/d/Y H:i', $request->start_date)->format('Y-m-d H:i');
                $event->end_date = Carbon::createFromFormat('m/d/Y H:i', $request->end_date)->format('Y-m-d H:i');
            }
        }

        $event->location = $request->location;
        $event->name = $request->name;
        $event->related_to = $request->related_to;
        $event->type = 'event';

        $agent = Auth::user();
        $event->agent_name = $agent->name_first . ' ' . $agent->name_last;

        $event->save();

        return response(['message' => 'Successfully created event.']);
    }

    public function createNewEventNote(Request $request) {
        $note = new Lead_Activity_Note;
        $note->activity_reference_id = $request->activity_reference_id;
        $note->agent_reference_id = $request->agent_reference_id;

        $agent = User::find($note->agent_reference_id);
        $note->agent_name = $agent->name_first . ' ' . $agent->name_last;

        $note->note = strip_tags($request->note);
        $note->save();
        return response(['agent_name' => $note->agent_name, 'date' => date_create_from_format('Y-m-d H:i:s', $note->created_at)->format('M d Y')]);
    }

    public function createNewLeadNote(Request $request) {
        $note = new Lead_Activity;
        $note->lead_reference_id = $request->lead_reference_id;
        $note->subject = $request->subject;
        $note->description = $request->description;

        $note->type = 'note';

        $agent = Auth::user();
        $note->agent_name = $agent->name_first . ' ' . $agent->name_last;
        $note->start_date = Carbon::now()->format('Y-m-d H:i');

        $note->save();

        if ($request->hasFile('attachment')) {
            $file = $request->file('attachment');
            $fileName = $file->getClientOriginalName();
            $fileExtension = $file->getClientOriginalExtension();
            $fileFull = $fileName . microtime();
            $filePath = 'lead_' . $note->id . '/' . $fileFull;
            $file->storeAs('/lead_' . $note->id, $fileFull, ['disk' => 'local']);

            $note->attachment = $filePath;
            $note->save();
        }

        return response(['message' => 'Successfully created note.']);
    }

    public function setTaskComplete(Request $request) {
        $activity = Lead_Activity::find($request->id);
        $activity->is_complete = 1;
        $activity->save();

        return response(['message' => 'Successfully set activity as complete.', 'group' => date_create_from_format('Y-m-d H:i:s', $activity->due_date)->format('F_Y')]);
    }
}