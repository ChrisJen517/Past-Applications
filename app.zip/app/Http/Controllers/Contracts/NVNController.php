<?php

namespace App\Http\Controllers\Contracts;

use App\Employer_Profile;
use App\Http\Controllers\Controller;
use ConvertApi\ConvertApi;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Response;

class NVNController extends Controller {

    /**
     * Show the National Verification Network report
     *
     * @return View agreement form
     */
    function showNVN()
    {
        $states = Employer_Profile::select('state_name')->get();
        return view('contracts.NVN')->with('states', $states);
    }

    /**
     * Export a National Verification network report
     *
     * @param Request $request POST parameters
     *
     * @return Redirect with success or failure
     */
    public function exportNVN(Request $request)
    {
        $user = Auth::user();
        $lastName = trim($user->name_last);

        $state = $request->state;
        if($state == 'USA')
        {
            $profiles = Employer_Profile::all();

            $unemployment_rate = $profiles->sum('unemployment_rate')/$profiles->count();
            $work_number = $profiles->sum('work_number');
            $third_party = $profiles->sum('third_party');
            $phone_verification = $profiles->sum('phone_verification');
            $fax_verification = $profiles->sum('fax_verification');
            $email_verification = $profiles->sum('email_verification');
            $mail_verification = $profiles->sum('mail_verification');
            $url_verification = $profiles->sum('url_verification');

            $total_completed = $work_number + $third_party + $phone_verification + $fax_verification + $email_verification + $mail_verification + $url_verification;
        }
        else{
            $profile = Employer_Profile::where('state_name', $state)->first();

            $unemployment_rate = $profile->unemployment_rate;
            if (empty($unemployment_rate))
                $unemployment_rate = "N/A";
            else
                $unemployment_rate .= "%";

            $work_number = $profile->work_number ?? 0;
            $third_party = $profile->third_party ?? 0;
            $phone_verification = $profile->phone_verification ?? 0;
            $fax_verification = $profile->fax_verification ?? 0;
            $email_verification = $profile->email_verification ?? 0;
            $mail_verification = $profile->mail_verification ?? 0;
            $url_verification = $profile->url_verification ?? 0;
            // $total_completed = $profile->total_profiles_complete ?? 0;
            $total_completed = $work_number + $third_party + $phone_verification + $fax_verification + $email_verification + $mail_verification + $url_verification;
            if ($total_completed == 0) $total_completed = 1; // prevent against division by 0 but this should not happen.

        }

        $template = new \PhpOffice\PhpWord\TemplateProcessor(storage_path() . '/' . 'NVN_SUMMARY_TEMPLATE.docx');
        if($state == 'USA')
        {
            $template->setValue('population', number_format($profiles->sum('employed_population')));
            $template->setValue('employment_pop', number_format($profiles->sum('employed_population') * (1-$unemployment_rate/100)));
            $unemployment_rate = round($unemployment_rate,2). "%";
        }
        else{
            $template->setValue('population', number_format($profile->employed_population));
            $template->setValue('employment_pop', number_format($profile->employed_population * (1-$profile->unemployment_rate/100)));
        }
        $template->setValue('state_name', $state);
        $template->setValue('state_name_2', $state);
        $template->setValue('unemployment_rate', $unemployment_rate);

        $template->setValue('work_number', number_format($work_number));
        $template->setValue('work_number_%', round(($work_number / $total_completed), 4) * 100 . '%');
        $template->setValue('3rd_party', number_format($third_party));
        $template->setValue('3rd_party_%', round(($third_party / $total_completed), 4) * 100 . '%');
        $template->setValue('phone', number_format($phone_verification));
        $template->setValue('phone_%', round(($phone_verification / $total_completed), 4) * 100 . '%');
        $template->setValue('fax', number_format($fax_verification));
        $template->setValue('fax_%', round(($fax_verification / $total_completed), 4) * 100 . '%');
        $template->setValue('email', number_format($email_verification));
        $template->setValue('email_%', round(($email_verification / $total_completed), 4) * 100 . '%');
        $template->setValue('mail', number_format($mail_verification));
        $template->setValue('mail_%', round(($mail_verification / $total_completed), 4) * 100 . '%');
        $template->setValue('website', number_format($url_verification));
        $template->setValue('website_%', round(($url_verification / $total_completed), 4) * 100 . '%');
        $template->setValue('completed', number_format($total_completed));
        $templateDocx = storage_path() . '/' . $lastName . '_NVN.docx';
        $template->saveAs($templateDocx);

        $fileName = $state . '_NVN.pdf';
        $savePath = public_path() . '/Exports' . '/' . $fileName;

        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $templateDocx]);
            $result->getFile()->save($savePath);
        } catch (Exception $e) {
            if (is_file($templateDocx))
                unlink($templateDocx);

            return redirect()->route('agentDashboard')->with('errorToast', 'NVN report creation failed, please try again later. If this persists, please contact a developer.');
        }

        if (is_file($templateDocx))
            unlink($templateDocx);

        return response()->json(['fileName' => $fileName]);
    }
}
