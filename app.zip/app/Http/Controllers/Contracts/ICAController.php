<?php

namespace App\Http\Controllers\Contracts;

use App\Contract;
use App\History;
use App\Http\Controllers\Controller;
use App\RNNMailer;
use ConvertApi\ConvertApi;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;
use Illuminate\Support\Facades\Storage;

class ICAController extends Controller {

    /**
     * Show an Independent Contractor Agreement contract
     *
     * @return View agreement form
     */
    function showICA()
    {
        return view('contracts.ICA');
    }

    /**
     * Export an Independent Contractor Agreement contract
     *
     * @param Request $request POST parameters
     *
     * @return Redirect with success or failure
     */
    public function exportICA(Request $request)
    {
        $contractor_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $request->contractor_name), 0, 100);
        $contractor_address_full = $request->contractor_address . ', ' . $request->contractor_city . ', ' . $request->contractor_state . ' ' . $request->contractor_zip;

        $commencement_date = Carbon::parse($request->commencement_date);
        $termination_date = Carbon::parse($request->termination_date);

        if($termination_date->isBefore($commencement_date))
            return redirect()->back()->with('errorToast', 'Termination date can not be after the commencement date.');

        $template = new \PhpOffice\PhpWord\TemplateProcessor(storage_path() . '/' . 'RNN_ICA_template_Old.docx');
        $template->setValue('date', htmlspecialchars(date('l, F j, Y')));
        $template->setValue('contractor_name', $request->contractor_name);
        $template->setValue('contractor_name_2', $request->contractor_name);
        $template->setValue('contractor_address', $contractor_address_full);
        $template->setValue('contractor_address_2', $contractor_address_full);
        // $template->setValue('services_description', $request->services_description);
        $template->setValue('services_description_2', $request->services_description);
        $template->setValue('periodic_report', $request->periodic_report);
        $template->setValue('commencement_date', $request->commencement_date);
        // $template->setValue('termination_date', $request->termination_date);
        $template->setValue('deliverables_timeline', $request->deliverables);
        $template->setValue('fee_structure', $request->fee_structure);
        $template->setValue('payment_schedule', $request->payment_schedule);
        $template->setValue('other_1', $request->other_1 ?? '');
        // $template->setValue('other_2', $request->other_2 ?? '');
        // $template->setValue('other_3', $request->other_3 ?? '');
        $templateDocx = storage_path() . '/' . $contractor_name . '_ICA.docx';
        $template->saveAs($templateDocx);

        $contract = new Contract();
        $contract->company_address = $request->contractor_address;
        $contract->company_city = $request->contractor_city;
        $contract->company_state = $request->contractor_state;
        $contract->company_zip = $request->contractor_zip;
        $contract->company_email = $request->contractor_email;
        $contract->agent_reference = Auth::user()->id;
        $contract->approval_needed = 0;
        $contract->status = 'awaiting_final_upload';
        $contract->contract_name = "temp";
        $contract->contract_type = "ICA";
        $contract->company_name = $request->contractor_name;
        $contract->client_id = null;
        $contract->envelopeId = "";
        $contract->docusign_email = $request->contract_email;
        $contract->save();

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__ICA_'.$date.'.pdf');
        $file_name = $directoryName . 'RNNGroup_' . substr($contractor_name, 0, $file_name_count) . '_ICA_' . $date . '.pdf';

        $contract->contract_name = $file_name;
        $contract->save();

        Storage::disk('local')->makeDirectory($directoryName, 0755, true);

        $savePath = storage_path() . '/' . 'app/' . 'public/' . $file_name;

        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $templateDocx]);
            $result->getFile()->save($savePath);
            $history = new History($contract->id, $file_name, "Original contract generated. Awaiting client signature upload.");
        } catch (Exception $e) {
            $contract->delete();

            if (is_file($templateDocx))
                unlink($templateDocx);

            return redirect()->route('agentDashboard')->with('errorToast', 'ICA contract creation failed, please try again later. If this persists, please contact a developer.');
        }

        $this->postConversion($contract, $history, $contractor_name);
        return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

        /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param string $contractor_name company's name with no spaces
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($contract, $history, $contractor_name)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Remove all temporary files from storage
        if (is_file(storage_path() . '/' . $contractor_name . '_ICA.docx'))
            unlink(storage_path() . '/' . $contractor_name . '_ICA.docx');
    }
}