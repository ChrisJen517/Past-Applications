<?php

namespace App\Http\Controllers\Contracts;

use App\Http\Controllers\Controller;
use App\Client;
use App\Contract;
use App\History;
use App\YouNegotiateHistory;
use App\ApprovalMessage;
use App\Jobs\ConvertContract;
use App\RNNMailer;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

use iio\libmergepdf\Merger;
use ConvertApi\ConvertApi;
use Exception;
use PhpOffice\PhpWord\TemplateProcessor;

class YouNegotiateController extends Controller
{
    /**
     * Get the YouNegotiate contract view.
     *
     * @return View
     */
    public function showYouNegotiate()
    {
        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return view('contracts.youNegotiate')->with('clients', $clients);
    }

    public function convertPrice($price) {
        $price = (float) $price;
        if ($price <= 10 || fmod($price, 1) !== 0.0) {
            if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                $price = number_format($price, 2);
            }
        }
        return $price;
    }

    /**
     * Generate the YouNegotiate contract.
     *
     * @param Request POST request params
     * @return Redirect with success or failure
     */
    public function exportYouNegotiate(Request $request)
    {
        $client = Client::find($request->input('company_id'));

        // Validate that if the company email was changed that it is unique
        if ($request->input('company_email') !== $client->company_email) {
            $this->validate($request, [
                'company_email' => ['unique:client_profiles,company_email'],
            ]);
        }

        $company_address_full = $request->company_address . ', ' . $request->company_city . ', ' . $request->company_state . ' ' . $request->company_zip;
        $needs_manager_approval = $needs_jim_approval = 0;
        $approval = "These items are waiting approval: ";

        for ($i = 0; $i <= 3; $i++) {
            if ($request->price[$i] <= $request->managerPrice[$i] || $request->price[$i] <= $request->jimPrice[$i]) {
                $prefix = $i != 1 ? '$' : '';
                $approval = $approval . "<br> The item " . $request->name[$i] . ", was set at a price of " . $prefix . $this->convertPrice($request->price[$i])
                    . ". The price was originally set at " . $prefix . $this->convertPrice($request->originalPrice[$i])
                    . ". Manager Approval Price is set at " . $prefix . $this->convertPrice($request->managerPrice[$i])
                    . ". Jim's Approval Price is set at " . $prefix . $this->convertPrice($request->jimPrice[$i]) . ".";

                if ($request->price[$i] < $request->jimPrice[$i])
                    $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
            }
            if (in_array($request->ach, ["Monthly", "Bi-Monthly"])) 
                $approval = $approval . "The ACH term was set to " . $request->ach;
                
            if ($request->price[$i] < $request->managerPrice[$i] || $request->ach == "Bi-Monthly")
                $needs_manager_approval = 1;
            if ($request->price[$i] < $request->jimPrice[$i] || $request->ach == "Monthly")
                $needs_jim_approval = 1;
        }

        switch ($request->ach)
        {
            case "Weekly":
                $recurring_payment = "each Monday for previous Mon-Sun ";
                $term_def = "fees will be ACH debited from bank account on each Monday for the following Monday-Sunday processed transactions.";
            break;
            case "Bi-Monthly":
                $recurring_payment = "the 16th if for the 1st through the 15th and the 1st if for the 16th-end of month";
                $term_def = "fees will be ACH debited from bank account on the 16th of each month, for transactions processed during the period of the 1st through the 15th of the calendar month.";
            break;
            case "Monthly":
                $recurring_payment = "the 1st for the previous month";
                $term_def = "fees will be ACH debited from the bank account on the 1st business day of each month for the previous month.";
            break;
        }

        // Load MSA without FCRA template and save as $templateDocx1
        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $client->company_name), 0, 100); // Removes special chars and trims to 100 chars

        // Load You-Negotiate Pricing Exhibit template and save as $templateDocx2
        $template = new TemplateProcessor(storage_path() . '/' . 'Master Services Agreement You Negotiate.docx');
        $template->setValue('date', htmlspecialchars(date('l, F j, Y')));
        $template->setValue('company_name', htmlspecialchars($client->company_name));
        $template->setValue('company_address_full', htmlspecialchars($company_address_full));
        $template->setValue('company_address', htmlspecialchars($request->company_address));
        $template->setValue('payment_term', htmlspecialchars($request->payment_term));
        $template->setValue('ach', htmlspecialchars($request->ach));
        $template->setValue('term_def', htmlspecialchars($request->term_def));
        $template->setValue('setup_fee', htmlspecialchars(number_format($request->price[0])));
        $template->setValue('payment_percent', htmlspecialchars($request->price[1]));
        $template->setValue('per_text', htmlspecialchars($request->price[2]));
        $template->setValue('per_email', htmlspecialchars($request->price[3]));
        $template->setValue('e_letter', htmlspecialchars($request->price[4]));
        $template->setValue('video_hosting', htmlspecialchars($request->price[5]));
        $template->setValue('recurring_payment', htmlspecialchars($request->recurring_payment));
        $template->setValue('company_phone', htmlspecialchars($request->company_phone));
        $template->setValue('city', htmlspecialchars($request->company_city));
        $template->setValue('state', htmlspecialchars($request->company_state));
        $template->setValue('zip', htmlspecialchars($request->company_zip));
        $template->setValue('email', htmlspecialchars($request->company_email));


        $templateDocx = storage_path() . '/' . $company_name . '_You_Neg_Part.docx';
        $template->saveAs($templateDocx);

        $contract = new Contract;
        $contract->makeContract($request, $client, "You-Negotiate");

        $client->fill($request->all());
        $client->save();

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__You-Negotiate_'.$date.'.pdf');
        $file_name = $directoryName . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_You-Negotiate_' . $date . '.pdf';

        $contract->contract_name = $file_name;
        $contract->save();

        $pricingHistory = new YouNegotiateHistory();
        $pricingHistory->newHistory($request, $client, $contract->id);

        $templatePdf = storage_path() . '/' . $company_name . '_You_Neg_Part.pdf';

        /**
         * Try initially to convert the docx file to pdf, if it works continue on normally.
         * If it fails, update the status to converting and throw the process upon the queue.
         */
        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $templateDocx]);
            $result->getFile()->save($templatePdf);

            $history = new History($contract->id, $file_name, "Original contract generated. Awaiting final contract with signatures.");
        } catch (Exception $e) {
            $contract->delete();

            if (is_file(storage_path() . '/' . $company_name . '_You_Neg_Part.docx'))
                unlink(storage_path() . '/' . $company_name . '_You_Neg_Part.docx');
            if (is_file($templatePdf))
                unlink($templatePdf);

            return redirect()->route('agentDashboard')->with('errorToast', 'You Negotiate contract creation failed, please try again later. If this persists, please contact a developer.');
            $contract->status = 'converting';
            $contract->save();

            $history = new History($contract->id, $file_name, 'Original contract generation conversion failed. Sending upon queue to convert docx to pdf.');
            $files = array($templateDocx => $templatePdf);

            $job = new ConvertContract(
                Auth::user(),                                   // User currently generating the contract.
                $contract->id,                                  // Contract ID
                $files,                                         // Array of (docxFile => pdfPath)
                __CLASS__,                                      // Class Name
                array(
                    $contract,
                    $history,
                    Auth::user(),
                    $company_name,
                    $templatePdf,
                    $file_name,
                    $needs_manager_approval,
                    $needs_jim_approval,
                    $approval
                )                                               // Parameters for static function 'postConversion'
            );

            dispatch($job);
            return redirect()->route('agentDashboard')->with('information', 'Contract creation currently pending.');
        }

        if ($this->postConversion($contract, $history, Auth::user(), $company_name, $templatePdf, $file_name, $needs_manager_approval, $needs_jim_approval, $approval))
            return redirect()->route('agentDashboard')->with('message', 'Contract Sent to Manager for Approval.');
        else
            return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

    /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param object $user currently authenticated user
     * @param string $company_name company's name with no spaces
     * @param string $templatePdf1 converted pdf file path 1
     * @param string $templatePdf2 converted pdf file path 2
     * @param string $templatePdf3 converted pdf file path 3
     * @param string $file_name final pdf path in storage
     * @param boolean $needs_manager_approval
     * @param boolean $needs_jim_approval
     * @param string $approval
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($contract, $history, $user, $company_name, $templatePdf, $file_name, $needs_manager_approval, $needs_jim_approval, $approval)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Merge all necessary PDF files into $mergedPdf path
        $merger = new Merger;
        $merger->addFile($templatePdf);
        $createdPdf = $merger->merge();

        Storage::disk('local')->put($file_name, $createdPdf);

        // Remove all temporary files from storage
        if (is_file(storage_path() . '/' . $company_name . '_You_Neg_Part.docx'))
            unlink(storage_path() . '/' . $company_name . '_You_Neg_Part.docx');
        if (is_file($templatePdf))
            unlink($templatePdf);

        // Send mail containing attachment if necessary (1 = sent, 0 = unnecessary)
        $mailer = new RNNMailer(true);
        return $mailer->sendContractApproval($user, $needs_manager_approval, $needs_jim_approval, $contract, $history, $file_name, $approval);
    }
}