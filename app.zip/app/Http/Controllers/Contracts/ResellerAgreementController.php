<?php

namespace App\Http\Controllers\Contracts;

use App\Http\Controllers\Controller;
use App\Client;
use App\Contract;
use App\History;
use App\YouNegotiateHistory;
use App\ApprovalMessage;
use App\Jobs\ConvertContract;
use App\RNNMailer;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

use iio\libmergepdf\Merger;
use ConvertApi\ConvertApi;
use Exception;
use PhpOffice\PhpWord\TemplateProcessor;

class ResellerAgreementController extends Controller
{
    /**
     * Get the YouNegotiate contract view.
     *
     * @return View
     */
    public function showResellerAgreement()
    {
        if(Auth::user()->is_admin != 1)
            return back()->with("error", "You do not have access to this page");
        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return view('contracts.resellerAgreement')->with('clients', $clients);
    }

    public function convertPrice($price) {
        $price = (float) $price;
        if ($price <= 10 || fmod($price, 1) !== 0.0) {
            if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                $price = number_format($price, 2);
            }
        }
        return $price;
    }

    /**
     * Generate the YouNegotiate contract.
     *
     * @param Request POST request params
     * @return Redirect with success or failure
     */
    public function exportResellerAgreement(Request $request)
    {
        $client = Client::find($request->input('company_id'));

        // Validate that if the company email was changed that it is unique
        if ($request->input('company_email') !== $client->company_email) {
            $this->validate($request, [
                'company_email' => ['unique:client_profiles,company_email'],
            ]);
        }

        $company_address_full = $request->company_address . ', ' . $request->company_city . ', ' . $request->company_state . ' ' . $request->company_zip;
        $needs_manager_approval = $needs_jim_approval = 0;
        $approval = "These items are waiting approval: ";

        // for ($i = 0; $i <= 0; $i++) {
        //     if (($request->price[$i] < 5 || $request->price[$i] > 7) && $request->price[$i] != "") {
        //         $approval = $approval . "<br> The Minimum End User Fee (collected payments) was set at: ".$request->price[$i]."%";
        
        //         $needs_manager_approval = 1;
        //     }
        // }

        // if (($request->setup_fee > 3000 || $request->setup_fee < 1500) && $request->setup_fee != "") {
        //     $approval = $approval . "<br> The Initiation & Setup Fee was set at: $".$this->convertPrice($request->setup_fee);
        
        //     $needs_manager_approval = 1;
        // }

        // if (($request->commission_fee >= $request->managerPrice[2] || $request->commission_fee >= $request->jimPrice[2]) && $request->commission_fee != "") {
        //     $prefix = '';
        //     $approval = $approval . "<br> The item " . $request->name[2] . ", was set at a price of " . $request->commission_fee."%"
        //         . ". The price was originally set at " . $request->originalPrice[2]."%"
        //         . ". Manager Approval Price is set at " . $request->managerPrice[2]."%"
        //         . ". Jim's Approval Price is set at " . $request->jimPrice[2]."%" . ".";
        
        //     if ($request->commission_fee > $request->managerPrice[2])
        //         $needs_manager_approval = 1;
        //     if ($request->commission_fee > $request->jimPrice[2])
        //         $needs_jim_approval = 1;
        // }
        
        // Load MSA without FCRA template and save as $templateDocx1
        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $client->company_name), 0, 100); // Removes special chars and trims to 100 chars

        // Load You-Negotiate Pricing Exhibit template and save as $templateDocx2
        $template = new TemplateProcessor(storage_path() . '/' . 'Master_Reseller_Agreement.docx');
        $template->setValue('date', htmlspecialchars(date('l, F j, Y')));
        $template->setValue('company_name', htmlspecialchars($client->company_name));
        $template->setValue('company_address_full', htmlspecialchars($company_address_full));
        $template->setValue('organization', htmlspecialchars($request->organization));
        $template->setValue('entity_type', htmlspecialchars($request->entity));
        $template->setValue('url', htmlspecialchars($request->company_url));
        // $template->setValue('ach', ($request->ach != "" ? "<w:br />".htmlspecialchars("Bilslspecialchars("Commission: ".$request->commission) : ""));
        // $template->setValue('sms_fee', ($request->price[0] != "" ? "<w:br />".htmlspecialchars("SMS: $".$request->price[0]) : ""));
        // $template->setValue('email_fee', ($request->price[1] != "" ? "<w:br />".htmlspecialchars("Email:  $".$request->price[1]) : ""));
        $template->setValue('issued_by', htmlspecialchars($request->issued_by));
        $template->setValue('industry', htmlspecialchars(($request->industry == "Other" ? $request->industry_other : $request->industry)));
        // $template->setValue('territory', htmlspecialchars(($request->territory == "National" ? $request->territory : $request->territory_other)));
        $template->setValue('demos', htmlspecialchars($request->demos));
        $template->setValue('min_fee', htmlspecialchars($request->price[0]."%"));
        $template->setValue('setup_fee', htmlspecialchars("$".$request->setup_fee));
        $template->setValue('commission_fee', htmlspecialchars($request->commission_fee."%"));

        $templateDocx = storage_path() . '/' . $company_name . '_Reseller_Agreement_Part.docx';
        $template->saveAs($templateDocx);

        $contract = new Contract;
        $contract->makeContract($request, $client, "Reseller Agreement");

        $client->fill($request->all());
        $client->save();

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__Reseller_Agreement_'.$date.'.pdf');
        $file_name = $directoryName . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_Reseller_Agreement_' . $date . '.pdf';

        $contract->contract_name = $file_name;
        $contract->save();

        $templatePdf = storage_path() . '/' . $company_name . '_Reseller_Agreement_Part.pdf';

        /**
         * Try initially to convert the docx file to pdf, if it works continue on normally.
         * If it fails, update the status to converting and throw the process upon the queue.
         */
        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $templateDocx]);
            $result->getFile()->save($templatePdf);

            $history = new History($contract->id, $file_name, "Original contract generated. Awaiting final contract with signatures.");
        } catch (Exception $e) {
            $contract->delete();

            if (is_file(storage_path() . '/' . $company_name . '_Reseller_Agreement_Part.docx'))
                unlink(storage_path() . '/' . $company_name . '_Reseller_Agreement_Part.docx');
            if (is_file($templatePdf))
                unlink($templatePdf);

            return redirect()->route('agentDashboard')->with('errorToast', 'Reseller Agreement contract creation failed, please try again later. If this persists, please contact a developer.');
            $contract->status = 'converting';
            $contract->save();

            $history = new History($contract->id, $file_name, 'Original contract generation conversion failed. Sending upon queue to convert docx to pdf.');
            $files = array($templateDocx1 => $templatePdf);

            $job = new ConvertContract(
                Auth::user(),                                   // User currently generating the contract.
                $contract->id,                                  // Contract ID
                $files,                                         // Array of (docxFile => pdfPath)
                __CLASS__,                                      // Class Name
                array(
                    $contract,
                    $history,
                    Auth::user(),
                    $company_name,
                    $templatePdf,
                    $file_name,
                    $needs_manager_approval,
                    $needs_jim_approval,
                    $approval
                )                                               // Parameters for static function 'postConversion'
            );

            dispatch($job);
            return redirect()->route('agentDashboard')->with('information', 'Contract creation currently pending.');
        }

        if ($this->postConversion($contract, $history, Auth::user(), $company_name, $templatePdf, $file_name, $needs_manager_approval, $needs_jim_approval, $approval))
            return redirect()->route('agentDashboard')->with('message', 'Contract Sent to Manager for Approval.');
        else
            return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

    /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param object $user currently authenticated user
     * @param string $company_name company's name with no spaces
     * @param string $templatePdf1 converted pdf file path 1
     * @param string $templatePdf2 converted pdf file path 2
     * @param string $templatePdf3 converted pdf file path 3
     * @param string $file_name final pdf path in storage
     * @param boolean $needs_manager_approval
     * @param boolean $needs_jim_approval
     * @param string $approval
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($contract, $history, $user, $company_name, $templatePdf, $file_name, $needs_manager_approval, $needs_jim_approval, $approval)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Merge all necessary PDF files into $mergedPdf path
        $merger = new Merger;
        $merger->addFile($templatePdf);
        $createdPdf = $merger->merge();

        Storage::disk('local')->put($file_name, $createdPdf);

        // Remove all temporary files from storage
        if (is_file(storage_path() . '/' . $company_name . '_Reseller_Agreement_Part.docx'))
            unlink(storage_path() . '/' . $company_name . '_Reseller_Agreement_Part.docx');
        if (is_file($templatePdf))
            unlink($templatePdf);

        // Send mail containing attachment if necessary (1 = sent, 0 = unnecessary)
        $mailer = new RNNMailer(true);
        return $mailer->sendContractApproval($user, $needs_manager_approval, $needs_jim_approval, $contract, $history, $file_name, $approval);
    }
}