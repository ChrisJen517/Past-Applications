<?php

namespace App\Http\Controllers\Contracts;

use App\Exports\ExportProducts;
use Illuminate\Http\Request;

use App\Http\Controllers\Controller;
use App\FPDF_Custom;
use App\Product_Headers;
use App\Products;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class ProductSheetController extends Controller
{
    /**
     * Get the product sheet view.
     *
     * @return View with product headers and products
     */
    public function showProductSheet()
    {
        $product_headers = Product_Headers::orderBy('order', 'asc')->get();
        $products = Products::orderBy('order', 'asc')->get();
        foreach($products as $product)
            $product->removeZeros();

        return view('contracts.productSheet')->with('product_headers', $product_headers)->with('products', $products);
    }

    /**
     * Generate the product sheet.
     *
     * @param Request MSA Product form
     * @return Response with file download
     */
    public function exportProductSheet(Request $request)
    {
        // Back end validation for $request
        // $this->validate(
        //     $request,
        //     [
        //         'price' => 'required',
        //         'price.required' => 'Please choose at least one product.'
        //     ]
        // );

        if (!is_array($request->name) || count($request->name) == 0)
            if ($request->submit == 'Generate Product Sheet Excel')
                return response(['error' => 'No products selected']);
            else
                return redirect()->back()->with('errorToast', 'No products selected');

        if ($request->submit == 'Generate Product Sheet Excel') {
            $fileName = 'products' . time() . '.xlsx';
            Excel::store(new ExportProducts($request), $fileName, 'exports');
            return response(['fileName' => $fileName]);
        }

        // Generate a product sheet using FPDF
        $fpdf = new FPDF_Custom();
        $fpdf->AddFont('Calibri', '', 'calibri.php');
        $fpdf->AddFont('Calibri-Bold', '', 'calibrib.php');
        $fpdf->SetFont('Calibri-Bold', '', 30);

        $fpdf->AddPage('L', 'Legal');

        $fpdf->SetY(20);
        $fpdf->SetDrawColor(0, 0, 0);
        $fpdf->SetFillColor(241, 241, 241);

        $fpdf->SetTextColor(161, 0, 0);
        $fpdf->MultiCell($fpdf->GetPageWidth() - 20, 5, 'RNN Product Guide 2020', 0, 'C', false);
        $fpdf->SetFont('Calibri', '', 10);
        $fpdf->SetY(25);
        $fpdf->SetX(20);

        $fpdf->SetTextColor(161, 0, 0);
        $fpdf->SetFont('Calibri-Bold', '', 10);
        $fpdf->SetTextColor(0, 0, 0);

        $count = count($request->name);
        $header_id = 0;

        for ($i = 0; $i < $count; $i++) {
            if ($request->prod_header_id[$i] != $header_id) {
                $prod_header = Product_Headers::find($request->prod_header_id[$i]);
                $header_id = $request->prod_header_id[$i];
                if($i != 0)
                    $fpdf->AddPage('L', 'Legal');
                $fpdf->Cell(20, 10, '', 0, 1, 'C');
                $fpdf->SetFont('Calibri-Bold', '', 12);
                $fpdf->setFillColor(241, 241, 241);
                $fpdf->Cell(10); //BORDER CELL FOR SPACING
                $fpdf->Cell(315, 8, $prod_header->name, 1, 1, 'C', 1);
                $fpdf->Cell(10); //BORDER CELL FOR SPACING
                $fpdf->SetFont('Calibri-Bold', '', 10);

                $x = $fpdf->GetX();
                $y = $fpdf->GetY();
                $fpdf->MultiCell(70, 6, $prod_header->column_1, 1, 'C', false);
                $fpdf->SetXY($x + 70, $y);
                $fpdf->MultiCell(30, 6, 'Batch Code', 1, 'C', false);
                // $fpdf->SetXY($x + 100, $y);
                // $fpdf->MultiCell(30, 6, 'Vast Code', 1, 'C', false);
                $fpdf->SetXY($x + 100, $y);
                $fpdf->MultiCell(30, 6, 'SLA', 1, 'C', false);
                $fpdf->SetXY($x + 130, $y);
                $fpdf->MultiCell(140, 6, $prod_header->column_2, 1, 'C', false);
                $fpdf->SetXY($x + 270, $y);
                $fpdf->MultiCell(45, 6, $prod_header->column_3, 1, 'C', false);
            }
            $fpdf->SetFont('Calibri', '', 10);
            if ($request->prod_header_id[$i] == 11) {
                $price = floor($request->price[$i]);

                $cost_string = $price;
            } else if ($request->name[$i] == "AWG 7 Attempt") {
                $cost_string = $request->price_name[$i];
            } else if ($request->use_quote[$i] == 1)
            {
                $cost_string = $request->price[$i];
            } else {
                $price = $request->price[$i];
                $price = (float) $price;
                if ($price <= 10 || fmod($price, 1) !== 0.0) {
                    if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                        $price = number_format($price, 2);
                    }
                }
                $cost_string = '$' . $price . ' ' . $request->price_name[$i];
            }

            $cell_height = 5;

            $line_description = $fpdf->GetMultiCellLineCount(140, $cell_height, $request->description[$i], 1, 'C', false);
            $line_batch = $fpdf->GetMultiCellLineCount(30, $cell_height, $request->batch_code[$i], 1, 'C', false);
            // $line_vast = $fpdf->GetMultiCellLineCount(30, $cell_height, $request->vast_code[$i], 1, 'C', false);
            $line_sla = $fpdf->GetMultiCellLineCount(30, $cell_height, $request->sla[$i], 1, 'C', false);
            $line_name = $fpdf->GetMultiCellLineCount(70, $cell_height, $request->name[$i], 1, 'C', false);
            $line_price = $fpdf->GetMultiCellLineCount(45, $cell_height, $cost_string, 1, 'C', false);

            // Finding the max amount of lines needed to draw the box
            $max = $line_name;
            if ($max < $line_description) {
                $max = $line_description;
            }
            if ($max < $line_price) {
                $max = $line_price;
            }


            $fpdf->Cell(10); //BORDER CELL FOR SPACING
            $x = $fpdf->GetX();
            $y = $fpdf->GetY();
            $fpdf->SetFont('Calibri', '', 10);
            //LOGIC TO DETERMINE IF WE NEED A PAGE BREAK
            if ($fpdf->PageBreakDetermine($max * $cell_height)) {
                $fpdf->AddPage('L', 'Legal');
                $fpdf->SetY(20);
                $fpdf->Cell(10); //BORDER CELL FOR SPACING
            }


            $fpdf->MultiCell(70, ($max * $cell_height) / ($line_name), $request->name[$i], 1, 'C', false);
            $y = $fpdf->GetY() - ($max * $cell_height);
            $fpdf->SetXY($x + 70, $y);
            $fpdf->MultiCell(30, ($max * $cell_height) / ($line_batch), $request->batch_code[$i], 1, 'C', false);
            // $fpdf->SetXY($x + 100, $y);
            // $fpdf->MultiCell(30, ($max * $cell_height) / ($line_vast), $request->vast_code[$i], 1, 'C', false);
            $fpdf->SetXY($x + 100, $y);
            $fpdf->MultiCell(30, ($max * $cell_height) / ($line_sla), $request->sla[$i], 1, 'C', false);
            $fpdf->SetXY($x + 130, $y);
            $fpdf->MultiCell(140, ($max * $cell_height) / $line_description, $request->description[$i], 1, 'C', false);
            $fpdf->SetXY($x + 270, $y);
            $fpdf->MultiCell(45, ($max * $cell_height) / ($line_price), $cost_string, 1, 'C', false);
        }

        $filePath = storage_path() . '/CustomProductSheet.pdf';
        $fpdf->Output('F', $filePath, true);

        // Return the FPDF as a download and delete the file after sending it
        return response()->download($filePath)->deleteFileAfterSend();
    }
}