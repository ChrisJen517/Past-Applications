<?php

namespace App\Http\Controllers\Contracts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Fpdf;
use File;
use Illuminate\Support\Facades\DB;
use ConvertApi\ConvertApi;
use PHPMailer\PHPMailer\PHPMailer;
use Exception;
use App\FPDF_Merge;
use Illuminate\Support\Facades\Auth;
use Mail;
use App\User;
use App\History;
use App\Contract;
use Illuminate\Support\Facades\Storage;
use App\ApprovalMessage;
use App\Product_Headers;
use App\Products;
use App\FPDF_Custom;
use App\Client;
use App\Jobs\ConvertContract;
use App\RNNMailer;

class MSAController extends Controller
{
    /**
     * Show the MSA contract generation view.
     *
     * @return View with product headers, products, and clients
     */
    public function showMSA()
    {
        $product_headers = Product_Headers::orderBy('order', 'asc')->get();
        $products = Products::orderBy('order', 'asc')->get();
        foreach($products as $product)
            $product->removeZeros();

        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return view('contracts.MSA')->with('product_headers', $product_headers)->with('products', $products)->with('clients', $clients);
    }

    public function convertPrice($price) {
        $price = (float) $price;
        if ($price <= 10 || fmod($price, 1) !== 0.0) {
            if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                $price = number_format($price, 2);
            }
        }
        return $price;
    }

    /**
     * Export the MSA Contract.
     *
     * @param Request $request POST request params
     *
     * @return Redirect with success or failure
     */
    public function exportMSA(request $request)
    {
        $client = Client::find($request->input('company_id'));

        // Validate that if company's email is changed that it is unique.
        if ($request->input('company_email') !== $client->company_email) {
            $this->validate($request, [
                'company_email' => ['unique:client_profiles,company_email'],
            ]);
        }

        // Generate part two of MSA using FPDF
        $fpdf = new FPDF_Custom();
        $fpdf->drawScheduleAHeader();

        $fpdf->MultiCell(160, 5, 'Clients will have access to the RNN Web App to build their product ' .
            'and tier waterfall at the file level for all products as listed below. RNN Tier pricing is delivered by purchasing leads with verification rates by price point or manual skip tracing costs.', 0, 'L', false);

        $fpdf->SetTextColor(161, 0, 0);
        $fpdf->SetFont('Calibri-Bold', '', 10);
        $fpdf->SetTextColor(0, 0, 0);

        if (!empty($request->name))
            $count = count($request->name);
        else
            $count = 0;

        $header_id = 0;
        $approval = "These items are waiting approval: ";
        $needs_manager_approval = 0;
        $needs_jim_approval = 0;

        $products = collect();
        if ($count != 0) {
            for ($i = 0; $i < $count; $i++) {
                if ($request->prod_header_id[$i] != $header_id) {
                    $prod_header = Product_Headers::find($request->prod_header_id[$i]);
                    $header_id = $request->prod_header_id[$i];
                    $fpdf->buildProductHeader($prod_header);
                }

                $fpdf->SetFont('Calibri', '', 10);
                $fpdf->buildProductCell($request, $i);

                $productObject = [
                    'productId' => $request->id[$i],
                    'productName' => $request->name[$i],
                    'productHeaderId' => $header_id,
                    'productHeaderName' => $prod_header->name,
                    'useQuote' => $request->use_quote[$i],
                    'price' => $request->price[$i],
                    'needsManagerApproval' => 0,
                    'needsJimApproval' => 0,
                    'reason' => $request->reason[$i] ?? ''
                ];

                if ($request->use_quote[$i] == 1) {
                    $products->push($productObject);
                    continue;
                }

                // Checking to see if the price has been set below the manager thresholds.
                if ($request->prod_header_id[$i] == 11) {

                    if ($request->price[$i] > ($request->managerPrice[$i] == 0 ? $request->price[$i] : $request->managerPrice[$i])) {
                        $productObject['needsManagerApproval'] = 1;
                        $needs_manager_approval = 1;
                        $approval = $approval . "<br> The item " . $request->name[$i] . ", was set with number of records as " . $request->price[$i]
                        . ". The number of records was originally set at " . $request->originalPrice[$i]
                        . ". Manager Approval Price is set at " . $request->managerPrice[$i]
                        . ". Jim's Approval Price is set at " . $request->jimPrice[$i] . ".";
                    }
                    if ($request->price[$i] > ($request->jimPrice[$i] == 0 ? $request->price[$i] : $request->jimPrice[$i])) {
                        $productObject['needsJimApproval'] = 1;
                        $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
                        $needs_jim_approval = 1;
                    }
                } else {
                    if ($request->price[$i] < $request->managerPrice[$i]) {
                        $productObject['needsManagerApproval'] = 1;
                        $needs_manager_approval = 1;
                        $approval = $approval . "<br> The item " . $request->name[$i] . ", was set at a price of $" . $this->convertPrice($request->price[$i])
                        . ". The price was originally set at $". $this->convertPrice($request->originalPrice[$i])
                        . ". Manager Approval Price is set at $" . $this->convertPrice($request->managerPrice[$i])
                        . ". Jim's Approval Price is set at $" . $this->convertPrice($request->jimPrice[$i]) . ".";
                    }
                    if ($request->price[$i] < $request->jimPrice[$i]) {
                        $productObject['needsJimApproval'] = 1;
                        $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
                        $needs_jim_approval = 1;
                    }
                }

                $products->push($productObject);
            }
        }

        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $client->company_name), 0, 100); // Removes special chars and trims to 100 chars

        $fpdf->Output('F', storage_path() . '/' . $company_name . '_MSA_Part-Two.pdf', true);

        $company_address_full = $request->company_address . ', ' . $request->company_city . ', ' . $request->company_state . ' ' . $request->company_zip;

        // Load part one as a template and store the document as $templateDocx1
        $template = new \PhpOffice\PhpWord\TemplateProcessor(storage_path() . '/' . 'Client MSA v3 part one.docx');
        $template->setValue('date', htmlspecialchars(date('l, F j, Y')));
        $template->setValue('company_name', htmlspecialchars($client->company_name));
        $template->setValue('company_name_2', htmlspecialchars($client->company_name));
        $template->setValue('company_name_3', htmlspecialchars($client->company_name));
        $template->setValue('company_address', htmlspecialchars($company_address_full));
        $templateDocx1 = storage_path() . '/' . $company_name . '_MSA_Part-One.docx';
        $template->saveAs($templateDocx1);

        // Load part three as a template and store the document as $templateDocx1
        $templateTwo = new \PhpOffice\PhpWord\TemplateProcessor(storage_path() . '/' . 'Client MSA v3 part three.docx');
        $templateDocx2 = storage_path() . '/' . $company_name . '_MSA_Part-Three.docx';
        $templateTwo->saveAs($templateDocx2);

        $contract = new Contract;
        $contract->makeContract($request, $client, "FCRA MSA", $products);

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup_FCRA_MSA_'.$date.'.pdf');
        $file_name = $directoryName . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_FCRA_MSA_' . $date . '.pdf';

        $contract->contract_name = $file_name;
        $contract->save();

        $templatePdf1 = storage_path() . '/' . $company_name . '_MSA_Part-One.pdf';
        $templatePdf2 = storage_path() . '/' . $company_name . '_MSA_Part-Three.pdf';

        /**
         * Try initially to convert the docx file to pdf, if it works continue on normally.
         * If it fails, update the status to converting and throw the process upon the queue.
         */
        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $templateDocx1]);
            $result->getFile()->save($templatePdf1);

            $result = ConvertApi::convert('pdf', ['File' => $templateDocx2]);
            $result->getFile()->save($templatePdf2);

            $history = new History($contract->id, $file_name, "Original contract generated. Awaiting client signature upload.");
        } catch (Exception $e) {
            $contract->delete();

            if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-One.docx'))
                unlink(storage_path() . '/' . $company_name . '_MSA_Part-One.docx');
            if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-Three.docx'))
                unlink(storage_path() . '/' . $company_name . '_MSA_Part-Three.docx');

            if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-One.pdf'))
                unlink(storage_path() . '/' . $company_name . '_MSA_Part-One.pdf');
            if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-Two.pdf'))
                unlink(storage_path() . '/' . $company_name . '_MSA_Part-Two.pdf');
            if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-Three.pdf'))
                unlink(storage_path() . '/' . $company_name . '_MSA_Part-Three.pdf');

            return redirect()->route('agentDashboard')->with('errorToast', 'MSA contract creation failed, please try again later. If this persists, please contact a developer.');

            $contract->status = 'converting';
            $contract->save();

            $history = new History($contract->id, $file_name, 'Original contract generation conversion failed. Sending upon queue to convert docx to pdf.');
            $files = array($templateDocx1 => $templatePdf1, $templateDocx2 => $templatePdf2);

            $job = new ConvertContract(
                Auth::user(),                                   // User currently generating the contract.
                $contract->id,                                  // Contract ID
                $files,                                         // Array of (docxFile => pdfPath)
                __CLASS__,                                      // Class Name
                array(
                    $contract,
                    $history,
                    Auth::user(),
                    $company_name,
                    $templatePdf1,
                    $templatePdf2,
                    $file_name,
                    $needs_manager_approval,
                    $needs_jim_approval,
                    $approval
                )                                               // Parameters for static function 'postConversion'
            );

            dispatch($job);
            return redirect()->route('agentDashboard')->with('information', 'MSA contract creation currently pending.');
        }

        if ($this->postConversion($contract, $history, Auth::user(), $company_name, $templatePdf1, $templatePdf2, $file_name, $needs_manager_approval, $needs_jim_approval, $approval))
            return redirect()->route('agentDashboard')->with('message', 'Contract Sent to Manager for Approval.');
        else
            return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

    /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param object $user pointer to currently authenticated user
     * @param string $company_name company's name with no spaces
     * @param string $templatePdf1 converted pdf file path 1
     * @param string $templatePdf2 converted pdf file path 2
     * @param string $file_name final pdf path in storage
     * @param boolean $needs_manager_approval
     * @param boolean $needs_jim_approval
     * @param string $approval
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($contract, $history, $user, $company_name, $templatePdf1, $templatePdf2, $file_name, $needs_manager_approval, $needs_jim_approval, $approval)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Merge all necessary PDF files into $file_name path
        $merger = new \iio\libmergepdf\Merger;
        $merger->addFile($templatePdf1);
        $merger->addFile(storage_path() . '/' . $company_name . '_MSA_Part-Two.pdf');
        $merger->addFile($templatePdf2);
        $createdPdf = $merger->merge();
        Storage::disk('local')->put($file_name, $createdPdf);

        // Remove all temporary files from storage
        if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-One.docx'))
            unlink(storage_path() . '/' . $company_name . '_MSA_Part-One.docx');
        if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-Three.docx'))
            unlink(storage_path() . '/' . $company_name . '_MSA_Part-Three.docx');

        if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-One.pdf'))
            unlink(storage_path() . '/' . $company_name . '_MSA_Part-One.pdf');
        if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-Two.pdf'))
            unlink(storage_path() . '/' . $company_name . '_MSA_Part-Two.pdf');
        if (is_file(storage_path() . '/' . $company_name . '_MSA_Part-Three.pdf'))
            unlink(storage_path() . '/' . $company_name . '_MSA_Part-Three.pdf');

        // Send mail containing attachment if necessary (1 = sent, 0 = unnecessary)
        $mailer = new RNNMailer(true);
        return $mailer->sendContractApproval($user, $needs_manager_approval, $needs_jim_approval, $contract, $history, $file_name, $approval);
    }

    /**
     * Fetch client data to fill input fields within the contract forms
     *
     * @param Request $request
     *
     * @return string JSON Encoded client data
     */
    public function fetchClientData(Request $request)
    {
        $client = Client::find($request->get('value'));
        $clientArray = array(
            'company_address' => $client->company_address,
            'company_city' => $client->company_city,
            'company_state' => $client->company_state,
            'company_zip' => $client->company_zip,
            'company_email' => $client->company_email,
            'company_ein' => $client->company_ein,
            'company_url' => $client->company_url,
            'company_phone' => $client->company_phone,
            'account_payable_name' => $client->account_payable_name,
            'account_payable_phone' => $client->account_payable_phone,
            'account_payable_email' => $client->account_payable_email,
            'invoice_approver_name' => $client->invoice_approver_name,
            'invoice_approver_phone' => $client->invoice_approver_phone,
            'invoice_approver_email' => $client->invoice_approver_email,
            'executive_contact_name' => $client->executive_contact_name,
            'executive_contact_phone' => $client->executive_contact_phone,
            'executive_contact_email' => $client->executive_contact_email
        );
        echo json_encode($clientArray);
    }
}