<?php

namespace App\Http\Controllers\Contracts;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Fpdf;
use File;
use Illuminate\Support\Facades\DB;
use ConvertApi\ConvertApi;
use PHPMailer\PHPMailer\PHPMailer;
use Exception;
use App\FPDF_Merge;
use Illuminate\Support\Facades\Auth;
use Mail;
use App\User;
use App\History;
use App\Contract;
use App\ApprovalMessage;
use App\Product_Headers;
use App\Products;
use App\FPDF_Custom;
use App\Client;
use App\Jobs\ConvertContract;
use App\RNNMailer;
use Illuminate\Support\Facades\Storage;

class RedlineController extends Controller
{
    /**
     * Show the redline start view
     *
     * @return View with clients
     */
    public function showRedlineStart()
    {
        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return view('contracts.redline')->with('clients', $clients);
    }

    public function convertPrice($price) {
        $price = (float) $price;
        if ($price <= 10 || fmod($price, 1) !== 0.0) {
            if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                $price = number_format($price, 2);
            }
        }
        return $price;
    }

    /**
     * Show the redline products view
     *
     * @param int $id contract unique identifier
     *
     * @return View with client, contract, products, and product headers
     */
    public function showRedlineProducts($id)
    {
        $contract = Contract::where('id', '=', $id)->first();
        $client = Client::where('id', $contract->client_id)->first();
        $product_headers = Product_Headers::orderBy('order', 'asc')->get();
        $products = Products::orderBy('order', 'asc')->get();
        foreach($products as $product)
            $product->removeZeros();

        return view('contracts.redlineProducts')->with('client', $client)->with('contract', $contract)->with('products', $products)->with('product_headers', $product_headers);
    }

    /**
     * exportRedlineStart
     *
     * @param Request $request POST request params
     *
     * @return Redirect with success or failure
     */
    public function exportRedlineStart(request $request)
    {
        $client = Client::find($request->input('company_id'));
        $company_address_full = $request->company_address . ', ' . $request->company_city . ', ' . $request->company_state . ' ' . $request->company_zip;

        $contract = new Contract;
        $contract->makeContract($request, $client, "REDLINE");
        $contract->status = 'awaiting_client_changes';
        $contract->save();

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'REDLINE/';

        // Load Redline template using PhpOffice and save as $storagePath
        $template = new \PhpOffice\PhpWord\TemplateProcessor(storage_path() . '/' . 'RNN MSA Redline v.3 last udpated 3.11.2019.docx');
        $template->setValue('date', htmlspecialchars(date('l, F j, Y')));
        $template->setValue('company_name', htmlspecialchars($client->company_name));
        $template->setValue('company_name_2', htmlspecialchars($client->company_name));
        $template->setValue('company_name_3', htmlspecialchars($client->company_name));
        $template->setValue('company_address', htmlspecialchars($company_address_full));

        $file_name = $directoryName;
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__REDLINE_'.$date.'.pdf');
        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $client->company_name), 0, 100); // Removes special chars and trims to 100 chars
        $file_name = $file_name . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_REDLINE_' . $date . '.docx';

        Storage::disk('local')->makeDirectory($directoryName);
        $storagePath = storage_path('app/public/' . $file_name);
        $template->saveAs($storagePath);

        $contract->contract_name = $file_name;
        $contract->save();

        $history = new History($contract->id, $file_name, "Redline contract generated. Awaiting client changes upload.");

        return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

    /**
     * Export Redline MSA contract
     *
     * @param Request $request POST request params
     *
     * @return Redirect with success or failure
     */
    public function exportRedlineWithProducts(request $request)
    {
        $contract = Contract::where('id', '=', $request->contract_ID)->first();

        // Validate that if the company's email was changed that it is unique
        if ($request->input('company_email') !== $contract->company_email) {
            $this->validate($request, [
                'company_email' => ['unique:client_profiles,company_email'],
            ]);
        }


        // Generate part two of the Redline using FPDF
        $fpdf = new FPDF_Custom();
        $fpdf->drawScheduleAHeader();

        $fpdf->MultiCell(160, 5, 'Clients will have access to the RNN Web App to build their product ' .
            'and tier waterfall at the file level for all products as listed below.', 0, 'L', false);

        $fpdf->SetTextColor(161, 0, 0);
        $fpdf->SetFont('Calibri-Bold', '', 10);
        $fpdf->SetTextColor(0, 0, 0);

        if (!empty($request->name))
            $count = count($request->name);
        else
            $count = 0;

        $header_id = 0;
        $approval = "These items are waiting approval: ";
        $needs_manager_approval = 0;
        $needs_jim_approval = 0;

        $products = collect();
        if ($count != 0) {
            for ($i = 0; $i < $count; $i++) {
                if ($request->prod_header_id[$i] != $header_id) {
                    $prod_header = Product_Headers::find($request->prod_header_id[$i]);
                    $header_id = $request->prod_header_id[$i];
                    $fpdf->buildProductHeader($prod_header);
                }

                $fpdf->SetFont('Calibri', '', 10);
                $fpdf->buildProductCell($request, $i);

                $productObject = [
                    'productId' => $request->id[$i],
                    'productName' => $request->name[$i],
                    'productHeaderId' => $header_id,
                    'productHeaderName' => $prod_header->name,
                    'useQuote' => $request->use_quote[$i],
                    'price' => $request->price[$i],
                    'needsManagerApproval' => 0,
                    'needsJimApproval' => 0,
                    'reason' => $request->reason[$i] ?? ''
                ];

                if ($request->use_quote[$i] == 1) {
                    $products->push($productObject);
                    continue;
                }

                // Checking to see if the price has been set below the manager thresholds.
                if ($request->prod_header_id[$i] == 11) {

                    if ($request->price[$i] > ($request->managerPrice[$i] == 0 ? $request->price[$i] : $request->managerPrice[$i])) {
                        $productObject['needsManagerApproval'] = 1;
                        $needs_manager_approval = 1;
                        $approval = $approval . "<br> The item " . $request->name[$i] . ", was set with number of records as " . $request->price[$i]
                        . ". The number of records was originally set at " . $request->originalPrice[$i]
                        . ". Manager Approval Price is set at " . $request->managerPrice[$i]
                        . ". Jim's Approval Price is set at " . $request->jimPrice[$i] . ".";
                    }
                    if ($request->price[$i] > ($request->jimPrice[$i] == 0 ? $request->price[$i] : $request->jimPrice[$i])) {
                        $productObject['needsJimApproval'] = 1;
                        $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
                        $needs_jim_approval = 1;
                    }
                } else {
                    if ($request->price[$i] < $request->managerPrice[$i]) {
                        $productObject['needsManagerApproval'] = 1;
                        $needs_manager_approval = 1;
                        $approval = $approval . "<br> The item " . $request->name[$i] . ", was set at a price of $" . $this->convertPrice($request->price[$i])
                        . ". The price was originally set at $". $this->convertPrice($request->originalPrice[$i])
                        . ". Manager Approval Price is set at $" . $this->convertPrice($request->managerPrice[$i])
                        . ". Jim's Approval Price is set at $" . $this->convertPrice($request->jimPrice[$i]) . ".";
                    }
                    if ($request->price[$i] < $request->jimPrice[$i]) {
                        $productObject['needsJimApproval'] = 1;
                        $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
                        $needs_jim_approval = 1;
                    }
                }

                $products->push($productObject);
            }
        }

        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $contract->company_name), 0, 100); // Removes special chars and trims to 100 chars
        $fpdf->Output('F', storage_path() . '/' . $company_name . 'MSA_Part-Two.pdf', true);
        $filePath = storage_path() . '/app/public/' . $contract->contract_name;
        $filePartOnePdf = storage_path() . '/' . $company_name . '_MSA_Part-One.pdf';

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__REDLINE_'.$date.'.pdf');
        $file_name = $directoryName . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_REDLINE_' . $date . '.pdf';
        $contract->updateContract($request, $file_name, $products);

        /**
         * Try initially to convert the docx file to pdf, if it works continue on normally.
         * If it fails, update the status to converting and throw the process upon the queue.
         */
        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $filePath]);
            $result->getFile()->save($filePartOnePdf);

            $history = new History($contract->id, $file_name, "Original contract generated. Awaiting client signature upload.");
        } catch (Exception $e) {
            $contract->delete();

            if (is_file(storage_path() . '/' . $company_name . 'MSA_Part-Two.pdf'))
                unlink(storage_path() . '/' . $company_name . 'MSA_Part-Two.pdf');
            if (is_file($filePartOnePdf))
                unlink($filePartOnePdf);

            return redirect()->route('agentDashboard')->with('errorToast', 'MSA Redline contract creation failed, please try again later. If this persists, please contact a developer.');

            $contract->status = 'converting';
            $contract->save();

            $history = new History($contract->id, $file_name, 'Original contract generation conversion failed. Sending upon queue to convert docx to pdf.');
            $files = array($filePath => $filePartOnePdf);

            $job = new ConvertContract(
                Auth::user(),                                   // User currently generating the contract.
                $contract->id,                                  // Contract ID
                $files,                                         // Array of (docxFile => pdfPath)
                __CLASS__,                                      // Class Name
                array(
                    $contract,
                    $history,
                    Auth::user(),
                    $company_name,
                    $filePartOnePdf,
                    $file_name,
                    $needs_manager_approval,
                    $needs_jim_approval,
                    $approval
                )                                               // Parameters for static function 'postConversion'
            );

            dispatch($job);
            return redirect()->route('agentDashboard')->with('information', 'Redline MSA contract creation is currently pending.');
        }

        if ($this->postConversion($contract, $history, Auth::user(), $company_name, $filePartOnePdf, $file_name, $needs_manager_approval, $needs_jim_approval, $approval))
            return redirect()->route('agentDashboard')->with('message', 'Contract Sent to Manager for Approval.');
        else
            return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

    /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param object $user pointer to authenticated user authenticated
     * @param string $company_name company's name with no spaces
     * @param string $filePartOnePdf converted pdf file path
     * @param string $file_name final pdf path in storage
     * @param boolean $needs_manager_approval
     * @param boolean $needs_jim_approval
     * @param string $approval
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($contract, $history, $user, $company_name, $filePartOnePdf, $file_name, $needs_manager_approval, $needs_jim_approval, $approval)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Merge all necessary PDF files into $mergedPdf path
        $merger = new \iio\libmergepdf\Merger;
        $merger->addFile($filePartOnePdf);
        $merger->addFile(storage_path() . '/' . $company_name . 'MSA_Part-Two.pdf');
        $createdPdf = $merger->merge();

        // Remove all temporary files from storage
        if (is_file(storage_path() . '/' . $company_name . 'MSA_Part-Two.pdf'))
            unlink(storage_path() . '/' . $company_name . 'MSA_Part-Two.pdf');
        if (is_file($filePartOnePdf))
            unlink($filePartOnePdf);

        Storage::disk('local')->put($file_name, $createdPdf);

        // Send mail containing attachment if necessary (1 = sent, 0 = unnecessary)
        $mailer = new RNNMailer(true);
        return $mailer->sendContractApproval($user, $needs_manager_approval, $needs_jim_approval, $contract, $history, $file_name, $approval);
    }
}