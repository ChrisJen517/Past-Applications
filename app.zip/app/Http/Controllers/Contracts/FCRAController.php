<?php

namespace App\Http\Controllers\Contracts;

use App\Http\Controllers\Controller;
use App\ApprovalMessage;
use App\Client;
use App\Contract;
use App\FPDF_Custom;
use App\History;
use App\Jobs\ConvertContract;
use App\Products;
use App\Product_Headers;
use App\User;
use App\RNNMailer;
use Illuminate\Support\Facades\Auth;
use ConvertApi\ConvertApi;
use Exception;
use Illuminate\Http\Request;
use PHPMailer\PHPMailer\PHPMailer;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\DB;

class FCRAController extends Controller
{
    /**
     * Show the FCRA contract generation view
     *
     * @return view with product headers, products, and clients
     */
    public function showFCRA()
    {
        $product_headers = Product_Headers::orderBy('order', 'asc')->get();
        $products = Products::orderBy('order', 'asc')->get();
        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        foreach($products as $product)
            $product->removeZeros();

        return view('contracts.FCRA')->with('product_headers', $product_headers)->with('products', $products)->with('clients', $clients);
    }

    public function convertPrice($price) {
        $price = (float) $price;
        if ($price <= 10 || fmod($price, 1) !== 0.0) {
            if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                $price = number_format($price, 2);
            }
        }
        return $price;
    }

    /**
     * Export an FCRA Amendment contract
     *
     * @param Request $request POST parameters
     *
     * @return Redirect with success or failure
     */
    public function exportFCRA(Request $request)
    {
        $client = Client::find($request->input('company_id'));
        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $client->company_name), 0, 100); // Removes special chars and trims to 100 chars
        // Verify that if a new email is specified that it is unique
        if ($request->input('company_email') !== $client->company_email) {
            $this->validate($request, [
                'company_email' => ['unique:client_profiles,company_email'],
            ]);
        }

        // Generate the FCRA Amendment using FPDF
        $year = date("Y");
        $month = date("m");
        $day = date("d");

        $date = $month . ' ' . $day . ', ' . $year;

        if (!empty($request->name)) {
            $count = count($request->name);
        } else {
            $count = 0;
        }
        $header_id = 0;
        $approval = "These items are waiting approval: ";
        $needs_manager_approval = 0;
        $needs_jim_approval = 0;
        $products = collect();
        if ($count != 0) {
            $fpdf = new FPDF_Custom();
            $fpdf->FCRAHeader($client, $request);
            for ($i = 0; $i < $count; $i++) {
                if ($request->prod_header_id[$i] != $header_id) {
                    $prod_header = Product_Headers::find($request->prod_header_id[$i]);
                    $header_id = $request->prod_header_id[$i];
                    $fpdf->buildProductHeader($prod_header);
                }
                $fpdf->SetFont('Calibri', '', 10);
                $fpdf->buildProductCell($request, $i);

                $productObject = [
                    'productId' => $request->id[$i],
                    'productName' => $request->name[$i],
                    'productHeaderId' => $header_id,
                    'productHeaderName' => $prod_header->name,
                    'useQuote' => $request->use_quote[$i],
                    'price' => $request->price[$i],
                    'needsManagerApproval' => 0,
                    'needsJimApproval' => 0,
                    'reason' => $request->reason[$i] ?? ''
                ];

                if ($request->use_quote[$i] == 1) {
                    $products->push($productObject);
                    continue;
                }

                // Checking to see if the price has been set below the manager thresholds.
                if ($request->prod_header_id[$i] == 11) {

                    if ($request->price[$i] > ($request->managerPrice[$i] == 0 ? $request->price[$i] : $request->managerPrice[$i])) {
                        $productObject['needsManagerApproval'] = 1;
                        $needs_manager_approval = 1;
                        $approval = $approval . "<br> The item " . $request->name[$i] . ", was set with number of records as " . $request->price[$i]
                        . ". The number of records was originally set at " . $request->originalPrice[$i]
                        . ". Manager Approval Price is set at " . $request->managerPrice[$i]
                        . ". Jim's Approval Price is set at " . $request->jimPrice[$i] . ".";
                    }
                    if ($request->price[$i] > ($request->jimPrice[$i] == 0 ? $request->price[$i] : $request->jimPrice[$i])) {
                        $productObject['needsJimApproval'] = 1;
                        $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
                        $needs_jim_approval = 1;
                    }
                } else {
                    if ($request->price[$i] < $request->managerPrice[$i]) {
                        $productObject['needsManagerApproval'] = 1;
                        $needs_manager_approval = 1;
                        $approval = $approval . "<br> The item " . $request->name[$i] . ", was set at a price of $" . $this->convertPrice($request->price[$i])
                        . ". The price was originally set at $". $this->convertPrice($request->originalPrice[$i])
                        . ". Manager Approval Price is set at $" . $this->convertPrice($request->managerPrice[$i])
                        . ". Jim's Approval Price is set at $" . $this->convertPrice($request->jimPrice[$i]) . ".";
                    }
                    if ($request->price[$i] < $request->jimPrice[$i]) {
                        $productObject['needsJimApproval'] = 1;
                        $approval .= " The reasoning for this price " . (!empty($request->reason[$i]) ? "is: '" . $request->reason[$i] . "'.": "was not specified.");
                        $needs_jim_approval = 1;
                    }
                }

                $products->push($productObject);
            }
            $fpdf->Output('F', storage_path() . '/' . $company_name . 'FCRAAmendment.pdf', true);
        }


        // Load docx template for FCRA template using PHPOffice and save as $file_name
        $template = new \PhpOffice\PhpWord\TemplateProcessor(storage_path() . '/' . 'FCRA amendment to Contract.docx');
        $template->setValue('date', htmlspecialchars(date('l, F j, Y')));
        $template->setValue('company_name', htmlspecialchars($client->company_name));
        $template->setValue('company_name_2', htmlspecialchars($client->company_name));
        $template->setValue('effective_date', htmlspecialchars($request->original_date));
        $file_name = storage_path() . '/' . $company_name . '_Amendment_part_1.docx';
        $template->saveAs($file_name);

        $contract = new Contract;
        $contract->makeContract($request, $client, "FCRA Amendment", $products);

        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__FCRA_Amendment_'.$date.'.pdf');
        $mergedPdf = $directoryName . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_FCRA_Amendment_' . $date . '.pdf';

        $contract->contract_name = $mergedPdf;
        $contract->save();

        $filePdf = storage_path() . '/' . $company_name . '_Amendment_part_1.pdf';

        /**
         * Try initially to convert the docx file to pdf, if it works continue on normally.
         * If it fails, update the status to converting and throw the process upon the queue.
         */
        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $file_name]);
            $result->getFile()->save($filePdf);

            $history = new History($contract->id, $mergedPdf, "Original contract generated. Awaiting client signature upload.");
        } catch (Exception $e) {
            $contract->delete();

            if (is_file(storage_path() . '/' . $company_name . 'FCRAAmendment.pdf'))
                unlink(storage_path() . '/' . $company_name . 'FCRAAmendment.pdf');
            if (is_file($filePdf))
                unlink($filePdf);
            if (is_file($file_name))
                unlink($file_name);

            return redirect()->route('agentDashboard')->with('errorToast', 'FCRA contract creation failed, please try again later. If this persists, please contact a developer.');

            $contract->status = 'converting';
            $contract->save();

            $history = new History($contract->id, $mergedPdf, 'Original contract generation conversion failed. Sending upon queue to convert docx to pdf.');
            $files = array($file_name => $filePdf);

            $job = new ConvertContract(
                Auth::user(),                                   // User currently generating the contract.
                $contract->id,                                  // Contract ID
                $files,                                         // Array of (docxFile => pdfPath)
                __CLASS__,                                      // Class Name
                array(
                    $contract,
                    $history,
                    Auth::user(),
                    $file_name,
                    $company_name,
                    $filePdf,
                    $mergedPdf,
                    $needs_manager_approval,
                    $needs_jim_approval,
                    $approval
                )                                               // Parameters for static function 'postConversion'
            );

            dispatch($job);
            return redirect()->route('agentDashboard')->with('information', 'Contract creation currently pending.');
        }

        if ($this->postConversion($count, $contract, $history, Auth::user(), $file_name, $company_name, $filePdf, $mergedPdf, $needs_manager_approval, $needs_jim_approval, $approval))
            return redirect()->route('agentDashboard')->with('message', 'Contract Sent to Manager for Approval.');
        else
            return redirect()->route('agentDashboard')->with('message', 'Contract Created.');
    }

    /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param object $user pointer to currently authenticated user
     * @param string $file_name docx path in storage
     * @param string $company_name company's name with no spaces
     * @param string $filePdf converted pdf file path
     * @param string $mergedPdf path to store the final pdf post-merge
     * @param boolean $needs_manager_approval
     * @param boolean $needs_jim_approval
     * @param string $approval
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($count, $contract, $history, $user, $file_name, $company_name, $filePdf, $mergedPdf, $needs_manager_approval, $needs_jim_approval, $approval)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Merge all necessary PDF files into $mergedPdf path
        $merger = new \iio\libmergepdf\Merger;
        $merger->addFile($filePdf);
        if($count != 0)
            $merger->addFile(storage_path() . '/' . $company_name . 'FCRAAmendment.pdf');
        $createdPdf = $merger->merge();
        Storage::disk('local')->put($mergedPdf, $createdPdf);

        // Remove all temporary files from storage
        if (is_file(storage_path() . '/' . $company_name . 'FCRAAmendment.pdf'))
            unlink(storage_path() . '/' . $company_name . 'FCRAAmendment.pdf');
        if (is_file($filePdf))
            unlink($filePdf);
        if (is_file($file_name))
            unlink($file_name);

        // Send mail containing attachment if necessary (1 = sent, 0 = unnecessary)
        $mailer = new RNNMailer(true);
        return $mailer->sendContractApproval($user, $needs_manager_approval, $needs_jim_approval, $contract, $history, $mergedPdf, $approval);
    }
}