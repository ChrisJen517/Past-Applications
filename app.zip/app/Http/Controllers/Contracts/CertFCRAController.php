<?php

namespace App\Http\Controllers\Contracts;

use PhpOffice\PhpWord\TemplateProcessor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use App\History;
use App\Client;
use App\Contract;
use App\Events\ContractUpdated;
use App\Jobs\ConvertContract;
use ConvertApi\ConvertApi;
use Exception;
use ReflectionClass;

class CertFCRAController extends Controller {

    /**
     * Show an Certification of FCRA Permissible Purpose: Collection contract
     *
     * @return View agreement form
     */
    function showCertFCRA()
    {
        $clients = Client::orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        return view('contracts.CertFCRA')->with('clients', $clients);
    }

    /**
     * Export an Certification of FCRA Permissible Purpose: Collection contract
     *
     * @param Request $request POST parameters
     *
     * @return Redirect with success or failure
     */
    public function exportCertFCRA(Request $request)
    {
         /**
         * Find the client and verify that their email is unique if changed
         */
        $client = Client::find($request->input('company_id'));

        if ($request->input('company_email') !== $client->company_email) {
            $this->validate($request, [
                'company_email' => ['unique:client_profiles,company_email'],
            ]);
        }

        $company_name = substr(preg_replace('/[^A-Za-z0-9\-]/', '', $client->company_name), 0, 100); // Removes special chars and trims to 100 chars
        $company_address_full = $request->company_address . ', ' . $request->company_city . ', ' . $request->company_state . ' ' . $request->company_zip;
        $fileNameDoc = storage_path() . '/' . $company_name . '_CertFCRA.docx';

        /**
         * Load the NDA template and fill in the company's name and address
         */
        $template = new TemplateProcessor(storage_path() . '/' . 'Certification of FCRA Permissible Purpose - Collection v1.docx');
        $template->setValue('company_name', htmlspecialchars($client->company_name));
        $template->saveAs($fileNameDoc);

        /**
         * Store the contract data
         */
        $contract = new Contract;
        $contract->makeContract($request, $client, 'FCRA Certification');

        /**
         * Store the client data
         */
        $client->fill($request->all());
        $client->save();

        /**
         * Create directory that will hold the NDA pdf
         */
        $directoryName = 'GeneratedReports/' . $contract->id . '/' . 'Original_Contract/';
        Storage::disk('local')->makeDirectory($directoryName);

        /**
         * Format the file name
         */

        $date = date('F_j_Y');
        $file_name_count = 99;
        $file_name_count -= strlen('RNNGroup__CertFCRA_'.$date.'.pdf');
        $fileName = $directoryName . 'RNNGroup_' . substr($company_name, 0, $file_name_count) . '_CertFCRA_' . $date . '.pdf';
        $storagePath = storage_path('app/public/' . $fileName);

        /**
         * Update contract model's path to NDA
         */
        $contract->contract_name = $fileName;
        $contract->save();

        /**
         * Use ConvertAPI to convert .docx => .pdf
         * Try initially to convert the docx file to pdf, if it works continue on normally.
         * If it fails, update the status to converting and throw the process upon the queue.
         */
        try {
            ConvertApi::setApiSecret('lmtkLhMybML7470c');
            $result = ConvertApi::convert('pdf', ['File' => $fileNameDoc]);
            $result->getFile()->save($storagePath);
            $history = new History($contract->id, $fileName, 'Initialized contract creation.');
        } catch (Exception $e) {
            $contract->delete();

            if (is_file($fileNameDoc))
                unlink($fileNameDoc);

            return redirect()->route('agentDashboard')->with('errorToast', 'FCRA Certification contract creation failed, please try again later. If this persists, please contact a developer.');

            $contract->status = 'converting';
            $contract->save();

            $history = new History($contract->id, $fileName, 'Original contract generation conversion failed. Sending upon queue to convert docx to pdf.');
            $files = array($fileNameDoc => $storagePath);

            $job = new ConvertContract(
                Auth::user(),                                   // User currently generating the contract.
                $contract->id,                                  // Contract ID
                $files,                                         // Array of (docxFile => pdfPath)
                __CLASS__,                                      // Class Name
                array($contract, $history, $fileNameDoc)        // Parameters for static function 'postConversion'
            );

            dispatch($job);
            return redirect()->route('agentDashboard')->with('information', 'Contract creation currently pending.');
        }

        $this->postConversion($contract, $history, $fileNameDoc);
        return redirect()->route('agentDashboard')->with('message', 'Contract Created.');

    }

        /**
     * Everything that must be done following the conversion from docx => pdf of contract files.
     *
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param string $client_name company's name with no spaces
     *
     * @return Redirect to dashboard with success or failure
     */
    public static function postConversion($contract, $history, $fileNameDoc)
    {
        // Set contract status if not already updated.
        if ($contract->status !== 'awaiting_final_upload') {
            $contract->status = 'awaiting_final_upload';
            $contract->save();
        }

        // Update history to assure that RNN is now awaiting the client signature upload.
        $history->description = 'Original contract generated. Awaiting client signature upload.';
        $history->save();

        // Remove all temporary files from storage
        if (is_file($fileNameDoc))
            unlink($fileNameDoc);
    }
}