<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

use App\User;

class AccountController extends Controller
{
    public function showChangePassword()
    {
        if (Auth::user()->password_valid == 0)
            return view('login/changePassword');
        else
            return redirect('/success');
    }

    public function changePassword(Request $request)
    {
        //Validating request
        $this->validate($request, [
            'newPasswordName' => 'required'
        ]);

        $user = Auth::user();

        $user->password = bcrypt($request->input('newPasswordName'));
        $user->password_valid = 1;
        $user->save();

        if (Auth::user()->role == 'agent') {
            return redirect('/dashboard')->with('message', 'Password Changed');
        } else if (Auth::user()->role == 'manager') {
            return redirect('/manager/dashboard')->with('message', 'Password Changed');
        }
    }
}
