<?php

namespace App\Http\Controllers\Agent;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\Contract;
use App\History;

class DashboardController extends Controller
{
    public function showDashboard()
    {
        if (Auth::user()->role == 'manager') {
            $toPass = [];
            $possible = ['message', 'error', 'success', 'information', 'errorToast', 'successToast'];

            foreach ($possible as $p) {
                if (Session::has($p)) {
                    $toPass[$p] = Session::get($p);
                }
            }

            return redirect('/manager/dashboard')->with($toPass);
        }

        $user_id = Auth::user()->id;
        $contracts = DB::table('contracts')->selectRaw("contracts.*, client_profiles.account_payable_name, client_profiles.invoice_approver_name, client_profiles.executive_contact_name")
        ->join('client_profiles', 'client_profiles.id', '=', 'contracts.client_id')
        ->orderByRaw('contracts.id desc')->where('agent_reference', $user_id)->get();

        return view('agent.dashboard')->with('contracts', $contracts);
        
    }

    public function archiveContract($id)
    {
        $contract = Contract::find($id);
        if ($contract == null)
            return back()->with('errorToast', 'Contract not found.');

        if ($contract->is_archived == null || $contract->is_archived == 0) {
            $contract->is_archived = 1;
            $contract->save();

            $history = new History($contract->id, $contract->contract_name, "Contract Archived.");
        } else if ($contract->is_archived == 1) {
            $contract->is_archived = 0;
            $contract->save();

            $history = new History($contract->id, $contract->contract_name, "Contract Un-Archived.");
        }
        return back()->with('success', 'Contract Updated.');
    }
}