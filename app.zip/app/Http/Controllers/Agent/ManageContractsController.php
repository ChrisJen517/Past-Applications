<?php

namespace App\Http\Controllers\Agent;

use App\Http\Controllers\Controller;

use Illuminate\Http\Request;
use Fpdf;
use File;
use Illuminate\Support\Facades\DB;
use ConvertApi\ConvertApi;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use App\RNNMailer;
use App\FPDF_Merge;
use Illuminate\Support\Facades\Auth;
use Mail;
use App\User;
use App\History;
use App\Contract;
use Illuminate\Support\Facades\Storage;
use App\ApprovalMessage;
use App\Product_Headers;
use App\Products;
use App\FPDF_Custom;
use App\Client;
use App\Contract_Product_History;

class ManageContractsController extends Controller
{
    public function manageContract($id)
    {
        $contract = Contract::find($id);
        $client = Client::find($contract->client_id);

        $name_options = "";
        if(isset($client->account_payable_name)) {
            $name_options .= "<br>" . $client->account_payable_name;
        }
        if(isset($client->invoice_approver_name)) {
            $name_options .= "<br>" . $client->invoice_approver_name;
        }
        if(isset($client->executive_contact_name)) {
            $name_options .= "<br>" . $client->executive_contact_name;
        }

        $history = DB::table('contract_history')->orderByRaw('id desc')->where('contract_reference_id', '=', $id)->get();
        $products = Contract_Product_History::select('product_name', 'price')->where('contract_id', $id)->get();
        $address = $contract->company_address . ', ' . $contract->company_city . ', ' . $contract->company_state . ' ' . $contract->company_zip;
        return view('agent.manageContract')->with('contract', $contract)->with('history', $history)->with('address', $address)->with('products',  $products)->with('name_options',  $name_options);
    }

    public function manageContractApi($id)
    {
        $contract = Contract::find($id);
        $history = DB::table('contract_history')->orderByRaw('id desc')->where('contract_reference_id', '=', $id)->get();
        $address = $contract->company_address . ', ' . $contract->company_city . ', ' . $contract->company_state . ' ' . $contract->company_zip;

        $histories = [];     
        foreach($history as $update){
            $histories[] = [$update->created_at, $update->description];
        }   

        switch($contract->status){
            case 'awaiting_jim_approval':
            case 'awaiting_manager_approval':
                $status = "Awaiting Manager Approval";
            break;
            case'awaiting_final_upload':
                $status = "Awaiting Final Contract Upload";
            break;
            case'complete':
                $status = "Contract Complete";
            break;
            case'awaiting_all_signature':
                $status = "Contract awaiting signatures by client and RNN.";
            break;
            case'awaiting_client_signature':
                $status = "Contract awaiting signature by client.";
            break;
            case'awaiting_jim_signature':
                $status = "Contract awaiting signature by RNN.";
            break;
            case'awaiting_client_changes':
                $status = "Awaiting Client Changes";
            break;
            case'awaiting_legal_approval':
                $status = "Awaiting Legal Approval";
            break;
            case'awaiting_product_selection':
                $status = "Awaiting Product Selection";
            break;
            case 'void':
                $status = "Voided";
            break;
        }

        $contract = [$contract->id, $contract->company_name, $address, date('Y-m-d H:i:s', strtotime($contract->created_at)), $status];

        return response()->json(['History' => $histories, 'Contract' => $contract]);
    }

    public function uploadCustomerChanges(Request $request)
    {
        $request->validate([
            'uploadFile' => 'required|mimes:docx,pdf',
        ]);
        $directoryName = 'GeneratedReports/' . $request->contractID . '/' . 'Client_Changes/';
        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();

        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $history = new History($request->contractID, $file_name, "Client changes uploaded. Awaiting legal approval.");

        $contract = Contract::where('id', '=', $request->contractID)->first();
        $contract->status = 'awaiting_legal_approval';
        $contract->approval_needed = 1;
        $contract->contract_name = $file_name;
        $contract->save();

        $file_name = $contract->contract_name;

        $agentName = Auth::user()->name_first . ' ' . Auth::user()->name_last;

        $mail = new RNNMailer(true);
        $mail->addAddresses(array('christianj@rnngroup.com', 'dennisg@rnngroup.com', 'scottm@rnngroup.com', 'stevet@rnngroup.com'));

        $mail->addAttachment($storage);        // Add attachment
        $link = 'http://contract.rnngroup.com/legalApprove/$2y$10$72OFQ.ByneknikAMSeaYxu/PJW2LTdObBQsDWBagvo1sekQp.tWeO/' . $contract->id;
        $mail->Subject = '[Contract Portal] Redline Customer Changes Legal Approval';
        $mail->CharSet = 'UTF-8';
        $mail->Body    = '<p>' . $agentName . ' is undergoing a redline contract with ' . $contract->company_name . '. The contract needs legal approval. Any changes have been redlined in the attached document. Redline password is RNN123!@# and does not need to be turned off to proceed. Please navigate to the link to approve the changes.</p><p>' . $link . '</p>';
        $mail->send();

        return back()->with('message', 'File uploaded successfully. Email sent to legal team.');
    }

    public function uploadContractChanges(Request $request)
    {
        $directoryName = 'GeneratedReports/' . $request->contractID . '/' . 'Client_Signature/';

        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();

        // -----StorageUpdateV2
        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $history = new History($request->contractID, $file_name, "Contract Changes Uploaded.");

        $contract = Contract::where('id', '=', $request->contractID)->first();
        $contract->status = 'complete';
        $contract->contract_name = $file_name;
        $contract->save();

        return back()->with('message', 'Contract uploaded successfully, thank you.');
    }

    public function uploadRedlineChanges(Request $request)
    {
        $request->validate([
            'uploadFile' => 'required|mimes:docx',
        ]);
        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $history = new History($request->contractID, $file_name, "Client changes uploaded. Awaiting legal approval.");
        $history->file_name = 'GeneratedReports/' . $request->contractID . '/' . 'Changes/'.$history->id.'/'.$file_name;
        $history->save();

        $directoryName = 'GeneratedReports/' . $request->contractID . '/' . 'Changes/'.$history->id.'/';

        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();

        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $contract = Contract::where('id', '=', $request->contractID)->first();
        $contract->status = 'awaiting_legal_approval';
        $contract->approval_needed = 1;
        $contract->contract_name = $file_name;
        $contract->save();

        $agentName = Auth::user()->name_first . ' ' . Auth::user()->name_last;

        $mail = new RNNMailer(true);
        $mail->addAddresses(array('christianj@rnngroup.com', 'dennisg@rnngroup.com', 'scottm@rnngroup.com', 'stevet@rnngroup.com'));

        $mail->addAttachment($storage);        // Add attachment
        $link = 'http://contract.rnngroup.com/legalApprove/$2y$10$72OFQ.ByneknikAMSeaYxu/PJW2LTdObBQsDWBagvo1sekQp.tWeO/' . $contract->id;
        $mail->Subject = '[Contract Portal] Redline Changes Legal Approval';
        $mail->CharSet = 'UTF-8';
        $mail->Body    = '<p>' . $agentName . ' has uploaded changes for the Redline with ' . $contract->company_name . '. The contract needs legal approval. Any changes have been redlined in the attached document. Redline password is RNN123!@# and does not need to be turned off to proceed. Please navigate to the link to approve the changes.</p><p>' . $link . '</p>';
        $mail->send();

        return back()->with('message', 'File uploaded successfully. Email sent to legal team.');
    }

    public function uploadCustomerSignature(Request $request)
    {
        $directoryName = 'GeneratedReports/' . $request->contractID . '/' . 'Client_Signature/';

        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();

        // -----StorageUpdateV2
        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $history = new History($request->contractID, $file_name, "Final Contract Uploaded.");

        $contract = Contract::where('id', '=', $request->contractID)->first();
        $contract->status = 'complete';
        $contract->contract_name = $file_name;
        $contract->save();

        return back()->with('message', 'Contract uploaded successfully, thank you.');
    }

    public function uploadManagerSignature(Request $request)
    {
        $file_name = $request->file('uploadFile')->getClientOriginalName();

        $file = $request->file('uploadFile');
        $fileExtension = $request->file('uploadFile')->getClientOriginalExtension();
        $directoryName = 'GeneratedReports/' . $request->contractID . '/' . 'Manager_Signature/';
        // -----StorageUpdateV2
        Storage::disk('local')->makeDirectory($directoryName);
        $storageDirectory = storage_path('app/public/' . $directoryName);
        $file->move($storageDirectory, $file_name);
        $file_name = $directoryName . $file_name;
        $storage = storage_path('app/public/' . $file_name);

        $history = new History($request->contractID, $file_name, "Manager signature uploaded. All signatures acquired. Contract complete.");

        $contract = Contract::where('id', '=', $request->contractID)->first();
        $contract->status = 'complete';
        $contract->contract_name = $file_name;
        $contract->save();

        $user = User::where('id', '=', $contract->agent_reference)->first();

        try {
            $mail = new RNNMailer(true);
            $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));

            // Attachments
            $mail->addAttachment($storage);         // Add attachment
            $mail->CharSet = 'UTF-8';

            $link = 'http://contract.rnngroup.com/';
            $mail->Subject = '[Contract Portal] Contract with ' . $contract->company_name . ' Completed';
            $mail->Body    = '<p>' . $user->name_first . ', you have completed Contract id: ' . $contract->id . ' with ' . $contract->company_name . '. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';
            $mail->send();

            return back()->with('message', 'File uploaded successfully.');
        } catch (\Throwable $e) {
            try {
                $mail = new RNNMailer(true);
                $mail->addAddresses(array($user->email, 'christianj@rnngroup.com'));
    
                // Attachments
                $mail->addAttachment($storage);         // Add attachment
                $mail->CharSet = 'UTF-8';
    
                $link = 'http://contract.rnngroup.com/';
                $mail->Subject = '[Contract Portal] Contract with ' . $contract->company_name . ' Completed';
                $mail->Body    = '<p>' . $user->name_first . ', you have completed Contract id: ' . $contract->id . ' with ' . $contract->company_name . '. Please click the link to access the Contract Portal.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Access the Contract Portal.</a>';
                $mail->send();
    
                return back()->with('message', 'File uploaded successfully.');
            } catch (\Throwable $e) {
                return back()->with('error', 'Something went wrong, submit again or reach out to christianj@rnngroup.com');
            }
        }
    }
}