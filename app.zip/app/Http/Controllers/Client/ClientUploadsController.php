<?php

namespace App\Http\Controllers\Client;

use App\Client;
use App\RNNMailer;
use App\User;
use App\Client_Email;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SebastianBergmann\Environment\Console;
use Yajra\DataTables\Facades\DataTables;
use Storage;
use Log;

class ClientUploadsController extends Controller
{
    public function showClientLogin()
    {   
        return view('client_uploads.login');
    }

    public function checkClientLogin(Request $request)
    {   
        $email = Client_Email::where('recipient', $request->email)->where('password', $request->password)->where('status', 'sent')->where('archived', 0)->first();
        
        if(isset($email)) {
            $client = Client::find($email->client_id);
            
            $original_files = Storage::files('sendEmail/' . $email->client_id . '/' . $email->id . '/originalFiles');
            $original_files_names = [];
            foreach($original_files as $original_file)
                $original_files_names[] = basename($original_file);

            $uploaded_files = Storage::files('sendEmail/' . $email->client_id . '/' . $email->id . '/clientFiles');
            $uploaded_files_names = [];
            foreach($uploaded_files as $uploaded_file)
                $uploaded_files_names[] = basename($uploaded_file);

            
            return view('client_uploads.files')->with('files', $original_files_names)->with('password', $request->password)->with('email', $request->email)->with('uploaded_files', $uploaded_files_names);
        } else {
            return redirect()->route('showClientLogin')->with('error', 'That email and password do not match a valid request');
        }
    }

    public function downloadDocument($file_name, $email, $password)
    {      
        $email = Client_Email::where('recipient', $email)->where('password', $password)->where('status', 'sent')->where('archived', 0)->first();
        if(isset($email)){
            $file = storage_path('app/public/sendEmail/' . $email->client_id . '/' . $email->id . '/originalFiles/' . $file_name);
            if(isset($file)) {
                return response()->download($file);
            } else {
                return back();
            }
        } else {
            return back();
        }
    }

    public function uploadDocument(Request $request)
    {
        $request->validate([
            'uploadFile' => 'required|mimes:docx,pdf',
        ]);
        try {
            $email = Client_Email::where('recipient', $request->email)->where('password', $request->password)->where('status', 'sent')->where('archived', 0)->first();
            $request->file("uploadFile")->storeAs('/sendEmail' . '/' . $email->client_id . '/'.$email->id.'/clientFiles', $request->file_name, ['disk' => 'local']);

            return redirect()->back()->with("success", "File Uploaded");

        } catch (\Throwable $e) {
            Log::channel('clients')->info($e);
            return back()->with('error', 'Something went wrong, if this persists please reach out');
        }
    }

    public function completeUploading($email, $password)
    {
        $email = Client_Email::where('recipient', $email)->where('password', $password)->where('status', 'sent')->where('archived', 0)->first();

        $original_files = Storage::files('sendEmail/' . $email->client_id . '/' . $email->id . '/originalFiles');
        $original_files_names = [];
        foreach($original_files as $original_file)
            $original_files_names[] = basename($original_file);

        $uploaded_files = Storage::files('sendEmail/' . $email->client_id . '/' . $email->id . '/clientFiles');
        $uploaded_files_names = [];
        foreach($uploaded_files as $uploaded_file)
            $uploaded_files_names[] = basename($uploaded_file);

        if($original_files_names != $uploaded_files_names)
            return back()->with('error', 'Please complete all documents before submitting');

        $email->status = "complete";
        $email->save();

        $mail = new RNNMailer(true);
        $mail->sendClientCompletedChanges($email, $uploaded_files_names);

        return redirect()->route("showClientLogin")->with('success', 'Thank you!');
    }
}