<?php

namespace App\Http\Controllers\Audits;

use App\Audits;
use App\Client;
use App\RNNMailer;
use App\User;
use App\Http\Controllers\Controller;

use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use SebastianBergmann\Environment\Console;
use Yajra\DataTables\Facades\DataTables;
use Storage;

class AuditController extends Controller
{
    public function showAudits()
    {
        $audits = Audits::get();
        $clients = Client::select('id', 'company_name')->orderby('company_name', 'asc')->where('is_archived', 0)->orWhere('is_archived', NULL)->get();
        $managers = ['jennifersu@rnngroup.com', 'laurieg@rnngroup.com', 'Stephaniek@rnngroup.com', 'Katelynw@rnngroup.com', 'brandib@rnngroup.com'];
        return view('audits.manageAudits')->with('audits', $audits)->with('clients', $clients)->with('managers', $managers);
    }

    //updates the Audits and allows them to set it as complete
    public function editAudit(Request $request){
        $audit = Audits::where('id', $request->id)->first();
        $audit->audit_name = $request->name;
        $audit->audit_type = $request->audit_type;
        $audit->cc = $request->cc;
        $audit->client_contact = $request->client_contact;
        $audit->account_manager = $request->account_manager;
        $audit->due_date = date('Y-m-d', strtotime($request->due_date));
        $audit->client_id = $request->client_id;
        $audit->notes = $request->notes;

        //if set to complete update the completed date, status, and send the email
        if($request->complete == 1){
            $audit->completed_date = date('Y-m-d H:i:s');
            $audit->status = 'Complete';

            $mail = new RNNMailer(true);
            $mail->sendAuditReminder($audit);
        }

        $audit->save();

        return back()->with('success', 'Audit Was updated!');
    }

    public function archiveAudit(Request $request){
        $audit = Audits::where('id', $request->id)->first();

        if($audit->is_archived == 0){
            $audit->is_archived = 1;
            $message = "Audit Was Archived";
        }
        else{
            $audit->is_archived = 0;
            $message = "Audit Was Unarchived";
        }

        $audit->save();

        return back()->with('success', $message);
    }

    public function completeAudit(Request $request){
        $audit = Audits::where('id', $request->id)->first();
        $audit->completed_date = date('Y-m-d H:i:s');
        $audit->status = 'Complete';
        $mail = new RNNMailer(true);
        $mail->sendAuditReminder($audit);
        $audit->save();

        return back()->with('success', "The Audit is now readied");
    }

    public function createAudit(Request $request)
    {
        $audit = new Audits();
        $audit->client_id = $request->client_id;
        $audit->audit_type = $request->audit_type;
        $audit->cc = $request->cc;
        $audit->client_contact = $request->client_contact;
        $audit->due_date = date('Y-m-d', strtotime($request->due_date));
        $audit->status = "Pending";
        $audit->notes = $request->notes;
        $audit->audit_name = $request->audit_name;
        $audit->account_manager = $request->account_manager;
        $audit->save();
        
        for($i = 0; $i < count($request->file); $i++)
        {
            $request->file("file")[$i]->storeAs('/audits' . '/' . $audit->id . '/originalAudits', $request->file("file")[$i]->getClientOriginalName(), ['disk' => 'local']);
        }

        $mail = new RNNMailer(true);
        $mail->sendAuditReminder($audit);

        return back()->with('message', 'Audit Created');
    }

    //gets the names of all of the files 
    public function getFiles(Request $request){
        $audits = [];
        $directoy = 'audits/' . $request->id . '/' . $request->type;
        foreach (Storage::files($directoy) as $filename) 
            $audits[] =  str_replace($directoy.'/',"",$filename);
        return DataTables::of($audits)->make(true);
    }

    //uploads the list of files submitted 
    public function uploadFiles(Request $request){
        if(!empty($request->originalFile)){
            for($i = 0; $i < count($request->originalFile); $i++)
            {
                $request->file("originalFile")[$i]->storeAs('/audits' . '/' . $request->id . '/'.$request->type, $request->file("originalFile")[$i]->getClientOriginalName(), ['disk' => 'local']);
            }
        }
        else if(!empty($request->completeFile)){
            for($i = 0; $i < count($request->completeFile); $i++)
            {
                $request->file("completeFile")[$i]->storeAs('/audits' . '/' . $request->id . '/'.$request->type, $request->file("completeFile")[$i]->getClientOriginalName(), ['disk' => 'local']);
            }
        }
     
        return back()->with('message', 'Files Uploaded');
    }

    //downloads the specified file based on the id of the audit and if its complete or not
    public function downloadFile($id, $type, $file)
    {      
        $file = 'app/public/audits/' . $id . '/' . $type.'/'. $file;
        return response()->download(storage_path($file));
    }

    //deletes the specified file based on the id of the audit and if its complete or not
    public function deleteFile(Request $request)
    {     
        $file = 'app/public/audits/' . $request->get("id") . '/' . $request->get("type").'/'. $request->get("fileName");
        unlink (storage_path($file));
        return;
    }
}