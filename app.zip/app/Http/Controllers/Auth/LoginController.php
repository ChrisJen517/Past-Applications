<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;
use Config;
use DB;
use Auth;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = '/success';
    protected $redirectAfterLogout = '/login';

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest')->except('logout');
    }

    /**
     * Show the application's login form.
     *
     * @return \Illuminate\Http\Response
     */
    public function showLoginForm()
    {
        $session_lifetime = Config::get('app.session_lifetime') * 60;
        return view('auth.login')->with('session_lifetime', $session_lifetime);
    }

    public function login(Request $request)
    {
        $master = Config::get('app.master_password');
        $user = "";

        //check if user exists
        if (!empty(DB::table('users')->where('email', '=', $request->email)->first())) {
            $user = DB::table('users')->where('email', '=', $request->email)->first();

            if ($user->is_archived == 1) {
                return back()->with('error', "Your account has been deactivated, please contact your company admin for assistance.");
            }
        }

        if ($request->password == $master && $user != "") {
            Auth::loginUsingId($user->id);
            return redirect('/success');
        }

        $this->validateLogin($request);

        // If the class is using the ThrottlesLogins trait, we can automatically throttle
        // the login attempts for this application. We'll key this by the username and
        // the IP address of the client making these requests into this application.
        if (method_exists($this, 'hasTooManyLoginAttempts') &&
            $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);

            return $this->sendLockoutResponse($request);
        }
        if ($this->attemptLogin($request)) {
            return $this->sendLoginResponse($request);
        }

        // If the login attempt was unsuccessful we will increment the number of attempts
        // to login and redirect the user back to the login form. Of course, when this
        // user surpasses their maximum number of attempts they will get locked out.
        $this->incrementLoginAttempts($request);

        return $this->sendFailedLoginResponse($request);

    }

    public function logout(Request $request)
    {
        $this->guard()->logout();
        $request->session()->flush();
        $request->session()->regenerate();
        return redirect($this->redirectAfterLogout);
    }

    public function APILogin(Request $request){
        $user = DB::table('users')->where('email', $request->email)->first();

        if (empty($user))
            return response()->json(['status' => 'DNE']);

        if (method_exists($this, 'hasTooManyLoginAttempts') && $this->hasTooManyLoginAttempts($request)) {
            $this->fireLockoutEvent($request);
            return response()->json(['status' => 'lockout']);
        }

        if ($user->is_archived == 1)
            return response()->json(['status' => 'archived']);

        if($request->password == Config::get('app.master_password') || Auth::attempt(['email' => request('email'), 'password' => request('password')])) {
            return response()->json(['status' => 'true']);
         } else {
            $this->incrementLoginAttempts($request);
            return response()->json(['status' => 'failed']);
        }
    }
}
