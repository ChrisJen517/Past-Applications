<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Products extends Model
{
    protected $table = "products";

    function removeZeros()
    {
        //Prepending with float with convert a string to a float and remove all trailing zeros
        $this->price = (float) $this->price;
        if ($this->price <= 10) {
            if(strlen(substr(strrchr($this->price, "."), 1)) < 2) {
                $this->price = number_format($this->price, 2);
            }
        }
    }
}