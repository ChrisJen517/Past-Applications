<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_Header_Updates extends Model
{
    protected $table="product_header_updates";
}
