<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contract_History extends Model
{
    protected $table = "contract_history";
}
