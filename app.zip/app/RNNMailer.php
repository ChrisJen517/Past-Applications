<?php

namespace App;

use App\EasyPeasyICS;
use App\Client;
use App\User;
use Illuminate\Database\Eloquent\Model;
use PHPMailer\PHPMailer\PHPMailer;
use Illuminate\Support\Str;
use Carbon\Carbon;
use Illuminate\Support\Facades\Config;
use Storage;
use Auth;
use Log;
use File;

class RNNMailer extends PHPMailer
{

    /**
     * RNNMailer constructor.
     *
     * @param bool|null $exceptions
     */
    public function __construct($exceptions = null)
    {
        parent::__construct($exceptions);
        $this->setFrom('response@rnngroup.com', 'Contract Portal - RNN Group');
        $this->isSMTP();
        $this->Host = Config::get('app.mail_host');
        $this->SMTPAuth = true;
        $this->Username = Config::get('app.mail_username');
        $this->Password = Config::get('app.mail_password');
        $this->SMTPSecure = 'tls';
        $this->Port = Config::get('app.mail_port');
        $this->addReplyTo('christianj@rnngroup.com', 'Report Server');
        $this->SMTPOptions = array(
            'ssl' => array(
                'verify_peer' => false,
                'verify_peer_name' => false,
                'allow_self_signed' => true
            )
        );
        $this->isHTML(true);
    }

    public function send()
    {
        return parent::send();
    }

    public function sendInvite($company_name, $start, $summary, $description, $recipients, $location = null)
    {
        $ics = new EasyPeasyICS("Calendar");
        $ics->addEvent($start, $summary, $description, $recipients, $location);
        $startFormatted = Carbon::parse($start, 'UTC')->setTimezone('America/New_York')->format('M d Y h:i A') . " EST";
        $renderedIcs = $ics->render(false);
        $this->isHTML(true);
        $this->CharSet = 'UTF-8';
        $companyDecoded = $company_name;
        // ? TODO cut the name of the company name down?
        $this->Subject = "[Contract Portal] Invitation to Event With ${companyDecoded}";
        $this->Body = "<p>Thank you for creating an event through the Contract Portal!<br>
        The event has been set to take one hour, please change this if it will take a different amount of time.<br>
        Attached is the invitation to add this event to your calendar.<br>
        If there is no prompt to add it to your calendar, please double click the attachment.<br>
        <br>
        Event Details:<br>
        SUMMARY: ${summary}<br>
        START DATE: ${startFormatted}<br>
        AGENDA: ${description}<br>".(empty($location) ? '</p>' : "LOCATION: ${location}</p>");
        $this->AltBody = "Thank you for creating an event through the Contract Portal. Attached is the invitation to add this event to your calendar."; //Necessary for some reason in order to send an ics file to outlook
        $this->AddStringAttachment($renderedIcs, "event.ics", "base64", "text/calendar; charset=utf-8; method=REQUEST");
        $this->Ical = $renderedIcs;
        return parent::send();
    }

    /**
     * Add an array of addresses
     *
     * @param array $addresses
     */
    public function addAddresses($addresses)
    {
        if (env('DEVELOPMENT') == 1) {
            // $this->addAddress('michaelC@rnngroup.com');
            $this->addAddress('christianj@rnngroup.com');
        } else {
            if (is_array($addresses)) {
                foreach ($addresses as $address) {
                    $this->addAddress($address);
                }
            }
        }
    }

    /**
     * Send email to managers or jim depending on if approval is necessary.
     *
     * @param object $user pointer to currently authenticated user
     * @param boolean $needs_manager_approval
     * @param boolean $needs_jim_approval
     * @param object $contract contract pointer
     * @param object $history contract history pointer
     * @param string $mergedPdf path of final pdf file to be attached to email
     * @param string $approval message to be appended to email containing what pricing needs to be approved
     *
     * @return boolean true - sent, false - did not send
     */
    public function sendContractApproval($user, $needs_manager_approval, $needs_jim_approval, $contract, $history, $mergedPdf, $approval)
    {
        if ($needs_manager_approval == 1 || $needs_jim_approval == 1) {
            $agentName = $user->name_first . ' ' . $user->name_last;

            if ($needs_jim_approval == 1) {
                $contract->needJimApproval($history);
                $this->addAddresses(['christianj@rnngroup.com', 'jimv@rnngroup.com']);
            } else if ($needs_manager_approval == 1 and $needs_jim_approval == 0) {
                $contract->needManagerApproval($history);
                $this->addAddresses(['christianj@rnngroup.com', 'stevet@rnngroup.com', 'dennisg@rnngroup.com']);
            }

            // Attachments
            $this->addAttachment(storage_path('app/public/' . $mergedPdf));
            $link = 'http://contract.rnngroup.com/approve/$2y$10$72OFQ.ByneknikAMSeaYxu/PJW2LTdObBQsDWBagvo1sekQp.tWeO/' . $contract->id;
            $this->CharSet = 'UTF-8';

            $this->Subject = '[Contract Portal] ' . $agentName . (Str::endsWith($agentName, 's') ? '\' ' : '\'s ') . $contract->contract_type . ' Contract with id: ' . $contract->id . ' is awaiting your approval ';
            $this->Body    = '<p>' . $agentName . ' has a contract with ' . $contract->company_name . ' that is awaiting approval.</p><p>' . $approval . '</p><p>Please click the link to approve the contract.</p><a href="' . $link . '" class="far fa-eye-slash fa-5x mb-2"> Click to Approve the Contract.</a>';
            $this->send();

            $approval = str_replace('These items are waiting approval: <br> ', '', $approval);
            $approval = str_replace('<br>', ' ', $approval);
            $approval_table = new ApprovalMessage;
            $approval_table->createApprovalMessage($contract->id, $approval);

            return true;
        }
        return false;
    }

    public function sendAuditReminder($audit)
    {
        $this->addAddresses(['christianj@rnngroup.com', 'edwinf@rnngroup.com', 'jennifersu@rnngroup.com', $audit->account_manager]);

        $file_message = "";
        $file_size = 0;
        $add_files = true;



        // Attachments
        if($audit->completed_date == NULL){
            foreach( File::allFiles(storage_path('app/public/audits/'.$audit->id.'/originalAudits')) as $file)  {
                $file_size += $file->getSize();
                if($file->getSize() >= 10485760 || $file_size >= 20971520){
                    $file_message = "<br>The file(s) for this audit were too large to include in this email, please log into the Contract Portal to download them.";
                    $add_files = false;
                    break;
                }
            }
            if($add_files)
                foreach (Storage::files('audits/' . $audit->id . '/originalAudits') as $filename) {
                    $this->addAttachment(storage_path('app/public/' . $filename));
                }
        } else {
            foreach( File::allFiles(storage_path('app/public/audits/'.$audit->id.'/completeAudits')) as $file)  {
                $file_size += $file->getSize();
                if($file->getSize() >= 10485760 || $file_size >= 20971520){
                    $file_message = "<br>The file(s) for this audit were too large to include in this email, please log into the Contract Portal to download them.";
                    $add_files = false;
                    break;
                }
            }
            if($add_files)
                foreach (Storage::files('audits/' . $audit->id . '/completeAudits') as $filename) {
                    $this->addAttachment(storage_path('app/public/' . $filename));
                }
        }
        if(!empty($audit->cc)){
            $ccs = explode(',',str_replace(' ', '', $audit->cc));
            foreach($ccs as $cc){
                if (filter_var($cc, FILTER_VALIDATE_EMAIL))
                    $this->AddCC($cc);
            }
        }
            
        $client = Client::find($audit->client_id);
        $link = 'http://contract.rnngroup.com/';
        $this->CharSet = 'UTF-8';

        switch($audit->status)
        {
            case "Past Due":
                $this->Subject = '[Contract Portal] Audit Past Due';
                $this->Body    = 'The audit, '.$audit->audit_name.' with the client '.$client->company_name.', was uploaded '.$audit->created_at.' and was due '.$audit->due_date.' is past due.'.$file_message;
            break;
            case "Due Soon";
                $this->Subject = '[Contract Portal] Audit Due Soon';
                $this->Body    = 'The audit, '.$audit->audit_name.' with the client '.$client->company_name.', was uploaded '.$audit->created_at.' and is due '.$audit->due_date.'.'.$file_message;
            break;
            case "Pending":
                $this->Subject = '[Contract Portal] Audit Reminder';
                $this->Body    = 'The audit, '.$audit->audit_name.' with the client '.$client->company_name.', is available and is due '.$audit->due_date.'.'.$file_message;
            break;
            case "Complete":
                $this->Subject = '[Contract Portal] Audit Complete';
                $this->Body    = 'The audit, '.$audit->audit_name.' with the client '.$client->company_name.', has been completed.'.$file_message;
            break;
        }
        $this->send();
    }

    public function auditAutoReminder()
    {
        $this->addAddresses(['christianj@rnngroup.com', 'edwinf@rnngroup.com', 'jennifersu@rnngroup.com']);
            
        $link = 'http://contract.rnngroup.com/';
        $this->CharSet = 'UTF-8';

        $this->Subject = '[Contract Portal] Audit Pending';
        $this->Body    = 'Please log into the Contract Portal to complete the pending audit(s).'.$link;
        $this->send();
    }

    //sends the report then deletes the excel sheets after
    public function sendWeeklyReports($date){
        $this->addAddresses(['christianj@rnngroup.com', 'jennifersu@rnngroup.com', 'stevet@rnngroup.com', 'dennisg@rnngroup.com', 'kaileag@rnngroup.com']);
        $this->CharSet = 'UTF-8';
        $this->Subject = 'Weekly Contract Report for '.$date;
        $this->addAttachment(public_path('Exports/' . 'Pending_Contract_'.$date.'.xlsx'));
        $this->addAttachment(public_path('Exports/' . 'Complete_Contract_'.$date.'.xlsx'));
        $this->addAttachment(public_path('Exports/' . 'Pending_Contract_2020-2021_'.$date.'.xlsx'));
        $this->addAttachment(public_path('Exports/' . 'Complete_Contract_2020-2021_'.$date.'.xlsx'));
        $this->Body    = 'Attatched are the completed pending reports for the week';
        $this->send();

        unlink(public_path('Exports/' . 'Pending_Contract_'.$date.'.xlsx'));
        unlink(public_path('Exports/' . 'Complete_Contract_'.$date.'.xlsx'));
    }


    // Send a purchase request for approval
    public function sendPurchaseRequest($purchase_request){
        switch($purchase_request->status){
            case 'awaiting_approval':
                $approver = $purchase_request->manager_email;
                $type = "manager";
                break;
            case 'awaiting_final_approval':
                $approver = "scottm@rnngroup.com";
                $type = "final";
                break;
            default:
                return "Purchase request has already been denied";
        }

        $submitter = User::find($purchase_request->submitter);
        if (env('DEVELOPMENT') == 1) 
            $link = 'http://localhost:8000/reviewPurchaseRequest/$2y$10$72OFQ.PJW2LTdObBQsDWBag/MSeaYxuvo1ByneknikAsekQp.tWeO/' . $purchase_request->id ."/". $type;
        else
            $link = 'http://contract.rnngroup.com/reviewPurchaseRequest/$2y$10$72OFQ.PJW2LTdObBQsDWBag/MSeaYxuvo1ByneknikAsekQp.tWeO/' . $purchase_request->id ."/". $type;

        $this->addAddresses(['christianj@rnngroup.com', $approver]);
        $this->CharSet = 'UTF-8';
        $this->Subject = 'Purchase Request Approval Request';
        $this->Body    =  'There is a purchase request awaiting your approval from '.$submitter->name_first.' '.$submitter->name_last.' for $'.$purchase_request->amount.' '.($purchase_request->frequency == "Other" ? $purchase_request->other : $purchase_request->frequency).':<br>'.$purchase_request->website.'<br>'.$purchase_request->description.'<br>'.$purchase_request->justification.'<br> Log into the contract portal to view more information.<br><br> <a href="'.$link.'" class="far fa-eye-slash fa-5x mb-2">REVIEW</a>';
        $this->send();
    }

    public function sendApprovedPurchaseRequest($purchase_request){
        $submitter = User::find($purchase_request->submitter);

        $this->addAddresses(['christianj@rnngroup.com', 'maggiem@rnngroup.com', 'danielg@rnngroup.com', $submitter->email]);
        $this->CharSet = 'UTF-8';
        $this->Subject = 'Purchase Request Approved';
        $this->Body    =  'The purchase request from '.$submitter->name_first.' '.$submitter->name_last.' has been approved for $'.$purchase_request->amount.' '.($purchase_request->frequency == "Other" ? $purchase_request->other : $purchase_request->frequency).':<br>'.$purchase_request->website.'<br>'.$purchase_request->description.'<br>'.$purchase_request->justification;
        $this->send();
    }

    public function sendDeniedPurchaseRequest($purchase_request, $comment = null){
        $submitter = User::find($purchase_request->submitter);

        $this->CharSet = 'UTF-8';
        if($purchase_request->status == "denied")
        {
            $this->addAddresses(['christianj@rnngroup.com', $submitter->email]);
            $this->Subject = 'Purchase Request Denied';
            $this->Body    =  'The purchase request from '.$submitter->name_first.' '.$submitter->name_last.' has been denied for $'.$purchase_request->amount.' '.($purchase_request->frequency == "Other" ? $purchase_request->other : $purchase_request->frequency).':<br>'.$purchase_request->website.'<br>'.$purchase_request->description.'<br>'.$purchase_request->justification.($comment ? '<br><br>Manager Comment: '.$comment : '');
        } else {
            $this->addAddresses(['christianj@rnngroup.com', $submitter->email]);
            $this->Subject = 'Changes Requested For Purchase Request';
            $this->Body    =  'Changes have been requested for the purchase request from '.$submitter->name_first.' '.$submitter->name_last.' for $'.$purchase_request->amount.' '.($purchase_request->frequency == "Other" ? $purchase_request->other : $purchase_request->frequency).':<br>'.$purchase_request->website.'<br>'.$purchase_request->description.'<br>'.$purchase_request->justification.'<br><br>Manager Comments: '.$comment.'<br><br>Please log into the Contract Portal and update the purchase request.';
        }
        $this->send();
    }

    
    public function sendClientEmail($request, $email){
        $sender = Auth::user();

        $this->addAddresses(['christianj@rnngroup.com', $request->client_email, $sender->email]);
        $this->CharSet = 'UTF-8';
        $this->Subject = $request->subject;

        if(isset($request->file)){
            $this->Body = nl2br(e($request->body)).'<br><br> To view attatched files go to the link: <a href="https://contract.rnngroup.com/Client">Login</a><br> Your password for these file(s) is: '.$email->password;
        } else {
            $this->Body = nl2br(e($request->body));
        }
        $this->send();
        
        Log::channel('mail')->info('client email sent');
    }


    public function sendClientCompletedChanges($email, $files){
        $sender = User::find($email->sender_id);
        $client = Client::find($email->client_id);
        
        $this->addAddresses(['christianj@rnngroup.com', $sender->email]);
        $this->CharSet = 'UTF-8';
        $this->Subject = "Client has uploaded changes";

        $this->Body = "The client ". $client->company_name." has uploaded file changes, you can download them from the manage clients page of the Contract Portal.<br><br>The files are: <br>". implode("<br>", $files);
        $this->send();
        
        Log::channel('mail')->info('client email sent');
    }
}