<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class History extends Model
{
    protected $table="contract_history";

    /**
     * Constructor for History model -- break eloquent model
     * (Can longer do History::find($id))
     *
     * @param $contract_id
     *        $file_name
     *        $description
     */
    public function __construct($contract_id, $file_name, $description)
    {
        $this->contract_reference_id = $contract_id;
        $this->file_name = $file_name;
        $this->description = $description;
        $this->save();
    }
}
