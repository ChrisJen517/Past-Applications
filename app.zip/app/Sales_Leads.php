<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sales_Leads extends Model
{
    protected $table = "sales_leads";

    public function user(){
        return $this->belongsTo(User::class);
    }

    public function activity() {
        return $this->hasMany(Lead_Activity::class, 'lead_reference_id');
    }

    public function getActivityCount(){
        return $this->activity()->count();
    }

    public function contacts() {
        return $this->hasMany(Lead_Contacts::class, 'lead_reference_id');
    }

    public function getNotesCount() {
        return $this->contacts()->count();
    }
}
