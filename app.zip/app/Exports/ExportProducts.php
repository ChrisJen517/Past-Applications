<?php

namespace App\Exports;

use Illuminate\Http\Request;
use Illuminate\Support\Collection;

use App\Product_Headers;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class ExportProducts implements FromArray, WithHeadings, ShouldAutoSize, WithEvents
{
    public function __construct(Request $request)
    {
        $this->request = $request;
    }

    public function headings(): array
    {
        return [
            'Product Header',
            'Product Name',
            'Product Description',
            'Product Price',
            'Needs Manager Approval',
            'Needs Executive Approval',
            'VAST Code',
            'BATCH Code',
            'SLA',
        ];
    }

    public function array() : array
    {
        $array = [];

        $count = count($this->request->name);
        for ($i = 0; $i < $count; $i++) {
            $prod_header = Product_Headers::find($this->request->prod_header_id[$i]);

            if ($this->request->prod_header_id[$i] == 11) {
                $price = floor($this->request->price[$i]);
                $cost_string = $price;
            } else if ($this->request->name[$i] == "AWG 7 Attempt") {
                $cost_string = $this->request->price_name[$i];
            } else if ($this->request->use_quote[$i] == 1) {
                $cost_string = $this->request->price[$i];
            } else {
                $price = $this->request->price[$i];
                $price = (float) $price; // Remove trailing zeros
                if ($price <= 10 || fmod($price, 1) !== 0.0) { // If the price is less than or equal to $10 or if it is not a whole number
                    if(strlen(substr(strrchr($price, "."), 1)) < 2) { // If there are less than 2 decimal points remaining
                        $price = number_format($price, 2); // round to 2 decimal points (add trailing zeros)
                    }
                }
                $cost_string = '$' . $price . ' ' . $this->request->price_name[$i];
            }

            array_push($array, [
                'Product Header' => $prod_header->name,
                'Product Name' => $this->request->name[$i],
                'Product Description' => $this->request->description[$i],
                'Product Price' => $cost_string,
                'Needs Manager Approval' => $this->request->managerPrice[$i],
                'Needs Executive Approval' => $this->request->jimPrice[$i],
                'VAST Code' => $this->request->vast_code[$i],
                'BATCH Code' => $this->request->batch_code[$i],
                'SLA' => $this->request->sla[$i]
            ]);
        }
        return $array;
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'top' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $cellRange = 'A1:I1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:I'.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
            },
        ];
    }
}