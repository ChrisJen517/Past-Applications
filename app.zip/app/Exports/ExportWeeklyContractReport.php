<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Exports\Sheets\AgentCountSheet;
use App\Exports\Sheets\CompletedByMonthSheet;
use App\Exports\Sheets\ContractsSheet;

class ExportWeeklyContractReport implements WithMultipleSheets
{
    use Exportable;

    protected $leads;
    protected $status;
    
    public function __construct($leads, $status)
    {
        $this->leads = $leads;
        $this->status = $status;
    }

    /**
     * @return array
     * Calls the three pages for the report, first the two counts then the list of contracts
     */
    public function sheets(): array
    {
        $sheets = [];

        $sheets[] = new AgentCountSheet($this->status, 'Month');
        $sheets[] = new AgentCountSheet($this->status, 'Year');
        if($this->status == 'Completed')
            $sheets[] = new CompletedByMonthSheet(); 
        $sheets[] = new ContractsSheet($this->leads);

        return $sheets;
    }
}