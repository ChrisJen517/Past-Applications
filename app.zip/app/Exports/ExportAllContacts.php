<?php

namespace App\Exports;

use App\Sales_Leads;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class ExportAllContacts implements FromArray, ShouldAutoSize, WithEvents, WithHeadings
{

    public function __construct($unworked) {
        $temp = Sales_Leads::select('id', 'company_name')
        ->with(['contacts' => function($query) {
            $query->select('lead_reference_id', 'lead_title', 'first_name', 'last_name', 'phone', 'phone_ext', 'email');
        }]);

        if ($unworked)
            $leads = $temp->where('closed', '!=', '1')->orWhereNull('closed')->get();
        else
            $leads = $temp->where('closed', '=', '1')->get();

        $leads_and_contacts = [];
        foreach($leads as $lead) {
            foreach($lead->contacts as $contact) {
                array_push($leads_and_contacts, ['company_name' => $lead->company_name, 'lead_title' => $contact->lead_title, 'first_name' => $contact->first_name, 'last_name' => $contact->last_name, 'phone' => $contact->phone, 'phone_ext' => $contact->phone_ext, 'email' => $contact->email]);
            }
        }
        $this->leads = $leads_and_contacts;
    }

    public function headings(): array
    {
        return [
            'Company Name',
            'Contact Title',
            'First Name',
            'Last Name',
            'Phone',
            'Phone Ext',
            'Email'
        ];

    }

    public function array(): array
    {
        return $this->leads;
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'top' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $cellRange = 'A1:G1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:G'.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
            },
        ];
    }
}