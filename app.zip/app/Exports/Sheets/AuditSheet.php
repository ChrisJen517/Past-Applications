<?php

namespace App\Exports\Sheets;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class AuditSheet implements FromCollection, WithTitle, WithHeadings, WithEvents, ShouldAutoSize
{

    private $type;
    private $audits;

    /**
     * Constructor for the excel export to store the collection
     */
    public function __construct($audits, $type)
    {
        $this->audits = $audits;
        $this->type = $type; 
    }

    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return $this->audits;
    }

    /**
     * Function to convert the status string in the database to a human-readable status
     */
    public function getStatusString($status) {
        return ucwords(str_replace("_", " ", $status));
    }

    public function headings() : array
    {
        return [
            'Audit Name',
            'Audit Type',
            'Notes',
            'Account Manager',
            'Due Date',
            'Completed Date'
        ];
    }

    /**
     * @return string
     */
    public function title(): string
    {
        return $this->type;
    }

    public function registerEvents() : array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'top' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $cellRange = 'A1:F1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:F'.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
            },
        ];
    }
}