<?php
namespace App\Exports\Sheets;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCharts;
use PhpOffice\PhpSpreadsheet\Chart\PlotArea;
use PhpOffice\PhpSpreadsheet\Chart\DataSeries;
use PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues;
use PhpOffice\PhpSpreadsheet\Chart\Chart;
use PhpOffice\PhpSpreadsheet\Chart\Title;
use PhpOffice\PhpSpreadsheet\Chart\Legend;
use Maatwebsite\Excel\Events\AfterSheet;
use App\Contract;

class AgentCountSheet implements FromCollection, WithTitle, WithEvents, WithHeadings, ShouldAutoSize, WithCharts
{
    private $status;
    private $timeFrame;
    private $data;
    private $counts;
    private $sheetName;
    
    public function __construct($status, $timeframe)
    {
        $this->status = $status;
        $this->timeFrame = $timeframe;
        $this->data = $this->getData('CONCAT(users.name_first, " ", users.name_last) AS agent_name, ');
        $this->data->push( $this->getData('"Grand Total" AS agent_name, '));

        $this->counts = Contract::SelectRaw('CONCAT(users.name_first, " ", users.name_last) AS agent_name, users.role')
        ->whereRaw("YEAR(contracts.updated_at) = YEAR(CURDATE())")
        ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
        ->when($this->timeFrame == 'Month', function ($query) { 
            return $query->whereRaw("MONTH(contracts.updated_at) = MONTH(CURDATE())");
        })
        ->when($this->status == 'Completed', function ($query) { 
            return $query->where("status", "complete");
        })
        ->when($this->status != 'Completed', function ($query) { 
            return $query->wherein("status", ["awaiting_manager_approval", "awaiting_jim_approval", "awaiting_all_signature", "awaiting_client_changes", "awaiting_final_upload", "awaiting_client_signature"]);
        })
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->groupBy('agent_reference')->orderBy('users.role')
        ->get();

    }

    public function getData($agents){
        $data = Contract::SelectRaw($agents.' 
        count(IF(contract_type = "Amendment" ,1,null)) AS amendment, 
        count(IF(contract_type = "REDLINE" ,1,null)) AS REDLINE, 
        count(IF(contract_type = "FCRA Amendment" ,1,null)) AS FCRA, 
        count(IF(contract_type IN ("FCRA MSA", "MSA") ,1,null)) AS MSA, 
        count(IF(contract_type = "MSA without FCRA" ,1,null)) AS noFCRA,
        count(IF(contract_type = "NDA" ,1,null)) AS NDA, 
        count(IF(contract_type = "You-Negotiate" ,1,null)) AS negotiate,
        count(IF(contract_type = "YN Amendment" ,1,null)) AS negotiate_amendment,
        count(IF(contract_type = "Reseller Agreement" ,1,null)) AS reseller,
        count(IF(contract_type = "FCRA Certification" ,1,null)) AS fcra_cert,
        count(IF(contract_type = "ICA" ,1,null)) AS ica,
        count(IF(contract_type = "Name Change Amendment" ,1,null)) AS name_change,
        count(IF(contract_type in ("You-Negotiate", "Amendment", "REDLINE", "FCRA Amendment", "FCRA MSA", "MSA", "MSA without FCRA", "NDA", "FCRA Certification", "ICA", "Reseller Agreement", "Name Change Amendment", "YN Amendment") ,1,null)) AS sum')
        ->whereRaw("YEAR(contracts.updated_at) = YEAR(CURDATE())")
        ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
        ->when($this->timeFrame == 'Month', function ($query) { 
            return $query->whereRaw("MONTH(contracts.updated_at) = MONTH(CURDATE())");
        })
        ->when($this->status == 'Completed', function ($query) { 
            return $query->where("status", "complete");
        })
        ->when($this->status != 'Completed', function ($query) { 
            return $query->where("status", "!=", "complete");
        })
        ->when($agents == 'CONCAT(users.name_first, " ", users.name_last) AS agent_name, ', function ($query) {
            $query->join('users', 'contracts.agent_reference', '=', 'users.id')
            ->groupBy('agent_reference')->orderByRaw("FIELD(email, 'STEVET@RNNGROUP.COM', 'JENNIFERSU@RNNGROUP.COM', 'TIMS@RNNGROUP.COM', 'JACQUELINEW@RNNGROUP.COM', 'MARYAA@RNNGROUP.COM', 'PATRICK@RNNGROUP.COM', 'STEPHANIEK@RNNGROUP.COM', 'KATELYNW@RNNGROUP.COM', 'BRANDIB@RNNGROUP.COM', 'LAURIEG@RNNGROUP.COM') DESC");
        })
        ->get();

        if($agents == 'CONCAT(users.name_first, " ", users.name_last) AS agent_name, ')
            return $data;
        else
            return $data->first();
    }

    //Sets the headers for the chart
    public function headings(): array
    {
        return [
            'Agent Name',
            'Amendment',
            'REDLINE',
            'FCRA Amendment',
            'FCRA MSA',
            'MSA Without FCRA',
            'NDA',
            'You-Negotiate',
            'YN Amendment',
            'Reseller Agreement',
            'FCRA Certification',
            'ICA',
            'Name Change Amendment',
            'Grand Total'
        ];

    }

    /**
    * @return \Illuminate\Support\Collection
    * Gathers the data for the report based on if its completed/pending and for the year/month
    */
    public function collection()
    {
        return $this->data;
    }

    /**
     * @return string
     */
    public function title(): string
    {
        switch($this->timeFrame){
            case "Year":
                $this->sheetName = date("Y")."_Total_".$this->status."_Contracts";
            break;
            case "Month":
                $this->sheetName = "Total_".$this->status."_For_".date("F");
        }
        return $this->sheetName;
    }

    //Adds in the styling of the chart to the header and adds in a border
    public function registerEvents() : array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'top' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];
                $styleArray3 = [
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'rgb' => 'FFFF00',
                        ]
                    ],
                ];
                $styleArray4 = [
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'rgb' => '80FF00',
                        ]
                    ],
                ];
                $agent_count = $this->counts->whereIn("agent_name", ['Stephanie Kavalec', 'Katelyn Walter', 'Brandi Briers', 'Laurie Garcia'])->count() + 1;
                $total_count = $this->counts->whereIn("agent_name", ['Tim Seaton', 'Jacqueline Waller', 'Marya Arndt', 'Patrick Welch'])->count() + $agent_count;
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $cellRange = 'A1:N1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:N'.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
                if($agent_count > 1)
                {
                    $agentRange = 'A2:A'.$agent_count;
                    $event->sheet->getDelegate()->getStyle($agentRange)->applyFromArray($styleArray3);
                } 

                if($total_count > 1)
                {
                    $managerRange = 'A'.($agent_count + 1).':A'.$total_count;
                    $event->sheet->getDelegate()->getStyle($managerRange)->applyFromArray($styleArray4);
                }
            },
        ];
    }


    /**
     * @return Chart|Chart[]
     */
    public function charts()
    {
        $count = $this->data->count();
        $line = $count;

        if($count == 0)
            $line = 2;

        $labels     = [
            new DataSeriesValues('String', $this->sheetName.'!$B$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$C$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$D$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$E$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$F$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$G$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$H$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$I$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$J$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$K$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$L$1', null, 1),
            new DataSeriesValues('String', $this->sheetName.'!$M$1', null, 1),
        ];
        $categories = [
            new DataSeriesValues('String', $this->sheetName.'!$A2:$A$'.$line, null, $count),
        ];
        $values     = [
            new DataSeriesValues('Number', $this->sheetName.'!$B$2:$B$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$C$2:$C$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$D$2:$D$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$E$2:$E$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$F$2:$F$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$G$2:$G$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$H$2:$H$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$I$2:$I$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$J$2:$J$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$K$2:$K$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$L$2:$L$'.$line, null, $count),
            new DataSeriesValues('Number', $this->sheetName.'!$M$2:$M$'.$line, null, $count),
        ];

        $series = new DataSeries(
            DataSeries::TYPE_BARCHART,
            DataSeries::GROUPING_CLUSTERED,
            range(0, count($values) - 1),
            $labels,
            $categories,
            $values
        );

        $chart1 = new Chart(
            'chart',
            new Title($this->timeFrame.' to Date Contracts'),
            new Legend(Legend::POSITION_RIGHT, null, false),
            new PlotArea(null, [$series]),
        );

        $chart1->setTopLeftPosition('P1');
        $chart1->setBottomRightPosition('AA20');

        return $chart1;
    }
}