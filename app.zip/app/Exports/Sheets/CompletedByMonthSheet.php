<?php
namespace App\Exports\Sheets;

use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithTitle;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithCharts;
use PhpOffice\PhpSpreadsheet\Chart\PlotArea;
use PhpOffice\PhpSpreadsheet\Chart\DataSeries;
use PhpOffice\PhpSpreadsheet\Chart\DataSeriesValues;
use PhpOffice\PhpSpreadsheet\Chart\Chart;
use PhpOffice\PhpSpreadsheet\Chart\Title;
use PhpOffice\PhpSpreadsheet\Chart\Legend;
use Maatwebsite\Excel\Events\AfterSheet;
use App\Contract;
use DB;

class CompletedByMonthSheet implements FromCollection, WithTitle, WithEvents, WithHeadings, ShouldAutoSize
{
    public function __construct()
    {
        $this->currentMonth = date('m'); 
        $this->columns = ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];
        
        $selectStatement = ' ';
        for($i = 1; $i <= $this->currentMonth; $i++)
            $selectStatement = $selectStatement.'count(IF(contract_type = "Amendment" AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS amendment'.$i.', 
            count(IF(contract_type = "REDLINE"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS REDLINE'.$i.', 
            count(IF(contract_type = "FCRA Amendment"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS FCRA'.$i.', 
            count(IF(contract_type IN ("MSA", "FCRA MSA")  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS MSA'.$i.', 
            count(IF(contract_type = "MSA without FCRA"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS noFCRA'.$i.',
            count(IF(contract_type = "NDA"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS NDA'.$i.', 
            count(IF(contract_type = "You-Negotiate"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS negotiate'.$i.',
            count(IF(contract_type = "YN Amendment"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS negotiate_amendment'.$i.',
            count(IF(contract_type = "Reseller Agreement"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS reseller'.$i.',
            count(IF(contract_type = "FCRA Certification"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS fcra_cert'.$i.', 
            count(IF(contract_type = "ICA"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS ica'.$i.',
            count(IF(contract_type = "Name Change Amendment"  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS name_change'.$i.',
            count(IF(contract_type in ("You-Negotiate", "Amendment", "REDLINE", "FCRA Amendment", "MSA", "FCRA MSA", "MSA without FCRA", "NDA", "FCRA Certification", "ICA", "Reseller Agreement", "Name Change Amendment", "YN Amendment")  AND MONTH(contracts.updated_at) = '.$i.',1,null)) AS sum'.$i.', ';
            
        $selectStatement = $selectStatement.'count(IF(contract_type in ("You-Negotiate", "FCRA Amendment", "Amendment", "REDLINE", "MSA", "FCRA MSA", "MSA without FCRA", "NDA") ,1,null)) AS grandTotal';

        $this->data = Contract::SelectRaw('CONCAT(users.name_first, " ", users.name_last) AS agent_name, '.$selectStatement)
        ->whereRaw("YEAR(contracts.updated_at) = YEAR(CURDATE())")
        ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
        ->where("status", "complete")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->groupBy('agent_reference')->orderByRaw("FIELD(email, 'STEVET@RNNGROUP.COM', 'JENNIFERSU@RNNGROUP.COM', 'TIMS@RNNGROUP.COM', 'JACQUELINEW@RNNGROUP.COM', 'MARYAA@RNNGROUP.COM', 'PATRICK@RNNGROUP.COM', 'STEPHANIEK@RNNGROUP.COM', 'KATELYNW@RNNGROUP.COM', 'BRANDIB@RNNGROUP.COM', 'LAURIEG@RNNGROUP.COM') DESC")
        ->get();

        $this->data->push(
            Contract::SelectRaw('"Grand Total" AS agent_name, '.$selectStatement)
            ->whereRaw("YEAR(contracts.updated_at) = YEAR(CURDATE())")
            ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
            ->where("status", "complete")
            ->first()
        );

        $this->counts = Contract::SelectRaw('CONCAT(users.name_first, " ", users.name_last) AS agent_name, users.role')
        ->whereRaw("YEAR(contracts.updated_at) = YEAR(CURDATE())")
        ->whereRaw("(contracts.is_archived != '1' OR contracts.is_archived IS NULL)")
        ->where("status", "complete")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->groupBy('agent_reference')->orderBy('users.role')
        ->get();
        
    }

    //Sets the headers for the chart
    public function headings(): array
    {
        $titles = [];
        $titles[] = 'Agent Name';
        $contractNames = [];
        $contractNames[] = ' ';

        for($i = 1; $i <= $this->currentMonth; $i++)
        {
            $titles[] = date('F', strtotime($i.'/01/0000')); //the rest of the string is just filler
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";
            $titles[] = "";

            $contractNames[] = 'Amendment';
            $contractNames[] = 'REDLINE';
            $contractNames[] = 'FCRA Amendment';
            $contractNames[] = 'MSA';
            $contractNames[] = 'MSA Without FCRA';
            $contractNames[] = 'NDA';
            $contractNames[] = 'You-Negotiate';
            $contractNames[] = "YN Amendment";
            $contractNames[] = "Reseller Agreement";
            $contractNames[] = "FCRA Certification";
            $contractNames[] = "ICA";
            $contractNames[] = "Name Change Amendment";
            $contractNames[] = 'Grand Total';
        }
        $titles[] = 'Grand Total';
        
        return [$titles, $contractNames];
    }

    /**
    * @return \Illuminate\Support\Collection
    * Gathers the data for the report based on if its completed/pending and for the year/month
    */
    public function collection()
    {
        return $this->data;
    }

    /**
     * @return string
     */
    public function title(): string
    {
        $this->sheetName = "Completed_By_Month";
        return $this->sheetName;
    }

    //Adds in the styling of the chart to the header and adds in a border
    public function registerEvents() : array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];

                $styleArray3 = [
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];

                $styleArray4 = [
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'rgb' => 'FFFF00',
                        ]
                    ],
                ];
                $styleArray5 = [
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'rgb' => '80FF00',
                        ]
                    ],
                ];
                
                $agent_count = $this->counts->whereIn("agent_name", ['Stephanie Kavalec', 'Katelyn Walter', 'Brandi Briers', 'Laurie Garcia'])->count() + 2;
                $total_count = $this->counts->whereIn("agent_name", ['Tim Seaton', 'Jacqueline Waller', 'Marya Arndt', 'Patrick Welch'])->count() + $agent_count;
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $highestColumn = $event->sheet->getDelegate()->getHighestColumn();
                $cellRange = 'A1:'.$highestColumn.'1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:'.$highestColumn.''.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $cellRange = 'A3:'.$highestColumn.''.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
                $event->sheet->mergeCells("A1:A2");
                $event->sheet->mergeCells($highestColumn.'1:'.$highestColumn.'2');

                for($i = 1; $i <= $this->currentMonth; $i++)
                {
                    $currentIndex = 1 + ( ( $i - 1 ) * 13 );
                    $startMonth = $this->getColumnHeader($currentIndex);
                    $endMonth = $this->getColumnHeader($currentIndex + 12);
                    $event->sheet->mergeCells( $startMonth."1:".$endMonth."1");
                    $event->sheet->getStyle($startMonth."3:".$endMonth.$highestRow)->applyFromArray($styleArray3);
                    $event->sheet->getStyle($startMonth."1:".$endMonth."2")->applyFromArray($styleArray3);
                }

                if($agent_count > 1)
                {
                    $agentRange = 'A3:A'.$agent_count;
                    $event->sheet->getDelegate()->getStyle($agentRange)->applyFromArray($styleArray4);
                } 

                if($total_count > 1)
                {
                    $managerRange = 'A'.($agent_count + 1).':A'.$total_count;
                    $event->sheet->getDelegate()->getStyle($managerRange)->applyFromArray($styleArray5);
                }
    
            },
        ];
    }

    
    /**
     * @return Chart|Chart[]
     */
    public function charts()
    {
        $count = $this->data->count();
        $line = $count;

        if($count == 0)
            $line = 2;
    
        $labels = [];
        $values = [];

        for($i = 1; $i < $this->currentMonth; $i++)
        {
            $currentColumn = $this->columns[$i];
            $labels[] = new DataSeriesValues('String', $this->sheetName.'!$'.$currentColumn.'$1', null, 1);
            $values[] = new DataSeriesValues('Number', $this->sheetName.'!$'.$currentColumn.'$2:$'.$currentColumn.'$'.$line, null, $count);
        }
        $categories = [
            new DataSeriesValues('String', $this->sheetName.'!$A2:$A$'.$line, null, $count),
        ];


        $series = new DataSeries(
            DataSeries::TYPE_BARCHART,
            DataSeries::GROUPING_CLUSTERED,
            range(0, count($values) - 1),
            $labels,
            $categories,
            $values
        );

        $chart1 = new Chart(
            'chart',
            new Title('Monthly Completed Contracts'),
            new Legend(Legend::POSITION_RIGHT, null, false),
            new PlotArea(null, [$series]),
        );

        $graphFirst = $this->columns[$this->currentMonth + 2];
        $graphLast = chr(ord($graphFirst) + 10); // ord() gets the ASCII value of a string, chr() converts ASCII to a string. can add 12 since it will never go past the last letter in alphabet
        $chart1->setTopLeftPosition($graphFirst.'1');
        $chart1->setBottomRightPosition($graphLast.'20');

        return $chart1;
    }

    public function getColumnHeader($num)
    {
        $numeric = $num % 26;
        $letter = chr(65 + $numeric);
        $num2 = intval($num / 26);
        if ($num2 > 0) {
            return $this->getColumnHeader($num2 - 1) . $letter;
        } else {
            return $letter;
        }
    }
}