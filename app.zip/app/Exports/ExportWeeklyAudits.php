<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Exports\Sheets\AuditSheet;


class ExportWeeklyAudits implements WithMultipleSheets
{
    use Exportable;

    protected $pending;
    protected $completed;
    protected $archived;

    public function __construct($pending, $completed, $archived)
    {
        $this->pending = $pending;
        $this->completed = $completed;
        $this->archived = $archived;
    }

    /**
     * @return array
     * Calls the three pages for the report, first the two counts then the list of contracts
     */
    public function sheets(): array
    {
        $sheets = [];

        $sheets[] = new AuditSheet($this->pending, "Pending");
        $sheets[] = new AuditSheet($this->completed, "Ready To Send");
        $sheets[] = new AuditSheet($this->archived, "Completed and Archived");

        return $sheets;
    }
}