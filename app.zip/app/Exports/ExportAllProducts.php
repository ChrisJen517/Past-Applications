<?php

namespace App\Exports;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

use App\Products;
use App\Product_Headers;

class ExportAllProducts implements FromCollection, WithHeadings, WithEvents, ShouldAutoSize
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        $products = Products::select('product_header_id', 'name', 'price', 'pricing_name', 'quote', 'manager_price_1', 'manager_price_2', 'description', 'batch_code', 'vast_code', 'sla')->orderBy('product_header_id')->get();
        $header_ids = [];

        foreach($products as $product) {
            $header_ids[] = $product->product_header_id;
        }

        $header_names = Product_Headers::whereIn('id', $header_ids)->select('id', 'name')->get();
        foreach($products as $product) {
            $header_name = $header_names->where('id', $product->product_header_id)->first();
            if ($header_name != null) {
                $header_name = $header_name->name;
            } else {
                $header_name = "";
            }
            $product->product_header_id = $header_name;
            $price = $product->price;
            $price = (float) $price;
            if ($price <= 10 || fmod($price, 1) !== 0.0) {
                if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                    $price = number_format($price, 2);
                }
            }
            $product->price = $price;
        }

        return $products;
    }

    public function headings() : array
    {
        return [
            'Product Header',
            'Product Name',
            'Product Price',
            'Product Price Type',
            'Quote',
            'Needs Manager Approval',
            'Needs Executive Approval',
            'Product Description',
            'BATCH Code',
            'VAST Code',
            'SLA',
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'top' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $cellRange = 'A1:K1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:K'.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
            },
        ];
    }
}