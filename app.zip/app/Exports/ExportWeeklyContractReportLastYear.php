<?php
namespace App\Exports;

use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;
use App\Exports\Sheets\AgentCountSheetLastYear;
use App\Exports\Sheets\AgentCountSheet;
use App\Exports\Sheets\CompletedByMonthSheetLastYear;
use App\Exports\Sheets\ContractsSheet;

class ExportWeeklyContractReportLastYear implements WithMultipleSheets
{
    use Exportable;

    protected $leads;
    protected $status;
    
    public function __construct($leads, $status)
    {
        $this->leads = $leads;
        $this->status = $status;
    }

    /**
     * @return array
     * Calls the three pages for the report, first the two counts then the list of contracts
     */
    public function sheets(): array
    {
        $sheets = [];

        $sheets[] = new AgentCountSheet($this->status, 'Month');
        $sheets[] = new AgentCountSheetLastYear($this->status);
        if($this->status == 'Completed')
            $sheets[] = new CompletedByMonthSheetLastYear(); 
        $sheets[] = new ContractsSheet($this->leads);

        return $sheets;
    }
}