<?php

namespace App\Exports;

use App\Sales_Leads;

use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class ExportContacts implements FromArray, ShouldAutoSize, WithEvents, WithHeadings
{

    public function __construct($leads) {
        $this->leads = $leads;
    }

    public function headings(): array
    {
        return [
            'Company Name',
            'Contact Title',
            'First Name',
            'Last Name',
            'Phone',
            'Phone Ext',
            'Email'
        ];

    }

    public function array(): array
    {
        return $this->leads;
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function(AfterSheet $event) {
                $styleArray = [
                    'font' => [
                        'bold' => true,
                        'size' => 14
                    ],
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'top' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ],
                    'fill' => [
                        'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                        'startColor' => [
                            'argb' => 'FFA0A0A0',
                        ]
                    ],
                ];
                $styleArray2 = [
                    'alignment' => [
                        'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
                    ],
                    'borders' => [
                        'outline' => [
                            'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                        ],
                    ]
                ];
                $highestRow = $event->sheet->getDelegate()->getHighestRow();
                $cellRange = 'A1:G1';
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray);
                $cellRange = 'A2:G'.$highestRow;
                $event->sheet->getDelegate()->getStyle($cellRange)->applyFromArray($styleArray2);
                $event->sheet->getRowDimension(1)->setRowHeight(40);
            },
        ];
    }
}
