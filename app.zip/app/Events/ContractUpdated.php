<?php

namespace App\Events;

use Illuminate\Broadcasting\Channel;
use Illuminate\Broadcasting\InteractsWithSockets;
use Illuminate\Broadcasting\PresenceChannel;
use Illuminate\Broadcasting\PrivateChannel;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;
use Illuminate\Contracts\Broadcasting\ShouldBroadcastNow;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ContractUpdated implements ShouldBroadcastNow
{
    use Dispatchable, InteractsWithSockets, SerializesModels;

    public $heading, $icon, $user, $contractId, $message;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($heading, $icon, $user, $contractId, $message)
    {
        $this->heading = $heading;
        $this->icon = $icon;
        $this->user = $user;
        $this->contractId = $contractId;
        $this->message = $message;
    }

    /**
     * Get the channels the event should broadcast on.
     *
     * @return \Illuminate\Broadcasting\Channel|array
     */
    public function broadcastOn()
    {
        return new PrivateChannel('user.' . $this->user->id);
    }

    /**
     * Get the data to broadcast.
     *
     * @return array
     */
    public function broadcastWith()
    {
        return ['heading' => $this->heading, 'icon' => $this->icon, 'userId' => $this->user->id, 'contractId' => $this->contractId, 'message' => $this->message];
    }
}
