<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use App\History;
use App\Contract_Product_History;

class Contract extends Model
{
    protected $table = "contracts";

    /**
     * Called on a new Contract to update the database.
     * Basically a constructor.
     *
     * @param $request from making a contract,
     *        $client model
     *        $contract_type
     */
    public function makeContract($request, $client, $contract_type, $products = null)
    {
        $this->company_address = $request->input('company_address');
        $this->company_city = $request->input('company_city');
        $this->company_state = $request->input('company_state');
        $this->company_zip = $request->input('company_zip');
        $this->company_email = $request->input('company_email');
        $this->agent_reference = Auth::user()->id;
        $this->approval_needed = 0;
        $this->status = 'awaiting_final_upload';
        $this->contract_name = "temp";
        $this->contract_type = $contract_type;
        $this->company_name = $client->company_name;
        $this->client_id = $client->id;
        $this->envelopeId = "";

        if (!empty($products))
            $this->products = $products->toJson();

        $this->save();

        if (!empty($products))
            $this->productHistory();
    }

    /**
     * Updates contract in the database to need Jim's approval
     *
     * @param $history model
     *
     */
    public function needJimApproval($history)
    {
        $this->status = 'awaiting_jim_approval'; //awaiting jim signature
        $this->approval_needed = 1;
        $this->save();
        $history->description = "Original contract generated. Awaiting Jim's Approval.";
        $history->save();
    }

    /**
     * Updates contract in the database to need a Manager's approval
     *
     * @param $history model
     *
     */
    public function needManagerApproval($history)
    {
        $this->status = 'awaiting_manager_approval'; //awaiting manager signature
        $this->approval_needed = 1;
        $this->save();
        $history->description = "Original contract generated. Awaiting Manager's Approval.";
        $history->save();
    }

    /**
     * Updates a contract's company information, and it's status
     *
     * @param $request from making a contract,
     *        $file_name
     */
    public function updateContract($request, $file_name, $products = null)
    {
        $this->contract_name = $file_name;
        $this->company_address = $request->input('company_address');
        $this->company_city = $request->input('company_city');
        $this->company_state = $request->input('company_state');
        $this->company_zip = $request->input('company_zip');
        $this->company_email = $request->input('company_email');
        $this->agent_reference = Auth::user()->id;
        $this->status = 'awaiting_final_upload';

        if (!empty($products))
            $this->products = $products->toJson();

        $this->save();
    }

    public function productHistory()
    {
        foreach(json_decode($this->products) as $product)
        {
            $history = new Contract_Product_History();
            $history->makeHistory($this->id, $product->productName, $product->price);
        }
    }
}