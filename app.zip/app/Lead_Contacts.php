<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lead_Contacts extends Model
{
    protected $table = "lead_contacts";

    public function lead() {
        return $this->belongsTo(Sales_Leads::class, 'lead_reference_id', 'lead_reference_id');
    }
}
