<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lead_Activity_Note extends Model
{
    protected $table = 'lead_activity_notes';

    public function lead(){
        return $this->belongsTo(Lead_Activity::class);
    }
}
