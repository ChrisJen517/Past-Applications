<?php

namespace App\Jobs;

use App\Events\ContractUpdated;
use App\RNNMailer;
use App\Contract;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use ConvertApi\ConvertApi;
use Exception;

class ConvertContract implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $user, $contractId, $files, $classPath, $param;

    /**
     * Create a new convert job instance.
     *
     * @return void
     */
    public function __construct($user, $contractId, array $files, $classPath = null, $param = null)
    {
        $this->user = $user;
        $this->contractId = $contractId;
        $this->files = $files;
        $this->classPath = $classPath;
        $this->param = $param;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $result = $this->convertAll();

        // If the result array is empty, that means that conversion has failed 3 times.
        if (empty($result)) {

            // Update the agent that their contract failed.
            event(
                new ContractUpdated(
                    'Error',
                    'error',
                    $this->user,
                    $this->contractId,
                    'Contract creation failed. Retrying... please check back soon.'
                )
            );

            $mail = new RNNMailer(true);
            $mail->addAddresses(array(
                'christianj@rnngroup.com'
            ));
            $mail->Subject = '[Contract Portal] !!! Contract Conversion Failed';
            $mail->Body    = '<p>' . $this->user->name_first . ' ' . $this->user->name_last . ' has queued for the generation of contract ' . $this->contractId . ' and the conversion process has <strong>failed</strong>.<br>Please check on the status of the contract portal and the ConvertAPI.</p>';
            $mail->send();

            // Fail the job so that it is pushed onto the failed_jobs queue
            $this->fail(new Exception('ConvertAPI has failed 3 times'));
        }

        if ($this->classPath != null) {
            // Run 'postConversion' from the class that the job was called from.
            call_user_func_array(array($this->classPath, 'postConversion'), $this->param);

            $contract = Contract::find($this->contractId);

            $mail = new RNNMailer(true);
            $mail->addAddresses(array(
                $this->user->email,
                'christianj@rnngroup.com'
            ));
            $mail->Subject = '[Contract Portal] Contract Conversion Process Completed';
            $mail->Body = '<p>' . $this->user->name_first . ', your contract id: ' . $this->contractId . ' has completed the conversion process. It has been attached to this email and is now accessible from the Contract Portal.</p>';
            $mail->addAttachment(storage_path('app/public/' . $contract->contract_name));
            $mail->send();
        }

        // Update the agent that their contract was created.
        event(
            new ContractUpdated(
                'Success',
                'success',
                $this->user,
                $this->contractId,
                'Contract successfully created. View the contract <a id="origin" data-href="/manageContract/' . $this->contractId . '">here</a>.'
            )
        );
    }

    /**
     * Convert the 'files' to pdf using ConvertAPI (attempt 3x before failure)
     *
     * @return pdfs (nullable) array of successful ($docFile => $pdfFile) conversions
     */
    public function convertAll()
    {
        $attempts = 0;
        $pdfs = array();
        ConvertApi::setApiSecret('lmtkLhMybML7470c');
        do {
            foreach ($this->files as $file => $path) {
                try {
                    $result = ConvertApi::convert('pdf', ['File' => $file]);
                    $result->getFile()->save($path);
                    array_push($pdfs, $path);
                } catch (Exception $e) {
                    report($e);
                    $pdfs = array();
                    break;
                }
                if (count($pdfs) == count($this->files))
                    return $pdfs;
                $attempts++;
            }
        } while ($attempts < 3);
        return $pdfs;
    }
}