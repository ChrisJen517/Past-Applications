<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lead_Activity extends Model
{
    protected $table = "lead_activity";

    public function lead() {
        return $this->belongsTo(Sales_Leads::class);
    }

    public function notes() {
        return $this->hasMany(Lead_Activity_Note::class, 'activity_reference_id');
    }

    public function getNotesCount() {
        return $this->notes()->count();
    }
}
