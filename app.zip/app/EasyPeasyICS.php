<?php

/* ------------------------------------------------------------------------ */
/* EasyPeasyICS
/* ------------------------------------------------------------------------ */
/* Manuel Reinhard, manu@sprain.ch
/* Twitter: @sprain
/* Web: www.sprain.ch
/*
/* Built with inspiration by
/" http://stackoverflow.com/questions/1463480/how-can-i-use-php-to-dynamically-publish-an-ical-file-to-be-read-by-google-calend/1464355#1464355
/* ------------------------------------------------------------------------ */
/* History:
/* 2010/12/17 - Manuel Reinhard - when it all started
/* ------------------------------------------------------------------------ */
namespace App;

use Carbon\Carbon;

class EasyPeasyICS {

	protected $calendarName;
	protected $events = array();


	/**
	 * Constructor
	 * @param string $calendarName
	 */
	public function __construct($calendarName=""){
		$this->calendarName = $calendarName;
	}//function


	/**
	 * Add event to calendar
	 * @param string $calendarName
	 */
	public function addEvent($start, $summary="", $description="", $recipients, $location=null) {
		$this->events[] = array(
			"start" => $start,
			"end"   => Carbon::parse($start)->addHour()->timestamp,
			"summary" => $summary,
            "description" => $description,
            "location" => empty($location) ? "" : $location,
            "url" => 'https://contract.rnngroup.com'
        );

        $this->recipients = $recipients;
	}


	public function render($output = true) {
		//start Variable
        $ics = "";

		//Add header
		$ics .= "BEGIN:VCALENDAR\r\nMETHOD:PUBLISH\r\nVERSION:2.0\r\nX-WR-CALNAME:".$this->calendarName."\r\nPRODID:-//hacksw/handcal//NONSGML v1.0//EN\r\n";

		//Add events
		foreach($this->events as $event) {
            $ics .= "BEGIN:VEVENT\r\nUID:". md5(uniqid(mt_rand(), true)) ."@EasyPeasyICS.php\r\nORGANIZER;CN=\"Contract Portal\":mailto:reports@bbconsultantsgroup.com\r\n";
            foreach($this->recipients as $recipient) {
                $name = $recipient['name'];
                $email = $recipient['email'];
                $ics .= "ATTENDEE;CUTYPE=INDIVIDUAL;ROLE=REQ-PARTICIPANT;PARTSTAT=NEEDS-ACTION;RSVP=TRUE;CN=${name};X-NUM-GUESTS=0:mailto:${email}\r\n";
            }
            if (!empty($event['location']))
                $ics .= "LOCATION: ".$event['location']."\r\n";
            $ics .= "TZID=UTC\r\nDTSTAMP:" . gmdate("Ymd")."T". gmdate("His") . "Z\r\nDTSTART:".gmdate("Ymd", $event["start"])."T".gmdate("His", $event["start"])."Z\r\nDTEND:".gmdate("Ymd", $event["end"])."T".gmdate("His", $event["end"])."Z\r\nSUMMARY:".str_replace("\n", "\\n", $event["summary"])."\r\nDESCRIPTION:".str_replace("\n", "\\n", $event["description"])."\r\nURL;VALUE=URI:".$event["url"]."\r\nEND:VEVENT\r\n";
		}//foreach

		//Footer
		$ics .= "END:VCALENDAR\r\n";

		if ($output) {
			//Output
			header("Content-type: text/calendar; charset=utf-8");
			header("Content-Disposition: inline; filename=".$this->calendarName.".ics");
			echo $ics;
		} else {
			return $ics;
		}

	}//function

}//class