<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Contract;
use App\Exports\ExportWeeklyAudits;
use Maatwebsite\Excel\Facades\Excel;
use App\RNNMailer;
use App\Audits;

class WeeklyAuditReport extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:WeeklyAuditReport';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Gives a weekly report of the completed and pending reports on a YTD basis';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $date = date("F_j_Y");
        $this->createReport($date);
        // $this->sendWeeklyAuditReport($date);
    }

    //creates the reports as excell files and stores them in the public/exports folder
    public function createReport($date){
        $pending = Audits::selectRaw("audits.audit_name, audits.audit_type, audits.notes, audits.account_manager, audits.due_date, audits.completed_date")->join('client_profiles', 'client_profiles.id', '=', 'audits.client_id')->where('status', 'Pending')->get();
        $completed = Audits::selectRaw("audits.audit_name, audits.audit_type, audits.notes, audits.account_manager, audits.due_date, audits.completed_date")->join('client_profiles', 'client_profiles.id', '=', 'audits.client_id')->where('status', 'Complete')->get();
        $archived = Audits::selectRaw("audits.audit_name, audits.audit_type, audits.notes, audits.account_manager, audits.due_date, audits.completed_date")->join('client_profiles', 'client_profiles.id', '=', 'audits.client_id')->where('audits.is_archived', '1')->get();
        Excel::store(new ExportWeeklyAudits($pending, $completed, $archived), 'Weekly_Audit_Report_'.$date.'.xlsx', 'exports');
    }

    //this function sends the report out and then deletes the files after it is done
    public function sendWeeklyReport($date){
        $mail = new RNNMailer(true);
        $mail->sendWeeklyReports($date);
    }
}