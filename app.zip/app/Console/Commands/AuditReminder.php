<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Config;
use App\Models\Corporation;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Audits;
use App\RNNMailer;

class AuditReminder extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:AuditReminder';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send reminder emails';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->auditReminder();
    }

    public function auditReminder(){
        if(Audits::where("status", "!=", "Complete")->where("is_archived", 0)->exists())
        {
            $mail = new RNNMailer(true);
            $mail->auditAutoReminder();
        }
        // $audits = Audits::whereRaw("(DATEDIFF(due_date, CURDATE()) <= 3) OR (DATEDIFF(due_date, CURDATE()) % 7 = 0)")
        // ->whereNull("completed_date")->get();
        // foreach($audits as $audit)
        // {
        //     $mail = new RNNMailer(true);
        //     $mail->sendAuditReminder($audit);
        // }
    }
}