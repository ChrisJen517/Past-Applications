<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Config;
use App\Models\Corporation;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Audits;

class UpdateAuditStatus extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:UpdateAuditStatus';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update Audit Status';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->updateStatus();
    }

    public function updateStatus(){
        Audits::whereRaw("(DATEDIFF(due_date, CURDATE()) < 0)")->update(["status" => "Past Due"]);
        Audits::whereRaw("(DATEDIFF(due_date, CURDATE()) <= 3 AND DATEDIFF(due_date, CURDATE()) >= 0)")->update(["status" => "Due Soon"]);
    }
}