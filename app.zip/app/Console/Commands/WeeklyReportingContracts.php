<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Foundation\Bus\Dispatchable;
use App\Contract;
use App\Exports\ExportWeeklyContractReport;
use App\Exports\ExportWeeklyContractReportLastYear;
use Maatwebsite\Excel\Facades\Excel;
use App\RNNMailer;

class WeeklyReportingContracts extends Command
{
    use Dispatchable;
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:WeeklyReportingContracts';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Gives a weekly report of the completed and pending reports on a YTD basis';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $date = date("F_j_Y");
        // $date = date("F_i_Y", strtotime('2021-02-28'));
        $this->createReport($date);
        $this->sendWeeklyReport($date);
    }

    //creates the reports as excell files and stores them in the public/exports folder
    public function createReport($date){
        $contracts = Contract::selectRaw("contracts.id as id, contracts.company_name, CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.updated_at as updated_at, contracts.contract_type, contracts.status, contracts.products")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("contracts.status != 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND YEAR(contracts.updated_at) = YEAR(CURDATE())")
        ->orderBy('contracts.id', 'desc')->get();
        Excel::store(new ExportWeeklyContractReport($contracts, "Pending"), 'Pending_Contract_'.$date.'.xlsx', 'exports');

        $contracts = Contract::selectRaw("contracts.id as id, contracts.company_name, CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.updated_at as updated_at, contracts.contract_type, contracts.status, contracts.products")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("contracts.status = 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND YEAR(contracts.updated_at) = YEAR(CURDATE())")
        ->orderBy('contracts.id', 'desc')->get();
        Excel::store(new ExportWeeklyContractReport($contracts, 'Completed'), 'Complete_Contract_'.$date.'.xlsx', 'exports');

        $contracts = Contract::selectRaw("contracts.id as id, contracts.company_name, CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.updated_at as updated_at, contracts.contract_type, contracts.status, contracts.products")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("contracts.status != 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND ( YEAR(contracts.updated_at) = YEAR(CURDATE()) OR YEAR(contracts.updated_at) = YEAR(CURDATE()) - 1 )")
        ->orderBy('contracts.id', 'desc')->get();
        Excel::store(new ExportWeeklyContractReportLastYear($contracts, "Pending"), 'Pending_Contract_2020-2021_'.$date.'.xlsx', 'exports');

        $contracts = Contract::selectRaw("contracts.id as id, contracts.company_name, CONCAT(users.name_first, ' ', users.name_last) AS agent_name, contracts.updated_at as updated_at, contracts.contract_type, contracts.status, contracts.products")
        ->join('users', 'contracts.agent_reference', '=', 'users.id')
        ->whereRaw("contracts.status = 'complete' AND (contracts.is_archived != '1' OR contracts.is_archived IS NULL) AND ( YEAR(contracts.updated_at) = YEAR(CURDATE()) OR YEAR(contracts.updated_at) = YEAR(CURDATE()) - 1 )")
        ->orderBy('contracts.id', 'desc')->get();
        Excel::store(new ExportWeeklyContractReportLastYear($contracts, 'Completed'), 'Complete_Contract_2020-2021_'.$date.'.xlsx', 'exports');
    }

    //this function sends the report out and then deletes the files after it is done
    public function sendWeeklyReport($date){
        $mail = new RNNMailer(true);
        $mail->sendWeeklyReports($date);
    }
}