<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        Commands\AuditReminder::class,
        Commands\UpdateAuditStatus::class,
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // Update audit status at the start of each day
        $schedule->command('command:UpdateAuditStatus')
            ->dailyAt('8:00')
            ->timezone('America/New_York');

        // Send reminders for pending audits every Monday Wednesday Friday at 9:00am EST
        $schedule->command('command:AuditReminder')
            ->days([1, 3, 5])
            ->dailyAt('9:00')
            ->timezone('America/New_York');
    
        // $schedule->command('queue:retry all')->ev;
        // $schedule->command('queue:work --timeout=55 --stop-when-empty')->everyMinute();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}