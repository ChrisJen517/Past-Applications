<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseRequestHistory extends Model
{
    protected $table = 'purchase_request_history';

    public function __create($purchase_request_id, $submitter, $history, $comment = null)
    {
        $this->purchase_request = $purchase_request_id;
        $this->submitter = $submitter;
        $this->history = $history;
        $this->comment = $comment;
        $this->save();
    }
}