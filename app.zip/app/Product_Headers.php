<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product_Headers extends Model
{
    //
    protected $table="product_headers";

    public function products()
    {
        return $this->hasMany('App\Products','product_header_id','id')->orderBy('order','asc');
    }
}
