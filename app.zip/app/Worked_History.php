<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Worked_History extends Model
{
    protected $table = 'worked_history';
}
