<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Client_Email extends Model
{
    protected $fillable = ['subject', 'body', 'recipient', 'client_id', 'sender_id', 'password'];
    protected $table = "client_emails";

    public function __create($subject, $body, $recipient, $client_id, $sender_id, $password)
    {
        $this->subject = $subject;
        $this->body = $body;
        $this->recipient = $recipient;
        $this->client_id = $client_id;
        $this->sender_id = $sender_id;

        if($password){
            $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ!?@#';
            $randomString = '';
            for ($i = 0; $i < 10; $i++) {
                $randomString .= $characters[rand(0, 65)];
            }
            $this->password = $randomString;
        }

        $this->save();
    }
}