<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Auth;

class YouNegotiateHistory extends Model
{
    protected $table = "you_negotiate_history";

    /**
     * Fills out a new You-Negotiate history
     *
     * @param $request from making you-negotiate contract
     *        $client model
     *        $contract_id
     */

    public function newHistory($request, $client, $contract_id)
    {
        $this->agent_reference = Auth::user()->id;
        $this->company_name = $client->company_name;
        $this->setup_price = $request->price[0];
        $this->monthly_service_fee_percentage = $request->price[1];
        $this->customized_setup_price = $request->price[2];
        $this->monthly_minimum_price = $request->price[3];
        $this->client_id = $client->id;
        $this->contract_id = $contract_id;
        $this->approved_by = "No approval needed";
        $this->save();
    }
}
