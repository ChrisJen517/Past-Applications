@extends('Includes.basicLayout')
@section('content')

@include('Includes.modal.audit.createAuditModal')
@include('Includes.modal.audit.editAuditModal')
@include('Includes.modal.audit.manageFilesModal')

<link href="{{asset('css/multiTableProcessing.css?'.time())}}" rel="stylesheet" />
<div class="container-fluid">
    <br>
    <a class="btn btn-primary" data-toggle="modal" data-target="#createAudit"
        style="margin:0px 0px 20px 15px; color:white;">Create Audit</a>

    <section id="previous-uploads-header">
        <div class="container-fluid">
            <div class="row text-left">
                <div class="col text-left">
                    <p>Pending Audits</p>
                </div>
            </div>
        </div>
    </section>    
    <div class="table-responsive">
        <div id="contracts-parent" class="table-parent">
            <table class="table table-striped table-bordered" id="pending-audits-table">
                <thead>
                    <tr>
                        <th class="text-center">Number</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Account Manager</th>
                        <th class="text-center">Client</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Created Date</th>
                        <th class="text-center">Due Date</th>
                        <th class="text-center">Manage Files</th>
                        <th class="text-center">Edit</th>
                        <th class="text-center">Ready</th>
                        <th class="text-center">Archive</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $pending = $audits->where('completed_date', null)->where('is_archived', 0); 
                    $today = date('Y-m-d'); 
                    $oneWeek = date('Y-m-d', strtotime('+1 week'));?>
                    @foreach($pending as $item)
                        <tr>
                            <td style="width:5%;">{{$item->id}}</td>
                            <td style="width:5%;">{{$item->audit_type}}</td>
                            <td style="width:10%;">{{$item->audit_name}}</td>
                            <td style="width:15%;">{{$item->account_manager}}</td>
                            <td style="width:15%;">
                                <a href="{{"/manageClients/edit/".$item->client_id}}">
                                    {{$clients->where('id', $item->client_id)->first()->company_name ?? $item->client_id}}
                                </a>    
                            </td>
                            <td style="width:5%;">{{$item->status}}</td>
                            <td style="width:5%;">{{$item->created_at}}</td>
                            <td
                            @if(strtotime($item->due_date) <= strtotime($today))
                                style="color:white !important; background-color: #bf2821 !important; font-weight: 500; width:10%;"
                            @elseif(strtotime($item->due_date) < strtotime($oneWeek))
                                style="color: white !important; background-color:goldenrod !important; font-weight: 500; width:10%;"
                            @endif>
                                {{$item->due_date}}
                            </td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#manageFilesModal" style="color:white;"
                                    data-id="{{ $item->id }}" data-name="{{ $item->audit_name }}">
                                    Manage
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAuditModal" style="color:white;"
                                    data-id="{{ $item->id }}" data-client_id="{{ $item->client_id }}" data-name="{{ $item->audit_name }}" data-notes="{{ $item->notes }}" 
                                    data-due_date="{{ $item->due_date }}" data-account_manager="{{$item->account_manager}}" data-client_contact="{{$item->client_contact}}" data-status="{{'pending'}}" data-cc="{{$item->cc}}" data-audit_type="{{$item->audit_type}}">
                                    Edit
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-success" onclick="completeAudit({{$item->id}}, 'complete', '{{$item->audit_name}}')">Ready</button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-danger" onclick="archiveAudit({{$item->id}}, 'Archive', '{{$item->audit_name}}')">Archive</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <section id="previous-uploads-header">
        <div class="container-fluid">
            <div class="row text-left">
                <div class="col text-left">
                    <p>Ready To Be Sent Audits</p>
                </div>
            </div>
        </div>
    </section>    
    <div class="table-responsive">
        <div id="contracts-parent" class="table-parent">
            <table class="table table-striped table-bordered" id="complete-audits-table">
                <thead>
                    <tr>
                        <th class="text-center">Number</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Account Manager</th>
                        <th class="text-center">Client</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Created Date</th>
                        <th class="text-center">Readied Date</th>
                        <th class="text-center">Manage Files</th>
                        <th class="text-center">Edit</th>
                        <th class="text-center">Archive</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $completed = $audits->where('completed_date', '!=', null)->where('is_archived', 0) ?>
                    @foreach($completed as $item)
                        <tr>
                            <td style="width:5%;">{{$item->id}}</td>
                            <td style="width:5%;">{{$item->audit_type}}</td>
                            <td style="width:10%;">{{$item->audit_name}}</td>
                            <td style="width:15%;">{{$item->account_manager}}</td>
                            <td style="width:15%;">
                                <a href="{{"/manageClients/edit/".$item->client_id}}">
                                    {{$clients->where('id', $item->client_id)->first()->company_name ?? $item->client_id}}
                                </a>    
                            </td>
                            <td style="width:5%;">Ready to Send</td>
                            <td style="width:5%;">{{$item->created_at}}</td>
                            <td style="width:10%;">{{$item->completed_date}}</td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#manageFilesModal" style="color:white;"
                                    data-id="{{ $item->id }}" data-name="{{ $item->audit_name }}">
                                    Manage
                                </button>
                            </td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAuditModal" style="color:white;"
                                    data-id="{{ $item->id }}" data-client_id="{{ $item->client_id }}" data-name="{{ $item->audit_name }}" data-notes="{{ $item->notes }}" 
                                    data-due_date="{{ $item->due_date }}" data-account_manager="{{$item->account_manager}}" data-client_contact="{{$item->client_contact}}" data-status="{{'complete'}}" data-cc="{{$item->cc}}" data-audit_type="{{$item->audit_type}}">
                                    Edit
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-danger" onclick="archiveAudit({{$item->id}}, 'Archive', '{{$item->audit_name}}')">Archive</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <section id="previous-uploads-header">
        <div class="container-fluid">
            <div class="row text-left">
                <div class="col text-left">
                    <p>Archived Audits</p>
                </div>
            </div>
        </div>
    </section>    
    <div class="table-responsive">
        <div id="contracts-parent" class="table-parent">
            <table class="table table-striped table-bordered" id="archived-audits-table">
                <thead>
                    <tr>
                        <th class="text-center">Number</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Account Manager</th>
                        <th class="text-center">Client</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Created Date</th>
                        <th class="text-center">Due Date</th>
                        <th class="text-center">Readied Date</th>
                        <th class="text-center">Manage Files</th>
                        <th class="text-center">Edit</th>
                        <th class="text-center">Unarchive</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $archived = $audits->where('is_archived', 1) ?>
                    @foreach($archived as $item)
                        <tr>
                            <td style="width:5%;">{{$item->id}}</td>
                            <td style="width:5%;">{{$item->audit_type}}</td>
                            <td style="width:10%;">{{$item->audit_name}}</td>
                            <td style="width:15%;">{{$item->account_manager}}</td>
                            <td style="width:15%;">
                                <a href="{{"/manageClients/edit/".$item->client_id}}">
                                    {{$clients->where('id', $item->client_id)->first()->company_name ?? $item->client_id}}
                                </a>    
                            </td>
                            <td style="width:5%;">{{$item->status}}</td>
                            <td style="width:5%;">{{$item->created_at}}</td>
                            <td style="width:5%;">{{$item->due_date}}</td>
                            <td style="width:5%;">{{$item->completed_date}}</td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#manageFilesModal" style="color:white;"
                                    data-id="{{ $item->id }}" data-name="{{ $item->audit_name }}">
                                    Manage
                                </button>
                            </td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAuditModal" style="color:white;"
                                    data-id="{{ $item->id }}" data-client_id="{{ $item->client_id }}" data-name="{{ $item->audit_name }}" data-notes="{{ $item->notes }}" 
                                    data-due_date="{{ $item->due_date }}" data-account_manager="{{$item->account_manager}}" data-client_contact="{{$item->client_contact}}" data-status="{{'complete'}}" data-cc="{{$item->cc}}" data-audit_type="{{$item->audit_type}}">
                                    Edit
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-danger" onclick="archiveAudit({{$item->id}}, 'Unarchive', '{{$item->audit_name}}')">Unarchive</button>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
<br>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        var table = $('#pending-audits-table').DataTable( {
            "order": [[ 7, "asc" ]],
            lengthChange: false,
            buttons: [
            {
                extend: 'excel',
                title: 'Pending Audits'
            }
            ],
            "initComplete": function(settings, json) {
            },
        });

        table.buttons().container()
            .appendTo( '#pending-audits-table_wrapper .col-md-6:eq(0)' );

        var table = $('#complete-audits-table').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
            {
                extend: 'excel',
                title: 'Pending Audits'
            }
            ],
            "initComplete": function(settings, json) {
            },
        });

        var table = $('#archived-audits-table').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
            {
                extend: 'excel',
                title: 'Pending Audits'
            }
            ],
            "initComplete": function(settings, json) {
            },
        });
    });

    function archiveAudit(auditId, textArchive, name){    
        var _token = $('input[name="_token"]').val();
        swal.fire({
            title: "Are you sure?",
            text: "You are about to "+textArchive+": "+name,
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: textArchive
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: "{{ route('archiveAudit') }}",
                        data: {
                            id:auditId,
                            _token:_token
                        },
                    }).then(function(data) {
                        $.LoadingOverlay("hide");

                        swal.fire(
                            "Success",
                            "Successfully "+textArchive+"d "+name+".",
                            "success"
                        ).then(function() {
                            $.LoadingOverlay("show");
                            location.reload();
                        });
                        
                    });
                });
            } else {
                swal.fire("Cancelled", name+" Was Not "+textArchive+"d!", "error");
            }
        }); 
    }

    function completeAudit(auditId, textArchive, name){    
        var _token = $('input[name="_token"]').val();
        swal.fire({
            title: "Are you sure?",
            text: "Are you sure: "+name+" is ready to be sent",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: textArchive
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: "{{ route('completeAudit') }}",
                        data: {
                            id:auditId,
                            _token:_token
                        },
                    }).then(function(data) {
                        $.LoadingOverlay("hide");

                        swal.fire(
                            "Success",
                            "Successfully updated "+name+".",
                            "success"
                        ).then(function() {
                            $.LoadingOverlay("show");
                            location.reload();
                        });
                        
                    });
                });
            } else {
                swal.fire("Cancelled", name+" Was Not Updated!", "error");
            }
        }); 
    }
</script>
@endsection
