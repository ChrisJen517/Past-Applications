@extends('Includes.basicLayout')
@section('content')
{{ csrf_field() }}
<div class="container-fluid">
    <div class="row">
            <!-- form user info -->
            <div class="card" style="width:100%;">
                <div class="card-header">
                    <h4>Contract Information</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class='col-lg-6'>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Contract Number</label>
                                <div class="col-lg-8">
                                    <input class="form-control" name="firstname" type="text" value="{{$contract->id}}" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Company name</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="{{$contract->company_name}}" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Company Address</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="{{$address}}" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Creation date</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="{{$contract->created_at}}" readonly>
                                </div>
                            </div>
                        </div>
                        <div class='col-lg-6'>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Manager Email</label>
                                <div class="col-lg-8">
                                    <input autocomplete="off" class="form-control auto-complete-off" name="manager_email" type="email" value="{{ Auth::user()->manager_email }}" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Contract Type</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="{{$contract->contract_type}}" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Contract Status</label>
                                <div class="col-lg-8">
                                @if($contract->status == 'awaiting_jim_approval')
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Manager Approval" readonly>
                                @elseif($contract->status == 'awaiting_manager_approval')
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Manager Approval" readonly>
                                @elseif($contract->status == 'awaiting_final_upload')
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Final Contract Upload" readonly>
                                @elseif($contract->status == 'complete')
                                    <input class="form-control" name="firstname" type="text" value="Contract Complete" readonly>
                                @elseif($contract->status == 'awaiting_all_signature')
                                    <input class="form-control" name="firstname" type="text" value="Contract awaiting signatures by client and RNN." readonly>
                                @elseif($contract->status == 'awaiting_client_signature')
                                    <input class="form-control" name="firstname" type="text" value="Contract awaiting signature by client." readonly>
                                @elseif($contract->status == 'awaiting_jim_signature')
                                    <input class="form-control" name="firstname" type="text" value="Contract awaiting signature by RNN." readonly>
                                @elseif($contract->status == 'awaiting_client_changes')
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Client Changes" readonly>
                                @elseif($contract->status == 'awaiting_legal_approval')
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Legal Approval" readonly>
                                @elseif($contract->status == 'changes_requested')
                                    <input class="form-control" name="firstname" type="text" value="Changes Requested" readonly>
                                @elseif($contract->status == 'void')
                                    <input class="form-control" name="firstname" type="text" value="Contract Voided" readonly>
                                @endif
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-4">
                                    <a href="{{route('agentDashboard')}}" class="btn btn-secondary float-left">Back</a>
                                </div>
                                <div class="col-lg-8">
                                    @if($contract->status == 'awaiting_client_changes')
                                        <a href="" data-toggle="modal" data-target="#clientChangesModal" class="btn btn-primary btn-sm float-right" role="button">Upload Client Changes</a>
                                    @elseif($contract->status == 'awaiting_legal_approval')
                                        <a href="" data-toggle="modal" data-target="#redlineChangesModal" class="btn btn-warning btn-sm" role="button">Upload Changes</a>   
                                        <span class="float-right">Awaiting Approval From Legal</span>
                                    @elseif($contract->status == 'changes_requested')
                                        <a href="" data-toggle="modal" data-target="#redlineChangesModal" class="btn btn-primary btn-sm float-right" role="button">Upload Changes</a>
                                    @elseif($contract->status == 'awaiting_product_selection')
                                        <a href="" data-toggle="modal" data-target="#redlineChangesModal" class="btn btn-warning btn-sm" role="button">Upload Changes</a>   
                                        <a href="{{route('showRedlineProducts',$contract->id)}}" class="btn btn-primary btn-sm float-right" role="button">Select Final Products</a>
                                    @elseif($contract->status == 'complete')
                                        <a href="" data-toggle="modal" data-target="#contractChangesModal" class="btn btn-primary btn-sm float-right" role="button">Upload Contract Updates</a>
                                    @elseif($contract->status == 'awaiting_manager_approval')
                                        <span class="float-right">Awaiting Approval From Manager</span>
                                    @elseif($contract->status == 'awaiting_jim_approval')
                                        <span class="float-right">Awaiting Approval From Manager</span>
                                    @elseif($contract->status == 'void')
                                        <span class="float-right">Contract Voided</span>
                                    @else
                                        <a href="" data-toggle="modal" data-target="#clientSignatureModal" class="btn btn-primary btn-sm float-right" role="button">Upload Final Contract</a>
                                        @if($contract->status == 'awaiting_all_signature')
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;"  onclick="resendContract({{$contract->id}}, 'jimv@rnngroup.com and ' + '{{$contract->docusign_email == null ? $contract->company_email : $contract->docusign_email}}')">
                                                Resend Contract
                                            </button>
                                        @elseif($contract->status == 'awaiting_client_signature')
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;" onclick="resendContract({{$contract->id}}, '{{$contract->docusign_email == null ? $contract->company_email : $contract->docusign_email}}')">
                                                Resend Contract
                                            </button>
                                        @elseif($contract->status == 'awaiting_jim_signature')
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;" onclick="resendContract({{$contract->id}}, 'jimv@rnngroup.com')">
                                                Resend Contract
                                            </button>
                                        @elseif($contract->contract_type != 'REDLINE')
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;" onclick="sendContract({{$contract->id}}, '{{$contract->company_email}}', '{{$name_options}}')">
                                            Send
                                            </button>
                                        @endif
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <section id="history">
        <div class="row">
            <h3>Contract History</h3>
        </div>
        <div class="row">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="history">
                    <thead>
                        <tr>
                            <th class="text-center">Update Time</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Updated File</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($history as $item)
                        <?php
                            $contractName = $item->file_name;
                            $contractName = "../".$contractName;
                            ?>
                        <tr class="item{{$item->id}}">
                            <td>{{$item->created_at}}</td>
                            <td>{{$item->description}}</td>
                            @if($contract->approval_needed == 1)
                            <td class="text-center">Awaiting Approval</td>
                            @else
                            <td class="text-center">
                                <a href="{{route('download', $item->file_name)}}">
                                    <div style="height:100%;width:100%">
                                        Download
                                    </div>
                                </a>
                            </td>
                            @endif
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    @if(!empty($products->first()))
        <section id="product_history">
            <div class="row">
                <h3>Contract Product History</h3>
            </div>
            <div class="row">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="products">
                        <thead>
                            <tr>
                                <th style="width: 50%" class="text-center">Product Name</th>
                                <th style="width: 50%" class="text-center">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $total = 0 ?>
                            @foreach($products as $product)
                                <?php $total += (is_numeric($product->price) ? $product->price : 0) ?> 
                                <tr class="item{{$product->id}}">
                                    <td style="width: 50%" class="text-center">{{$product->product_name}}</td>
                                    <td style="width: 50%" class="text-center">${{$product->price}}</td>
                                </tr>
                            @endforeach
                        </tbody>
                        <tfoot>
                            <tr>
                                <th style="width: 50%" class="text-center">Total</th>
                                <th style="width: 50%" class="text-center">${{$total}}</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </section>
    @endif
</div>

<div class="modal fade" id="clientChangesModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Client Changes Upload (.docx or .pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="{{route('uploadCustomerChanges')}}" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="{{$contract->contract_name}}">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="{{$contract->id}}">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Signature Upload File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".docx, .pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="contractChangesModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Contract Changes Upload (.pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="{{route('uploadContractChanges')}}" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="{{$contract->contract_name}}">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="{{$contract->id}}">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Contract Updated File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="redlineChangesModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Redline Changes Upload (.docx only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="{{route('uploadRedlineChanges')}}" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="{{$contract->contract_name}}">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="{{$contract->id}}">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Contract Updated File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".docx"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="clientSignatureModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Final Contract Upload (.pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="{{route('uploadCustomerSignature')}}" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="{{$contract->contract_name}}">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="{{$contract->id}}">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Contract Upload</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="managerSignatureModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Manager Signature Upload (.pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="{{route('uploadManagerSignature')}}" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="{{$contract->contract_name}}">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="{{$contract->id}}">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Signature Upload File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('js/modal.js?'.time())}}"></script>
<script>
$(document).ready(function () {
    $("#clientSignatureModal").validate({
        rules: {
            uploadFile: "required"
        },
        messages: {
            uploadFile: "Please select a file to upload"
        }
    });
    $("#managerSignatureModal").validate({
        rules: {
            uploadFile2: "required"
        },
        messages: {
            uploadFile2: "Please select a file to upload"
        }
    });
});

$(".manualUploadForm").on( "submit",function(){
    $.LoadingOverlay("show");
});
</script>

@endsection
