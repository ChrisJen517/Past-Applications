@extends('Includes.basicLayout')
@section('content')
<br>
<section id="dashboard-icons">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-3 mb-3 text-center">
                <a href="/MSA" class="fas fa-file-signature fa-4x mb-2 dashboard-icon"></a>
                <h3>Standard FCRA MSA</h3>
                <p>Generate a Standard FCRA MSA contract with options to customize pricing and products</p>
            </div>
            <div class="col-md-3 mb-3 text-center">
                <a href="/MSA_No_FCRA" class="fas fa-file-signature fa-4x mb-2 dashboard-icon"></a>
                <h3>Non FCRA MSA</h3>
                <p>Generate a Non FCRA MSA contract with options to customize pricing and products</p>
            </div>
            <div class="col-md-3 mb-3 text-center">
                <a href="/You-Negotiate" class="fas fa-file-signature fa-4x mb-2 dashboard-icon"></a>
                <h3>You-Negotiate</h3>
                <p>Generate a You-Negotiate contract with options to customize pricing and products</p>
            </div>
            <div class="col-md-3 mb-3 text-center">
                <a href="/RedlineStart" class="fas fa-highlighter fa-4x mb-2 dashboard-icon"></a>
                <h3>Redline MSA</h3>
                <p>Generate an MSA Redline Contract</p>
            </div>


        </div>

        <div class="row">
            <div class="col-md-3 mb-3 text-center">
                <a href="/MSA_Amendment" class="fas fa-edit fa-4x mb-2 dashboard-icon"></a>
                <h3>MSA Amendment</h3>
                <p>Generate an MSA Amendment Contract</p>
            </div>
            <div class="col-md-3 mb-3 text-center">
                <a href="/FCRA" class="fas fa-edit fa-4x mb-2 dashboard-icon"></a>
                <h3>FCRA Amendment</h3>
                <p>Generate an FCRA Amendment Contract</p>
            </div>
            <div class="col-md-3 mb-3 text-center">
                <a href="/productSheet" class="far fa-file-alt fa-4x mb-2 dashboard-icon"></a>
                <h3>Generate Product Sheet</h3>
                <p>Generate a custom product sheet</p>
            </div>
            <div class="col-md-3 mb-3 text-center">
                <a href="/NDA" class="far fa-eye-slash fa-4x mb-2 dashboard-icon"></a>
                <h3>Standard NDA</h3>
                <p>Generate a standard NDA contract</p>
            </div>
            {{-- <div class="col-md-3 mb-3 text-center">
                <a href="/supportDocuments" class="fas fa-clipboard-list fa-4x mb-2 dashboard-icon"></a>
                <h3>Support Documents</h3>
                <p>View all documents to support your sales.</p>
            </div> --}}

        </div>
    </div>
</section>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Contracts Pending:</p>
            </div>

        </div>
    </div>
</section>
<section id="upload-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive">
                <div id="contracts-pending-parent" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="contracts-table-pending">
                        <thead>
                            <tr>
                                <th class="text-center">ID</th>
                                <th class="text-center">Client Name</th>
                                <th class="text-center">Created Date</th>
                                <th class="text-center">Contract Type</th>
                                <th class="text-center">Send Contract</th>
                                <th class="text-center">Download</th>
                                <th class="text-center">History</th>
                                <th class="text-center">Next Action</th>
                                <th class="text-center">Archive</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($contracts as $item)
                            @if($item->is_archived != 1 && $item->status != 'complete' && $item->contract_type != "ICA")
                            <?php
                                $redirect = '';
                                if ($item->client_id != null)
                                    $redirect = route('editClient', $item->client_id);
                                elseif ($item->contract_type != "ICA")
                                    $redirect = route('findClient', $item->company_name);

                                $name_options = "";
                                if(isset($item->account_payable_name)) {
                                    $name_options .= "<br>" . $item->account_payable_name;
                                }
                                if(isset($item->invoice_approver_name)) {
                                    $name_options .= "<br>" . $item->invoice_approver_name;
                                }
                                if(isset($item->executive_contact_name)) {
                                    $name_options .= "<br>" . $item->executive_contact_name;
                                }
                            ?>
                            <tr class="item{{$item->id}}">
                                <td>{{$item->id}}</td>
                                <td>
                                    @if($redirect != '')
                                    <a href="{{ $redirect }}">
                                        {{$item->company_name}}
                                    </a>
                                    @else
                                    {{$item->company_name}}
                                    @endif
                                </td>
                                <td>{{substr($item->created_at, 0, 10)}}</td>
                                <td>{{$item->contract_type}}</td>
                                <td class="text-center">
                                    @if($item->status == 'converting')
                                    Converting
                                    @elseif($item->approval_needed == 1)
                                    Awaiting Approval
                                    @elseif($item->contract_type == "REDLINE")
                                    Docusign not implemented for redline
                                    @elseif($item->status == 'complete')
                                    Contract Complete
                                    @elseif($item->company_email == NULL)
                                    No Email with Contract
                                    @elseif($item->status == 'awaiting_all_signature')
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="resendContract({{$item->id}}, 'jimv@rnngroup.com and ' + '{{$item->docusign_email == null ? $item->company_email : $item->docusign_email}}')">
                                        Resend
                                    </button>
                                    @elseif($item->status == 'awaiting_client_signature')
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="resendContract({{$item->id}}, '{{$item->docusign_email == null ? $item->company_email : $item->docusign_email}}')">
                                        Resend
                                    </button>
                                    @elseif($item->status == 'awaiting_jim_signature')
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="resendContract({{$item->id}}, 'jimv@rnngroup.com')">
                                        Resend
                                    </button>
                                    @else
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="sendContract({{$item->id}}, '{{$item->company_email}}', '{{$name_options}}')">
                                        Send
                                    </button>
                                    @endif
                                </td>
                                @if($item->approval_needed == 1)
                                <td class="text-center">Awaiting Approval</td>
                                @elseif($item->status == 'converting')
                                <td class="text-center">Converting</td>
                                @else
                                <td class="text-center">
                                    <a href="{{route('download', $item->contract_name)}}">
                                        <div style="height:100%;width:100%">
                                            Download
                                        </div>
                                    </a>
                                </td>
                                @endif
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">History</a>
                                </td>
                                @if($item->status == 'converting')
                                <td class="text-center">
                                    Converting
                                </td>
                                @elseif($item->status == 'awaiting_manager_approval')
                                <td class="text-center">
                                    Awaiting Approval by Manager
                                </td>
                                @elseif($item->status == 'awaiting_jim_approval')
                                <td class="text-center">
                                    Awaiting Approval by Jim
                                </td>
                                @elseif($item->status == 'awaiting_final_upload')
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">Upload Final Contract</a>
                                </td>
                                @elseif($item->status == 'complete')
                                <td class="text-center">
                                    Contract Complete
                                </td>
                                @elseif($item->status == 'awaiting_all_signature')
                                <td class="text-center">
                                    Contract awaiting signatures by client and RNN.
                                </td>
                                @elseif($item->status == 'awaiting_client_signature')
                                <td class="text-center">
                                    Contract awaiting signature by client.
                                </td>
                                @elseif($item->status == 'awaiting_jim_signature')
                                <td class="text-center">
                                    Contract awaiting signature by RNN.
                                </td>
                                @elseif($item->status == 'awaiting_client_changes')
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">Upload Client Changes</a>
                                </td>
                                @elseif($item->status == 'awaiting_legal_approval')
                                <td class="text-center">
                                    Awaiting Legal Approval
                                </td>
                                @elseif($item->status == 'changes_requested')
                                <td class="text-center">
                                    Changes Requested
                                </td>
                                @elseif($item->status == 'awaiting_product_selection')
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">Select Final Products</a>
                                </td>
                                @else
                                <td class="text-center">
                                    Unknown status
                                </td>
                                @endif
                                <td class="text-center">
                                    <button class="btn btn-danger" style="width:100%; color:white;"
                                        onclick="archiveContract({{$item->id}})">
                                        Archive
                                    </button>
                                </td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader3" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<br>
<hr>
<br>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Contracts Complete:</p>
            </div>

        </div>
    </div>
</section>
<section id="upload-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive">
                <div id="contracts-parent" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="contracts-table">
                        <thead>
                            <tr>
                                <th class="text-center">Contract Number</th>
                                <th class="text-center">Client ID</th>
                                <th class="text-center">Company Name</th>
                                <th class="text-center">Created Date</th>
                                <th class="text-center">Contract Type</th>
                                <th class="text-center">Send Contract</th>
                                <th class="text-center">Download</th>
                                <th class="text-center">History</th>
                                <th class="text-center">Next Action</th>
                                <th class="text-center">Archive</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($contracts as $item)
                            @if($item->is_archived != 1 && $item->status == 'complete' && $item->contract_type != "ICA")
                            <?php
                                $redirect = '';
                                if ($item->client_id != null)
                                    $redirect = route('editClient', $item->client_id);
                                elseif ($item->contract_type != "ICA")
                                    $redirect = route('findClient', $item->company_name);

                                $name_options = "";
                                if(isset($item->account_payable_name)) {
                                    $name_options .= "<br>" . $item->account_payable_name;
                                }
                                if(isset($item->invoice_approver_name)) {
                                    $name_options .= "<br>" . $item->invoice_approver_name;
                                }
                                if(isset($item->executive_contact_name)) {
                                    $name_options .= "<br>" . $item->executive_contact_name;
                                }

                            ?>
                            <tr class="item{{$item->id}}">
                                <td>{{$item->id}}</td>
                                <td>@if($item->client_id == NULL)
                                    N/A
                                    @else
                                    {{$item->client_id}}
                                    @endif
                                </td>
                                <td>
                                    @if($redirect != '')
                                    <a href="{{ $redirect }}">
                                        {{$item->company_name}}
                                    </a>
                                    @else
                                    {{$item->company_name}}
                                    @endif
                                </td>
                                <td>{{substr($item->created_at, 0, 10)}}</td>
                                <td>{{$item->contract_type}}</td>
                                <td class="text-center">
                                    @if($item->status == 'converting')
                                    Converting
                                    @elseif($item->approval_needed == 1)
                                    Awaiting Approval
                                    @elseif($item->contract_type == "REDLINE")
                                    Docusign not implemented for redline
                                    @elseif($item->status == 'complete')
                                    Contract Complete
                                    @elseif($item->company_email == NULL)
                                    No Email with Contract
                                    @elseif($item->status == 'awaiting_all_signature')
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="resendContract({{$item->id}}, 'jimv@rnngroup.com and ' + '{{$item->docusign_email == null ? $item->company_email : $item->docusign_email}}')">
                                        Resend
                                    </button>
                                    @elseif($item->status == 'awaiting_client_signature')
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="resendContract({{$item->id}}, '{{$item->docusign_email == null ? $item->company_email : $item->docusign_email}}')">
                                        Resend
                                    </button>
                                    @elseif($item->status == 'awaiting_jim_signature')
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="resendContract({{$item->id}}, 'jimv@rnngroup.com')">
                                        Resend
                                    </button>
                                    @else
                                    <button class="btn btn-primary" style="width:100%; color:white;"
                                        onclick="sendContract({{$item->id}}, '{{$item->company_email}}', '{{$name_options}}')">
                                        Send
                                    </button>
                                    @endif
                                </td>
                                @if($item->approval_needed == 1)
                                <td class="text-center">Awaiting Approval</td>
                                @elseif($item->status == 'converting')
                                <td class="text-center">Converting</td>
                                @else
                                <td class="text-center">
                                    <a href="{{route('download', $item->contract_name)}}">
                                        <div style="height:100%;width:100%">
                                            Download
                                        </div>
                                    </a>
                                </td>
                                @endif
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">History</a>
                                </td>
                                @if($item->status == 'converting')
                                <td class="text-center">
                                    Converting
                                </td>
                                @elseif($item->status == 'awaiting_manager_approval')
                                <td class="text-center">
                                    Awaiting Approval by Manager
                                </td>
                                @elseif($item->status == 'awaiting_jim_approval')
                                <td class="text-center">
                                    Awaiting Approval by Jim
                                </td>
                                @elseif($item->status == 'awaiting_final_upload')
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">Upload Final Contract</a>
                                </td>
                                @elseif($item->status == 'complete')
                                <td class="text-center">
                                    None
                                </td>
                                @elseif($item->status == 'awaiting_all_signature')
                                <td class="text-center">
                                    Contract awaiting signatures by client and RNN.
                                </td>
                                @elseif($item->status == 'awaiting_client_signature')
                                <td class="text-center">
                                    Contract awaiting signature by client.
                                </td>
                                @elseif($item->status == 'awaiting_jim_signature')
                                <td class="text-center">
                                    Contract awaiting signature by RNN.
                                </td>
                                @elseif($item->status == 'awaiting_client_changes')
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">Upload Client Changes</a>
                                </td>
                                @elseif($item->status == 'awaiting_legal_approval')
                                <td class="text-center">
                                    Awaiting Legal Approval
                                </td>
                                @elseif($item->status == 'changes_requested')
                                <td class="text-center">
                                    Changes Requested
                                </td>
                                @elseif($item->status == 'awaiting_product_selection')
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">Select Final Products</a>
                                </td>
                                @else
                                <td class="text-center">
                                    Unknown status
                                </td>
                                @endif
                                <td class="text-center">
                                    <button class="btn btn-danger" style="width:100%; color:white;"
                                        onclick="archiveContract({{$item->id}})">
                                        Archive
                                    </button>
                                </td>
                            </tr>
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<br>
<hr>
<br>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Archived Contracts:</p>
            </div>
        </div>
    </div>
</section>
<section id="upload-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive">
                <div id="archived-parent" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="archived-contracts-table">
                        <thead>
                            <tr>
                                <th class="text-center">Contract Number</th>
                                <th class="text-center">Client ID</th>
                                <th class="text-center">Company Name</th>
                                <th class="text-center">Created Date</th>
                                <th class="text-center">Contract Type</th>
                                <th class="text-center">Download</th>
                                <th class="text-center">History</th>
                                <th class="text-center">Un-Archive</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($contracts as $item)
                            @if($item->is_archived == 1 && $item->contract_type != "ICA")
                            <?php
                                $redirect = '';
                                if ($item->client_id != null)
                                    $redirect = route('editClient', $item->client_id);
                                elseif ($item->contract_type != "ICA")
                                    $redirect = route('findClient', $item->company_name);
                            ?>
                            <tr class="item{{$item->id}}">
                                <td>{{$item->id}}</td>
                                <td>@if($item->client_id == NULL)
                                    N/A
                                    @else
                                    {{$item->client_id}}
                                    @endif
                                </td>
                                <td>
                                    @if($redirect != '')
                                    <a href="{{ $redirect }}">
                                        {{$item->company_name}}
                                    </a>
                                    @else
                                    {{$item->company_name}}
                                    @endif
                                </td>
                                <td>{{substr($item->created_at, 0, 10)}}</td>
                                <td>{{$item->contract_type}}</td>
                                @if($item->approval_needed == 1)
                                <td class="text-center">Awaiting Approval</td>
                                @elseif($item->status == 'converting')
                                <td class="text-center">Converting</td>
                                @else
                                <td class="text-center">
                                    <a href="{{route('download', $item->contract_name)}}">
                                        <div style="height:100%;width:100%">
                                            Download
                                        </div>
                                    </a>
                                </td>
                                @endif
                                <td class="text-center">
                                    <a href="{{route('manageContract',$item->id)}}" class="btn btn-primary btn-sm"
                                        role="button">History</a>
                                </td>
                                <td class="text-center">
                                    <button class="btn btn-danger" style="color:white;"
                                        onclick="unarchiveContract({{$item->id}})">
                                        Unarchive
                                    </button>
                                </td>
                            </tr>
                            @endif()
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader2" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script src="{{asset('js/modal.js?'.time())}}"></script>

<script>
    $(document).ready(function() {
    $('#contracts-table-pending').DataTable({
        "order":[[0,"desc"]],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader3').delay(25).fadeOut();
            $('#contracts-pending-parent').removeClass('table-parent-hidden');
        }
    });
  });

$(document).ready(function() {
    $('#contracts-table').DataTable({
        "order":[[0,"desc"]],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#contracts-parent').removeClass('table-parent-hidden');
        }
    });
  });

$(document).ready(function() {
    $('#archived-contracts-table').DataTable({
        "order":[[0,"desc"]],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader2').delay(25).fadeOut();
            $('#archived-parent').removeClass('table-parent-hidden');
        }
    });
  });
</script>

@endsection
