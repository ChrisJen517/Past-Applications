<link href="{{asset('plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
    type="text/css">
<link href="{{asset('plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('plugins\bootstrap-datatable\css\rowReorder.dataTables.min.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css"
    integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="google" content="notranslate">
    <title>Contract Portal 2.0</title>

    <!-- Bootstrap core CSS-->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="{{asset('css/datatable.css?'.time())}}" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="{{asset('css/sidebar-top.css?'.time())}}" rel="stylesheet" />
    <!-- Icons CSS-->
    <link href="{{asset('css/icons.css')}}" rel="stylesheet" type="text/css" />

    <!-- Styling CSS-->
    <link href="{{asset('/css/style-test.css')}}" rel="stylesheet" />
</head>

<header class="topbar-nav">
    <nav class="navbar navbar-expand fixed-top bg-topbar" style="height:80px">
        <ul class="navbar-nav mr-auto align-items-left">
            <a href="{{asset('/')}}">
                <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon" style="size: 60%">   
            </a>  
        </ul>
        <ul class="navbar-nav align-items-center right-nav-link" style="padding-right: 5%">
            <a href="{{asset('/')}}">
                @if(empty(Auth::user()))
                    Login 
                @else
                    Dashboard
                @endif
            </a> 
        </ul>
    </nav>
</header>

<!-- Main Content -->
<div class="content-wrapper" style="margin-left: 5px">
    <div class="container-fluid">
        <br>
        @include('Includes.messages')
            <div class="container-fluid">
                <div class="row text-left">
                    <div class="col text-center">
                        <section id="previous-uploads-header">
                            Review Purchase Request
                        </section>

                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 offset-lg-3 text-right">
                        <p>
                            Submitted By: 
                            <br>Amount:
                            @if($purchase_request->website)<br>Website:@endif
                            <br>Description:
                            <br>Business Justification:
                        </p>
                    </div>
                    <div class="col-lg-6 text-left">
                        <p>
                            {{$submitter->name_first . ' ' . $submitter->name_last}}
                            <br>{{'$'.$purchase_request->amount.' '.($purchase_request->frequency == "Other" ? $purchase_request->other : $purchase_request->frequency)}}
                            @if($purchase_request->website)<br><a href="{{$purchase_request->website}}">{{$purchase_request->website}}</a>@endif
                            <br>{{$purchase_request->description}}
                            <br>{{$purchase_request->justification}}
                        </p>
                    </div>
                </div>
                <hr>
                <div class="row">
                    <div class="offset-lg-2 col-lg-8 text-center">
                        <form action="{{ route('reviewPurchaseRequest-submit') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                            <div class="form-group row">
                                <label class="col-lg-3 col-form-label form-control-label">Comment</label>
                                <div class="col-lg-9">
                                    <textarea class="form-control" name="comment" type="text" placeholder="Reason is required to request changes"></textarea>
                                    <br>
                                    <button class="btn btn-lg btn-danger float-left" type="submit" name="submit" value="denied">Deny</button>
                                    <button class="btn btn-lg btn-warning float-middle" type="submit" name="submit" value="changes_requested">Request Changes</button>
                                    <button class="btn btn-lg btn-success float-right" type="submit" name="submit" value="approved">Approve</button>
                                </div>
                            </div>
                            <input hidden name="request_id" value="{{$purchase_request->id}}">
                            <input hidden name="type" value="{{$type}}">
                        </form>
                    </div>
                </div>
            </div>
        <br>
    </div>
</div>