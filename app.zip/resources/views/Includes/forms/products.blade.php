<div class="row">
    @foreach($product_headers as $item)
    @if($item->name != 'Archived' && ($item->show_in_list == 1 || Auth::user()->role == 'manager'))
    <div class="card" style="width:48%; margin:1%;">
        <div class="card-body">
            <div class="row">
                <div class="col-md-9">
                    <h4 class="mb-0">{{$item->name}}</h4>
                </div>
                <div class="col-md-2">
                    <button href="#" class="btn btn-primary btn-sm product-button" type="text" id="pc-btn-{{$item->id}}"
                        data-enabled="true" value="{{$item->id}}" style="color: white; display:none;">Select
                        All</button>
                </div>
            </div>
            <hr>

            <div class="form-check">
                <input class="pc-box" type="checkbox" data-pc={{$item->id}} name="parent" id="pc-{{$item->id}}">
                {{$item->name}}
                <ul style="list-style: none; padding-left: 0;" id="pc-ul-{{$item->id}}">
                    @php($i = 0)
                    @foreach($products as $product)
                    @if($item->id == $product->product_header_id && ($product->show_in_list == 1 || Auth::user()->role
                    == 'manager'))
                    <li id="pc-li-{{$item->id}}">
                        <div class="form-check">
                            <div class="row" id="pc-row-{{$item->id}}">
                                <div class="col-md-9">
                                    <input class="cc-box" type="checkbox" name="VPOE" id="{{$item->id}}"
                                        data-quote="{{$product->use_quote}}" disabled>
                                    {{$product->name}}
                                </div>
                                <div class="col-md-3">
                                    <?php
                                    $price = $product->price;
                                    $price = (float) $price;
                                    if ($price <= 10 || fmod($price, 1) !== 0.0) {
                                        if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                                            $price = number_format($price, 2);
                                        }
                                    }
                                    ?>
                                    @if($product->use_quote == 1)
                                    <input class="col float-right" id="price{{$product->id}}" name="price[{{$i}}]"
                                        type="text" value="{{$product->quote}}" disabled>
                                    <input hidden class="form-control" name="use_quote[]" id="use_quote" type="text"
                                        value="1" disabled>
                                    @else
                                    <input class="col float-right" id="price{{$product->id}}" step="0.01"
                                        name="price[{{$i}}]" type="number" value="{{$price}}" disabled>
                                    <input hidden class="form-control" name="use_quote[]" id="use_quote" type="text"
                                        value="0" disabled>
                                    @endif
                                    <input hidden class="form-control" name="originalPrice[]"
                                        value="{{$product->price}}" placeholder="originalPrice" disabled>
                                    <input hidden class="form-control" name="managerPrice[]"
                                        value="{{$product->manager_price_1}}" placeholder="managerPrice" disabled>
                                    <input hidden class="form-control" name="jimPrice[]"
                                        value="{{$product->manager_price_2}}" placeholder="jimPrice" disabled>
                                    <input hidden class="form-control" name="name[]" value="{{$product->name}}"
                                        placeholder="{{$product->name}}" disabled>
                                    <input hidden class="form-control" name="id[]" value="{{$product->id}}"
                                        placeholder="{{$product->id}}" disabled>
                                    <input hidden class="form-control" name="prod_header_id[]"
                                        value="{{$product->product_header_id}}"
                                        placeholder="{{$product->product_header_id}}" disabled>
                                    <input hidden class="form-control" name="reason[]" value="" placeholder="" disabled>
                                    <textarea hidden class="form-control" name="description[]"
                                        value="{{$product->description}}" placeholder="{{$product->description}}"
                                        disabled>{{$product->description}}</textarea>
                                    <input hidden class="form-control" name="price_name[]"
                                        value="{{$product->pricing_name}}" placeholder="{{$product->pricing_name}}"
                                        disabled>
                                    <input hidden class="form-control" name="batch_code[]"
                                        value="{{$product->batch_code}}" placeholder="{{$product->batch_code}}"
                                        disabled>
                                    <input hidden class="form-control" name="vast_code[]"
                                        value="{{$product->vast_code}}" placeholder="{{$product->vast_code}}" disabled>
                                    <input hidden class="form-control" name="sla[]" value="{{$product->sla}}"
                                        placeholder="{{$product->sla}}" disabled>
                                </div>
                            </div>
                        </div>
                    </li>
                    @endif
                    @php($i++)
                    @endforeach
            </div>
        </div>
        </ul>
    </div>
    @endif
    @endforeach
</div>
