<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
    <div class="brand-logo text-center">
        <a href="{{asset('/manager/dashboard')}}">
            <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon">
        </a>
    </div>
    <ul class="sidebar-menu do-nicescroll">
        <li class="sidebar-header">MAIN NAVIGATION</li>
        <li>
            <a href="{{asset('/manager/dashboard')}}" class="waves-effect">
                <i class="icon-home"></i> <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="/supportDocuments" class="waves-effect">
                <i class="far fa-folder"></i> <span>Document Repository</span>
            </a>
        </li>
        <li>
            <a href="/manageUsers" class="waves-effect">
                <i class="fa fa-address-book"></i> <span>Manage Users</span>
            </a>
        </li>
        <li>
            <a href="/manageProductSheet" class="waves-effect">
                <i class="fab fa-product-hunt"></i> <span>Manage Products</span>
            </a>
        </li>
        <li>
            <a href="/manageClients" class="waves-effect">
                <i class="fa fa-address-book"></i> <span>Manage Clients / Vendors</span>
            </a>
        </li>
        <li>
            <a href="{{asset('/showLeads')}}" class="waves-effect">
                <i class="fas fa-headset"></i> <span>Show Leads</span>
            </a>
        </li>
        <li>
            <a href="{{asset('/salesLeadStats')}}" class="waves-effect">
                <i class="fas fa-shield-alt"></i> <span>Lead Statistics</span>
            </a>
        </li>

        <li>
            <a href="{{asset('/productSheet')}}" class="waves-effect">
                <i class="fas fa-file-contract"></i> <span>Create Product Sheet</span>
            </a>
        </li>
        <li>
            <a href="/NVN" class="waves-effect">
                <i class="fas fa-stamp"></i> <span>NVN Report</span>
            </a>
        </li>
        <li>
            <a href="javaScript:void();" class="waves-effect">
                <i class="fas fa-file-signature"></i>
                <span>Generate Contract</span><i class="fa fa-angle-right pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="{{ asset('/MSA') }}"><i class="fa fa-circle-o"></i>Standard FCRA MSA</a></li>
                <li><a href="{{ asset('/MSA_No_FCRA') }}"><i class="fa fa-circle-o"></i>Non FCRA MSA</a></li>
                <li><a href="{{ asset('/MSA_Amendment') }}"><i class="fa fa-circle-o"></i>MSA Amendment</a></li>
                <li><a href="{{ asset('/FCRA') }}"><i class="fa fa-circle-o"></i>FCRA Amendment</a></li>
                <li><a href="{{ asset('/You-Negotiate') }}"><i class="fa fa-circle-o"></i>You-Negotiate</a></li>
                <li><a href="{{ asset('/YNAmendment') }}"><i class="fa fa-circle-o"></i>YN Amendment</a></li>
                @if(Auth::user()->is_admin == 1)
                    <li><a href="{{ asset('/ResellerAgreement') }}"><i class="fa fa-circle-o"></i>YN Reseller Agreement</a></li>
                @endif
                <li><a href="{{ asset('/RedlineStart') }}"><i class="fa fa-circle-o"></i>Redline</a></li>
                <li><a href="{{ asset('/NDA') }}"><i class="fa fa-circle-o"></i>NDA</a></li>
                <li><a href="{{ asset('/ICA') }}"><i class="fa fa-circle-o"></i>Independent Contractor <span style="margin-left:30px">Agreement</span></a></li>
                <li><a href="{{ asset('/CertFCRA') }}"><i class="fa fa-circle-o"></i>Certification of FCRA <span style="margin-left:30px">Collection</span></a></li>
                <li><a href="{{ asset('/Name_Change_Amendment') }}"><i class="fa fa-circle-o"></i>Name Change <span style="margin-left:30px">Amendment</span></a></li>
            </ul>
        </li>
        <li>
            <a href="/audits" class="waves-effect">
                <i class="fa fa-folder-open"></i> <span>Client Audits</span>
            </a>
        </li>
        <li>
            <a href="{{asset('/RequestForm')}}" class="waves-effect">
                <i  class="fa fa-credit-card-alt" aria-hidden="true"></i> <span>Request Form</span>
            </a>
        </li>
    </ul>
</div>

<div id="sidebar-wrapper-icons">
    <div class="brand-logo text-center small-bar">
        <a href="{{asset('/dashboard')}}" class="small-image-wrapper">
            <img src="/images/Small-R.png" class="logo-icon" alt="logo icon">
        </a>
    </div>
    <ul class="sidebar-menu do-nicescroll" style="margin-top: 10px;">
        {{-- Dashboard --}}
        <li>
            <a href="/" class="nav-link waves-effect">
                <i class="icon-home"></i>
            </a>
        </li>
        <li>
            <a href="/supportDocuments" class="nav-link waves-effect">
                <i class="far fa-folder"></i>
            </a>
        </li>
        {{-- Directory Manager --}}
        <li>
            <a href="/manageUsers" class="nav-link waves-effect">
                <i class="fa fa-address-book"></i>
            </a>
        </li>
        <li>
            <a href="/manageProductSheet" class="waves-effect">
                <i class="fab fa-product-hunt"></i>
            </a>
        </li>
        <li>
            <a href="{{asset('/manageClients')}}" class="nav-link waves-effect">
                <i class="fa fa-address-book"></i>
            </a>
        </li>
        <li>
            <a href="{{asset('/showLeads')}}" class="waves-effect">
                <i class="fas fa-headset"></i>
            </a>
        </li>
        <li>
            <a href="{{asset('/salesLeadStats')}}" class="waves-effect">
                <i class="fas fa-shield-alt"></i>
            </a>
        </li>
        <li>
            <a href="/NVN" class="waves-effect">
                <i class="fas fa-stamp"></i>
            </a>
        </li>
        <li>
            <a href="javaScript:void();" class="waves-effect">
                <i class="fas fa-file-signature "></i>
                <i class="fa fa-angle-right float-right"></i>
            </a>
            <ul class="sidebar-submenu sidebar-submenu-icons">
                <li><a href="{{ asset('/MSA') }}">Standard FCRA MSA</a></li>
                <li><a href="{{ asset('/MSA_No_FCRA') }}">Non FCRA MSA</a></li>
                <li><a href="{{ asset('/MSA_Amendment') }}">MSA Amendment</a></li>
                <li><a href="{{ asset('/productSheet') }}">Product Sheet</a></li>
                <li><a href="{{ asset('/You-Negotiate') }}">You-Negotiate</a></li>
                <li><a href="{{ asset('/YNAmendment') }}">YN Amendment</a></li>
                @if(Auth::user()->is_admin == 1)
                    <li><a href="{{ asset('/ResellerAgreement') }}">YN Reseller Agreement</a></li>
                @endif
                <li><a href="{{ asset('/RedlineStart') }}">Redline</a></li>
                <li><a href="{{ asset('/FCRA') }}">FCRA</a></li>
                <li><a href="{{ asset('/NDA') }}">NDA</a></li>
                <li><a href="{{ asset('/ICA') }}">Independent Contractor Agreement</a></li>
                <li><a href="{{ asset('/CertFCRA') }}">Certification of FCRA <span style="margin-left:30px">Collection</span></a></li>
                <li><a href="{{ asset('/Name_Change_Amendment') }}">Name Change <span style="margin-left:30px">Amendment</span></a></li>
            </ul>
        </li>
        <li>
            <a href="/audits" class="waves-effect">
                <i class="fa fa-folder-open"></i>
            </a>
        </li>
        <li>
            <a href="{{asset('/RequestForm')}}" class="waves-effect">
                <i  class="fa fa-credit-card-alt" aria-hidden="true"></i>
            </a>
        </li>
    </ul>
</div>

<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{asset('js/popper.min.js')}}"></script>
<script src="{{asset('js/bootstrap.min.js')}}"></script>
<script src="{{asset('/plugins/simplebar/js/simplebar.js')}}"></script>
<!-- sidebar-menu js -->
<script src="{{asset('js/sidebar-menu.js')}}"></script>
