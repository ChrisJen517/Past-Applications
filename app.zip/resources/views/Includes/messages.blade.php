<!--catches the validation errors-->
@if(count($errors) > 0)
    @foreach($errors->all() as $error)
        <div class="alert alert-danger">
            {{$error}}
        </div>
    @endforeach
@endif

@isset($success)
<div class="alert alert-success message">
            {{$success}}
        </div>
@endisset

<!--catches the success messages-->
@if (session('success'))
        <div class="alert alert-success message">
            {{session('success')}}
        </div>
@endif

<!--catches the errors we create-->
@if (session('error'))
    <div class="alert alert-danger message">
        {{session('error')}}
    </div>
@endif

<!--catches the messages-->
@if(session()->has('message'))
    <div class="alert alert-success message">
        {{ session()->get('message') }}
    </div>
@endif

@if(session('information'))
<script>
  $(document).ready(function() {
    $.toast({
        heading: 'Information',
        text: "{{ session('information') }}",
        showHideTransition: 'slide',
        icon: 'info',
        hideAfter: 30000,
        position: 'bottom-right'
    })
  });
</script>
@endif

@if(session('successToast'))
<script>
  $(document).ready(function() {
    $.toast({
        heading: 'Success',
        text: "{{ session('successToast') }}",
        showHideTransition: 'slide',
        icon: 'success',
        hideAfter: 30000,
        position: 'bottom-right'
    })
  });
</script>
@endif

@if(session('errorToast'))
<script>
  $(document).ready(function() {
    $.toast({
        heading: 'Error',
        text: "{{ session('errorToast') }}",
        showHideTransition: 'slide',
        icon: 'error',
        hideAfter: 30000,
        position: 'bottom-right'
    })
  });
</script>
@endif