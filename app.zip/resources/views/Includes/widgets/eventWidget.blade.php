<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/form.css?'.time()) }}" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.css" rel="stylesheet">

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link custom-nav-link active" data-toggle="tab" href="#my-activity" style="border-radius: .2rem 0 0 0;">My Activity</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link custom-nav-link" data-toggle="tab" href="#new-task" style="border-radius: .2rem 0 0 0;">Next Step</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div id="my-activity" class="container tab-pane active">
                    <div class="options" style="font-size: 12px;">
                        <span>  [  </span>
                        <a href="#" class="expand-all">Expand All</a>
                        <span>  |  </span>
                        <a href="#" class="view-all">View All</a>
                        <span>  |  </span>
                        <a href="#" class="hide-all">Hide All</a>
                        <span>  ]  </span>
                    </div>
                    @foreach($activities as $activity => $values)
                        <a class="btn btn-activity" @if(empty($values)) style="display: none;" @endif data-toggle="collapse" href="#{{str_replace(' ', '_', $activity)}}" role="button" aria-expanded="true" aria-controls="{{str_replace(' ', '_', $activity)}}"><i class="fa fa-custom-drop float-left" style="font-size: 20px; color: dodgerblue;"></i>{{$activity}}</a>
                        <div class="collapse show" id="{{str_replace(' ', '_', $activity)}}" data-role="group">
                            <div class="events" style="padding:0px 10px 5px 10px;">
                                @foreach($values as $value)
                                <div class="event" id="event-{{$value->id}}">
                                    <div class="row" style="margin-top: 5px;">
                                        <div class="col-md-1">
                                            @if ($value->type != 'note')
                                            <a data-toggle="collapse" class="collapsed inner-collapse" href="#activity{{$value->id}}" role="button" aria-expanded="true" aria-controls="activity{{$value->id}}"><i class="fa fa-custom-note float-left" style="font-size: 20px; color: black;"></i></a>
                                            @endif
                                        </div>
                                        <div class="col-md-1 text-center">

                                            @if($activity == 'Upcoming and Overdue')
                                                @php ($color = "#cd5c5c")
                                                @if($value->type == 'task' && $value->is_complete == '0')
                                                    {{-- @php ($color = "#d4af37") --}}
                                                    @php ($icon = "far fa-file-excel")
                                                @else
                                                    {{-- @php ($color = "#cd5c5c") --}}
                                                    @php ($icon = "far fa-calendar-times")
                                                @endif
                                            @else
                                                @php ($color = "#228b22")
                                                @if($value->type == 'task')
                                                    {{-- @php ($color = "#20b2aa") --}}
                                                    @php ($icon = "fas fa-tasks")
                                                @elseif ($value->type == 'note')
                                                    @if(!empty($value->attachment))
                                                        @php ($icon = "fas fa-paperclip")
                                                        @php ($color = "#007bff")
                                                    @else
                                                        @php ($icon = "far fa-sticky-note")
                                                    @endif
                                                @else
                                                    {{-- @php ($color = "#228b22") --}}
                                                    @php ($icon = "far fa-calendar-check")
                                                @endif
                                            @endif
                                            @if(!empty($value->attachment))
                                            <a href="{{route('download', $value->attachment)}}">
                                                <i class="fas fa-paperclip" id="custom-icon-color" style="font-size: 15px; color: {{$color}}"></i>
                                            </a>
                                            @else
                                            <i class="{{$icon}}" id="custom-icon-color" style="font-size: 15px; color: {{$color}}"></i>
                                            @endif
                                        </div>
                                        <div class="col-md-7">
                                            @if((isset($value->description)))
                                            <a tabindex="0" class="custom-popover" role="button" data-container="body" data-toggle="popover" data-placement="top" data-trigger="focus" data-title="Description" data-content="{{$value->description}}" style="font-size:14px; margin-bottom: 0px;">
                                            @endif
                                            <p @if(isset($value->description)) class="float-left has-description" @else class="float-left" @endif style="font-size:14px; margin-bottom: 0px;">
                                            @if($value->type == 'task' && $value->is_complete == '0')
                                            <input type="checkbox" id="mark-completed" data-id="{{$value->id}}" title="Mark Complete">
                                            @endif
                                            {{$value->subject}}
                                            @if ($value->attachment != '')
                                            <a href="{{route('download', $value->attachment)}}">
                                                <i class="fas fa-paperclip"></i>
                                            </a>
                                            @endif
                                            </p>
                                            @if((isset($value->description)))
                                            </a>
                                            @endif
                                        </div>
                                        <div class="col-md-3">
                                            <span class="float-right" style="font-size:10px;">{{date_create_from_format('Y-m-d H:i:s', $value->dateDue)->format('M d Y')}}</span>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-1 offset-md-1">
                                            <div class="line-vertical mx-auto" id="custom-bg-color" style="background-color: {{$color}}"></div>
                                        </div>
                                        <div class="col-md-10">
                                            <span class="float-left" style="font-size: 10px;">
                                                {{$value->agent_name}} created a next step.
                                            </span>
                                        </div>
                                    </div>
                                    @if ($value->type != 'note')
                                    <div class="collapse" id="activity{{$value->id}}" data-role="notes">
                                        <div class="row">
                                            <div class="col-md-1 offset-md-1">
                                                <div class="line-vertical mx-auto" id="custom-bg-color" style="background-color: {{$color}}"></div>
                                            </div>
                                            <div class="col-md-10" style="margin-top: 10px;">
                                                <div class="card" style="background-color: #ebebeb;">
                                                    <div class="card-header note-header" style="background-color: #ebebeb;">
                                                        <span style="color: dodgerblue;">Notes</span>
                                                    </div>
                                                    <div class="card-body" style="padding: 0px 10px 10px 10px;">
                                                        <div class="row">
                                                            <div class="col-md-12" id="append-note">
                                                                @foreach($value->notes as $note)
                                                                <span style="font-size: 14px;">{{$note->note}}</span>
                                                                <br>
                                                                <span style="font-size: 10px; color: dodgerblue;">{{$note->agent_name}} - {{date_create_from_format('Y-m-d H:i:s', $note->created_at)->format('M d Y')}}</span>
                                                                <br><br>
                                                                @endforeach
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <button id="add-note-button" data-activityref="{{$value->id}}" data-agentref="{{Auth::user()->id}}" class="btn btn-primary btn-sm float-right ml-auto notes-{{$value->id}}" style="margin: -20px 0px 20px 0px;">Add Note</button>
                                            </div>
                                        </div>
                                    </div>
                                    @endif
                                </div>
                                @endforeach
                            </div>
                        </div>
                    @endforeach
                </div>
                <div id="new-task" class="container tab-pane"><br>
                    <form action="{{route('createNextStep', '1')}}" method="POST" id="createNextStep" enctype="multipart/form-data">
                        <div class="form-group row">
                            <input type="text" id="lead_reference_id" name="lead_reference_id" value="{{$lead->id}}" hidden>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Subject<span class="required">*</span></span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-info form-icon"></i>
                                <select class="form-control input-field" id="subject" name="subject" value="{{old('subject')}}" placeholder="" required>
                                    <option value="" selected disabled>Select a Subject</option>
                                    @foreach ($subjects as $subject)
                                    <option value="{{$subject}}">{{$subject}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Agenda</span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container-area">
                                <i class="fas fa-comment form-icon"></i>
                                <textarea rows="5" style="resize: none;" class="form-control input-field" id="description" name="description" value="{{old('description')}}" placeholder=""></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Date<span class="required">*</span></span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="far fa-calendar-plus form-icon"></i>
                                <input class="form-control input-field" id="datetimepicker3" name="date" value="{{old('date')}}" placeholder="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Assigned To<span class="required">*</span></span>
                                <i class="fas fa-check form-icon-added" style="display: show;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-user-edit form-icon"></i>
                                <select class="form-control input-field multiple-select-agents" id="assigned_to[]" value="{{$lead->agent_id}}" name="assigned_to[]" multiple>
                                    @foreach($agents as $agent)
                                    <option value="{{$agent->id}}" @if($agent->id == $lead->agent_id) selected readonly @endif>{{$agent->name_first . ' ' . $agent->name_last}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Contact(s)</span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-user form-icon"></i>
                                <select class="form-control input-field multiple-select-contacts" id="contacts[]" name="contacts[]" data-width:"100%" multiple>
                                    @foreach($lead_contacts as $contact)
                                    <option value="{{$contact->id}}">[{{$contact->lead_title}}] {{$contact->first_name . ' ' . $contact->last_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="form-group row" style="display: none;">
                            <div class="form-label">
                                <span>Location</span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-map-marked-alt form-icon"></i>
                                <input class="form-control input-field" id="location" name="location" value="{{old('location')}}" placeholder="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Related To</span>
                                <i class="fas fa-check form-icon-added" style="display: show;"></i>
                            </div>
                            <div class="input-container">
                                <i class="far fa-building form-icon"></i>
                                <input class="form-control input-field" id="related_to" name="related_to" value="{{$lead->company_name}}" placeholder="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <button type="submit" name="submit" id="submit-button-1" value="submit" class="btn btn-success btn-lg ml-auto">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.multiple-select-agents').select2({
        placeholder: 'Select Agent(s)'
    });

    $('.multiple-select-contacts').select2({
        placeholder: 'Select Contact(s)'
    });

    var userId = "{{$lead->agent_id}}";
    var salesAgent = "{{$lead->sales_agent}}";

    var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
    $(selectItem).remove();

    $('.multiple-select-agents').on('select2:unselecting', function(event) {
        var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
        $(selectItem).remove();

        if (event.params.args.data.id == userId) {
            event.preventDefault();
        }
    });

    $('.multiple-select-agents').on('select2:unselect', function(event) {
        var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
        $(selectItem).remove();
    });

    $('.multiple-select-agents').on('select2:select', function(event) {
        var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
        $(selectItem).remove();
    });

    $('.custom-popover').popover({
        trigger: 'focus'
    });

    var dateToday = new Date();
    dateToday.setMinutes(dateToday.getMinutes() - 15);
    $('#datetimepicker3').datetimepicker({
        controlType: 'select',
        oneLine: true,
        timeFormat: 'HH:mm',
        minDate: dateToday
    });

    $('.input-field').change(function() {
        if ($(this).data('iconid'))
            var icon = $('#' + $(this).data('iconid'));
        else
            var icon = $(this).closest('.form-group').find('.form-icon-added');

        if (icon.length > 0) {
            if($.trim($(this).val())) $(icon).show();
            else $(icon).hide();
        }

        if ($(this).attr('id') == "subject") {
            if ($(this).val() == "ONSITE MEETING")
                $('#location').closest('.form-group').show();
            else
                $('#location').closest('.form-group').hide();
        }
    });

    $('#createNextStep').submit(function(e) {
        e.preventDefault();
        if(!$(this).valid()) return;
        var form = $(this);
        var form_data = new FormData(form[0]);
        var url = form.attr('action');
        swal.fire({
            title: "Are you sure?",
            text: "You are about to create a next step.",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Create"
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: url,
                        data: form_data,
                        processData: false,
                        contentType: false
                    }).then(function(data) {
                        form.trigger("reset");
                        $.LoadingOverlay('hide');
                        swal.fire(
                            "Success",
                            "Successfully created a next step.",
                            "success"
                        );
                        renderWidget();
                    });
                });
            } else {
                swal.fire("Cancelled", "Next step was not created!", "error");
            }
        });
    });

    $('#createNextStep').on('reset', function() {
        $(this).find('.hide-on-reset').hide();
    });

    $(".custom-file").on("change", function() {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index).toLowerCase();
            if (fileSize > 1502500) {
                swal.fire({
                    title: "File size too large!",
                    text: "Attachment size cannot exceed 1.5MB",
                    icon: "warning"
                })

                $(this).val("");
            }

            if ($(this).val() != "") {
                var fileName = $(this).val().split("\\").pop();
            }
        }
    });

    $.validator.setDefaults({
        errorPlacement: function(error, element) {
            if (element.hasClass("form-control")) {
                error.insertAfter(element.parent());
            }
        }
    });

    $.validator.addMethod("minDate", function (value, element) {
                    var minDate = new Date();
                    minDate.setMinutes(minDate.getMinutes() - 20);
                    var valueEntered = Date.parse(value);
                    if (valueEntered < minDate) return false;
                    return true;
                },
                "The date can not be set to a past value"
    );

    $.validator.addMethod("validDate", function (value, element) {
                    var valueEntered = Date.parse(value);
                    if (valueEntered == null || isNaN(valueEntered)) return false;
                    return true;
                },
                "Invalid date format"
    );

    $('#createNextStep').validate({
        rules: {
            subject: {
                required: true
            },
            date: {
                required: true,
                validDate: true,
                minDate: true
            }
        }
    });

    $(document).on('click', '#add-note-button', function(e) {
        e.preventDefault();
        var btn = $(this);
        var activity_reference_id = btn.data('activityref');
        var agent_reference_id = btn.data('agentref');
        var find = btn.parent().find('#append-note');
        var url = "/createNewEventNote";
        swal.fire({
                title: 'Submit a note:',
                input: 'textarea',
                inputAttributes: {
                    autocapitalize: 'off',
                    'aria-label': 'Type your message here'
                },
                inputPlaceholder: 'Type your message here...',
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: 'Add Note'
        }).then(note => {
            if (note.value) {
                note.value = note.value.replace(/<[^>]*>/g, '');
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post(url, {
                        activity_reference_id: activity_reference_id,
                        agent_reference_id: agent_reference_id,
                        note: note.value
                    }, function(data) {
                        $.LoadingOverlay('hide');
                        find.prepend(
                                `<span style="font-size: 14px;">${note.value}</span>
                                <br>
                                <span style="font-size: 10px; color: dodgerblue;">${data.agent_name} - ${data.date}</span>
                                <br><br>`
                            );
                        swal.fire(
                            "Success",
                            "Note has been successfully created.",
                            "success"
                        )
                    });
                });
            } else {
                swal.fire("Cancelled", "Note was not created!", "error");
            }
        });
    });

    $(document).on('click', '#mark-completed', function(e) {
        e.preventDefault();
        var btn = $(this);
        var id = btn.data('id');
        var url = "/setTaskComplete";
        swal.fire({
            title: "Are you sure?",
            text: "You are about to set this task as complete",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Set Complete"
        }).then(completed => {
            if (completed.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post(url, {
                        id: id
                    }, function(data) {
                        $.LoadingOverlay('hide');
                        btn.hide();
                        var event = $('#event-' + id);
                        var group = $('#' + data.group);
                        setTaskComplete(event);
                        event.detach().prependTo(group.find('.events'));
                        group.parent().find('.btn-activity').show();
                        swal.fire(
                            "Success",
                            "Task has been successfully set to complete.",
                            "success"
                        )
                    });
                });
            } else {
                swal.fire("Cancelled", "Task was not set to complete!", "error");
            }
        });
    });

    $(window).keydown(function(event){
        if(event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });

    function setTaskComplete(event) {
        var target = event.find('#custom-icon-color');
        target.css('color', '#228b22');
        target.removeClass();
        target.addClass('fas fa-tasks');
        event.find('#custom-bg-color').css('background-color', '#228b22')
    }

    $(document).on('click', '.expand-all', function(e) {
        e.preventDefault();
        $('.collapse').each(function() {
            if ($(this).data('role') == 'group') $(this).addClass('show');
        });
        $('.btn-activity').removeClass('collapsed');
        $('.btn-activity').attr('aria-expanded', true);
    });

    $(document).on('click', '.view-all', function(e) {
        e.preventDefault();
        $('.collapse').addClass('show');
        $('.btn-activity').removeClass('collapsed');
        $('.btn-activity').attr('aria-expanded', true);
        $('.inner-collapse').removeClass('collapsed');
        $('.inner-collapse').attr('aria-expanded', true);
    });

    $(document).on('click', '.hide-all', function(e) {
        e.preventDefault();
        $('.collapse').removeClass('show');
        $('.btn-activity').addClass('collapsed');
        $('.btn-activity').attr('aria-expanded', false);
        $('.inner-collapse').addClass('collapsed');
        $('.inner-collapse').attr('aria-expanded', false);
    });

});
</script>
