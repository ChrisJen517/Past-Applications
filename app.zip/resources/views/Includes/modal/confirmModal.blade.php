<link href="{{asset('css/modal.css')}}" rel="stylesheet"/>

<div class="modal fade" id="confirmModal" tabindex="-1" role="dialog" aria-labelledby="confirmLabel">
    <div class="modal-dialog modal-sm-6" role="document">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title text-white" id="confirmLabel">Confirm</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <p>Are you sure you would like to <span id="action"></span> <strong><span id="name"></span></strong>?</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a id="accept" class="btn btn-primary" value="Confirm">Confirm</a>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#confirmModal').on('show.bs.modal', function(e) {
        $(this).find('#action').text($(e.relatedTarget).data('action'));
        $(this).find('#name').text($(e.relatedTarget).data('name'));
        $(this).find('#accept').attr('href', $(e.relatedTarget).data('href'));
    });
});
</script>