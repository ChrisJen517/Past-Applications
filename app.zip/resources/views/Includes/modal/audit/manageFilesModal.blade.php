<link href="{{asset('css/modal.css')}}" rel="stylesheet"/>

<div class="modal fade" id="manageFilesModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title">Manage files for  <span id="auditName"></span></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <h4>Original Files</h4>
                <button class="btn btn-primary" style="color:white;" onclick="downloadAll('originalAudits')"> Download All Original Files</button>
                <button class="btn btn-primary" style="color:white;" onclick="toggleCreate('#create-original')"> Add New Original Documents</button>
                <div id="create-original" style='display:none'>
                    <form action="{{ route('auditUpload') }}" method="POST" enctype="multipart/form-data" id="uploadOriginalFilesForm">
                        @csrf
                        <br>
                        <input type="text" class="form-control" id="upload_original_id" name="id" value="{{ old('id') }}" required hidden>
                        <input type="text" class="form-control" id="original_type" name="type" value="originalAudits" required hidden>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">File</label>
                            <div class="col-lg-9">
                                <input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="originalFile" name="originalFile[]" type="file" required multiple>
                                <label id="original-file-lable" class="custom-file-label" for="originalFile[]" style="margin: 0px 15px 0px 15px;">Choose file(s)...</label>
                            </div>
                        </div>
                        <span id="files-original"></span>
                        <div class="form-group row">
                            <div class="offset-lg-3 col-lg-9">
                                <button class="btn btn-primary" id="addAnotherFileOriginal" type="button" >Add Another File</button>
                                <button class="btn btn-danger" id="removeFileOriginal" type="button"  hidden>Remove File</button>
                                <input type="submit" id="submit" class="btn btn-primary float-right" value="Upload Files">
                            </div>
                        </div>
                    </form>
                </div>
                <table class="table table-striped table-bordered" id="originalFiles">
                    <thead>
                        <tr>
                            <th class="text-center">File Name</th>
                            <th class="text-center">Download</th>
                            <th class="text-center">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <br>
                <hr>
                <br>
                <h4>Completed Files</h4>
                <button class="btn btn-primary" style="color:white;" onclick="downloadAll('completeAudits')"> Download All Completed Files</button>
                <button class="btn btn-primary" style="color:white;" onclick="toggleCreate('#create-complete')"> Add New Completed Documents</button>
                <div id="create-complete" style='display:none'>
                    <form action="{{ route('auditUpload') }}" method="POST" enctype="multipart/form-data" id="uploadCompleteFilesForm">
                        @csrf
                        <br>
                        <input type="text" class="form-control" id="upload_complete_id" name="id" value="{{ old('id') }}" required hidden>
                        <input type="text" class="form-control" id="complete_type" name="type" value="completeAudits" required hidden>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">File</label>
                            <div class="col-lg-9">
                                <input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="completeFile" name="completeFile[]" type="file" required multiple>
                                <label id="complete-file-lable" class="custom-file-label" for="completeFile[0]" style="margin: 0px 15px 0px 15px;">Choose file(s)...</label>
                            </div>
                        </div>
                        <span id="files-complete"></span>
                        <div class="form-group row">
                            <div class="offset-lg-3 col-lg-9">
                                <button class="btn btn-primary" id="addAnotherFileComplete" type="button" >Add Another File</button>
                                <button class="btn btn-danger" id="removeFileComplete" type="button"  hidden>Remove File</button>
                                <input type="submit" id="submit" class="btn btn-primary float-right" value="Upload Files">
                            </div>
                        </div>
                    </form>
                </div>
                <table class="table table-striped table-bordered" id="completedFiles">
                    <thead>
                        <tr>
                            <th class="text-center">File Name</th>
                            <th class="text-center">Download</th>
                            <th class="text-center">Remove</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
                <br>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    var id;   
    var pendingFiles = Array();
    var completedFiles = Array();

    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#originalFiles').DataTable({
            "order":[[0,"desc"]],
            autoWidth: false,
            "processing": true,
            "serverSide": true,
            "ordering": false,
            searching: false,
            "language": {
                'loadingRecords': '&nbsp;',
                processing: '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": `{{ route('auditFiles') }}`,
                "dataType": "json",
                "type": "GET",
                "data": function( d ){
                    d._token = "{{csrf_token()}}";
                    d.id = id;
                    d.type = 'originalAudits';
                }
            },
            "columns": [
                { "data": "0" },
                {
                    "class": "text-center",
                    render: function(return_id, type, row, meta) {
                        pendingFiles.push(row);
                        let route = "/downloadAudit/"+id+"/originalAudits/" + row;
                        return `
                            <td class="text-center">
                                <a class="btn btn-primary btn-sm" style="color:white;"
                                    href="${route}">
                                    Download
                                </a>
                            </td>
                        `;
                    }
                },
                {
                    "class": "text-center",
                    render: function(return_id, type, row, meta) {
                        return `
                            <td class="text-center">
                                <button class="btn btn-danger" style="color:white;"
                                    onclick="deleteAudit('originalAudits','${row}')">
                                    Delete
                                </button>
                            </td>
                        `;
                    }
                },
            ],
            dom: 'Bfrtip',
            "pageLength": 5,
            buttons: [],
            initComplete: function() {
                var input = $("#originalFiles-div .dataTables_filter input").unbind();
                var self = this.api();

                $("#originalFiles-div .dataTables_filter input").keyup(function (e) {
                    // Allows use of Enter key for searching
                    if (e.keyCode == 13)
                        self.search(input.val().replace(/['"]+/g, '')).draw();
                }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                ).text("search")
                .click(function () {
                    self.search(input.val().replace(/['"]+/g, '')).draw();
                }));
                $("#originalFiles-div .dataTables_filter").append($searchButton);
            }
        });

        $('#completedFiles').DataTable({
            autoWidth: false,
            "processing": true,
            "serverSide": true,
            "ordering": false,
            searching: false,
            "language": {
                'loadingRecords': '&nbsp;',
                processing: '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": `{{ route('auditFiles') }}`,
                "dataType": "json",
                "type": "GET",
                "data": function( d ){
                    d._token = "{{csrf_token()}}";
                    d.id = id;
                    d.type = 'completeAudits';
                }
            },
            "columns": [
                { "data": "0" },
                {
                    "class": "text-center",
                    render: function(return_id, type, row, meta) {
                        completedFiles.push(row);
                        let route = "/downloadAudit/"+id+"/completeAudits/" + row;
                        return `
                            <td class="text-center">
                                <a class="btn btn-primary btn-sm" style="color:white;"
                                    href="${route}">
                                    Download
                                </a>
                            </td>
                        `;
                    }
                },
                {
                    "class": "text-center",
                    render: function(return_id, type, row, meta) {
                        return `
                            <td class="text-center">
                                <button class="btn btn-danger" style="color:white;"
                                    onclick="deleteAudit('completeAudits','${row}')">
                                    Delete
                                </button>
                            </td>
                        `;
                    }
                },
            ],
            dom: 'Bfrtip',
            "pageLength": 5,
            buttons: [],
            initComplete: function() {
                var input = $("#completedFiles-div .dataTables_filter input").unbind();
                var self = this.api();

                $("#completedFiles-div .dataTables_filter input").keyup(function (e) {
                    // Allows use of Enter key for searching
                    if (e.keyCode == 13)
                        self.search(input.val().replace(/['"]+/g, '')).draw();
                }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                ).text("search")
                .click(function () {
                    self.search(input.val().replace(/['"]+/g, '')).draw();
                }));
                $("#completedFiles-div .dataTables_filter").append($searchButton);
            }
        });
    
        //when the modal is called sets the id and loads the table data
        $('#manageFilesModal').on('show.bs.modal', function(e) {
            document.getElementById("auditName").innerHTML = $(e.relatedTarget).data('name');
            id = $(e.relatedTarget).data('id');
            $(this).find('#upload_original_id').val($(e.relatedTarget).data('id'));
            $(this).find('#upload_complete_id').val($(e.relatedTarget).data('id'));
            
            reloadTables();
        }); 

        $('#manageFilesModal').on('hide.bs.modal', function(e) {
            document.querySelector('#files-complete').innerHTML = '';
            document.querySelector('#files-original').innerHTML = '';
            document.querySelector('#original-file-lable').innerHTML = 'Choose file(s)...';
            document.querySelector('#complete-file-lable').innerHTML = 'Choose file(s)...';
            $("#create-original").hide();
            $("#create-complete").hide();
        }); 
    });

    //deletes the selected audit
    function deleteAudit(fileType, fileName){
        var _token = $('input[name="_token"]').val();
        swal.fire({
            title: "Are you sure?",
            text: "You are about to delete: "+fileName,
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Delete"
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: "{{ route('auditDelete') }}",
                        data: {
                            type: fileType,
                            fileName: fileName,
                            id:id,
                            _token:_token
                        },
                    }).then(function(data) {
                        $.LoadingOverlay('hide');
                        swal.fire(
                            "Success",
                            "Successfully deleted "+fileName+".",
                            "success"
                        );
                        reloadTables();
                    });
                });
            } else {
                swal.fire("Cancelled", "The file was not deleted!", "error");
            }
        });
    }

    //clears the arrays that store the file names and reloads both tables
    function reloadTables(){
        pendingFiles = Array();
        completedFiles = Array();
        $('#originalFiles').DataTable().ajax.reload();
        $('#completedFiles').DataTable().ajax.reload();
    }

    //downloads each file within the table
    function downloadAll(fileType){
        if(fileType == 'originalAudits'){
            pendingFiles.forEach(fileName => downloadAudit(fileType, fileName));
        }
        else{
            completedFiles.forEach(fileName => downloadAudit(fileType, fileName));
        }
    }

    //downloads the proper file
    function downloadAudit(fileType, fileName){
        window.open(
            '/downloadAudit/'+id+'/'+fileType+'/' + fileName,
            '_blank' 
        );
    }

    //shows or hides the text of the uploading files
    function toggleCreate(toggle){
        $(toggle).toggle();
    }

    //updates the input text to match the uploaded file
    function updateName(element) {
        var fileName = ""
        if ($(element).get(0).files.length > 0) { // only if a file is selected
            
            $($(element).get(0).files).each(function() {
                fileName = fileName + this.name + " ";
            });

            if(fileName.length > 50)
                fileName = fileName.substring(0, 50) +"...";

            if ($(element).val() != "") {
                $(element).siblings(".custom-file-label").addClass("selected").html(fileName);
            }
        }
    }


    //adds or removes a new original file input
    $("#addAnotherFileOriginal").on("click", function(){
        $("#files-original").append('<div class="form-group row">' + 
                    '<label class="col-lg-3 col-form-label form-control-label">File</label>' + 
                        '<div class="col-lg-9">' + 
                            '<input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="originalFile" name="originalFile[]" type="file" multiple>' + 
                            '<label class="custom-file-label" for="originalFile[]" style="margin: 0px 15px 0px 15px;">Choose file(s)...</label>' +
                        '</div>' +
                    '</div>');
        $("#removeFileOriginal").attr("hidden", false);
    });
    
    $("#removeFileOriginal").on("click", function(){
        var list = document.getElementById("files-original");
        var count = list.childElementCount - 1;
        list.removeChild(list.childNodes[count]);
        if(count == 0)
            document.getElementById("removeFileOriginal").hidden = true;
    });

    //adds or removes a new complete file input
    $("#addAnotherFileComplete").on("click", function(){
        $("#files-complete").append('<div class="form-group row">' + 
                    '<label class="col-lg-3 col-form-label form-control-label">File</label>' + 
                        '<div class="col-lg-9">' + 
                            '<input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="completeFile" name="completeFile[]" type="file" multiple>' + 
                            '<label class="custom-file-label" for="completeFile[]" style="margin: 0px 15px 0px 15px;">Choose file(s)...</label>' +
                        '</div>' +
                    '</div>');
        $("#removeFileComplete").attr("hidden", false);
    });

    $("#removeFileComplete").on("click", function(){
        var list = document.getElementById("files-complete");
        var count = list.childElementCount - 1;
        list.removeChild(list.childNodes[count]);
        if(count == 0)
            document.getElementById("removeFileComplete").hidden = true;
    });

    //when uploading a new files check the sum is not too large
    $("#uploadOriginalFilesForm").on( "submit",function(e){
        checkSubmitSize("input[name='originalFile[]'", e);
    });
    $("#uploadCompleteFilesForm").on( "submit",function(e){
        checkSubmitSize("input[name='completeFile[]'", e);
    });

    function checkSubmitSize(filename, e){
        totalSize = 0;
        $(filename).each(function() {
            $(this.files).each(function() {
                totalSize += this.size/1024/1024;
            });
        });

        if(totalSize > 90.0){
            e.preventDefault();
            $.LoadingOverlay("hide");
            swal.fire("Too large", "The files you uploaded were too large! Please don't exceed 90MB or 90,00KB in a single upload.", "error");
            return;
        }

        $.LoadingOverlay("show"); 
    }
</script>
