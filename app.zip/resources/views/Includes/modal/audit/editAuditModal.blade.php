<link href="{{asset('css/modal.css')}}" rel="stylesheet"/>

<div class="modal fade" id="editAuditModal">
    <div class="modal-dialog modal-lg">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title">Edit Audit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="{{route('editAudit')}}" method="POST" enctype="multipart/form-data" id="editAudit">
                <div class="modal-body">
                    @csrf
                    <input type="text" class="form-control" id="edit_id" name="id" value="{{ old('id') }}" required hidden>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Audit Name <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_name" name="name" style="width: 100%;" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Audit/Assesment <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <select class="form-control" id="edit_audit_type" name="audit_type" type="text" value="" required>
                                <option value="audit">Audit</option>
                                <option value="assessment">Assessment</option>
                            </select>  
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Account Manager <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <select class="form-control" id="edit_account_manager" name="account_manager" type="text" value="" required>
                                @foreach($managers as $manager)
                                    <option value="{{$manager}}">{{$manager}}</option>
                                @endforeach
                            </select>  
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">CC (seperate by comma)</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_cc" name="cc" style="width: 100%;" onkeyup="countCharactersEdit('edit_cc', 'ccMessage-edit', 'ccLetters-edit')"> 
                            <span id="ccLetters-edit">
                                <span id="ccMessage-edit"> 0 </span>
                                <span> out of 500 </span>
                            </span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client Contact</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_client_contact" name="client_contact" style="width: 100%;"> 
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <select id="edit_client_id" class="form-control" name="client_id">
                                @foreach($clients as $client)
                                    <option value="{{$client->id}}">{{$client->company_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Due Date <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_due_date" name="due_date" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Notes</label>
                        <div class="col-lg-9">
                            <textarea id="notes-edit" type="textarea" class="form-control textarea" id="edit_notes" name="notes" rows="5" cols="20" maxlength="500"  onkeyup="countCharactersEdit('notes-edit', 'countMessage-edit', 'remainingLetters-edit')"></textarea>
                            <span id="remainingLetters-edit">
                                <span id="countMessage-edit"> 0 </span>
                                <span> out of 500 </span>
                            </span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Complete the Audit</label>
                        <div class="col-lg-9">
                            <select id="edit_complete" class="form-control" name="complete">
                                <option value="0">Still Pending</option>
                                <option value="1">Completed</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <span style="float:left;"> <span style="color: red;">* </span> Denotes required field. </span>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="submit_2" class="btn btn-primary float-right" value="Update">
                </div>
            </form>
        </div>
    </div>
</div>

<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        $(function() {
            $('#edit_due_date').datepicker({
                minDate: new Date,
            });
        });
    
        $('#editAuditModal').on('show.bs.modal', function(e) {
            $(this).find('#edit_id').val($(e.relatedTarget).data('id'));
            $(this).find('#edit_name').val($(e.relatedTarget).data('name'));
            $(this).find('#edit_notes').val($(e.relatedTarget).data('notes'));
            document.getElementById('notes-edit').innerHTML = $(e.relatedTarget).data('notes');
            $(this).find('#edit_due_date').val($(e.relatedTarget).data('due_date'));   
            $(this).find('#edit_account_manager').val($(e.relatedTarget).data('account_manager'));  
            $(this).find('#edit_client_id').val($(e.relatedTarget).data('client_id'));   
            $(this).find('#edit_audit_type').val($(e.relatedTarget).data('audit_type'));
            $(this).find('#edit_cc').val($(e.relatedTarget).data('cc'));   
            $(this).find('#edit_client_contact').val($(e.relatedTarget).data('client_contact'));
            
            if($(e.relatedTarget).data('status') == 'complete'){
                $(this).find('#edit_complete').val(1);
                $('#edit_complete').attr("disabled", true); 
            }
            else{
                $(this).find('#edit_complete').val(0);
                $('#edit_complete').attr("disabled", false); 
            }

            countCharactersEdit('notes-edit', 'countMessage-edit', 'remainingLetters-edit');
            countCharactersEdit('edit_cc', 'ccMessage-edit', 'ccLetters-edit');
        });

        $("#editAudit").each(function() {
            $(this).validate({
                rules: {
                    name: {
                        required: true,
                        maxlength: 100
                    },
                    account_manager: {
                        required: true,
                        maxlength: 100
                    },
                    due_date: {
                        required: true,
                        maxlength: 100
                    },
                    client_id: {
                        required: true,
                    },
                }
            });
        });

        $("#submit_2").click(function () {
            if ($("#editAudit").valid()) {
                $.LoadingOverlay("show");
            }
        })

    });

    //when a key is pressed, updates the counter
    function countCharactersEdit(message, counter, span){
        var count = document.getElementById(message).value.length;
        document.getElementById(counter).innerHTML = count;
        if(count == 500)
            document.getElementById(span).style.color = 'red';
        else
            document.getElementById(span).style.color = 'black';
    }
</script>