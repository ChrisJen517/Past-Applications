<link href="{{asset('css/modal.css')}}" rel="stylesheet"/>

<div class="modal fade" id="createAudit" tabindex="-1" role="dialog" aria-labelledby="createLabel">
    <div class="modal-dialog modal-lg" role="audit">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="createLabel">Create Audit</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="{{ route('createAudit') }}" method="POST" enctype="multipart/form-data" id="createAuditForm">
                <div class="modal-body">
                    @csrf
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Audit Name <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="audit_name" name="audit_name" style="width: 100%;" value="{{ old('audit_name') }}"  maxlength="150">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Audit/Assesment <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <select class="form-control" id="edit_audit_type" name="audit_type" type="text" value="" required>
                                <option value="audit">Audit</option>
                                <option value="assessment">Assessment</option>
                            </select>  
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Account Manager <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <select class="form-control" name="account_manager" type="text" value="" required>
                                <option value="" id="none">Select Account Manager</option>
                                @foreach($managers as $manager)
                                    <option value="{{$manager}}">{{$manager}}</option>
                                @endforeach
                            </select>  
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">CC (seperate by comma)</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="cc" name="cc" style="width: 100%;" onkeyup="countCharactersEdit('cc', 'ccMessage', 'ccLetters')"> 
                            <span id="ccLetters">
                                <span id="ccMessage"> 0 </span>
                                <span> out of 500 </span>
                            </span>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client Contact</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="client_contact" name="client_contact" style="width: 100%;"> 
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client or Vendor Name <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <select id="client_id" class="form-control" name="client_id">
                                <option value="" selected>N/A</option>
                                @foreach($clients as $client)
                                    <option value="{{$client->id}}">{{$client->company_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Due Date <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="due_date" autocomplete="off" name="due_date">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">File <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="file" name="file[]" type="file" required multiple>
                            <label id="create-file-lable" class="custom-file-label" for="file[0]" style="margin: 0px 15px 0px 15px;">Choose file(s)...</label>
                        </div>
                    </div>
                    <span id="files"></span>
                    <div class="form-group row">
                        <div class="offset-lg-3 col-lg-9">
                            <button class="btn btn-primary" id="addAnotherFile" type="button" >Add Another File</button>
                            <button class="btn btn-danger" id="removeFile" type="button"  hidden>Remove File</button>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Notes</label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="notes" name="notes" value="{{ old('notes') }}"rows="5" cols="20" maxlength="500" onkeyup="countCharactersCreate('notes', 'countMessage-create', 'remainingLetters-create')"></textarea>
                            <span id="remainingLetters-create">
                                <span id="countMessage-create"> 0 </span>
                                <span> out of 500 </span>
                            </span>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <span style="float:left;"> <span style="color: red;">* </span> Denotes required field. </span>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="submit" class="btn btn-primary float-right" value="Create Audit">
                </div>
            </form>
        </div>
    </div>
</div>

<script src="{{ asset('js/validation/createAudit.js') }}"></script>
<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script>
    $(document).ready(function() {
        $(function() {
            $('#due_date').datepicker({
                minDate: new Date,
            });
        });


    });

    $('[data-toggle="tooltip"]').tooltip();

    $("#addAnotherFile").on("click", function(){
        $("#files").append('<div class="form-group row">' + 
                    '<label class="col-lg-3 col-form-label form-control-label">File</label>' + 
                        '<div class="col-lg-9">' + 
                            '<input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="file" name="file[]" type="file" multiple>' + 
                            '<label class="custom-file-label" for="file[]" style="margin: 0px 15px 0px 15px;">Choose file(s)...</label>' +
                        '</div>' +
                    '</div>');
        $("#removeFile").attr("hidden", false);
    });

    $("#removeFile").on("click", function(){
        var list = document.getElementById("files");
        var count = list.childElementCount - 1;
        list.removeChild(list.childNodes[count]);
        if(count == 0)
            document.getElementById("removeFile").hidden = true;
    });

    $("#createAuditForm").on( "submit",function(e){
        var totalSize = 0;
        $("input[name='file[]'").each(function() {
            $(this.files).each(function() {
                totalSize += this.size/1024/1024;
            });
        });
        if(totalSize > 90.0){
            e.preventDefault();
            swal.fire("Too large", "The files you uploaded were too large! Please don't exceed 90MB or 90,00KB in a single upload.", "error");
            return;
        }
        if($(this).valid())
            $.LoadingOverlay("show");
    });

    $('#createAudit').on('hide.bs.modal', function(e) {
        document.querySelector('#files').innerHTML = '';
        document.querySelector('#create-file-lable').innerHTML = 'Choose file(s)...';
        document.getElementById("removeFile").hidden = true;

        document.getElementById('countMessage-create').innerHTML = 0;
        document.getElementById('remainingLetters-create').style.color = 'black';
        document.getElementById('ccMessage').innerHTML = 0;
        document.getElementById('ccLetters').style.color = 'black';
    }); 

    function updateName(element) {
        var fileName = ""
        if ($(element).get(0).files.length > 0) { // only if a file is selected
            $($(element).get(0).files).each(function() {
                fileName = fileName + this.name + " ";
            });

            if(fileName.length > 50)
                fileName = fileName.substring(0, 50) +"...";

            if ($(element).val() != "") {
                $(element).siblings(".custom-file-label").addClass("selected").html(fileName);
            }
        }
    }

    //when a key is pressed, updates the counter
    function countCharactersCreate(message, counter, span){
        var count = document.getElementById('notes').value.length;
        document.getElementById('countMessage-create').innerHTML = count;
        if(count == 500)
            document.getElementById('remainingLetters-create').style.color = 'red';
        else
            document.getElementById('remainingLetters-create').style.color = 'black';
    }

</script>
