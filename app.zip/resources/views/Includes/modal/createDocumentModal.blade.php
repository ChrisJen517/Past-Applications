<link href="{{asset('css/modal.css')}}" rel="stylesheet"/>

<div class="modal fade" id="createDocument" tabindex="-1" role="dialog" aria-labelledby="createLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="createLabel">Add Document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="{{ route('createDocument') }}" method="POST" enctype="multipart/form-data" id="createDocumentForm">
                <div class="modal-body">
                    @csrf
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Name <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="document_name" name="document_name" style="width: 100%;" value="{{ old('document_name') }}"  maxlength="150">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client or Vendor Name</label>
                        <div class="col-lg-9">
                            <select id="client_id" class="form-control" name="client_id">
                                <option value="" selected>N/A</option>
                                @foreach($clients as $client)
                                    <option value="{{$client->id}}">{{$client->company_name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Type <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <?php $types = array('Client FCRA MSA', 'Client Non FCRA MSA',
                            'Client Product Amendment', 'Client FCRA Amendment', 'MNDA/NDA',
                            'Data Vendor contract', 'Data Vendor NDA', 'Trend Source Audit','Trendsource Background Check',
                            'Verified vendor contract', 'Verified vendor NDA', 'Policy', 'Procedure',
                            'Marketing', 'Deck', 'Presentation', 'FAQs', 'Onboarding', 'Certificate', 'End User Audit', 'OTHER');?>
                            <select id="type" name="type" class="form-control">
                                @foreach($types as $type)
                                    <option value="{{$type}}">{{$type}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Created Date</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="created_date" autocomplete="off" name="created_date">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Expiration Date</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="expiration_date" autocomplete="off" name="expiration_date">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">File <span style="color: red;">*</span></label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input" id="customFileInput" name="file_name" type="file" value="{{old('file_name')}}">
                            <label class="custom-file-label" for="customFileInput" style="margin: 0px 15px 0px 15px;">Choose file...</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;" data-toggle="tooltip" title="Used to help search for the file, seperate the words by a comma">Key Words</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="key_words" name="key_words">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Notes</label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="notes" name="notes" value="{{ old('notes') }}"rows="5" cols="20" maxlength="250"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <span style="float:left;"> <span style="color: red;">* </span> Denotes required field. </span>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="submit" class="btn btn-primary float-right" value="Add Document">
                </div>
            </form>
        </div>
    </div>
</div>

<script src={{ asset('js/validation/createDocument.js') }}></script>
<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script>
$(document).ready(function() {
    $(function() {
        $('#created_date').datepicker({
            maxDate: new Date,
        });
    });
});

$('[data-toggle="tooltip"]').tooltip();

$(document).ready(function() {
    $(function() {
        $('#expiration_date').datepicker({
            minDate: new Date,
        });
    });
});

$(document).ready(function() {
// form front-end validation
    $('#createDocumentForm').validate({
        rules: {
            document_name: {
                required: true
            },
            type: {
                required: true
            },
            file_name: {
                required: true,
            },
        },
    });

    $('#createDocument').on('hide.bs.modal', function(e) {
            var validator = $( "#createDocumentForm" ).validate();
            validator.resetForm();
        });
    });

    $("#createDocumentForm").on( "submit",function(){
        if($(this).valid())
            $.LoadingOverlay("show");
    });
</script>
