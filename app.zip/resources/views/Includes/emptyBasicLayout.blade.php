<link href="{{asset('plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css" integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta name="description" content="" />
  <meta name="author" content="" />
  <meta name="csrf-token" content="{{ csrf_token() }}" />
  <title>Contract Portal 2.0</title>

  <!-- Bootstrap core CSS-->
  <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" />
  <!-- Custom Style-->
  <link href="{{asset('css/datatable.css')}}" rel="stylesheet" />
  <!-- Icons CSS-->
  <link href="{{asset('css/icons.css')}}" rel="stylesheet" type="text/css" />
  <!-- Sidebar CSS-->
  <link href="{{asset('css/sidebar-menu.css')}}" rel="stylesheet" />
  <!-- Custom Style-->
  <link href="{{asset('css/sidebar-top.css')}}" rel="stylesheet" />
  <!-- simplebar CSS-->
  <link href="{{asset('plugins/simplebar/css/simplebar.css')}}" rel="stylesheet" />

  <!-- Styling CSS-->
  <link href="{{asset('/css/style-test.css')}}" rel="stylesheet" />
</head>

<body>
  <!-- Start wrapper-->
      <!-- Sidebar and Topbar -->
      <header class="topbar-nav">
        <nav class="navbar navbar-expand fixed-top bg-topbar" style="height:80px">
            <ul class="navbar-nav mr-auto align-items-left">
                <a href="{{asset('/')}}">
                    <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon" style="size: 60%">   
                </a>  
            </ul>
            <ul class="navbar-nav align-items-center right-nav-link" style="padding-right: 5%">
                <a href="{{asset('/')}}">
                    @if(empty(Auth::user()))
                        Login 
                    @else
                        Dashboard
                    @endif
                </a> 
            </ul>
        </nav>
      </header>
      <br>
      <br>
      <br>
      <br>
      <!-- Main Conten -->
        <div class="container-fluid">
          @include('Includes.messages')
          @yield('content')
        </div>
</body>



