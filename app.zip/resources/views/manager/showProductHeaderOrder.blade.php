<div class="loading-overlay">
    @extends('Includes.basicLayout')
    @section('content')
    <div class="container-fluid py-3">
        <section id="documents_header">
            <div class="container-fluid text-center">
                <div class="row">
                    <p class="mx-auto">Product Headers Order</p>
                </div>
            </div>
        </section>
        <br>
        <div class="row text-left">
            <div class="col-md-4 offset-md-4 text-center">
                <div class="table-responsive">
                    <table class="table table-hover table-striped table-bordered" id="product-headers">
                        <thead>
                            <tr>
                                <th class="text-center">
                                    Name
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($product_headers as $item)
                            <tr data-index="{{$item->id}}" data-position="{{$item->order}}" style="height:45px;">
                                <td>{{ $item->name }}</td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <a onclick="reorderHeaders()" class="btn btn-primary mx-auto" style="color: white;">Save Order</a>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('js/modal.js?'.time())}}"></script>

<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script>
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('#product-headers tbody').sortable({
        update: function (event, ui) {
            $(this).children().each(function (index) {
                if ($(this).attr('data-position') != (index+1)) {
                    $(this).attr('data-position', (index+1));
                }
            });
        }
    });
});

function reorderHeaders() {
    var positions = [];
    $('#product-headers tbody').children().each(function (index) {
        positions.push(
            {
                index: $(this).attr('data-index'),
                position: $(this).attr('data-position')
            }
        );
    });
    swal.fire({
        title: "Are you sure?",
        text: "You are about to reorder the product headers.",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: 'Save'
    }).then((willSave) => {
        if (willSave.value) {
            $.LoadingOverlay("show");
            $(function() {
                "use strict";
                $.post( "/saveProductHeaderOrder", { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), 'order': positions })
                .done(function(data) {
                    $.LoadingOverlay("hide");
                        swal.fire(
                            "Success",
                            "Product header order has been saved.",
                            "success"
                        );
                });
            });
        } else {
            swal.fire(
                "Cancelled",
                "Header order was not saved!",
                "error"
            );
        }
    });
}
</script>
@endsection
