<div class="loading-overlay">
@extends('Includes.basicLayout')
@section('content')
<link href="{{asset('css/modal.css')}}" rel="stylesheet" />
<div class="card col-md-8 offset-md-2">
    <form action="{{route('saveProductOrder')}}" method="POST" enctype="multipart/form-data" id="Update">
        @csrf
        <div class="card-header">
            <h4 class="modal-title" id="myModalLabel">Update Product Order</h4>
        </div>
        <div class="col-md-6 offset-md-3 text-center">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered" id="product-order">
                    <thead>
                        <tr>
                            <th class="class-center">
                                ID
                            </th>
                            <th class="class-center">
                                Order
                            </th>
                            <th class="text-center">
                                Name
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($products as $item)
                            <tr data-index="{{$item->id}}" data-position="{{$item->order}}" style="height:45px;">
                                <td style="width:10%;">{{ $item->id }}</td>
                                <td style="width:20%;" class="order">{{ empty($item->order) ? 'Unordered' : $item->order }}</td>
                                <td style="width:70%;">{{ $item->name }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            <a class="btn btn-secondary float-left" href="/manageProductSheet">Back</a>
            <a class="btn btn-primary float-right" onclick="reorderProducts()" style="color: white;">Save Order</a>
        </div>
    </form>
</div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

    <script src="{{ asset('js/jquery-ui.min.js') }}"></script>
    <link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script>
    $(document).ready(function() {

        var fixHelper = function(e, ui) {
            ui.children().each(function() {
                $(this).width($(this).width());
            });
            return ui;
        };

        $('#product-order tbody').sortable({
            revert: true,
            helper: fixHelper,
            placeholder: "my-ui-placeholder",
            update: function (event, ui) {
                $(this).children().each(function (index) {
                    if ($(this).attr('data-position') != (index+1)) {
                        $(this).attr('data-position', (index+1));
                        $(this).find('td.order').text(index+1);
                    }
                });
            }
        }).disableSelection();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    function reorderProducts() {
        var positions = [];
        $('#product-order tbody').children().each(function (index) {
            positions.push(
                {
                    index: $(this).attr('data-index'),
                    position: $(this).attr('data-position')
                }
            );
        });
        swal.fire({
            title: "Are you sure?",
            text: "You are about to reorder the products.",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: 'Save'
        }).then((willSave) => {
            if (willSave.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post( "/saveProductOrder", { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), 'order': positions })
                    .done(function(data) {
                        $.LoadingOverlay("hide");
                            swal.fire(
                                "Success",
                                "Product order has been saved.",
                                "success"
                            );
                    });
                });
            } else {
                swal.fire(
                    "Cancelled",
                    "Product order was not saved!",
                    "error"
                );
            }
        });
    }
</script>
@endsection
