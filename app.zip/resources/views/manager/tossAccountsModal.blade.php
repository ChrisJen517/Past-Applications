<link href="{{asset('css/modal.css?'.time())}}" rel="stylesheet"/>

<div class="modal fade" id="tossAccountsModal">
    <div class="modal-dialog modal-sm-6">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title">Toss Accounts ({{$total_unassigned}} Unassigned)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
        </form>
            <form action="{{route('assignAgentLeads')}}" method="POST" enctype="multipart/form-data" id="tossAccounts">
                <div class="modal-body">
                    @csrf
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Agent</label>
                        <div class="col-lg-8">
                            <select id="id" name="id" class="form-control" size="0" value="" required>
                                <option value="" selected disabled>Select Agent</option>
                                @foreach($leads as $lead)
                                <option value="{{$lead->agent_id}}">{{$lead->agent_name}} - {{$lead->total_accounts}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Max Accounts</label>
                        <div class="col-lg-8">
                            <input type="number" class="form-control" id="accounts" name="accounts" value="10" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Industry</label>
                        <div class="col-lg-8">
                            <select id="industry" name="industry" class="form-control" size="0" value="">
                                <option value="" selected>Industry</option>
                                @foreach ($unassigned as $industry)
                                <option value="{{$industry->industry}}">{{$industry->industry}} - {{$industry->total}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button class="btn btn-danger" type="submit" style="color: white;">Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src={{asset('js/validation/tossAccounts.js?'.time())}}></script>
