@extends('Includes.basicLayout')
@section('content')
@include('Includes.modal.manageProductsModal')
<link href="{{asset('css/manageProducts.css?'.time())}}" rel="stylesheet" />

<div class="container-fluid py-3">
    <div class="col-md-12 mx-auto">
        <div class="container-fluid">
            <div class="col float-right text-center">
                <p class="" style="font-size:12; margin-top: 10px;">Disclaimer: Product Order will update automatically when products are moved</p>
            </div>
            <div class="col float-right">
                <a class="btn btn-primary float-left" style="color: white; margin: 30px 40px 0px 0px;" href="/manageProductHeaders">Manage Product Headers</a>
                <a class="btn btn-primary float-left" id="hideButton" style="color: white; margin: 30px 20px 0px 0px;" onclick="hideDescription()">Hide descriptions</a>
                <a class="btn btn-primary float-right" href="/productHistory" style="color: white; margin: 30px 40px 0px 0px;">Product History</a>
                <a class="btn btn-primary float-right" data-toggle="modal" style="color: white; margin: 30px 40px 0px 0px;" data-target="#myModalModAdd">Add Product</a>
                <a class="btn btn-primary float-right" id="export-products" href="#" style="color: white; margin: 30px 40px 0px 0px;">Export Products</a>
            </div>
            <div class="row" style="display:-webkit-inline-box">
                @foreach($product_info as $item)
                <div class="card" style="width:47%; margin:1%;">
                    <div class="card-header text-center" id="product-header" style="font-size: 28px !important;">
                        {{$item->name}}
                    </div>
                    <div class="card-body">
                        <div class="table-responsive" id="product-div">
                            <table class="table table-bordered table-striped" id="product-table">
                                <thead class="table-info product-info">
                                    <tr>
                                        <th style="width:3%">#</th>
                                        <th style="width:22%" class="thName">Name</th>
                                        <th style="width:47%" class = "description">Description</th>
                                        <th style="width:15%">{{$item->id === 11 ? "Records" : "Price"}}</th>
                                        <th style="width:8%">Edit</th>
                                    </tr>
                                </thead>
                                <tbody class="connectedSortable" data-table_header="{{$item->id}}">
                                    @foreach($item->products as $product)
                                    <?php
                                    $price = $product->price;
                                    $price = (float) $price;
                                    if ($price <= 10 || fmod($price, 1) !== 0.0) {
                                        if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                                            $price = number_format($price, 2);
                                        }
                                    }
                                    ?>
                                    <tr data-product_id="{{$product->id}}" style="cursor: -webkit-grab; cursor: grab;">
                                        <td>{{$loop->iteration}}</td>
                                        <td>{{$product->name}}</td>
                                        <td class = "description">{{$product->description}}</td>
                                        <td>@if($product->use_quote == 1) {{$product->quote}} @else {{$price}}@endif</td>
                                        <td class="text-center" style="vertical-align:middle">
                                            <a class="btn btn-primary" style="color: white;" data-id="{{$product->id}}" data-use="{{$product->use_quote}}" data-quote="{{$product->quote}}" data-check="{{$product->show_in_list}}" data-sla="{{$product->sla}}" data-name="{{$product->name}}" data-description="{{$product->description}}" data-product_header_id="{{$product->product_header_id}}" data-price="{{$product->price}}" data-price_name="{{$product->pricing_name}}" data-batch_code="{{$product->batch_code}}" data-vast_code="{{$product->vast_code}}" data-manager_price_1="{{$product->manager_price_1}}" data-manager_price_2="{{$product->manager_price_2}}" data-toggle="modal" data-target="#myModalMod">
                                                Edit
                                        </td>
                                    </tr>
                                    @endforeach
                                    <tr class="sort-disabled"></tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
            <br>
        </div>
    </div>
</div>
<br>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('js/modal.js?'.time())}}"></script>

<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">
<script>
    var updated = false;

    $(window).bind("beforeunload", function() {
        if (updated) {
            return "Are you sure you want to leave? We haven't finished saving.";
        }
    });

    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $('#export-products').click(function(e) {
            e.preventDefault();
            $.LoadingOverlay('show');

            $.get('{{route("exportProducts")}}', function(data, status) {
                $.LoadingOverlay('hide');
                if (status == 'success') {
                    var fileName = data['fileName'];
                    window.location.href = '/downloadExport/' + fileName;
                } else {
                    swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                }
            });
        });

        var fixHelper = function(e, ui) {
            ui.children().each(function() {
                $(this).width($(this).width());
            });
            return ui;
        };

        var start = function(e, ui) {
            ui.item.css({
                'border': '2px solid black',
                'background-color': '#f4f4f4',
                'opacity': 1.0
            });
            $(this).find('.my-ui-placeholder td:nth-child(2)').addClass('hidden-td');
        }

        var stop = function(e, ui) {
            ui.item.css({
                'border': '2px dashed #f8de7e',
                'background-color': '',
                'opacity': ''
            });
            ui.item.css('display', '');
        }

        $("tbody.connectedSortable").sortable({
            connectWith: ".connectedSortable",
            items: ">*:not(.sort-disabled)",
            revert: true,
            dropOnEmpty: true,
            helper: fixHelper,
            start: start,
            stop: stop,
            placeholder: "my-ui-placeholder",
            cursor: "move",
            update: function(event, ui) {
                if (this === ui.item.parent()[0]) {
                var index = 1;
                for (var i = 0; i < event.target.children.length; i++) {
                    if (!$(event.target.children[i]).hasClass('sort-disabled')) {
                        $(event.target.children[i]).find("td:first").html(index++);
                    }
                }
                updated = true;
                $(this)
                    .find("tr:not(.sort-disabled)")
                    .each(function(index) {
                        if (!$(this).hasClass('sort-disabled')) {
                            $(this).attr("data-position", index + 1);
                            $(this).data("position", index + 1);
                        }
                    });

                    var ids = [];
                    var orders = [];
                    var headers = [];
                    $("tbody.connectedSortable").each(function(){
                        var header_id = $(this).data('table_header');
                        $(this).find('tr').each(function(){
                            if (!$(this).hasClass('sort-disabled')) {
                                ids.push($(this).data('product_id'));
                                orders.push($(this).find('td:first').html());
                                headers.push(header_id);
                            }
                        });
                    });

                    if (ids.length != 0 || orders.length != 0) {
                        $.post("/saveProductOrder", {
                            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                                "content"
                            ),
                            ids: ids,
                            orders: orders,
                            p_headers: headers
                        }).done(function(data) {
                            updated = false;
                        });
                    }

            }
            }
        }).disableSelection();
    });

    //hides or shows the description field based on the current state of the tables
    function hideDescription(){
        var hideTds;

        if(document.getElementById("hideButton").innerHTML == "Hide descriptions"){
            hideTds = true;
            document.getElementById("hideButton").innerHTML = "Show descriptions"
        }
        else{
            hideTds = false;
            document.getElementById("hideButton").innerHTML = "Hide descriptions"
        }

        //hides or displays the description
        [].forEach.call(document.getElementsByClassName("description"), function (el) {
            el.hidden = hideTds;

            if(hideTds){
                el.style.maxHeight = "0px";
                el.style.maxWidth = "0px";
                el.style.width = "0px";
            }
            else{
                el.style.maxHeight = "none";
                el.style.maxWidth = "none";
                el.style.width = "47%";
            }
        });

        //makes the name field help fill it back in
        [].forEach.call(document.getElementsByClassName("thName"), function (el) {
            if(hideTds){
                el.style.width = "69%";
            }
            else{
                el.style.width = "22%";
            }
        });
    }

</script>

@endsection
