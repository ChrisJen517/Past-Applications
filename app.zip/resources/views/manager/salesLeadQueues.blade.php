@extends('Includes.basicLayout')
@section('content')
@include('manager.tossAccountsModal')
<br>

<section id="unworked-leads-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <p class="float-left">Lead Queue: {{$total_unassigned}} Un-Assigned Leads</p>
            </div>
        <div class="col-md-2 offset-md-2">
                <a href="" data-toggle="modal" data-target="#tossAccountsModal" class="btn btn-primary btn-sm float-right" role="button">Toss Accounts</a>
            </div>
        </div>
    </div>
</section>

<section id="unworked-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="unworked-leads-div">
                <div id="parent1" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="unworked-leads-table">
                        <thead>
                            <tr>
                                <th class="text-center">Agent ID</th>
                                <th class="text-center">Agent Name</th>
                                <th class="text-center">New Accounts</th>
                                <th class="text-center">Worked Accounts</th>
                                <th class="text-center">Total Accounts</th>
                                <th class="text-center">Un-Assign Queue</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($leads as $lead)

                            <tr>
                                @if (empty($lead->agent_id))
                                    <td class="text-center">Unassigned</td>
                                @else
                                    <td class="text-center">{{$lead->agent_id}}</td>
                                @endif
                                @if (empty($lead->agent_name))
                                    <td class="text-center">Unassigned</td>
                                @else
                                    <td class="text-center">{{$lead->agent_name}}</td>
                                @endif
                                <td class="text-center">{{$lead->new_accounts}}</td>
                                <td class="text-center">{{$lead->worked_accounts}}</td>
                                <td class="text-center">{{$lead->total_accounts}}</td>

                                @if (empty($lead->agent_id))
                                    <td class="text-center">N/A</td>
                                @else
                                    <td class="text-center">
                                        <form action="{{route('clearAgentLeads')}}" method="GET" id="showLeadForm"
                                            enctype="multipart/form-data">
                                            @csrf
                                            <input class="form-control" type="hidden" id="leadId" name="id"
                                                value="{{$lead->agent_id}}">
                                            <button class="btn btn-danger" type="submit" style="color: white;">Un-Assign</button>
                                        </form>
                                    </td>
                                @endif

                                <td class="text-center">
                                    <form action="{{route('showAgentLeads')}}" method="GET" id="showLeadForm"
                                        enctype="multipart/form-data">
                                        @csrf
                                        <input class="form-control" type="hidden" id="leadId" name="id"
                                            value="{{$lead->agent_id}}">
                                        <button class="btn btn-info" type="submit"  style="color: white;">Show
                                            Accounts</button>
                                    </form>
                                </td>
                            </tr>

                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
$(document).ready(function() {

    $('#unworked-leads-table').DataTable({
        "order": [
            [3, "desc"],
            [1,"asc"]
        ],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#parent1').removeClass('table-parent-hidden');
        }
    });
});
</script>
@endsection
