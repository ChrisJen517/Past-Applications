@extends('Includes.basicLayout')
@section('content')
@include('Includes.modal.approveLegalModal')

<link href="{{asset('css/multiTableProcessing.css?'.time())}}" rel="stylesheet" />

<br>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Approval Needed:</p>
            </div>
        </div>
    </div>
</section>

<section id="upload-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="payroll-uploads-action-needed-div">
                <table class="table table-striped table-bordered" id="payroll-uploads-action-needed">
                    <thead>
                        <tr>
                            <th style="width: 10%;" class="text-center">Contract Number</th>
                            <th style="width: 15%;" class="text-center">Company Name</th>
                            <th style="width: 15%;" class="text-center">Agent Name</th>
                            <th style="width: 10%;" class="text-center">Created Date</th>
                            <th style="width: 10%;" class="text-center">Contract Type</th>
                            <th style="width: 10%;" class="text-center">Contract Link</th>
                            <th style="width: 10%;" class="text-center">Needs Approval By</th>
                            <th style="width: 10%;" class="text-center">Approve Contract</th>
                            <th style="width: 10%;" class="text-center">Archive</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<hr>
<br>
<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Contracts Pending:</p>
            </div>
        </div>
    </div>
</section>

<section id="upload-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="payroll-uploads-div">
                <div id="parent6">
                    <table class="table table-striped table-bordered" id="payroll-uploads-pending">
                        <thead>
                            <tr>
                                <th style="width: 10%;" class="text-center">Contract Number</th>
                                <th style="width: 15%;" class="text-center">Company Name</th>
                                <th style="width: 15%;" class="text-center">Agent Name</th>
                                <th style="width: 10%;" class="text-center">Created Date</th>
                                <th style="width: 10%;" class="text-center">Contract Type</th>
                                <th style="width: 10%;" class="text-center">Send Contract</th>
                                <th style="width: 10%;" class="text-center">Contract Link</th>
                                <th style="width: 10%;" class="text-center">Contract History</th>
                                <th style="width: 10%;" class="text-center">Archive</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>
<br />
<br />

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Contracts Complete:</p>
            </div>
        </div>
    </div>
</section>

<section id="upload-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="payroll-uploads-div">
                <div id="parent2">
                    <table class="table table-striped table-bordered" id="payroll-uploads">
                        <thead>
                            <tr>
                                <th style="width: 10%;" class="text-center">Contract Number</th>
                                <th style="width: 15%;" class="text-center">Company Name</th>
                                <th style="width: 15%;" class="text-center">Agent Name</th>
                                <th style="width: 10%;" class="text-center">Created Date</th>
                                <th style="width: 10%;" class="text-center">Contract Type</th>
                                <th style="width: 10%;" class="text-center">Send Contract</th>
                                <th style="width: 10%;" class="text-center">Contract Link</th>
                                <th style="width: 10%;" class="text-center">Contract History</th>
                                <th style="width: 10%;" class="text-center">Archive</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<hr>
<br>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Archived Contracts:</p>
            </div>
        </div>
    </div>
</section>

<section id="upload-history-archived">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="payroll-uploads-archived-div">
                <div id="parent3">
                    <table class="table table-striped table-bordered" id="payroll-uploads-archived">
                        <thead>
                            <tr>
                                <th style="width: 10%;" class="text-center">Contract Number</th>
                                <th style="width: 20%;" class="text-center">Company Name</th>
                                <th style="width: 20%;" class="text-center">Agent Name</th>
                                <th style="width: 10%;" class="text-center">Created Date</th>
                                <th style="width: 10%;" class="text-center">Contract Type</th>
                                <th style="width: 10%;" class="text-center">Contract Link</th>
                                <th style="width: 10%;" class="text-center">Contract History</th>
                                <th style="width: 10%;" class="text-center">UnArchive</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<hr>
<br>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>You-Negotiate Contract Pricing:</p>
            </div>
        </div>
    </div>
</section>

<section id="you-negotiate-pricing">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="you-negotiate-div">
                <div id="parent4">
                    <table class="table table-striped table-bordered" id="you-negotiate">
                        <thead>
                            <tr>
                                <th style="width: 10%;" class="text-center">Contract Number</th>
                                <th style="width: 15%;" class="text-center">Company Name</th>
                                <th style="width: 15%;" class="text-center">Agent Name</th>
                                <th style="width: 10%;" class="text-center">Created Date</th>
                                <th style="width: 10%;" class="text-center">One-Time Set Up Fee</th>
                                <th style="width: 10%;" class="text-center">
                                    Successful Payments Processed (Percentage)
                                </th>
                                <th style="width: 10%;" class="text-center">SMS Service</th>
                                <th style="width: 10%;" class="text-center">Email Service</th>
                                <th style="width: 10%;" class="text-center">Approved By</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script src="{{asset('js/modal.js?'.time())}}"></script>

<script>
    $(document).ready(function() {

    $('#payroll-uploads-action-needed').DataTable({
        "order":[[0,"desc"]],
        autoWidth: false,
        "processing": true,
        "serverSide": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "ajax": {
            "url": "{{ route('getContractsNeedingApproval') }}",
            "dataType": "json",
            "type": "POST",
            "data": {
                _token: "{{csrf_token()}}",
            }
        },
        "columns": [
            { "data": "id" },
            {
                "data": "company_name",
                render: function(company_name, type, row, meta) {
                    let client_id = row.client_id;
                    let redirect = "";
                    if (client_id != null)
                        redirect = "/manageClients/edit/" + client_id;
                    else if (row.contract_type != "ICA")
                        redirect = "/findClient/" + company_name;

                    if (redirect != '') {
                        return `<td>
                                    <a href="${redirect}">
                                        ${company_name}
                                    </a>
                                </td>`;
                    } else
                        return `<td>${company_name}</td>`
                }
            },
            { "data": "agent_name" },
            { "data": "created_at" },
            { "data": "contract_type" },
            {
                "data": "contract_name",
                "class": "text-center",
                render: function(contract_name, type, row, meta) {
                    let route = "/download/" + contract_name;
                    return `
                        <td>
                            <a href="${route}">
                                <div style="height:100%; width:100%">
                                    Download
                                </div>
                            </a>
                        </td>
                    `;
                }
            },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    let approver = 'Jim';
                    if (status == 'awaiting_manager_approval')
                        approver = 'Manager';
                    else if(status == 'awaiting_legal_approval')
                        approver = 'Legal';

                    return `<td>${approver}</td>`;
                }
            },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    if (status != 'awaiting_legal_approval') {
                        let route = '/authorizeContract/' + row.id;
                        return `
                            <td>
                                <a href="${route}" id="approveButton">
                                    <div style="height:100%;width:100%">
                                        Approve Contract
                                    </div>
                                </a>
                            </td>
                        `;
                    } else {
                        return `
                           <td>
                                <a class="btn btn-primary" data-toggle="modal" data-target="#approveLegal"
                                    style="color:white;" data-id="${row.id}"
                                    data-name="${row.agent_name}"
                                    data-id = "${row.agent_reference}"
                                    data-contract_id="${row.id}"
                                    data-company="${row.company_name}"
                                    data-type="${row.contract_type}"
                                    data-contract_name="${row.contract_name}"
                                >
                                    Approve
                                </a>
                            </td>
                        `;
                    }
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    return `
                        <td class="text-center">
                            <button class="btn btn-danger" style="color:white;"
                                onclick="archiveContract(${id})">
                                Archive
                            </button>
                        </td>
                    `;
                }
            },
        ],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            {
                extend: 'excelHtml5',
                action: (e, dt, node, config) => {
                    $.LoadingOverlay('show');
                    $.post('{{route("exportContracts")}}', {
                        type: 'approval',
                        search: dt.search()
                    }, function(data, status) {
                        if (status == 'success') {
                            var fileName = data['fileName'];
                            window.location.href = '/downloadExport/' + fileName;
                            $.LoadingOverlay('hide');
                        } else {
                            swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                            $.LoadingOverlay('hide');
                        }
                    });
                }
            },
            'pdfHtml5'
        ],
        initComplete: function() {
            var input = $("#payroll-uploads-action-needed-div .dataTables_filter input").unbind();
            var self = this.api();

            $("#payroll-uploads-action-needed-div .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#payroll-uploads-action-needed-div .dataTables_filter").append($searchButton);
        }
    });

    $('#payroll-uploads').DataTable({
        "order":[[0,"desc"]],
        autoWidth: false,
        "processing": true,
        "serverSide": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "ajax": {
            "url": "{{ route('getCompleteContracts') }}",
            "dataType": "json",
            "type": "POST",
            "data": {
                _token: "{{csrf_token()}}",
            }
        },
        "columns": [
            { "data": "id" },
            {
                "data": "company_name",
                render: function(company_name, type, row, meta) {
                    let client_id = row.client_id;
                    let redirect = "";
                    if (client_id != null)
                        redirect = "/manageClients/edit/" + client_id;
                    else if (row.contract_type != "ICA")
                        redirect = "/findClient/" + company_name;

                    if (redirect != '') {
                        return `<td>
                                    <a href="${redirect}">
                                        ${company_name}
                                    </a>
                                </td>`;
                    } else
                        return `<td>${company_name}</td>`
                }
            },
            { "data": "agent_name" },
            { "data": "created_at" },
            { "data": "contract_type" },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    let display = '';
                    if (status == 'converting')
                        display = 'Converting';
                    else if (row.approval_needed == 1)
                        display = 'Awaiting Approval';
                    else if (row.contract_type == 'REDLINE')
                        display = 'Docusign not implemented for redline';
                    else if (status == 'complete')
                        display = 'Contract Complete';
                    else if (row.company_email == null)
                        display = 'No Email with contract';
                    else if (status == 'awaiting_all_signature') {
                        let email = row.docusign_email;
                        if (email == null)
                            email = row.company_email;
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="resendContract(${row.id}, 'jimv@rnngroup.com and ${email}')">
                                    Resend
                                </button>
                            </td>
                        `;
                    } else if (status == 'awaiting_client_signature') {
                        let email = row.docusign_email;
                        if (email == null)
                            email = row.company_email;
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="resendContract(${row.id}, '${email}')">
                                    Resend
                                </button>
                            </td>
                        `;
                    } else if (status == 'awaiting_jim_signature') {
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="resendContract(${row.id}, 'jimv@rnngroup.com')">
                                    Resend
                                </button>
                            </td>
                        `;
                    } else {
                        let name_options = "";
                        if(row.account_payable_name != null) {
                            name_options += "<br>" + row.account_payable_name;
                        }
                        if(row.invoice_approver_name != null) {
                            name_options += "<br>" + row.invoice_approver_name;
                        }
                        if(row.executive_contact_name != null) {
                            name_options += "<br>" + row.executive_contact_name;
                        }
                            
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="sendContract(${row.id}, '${row.company_email}', '${name_options}')">
                                    Send
                                </button>
                            </td>
                        `;
                    }
                    return `<td>${display}</td>`;
                }
            },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    let display = '';
                    if (status == 'converting')
                        display = 'Converting';
                    else if (row.approval_needed == 1)
                        display = 'Awaiting Approval';
                    else {
                        let route = "/download/" + row.contract_name;
                        return `
                            <td>
                                <a href="${route}">
                                    <div style="height:100%; width:100%">
                                        Download
                                    </div>
                                </a>
                            </td>
                        `;
                    }
                    return `<td>${display}</td>`;
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    let route = '/manageContract/' + id;
                    return `
                        <td>
                            <a href="${route}" class="btn btn-primary btn-sm"
                            role="button">View History</a>
                        </td>
                    `;
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    return `
                        <td class="text-center">
                            <button class="btn btn-danger" style="color:white;"
                                onclick="archiveContract(${id})">
                                Archive
                            </button>
                        </td>
                    `;
                }
            },
        ],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            {
                extend: 'excelHtml5',
                action: (e, dt, node, config) => {
                    $.LoadingOverlay('show');
                    $.post('{{route("exportContracts")}}', {
                        type: 'complete',
                        search: dt.search()
                    }, function(data, status) {
                        if (status == 'success') {
                            var fileName = data['fileName'];
                            window.location.href = '/downloadExport/' + fileName;
                            $.LoadingOverlay('hide');
                        } else {
                            swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                            $.LoadingOverlay('hide');
                        }
                    });
                }
            },
            'pdfHtml5'
        ],
        initComplete: function() {
            var input = $("#parent2 .dataTables_filter input").unbind();
            var self = this.api();

            $("#parent2 .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#parent2 .dataTables_filter").append($searchButton);
        }
    });

    $('#payroll-uploads-pending').DataTable({
        "order":[[0,"desc"]],
        autoWidth: false,
        "processing": true,
        "serverSide": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "ajax": {
            "url": "{{ route('getPendingContracts') }}",
            "dataType": "json",
            "type": "POST",
            "data": {
                _token: "{{csrf_token()}}",
            }
        },
        "columns": [
            { "data": "id" },
            {
                "data": "company_name",
                render: function(company_name, type, row, meta) {
                    let client_id = row.client_id;
                    let redirect = "";
                    if (client_id != null)
                        redirect = "/manageClients/edit/" + client_id;
                    else if (row.contract_type != "ICA")
                        redirect = "/findClient/" + company_name;

                    if (redirect != '') {
                        return `<td>
                                    <a href="${redirect}">
                                        ${company_name}
                                    </a>
                                </td>`;
                    } else
                        return `<td>${company_name}</td>`
                }
            },
            { "data": "agent_name" },
            { "data": "created_at" },
            { "data": "contract_type" },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    let display = '';
                    if (status == 'converting')
                        display = 'Converting';
                    else if (row.approval_needed == 1)
                        display = 'Awaiting Approval';
                    else if (row.contract_type == 'REDLINE')
                        display = 'Docusign not implemented for redline';
                    else if (status == 'complete')
                        display = 'Contract Complete';
                    else if (row.company_email == null)
                        display = 'No Email with contract';
                    else if (status == 'awaiting_all_signature') {
                        let email = row.docusign_email;
                        if (email == null)
                            email = row.company_email;
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="resendContract(${row.id}, 'jimv@rnngroup.com and ${email}')">
                                    Resend
                                </button>
                            </td>
                        `;
                    } else if (status == 'awaiting_client_signature') {
                        let email = row.docusign_email;
                        if (email == null)
                            email = row.company_email;
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="resendContract(${row.id}, '${email}')">
                                    Resend
                                </button>
                            </td>
                        `;
                    } else if (status == 'awaiting_jim_signature') {
                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="resendContract(${row.id}, 'jimv@rnngroup.com')">
                                    Resend
                                </button>
                            </td>
                        `;
                    } else {
                        let name_options = "";
                        if(row.account_payable_name != null) {
                            name_options += "<br>" + row.account_payable_name;
                        }
                        if(row.invoice_approver_name != null) {
                            name_options += "<br>" + row.invoice_approver_name;
                        }
                        if(row.executive_contact_name != null) {
                            name_options += "<br>" + row.executive_contact_name;
                        }

                        return `
                            <td>
                                <button class="btn btn-primary" style="width:100%; color:white;"
                                    onclick="sendContract(${row.id}, '${row.company_email}', '${name_options}')">
                                    Send
                                </button>
                            </td>
                        `;
                    }
                    return `<td>${display}</td>`;
                }
            },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    let display = '';
                    if (status == 'converting')
                        display = 'Converting';
                    else if (row.approval_needed == 1)
                        display = 'Awaiting Approval';
                    else {
                        let route = "/download/" + row.contract_name;
                        return `
                            <td>
                                <a href="${route}">
                                    <div style="height:100%; width:100%">
                                        Download
                                    </div>
                                </a>
                            </td>
                        `;
                    }
                    return `<td>${display}</td>`;
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    let route = '/manageContract/' + id;
                    return `
                        <td>
                            <a href="${route}" class="btn btn-primary btn-sm"
                            role="button">View History</a>
                        </td>
                    `;
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    return `
                        <td class="text-center">
                            <button class="btn btn-danger" style="color:white;"
                                onclick="archiveContract(${id})">
                                Archive
                            </button>
                        </td>
                    `;
                }
            },
        ],
        dom: 'Bfrtip',
        pageLength: 5,
        buttons: [
            {
                extend: 'excelHtml5',
                action: (e, dt, node, config) => {
                    $.LoadingOverlay('show');
                    $.post('{{route("exportContracts")}}', {
                        type: 'pending',
                        search: dt.search()
                    }, function(data, status) {
                        if (status == 'success') {
                            var fileName = data['fileName'];
                            window.location.href = '/downloadExport/' + fileName;
                            $.LoadingOverlay('hide');
                        } else {
                            swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                            $.LoadingOverlay('hide');
                        }
                    });
                }
            },
            'pdfHtml5'
        ],
        initComplete: function() {
            var input = $("#parent6 .dataTables_filter input").unbind();
            var self = this.api();

            $("#parent6 .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#parent6 .dataTables_filter").append($searchButton);
        }
    });

    $('#payroll-uploads-archived').DataTable({
        "order":[[0,"desc"]],
        autoWidth: false,
        "processing": true,
        "serverSide": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "ajax": {
            "url": "{{ route('getArchivedContracts') }}",
            "dataType": "json",
            "type": "POST",
            "data": {
                _token: "{{csrf_token()}}",
            }
        },
        "columns": [
            { "data": "id" },
            {
                "data": "company_name",
                render: function(company_name, type, row, meta) {
                    let client_id = row.client_id;
                    let redirect = "";
                    if (client_id != null)
                        redirect = "/manageClients/edit/" + client_id;
                    else if (row.contract_type != "ICA")
                        redirect = "/findClient/" + company_name;

                    if (redirect != '') {
                        return `<td>
                                    <a href="${redirect}">
                                        ${company_name}
                                    </a>
                                </td>`;
                    } else
                        return `<td>${company_name}</td>`
                }
            },
            { "data": "agent_name" },
            { "data": "created_at" },
            { "data": "contract_type" },
            {
                "data": "status",
                "class": "text-center",
                render: function(status, type, row, meta) {
                    let display = '';
                    if (status == 'converting')
                        display = 'Converting';
                    else if (row.approval_needed == 1)
                        display = 'Awaiting Approval';
                    else {
                        let route = "/download/" + row.contract_name;
                        return `
                            <td>
                                <a href="${route}">
                                    <div style="height:100%; width:100%">
                                        Download
                                    </div>
                                </a>
                            </td>
                        `;
                    }
                    return `<td>${display}</td>`;
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    let route = '/manageContract/' + id;
                    return `
                        <td>
                            <a href="${route}" class="btn btn-primary btn-sm"
                            role="button">View History</a>
                        </td>
                    `;
                }
            },
            {
                "data": "id",
                "class": "text-center",
                render: function(id, type, row, meta) {
                    return `
                        <td class="text-center">
                            <button class="btn btn-danger" style="color:white;"
                                onclick="unarchiveContract(${id})">
                                Unarchive
                            </button>
                        </td>
                    `;
                }
            },
        ],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            {
                extend: 'excelHtml5',
                action: (e, dt, node, config) => {
                    $.LoadingOverlay('show');
                    $.post('{{route("exportContracts")}}', {
                        type: 'archived',
                        search: dt.search()
                    }, function(data, status) {
                        if (status == 'success') {
                            var fileName = data['fileName'];
                            window.location.href = '/downloadExport/' + fileName;
                            $.LoadingOverlay('hide');
                        } else {
                            swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                            $.LoadingOverlay('hide');
                        }
                    });
                }
            },
            'pdfHtml5'
        ],
        initComplete: function() {
            var input = $("#parent3 .dataTables_filter input").unbind();
            var self = this.api();

            $("#parent3 .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#parent3 .dataTables_filter").append($searchButton);
        }
    });

    $('#you-negotiate').DataTable({
        "order":[[0,"desc"]],
        autoWidth: false,
        "processing": true,
        "serverSide": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "ajax": {
            "url": "{{ route('getYouNegotiateContracts') }}",
            "dataType": "json",
            "type": "POST",
            "data": {
                _token: "{{csrf_token()}}",
            }
        },
        "columns": [
            { "data": "contract_id" },
            {
                "data": "company_name",
                render: function(company_name, type, row, meta) {
                    let client_id = row.client_id;
                    let redirect = "";
                    if (client_id != null)
                        redirect = "/manageClients/edit/" + client_id;
                    else if (row.contract_type != "ICA")
                        redirect = "/findClient/" + company_name;

                    if (redirect != '') {
                        return `<td>
                                    <a href="${redirect}">
                                        ${company_name}
                                    </a>
                                </td>`;
                    } else
                        return `<td>${company_name}</td>`
                }
            },
            { "data": "agent_name" },
            { "data": "created_at" },
            {
                "data": "setup_price",
                render: function(setup_price, type, row, meta) {
                    let floatPrice = parseFloat(setup_price);
                    if (floatPrice <= 10 || (floatPrice - parseInt(setup_price) !== 0)) {
                        if (floatPrice.toString().substring(1, floatPrice.toString().lastIndexOf('.')).length < 2) {
                            floatPrice = floatPrice.toFixed(2);
                        }
                    }
                    return `<td>$${floatPrice}</td>`;
                }
            },
            {
                "data": "monthly_service_fee_percentage",
                render: function(monthly_service_fee_percentage, type, row, meta) {
                    return `<td>${monthly_service_fee_percentage}%</td>`;
                }
            },
            {
                "data": "customized_setup_price",
                render: function(customized_setup_price, type, row, meta) {
                    return `<td>$${customized_setup_price}</td>`;
                }
            },
            {
                "data": "monthly_minimum_price",
                render: function(monthly_minimum_price, type, row, meta) {
                    return `<td>$${monthly_minimum_price}</td>`;
                }
            },
            { "data": "approved_by" },
        ],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            var input = $("#parent4 .dataTables_filter input").unbind();
            var self = this.api();

            $("#parent4 .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#parent4 .dataTables_filter").append($searchButton);
        }
    });
});

$("#approveButton").click(function(){
    $.LoadingOverlay("show");
});
</script>
@endsection
