<div class="loading-overlay">
@extends('Includes.basicLayout')
@section('content')
<section id="upload-history">
    <div class="container-fluid">
        <div class="col-lg-12">
            <a href="" data-toggle="modal" data-target="#newUserModal" class="btn btn-primary" role="button">Create New User</a>
        </div>
        <br/>
        <section id="user-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <p class="float-left">Users:</p>
                    </div>
                </div>
            </div>
        </section>
        <div class="row">
            <div class="table-responsive" id="table">
                <div id="parent1" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="users-table">
                        <thead>
                            <tr>
                                <th class="text-center">User ID</th>
                                <th class="text-center">User Firstname</th>
                                <th class="text-center">User Lastname</th>
                                <th class="text-center">User Email</th>
                                <th class="text-center">User Role</th>
                                <th class="text-center">Edit User</th>
                                <th class="text-center">Reset Password</th>
                                <th class="text-center">Archive User</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $item)
                            @if($item->id != Auth::user()->id)
                                @if($item->is_archived == 0)
                                <tr class="item{{$item->id}}">
                                    <td>{{$item->id}}</td>
                                    <td>{{$item->name_first}}</td>
                                    <td>{{$item->name_last}}</td>
                                    <td>{{$item->email}}</td>
                                    <td>{{$item->role}}</td>
                                    <td class="text-center">
                                    <a href="{{route('editUser',$item->id)}}" class="btn btn-primary btn-sm" role="button">EDIT</a>
                                    </td>
                                    <td class="text-center">
                                    <button id="password{{$item->id}}" class="btn btn-sm btn-warning" onclick="passwordReset('{{$item->id}}')">Password Reset</button>
                                    </td>
                                    <td class="text-center">
                                    <a href="#" onclick="archiveUser({{$item->id}})" class="btn btn-danger btn-sm" role="button">ARCHIVE</a>
                                    </td>
                                </tr>
                                @endif
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader" style="display:show">
                </div>
            </div>
        </div>
        <br>
        <section id="user-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-8">
                        <p class="float-left">Archived Users:</p>
                    </div>
                </div>
            </div>
        </section>
        <div class="row">
            <div class="table-responsive" id="table">
                <div id="parent2" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="archived-users-table">
                        <thead>
                            <tr>
                                <th class="text-center">User ID</th>
                                <th class="text-center">User Firstname</th>
                                <th class="text-center">User Lastname</th>
                                <th class="text-center">User Email</th>
                                <th class="text-center">User Role</th>
                                <th class="text-center">Unarchive User</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($users as $item)
                            @if($item->is_archived == 1)
                                @if($item->id != Auth::user()->id)
                                <tr class="item{{$item->id}}">
                                    <td>{{$item->id}}</td>
                                    <td>{{$item->name_first}}</td>
                                    <td>{{$item->name_last}}</td>
                                    <td>{{$item->email}}</td>
                                    <td>{{$item->role}}</td>
                                    <td class="text-center">
                                    <a href="#" onclick="unarchiveUser({{$item->id}})" class="btn btn-danger btn-sm" role="button">UNARCHIVE</a>
                                    </td>
                                </tr>
                                @endif
                            @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader-2" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>
</div>
@include('manager.addNewUser')
<script src="{{asset('js/modal.js?'.time())}}"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script>
$(document).ready(function() {
    $('#users-table').DataTable({
        "order":[[1,"asc"]],
        initComplete: function() {
            $('#loader').delay(25).fadeOut();
            $('#parent1').removeClass('table-parent-hidden');
        }
    });

    $('#archived-users-table').DataTable({
        "order":[[1,"asc"]],
        initComplete: function() {
            $('#loader-2').delay(25).fadeOut();
            $('#parent2').removeClass('table-parent-hidden');
        }
    });

    $('#role').on('change', function(){
        if( $('#role').val() == 'agent')
        {
            $('#hiddenEmail').attr('hidden', false);
            if ($('#admin_checkbox_div').length) {
                $('#admin_checkbox_div').attr('hidden', true);
                $('#admin_checkbox_input').attr('disabled', true);
            }
            $('[name=manager_email]').val($('#old_manager_email').val());
        }
        if( $('#role').val() == 'manager')
        {
            $('#hiddenEmail').attr('hidden', true);
            if ($('#admin_checkbox_div').length) {
                $('#admin_checkbox_div').attr('hidden', false);
                $('#admin_checkbox_input').attr('disabled', false);
            }
            $('[name=manager_email]').val('');
        }
    });

    $('#newUserForm').validate({
        rules: {
            name_first: {
                required: true
            },
            name_last: {
                required: true
            },
            email: {
                required: true,
                email: true
            },
            manager_email: {
                required: true
            }
        }
    });
});
$("#newUserForm").on( "submit",function(){
    if($(this).valid())
        $.LoadingOverlay("show");
});

</script>
@endsection
