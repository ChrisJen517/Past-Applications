@extends('Includes.basicLayout')
@section('content')

@if(Auth::user()->role == 'manager')
@include('Includes.modal.editDocumentModal')
@endif

<div class="container-fluid py-3">
    <div class="row">
        <div class="mx-auto col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Document Information</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document ID</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="id" type="text" value="{{$document->id}}" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Name</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="document_name" type="text" value="{{$document->document_name}}" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Description</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="document_name" type="text" value="{{$document->description}}" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Created At</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="created_at" type="text" value="{{$document->created_at}}" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Updated At</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="updated_at" type="text" value="{{$document->updated_at}}" readonly>
                        </div>
                    </div>
                    <a class="btn btn-secondary float-left" href="/supportDocuments">Back</a>   
                    @if(Auth::user()->role == 'manager')
                    <a class="btn btn-primary float-right" data-toggle="modal" data-target="#editDocument" style="color:white;"
                    data-id="{{ $document->id }}" data-name="{{ $document->document_name }}" data-description="{{ $document->description }}">
                       Edit
                    </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
<section id="history">
    <div class="container-fluid">
        <div class="row">
        <h3>Document History</h3>
        </div>
        <div class="row">
            <div class="table-responsive" id="history-div" hidden>
                <table class="table table-striped table-bordered" id="history-table">
                    <thead>
                        <tr>
                            <th class="text-center">Update Time</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Updated File</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($history as $item)
                        <?php
                            $contractName = $item->file_name;
                        ?>
                        <tr class="item{{$item->id}}">
                            <td>{{$item->created_at}}</td>
                            <td>{{$item->description}}</td>
                            <td class="text-center">
                                <a href="{{ route('download', $contractName) }}" download>
                                    <div style="height:100%;width:100%">
                                        Download File
                                    </div>
                                </a>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<script>
$(document).ready(function() {
    $('#history-table').DataTable({
        "order":[[0,"desc"]],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#history-div').attr('hidden', false);
        }
    });
});
</script>
@endsection
