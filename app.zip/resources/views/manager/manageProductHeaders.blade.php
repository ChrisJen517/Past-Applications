<div class="loading-overlay">
@extends('Includes.basicLayout')
@section('content')

@include('Includes.modal.editProductHeader')
@include('Includes.modal.addProductHeader')

<div class="container-fluid py-3">
    <section id="documents_header">
        <div class="container-fluid">
            <div class="row text-left">
                <p>Edit Product Headers</p>
            </div>
            <div class="row text-left">
                <a href="/manageProductSheet" class="btn btn-secondary" style="margin-right: 10px;">Back</a>
                <a class="btn btn-primary float-right" href="/productHistory" style="color: white; margin-right: 10px;">Header History</a>
                <a href="" data-toggle="modal" data-target="#addProductHeaderModal" class="btn btn-primary" role="button">Add Product Header</a>
            </div>
        </div>
    </section>
    <br>
    <div class="row text-left">
    <div class="table-responsive">
                <table class="table table-striped table-bordered" id="product-headers" style="border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th class="text-center">Order</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Product Name Label</th>
                            <th class="text-center">Description Label</th>
                            <th class="text-center">Cost Label</th>
                            <th class="text-center">Pricing Contract Header</th>
                            <th class="text-center">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($product_headers as $item)
                        <tr data-index="{{$item->id}}" data-position="{{$item->order}}" style="height:45px;">
                            <td class="order"> {{$item->order }}</td>
                            <td>{{ $item->name }}</td>
                            <td>{{ $item->column_1 }}</td>
                            <td>{{ $item->column_2 }}</td>
                            <td>{{ $item->column_3 }}</td>
                            <td class="text-center">
                                <a class="btn btn-primary" data-toggle="modal" data-target="#editProductHeader" style="color:white;"
                                 data-id="{{ $item->id }}" data-name="{{ $item->name }}" data-description="{{ $item->description }}" data-check="{{$item->show_in_list}}"
                                 data-column_1="{{ $item->column_1 }}" data-column_2="{{ $item->column_2 }}" data-column_3="{{ $item->column_3 }}">
                                    Edit
                                </a>
                            </td>
                            <td class="text-center">
                                <button class="btn btn-danger" onclick=deleteProductHeader({{$item->id}})>Delete</button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('js/modal.js?'.time())}}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
<link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">

<script>

var updated = false;

$(window).bind("beforeunload", function() {
    if (updated) {
        return "Are you sure you want to leave? We haven't finished saving.";
    }
});

$(document).ready(function() {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var fixHelper = function(e, ui) {
        ui.children().each(function() {
            $(this).width($(this).width());
        });
        return ui;
    };

    var start = function(e, ui) {
        $(this).sortable('refreshPositions');
        ui.item.css({
            'outline': '',
            'border': '2px solid black',
            'background-color': '#f4f4f4',
            'opacity': 1.0
        });
    };

    var stop = function(e, ui) {
        ui.item.css({
            'outline': '2px dashed #f8de7e',
            'border': '',
            'background-color': '',
            'opacity': ''
        });
    };

    $('#product-headers tbody').children().each(function (index) {
                if ($(this).attr('data-position') != (index+1)) {
                    $(this).attr('data-position', (index+1));
                    $(this).find('td.order').text(index+1);
                }
            });

    $('#product-headers tbody').sortable({
        revert: true,
        helper: fixHelper,
        start: start,
        stop: stop,
        placeholder: "my-ui-placeholder",
        cursor: "move",
        zIndex: 99999,
        opacity: 1.0,
        update: function (event, ui) {
            $(this).children().each(function (index) {
                if ($(this).attr('data-position') != (index+1)) {
                    $(this).attr('data-position', (index+1));
                    $(this).find('td.order').text(index+1);
                }
                updated = true;
            });
                updated = true;
                $(this)
                    .children()
                    .each(function(index) {
                        $(this).attr("data-position", index + 1);
                        $(this).data("position", index + 1);
                    });

                    var ids = [];
                    var orders = [];
                    $('#product-headers tbody').children().each(function (index) {
                        ids.push($(this).attr('data-index'));
                        orders.push($(this).attr('data-position'));
                    });

                    if (ids.length != 0 || orders.length != 0) {
                        $.post("/saveProductHeaderOrder", {
                            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                                "content"
                            ),
                            ids: ids,
                            orders: orders,
                        }).done(function(data) {
                            updated = false;
                        });
                    }

            }
        }).disableSelection();
    });

</script>
@endsection
