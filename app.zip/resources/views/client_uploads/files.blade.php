<link href="{{asset('plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
    type="text/css">
<link href="{{asset('plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('plugins\bootstrap-datatable\css\rowReorder.dataTables.min.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css"
    integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="google" content="notranslate">
    <title>Contract Portal 2.0</title>

    <!-- Bootstrap core CSS-->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="{{asset('css/datatable.css?'.time())}}" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="{{asset('css/sidebar-top.css?'.time())}}" rel="stylesheet" />
    <!-- Icons CSS-->
    <link href="{{asset('css/icons.css')}}" rel="stylesheet" type="text/css" />

    <!-- Styling CSS-->
    <link href="{{asset('/css/style-test.css')}}" rel="stylesheet" />
</head>

<header class="topbar-nav">
    <nav class="navbar navbar-expand fixed-top bg-topbar" style="height:80px">
        <ul class="navbar-nav mr-auto align-items-left">
            <a>
                <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon" style="size: 60%">   
            </a>  
        </ul>
    </nav>
</header>

<!-- Main Content -->
<div class="content-wrapper" style="margin-left: 5px">
    <div class="container-fluid">
        <br>
        <br>
            <div class="container-fluid">
                <div class="row text-left">
                    <div class="col-md-8 offset-md-2 text-left">
                        <!--catches the validation errors-->
                        @if(count($errors) > 0)
                            @foreach($errors->all() as $error)
                                <div class="alert alert-danger">
                                    {{$error}}
                                </div>
                            @endforeach
                        @endif

                        @isset($success)
                        <div class="alert alert-success message">
                                    {{$success}}
                                </div>
                        @endisset

                        <!--catches the success messages-->
                        @if (session('success'))
                                <div class="alert alert-success message">
                                    {{session('success')}}
                                </div>
                        @endif

                        <!--catches the errors we create-->
                        @if (session('error'))
                            <div class="alert alert-danger message">
                                {{session('error')}}
                            </div>
                        @endif

                        <!--catches the messages-->
                        @if(session()->has('message'))
                            <div class="alert alert-success message">
                                {{ session()->get('message') }}
                            </div>
                        @endif
                        <table class="table table-striped table-bordered" id="history">
                            <thead>
                                <tr>
                                    <th class="text-center">File Name</th>
                                    <th class="text-center">Download File</th>
                                    <th class="text-center">Upload File</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($files as $file_name)
                                    <tr class="item">
                                        <td class="text-center" style="width: 60%;">
                                            {{$file_name}}
                                        </td>
                                        <td class="text-center" style="width: 20%;">
                                            <a href="{{route('downloadClientDocument', ['file_name' => $file_name, 'email' => $email, 'password' => $password])}}">
                                                <div style="height:100%;width:100%">
                                                    Download
                                                </div>
                                            </a>
                                        </td>
                                        <td class="text-center" style="width: 20%;">
                                            <button  data-toggle="modal" data-target="#clientChangesModal" data-file_name="{{$file_name}}" class="btn btn-primary btn-sm">@if(in_array($file_name, $uploaded_files)) Change Upload @else Upload Changes @endif</button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <div>
                            <a href="{{route('clientCompleteUploading', ['email' => $email, 'password' => $password])}}" class="btn btn-danger btn-sm float-right">Submit Files</a>
                        </div>
                    </div>
                </div>
            </div>
        <br>
    </div>
</div>

<div class="modal fade" id="clientChangesModal" >
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Upload File (.docx or .pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="{{route('clientUploadDocument')}}" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                @csrf
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="file_name" name="file_name" value="">
                    <input class="form-control" type="hidden" id="email" name="email" value="{{$email}}">
                    <input class="form-control" type="hidden" id="password" name="password" value="{{$password}}">
                </div>

                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Upload File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".docx, .pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>


<script src="{{asset('js/jquery.min.js')}}"></script>
<script src="{{ asset('js/app.js' )}}"></script>
<script src="{{ asset('js/jquery.toast.min.js' )}}"></script>
<script src="{{asset('js/collapse.js?'.time())}}"></script>
<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<script src="{{asset('js/bootstrap.min.js')}}"></script>


<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>



<script src="{{asset('plugins/jquery-multi-select/jquery.multi-select.js')}}"></script>

<script src="{{asset('plugins/jquery-multi-select/jquery.quicksearch.js')}}"></script>

<script src="{{asset('plugins/jquery-validation/js/jquery.validate.min.js')}}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.9.0/jquery.validate.js"></script>

<script src="{{asset('plugins/select2/js/select2.min.js')}}"></script>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.js">
</script>

<script>

$(document).ready(function () {

    $("#submit-button").on( "click",function(e){
        e.preventDefault();
        var totalSize = 0;
        $("input[name='uploadFile']").each(function() {
            if(this.files[0])
                totalSize += this.files[0].size/1024/1024;
        });
        if(totalSize > 50.0){
            e.preventDefault();
            swal.fire("Too large", "The files you uploaded were too large! Please don't exceed 50MB or 50,00KB in a single upload.", "error");
            return;
        } else {
            $("#manualUploadForm").submit();
        }

    });

    
    $('#clientChangesModal').on('show.bs.modal', function(e) {
        $("#file_name").val($(e.relatedTarget).data('file_name'));
    });

});
</script>