<link href="{{asset('plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet"
    type="text/css">
<link href="{{asset('plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')}}" rel="stylesheet" type="text/css">
<link href="{{asset('plugins\bootstrap-datatable\css\rowReorder.dataTables.min.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css"
    integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="google" content="notranslate">
    <title>Contract Portal 2.0</title>

    <!-- Bootstrap core CSS-->
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="{{asset('css/datatable.css?'.time())}}" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="{{asset('css/sidebar-top.css?'.time())}}" rel="stylesheet" />
    <!-- Icons CSS-->
    <link href="{{asset('css/icons.css')}}" rel="stylesheet" type="text/css" />

    <!-- Styling CSS-->
    <link href="{{asset('/css/style-test.css')}}" rel="stylesheet" />
</head>

<header class="topbar-nav">
    <nav class="navbar navbar-expand fixed-top bg-topbar" style="height:80px">
        <ul class="navbar-nav mr-auto align-items-left">
            <a>
                <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon" style="size: 60%">   
            </a>  
        </ul>
    </nav>
</header>

<!-- Main Content -->
<div class="content-wrapper" style="margin-left: 5px">
    <div class="container-fluid">
        <br>
        <br>
        <section id="previous-uploads-header" style="font-size: 30px">
            <div class="container-fluid">
                <div class="row text-left">
                    <div class="col-md-8 offset-md-2 text-left">
                        <form method="GET" action="{{ route('checkClientLogin') }}">
                            @csrf
                            <div class="card-title text-uppercase text-center py-3" >Please use your Email and the Password that we provided</div>
                            <div class="row text-left">
                                <div class="col-md-8 offset-md-2 text-left">
                                    @if($errors->any())
                                        @foreach ($errors->all() as $error)
                                            <div class="alert alert-danger text-center">{{ $error }}</div>
                                        @endforeach
                                    @endif
                                    @if(session()->has('message'))
                                        <div class="alert alert-success text-center">
                                            {{ session()->get('message') }}
                                        </div>
                                    @endif
                                    @if(session()->has('success'))
                                        <div class="alert alert-success text-center">
                                            {{ session()->get('success') }}
                                        </div>
                                    @endif
                                    @if(session()->has('error'))
                                        <div class="alert alert-danger text-center">
                                            {!! session()->get('error') !!}
                                        </div>
                                    @endif
                                    <div class="form-group">
                                        <div class="position-relative has-icon-right">
                                            <label for="exampleInputUsername" class="sr-only">Email</label>
                                            <input type="email" id="email" required autocomplete="email" name="email"
                                                value="{{ old('email') }}" class="form-control form-control-rounded"
                                                placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="position-relative has-icon-right">
                                            <label for="exampleInputPassword" class="sr-only">Password</label>
                                            <input id="password" class="form-control form-control-rounded" required
                                                name="password" placeholder="Password">
                                        </div>
                                    </div>
                                    <button type="submit" class="btn btn-outline-primary btn-block waves-effect waves-light">
                                        Submit
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </section>
        <br>
    </div>
</div>