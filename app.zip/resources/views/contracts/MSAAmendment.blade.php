@extends('Includes.baseContract')

@section('route')
{{ route('exportMSAAmendment') }}
@endsection

@section('companyInformation')
@include('Includes.forms.amendmentCompanyInformation')
@endsection

@section('extra')
    @include('Includes.forms.products')

    <script src="{{ asset('js/jquery-ui.min.js') }}"></script>
    <link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">

    <script>
    $(document).ready(function() {
        $(function() {
            $('#datepicker').datepicker({
                maxDate: new Date,
            });
        });
    });
    </script>
@endsection

@section('name')
MSA Amendment
@endsection