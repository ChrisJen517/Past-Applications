@extends('Includes.baseContract')

@section('route')
{{ route('exportNonFCRAMSA') }}
@endsection

@section('companyInformation')
    @include('Includes.forms.companyInformation')
@endsection

@section('extra')
    @include('Includes.forms.products')
@endsection

@section('name')
Non FCRA MSA Contract
@endsection
