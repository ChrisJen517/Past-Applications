@extends('Includes.baseContract')

@section('route')
{{ route('exportYNAmendment') }}
@endsection

@section('companyInformation')
@include('Includes.forms.amendmentCompanyInformation')
@endsection

@section('extra')
<div class="mx-auto card w-75">
    <div class="card-body">
        <div class="row">
            <div class="offset-md-1 col-md-4">
                <h4 class="mb-0">Product Selection:</h4>
            </div>
            <div class="col-md-4">
                <h4 class="mb-0">Pricing Selection:</h4>
            </div>
        </div>
        <br />
        <div class="form-check">
            <div class="row">
                <div class="offset-md-1 col-md-4">
                    SMS Service
                </div>
                <div class="col-md-4" style="margin-bottom: 10px;">
                    <input class="form-control float-right" id="price3" step="0.001" name="price[2]"
                        type="number" value="0.01000" required>
                    <input hidden class="form-control" name="originalPrice[]" value="0.01500"
                        placeholder="originalPrice">
                    <input hidden class="form-control" name="managerPrice[]" value="0.01313" placeholder="managerPrice">
                    <input hidden class="form-control" name="jimPrice[]" value="0.01125" placeholder="jimPrice">
                    <input hidden class="form-control" name="name[]" value="SMS Service for Mass Communication"
                        placeholder="">
                    <input hidden class="form-control" name="prod_header_id[]" value="" placeholder="">
                    <input hidden class="form-control" name="reason[]" value="" placeholder="">
                    <textarea hidden class="form-control" name="description[]" value="In solution, optional to use. Charge per text sent in the YN platform"
                         placeholder="">In solution, optional to use. Charge per text sent in the YN platform</textarea>
                    <input hidden class="form-control" name="price_name[]" value="SMS Service for Mass Communication"
                        placeholder="">
                </div>
            </div>
        </div>
        <div class="form-check">
            <div class="row">
                <div class="offset-md-1 col-md-4">
                    eLetter
                </div>
                <div class="col-md-4" style="margin-bottom: 10px;">
                    <input class="form-control float-right" id="price4" min="0" step="0.01" name="price[4]"
                        type="number" value="0.30" required>
                    <input hidden class="form-control" name="originalPrice[]" value="0.30"
                        placeholder="originalPrice">
                    <input hidden class="form-control" name="managerPrice[]" value="0.20" placeholder="managerPrice">
                    <input hidden class="form-control" name="jimPrice[]" value="0.10" placeholder="jimPrice">
                    <input hidden class="form-control" name="name[]" value="eLetter"
                        placeholder="">
                    <input hidden class="form-control" name="prod_header_id[]" value="" placeholder="">
                    <input hidden class="form-control" name="reason[]" value="" placeholder="">
                    <textarea hidden class="form-control" name="description[]" value="Create custom eLetter templates in You Negotiate and RNN will deliver into Consumers You Negotiate eMailBox"
                         placeholder="">Create custom eLetter templates in You Negotiate and RNN will deliver into Consumers You Negotiate eMailBox</textarea>
                    <input hidden class="form-control" name="price_name[]" value="eLetter"
                        placeholder="">
                </div>
            </div>
        </div>

        <div class="form-check">
            <div class="row">
                <div class="offset-md-1 col-md-4">
                    RNN Fee Payment Method
                </div>
                <div class="col-md-3" style="margin-bottom: 10px;">
                    <select class="form-control" id="recurring_payment" name="recurring_payment" required>
                        <option value="auto ACH">Auto ACH</option>
                        <option value="auto credit card">Auto Credit Card</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="form-check">
            <div class="row">
                <div class="offset-md-1 col-md-4">
                    Payment Term
                </div>
                <div class="col-md-3" style="margin-bottom: 10px;">
                    <select class="form-control" id="payment_term" name="payment_term" required>
                        <option value="Weekly">Weekly</option>
                        <option value="Bi-Monthly">Bi-Monthly</option>
                        <option value="Monthly">Monthly</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="form-check">
            <div class="row">
                <div class="offset-md-1 col-md-12">
                    <span class="required">*</span> a 3% convenience fee for credit card (of RNN's fees)
                </div>
            </div>
        </div>

    </div>
    <script>
        $(document).ready(function() {
        setTimeout(() => {
            $('[name^="price["]').each(function() {
                $(this).rules("add", {
                    required: true,
                    decimal: true,
                    minimumPrice: true,
                    messages: {
                        min: "Invalid price"
                    }
                });
            })
        }, 0);
    });
    </script>
@endsection

@section('name')
YN Amendment
@endsection