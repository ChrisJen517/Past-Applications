@extends('Includes.baseContract')

@section('route')
{{ route('exportNameChangeAmendment') }}
@endsection

@section('companyInformation')
@include('Includes.forms.amendmentCompanyInformation')

    <hr>
    <br>
    <div class="col-lg-6">
        <div class="form-group row">
            <label class="col-lg-4 col-form-label form-control-label">New Company Name <span style="color:red">&#10033;</span></label>
            <div class="col-lg-8">
                <input class="form-control" id="new_name" name="new_name" type="text">
            </div>
        </div>
    </div>
@endsection

@section('extra')
    <script src="{{ asset('js/jquery-ui.min.js') }}"></script>
    <link href="{{ asset('css/jquery-ui.theme.min.css') }}" rel="stylesheet">
    <link href="{{ asset('css/jquery-ui.structure.min.css') }}" rel="stylesheet">

    <script>
    $(document).ready(function() {
        $(function() {
            $('#datepicker').datepicker({
                maxDate: new Date,
            });
        });
    });
    </script>
@endsection

@section('name', 'Name Change Amendment')