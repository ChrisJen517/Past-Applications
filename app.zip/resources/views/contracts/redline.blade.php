@extends('Includes.baseContract')

@section('route')
{{ route('exportRedlineStart') }}
@endsection

@section('companyInformation')
    @include('Includes.forms.companyInformation')
@endsection

@section('name', 'Redline Start Contract')