@extends('Includes.basicLayout')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-md-4 mx-auto">
            <div class="card">
                <div class="card-header">
                    <h1>Export NVN Report</h1>
                </div>
                <div class="card-body">
                    <form action="{{route('exportNVN')}}" method="POST" id="exportNVNForm" enctype="multipart/form-data">
                        @csrf
                        <div class="form-group row">
                            <div class="col-md-8">
                                <select class="form-control" name="state" id="state_selector" required>
                                    <option value="" selected disabled>Please Select a State</option>
                                    <option value="USA">United States of America</option>
                                    @foreach($states as $state)
                                    <option value="{{$state->state_name}}">{{$state->state_name}}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="col-md-2">
                                <button type="submit" id="submit" name="submit" value="submit" class="btn btn-primary btn-lg" style="height: 100%;">Submit</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script>
$(document).ready(function() {
    $('#exportNVNForm').on('submit', function(e) {
        e.preventDefault();
        $.LoadingOverlay('show');
        var formData = $(this).serialize();
        $.post('{{route("exportNVN")}}', formData, function(data, status) {
            $.LoadingOverlay('hide');
            if (data['error']) {
                swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                return;
            }
            if (status == 'success') {
                var fileName = data['fileName'];
                window.location.href = '/downloadExport/' + fileName;
            } else {
                swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
            }
        });
    });
});
</script>
@endsection
