@extends('Includes.baseContract')

@section('route')
{{ route('exportNDA') }}
@endsection

@section('companyInformation')
    @include('Includes.forms.companyInformation')
@endsection

@section('name', 'NDA Contract')