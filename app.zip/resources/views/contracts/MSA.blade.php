@extends('Includes.baseContract')

@section('route')
{{ route('exportMSA') }}
@endsection

@section('companyInformation')
    @include('Includes.forms.companyInformation')
@endsection

@section('extra')
    @include('Includes.forms.products')
@endsection

@section('name')
Standard FCRA MSA Contract
@endsection
