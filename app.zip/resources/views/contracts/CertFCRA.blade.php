@extends('Includes.baseContract')

@section('route')
{{ route('exportCertFCRA') }}
@endsection

@section('companyInformation')
    @include('Includes.forms.companyInformation')
@endsection

@section('name', 'Certification FCRA Contract')