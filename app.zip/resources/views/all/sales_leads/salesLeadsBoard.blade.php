@extends('Includes.basicLayout')
@section('content')
<link href="{{asset('css/leadsBoard.css?'.time())}}" rel="stylesheet" />
<div class="lead-board" id="mainBody">
    <div class="task-board">
        @for($i = 0; $i < sizeof($statuses); $i++)
        <div class="status-card-wrapper">
            <div class="status-card">
                <div class="status-header">
                    <span class="card-header-text">{{$statuses[$i]}}</span>
                </div>
                <div class="status">
                    <ul class="sortable ui-sortable" id="sort-{{$i}}" data-column="{{$i}}">
                    @if (!empty($cards))
                        @foreach ($cards[$i] as $card)
                        <li class="text-row ui-sortable-handle product" onmousedown="setInfo('{{$card->company_name}}', '{{$card->id}}')" data-id="{{$card->id}}" data-position="{{$card->column_position}}">
                            {{$card->company_name}} {{ $card->industry != null ? '- ' . $card->industry : ''}}
                            <br>
                            <span style="font-size: 11px;">Last worked: {{$card->last_worked != null ? $card->last_worked : 'not worked'}}</span>
                        </li>
                        @endforeach
                    @endif
                    </ul>
                </div>
                <div class="new-company-wrapper text-center">
                    {{-- <a class="input-placeholder float-left" id="text-placeholder-{{$i}}" onclick="showInput('{{$i}}')">
                        <i class="fas fa-plus"></i>
                        Add a new lead...
                    </a>
                    <textarea class="new-company-input" id="text-{{$i}}" data-id="{{$i}}" cols="30" rows="1" placeholder="Company Name" onkeydown="addCard('sort-{{$i}}', 'text-{{$i}}')" style="display: none;"></textarea> --}}
                </div>
            </div>
        </div>
        @endfor
        {{-- <a onclick="reorderCards()" class="btn btn-primary ml-auto" style="color: white;">Save Lead Order</a> --}}
    </div>
</div>

<div class="modal fade" id="cardInfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
    <div class="modal-dialog modal-xxl" role="document">
        <div class="modal-content border-0">
            <div class="modal-body" id="showLeadDiv" style="min-height:20px; max-height:calc(100vh - 100px); overflow-y: auto; overflow-x:hidden;">
            </div>
        </div>
    </div>
</div>

<script src="{{asset('js/modal.js?'.time())}}"></script>
<script src="{{asset('js/jquery-ui.min.js')}}"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="{{asset('js/leadBoard.js')}}"></script>
<script>
function addCard(location, text) {
    if (event.keyCode == 13) {
        event.preventDefault();

        var company_name = document.getElementById(text).value;
        var user_id = {{ Auth::user()->id}};

        swal.fire({
            title: "Are you sure?",
            text: "You are about to create a sales lead for the company " + company_name + ".",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: 'Create'
        }).then((willSave) => {
            if (willSave.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post("/createSalesLead", {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            company_name: company_name,
                            user_id: user_id
                        })
                        .done(function(data) {
                            updated = false;
                            $.LoadingOverlay("hide");
                            $("#"+location).append(
                                `<li class="text-row product ui-sortable-handle" onmousedown="setInfo(' + "'" + '${company_name}, ${data['lead_id']} +' + "'" + ')" data-id="${data['lead_id']}" data-position="${data['column_position']}"> ${company_name} </li>`
                            );
                            swal.fire(
                                "Success",
                                "Lead has been created.",
                                "success"
                            );
                        });
                });
            } else {
                swal.fire(
                    "Cancelled",
                    "Lead was not created!",
                    "error"
                );
            }
        document.getElementById(text).value = "";
        });
    }
}

//opens the worklead within the modal if it is just clicked
var held;
$("#mainBody").on('mousedown', 'div.product', function() {
    held = false;
    setTimeout(function() {
        held =  true;
    }, 500);
}).on('mouseup',function(){
    if((!held) && (cardTitle != null)){
        $('#cardInfo').modal('show');
        $('#myModalLabel').html(cardTitle);

        var url = "{{ asset('/workLead/modal/:id') }}"
        url = url.replace(':id', cardId);

        $('#showLeadDiv').LoadingOverlay("show");

        $('#showLeadDiv').load(url, function(data, statusText, xhr){
            //checks if the response text is that of the login page if so, redirects the page
            if (xhr.responseText.trim().startsWith("<!DOCTYPE html>")) {
                window.location.href = "/";
            }
            $('#showLeadDiv').LoadingOverlay("hide", true);
        });
    }
});
</script>
@endsection
