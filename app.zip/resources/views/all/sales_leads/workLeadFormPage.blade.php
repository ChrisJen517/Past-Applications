@extends('Includes.basicLayout')
@section('content')

    @include('all.sales_leads.workLeadForm')
    
@endsection