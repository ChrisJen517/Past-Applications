@extends('Includes.basicLayout')
@section('content')

<link href="{{asset('css/workForm.css')}}" rel="stylesheet" />
<div class="row">
    <div class="col-md-4">
        @include('Includes.widgets.eventWidget')
    </div>
</div>
<form action="{{route('updateLead')}}" method="POST" enctype="multipart/form-data" id="Update">
    {{ csrf_field() }}
    <div class="row" style="margin-left:0.2%">
        <div class="col-lg-8" style="margin-top:65px;">
            <div class="card">
                <div class="card-body">
                    <h4 class="form-header text-uppercase">
                        <i class="fa fa-address-book-o"></i>
                        Sales Lead Data
                    </h4>
                    <hr>
                    <div class="mainBody">
                        <input type="hidden" name="lead_id" value="{{$lead->id}}">
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">Company Name:</label>
                                <div class="input-group mb-3">
                                <input class="form-control" name="company_name" id="company_name" type="text" value="{{$lead->company_name}}" readonly>
                                <div class="input-group-append input-google">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <hr>
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">Company Phone<span class="conditional">*</span>:</label>
                                <div class="input-group mb-3">

                                    <input class="form-control" name="company_phone" id="company_phone" type="text" placeholder="Company Phone" value="{{$lead->company_phone}}">
                                    <div class="input-group-append input-google">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                    <div class="input-group-append input-phone" onclick="callNumber();">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-phone" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-control-label">Company Email:</label>
                                <div class="input-group mb-3">
                                    <input class="form-control" name="company_email" id="company_email" type="text" placeholder="Contact Email" value="{{$lead->company_email}}">
                                    <div class="input-group-append input-google">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">Company Fax<span class="conditional">*</span>:</label>
                                <div class="input-group mb-3">
                                <input class="form-control" name="company_fax" id="company_fax" type="text" placeholder="Company Fax" value="{{$lead->company_fax}}">
                                <div class="input-group-append input-google">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-control-label">Industry<span class="conditional">*</span>:</label>
                                <select id="industry" name="industry" class="form-control" size="0" value="{{$lead->industry}}" required>
                                    <option value="" selected disabled>Industry</option>
                                    <option value="Bank: All Other">Bank: All Other</option>
                                    <option value="Bank: Top 200">Bank: Top 200</option>
                                    <option value="Bank Association">Bank Association</option>
                                    <option value="Collection Agency">Collection Agency</option>
                                    <option value="Collection Law Firm">Collection Law Firm</option>
                                    <option value="Consulting Company">Consulting Company</option>
                                    <option value="Credit Union">Credit Union</option>
                                    <option value="Debt Buyer">Debt Buyer</option>
                                    <option value="Financial Services">Financial Services</option>
                                    <option value="Government: City">Government: City</option>
                                    <option value="Government: County">Government: County</option>
                                    <option value="Government: State">Government: State</option>
                                    <option value="Government: Federal">Government: Federal</option>
                                    <option value="Healthcare">Healthcare</option>
                                    <option value="Loan Originator: Auto">Loan Originator: Auto</option>
                                    <option value="Loan Originator: Credit Card">Loan Originator: Credit Card</option>
                                    <option value="Loan Originator: FinTech">Loan Originator: FinTech</option>
                                    <option value="Loan Originator: Mortgage">Loan Originator: Mortgage</option>
                                    <option value="Loan Originator: Other">Loan Originator: Other</option>
                                    <option value="Loan Originator: Student Loan">Loan Originator: Student Loan</option>
                                    <option value="Private Equity Firm">Private Equity Firm</option>
                                    <option value="Service Provider">Service Provider</option>
                                    <option value="Software">Software</option>
                                    <option value="University">University</option>
                                    <option value="Vendor">Vendor</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <hr>
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">Select CAPCODE<span class="required">*</span>:</label>
                                <select class="col-lg-12" name="capcode" id="capcode" style="height:35px; border-radius:5px;" value="{{$lead->capcode}}" required>
                                    <option value="" selected disabled> - Select CapCode - </option>
                                    <option value="1000">1000 - Lead Data Complete</option>
                                    <option value="2000">2000 - Lead Needs More Work</option>
                                </select>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-control-label">Company Website URL<span class="conditional">*</span>:</label>
                                <div class="input-group mb-3">
                                <input class="form-control" name="company_url" id="company_url" type="text" placeholder="Third Party Name" value="{{$lead->company_url}}">
                                <div class="input-group-append input-google">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">Address:</label>
                                <div class="input-group mb-3">
                                <input class="form-control" name="address" id="address" type="text" placeholder="Address" value="{{$lead->company_address}}">
                                <div class="input-group-append input-google">
                                        <span class="input-group-text">
                                            <i class="zmdi zmdi-google" style="color:blue" aria-hidden="true"></i>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-control-label">City:</label>
                                <input class="form-control" name="city" id="city" type="text" placeholder="City" value="{{$lead->company_city}}">
                            </div>
                        </div>
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">State:</label>
                                <select id="state" name="state" class="form-control" size="0" value="{{$lead->company_state}}">
                                    <option value="">State</option>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CAN">Canada</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="PR">Puerto Rico</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </select>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-control-label">Zip:</label>
                                <input class="form-control" name="zip" id="zip" type="number" placeholder="Zip" value="{{$lead->company_zip}}">
                            </div>
                        </div>
                        <hr>
                        <div class="form-group row">
                            <label class="col-lg-8 col-form-label form-control-label">Company Contacts:</label>
                            <div class="col-lg-12">
                                <button type="button" class="btn btn-primary btn-lg" data-toggle="modal" data-target="#ContactModal">
                                    Add New Contact
                                </button>
                                <br />
                                <br />

                                <table class="table table-striped" id="contacts_table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Title</th>
                                            <th scope="col">First Name</th>
                                            <th scope="col">Last Name</th>
                                            <th scope="col">Email Address</th>
                                            <th scope="col">Phone Number</th>
                                            <th scope="col">Linked In</th>
                                            <th scope="col">Edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($lead_contacts as $item)
                                        <tr style="height:50px;">
                                            <td id="contact_{{$item->id}}" class="text-center" value="{{$item->id}}">{{$item->lead_title}}</td>
                                            <td id="first_name_{{$item->id}}" class="text-center">{{$item->first_name}}</td>
                                            <td id="last_name_{{$item->id}}" class="text-center">{{$item->last_name}}</td>
                                            <td id="phone_{{$item->id}}" class="text-center">{{$item->phone}}</td>
                                            <td id="email_{{$item->id}}" class="text-center">{{$item->email}}</td>
                                            <td id="linked_in_{{$item->id}}" class="text-center">{{$item->linked_in}}</td>
                                            <td class="text-center"> <a data-toggle="modal" d-lead_id="{{$item->id}}" d-lead_title="{{$item->lead_title}}" d-lead_first_name="{{$item->first_name}}" d-lead_last_name="{{$item->last_name}}" d-lead_phone="{{$item->phone}}" d-lead_email="{{$item->email}}" d-lead_linked_in="{{$item->linked_in}}" data-target="#ContactModal" class="btn btn-primary btn-xlg text-white">
                                                    Edit
                                                </a> </td>

                                        </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <div class="loader my-5 ml-5" id="loader" style="display:none">
                                </div>
                            </div>
                        </div>
                        <hr>
                        <div class="row infoRow">
                            <div class="col-lg-6">
                                <label class="form-control-label">Notes:</label>
                                <textarea class="form-control" name="notes" id="notes" type="text" value="{{$lead->notes}}" limit="250" placeholder="Notes">{{$lead->notes}}</textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <input id="update" class="btn btn-lg btn-danger float-right" name="submit" type="submit" value="update" style="margin-left:5px" />
                    <input id="update_and_next" class="btn btn-lg btn-success float-right" name="submit" type="submit" value="update_and_next" />
                </div>
            </div>
        </div>
        <div class="col-lg-4" style="margin-top:65px;">
            <div class="card">
                <div class="card-body">
                    <h4 class="form-header text-uppercase">
                        <i class="fa fa-address-book-o"></i>
                        Employer Information
                    </h4>
                    <hr>
                    Direct Call: select & press CTRL+SHIFT+C
                    <br>
                    <input class="form-control" name="phone_wrapper" id="phone_wrapper" type="text" placeholder="Company Phone" value="{{$lead->company_phone}}">
                    <br>
                    <br>
                    <div class="form-group row">
                        <label class="col-lg-8 col-form-label form-control-label">Total Employees:</label>
                        <div class="col-lg-12">
                            <input class="form-control" name="employees_count" id="employees_count" type="number" value="{{$lead->employees_count}}">
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <span class="required">*</span> - Required to Save/Update status
                    <br>
                    <span class="conditional">*</span> - Conditonally required depending on selected CapCode
                </div>
            </div>
        </div>
    </div>
</form>

<div class="row" style="margin-right:2%;">
    <div class="card col-lg-12">
        <div class="card-body">
            <h4 class="form-header text-uppercase">
                <i class="fas fa-history"></i>
                History
            </h4>
            <div class="table-responsive fixed-table-body">
                <table class="table table-striped" style="width:100%;">
                    <thead>
                        <tr>
                            <th class="text-center">Date</th>
                            <th class="text-center">Agent</th>
                            <th class="text-center">CapCode</th>
                            <th class="text-center">Notes</th>
                            <th class="text-center">Change Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($history as $item)
                        <tr style="height:50px;">
                            <td class="text-center">{{$item->created_at}}</td>
                            <td class="text-center">{{$item->agent_id}} @if($item->agent_name != null) - {{$item->agent_name}} @endif</td>
                            <td class="text-center">{{$item->capcode}}</td>
                            <td class="text-center" style="width:30%;">{{$item->notes}}</td>
                            <td class="text-center" style="width:30%;">{{$item->change_notes}}</td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>

            </div>
        </div>
    </div>

</div>
<!-- Modal HTML Markup -->
<div id="ContactModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Contact Info</h3>
            </div>
            <div class="modal-body">
                <form role="form" id="add_contact_form" method="POST">
                    {{ csrf_field() }}
                    <input type="hidden" name="lead_reference_id" value="{{$lead->id}}">
                    <input type="hidden" name="contact_id" value="">
                    <div class="form-group">
                        <label class="form-control-label">Select Contact Title<span class="required">*</span>:</label>
                        <select name="lead_title" id="lead_title" style="height:35px; border-radius:5px;">
                            <option value="" disabled> - Select Title - </option>
                            <option value="Collection Manager">Collection Manager</option>
                            <option value="Chief Information Officer">Chief Information Officer</option>
                            <option value="Operations Manager">Operations Manager</option>
                            <option value="Financial Executive">Financial Executive</option>
                            <option value="Chief Executive Officer">Chief Executive Officer</option>
                            <option value="Chief Financial Officer">Chief Financial Officer</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="control-label">First Name</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_first_name" name="lead_first_name" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Last Name</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_last_name" name="lead_last_name" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">E-Mail Address</label>
                        <div>
                            <input type="email" class="form-control input-lg" id="lead_email" name="lead_email" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Phone Number</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_phone" name="lead_phone" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Linked-In </label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_linked_in" name="lead_linked_in" value="">
                        </div>
                    </div>

                </form>
                <div class="form-group">
                    <div>
                        <button id="save_update_contact" class="btn btn-success">
                            Save / Update
                        </button>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->

<script src="{{ asset('js/jquery-ui.min.js') }}"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

<script>
    //calls current phone number
    function callNumber() {
        var number = $('#company_phone').val();
        var link = "tel:" + number;
        window.location.href = link;
    }

    $(document).ready(function() {

        var industry = {!! json_encode($lead->industry) !!};
        $('#industry').attr('value', industry);
        $('#industry option[value="' + industry + '"]').attr('selected', 'selected');

        var capcode = {!! json_encode($lead->capcode) !!};
        $('#capcode').attr('value', capcode);
        $('#capcode option[value="' + capcode + '"]').attr('selected', 'selected');

        var state = {!! json_encode($lead->company_state) !!};
        $('#state').attr('value', state);
        $('#state option[value="' + state + '"]').attr('selected', 'selected');

        $("#add_contact_form").validate({
            rules: {
                lead_title: {
                    required: true
                },
                lead_first_name: {
                    required: true
                }
            }
        });

        $("#Update").validate({
            rules: {
                capcode: {
                    required: true
                }
            }
        });


        $('#ContactModal').on('show.bs.modal', function(e) {
            // get information to update quickly to modal view as loading begins
            var opener = e.relatedTarget; //this holds the element who called the modal
            //we get details from attributes
            var lead_id = $(opener).attr('d-lead_id');
            var lead_title = $(opener).attr('d-lead_title');
            var lead_first_name = $(opener).attr('d-lead_first_name');
            var lead_last_name = $(opener).attr('d-lead_last_name');
            var lead_email = $(opener).attr('d-lead_email');
            var lead_phone = $(opener).attr('d-lead_phone');
            var lead_linked_in = $(opener).attr('d-lead_linked_in');


            //set what we got to our form
            $('#add_contact_form').find('[name="contact_id"]').val(lead_id);
            $('#add_contact_form').find('[name="lead_title"]').val(lead_title);
            $('#add_contact_form').find('[name="lead_first_name"]').val(lead_first_name);
            $('#add_contact_form').find('[name="lead_last_name"]').val(lead_last_name);
            $('#add_contact_form').find('[name="lead_email"]').val(lead_email);
            $('#add_contact_form').find('[name="lead_phone"]').val(lead_phone);
            $('#add_contact_form').find('[name="lead_linked_in"]').val(lead_linked_in);

        });


        $("#save_update_contact").click(function(e) {
            $('#contacts_table').delay(25).fadeOut();
            $('#loader').delay(25).fadeIn();
            if ($("#add_contact_form").valid() == false)
                return false;
            $('#contacts_table').delay(450).fadeOut();
            $('#loader').delay(25).fadeIn();


            var lead_title = $("#lead_title").val();
            if (lead_title == null) lead_title = '';
            var first_name = $("#lead_first_name").val();
            if (first_name == null) first_name = '';
            var last_name = $("#lead_last_name").val();
            if (last_name == null) last_name = '';
            var email = $("#lead_email").val();
            if (email == null) email = '';
            var phone = $("#lead_phone").val();
            if (phone == null) phone = '';
            var linked_in = $("#lead_linked_in").val();
            if (linked_in == null) linked_in = '';

            var existingcontact = !($('#add_contact_form').find('[name="contact_id"]').val() === "");

            var id = $('#add_contact_form').find('[name="contact_id"]').val();

            //$("#contacts_table").children('tbody').append(markup);

            var form = document.getElementById("add_contact_form");
            var formData = $(form).serialize();

            var markup = '<tr><td class="text-center" id="contact_' + id + '">' + lead_title + '</td>' +
                '<td class="text-center">' + first_name + '</td>' +
                '<td class="text-center">' + last_name + '</td>' +
                '<td class="text-center">' + email + '</td>' +
                '<td class="text-center">' + phone + '</td>' +
                '<td class="text-center">' + linked_in + '</td>' +
                '<td class="text-center"><a data-toggle="modal"' +
                ' d-lead_id="' + id +
                '" d-lead_title="' + lead_title +
                '" d-lead_first_name="' + first_name +
                '" d-lead_last_name="' + last_name +
                '" d-lead_phone="' + phone +
                '" d-lead_email="' + email +
                '" d-lead_linked_in="' + linked_in +
                '" data-target="#ContactModal" class="btn btn-primary btn-lg text-white"> Edit </a> </td>' +
                '</tr>';
            if (existingcontact)
                $("#contact_" + id).closest('tr').replaceWith(markup);


            $.ajax({
                type: 'POST',
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                },
                url: '/addLead',
                data: formData,
                success: function(text) {
                    $('#contacts_table').delay(450).fadeIn();
                    $('#loader').delay(25).fadeOut();

                    var markup = '<tr><td class="text-center" id="contact_' + text + '">' + lead_title + '</td>' +
                        '<td class="text-center">' + first_name + '</td>' +
                        '<td class="text-center">' + last_name + '</td>' +
                        '<td class="text-center">' + email + '</td>' +
                        '<td class="text-center">' + phone + '</td>' +
                        '<td class="text-center">' + linked_in + '</td>' +
                        '<td class="text-center"><a data-toggle="modal"' +
                        ' d-lead_id="' + text +
                        '" d-lead_title="' + lead_title +
                        '" d-lead_first_name="' + first_name +
                        '" d-lead_last_name="' + last_name +
                        '" d-lead_phone="' + phone +
                        '" d-lead_email="' + email +
                        '" d-lead_linked_in="' + linked_in +
                        '" data-target="#ContactModal" class="btn btn-primary btn-lg"> Edit </a> </td>' +
                        '</tr>';
                    if (!existingcontact)
                        $("#contacts_table").children('tbody').append(markup);
                }
            });
            $('#ContactModal').modal('toggle');
        });
    });
    $(document).ready(function() {
        $(".input-google").click(function() {
            var inputId = $(this).parent().find('.form-control').attr('id');
            var input = $(this).parent().find('.form-control').val();
            if (inputId == 'address') {
                if (input != '') {
                    var emp_city = $('#city').val();
                    console.log(emp_city);
                    var emp_zip = $('#zip').val();
                    var emp_state = $('#state').val();
                    window.open('https://www.google.com/search?q=' + input + ', ' + emp_city + ', ' + emp_state + ', ' + emp_zip, '_blank');
                }
            }

            if (input != '') {
                window.open('https://www.google.com/search?q=' + input, '_blank');
            }
        })

        //checks for ctrl shift + c
        $('#phone_wrapper').on('keydown', function ( e ) {
            if ((e.metaKey || e.ctrlKey) && ( String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
                console.log('called');
                e.preventDefault();
                callNumber($('#phone_wrapper').text());
            }
        });

        $('#company_phone').on('keydown', function ( e ) {
            if ((e.metaKey || e.ctrlKey) && ( String.fromCharCode(e.which).toLowerCase() === 'c') && (e.shiftKey)) {
                console.log('called');
                e.preventDefault();
                callNumber($('#company_phone').text());
            }
        });

        //calls selected phone number
        function callNumber(phoneNumber) {
            var link = "tel:"+phoneNumber;
            window.location.href = link;
        }
    });
</script>


@endsection
