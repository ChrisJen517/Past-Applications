@extends('Includes.basicLayout')
@section('content')

<br />
<div class="container-fluid">
    <div class="row">
        <div class="mx-auto card" style="width: 30%; overflow: overlay;">
            <div class="card-header">
                <h4 class="mb-0">User Information</h4>
            </div>
            <div class="card-body">
                <form action="{{ route('updateAccount') }}" method="POST" enctype="multipart/form-data"
                    id="user_information_form">
                    @csrf
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">First name</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="firstname" type="text"
                                value={{ Auth::user()->name_first }}>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Last name</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="lastname" type="text" value={{ Auth::user()->name_last }}>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Email</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off" name="email" type="email"
                                value={{ Auth::user()->email }} readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Role</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="role" type="text" value={{ Auth::user()->role }} readonly>
                        </div>
                    </div>
                    @if (Auth::user()->role == 'agent')
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Manager Email</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off" name="manager_email"
                                type="email" value="{{ Auth::user()->manager_email }}" readonly>
                        </div>
                    </div>
                    @endif
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Avatar</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input"
                                id="customFileInput" name="avatar" id="avatar" type="file">
                            <label class="custom-file-label" for="customFileInput"
                                style="margin: 0px 15px 0px 15px;">Choose file...</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Background:</label>
                        <div class="col-lg-9" style="margin-top:1.5%">
                            <div class="form-check-inline">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" id="background_image"
                                        name="background_type" onchange="unhide(1)" value="1">Image
                                </label>
                            </div>
                            <div class="form-check-inline">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" id="background_color"
                                        name="background_type" onchange="unhide(2)" value="2">Color
                                </label>
                            </div>
                            <div class="form-check-inline">
                                <label class="form-check-label">
                                    <input type="radio" class="form-check-input" id="background_none"
                                        name="background_type" onchange="unhide(3)" value="3">Default
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row" id="backgroundImage" hidden>
                        <label class="col-lg-3 col-form-label form-control-label">Image:</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input"
                                id="customBackgroundInput" name="customBackgroundInput" type="file">
                            <label class="custom-file-label" for="customBackgroundInput"
                                style="margin: 0px 15px 0px 15px;">Choose file...</label>
                        </div>
                    </div>
                    <div class="form-group row" id="backgroundColor" hidden>
                        <label class="col-lg-3 col-form-label form-control-label">Color:</label>
                        <div class="col-lg-9">
                            <input type="color" name="customBackgroundColor" id="customBackgroundColor"
                                @if(Auth::user()->background_color != null)
                            value="{{Auth::user()->background_color}}"
                            @else
                            value="#636363"
                            @endif
                            >
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">New Password</label>
                        <div class="col-lg-9">
                            <input autocomplete="new-password" class="form-control" id="newPassword" name="newPassword"
                                type="password" Placeholder="Enter only if you want to change">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Confirm New Password</label>
                        <div class="col-lg-9">
                            <input class="form-control" id="confirmPassword" name="confirmPassword" type="password">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label"></label>
                        <div class="col-lg-9">
                            <input id="submit-button-2" type="submit" class="btn btn-primary float-right"
                                value="Save Changes">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-12" id="pswd_info" style="display: none;">
                            <h4>Password requirements:</h4>
                            <ul style="font-size: 12px;">
                                <li id="length" class="invalid">Be at least <strong>10 characters (Max 32)</strong></li>
                                <li id="number" class="invalid">At least <strong>one number</strong></li>
                                <li id="letter_lower" class="invalid">At least <strong>one lowercase letter</strong>
                                </li>
                                <li id="letter_upper" class="invalid">At least <strong>one capital letter</strong></li>
                                <li id="special" class="invalid">At least <strong>one special character
                                        (#?!@$%^&*-)</strong></li>
                            </ul>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function () {
    jQuery.validator.addMethod("passwordCorrectRules", function(value, element) {
        return this.optional(element) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!#%*?&])[A-Za-z\d@$!#%*?&]{10,32}$/.test(value);
    }, "Must follow password rules");

    // form front-end validation
    $('#user_information_form').validate({
        rules: {
            firstname: {
                required: true
            },
            lastname: {
                required: true
            },
            email: {
                required: true,
                email: true
            },
            newPassword:{
                required: function(element) {
                    return $("#newPassword").val()!="";
                },
                passwordCorrectRules: function(element) {
                    return $("#newPassword").val()!="";
                }
            },
            confirmPassword:{
                required: function(element) {
                    return $("#newPassword").val()!="";
                },
                equalTo:'#newPassword'
            }
        },
        messages: {
            confirmPassword: "Passwords do not match"
        }
    });

    $('input[name=newPassword]').keyup(function() {
        var pswd = $(this).val();

        //validate length
        if (pswd.length < 10 && pswd.length < 33) {
            $('#length').removeClass('valid').addClass('invalid');
        } else {
            $('#length').removeClass('invalid').addClass('valid');
        }

        //validate capital letter
        if (pswd.match(/[A-Z]/)) {
            $('#letter_upper').removeClass('invalid').addClass('valid');
        } else {
            $('#letter_upper').removeClass('valid').addClass('invalid');
        }

        //validate lowercase letter
        if (pswd.match(/[a-z]/)) {
            $('#letter_lower').removeClass('invalid').addClass('valid');
        } else {
            $('#letter_lower').removeClass('valid').addClass('invalid');
        }

        //validate number
        if (pswd.match(/\d/)) {
            $('#number').removeClass('invalid').addClass('valid');
        } else {
            $('#number').removeClass('valid').addClass('invalid');
        }

        //validate special character
        if (pswd.match(/^(?=.*?[#?!@$%^&*-])/)) {
            $('#special').removeClass('invalid').addClass('valid');
        } else {
            $('#special').removeClass('valid').addClass('invalid');
        }
    }).focus(function() {
        // Keep width static, change height when depending on focus on password.
        $('#pswd_info').slideDown(500);
    }).blur(function() {
        $('#pswd_info').hide(500);
    });

    // Validate avatar file
    $(".custom-file-input").on("change", function() {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index).toLowerCase();
            if (fileSize > ($(this).hasClass('background') ? 1502500 : 51200)) //check file size
            {
                swal.fire({
                    title: "File size too large!",
                    text: "Image size cannot exceed " + ($(this).hasClass('background') ? "1.5MB" : "50kb"),
                    icon: "warning"
                })

                $(this).val("");
            }

            else if (ext != '.jpg' && ext != '.jpeg' && ext != '.png') //check file extension type
            {

                swal.fire({
                    title: "Wrong file type",
                    text: "Must be .jpg, .jpeg, or .png",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }

            if ($(this).val() != "") {
                var fileName = $(this).val().split("\\").pop();
                $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
            }
        }
    });
});

    function unhide(tab){
        if(tab == 1){
            document.getElementById("backgroundImage").hidden = false;
            document.getElementById("backgroundColor").hidden = true;
        }
        else if(tab == 2){
            document.getElementById("backgroundImage").hidden = true;
            document.getElementById("backgroundColor").hidden = false;
        }
        else{
            document.getElementById("backgroundImage").hidden = true;
            document.getElementById("backgroundColor").hidden = true;
        }
    }

    $("#user_information_form").on( "submit",function(){
        if($(this).valid())
            $.LoadingOverlay("show");
    });
</script>
@endsection
