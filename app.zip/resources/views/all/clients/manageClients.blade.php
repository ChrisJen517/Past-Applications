@extends('Includes.basicLayout')
@section('content')

@include('Includes.modal.manageClients.sendCompanyEmail')
@include('Includes.modal.manageClients.viewCompanyEmail')

<link href="{{asset('css/multiTableProcessing.css?'.time())}}" rel="stylesheet" />
<section id="upload-history">
    <div class="container-fluid">
            <section id="previous-uploads-header">
                <div class="container-fluid">
                    <div class="row text-left">
                        <div class="col text-left">
                            <p>Manage Clients / Vendors</p>
                        </div>
                    </div>
                </div>
            </section>
            <a class="btn btn-primary float-left mb-3" style="margin-left:15px;" href="{{route('showAddClient')}}">Add
                Client / Vendor</a>
            <div class="table-responsive" id="client-table-div">
                <table class="table table-striped table-bordered" id="client-table">
                    <thead>
                        <tr>
                            <th class="text-center">Company ID</th>
                            <th class="text-center">Company Name</th>
                            <th class="text-center">Company State</th>
                            <th class="text-center">Company Address</th>
                            <th class="text-center">Company City</th>
                            <th class="text-center">Company Zip Code</th>
                            <th class="text-center">Company Primary Email</th>
                            <th class="text-center">Edit Client</th>
                            <th class="text-center">Send Company Email</th>
                            <th class="text-center">View Emails</th>
                            <th class="text-center">Archive</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        <br>
        <hr>
        <br>
        <section id="previous-uploads-header">
                <div class="container-fluid">
                    <div class="row text-left">
                        <div class="col text-left">
                            <p>Archived Clients</p>
                        </div>
                    </div>
                </div>
            </section>
            <div class="table-responsive" id="archived-client-table-div">
                <table class="table table-striped table-bordered" id="archived-client-table">
                    <thead>
                        <tr>
                            <th class="text-center">Company ID</th>
                            <th class="text-center">Company Name</th>
                            <th class="text-center">Company State</th>
                            <th class="text-center">Company Address</th>
                            <th class="text-center">Company City</th>
                            <th class="text-center">Company Zip Code</th>
                            <th class="text-center">Company Primary Email</th>
                            <th class="text-center">Edit Client</th>
                            <th class="text-center">Un-Archive</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>

    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src={{asset('js/modal.js?'.time())}}></script>

<script>
    $(document).ready(function() {
        $('#client-table').DataTable({
            "order":[[0,"desc"]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "language": {
                'loadingRecords': '&nbsp;',
                "processing": '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": "{{ route('getClientTable') }}",
                "dataType": "json",
                "type": "GET",
                "data": {
                    "_token": "{{csrf_token()}}",
                }
            },
            "columns": [
                { "data": "id" },
                { "data": "company_name" },
                { "data": "company_state" },
                { "data": "company_address" },
                { "data": "company_city" },
                { "data": "company_zip" },
                {
                    "data": "company_email",
                    "class": "text-center",
                    "style": "word-break:break-all",
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        let route = "/manageClients/edit/" + id;
                        return `
                            <td class="text-center">
                                <form action="${route}" method="get" enctype="multipart/form-data"
                                    id="user_information_form">
                                    {{ csrf_field() }}
                                    <input id="submit-button-2" type="submit" class="btn btn-primary btn-sm"
                                        role="button" value="Edit Client">
                                </form>
                            </td>`;
                    }
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        return `
                            <td class="text-center">
                                <button class="btn btn-info" data-toggle="modal" data-target="#sendEmailFormModal" 
                                    data-company_email="${row.company_email}" 
                                    data-payable_email="${row.account_payable_email}" 
                                    data-approver_email="${row.invoice_approver_email}" 
                                    data-contact_email="${row.executive_contact_email}" 
                                    data-id="${id}">
                                    Send
                                </button>
                            </td>`;
                    }
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        return `
                            <td class="text-center">
                                <button class="btn btn-primary" data-toggle="modal" data-target="#viewEmailsModal" 
                                    data-id="${id}">
                                    View
                                </button>
                            </td>`;
                    }
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        
                        return `
                            <td class="text-center">
                                <button class="btn btn-danger" onclick="archiveClient(${id}, '${row.company_name}')">Archive</button>
                            </td>`;
                    }
                },
            ],
            
            "lengthMenu": [[10, 25, 50, 100], [10, 25, 50, 100]],
            dom: 'Blfrtip',
            "pageLength": 10,
            buttons: [
                'excelHtml5',
                'pdfHtml5'
            ],
            initComplete: function() {
                var input = $("#client-table-div .dataTables_filter input").unbind();
                var self = this.api();

                $("#client-table-div .dataTables_filter input").keyup(function (e) {
                    // Allows use of Enter key for searching
                    if (e.keyCode == 13)
                        self.search(input.val().replace(/['"]+/g, '')).draw();
                }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                ).text("search")
                .click(function () {
                    self.search(input.val().replace(/['"]+/g, '')).draw();
                }));
                $("#client-table-div .dataTables_filter").append($searchButton);
            }
        });

        $('#archived-client-table').DataTable({
            "order":[[0,"desc"]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "language": {
                'loadingRecords': '&nbsp;',
                "processing": '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": "{{ route('getArchivedClientTable') }}",
                "dataType": "json",
                "type": "GET",
                "data": {
                    "_token": "{{csrf_token()}}",
                }
            },
            "columns": [
                { "data": "id" },
                { "data": "company_name" },
                { "data": "company_state" },
                { "data": "company_address" },
                { "data": "company_city" },
                { "data": "company_zip" },
                {
                    "data": "company_email",
                    "class": "text-center",
                    "style": "word-break:break-all",
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        let route = "/manageClients/edit/" + id;
                        return `
                            <td class="text-center">
                                <form action="${route}" method="get" enctype="multipart/form-data"
                                    id="user_information_form">
                                    {{ csrf_field() }}
                                    <input id="submit-button-2" type="submit" class="btn btn-primary btn-sm"
                                        role="button" value="Edit Client">
                                </form>
                            </td>`;
                    }
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        return `
                            <td class="text-center">
                                <button class="btn btn-danger" onclick="unarchiveClient(${id}, '${row.company_name}')">Unarchive</button>
                            </td>`;
                    }
                },
            ],
            "lengthMenu": [[10, 25, 50, 100], [10, 25, 50, 100]],
            dom: 'Blfrtip',
            "pageLength": 10,
            buttons: [
                'excelHtml5',
                'pdfHtml5'
            ],
            initComplete: function() {
                var input = $("#archived-client-table-div .dataTables_filter input").unbind();
                var self = this.api();

                $("#archived-client-table-div .dataTables_filter input").keyup(function (e) {
                    // Allows use of Enter key for searching
                    if (e.keyCode == 13)
                        self.search(input.val().replace(/['"]+/g, '')).draw();
                }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                ).text("search")
                .click(function () {
                    self.search(input.val().replace(/['"]+/g, '')).draw();
                }));
                $("#archived-client-table-div .dataTables_filter").append($searchButton);
            }
        });
    });
</script>

@endsection
