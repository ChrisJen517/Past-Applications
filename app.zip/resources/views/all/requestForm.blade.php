@extends('Includes.basicLayout')
@section('content')
@include('Includes.modal.requestForms.requestFormModal')
@include('Includes.modal.requestForms.requestHistoryModal')
<br>

<link href="{{asset('css/multiTableProcessing.css?'.time())}}" rel="stylesheet" />
<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Purchase Requests:</p>
            </div>
        </div>
    </div>
</section>

<section id="previous-requests">
    <div class="container-fluid">
        
        <button data-toggle="modal" data-target="#requestFormModal" d-type="create" class="btn btn-primary mb-3">
            Create New Request
        </button>

        <div class="row">
            <div class="table-responsive" id="previous-requests-div">
                <table class="table table-striped table-bordered" id="previous-requests-table">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Department</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Requested On</th>
                            <th class="text-center">Edit</th>
                            <th class="text-center">View History</th>
                            <th class="text-center">Archive</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($previousRequests as $previousRequest)
                            <tr>
                                <td class="text-center" style="width: 8%">{{$previousRequest->id}}</td>
                                <td class="text-center">${{$previousRequest->amount}} {{$previousRequest->frequency}}</td>
                                <td class="text-center">{{$previousRequest->department}}</td>
                                <td class="text-center">{{$previousRequest->description}}</td>
                                <td class="text-center">
                                    @if($previousRequest->status == 'approved')
                                        <span class="badge badge-success">Approved!</span>
                                    @elseif($previousRequest->status == 'awaiting_approval')
                                        <span class="badge badge-warning">Awaiting Manager</span>
                                    @elseif($previousRequest->status == 'awaiting_final_approval')
                                        <span class="badge badge-warning">Awaiting Final</span>
                                    @elseif($previousRequest->status == 'changes_requested')
                                        <span class="badge badge-danger">Changes Requested</span>
                                    @else
                                        <span class="badge badge-danger">Denied!</span>
                                    @endif
                                </td>
                                <td class="text-center">{{$previousRequest->created_at}}</td>
                                <td class="text-center">
                                    <button data-toggle="modal" data-target="#requestFormModal" class="btn btn-info text-center" 
                                        d-type="edit" d-id="{{$previousRequest->id}}" d-amount="{{$previousRequest->amount}}" d-manager="{{$previousRequest->manager}}" d-approved="{{$previousRequest->approved}}"
                                        d-justification="{{$previousRequest->justification}}" d-department="{{$previousRequest->department}}" d-frequency="{{$previousRequest->frequency}}" d-other="{{$previousRequest->other}}"
                                        d-description="{{$previousRequest->description}}" d-username="{{$previousRequest->username}}" d-password="{{$previousRequest->password}}" d-website="{{$previousRequest->website}}">
                                        Edit
                                    </button>
                                </td>
                                <td>
                                    <button data-toggle="modal" data-target="#requestHistoryModal" class="btn btn-primary text-center" d-id="{{$previousRequest->id}}">History</button>
                                </td>
                                <td>
                                    <button class="btn btn-danger text-center" type="submit" onclick="archiveContract({{$previousRequest->id}})">Archive</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Archived Requests:</p>
            </div>
        </div>
    </div>
</section>

<section id="previous-requests">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="previous-requests-div">
                <table class="table table-striped table-bordered" id="archived-requests-table">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Department</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Last Updated</th>
                            <th class="text-center">View</th>
                            <th class="text-center">View History</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($archivedRequests as $previousRequest)
                            <tr>
                                <td class="text-center" style="width: 8%">{{$previousRequest->id}}</td>
                                <td class="text-center">${{$previousRequest->amount}} {{$previousRequest->frequency}}</td>
                                <td class="text-center">{{$previousRequest->department}}</td>
                                <td class="text-center">{{$previousRequest->description}}</td>
                                <td class="text-center">
                                    @if($previousRequest->status == 'approved')
                                        <span class="badge badge-success">Approved!</span>
                                    @elseif($previousRequest->status == 'awaiting_approval')
                                        <span class="badge badge-warning">Awaiting Manager</span>
                                    @elseif($previousRequest->status == 'awaiting_final_approval')
                                        <span class="badge badge-warning">Awaiting Final</span>
                                    @else
                                        <span class="badge badge-danger">Denied!</span>
                                    @endif
                                </td>
                                <td class="text-center">{{$previousRequest->updated_at}}</td>
                                <td class="text-center">
                                    <button data-toggle="modal" data-target="#requestFormModal" class="btn btn-info text-center" 
                                        d-type="view" d-id="{{$previousRequest->id}}" d-amount="{{$previousRequest->amount}}" d-manager="{{$previousRequest->manager}}" d-approved="{{$previousRequest->approved}}"
                                        d-justification="{{$previousRequest->justification}}" d-department="{{$previousRequest->department}}" d-frequency="{{$previousRequest->frequency}}" d-other="{{$previousRequest->other}}"
                                        d-description="{{$previousRequest->description}}" d-username="{{$previousRequest->username}}" d-password="{{$previousRequest->password}}" d-website="{{$previousRequest->website}}">
                                        View
                                    </button>
                                </td>
                                <td class="text-center">
                                    <button data-toggle="modal" data-target="#requestHistoryModal" class="btn btn-primary text-center" d-id="{{$previousRequest->id}}">History</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        $('#previous-requests-table').DataTable({
            "order":[[0,"asc"]],
            dom: 'Bfrtip',
            "pageLength": 10,
            buttons: [
            ],
            initComplete: function() {
            }
        });

        $('#archived-requests-table').DataTable({
            "order":[[0,"asc"]],
            dom: 'Bfrtip',
            "pageLength": 10,
            buttons: [
            ],
            initComplete: function() {
            }
        });
    })

    function archiveContract(contractId) {
        urlLink = "/RequestForm/archive/" + contractId;
        swal.fire({
            title: "Are you sure?",
            text:
                "You are about to archive the request with id " + contractId + ".",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Archive"
        }).then(willArchive => {
            if (willArchive.value) {
                $.LoadingOverlay("show", {
                    zIndex: 2147483645
                });
                $(function() {
                    "use strict";
                    $.get(urlLink, function(data) {
                        swal.fire(
                            "Success",
                            "Request has been successfully archived.",
                            "success"
                        );
                        setTimeout(() => location.reload(true), 100);
                    });
                });
            } else {
                swal.fire("Cancelled", "Request was not archived!", "error");
            }
        });
    }
</script>
@endsection