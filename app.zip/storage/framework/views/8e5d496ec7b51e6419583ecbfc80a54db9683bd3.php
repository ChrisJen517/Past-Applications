<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="modal fade" id="approveLegal" tabindex="-1" role="dialog" aria-labelledby="editLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="editLabel">Approve Redline</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
            <form action="<?php echo e(route('approveLegalContract')); ?>" method="POST" enctype="multipart/form-data" id="legal_approval_form">
                <?php echo e(csrf_field()); ?>

                <br>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label">Agent Name:</label>
                    <div class="col-lg-9">
                        <a id="approve_legal_name" name="name"></a>
                        <input id="approve_legal_id" name="id" value="" hidden>
                        <input id="approve_legal_contractId" name="contractId" value="" hidden>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label">Contract:</label>
                    <div class="col-lg-9">
                        Company Name: <a id="approve_legal_company" name="company"></a>
                        <br>
                        Contract Type: <a id="approve_legal_contract_type" name="contract_type"></a>
                        <br>
                        Contract Name: <a id="approve_legal_contract_name" name="contract_name"></a>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label">Upload File:</label>
                    <div class="col-lg-9">
                        <input type="file" accept=".docx, .pdf"  name="uploadFile" id="approve_legal_uploadFile">
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label">Comment:</label>
                    <div class="col-lg-9">
                        <textarea class="form-control" id="approve_legal_comment" name="comment" type="text" placeholder="Reason is required to request changes"></textarea>
                    </div>
                </div>
                <div class="form-group row">
                    <button class="btn btn-lg btn-danger float-middle" type="submit" name="submit" value="changes_requested" style="margin-right:10px;">Request Changes</button>
                    <input class="btn btn-lg btn-primary float-right" type="submit" name="submit" value="Approve">
                </div>
            </form>
            </div>
        </div>
    </div>
</div>

<link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">

<script>


    $(document).ready(function() {
        $('#approveLegal').on('hide.bs.modal', function(){
            var validator = $( "#legal_approval_form" ).validate();
            validator.resetForm();
        })

        $('#approveLegal').on('show.bs.modal', function(e) {
            console.log($(e.relatedTarget).data());
            $(this).find('#approve_legal_name').html($(e.relatedTarget).data('name'));
            $(this).find('#approve_legal_id').val($(e.relatedTarget).data('id'));
            $(this).find('#approve_legal_contractId').val($(e.relatedTarget).data('contract_id'));
            $(this).find('#approve_legal_company').html($(e.relatedTarget).data('company'));
            $(this).find('#approve_legal_contract_type').html($(e.relatedTarget).data('type'));
            $(this).find('#approve_legal_contract_name').html($(e.relatedTarget).data('contract_name'));

            $(this).find('#approve_legal_uploadFile').val('');
            $(this).find('#approve_legal_comment').val('');

        });

    });
</script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views/Includes/modal/approveLegalModal.blade.php ENDPATH**/ ?>