<?php $__env->startSection('route'); ?>
<?php echo e(route('exportMSAAmendment')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('companyInformation'); ?>
<?php echo $__env->make('Includes.forms.amendmentCompanyInformation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
    <?php echo $__env->make('Includes.forms.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
    <link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">

    <script>
    $(document).ready(function() {
        $(function() {
            $('#datepicker').datepicker({
                maxDate: new Date,
            });
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name'); ?>
MSA Amendment
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Includes.baseContract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\MSAAmendment.blade.php ENDPATH**/ ?>