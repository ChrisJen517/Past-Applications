<?php $__env->startSection('route'); ?>
<?php echo e(route('exportICA')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('companyInformation'); ?>
<div class="card-body">
    <div class="row" style="margin-top: 40px !important;">
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Contractor Name <span
                        style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('contractor_name')); ?>" id="contractor_name"
                        name="contractor_name" type="text" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Contractor Email <span
                        style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('contractor_email')); ?>" id="contractor_email"
                        name="contractor_email" type="email" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Commencement Date <span
                    style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('commencement_date')); ?>" id="datepicker" name="commencement_date" type="text" required>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Contractor Address <span
                        style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('contractor_address')); ?>"
                        id="contractor_address" name="contractor_address" type="text" required>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Contractor City <span
                        style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('contractor_city')); ?>" id="contractor_city"
                        name="contractor_city" type="text" required>
                </div>
            </div>
                        <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Contractor State <span
                        style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <select id="contractor_state" value="<?php echo e(old('contractor_state')); ?>" name="contractor_state"
                        class="form-control" required>
                        <option selected disabled value="">Please select a state</option>
                        <option value="AL">Alabama</option>
                        <option value="AK">Alaska</option>
                        <option value="AZ">Arizona</option>
                        <option value="AR">Arkansas</option>
                        <option value="CA">California</option>
                        <option value="CAN">Canada</option>
                        <option value="CO">Colorado</option>
                        <option value="CT">Connecticut</option>
                        <option value="DE">Delaware</option>
                        <option value="DC">District Of Columbia</option>
                        <option value="FL">Florida</option>
                        <option value="GA">Georgia</option>
                        <option value="HI">Hawaii</option>
                        <option value="ID">Idaho</option>
                        <option value="IL">Illinois</option>
                        <option value="IN">Indiana</option>
                        <option value="IA">Iowa</option>
                        <option value="KS">Kansas</option>
                        <option value="KY">Kentucky</option>
                        <option value="LA">Louisiana</option>
                        <option value="ME">Maine</option>
                        <option value="MD">Maryland</option>
                        <option value="MA">Massachusetts</option>
                        <option value="MI">Michigan</option>
                        <option value="MN">Minnesota</option>
                        <option value="MS">Mississippi</option>
                        <option value="MO">Missouri</option>
                        <option value="MT">Montana</option>
                        <option value="NE">Nebraska</option>
                        <option value="NV">Nevada</option>
                        <option value="NH">New Hampshire</option>
                        <option value="NJ">New Jersey</option>
                        <option value="NM">New Mexico</option>
                        <option value="NY">New York</option>
                        <option value="NC">North Carolina</option>
                        <option value="ND">North Dakota</option>
                        <option value="OH">Ohio</option>
                        <option value="OK">Oklahoma</option>
                        <option value="OR">Oregon</option>
                        <option value="PA">Pennsylvania</option>
                        <option value="PR">Puerto Rico</option>
                        <option value="RI">Rhode Island</option>
                        <option value="SC">South Carolina</option>
                        <option value="SD">South Dakota</option>
                        <option value="TN">Tennessee</option>
                        <option value="TX">Texas</option>
                        <option value="UT">Utah</option>
                        <option value="VT">Vermont</option>
                        <option value="VA">Virginia</option>
                        <option value="WA">Washington</option>
                        <option value="WV">West Virginia</option>
                        <option value="WI">Wisconsin</option>
                        <option value="WY">Wyoming</option>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Contractor Zip <span
                        style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('contractor_zip')); ?>" id="contractor_zip"
                        name="contractor_zip" type="text" required>
                </div>
            </div>
        </div>
    </div>
        <hr>
    <div class="form-group row">
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Periodic Report <span
                    style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <select class="form-control" id="periodic_report" value="<?php echo e(old('periodic_report')); ?>" name="periodic_report" type="text" required>
                        <option value="" disabled selected>Select Periodic Report</option>
                        <option value="weekly">Weekly</option>
                        <option value="biweekly">Biweekly</option>
                        <option value="monthly">Monthly</option>
                    </select>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Deliverables Timeline <span
                    style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('deliverables')); ?>" id="deliverables" name="deliverables" type="text" required>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Description of Services <span
                    style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <textarea class="form-control" style="resize: none;" value="<?php echo e(old('services_description')); ?>" name="services_description" id="services_description" cols="30" rows="3" required></textarea>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-lg-6">
            <div class="form-group row">
                <div class="col-lg-4">
                    <label class="form-control-label">Fee Structure <span
                        style="color:red">&#10033;</span></label>
                        <br>
                    <span style="font-size: 12px;">(Commission Plan)</span>
                </div>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('fee_structure')); ?>" id="fee_structure" name="fee_structure" type="text" required>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Payment Schedule <span
                    style="color:red">&#10033;</span></label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('payment_schedule')); ?>" id="payment_schedule" name="payment_schedule" type="text" required>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Other (1)</label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('other_1')); ?>" id="other_1" name="other_1" type="text">
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Other (2)</label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('other_2')); ?>" id="other_2" name="other_2" type="text">
                </div>
            </div>
        </div>
    </div>
    <div class="form-group row">
        <div class="col-lg-6">
            <div class="form-group row">
                <label class="col-lg-4 col-form-label form-control-label">Other (3)</label>
                <div class="col-lg-8">
                    <input class="form-control" value="<?php echo e(old('other_3')); ?>" id="other_3" name="other_3" type="text">
                </div>
            </div>
        </div>
    </div>        
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">

<style>
div:nth-of-type(2) > .mb-0 {
    display: none;
}
</style>

<script>
$(document).ready(function() {
    $('#datepicker').datepicker({
        minDate: new Date()
    });
    $('#datepicker2').datepicker({
        minDate: new Date()
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name'); ?>
Independent Contractor Agreement
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.baseContract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\ICA.blade.php ENDPATH**/ ?>