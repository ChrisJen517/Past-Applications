<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="loading-overlay">
    <div class="modal fade" id="viewEmailsModal" tabindex="-1" role="dialog" aria-labelledby="editLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content border-0" id="viewEmailsModalBody">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLabel">Request History</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped table-bordered" id="history-table">
                        <thead>
                            <tr>
                                <th class="text-center">Sent At</th>
                                <th class="text-center">Client Email</th>
                                <th class="text-center">Subject</th>
                                <th class="text-center">Status</th>
                                <th class="text-center">Download Original Files</th>
                                <th class="text-center">Download Client Files</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        datatable = $('#history-table').DataTable({
            "order":[[0,"desc"]],
            autoWidth: false,
            "processing": true,
            "serverSide": true,
            "language": {
                'loadingRecords': '&nbsp;',
                processing: '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": "/manageClients/getEmailHistory/0",
                "dataType": "json",
                "type": "GET",
                "data": {
                    _token: "<?php echo e(csrf_token()); ?>",
                }
            },
            "columns": [
                { "data": "created_at" },
                { "data": "recipient" },
                { "data": "subject" },
                { "data": "status" },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        if(row.password){
                            return `
                                <td class="text-center">
                                    <button class="btn btn-primary" style="color:white;" onclick="downloadAll('original', ${row.id})" 
                                        data-id="${id}">
                                        Download
                                    </button>
                                </td>`;
                        }
                        else{
                            return `<td class="text-center">N/A</td>`;
                        }
                    }
                },
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        if(row.status == 'complete'){
                            return `
                                <td class="text-center">
                                    <button class="btn btn-primary" style="color:white;" onclick="downloadAll('client', ${row.id})" 
                                        data-id="${id}">
                                        Download
                                    </button>
                                </td>`;
                        }
                        else{
                            return `<td class="text-center">N/A</td>`;
                        }
                    }
                },
            ],
            dom: 'Bfrtip',
            "pageLength": 5,
            buttons: [],
            "searching": false,
            initComplete: function() {
                var input = $("#parent4 .dataTables_filter input").unbind();
                var self = this.api();
            }
        });

        $('#viewEmailsModal').on('show.bs.modal', function(e) {
            id = $(e.relatedTarget).data('id');
            datatable.ajax.url('/manageClients/getEmailHistory/'+id).load();
        })
    });

    function downloadAll(fileType, id){
        $.ajax({
            url: "/manageClients/getFileNames/"+id+"/"+fileType,
            type: "GET",
            contentType: false,
            cache: false,
            processData: false,
            success: function (data, status) {
                var pendingFiles = JSON.parse(data);
                pendingFiles.forEach(fileName => downloadfile(id, fileType, fileName));
            }, error: function (err) {
                if (err.status == 419) {
                    location.reload();
                }
            }
        })
    }

    //downloads the proper file
    function downloadfile(id, fileType, fileName){
            window.open(
                '/manageClients/getEmailFiles/'+id+'/'+fileType+'/' + fileName,
                '_blank' 
            );
        }
</script><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\manageClients\viewCompanyEmail.blade.php ENDPATH**/ ?>