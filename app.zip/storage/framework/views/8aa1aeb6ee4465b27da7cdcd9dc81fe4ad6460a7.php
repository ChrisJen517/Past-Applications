<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Rocker - Bootstrap4  Admin Dashboard Template</title>

  <!-- Bootstrap core CSS-->
  <link href="css/bootstrap.min.css" rel="stylesheet"/>
  <!-- Icons CSS-->
  <link href="css/icons.css" rel="stylesheet" type="text/css"/>
  <!-- Custom Style-->
  <link href="css/login-form.css" rel="stylesheet"/>

  <script src="js/jquery.min.js"></script>


</head>

<body>

  <div id="wrapper">
  <?php if(session()->has('message')): ?>
  <div class="alert alert-success">
      <?php echo e(session()->get('message')); ?>

  </div>
  <?php endif; ?>
  <div class="card border-primary border-top-sm border-bottom-sm card-authentication1 mx-auto my-5 animated bounceInDown">
    <div class="card-body">
      <div class="card-content p-2">
        <div class="text-center">
          <img src="/images/RNN-Logo-Square.png" width="200" height="150">
          </div>
          <form method="POST" action="<?php echo e(route('sendResetPassword')); ?>">
          <?php echo csrf_field(); ?>
            <div class="card-title text-uppercase text-center py-3">An email will be sent to you after reset</div>
            <div class="form-group">
              <div class="position-relative has-icon-right">
                <label for="exampleInputUsername" class="sr-only">Email</label>
                <input type="email" id="email" required autocomplete="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control form-control-rounded" placeholder="Email">
                <div class="form-control-position">
                  <i class="icon-user"></i>
                </div>
              </div>
            </div>
            <button type="submit" class="btn btn-outline-primary btn-block waves-effect waves-light">Reset Password</button>
        </form>
        <br>
        <a href="/login">Back</a>
      </div>
    </div>
  </div>
  <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\auth\resetPassword.blade.php ENDPATH**/ ?>