<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />

    <!-- Bootstrap core CSS-->
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <!-- Icons CSS-->
    <link href="css/icons.css" rel="stylesheet" type="text/css" />
    <!-- Custom Style-->
    <link href="css/login-form.css" rel="stylesheet" />

    <script src="https://code.jquery.com/jquery-3.1.1.js"></script>
    <script src="plugins/jquery-validation/js/jquery.validate.js"></script>
    <script src="http://malsup.github.com/jquery.form.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
</head>
<style>
    .error{
        color: red;
    }
</style>

<body>
    <!-- Start wrapper-->
    <div id="wrapper">
        <div
            class="card border-primary border-top-sm border-bottom-sm card-authentication1 mx-auto my-5 animated bounceInDown">
            <div class="card-body">
                <div class="card-content p-2">
                    <div class="text-center">
                        <img src="/images/RNN-Logo-Square.png" width="160" height="150">
                        <form action="<?php echo e(route('changePassword')); ?>" method="POST" enctype="multipart/form-data"
                            id="user_information_form">
                            <?php echo e(csrf_field()); ?>

                            <div class="card-title text-uppercase text-center py-3" style="color:red">Password needs to be reset, Please
                                Create A New Password:
                                <?php if(session()->has('message')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session()->get('message')); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="position-relative has-icon-right">
                                    <label for="exampleInputPassword" class="sr-only">New Password</label>
                                    <input id="newPasswordName" name="newPasswordName" type="password"
                                        class="form-control form-control-rounded" placeholder="New Password">
                                    <div class="form-control-position">
                                        <i class="icon-lock"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="position-relative has-icon-right">
                                    <label for="exampleInputPassword" class="sr-only">Confirm Password</label>
                                    <input id="confirmPassword" name="confirmPassword" type="password"
                                        class="form-control form-control-rounded" placeholder="Confirm Password">
                                    <div class="form-control-position">
                                        <i class="icon-lock"></i>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12" id="pswd_info">
                                    <div class="card-title text-uppercase">Password must meet the
                                        following requirements:</div>
                                    <ul style="text-align:left">
                                        <li id="length" class="invalid">Be at least <strong>10 characters (Max
                                                32)</strong></li>
                                        <li id="number" class="invalid">At least <strong>one number</strong></li>
                                        <li id="letter_lower" class="invalid">At least <strong>one lowercase
                                                letter</strong></li>
                                        <li id="letter_upper" class="invalid">At least <strong>one capital
                                                letter</strong></li>
                                        <li id="special" class="invalid">At least <strong>one special character
                                                (?!@$%^&*-)</strong></li>
                                    </ul>
                                </div>
                            </div>
                            <button type="submit"
                                class="btn btn-outline-primary btn-block waves-effect waves-light">Submit</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!--Start Back To Top Button-->
        <a href="javaScript:void();" class="back-to-top"><i class="fa fa-angle-double-up"></i> </a>
        <!--End Back To Top Button-->
    </div>
    <!--wrapper-->

</body>

</html>


<style>
    .invalid {
        color: #ec3f41;
    }

    .valid {
        color: #3a7d34;
    }
</style>
<script>
    $(document).ready(function(){
    jQuery.validator.addMethod("passwordCorrectRules", function(value, element) {
    return this.optional(element) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,32}$/.test(value);
}, "Must follow password rules");

    // validate signup form on keyup and submit
    $("#user_information_form").validate({
        rules: {
            newPasswordName: {
                required: true,
                passwordCorrectRules: true,
            },
            confirmPassword: {
                required: true,
                equalTo:'#newPasswordName'
            },
        },
        messages: {
            newPasswordName: {
                required: "Please provide a password",
                passwordCorrectRules: "Please follow password rules"
            },
            confirmPassword: {
                required: "Please provide a password",
                equalTo: "Passwords Must Match"
            }
            },
            submitHandler : function(form) {
                $.LoadingOverlay("show");
            // .then(form.submit())
            setTimeout(function(){ form.submit() }, 1500);
            // form.submit();
            }
    });

$('input[name=newPasswordName]').keyup(function() {
    var pswd = $(this).val();
    if ( pswd.length < 10 && pswd.length < 33) {
        $('#length').removeClass('valid').addClass('invalid');
    } else {
        $('#length').removeClass('invalid').addClass('valid');
    }
    //validate capital letter
    if ( pswd.match(/[A-Z]/) ) {
        $('#letter_upper').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_upper').removeClass('valid').addClass('invalid');
    }

        //validate lowercase letter
        if ( pswd.match(/[a-z]/) ) {
        $('#letter_lower').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_lower').removeClass('valid').addClass('invalid');
    }

    //validate number
    if ( pswd.match(/\d/) ) {
        $('#number').removeClass('invalid').addClass('valid');
    } else {
        $('#number').removeClass('valid').addClass('invalid');
    }

        //validate special character
        if ( pswd.match(/^(?=.*?[?!@$%^&*-])/) ) {
        $('#special').removeClass('invalid').addClass('valid');
    } else {
        $('#special').removeClass('valid').addClass('invalid');
    }
    }).focus(function() {
        $('#pswd_info').show();
    });

});



</script><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\login\changePassword.blade.php ENDPATH**/ ?>