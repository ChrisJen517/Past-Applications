<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Includes.modal.createDocumentModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Includes.modal.editDocumentModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="<?php echo e(asset('css/multiTableProcessing.css?'.time())); ?>" rel="stylesheet" />

<section id="documents_header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Documents:</p>
            </div>
        </div>
        <div class="row text-left">
            <?php if($isManager): ?>
                <a class="btn btn-primary" data-toggle="modal" data-target="#createDocument"
                    style="margin:0px 0px 20px 15px; color:white;">Add Document</a>
            <?php endif; ?>
        </div>
        <div class="row text-left">
            <a class="btn btn-primary" id="filter_button" style="margin:0px 0px 20px 15px; color:white;">Filter Documents</a>
        </div>
        <div id="filters" style="display: none">
            <hr>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label" style="font-size:20">Filter By Client:</label>
                            <div class="col-sm-8">
                                <select id="client_filter" class="form-control">
                                    <option value="">All Clients</option>
                                    <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($client->company_name); ?>"><?php echo e($client->company_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group row">
                            <label class="col-sm-4 col-form-label" style="font-size:20">Filter By Type:</label>
                            <div class="col-sm-8">
                                <?php $types = array('Client FCRA MSA', 'Client Non FCRA MSA',
                                'Client Product Amendment', 'Client FCRA Amendment', 'MNDA/NDA',
                                'Data Vendor contract', 'Data Vendor NDA', 'Trend Source Audit','Trendsource Background Check',
                                'Verified vendor contract', 'Verified vendor NDA', 'Policy', 'Procedure',
                                'Marketing', 'Deck', 'Presentation', 'FAQs', 'Onboarding', 'Certificate', 'End User Audit', 'OTHER');?>
                                <select id="type_filter" class="form-control">
                                    <option value="">All Types</option>
                                    <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            <hr>
        </div>
    </div>
</section>
<section id="documents">
    <div class="container-fluid">
        <div class="row">
            <div id="documents_table" style="width: 100%;">
                <table class="table table-striped table-bordered" id="support-documents" style="width: 100%;">
                    <thead>
                        <tr>
                            <th style="width: 20%;" class="text-center">Document Name</th>
                            <th style="width: 20%;" class="text-center">Client or Vendor Name</th>
                            <th style="width: 10%;" class="text-center">Document Type</th>
                            <th style="width: 20%;" class="text-center">Document Notes</th>
                            <th style="width: 10%;" class="text-center">Expiration Date</th>
                            <th style="width: 10%;" class="text-center">Key Words</th>
                            <th style="width: 5%;" class="text-center">Download</th>
                            <?php if($isManager): ?>
                            <th style="width: 5%;" class="text-center">Edit</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
</section>

<section id="archived_documents_header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Archived Documents:</p>
            </div>
        </div>
    </div>
</section>
<section id="documents">
    <div class="container-fluid">
        <div class="row">
            <div id="archived_documents_table" style="width: 100%;">
                <table class="table table-striped table-bordered" id="archived-support-documents" style="width: 100%;">
                    <thead>
                        <tr>
                            <th style="width: 20%;" class="text-center">Document Name</th>
                            <th style="width: 20%;" class="text-center">Client or Vendor Name</th>
                            <th style="width: 10%;" class="text-center">Document Type</th>
                            <th style="width: 20%;" class="text-center">Document Notes</th>
                            <th style="width: 10%;" class="text-center">Expiration Date</th>
                            <th style="width: 10%;" class="text-center">Key Words</th>
                            <th style="width: 5%;" class="text-center">Download</th>
                            <?php if($isManager): ?>
                            <th style="width: 5%;" class="text-center">Edit</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
</section>

<br>

<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
    $(document).ready(function() {
        active = $('#support-documents').DataTable({
            "order":[[0,"asc"]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "language": {
                'loadingRecords': '&nbsp;',
                "processing": '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": "<?php echo e(route('getSupportDocumentTable')); ?>",
                "dataType": "json",
                "type": "POST",
                "data": {
                    "_token": "<?php echo e(csrf_token()); ?>",
                }
            },
            "columns": [
                { "data": "document_name" },
                { "data": "client_vendor_name" },
                { "data": "type" },
                { "data": "notes" },
                {
                    "data": "expiration_date_formatted",
                    render: function(expiration_date_formatted, type, row, meta) {
                        let date = '';
                        if (expiration_date_formatted != null)
                            date = expiration_date_formatted;

                        return `<td>${date}</td>`;
                    }
                },
                { "data": "key_words" },
                {
                    "data": "file_name",
                    "class": "text-center",
                    render: function(file_name, type, row, meta) {
                        let route = "/download/" + file_name;
                        return `
                            <td class="text-center">
                                <a href="${route}" download>
                                    <i class="fa fa-download fa-5" aria-hidden="true" style="font-size: 25px;"></i>
                                </a>
                            </td>
                        `;
                    }
                },
                <?php if($isManager): ?>
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        return `
                            <td>
                                <a class="btn btn-primary" data-toggle="modal" data-target="#editDocument"
                                    style="color:white;" data-id="${id}"
                                    data-name="${row.document_name}" data-notes="${row.notes}"
                                    data-type="${row.type}"
                                    data-client_vendor_name="${row.client_vendor_name}"
                                    data-client_id="${row.client_id}" data-created_date="${row.created_date}"
                                    data-expiration_date="${row.expiration_date}"
                                    data-key_words="${row.key_words}" data-archived="0">
                                    Edit
                                </a>
                            </td>
                        `;
                    }
                },
                <?php endif; ?>
            ],
            "lengthMenu": [[10, 25, 50, 100], [10, 25, 50, 100]],
            dom: 'Blfrtip',
            "pageLength": 10,
            buttons: [
                'excelHtml5',
                'pdfHtml5'
            ],
            initComplete: function() {
                var input = $("#documents_table .dataTables_filter input").unbind();
                var self = this.api();

                $("#documents_table .dataTables_filter input").keyup(function (e) {
                    // Allows use of Enter key for searching
                    if (e.keyCode == 13)
                        self.search(input.val().replace(/['"]+/g, '')).draw();
                }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                ).text("search")
                .click(function () {
                    self.search(input.val().replace(/['"]+/g, '')).draw();
                }));
                $("#documents_table .dataTables_filter").append($searchButton);
            }
        });

        archived = $('#archived-support-documents').DataTable({
            "order":[[0,"asc"]],
            "autoWidth": false,
            "processing": true,
            "serverSide": true,
            "language": {
                'loadingRecords': '&nbsp;',
                "processing": '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": "<?php echo e(route('getArchivedSupportDocumentTable')); ?>",
                "dataType": "json",
                "type": "POST",
                "data": {
                    "_token": "<?php echo e(csrf_token()); ?>",
                }
            },
            "columns": [
                { "data": "document_name" },
                { "data": "client_vendor_name" },
                { "data": "type" },
                { "data": "notes" },
                {
                    "data": "expiration_date_formatted",
                    render: function(expiration_date_formatted, type, row, meta) {
                        let date = '';
                        if (expiration_date_formatted != null)
                            date = expiration_date_formatted;

                        return `<td>${date}</td>`;
                    }
                },
                { "data": "key_words" },
                {
                    "data": "file_name",
                    "class": "text-center",
                    render: function(file_name, type, row, meta) {
                        let route = "/download/" + file_name;
                        return `
                            <td class="text-center">
                                <a href="${route}" download>
                                    <i class="fa fa-download fa-5" aria-hidden="true" style="font-size: 25px;"></i>
                                </a>
                            </td>
                        `;
                    }
                },
                <?php if($isManager): ?>
                {
                    "data": "id",
                    "class": "text-center",
                    render: function(id, type, row, meta) {
                        return `
                            <td>
                                <a class="btn btn-primary" data-toggle="modal" data-target="#editDocument"
                                    style="color:white;" data-id="${id}"
                                    data-name="${row.document_name}" data-notes="${row.notes}"
                                    data-type="${row.type}"
                                    data-client_vendor_name="${row.client_vendor_name}"
                                    data-client_id="${row.client_id}" data-created_date="${row.created_date}"
                                    data-expiration_date="${row.expiration_date}"
                                    data-key_words="${row.key_words}" data-archived="1">
                                    Edit
                                </a>
                            </td>
                        `;
                    }
                },
                <?php endif; ?>
            ],
            "lengthMenu": [[10, 25, 50, 100], [10, 25, 50, 100]],
            dom: 'Blfrtip',
            "pageLength": 10,
            buttons: [
                'excelHtml5',
                'pdfHtml5'
            ],
            initComplete: function() {
                var input = $("#archived_documents_table .dataTables_filter input").unbind();
                var self = this.api();

                $("#archived_documents_table .dataTables_filter input").keyup(function (e) {
                    // Allows use of Enter key for searching
                    if (e.keyCode == 13)
                        self.search(input.val().replace(/['"]+/g, '')).draw();
                }),
                ($searchButton = $(
                    '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
                ).text("search")
                .click(function () {
                    self.search(input.val().replace(/['"]+/g, '')).draw();
                }));
                
                $("#archived_documents_table .dataTables_filter").append($searchButton);
            }
        });

        $('#client_filter').on('change', function(){
            client = $('#client_filter').val();
            archived.columns(1).search(client).draw();
            active.columns(1).search(client).draw();  
        });
        $('#type_filter').on('change', function(){
            docType = $('#type_filter').val();
            archived.columns(2).search(docType).draw();
            active.columns(2).search(docType).draw();  
        });
    });

    $("#filter_button").click(function () {
        $("#filters").toggle(500);
    });

    $(document).ready(function() {
        $(".custom-file-input").on("change", function() {
            if ($(this).get(0).files.length > 0) { // only if a file is selected
                var fileSize = $(this).get(0).files[0].size;
                var fileName = $(this).get(0).files[0].name;
                var index = fileName.lastIndexOf('.');
                var ext = fileName.substring(index);
                if (fileSize > 52428799) {
                    swal.fire({
                        title: "File size too large!",
                        text: "File size cannot exceed 50mb",
                        icon: "warning",
                        buttons: true,
                        dangerMode: true,
                    })

                    $(this).val("");
                    $(this).siblings(".custom-file-label").html("Choose file...");
                }
                if ($(this).val() != "") {
                    var fileName = $(this).val().split("\\").pop();

                    if(fileName.length > 50){
                        fileName = fileName.substring(0, 50) + "...";
                    }
                    $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
                }
            }
            else {
                $(this).siblings(".custom-file-label").html("Choose file...");
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\supportDocuments.blade.php ENDPATH**/ ?>