<div class="loading-overlay">

<?php $__env->startSection('content'); ?>

<?php echo $__env->make('Includes.modal.editProductHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Includes.modal.addProductHeader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container-fluid py-3">
    <section id="documents_header">
        <div class="container-fluid">
            <div class="row text-left">
                <p>Edit Product Headers</p>
            </div>
            <div class="row text-left">
                <a href="/manageProductSheet" class="btn btn-secondary" style="margin-right: 10px;">Back</a>
                <a class="btn btn-primary float-right" href="/productHistory" style="color: white; margin-right: 10px;">Header History</a>
                <a href="" data-toggle="modal" data-target="#addProductHeaderModal" class="btn btn-primary" role="button">Add Product Header</a>
            </div>
        </div>
    </section>
    <br>
    <div class="row text-left">
    <div class="table-responsive">
                <table class="table table-striped table-bordered" id="product-headers" style="border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th class="text-center">Order</th>
                            <th class="text-center">Name</th>
                            <th class="text-center">Product Name Label</th>
                            <th class="text-center">Description Label</th>
                            <th class="text-center">Cost Label</th>
                            <th class="text-center">Pricing Contract Header</th>
                            <th class="text-center">Delete</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $product_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr data-index="<?php echo e($item->id); ?>" data-position="<?php echo e($item->order); ?>" style="height:45px;">
                            <td class="order"> <?php echo e($item->order); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->column_1); ?></td>
                            <td><?php echo e($item->column_2); ?></td>
                            <td><?php echo e($item->column_3); ?></td>
                            <td class="text-center">
                                <a class="btn btn-primary" data-toggle="modal" data-target="#editProductHeader" style="color:white;"
                                 data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->name); ?>" data-description="<?php echo e($item->description); ?>" data-check="<?php echo e($item->show_in_list); ?>"
                                 data-column_1="<?php echo e($item->column_1); ?>" data-column_2="<?php echo e($item->column_2); ?>" data-column_3="<?php echo e($item->column_3); ?>">
                                    Edit
                                </a>
                            </td>
                            <td class="text-center">
                                <button class="btn btn-danger" onclick=deleteProductHeader(<?php echo e($item->id); ?>)>Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">

<script>

var updated = false;

$(window).bind("beforeunload", function() {
    if (updated) {
        return "Are you sure you want to leave? We haven't finished saving.";
    }
});

$(document).ready(function() {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    var fixHelper = function(e, ui) {
        ui.children().each(function() {
            $(this).width($(this).width());
        });
        return ui;
    };

    var start = function(e, ui) {
        $(this).sortable('refreshPositions');
        ui.item.css({
            'outline': '',
            'border': '2px solid black',
            'background-color': '#f4f4f4',
            'opacity': 1.0
        });
    };

    var stop = function(e, ui) {
        ui.item.css({
            'outline': '2px dashed #f8de7e',
            'border': '',
            'background-color': '',
            'opacity': ''
        });
    };

    $('#product-headers tbody').children().each(function (index) {
                if ($(this).attr('data-position') != (index+1)) {
                    $(this).attr('data-position', (index+1));
                    $(this).find('td.order').text(index+1);
                }
            });

    $('#product-headers tbody').sortable({
        revert: true,
        helper: fixHelper,
        start: start,
        stop: stop,
        placeholder: "my-ui-placeholder",
        cursor: "move",
        zIndex: 99999,
        opacity: 1.0,
        update: function (event, ui) {
            $(this).children().each(function (index) {
                if ($(this).attr('data-position') != (index+1)) {
                    $(this).attr('data-position', (index+1));
                    $(this).find('td.order').text(index+1);
                }
                updated = true;
            });
                updated = true;
                $(this)
                    .children()
                    .each(function(index) {
                        $(this).attr("data-position", index + 1);
                        $(this).data("position", index + 1);
                    });

                    var ids = [];
                    var orders = [];
                    $('#product-headers tbody').children().each(function (index) {
                        ids.push($(this).attr('data-index'));
                        orders.push($(this).attr('data-position'));
                    });

                    if (ids.length != 0 || orders.length != 0) {
                        $.post("/saveProductHeaderOrder", {
                            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                                "content"
                            ),
                            ids: ids,
                            orders: orders,
                        }).done(function(data) {
                            updated = false;
                        });
                    }

            }
        }).disableSelection();
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\manageProductHeaders.blade.php ENDPATH**/ ?>