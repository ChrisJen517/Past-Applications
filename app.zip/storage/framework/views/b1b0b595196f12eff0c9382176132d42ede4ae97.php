<div class="loading-overlay">


<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="container-fluid">
    <!--Client Info-->
    <form action="<?php echo e(route('updateClient')); ?>" method="post" enctype="multipart/form-data"
                id="client_information_form">
                <?php echo e(csrf_field()); ?>

        <div class="row">
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-header">
                        <h2 id="previous-uploads-header" class="mb-0 text-center">Company Information</h4>
                    </div>
                    <br>
                    <div class="form-group-row">
                                <p class="text-center" style="font-weight: bold;"><span
                                        style="color:red">&#10033;</span>Denotes Required Field</p>
                    </div>
                    <div class="card-body">
                        <input class="form-control" name="id" value="<?php echo e($client->id); ?>" type="text" hidden>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Industry <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <select class="form-control" id="industry" value="" data-industry="<?php echo e(old('industry', $client->industry)); ?>" name="industry"
                                    required>
                                    <option value="Collection Agency">Collection Agency</option>
                                    <option value="Law Firm">Law Firm</option>
                                    <option value="Debt Buyer">Debt Buyer</option>
                                    <option value="Originator">Originator</option>
                                    <option value="Government">Government</option>
                                    <option value="Healthcare">Healthcare</option>
                                    <option value="Reseller">Reseller</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Name <span style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyName" type="text"
                                    value="<?php echo e(old('companyName', $client->company_name)); ?>" maxlength="255" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Address <span style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyAddress" type="text"
                                    value="<?php echo e(old('companyAddress', $client->company_address)); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company City <span style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyCity"
                                    type="text" value="<?php echo e(old('companyCity', $client->company_city)); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company State <span style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <select class="form-control" id="company-state" value=""
                                    data-state="<?php echo e(old('companyState', $client->company_state)); ?>" name="companyState"
                                    required>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CAN">Canada</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="PR">Puerto Rico</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Zip <span style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyZip" type="text"
                                    value="<?php echo e(old('companyZip', $client->company_zip)); ?>" required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Email <span style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyEmail" type="email"
                                    value="<?php echo e(old('companyEmail', $client->company_email)); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company EIN</label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyEIN"
                                    type="text" value="<?php echo e(old('companyEIN', $client->company_ein)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Phone</label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyPhone"
                                    type="phone" value="<?php echo e(old('companyPhone', $client->company_phone)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company URL</label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyURL"
                                    type="text" value="<?php echo e(old('companyURL', $client->company_url)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                                <div class="col-lg-12">
                                    <a href="<?php echo e(route('manageClients')); ?>" class="btn btn-secondary float-left">Back</a>
                                    <input type="submit" class="btn btn-primary float-right" value="Update Client">
                                </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title text-center">Account Payable Contact Information:</h3>
                        <br>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Account Payable Name</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="accountPayableName" type="text"
                                    value="<?php echo e(old('accountPayableName', $client->account_payable_name)); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Account Payable Phone</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="accountPayablePhone" type="phone"
                                    value="<?php echo e(old('accountPayablePhone', $client->account_payable_phone)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Account Payable Email</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="accountPayableEmail" type="email"
                                    value="<?php echo e(old('accountPayableEmail', $client->account_payable_email)); ?>">
                            </div>
                        </div>
                        <hr>
                        <br>
                        <h3 class="card-title text-center">Invoice Approver Information:</h3>
                        <br>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Invoice Approver Name</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="invoiceApproverName" type="text"
                                    value="<?php echo e(old('invoiceApproverName', $client->invoice_approver_name)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Invoice Approver Phone</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="invoiceApproverPhone" type="text"
                                    value="<?php echo e(old('invoiceApproverPhone', $client->invoice_approver_phone)); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Invoice Approver Email</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="invoiceApproverEmail" type="email"
                                    value="<?php echo e(old('invoiceApproverEmail', $client->invoice_approver_email)); ?>">
                            </div>
                        </div>
                        <hr>
                        <br>
                        <h3 class="card-title text-center">Executive Contact Information:</h3>
                        <br>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Executive Contact Name</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="executiveContactName" type="text"
                                    value="<?php echo e(old('executiveContactName', $client->executive_contact_name)); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Executive Contact Phone</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="executiveContactPhone" type="phone"
                                    value="<?php echo e(old('executiveContactPhone', $client->executive_contact_phone)); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Executive Contact Email</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="executiveContactEmail" type="email"
                                    value="<?php echo e(old('executiveContactEmail', $client->executive_contact_email)); ?>">
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="card">
        <div class="card-body">
            <section id="previous-uploads-header">
                <div class="container-fluid">
                    <div class="row text-left">
                        <div class="col text-left">
                            <p>Contracts</p>
                        </div>
                    </div>
                </div>
            </section>
            <div class="table-responsive">
                <div id="contracts-pending-parent" class="table-parent-hidden">
                <table class="table table-striped table-bordered" id="contracts-table-pending">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Agent Name</th>
                            <th class="text-center">Created Date</th>
                            <th class="text-center">Contract Type</th>
                            <th class="text-center">Send Contract</th>
                            <th class="text-center">Download</th>
                            <th class="text-center">History</th>
                            <th class="text-center">Next Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="item<?php echo e($item->id); ?>">
                                <td><?php echo e($item->id); ?></td>
                            <td><?php echo e($item->agent_name); ?></td>
                                <td><?php echo e(substr($item->created_at, 0, 10)); ?></td>
                                <td><?php echo e($item->contract_type); ?></td>
                                <td class="text-center">
                                    <?php if($item->status == 'converting'): ?>
                                        Converting
                                    <?php elseif($item->approval_needed == 1): ?>
                                        Awaiting Approval
                                    <?php elseif($item->contract_type == "REDLINE"): ?>
                                        Docusign not implemented for redline
                                    <?php elseif($item->status == 'complete'): ?>
                                        Contract Complete
                                    <?php elseif($item->company_email == NULL): ?>
                                        No Email with Contract
                                    <?php elseif($item->status == 'awaiting_all_signature'): ?>
                                        <button class="btn btn-primary" style="width:100%; color:white;" onclick="resendContract(<?php echo e($item->id); ?>, 'jimv@rnngroup.com and ' + '<?php echo e($item->docusign_email == null ? $item->company_email : $item->docusign_email); ?>')">
                                        Resend
                                        </button>
                                    <?php elseif($item->status == 'awaiting_client_signature'): ?>
                                        <button class="btn btn-primary" style="width:100%; color:white;" onclick="resendContract(<?php echo e($item->id); ?>, '<?php echo e($item->docusign_email == null ? $item->company_email : $item->docusign_email); ?>')">
                                        Resend
                                        </button>
                                    <?php elseif($item->status == 'awaiting_jim_signature'): ?>
                                        <button class="btn btn-primary" style="width:100%; color:white;" onclick="resendContract(<?php echo e($item->id); ?>, 'jimv@rnngroup.com')">
                                        Resend
                                        </button>
                                    <?php else: ?>
                                        <button class="btn btn-primary" style="width:100%; color:white;" onclick="sendContract(<?php echo e($item->id); ?>, '<?php echo e($item->company_email); ?>')">
                                        Send
                                        </button>
                                    <?php endif; ?>
                                </td>
                                <?php if($item->approval_needed == 1): ?>
                                    <td class="text-center">Awaiting Approval</td>
                                <?php elseif($item->status == 'converting'): ?>
                                    <td class="text-center">Converting</td>
                                <?php else: ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('download', $item->contract_name)); ?>">
                                            <div style="height:100%;width:100%">
                                            Download
                                            </div>
                                        </a>
                                    </td>
                                <?php endif; ?>
                                <td class="text-center">
                                    <a href="<?php echo e(route('manageContract',$item->id)); ?>" class="btn btn-primary btn-sm"
                                    role="button">History</a>
                                </td>
                                <?php if($item->status == 'converting'): ?>
                                    <td class="text-center">
                                    Converting
                                    </td>
                                <?php elseif($item->status == 'awaiting_manager_approval'): ?>
                                    <td class="text-center">
                                    Awaiting Approval
                                    </td>
                                <?php elseif($item->status == 'awaiting_jim_approval'): ?>
                                    <td class="text-center">
                                    Awaiting Approval
                                    </td>
                                <?php elseif($item->status == 'awaiting_final_upload'): ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('manageContract',$item->id)); ?>" class="btn btn-primary btn-sm"
                                        role="button">Upload Final Contract</a>
                                    </td>
                                <?php elseif($item->status == 'complete'): ?>
                                    <td class="text-center">
                                    Contract Complete
                                    </td>
                                <?php elseif($item->status == 'awaiting_all_signature'): ?>
                                    <td class="text-center">
                                    Contract awaiting signatures by client and RNN.
                                    </td>
                                <?php elseif($item->status == 'awaiting_client_signature'): ?>
                                    <td class="text-center">
                                    Contract awaiting signature by client.
                                    </td>
                                <?php elseif($item->status == 'awaiting_jim_signature'): ?>
                                    <td class="text-center">
                                    Contract awaiting signature by RNN.
                                    </td>
                                <?php elseif($item->status == 'awaiting_client_changes'): ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('manageContract',$item->id)); ?>" class="btn btn-primary btn-sm"
                                        role="button">Upload Client Changes</a>
                                    </td>
                                <?php elseif($item->status == 'awaiting_legal_approval'): ?>
                                    <td class="text-center">
                                    Awaiting Legal Approval
                                    </td>
                                <?php elseif($item->status == 'changes_requested'): ?>
                                    <td class="text-center">
                                    Changes Requested
                                    </td>
                                <?php elseif($item->status == 'awaiting_product_selection'): ?>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('manageContract',$item->id)); ?>" class="btn btn-primary btn-sm"
                                        role="button">Select Final Products</a>
                                    </td>
                                <?php else: ?>
                                    <td class="text-center">
                                    Unknown status
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                    </div>
            </div>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <section id="previous-uploads-header">
                <div class="container-fluid">
                    <div class="row text-left">
                        <div class="col text-left">
                            <p>Documents</p>
                        </div>
                    </div>
                </div>
            </section>
            <div class="table-responsive">
                <div id="documemts_table" class="table-parent-hidden">
                <table class="table table-striped table-bordered" id="support-documents">
                    <thead>
                        <tr>
                            <th class="text-center">Document Name</th>
                            <th class="text-center">Document Type</th>
                            <th class="text-center">Document Notes</th>
                            <th class="text-center">Expiration Date</th>
                            <th class="text-center">Key Words</th>
                            <th class="text-center">Download</th>
                            <?php if($isManager): ?>
                                <th class="text-center">Edit Document</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="item<?php echo e($item->id); ?>">
                            <td><?php echo e($item->document_name); ?></td>
                            <td><?php echo e($item->type); ?></td>
                            <td><?php echo e($item->notes); ?></td>
                            <td><?php echo e($item->expiration_date == null ? '' : date('m/d/Y', strtotime($item->expiration_date))); ?></td>
                            <td><?php echo e($item->key_words); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('download', $item->file_name)); ?>" download>
                                    <i class="fa fa-download fa-5" aria-hidden="true" style="font-size: 25px;"></i>
                                </a>
                            </td>
                            <?php if($isManager): ?>
                                <td class="text-center">
                                    <a class="btn btn-primary" data-toggle="modal" data-target="#editDocument" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->document_name); ?>" data-notes="<?php echo e($item->notes); ?>"
                                    data-type="<?php echo e($item->type); ?>" data-client_vendor_name="<?php echo e($item->client_vendor_name); ?>" data-client_id="<?php echo e($item->client_id); ?>"
                                    data-created_date="<?php echo e($item->created_date); ?>" data-expiration_date="<?php echo e($item->expiration_date); ?>"
                                    data-key_words="<?php echo e($item->key_words); ?>" data-archived="0">
                                        Edit
                                    </a>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div>
                <div class="loader my-5 ml-5" id="loader2" style="display:show">
                    </div>
            </div>
        </div>
    </div>

</div>
</div>
<div class="modal fade" id="editDocument" tabindex="-1" role="dialog" aria-labelledby="editLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="editLabel">Edit Document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="editDocumentForm">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control" id="id" name="id" value="<?php echo e(old('id')); ?>" hidden>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Name <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="document_name_edit" name="document_name" style="width: 100%;" value="<?php echo e(old('document_name')); ?>" maxlength="150">
                        </div>
                    </div>
                    <input id="client_id" class="form-control" name="client_id" value="<?php echo e($client->id); ?>" hidden>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Type <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <?php $types = array('Client FCRA MSA', 'Client Non FCRA MSA',
                            'Client Product Amendment', 'Client FCRA Amendment', 'MNDA/NDA',
                            'Data Vendor contract', 'Data Vendor NDA', 'Trend Source Audit','Trendsource Background Check',
                            'Verified vendor contract', 'Verified vendor NDA', 'Policy', 'Procedure',
                            'Marketing', 'Deck', 'Presentation', 'FAQs', 'Onboarding', 'Certificate', 'End User Audit', 'OTHER');?>
                            <select id="type_edit" name="type" class="form-control">
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Created Date</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="created_date_edit" name="created_date" autocomplete="off" disabled>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Expiration Date</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="expiration_date_edit" autocomplete="off" name="expiration_date">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">File</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input" id="customFileInput" name="file_name" id="file_name" type="file">
                            <label class="custom-file-label" for="customFileInput" style="margin: 0px 15px 0px 15px;">Choose file...</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;" data-toggle="tooltip" title="Used to help search for the file, seperate the words by a comma">Key Words</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="key_words_edit" name="key_words">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Notes</label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="notes_edit" name="notes" value="<?php echo e(old('notes')); ?>"rows="5" cols="20" maxlength="250"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <span style="float:left;"> <span style="color: red;">* </span> Denotes required field. </span>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id="archived_button" class="btn btn-danger" onclick="archiveDocument()" hidden>Delete</button>
                    <input type="submit" id="submit" class="btn btn-primary float-right" value="Save">
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/validation/editDocument.js')); ?>"></script>
<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>
<script src="<?php echo e(asset('js/editDocument.js?'.time())); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

<script>
$(document).ready(function() {
    var state = $("#company-state").data('state');
    var industry = $("#industry").data('industry');
    $("#company-state").val(state);
    $("#industry").val(industry);

     $('#contracts-table-pending').DataTable({
         "order":[[0,"desc"]],
         dom: 'Bfrtip',
         "pageLength": 5,
         buttons: [
             'excelHtml5',
             'pdfHtml5'
         ],
         initComplete: function() {
             $('#loader1').delay(25).fadeOut();
             $('#contracts-pending-parent').removeClass('table-parent-hidden');
         }
     });

     $('#support-documents').DataTable({
         "order":[[0,"asc"]],
         dom: 'Bfrtip',
         "pageLength": 5,
         buttons: [
             'excelHtml5',
             'pdfHtml5'
         ],
         initComplete: function() {
             $('#loader2').delay(25).fadeOut();
             $('#documemts_table').removeClass('table-parent-hidden');
         }
     });

 });
    $().ready(function () {

    $("#client_information_form").submit(function () {
        if ($(this).valid())
            $.LoadingOverlay("show");
    });

    $("#client_information_form").validate({ // initialize the plugin
        rules: {
            industry: {
                required: true,
            },
            companyName: {
                required: true,
                maxlength: 255
            },
            companyAddress: {
                required: true
            },
            companyState: {
                required: true
            },
            companyCity: {
                required: true
            },
            companyZip: {
                required: true
            },
            companyEmail: {
                required: true
            }
        },
        invalidHandler: function (event, validator) {
            // 'this' refers to the form
            var errors = validator.numberOfInvalids();
            if (errors) {
                $.LoadingOverlay("hide");
            } else {
                $.LoadingOverlay("show");

            }
        }
    });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\clients\editClient.blade.php ENDPATH**/ ?>