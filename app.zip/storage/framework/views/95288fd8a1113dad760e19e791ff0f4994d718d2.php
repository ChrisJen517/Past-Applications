<div class="modal fade" id="newUserModal">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Create New User</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('addNewUser')); ?>" method="POST" id="newUserForm" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">First Name</label>
                        <div class="col-lg-8">
                            <input class="form-control" name="name_first" type="text" value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Last Name</label>
                        <div class="col-lg-8">
                            <input class="form-control" name="name_last" type="text" value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Email</label>
                        <div class="col-lg-8">
                            <input class="form-control" name="email" type="text" value="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Role</label>
                        <div class="col-lg-8">
                            <select class="form-control" name="role" type="text" id="role">
                                <option value="agent">Agent</option>
                                <option value="manager">Manager</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row"  id="hiddenEmail">
                        <label class="col-lg-4 col-form-label form-control-label">Manager Email</label>
                        <div class="col-lg-8">
                            <select class="form-control" name="manager_email" type="text" value="">
                                <option value="" id="none">Select Manager</option>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($manager->email); ?>"><?php echo e($manager->email); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <?php if(Auth::user()->is_admin == 1): ?>
                    <div class="form-group row" id="admin_checkbox_div" hidden>
                        <div class="col-lg-4">
                            Admin Account
                            <input class="form-check-input" name="is_admin" type="hidden" value="0">
                            <input class="form-check-input" name="is_admin" id="admin_checkbox_input" type="checkbox" value="1" style="margin-left: 5px;">
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" id="submit-button" class="btn btn-primary btn-lg">Create</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\addNewUser.blade.php ENDPATH**/ ?>