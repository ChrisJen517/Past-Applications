<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/leadsBoard.css?'.time())); ?>" rel="stylesheet" />
<div class="lead-board" id="mainBody">
    <div class="task-board">
        <?php for($i = 0; $i < sizeof($statuses); $i++): ?>
        <div class="status-card-wrapper">
            <div class="status-card">
                <div class="status-header">
                    <span class="card-header-text"><?php echo e($statuses[$i]); ?></span>
                </div>
                <div class="status">
                    <ul class="sortable ui-sortable" id="sort-<?php echo e($i); ?>" data-column="<?php echo e($i); ?>">
                    <?php if(!empty($cards)): ?>
                        <?php $__currentLoopData = $cards[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="text-row ui-sortable-handle product" onmousedown="setInfo('<?php echo e($card->company_name); ?>', '<?php echo e($card->id); ?>')" data-id="<?php echo e($card->id); ?>" data-position="<?php echo e($card->column_position); ?>">
                            <?php echo e($card->company_name); ?> <?php echo e($card->industry != null ? '- ' . $card->industry : ''); ?>

                            <br>
                            <span style="font-size: 11px;">Last worked: <?php echo e($card->last_worked != null ? $card->last_worked : 'not worked'); ?></span>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    </ul>
                </div>
                <div class="new-company-wrapper text-center">
                    
                </div>
            </div>
        </div>
        <?php endfor; ?>
        
    </div>
</div>

<div class="modal fade" id="cardInfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
    <div class="modal-dialog modal-xxl" role="document">
        <div class="modal-content border-0">
            <div class="modal-body" id="showLeadDiv" style="min-height:20px; max-height:calc(100vh - 100px); overflow-y: auto; overflow-x:hidden;">
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="<?php echo e(asset('js/leadBoard.js')); ?>"></script>
<script>
function addCard(location, text) {
    if (event.keyCode == 13) {
        event.preventDefault();

        var company_name = document.getElementById(text).value;
        var user_id = <?php echo e(Auth::user()->id); ?>;

        swal.fire({
            title: "Are you sure?",
            text: "You are about to create a sales lead for the company " + company_name + ".",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: 'Create'
        }).then((willSave) => {
            if (willSave.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post("/createSalesLead", {
                            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            company_name: company_name,
                            user_id: user_id
                        })
                        .done(function(data) {
                            updated = false;
                            $.LoadingOverlay("hide");
                            $("#"+location).append(
                                `<li class="text-row product ui-sortable-handle" onmousedown="setInfo(' + "'" + '${company_name}, ${data['lead_id']} +' + "'" + ')" data-id="${data['lead_id']}" data-position="${data['column_position']}"> ${company_name} </li>`
                            );
                            swal.fire(
                                "Success",
                                "Lead has been created.",
                                "success"
                            );
                        });
                });
            } else {
                swal.fire(
                    "Cancelled",
                    "Lead was not created!",
                    "error"
                );
            }
        document.getElementById(text).value = "";
        });
    }
}

//opens the worklead within the modal if it is just clicked
var held;
$("#mainBody").on('mousedown', 'div.product', function() {
    held = false;
    setTimeout(function() {
        held =  true;
    }, 500);
}).on('mouseup',function(){
    if((!held) && (cardTitle != null)){
        $('#cardInfo').modal('show');
        $('#myModalLabel').html(cardTitle);

        var url = "<?php echo e(asset('/workLead/modal/:id')); ?>"
        url = url.replace(':id', cardId);

        $('#showLeadDiv').LoadingOverlay("show");

        $('#showLeadDiv').load(url, function(data, statusText, xhr){
            //checks if the response text is that of the login page if so, redirects the page
            if (xhr.responseText.trim().startsWith("<!DOCTYPE html>")) {
                window.location.href = "/";
            }
            $('#showLeadDiv').LoadingOverlay("hide", true);
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\sales_leads\salesLeadsBoard.blade.php ENDPATH**/ ?>