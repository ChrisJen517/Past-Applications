<?php $__env->startSection('content'); ?>

<?php echo $__env->make('Includes.modal.audit.createAuditModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Includes.modal.audit.editAuditModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Includes.modal.audit.manageFilesModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="<?php echo e(asset('css/multiTableProcessing.css?'.time())); ?>" rel="stylesheet" />
<div class="container-fluid">
    <br>
    <a class="btn btn-primary" data-toggle="modal" data-target="#createAudit"
        style="margin:0px 0px 20px 15px; color:white;">Create Audit</a>

    <section id="previous-uploads-header">
        <div class="container-fluid">
            <div class="row text-left">
                <div class="col text-left">
                    <p>Pending Audits</p>
                </div>
            </div>
        </div>
    </section>    
    <div class="table-responsive">
        <div id="contracts-parent" class="table-parent">
            <table class="table table-striped table-bordered" id="pending-audits-table">
                <thead>
                    <tr>
                        <th class="text-center">Number</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Account Manager</th>
                        <th class="text-center">Client</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Created Date</th>
                        <th class="text-center">Due Date</th>
                        <th class="text-center">Manage Files</th>
                        <th class="text-center">Edit</th>
                        <th class="text-center">Ready</th>
                        <th class="text-center">Archive</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $pending = $audits->where('completed_date', null)->where('is_archived', 0); 
                    $today = date('Y-m-d'); 
                    $oneWeek = date('Y-m-d', strtotime('+1 week'));?>
                    <?php $__currentLoopData = $pending; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width:5%;"><?php echo e($item->id); ?></td>
                            <td style="width:5%;"><?php echo e($item->audit_type); ?></td>
                            <td style="width:10%;"><?php echo e($item->audit_name); ?></td>
                            <td style="width:15%;"><?php echo e($item->account_manager); ?></td>
                            <td style="width:15%;">
                                <a href="<?php echo e("/manageClients/edit/".$item->client_id); ?>">
                                    <?php echo e($clients->where('id', $item->client_id)->first()->company_name ?? $item->client_id); ?>

                                </a>    
                            </td>
                            <td style="width:5%;"><?php echo e($item->status); ?></td>
                            <td style="width:5%;"><?php echo e($item->created_at); ?></td>
                            <td
                            <?php if(strtotime($item->due_date) <= strtotime($today)): ?>
                                style="color:white !important; background-color: #bf2821 !important; font-weight: 500; width:10%;"
                            <?php elseif(strtotime($item->due_date) < strtotime($oneWeek)): ?>
                                style="color: white !important; background-color:goldenrod !important; font-weight: 500; width:10%;"
                            <?php endif; ?>>
                                <?php echo e($item->due_date); ?>

                            </td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#manageFilesModal" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->audit_name); ?>">
                                    Manage
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAuditModal" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-client_id="<?php echo e($item->client_id); ?>" data-name="<?php echo e($item->audit_name); ?>" data-notes="<?php echo e($item->notes); ?>" 
                                    data-due_date="<?php echo e($item->due_date); ?>" data-account_manager="<?php echo e($item->account_manager); ?>" data-client_contact="<?php echo e($item->client_contact); ?>" data-status="<?php echo e('pending'); ?>" data-cc="<?php echo e($item->cc); ?>" data-audit_type="<?php echo e($item->audit_type); ?>">
                                    Edit
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-success" onclick="completeAudit(<?php echo e($item->id); ?>, 'complete', '<?php echo e($item->audit_name); ?>')">Ready</button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-danger" onclick="archiveAudit(<?php echo e($item->id); ?>, 'Archive', '<?php echo e($item->audit_name); ?>')">Archive</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <section id="previous-uploads-header">
        <div class="container-fluid">
            <div class="row text-left">
                <div class="col text-left">
                    <p>Ready To Be Sent Audits</p>
                </div>
            </div>
        </div>
    </section>    
    <div class="table-responsive">
        <div id="contracts-parent" class="table-parent">
            <table class="table table-striped table-bordered" id="complete-audits-table">
                <thead>
                    <tr>
                        <th class="text-center">Number</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Account Manager</th>
                        <th class="text-center">Client</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Created Date</th>
                        <th class="text-center">Readied Date</th>
                        <th class="text-center">Manage Files</th>
                        <th class="text-center">Edit</th>
                        <th class="text-center">Archive</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $completed = $audits->where('completed_date', '!=', null)->where('is_archived', 0) ?>
                    <?php $__currentLoopData = $completed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width:5%;"><?php echo e($item->id); ?></td>
                            <td style="width:5%;"><?php echo e($item->audit_type); ?></td>
                            <td style="width:10%;"><?php echo e($item->audit_name); ?></td>
                            <td style="width:15%;"><?php echo e($item->account_manager); ?></td>
                            <td style="width:15%;">
                                <a href="<?php echo e("/manageClients/edit/".$item->client_id); ?>">
                                    <?php echo e($clients->where('id', $item->client_id)->first()->company_name ?? $item->client_id); ?>

                                </a>    
                            </td>
                            <td style="width:5%;">Ready to Send</td>
                            <td style="width:5%;"><?php echo e($item->created_at); ?></td>
                            <td style="width:10%;"><?php echo e($item->completed_date); ?></td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#manageFilesModal" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->audit_name); ?>">
                                    Manage
                                </button>
                            </td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAuditModal" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-client_id="<?php echo e($item->client_id); ?>" data-name="<?php echo e($item->audit_name); ?>" data-notes="<?php echo e($item->notes); ?>" 
                                    data-due_date="<?php echo e($item->due_date); ?>" data-account_manager="<?php echo e($item->account_manager); ?>" data-client_contact="<?php echo e($item->client_contact); ?>" data-status="<?php echo e('complete'); ?>" data-cc="<?php echo e($item->cc); ?>" data-audit_type="<?php echo e($item->audit_type); ?>">
                                    Edit
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-danger" onclick="archiveAudit(<?php echo e($item->id); ?>, 'Archive', '<?php echo e($item->audit_name); ?>')">Archive</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <br>
    <hr>
    <br>
    <section id="previous-uploads-header">
        <div class="container-fluid">
            <div class="row text-left">
                <div class="col text-left">
                    <p>Archived Audits</p>
                </div>
            </div>
        </div>
    </section>    
    <div class="table-responsive">
        <div id="contracts-parent" class="table-parent">
            <table class="table table-striped table-bordered" id="archived-audits-table">
                <thead>
                    <tr>
                        <th class="text-center">Number</th>
                        <th class="text-center">Type</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Account Manager</th>
                        <th class="text-center">Client</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Created Date</th>
                        <th class="text-center">Due Date</th>
                        <th class="text-center">Readied Date</th>
                        <th class="text-center">Manage Files</th>
                        <th class="text-center">Edit</th>
                        <th class="text-center">Unarchive</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $archived = $audits->where('is_archived', 1) ?>
                    <?php $__currentLoopData = $archived; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td style="width:5%;"><?php echo e($item->id); ?></td>
                            <td style="width:5%;"><?php echo e($item->audit_type); ?></td>
                            <td style="width:10%;"><?php echo e($item->audit_name); ?></td>
                            <td style="width:15%;"><?php echo e($item->account_manager); ?></td>
                            <td style="width:15%;">
                                <a href="<?php echo e("/manageClients/edit/".$item->client_id); ?>">
                                    <?php echo e($clients->where('id', $item->client_id)->first()->company_name ?? $item->client_id); ?>

                                </a>    
                            </td>
                            <td style="width:5%;"><?php echo e($item->status); ?></td>
                            <td style="width:5%;"><?php echo e($item->created_at); ?></td>
                            <td style="width:5%;"><?php echo e($item->due_date); ?></td>
                            <td style="width:5%;"><?php echo e($item->completed_date); ?></td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#manageFilesModal" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-name="<?php echo e($item->audit_name); ?>">
                                    Manage
                                </button>
                            </td>
                            <td style="width:10%;" class="text-center">
                                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#editAuditModal" style="color:white;"
                                    data-id="<?php echo e($item->id); ?>" data-client_id="<?php echo e($item->client_id); ?>" data-name="<?php echo e($item->audit_name); ?>" data-notes="<?php echo e($item->notes); ?>" 
                                    data-due_date="<?php echo e($item->due_date); ?>" data-account_manager="<?php echo e($item->account_manager); ?>" data-client_contact="<?php echo e($item->client_contact); ?>" data-status="<?php echo e('complete'); ?>" data-cc="<?php echo e($item->cc); ?>" data-audit_type="<?php echo e($item->audit_type); ?>">
                                    Edit
                                </button>
                            </td>
                            <td style="width:5%;" class="text-center">
                                <button type="submit" id="submit" class="btn btn-danger" onclick="archiveAudit(<?php echo e($item->id); ?>, 'Unarchive', '<?php echo e($item->audit_name); ?>')">Unarchive</button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<br>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        var table = $('#pending-audits-table').DataTable( {
            "order": [[ 7, "asc" ]],
            lengthChange: false,
            buttons: [
            {
                extend: 'excel',
                title: 'Pending Audits'
            }
            ],
            "initComplete": function(settings, json) {
            },
        });

        table.buttons().container()
            .appendTo( '#pending-audits-table_wrapper .col-md-6:eq(0)' );

        var table = $('#complete-audits-table').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
            {
                extend: 'excel',
                title: 'Pending Audits'
            }
            ],
            "initComplete": function(settings, json) {
            },
        });

        var table = $('#archived-audits-table').DataTable( {
            "order": [[ 0, "desc" ]],
            lengthChange: false,
            buttons: [
            {
                extend: 'excel',
                title: 'Pending Audits'
            }
            ],
            "initComplete": function(settings, json) {
            },
        });
    });

    function archiveAudit(auditId, textArchive, name){    
        var _token = $('input[name="_token"]').val();
        swal.fire({
            title: "Are you sure?",
            text: "You are about to "+textArchive+": "+name,
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: textArchive
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('archiveAudit')); ?>",
                        data: {
                            id:auditId,
                            _token:_token
                        },
                    }).then(function(data) {
                        $.LoadingOverlay("hide");

                        swal.fire(
                            "Success",
                            "Successfully "+textArchive+"d "+name+".",
                            "success"
                        ).then(function() {
                            $.LoadingOverlay("show");
                            location.reload();
                        });
                        
                    });
                });
            } else {
                swal.fire("Cancelled", name+" Was Not "+textArchive+"d!", "error");
            }
        }); 
    }

    function completeAudit(auditId, textArchive, name){    
        var _token = $('input[name="_token"]').val();
        swal.fire({
            title: "Are you sure?",
            text: "Are you sure: "+name+" is ready to be sent",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: textArchive
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: "<?php echo e(route('completeAudit')); ?>",
                        data: {
                            id:auditId,
                            _token:_token
                        },
                    }).then(function(data) {
                        $.LoadingOverlay("hide");

                        swal.fire(
                            "Success",
                            "Successfully updated "+name+".",
                            "success"
                        ).then(function() {
                            $.LoadingOverlay("show");
                            location.reload();
                        });
                        
                    });
                });
            } else {
                swal.fire("Cancelled", name+" Was Not Updated!", "error");
            }
        }); 
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\audits\manageAudits.blade.php ENDPATH**/ ?>