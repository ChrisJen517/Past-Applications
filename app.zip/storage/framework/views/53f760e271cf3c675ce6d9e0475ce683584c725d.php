<div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
    <div class="brand-logo text-center">
        <a href="<?php echo e(asset('/manager/dashboard')); ?>">
            <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon">
        </a>
    </div>
    <ul class="sidebar-menu do-nicescroll">
        <li class="sidebar-header">MAIN NAVIGATION</li>
        <li>
            <a href="<?php echo e(asset('/manager/dashboard')); ?>" class="waves-effect">
                <i class="icon-home"></i> <span>Dashboard</span>
            </a>
        </li>
        <li>
            <a href="/supportDocuments" class="waves-effect">
                <i class="far fa-folder"></i> <span>Document Repository</span>
            </a>
        </li>
        <li>
            <a href="/manageUsers" class="waves-effect">
                <i class="fa fa-address-book"></i> <span>Manage Users</span>
            </a>
        </li>
        <li>
            <a href="/manageProductSheet" class="waves-effect">
                <i class="fab fa-product-hunt"></i> <span>Manage Products</span>
            </a>
        </li>
        <li>
            <a href="/manageClients" class="waves-effect">
                <i class="fa fa-address-book"></i> <span>Manage Clients / Vendors</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/showLeads')); ?>" class="waves-effect">
                <i class="fas fa-headset"></i> <span>Show Leads</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/salesLeadStats')); ?>" class="waves-effect">
                <i class="fas fa-shield-alt"></i> <span>Lead Statistics</span>
            </a>
        </li>

        <li>
            <a href="<?php echo e(asset('/productSheet')); ?>" class="waves-effect">
                <i class="fas fa-file-contract"></i> <span>Create Product Sheet</span>
            </a>
        </li>
        <li>
            <a href="/NVN" class="waves-effect">
                <i class="fas fa-stamp"></i> <span>NVN Report</span>
            </a>
        </li>
        <li>
            <a href="javaScript:void();" class="waves-effect">
                <i class="fas fa-file-signature"></i>
                <span>Generate Contract</span><i class="fa fa-angle-right pull-right"></i>
            </a>
            <ul class="sidebar-submenu">
                <li><a href="<?php echo e(asset('/MSA')); ?>"><i class="fa fa-circle-o"></i>Standard FCRA MSA</a></li>
                <li><a href="<?php echo e(asset('/MSA_No_FCRA')); ?>"><i class="fa fa-circle-o"></i>Non FCRA MSA</a></li>
                <li><a href="<?php echo e(asset('/MSA_Amendment')); ?>"><i class="fa fa-circle-o"></i>MSA Amendment</a></li>
                <li><a href="<?php echo e(asset('/FCRA')); ?>"><i class="fa fa-circle-o"></i>FCRA Amendment</a></li>
                <li><a href="<?php echo e(asset('/You-Negotiate')); ?>"><i class="fa fa-circle-o"></i>You-Negotiate</a></li>
                <li><a href="<?php echo e(asset('/YNAmendment')); ?>"><i class="fa fa-circle-o"></i>YN Amendment</a></li>
                <?php if(Auth::user()->is_admin == 1): ?>
                    <li><a href="<?php echo e(asset('/ResellerAgreement')); ?>"><i class="fa fa-circle-o"></i>YN Reseller Agreement</a></li>
                <?php endif; ?>
                <li><a href="<?php echo e(asset('/RedlineStart')); ?>"><i class="fa fa-circle-o"></i>Redline</a></li>
                <li><a href="<?php echo e(asset('/NDA')); ?>"><i class="fa fa-circle-o"></i>NDA</a></li>
                <li><a href="<?php echo e(asset('/ICA')); ?>"><i class="fa fa-circle-o"></i>Independent Contractor <span style="margin-left:30px">Agreement</span></a></li>
                <li><a href="<?php echo e(asset('/CertFCRA')); ?>"><i class="fa fa-circle-o"></i>Certification of FCRA <span style="margin-left:30px">Collection</span></a></li>
                <li><a href="<?php echo e(asset('/Name_Change_Amendment')); ?>"><i class="fa fa-circle-o"></i>Name Change <span style="margin-left:30px">Amendment</span></a></li>
            </ul>
        </li>
        <li>
            <a href="/audits" class="waves-effect">
                <i class="fa fa-folder-open"></i> <span>Client Audits</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/RequestForm')); ?>" class="waves-effect">
                <i  class="fa fa-credit-card-alt" aria-hidden="true"></i> <span>Request Form</span>
            </a>
        </li>
    </ul>
</div>

<div id="sidebar-wrapper-icons">
    <div class="brand-logo text-center small-bar">
        <a href="<?php echo e(asset('/dashboard')); ?>" class="small-image-wrapper">
            <img src="/images/Small-R.png" class="logo-icon" alt="logo icon">
        </a>
    </div>
    <ul class="sidebar-menu do-nicescroll" style="margin-top: 10px;">
        
        <li>
            <a href="/" class="nav-link waves-effect">
                <i class="icon-home"></i>
            </a>
        </li>
        <li>
            <a href="/supportDocuments" class="nav-link waves-effect">
                <i class="far fa-folder"></i>
            </a>
        </li>
        
        <li>
            <a href="/manageUsers" class="nav-link waves-effect">
                <i class="fa fa-address-book"></i>
            </a>
        </li>
        <li>
            <a href="/manageProductSheet" class="waves-effect">
                <i class="fab fa-product-hunt"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/manageClients')); ?>" class="nav-link waves-effect">
                <i class="fa fa-address-book"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/showLeads')); ?>" class="waves-effect">
                <i class="fas fa-headset"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/salesLeadStats')); ?>" class="waves-effect">
                <i class="fas fa-shield-alt"></i>
            </a>
        </li>
        <li>
            <a href="/NVN" class="waves-effect">
                <i class="fas fa-stamp"></i>
            </a>
        </li>
        <li>
            <a href="javaScript:void();" class="waves-effect">
                <i class="fas fa-file-signature "></i>
                <i class="fa fa-angle-right float-right"></i>
            </a>
            <ul class="sidebar-submenu sidebar-submenu-icons">
                <li><a href="<?php echo e(asset('/MSA')); ?>">Standard FCRA MSA</a></li>
                <li><a href="<?php echo e(asset('/MSA_No_FCRA')); ?>">Non FCRA MSA</a></li>
                <li><a href="<?php echo e(asset('/MSA_Amendment')); ?>">MSA Amendment</a></li>
                <li><a href="<?php echo e(asset('/productSheet')); ?>">Product Sheet</a></li>
                <li><a href="<?php echo e(asset('/You-Negotiate')); ?>">You-Negotiate</a></li>
                <li><a href="<?php echo e(asset('/YNAmendment')); ?>">YN Amendment</a></li>
                <?php if(Auth::user()->is_admin == 1): ?>
                    <li><a href="<?php echo e(asset('/ResellerAgreement')); ?>">YN Reseller Agreement</a></li>
                <?php endif; ?>
                <li><a href="<?php echo e(asset('/RedlineStart')); ?>">Redline</a></li>
                <li><a href="<?php echo e(asset('/FCRA')); ?>">FCRA</a></li>
                <li><a href="<?php echo e(asset('/NDA')); ?>">NDA</a></li>
                <li><a href="<?php echo e(asset('/ICA')); ?>">Independent Contractor Agreement</a></li>
                <li><a href="<?php echo e(asset('/CertFCRA')); ?>">Certification of FCRA <span style="margin-left:30px">Collection</span></a></li>
                <li><a href="<?php echo e(asset('/Name_Change_Amendment')); ?>">Name Change <span style="margin-left:30px">Amendment</span></a></li>
            </ul>
        </li>
        <li>
            <a href="/audits" class="waves-effect">
                <i class="fa fa-folder-open"></i>
            </a>
        </li>
        <li>
            <a href="<?php echo e(asset('/RequestForm')); ?>" class="waves-effect">
                <i  class="fa fa-credit-card-alt" aria-hidden="true"></i>
            </a>
        </li>
    </ul>
</div>

<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/plugins/simplebar/js/simplebar.js')); ?>"></script>
<!-- sidebar-menu js -->
<script src="<?php echo e(asset('js/sidebar-menu.js')); ?>"></script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views/Includes/manager/sidebar.blade.php ENDPATH**/ ?>