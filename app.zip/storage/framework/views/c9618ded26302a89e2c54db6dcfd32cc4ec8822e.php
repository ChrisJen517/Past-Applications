<link href="<?php echo e(asset('css/modal.css?'.time())); ?>" rel="stylesheet"/>

<div class="modal fade" id="tossAccountsModal">
    <div class="modal-dialog modal-sm-6">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title">Toss Accounts (<?php echo e($total_unassigned); ?> Unassigned)</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
        </form>
            <form action="<?php echo e(route('assignAgentLeads')); ?>" method="POST" enctype="multipart/form-data" id="tossAccounts">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Agent</label>
                        <div class="col-lg-8">
                            <select id="id" name="id" class="form-control" size="0" value="" required>
                                <option value="" selected disabled>Select Agent</option>
                                <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($lead->agent_id); ?>"><?php echo e($lead->agent_name); ?> - <?php echo e($lead->total_accounts); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Max Accounts</label>
                        <div class="col-lg-8">
                            <input type="number" class="form-control" id="accounts" name="accounts" value="10" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Industry</label>
                        <div class="col-lg-8">
                            <select id="industry" name="industry" class="form-control" size="0" value="">
                                <option value="" selected>Industry</option>
                                <?php $__currentLoopData = $unassigned; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $industry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($industry->industry); ?>"><?php echo e($industry->industry); ?> - <?php echo e($industry->total); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button class="btn btn-danger" type="submit" style="color: white;">Assign</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src=<?php echo e(asset('js/validation/tossAccounts.js?'.time())); ?>></script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\tossAccountsModal.blade.php ENDPATH**/ ?>