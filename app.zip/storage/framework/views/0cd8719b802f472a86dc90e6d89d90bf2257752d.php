<?php $__env->startSection('content'); ?>
<br>

<section id="unworked-leads-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col text-left">
                <p>Unworked Leads:</p>
            </div>
            <?php if(Auth::user()->role == 'manager'): ?>
            <div class="col text-right">
                <a class="btn btn-primary float-right" onclick="postExportAll('1')" style="color: white;">Export All Contacts for Unworked Leads</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<div class="row" style="margin-bottom: 15px;">
    <div class="col-md-4">
        <td class="text-center">
            <?php if(Auth::user()->role == 'manager'): ?>
            <button class="btn btn-info btn-sm btn-selected" id="unworked-selected-assign" id-names="temp" company-name="companies" style="margin-left: 15px; margin-bottom: 5px;">
                Assign Agent to Selected Leads
            </button>
            <button class="btn btn-primary btn-sm btn-selected-contacts" id="unworked-selected-export-contacts" style="display: none; margin-left: 15px; margin-right: 15px;">
                Export Contacts for Selected Leads
            </button>
            <?php endif; ?>
        </td>
    </div>
    <div class="col-md-8"></div>
</div>

<section id="unworked-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="unworked-leads-div">
                <div id="parent1" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="unworked-leads-table" style="overflow-x: auto; width: 100%;" data-type="unworked" data-export="unworked-selected-export-contacts">
                        <thead>
                            <tr>
                                <?php if(Auth::user()->role == 'manager'): ?>
                                    <th class="text-center">Checkboxes</th>
                                <?php endif; ?>
                                <th class="text-center">Lead ID</th>
                                <th class="text-center">Assigned Agent</th>
                                <th class="text-center">Company Name</th>
                                <th class="text-center">Industry</th>
                                <th class="text-center">State</th>
                                <th class="text-center">Last Updated</th>
                                <?php if(Auth::user()->role == 'manager'): ?>
                                    <th class="text-center">Assign Agent</th>
                                <?php endif; ?>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<hr>
<br>

<section id="completed-leads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Closed Leads:</p>
            </div>
            <?php if(Auth::user()->role == 'manager'): ?>
            <div class="col text-right">
                <a class="btn btn-primary float-right" onclick="postExportAll('0')" style="color: white;">Export All Contacts for Closed Leads</a>
            </div>
            <?php endif; ?>
        </div>
    </div>
</section>

<div class="row" style="margin-bottom: 15px;">
    <div class="col-md-4">
        <td class="text-center">
            <?php if(Auth::user()->role == 'manager'): ?>
            <button class="btn btn-info btn-sm btn-selected" id="worked-selected-assign" id-names="temp" company-name="companies" style="margin-left: 15px; margin-bottom: 5px;">
                Assign Agent to Selected Leads
            </button>
            <button class="btn btn-primary btn-sm btn-selected-contacts" id="worked-selected-export-contacts" style="display: none; margin-left: 15px; margin-right: 15px;">
                Export Contacts for Selected Leads
             </button>
             <?php endif; ?>
        </td>
    </div>
    <div class="col-md-8"></div>
</div>

<section id="completed-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="completed-leads-div">
                <div id="parent2" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="completed-leads-table" style="overflow-x: auto; width: 100%;" data-type="worked" data-export="worked-selected-export-contacts">
                        <thead>
                            <tr>
                                <?php if(Auth::user()->role == 'manager'): ?>
                                    <th class="text-center">Checkboxes</th>
                                <?php endif; ?>
                                <th class="text-center">Lead ID</th>
                                <th class="text-center">Assigned Agent</th>
                                <th class="text-center">Company Name</th>
                                <th class="text-center">Industry</th>
                                <th class="text-center">State</th>
                                <th class="text-center">Last Updated</th>
                                <?php if(Auth::user()->role == 'manager'): ?>
                                    <th class="text-center">Assign Agent</th>
                                <?php endif; ?>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader2" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<div class="modal fade" id="addToAgent" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-sm-6" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="myModalLabel">Add to Agent Queue</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body" id="myModalUpdateBody">
                <form action="<?php echo e(route('addToAgentQueue')); ?>" method="POST" id="addAgentForm"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input hidden value="" name="sales_lead_id">
                    <div class="form-group row">
                        <label class="col-lg-4 col-form-label form-control-label">Select an Agent</label>
                        <div class="col-lg-8">
                            <select class="form-control" name="user_id" style="margin-top:5px;">
                                <!--
                                    Minimal change to time efficieny but scales depending on user table size.
                                    Also allows for less ordering in SQL statement and saves a capitalizeOnce call?
                                    Can research whether doing a double sort is better.
                                -->
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($agent->role == 'agent'): ?>
                                        <option value="<?php echo e($agent->user_id); ?>"><?php echo e($agent->name_first); ?> <?php echo e($agent->name_last); ?> - Agent - <?php echo e($agent->lead_count); ?> Leads</option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($agent->role == 'manager'): ?>
                                        <option value="<?php echo e($agent->user_id); ?>"><?php echo e($agent->name_first); ?> <?php echo e($agent->name_last); ?> - Manager - <?php echo e($agent->lead_count); ?> Leads</option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <input id="add_queue_submit" type="submit" name="submit" class="btn btn-info float-right"
                    value="Add to Agent">
                </form>
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<?php ($orderColumn = (Auth::user()->role == 'manager' ? 1 : 0)); ?>

<script>
var unworked, worked;
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    unworked = $('#unworked-leads-table').DataTable({
        "info": true,
        "processing": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "serverSide": true,
        "ajax": {
                    "url": "<?php echo e(url('exportLeadsJson', '1')); ?>",
                    "dataType": "json",
                    "type": "POST",
                    "data":{ _token: "<?php echo e(csrf_token()); ?>"}
        },
        "lengthMenu": [
            [10, 25, 50, 100], [10, 25, 50, 100]
        ],
        "order":[[<?php echo e($orderColumn); ?>,"desc"]],
        "pageLength": 10,
        <?php if(Auth::user()->role == 'manager'): ?>
        'columnDefs': [
            {
                'targets': 0,
                'orderable': false,
                'checkboxes': {
                    'selectRow': true
                }
            },
            {
                'targets': [7, 8],
                'orderable': false
            }
        ],
        'select': {
            'style': 'multi'
        },
        "columns": [
            { "data": "id" },
            { "data": "id" },
            { "data": "agent_id" },
            { "data": "company_name" },
            { "data": "industry" },
            { "data": "company_state", "className": "text-center" },
            { "data": "updated_at", "className": "text-center" },
            { "data": "assign_agent", "className": "text-center" },
            { "data": "action", "className": "text-center" }
        ],
        <?php else: ?>
        "columns": [
            { "data": "id" },
            { "data": "agent_id" },
            { "data": "company_name" },
            { "data": "industry" },
            { "data": "company_state", "className": "text-center" },
            { "data": "updated_at", "className": "text-center" },
            { "data": "action", "className": "text-center" }
        ],
        <?php endif; ?>
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#parent1').removeClass('table-parent-hidden');

            var input = $("#parent1 .dataTables_filter input").unbind();
            var self = this.api();

            $("#parent1 .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#parent1 .dataTables_filter").append($searchButton);
        }
    });

    worked = $('#completed-leads-table').DataTable({
        "info": true,
        "processing": true,
        "language": {
            'loadingRecords': '&nbsp;',
            processing: '<i class="fa fa-refresh fa-spin"></i>'
        },
        "serverSide": true,
        "ajax": {
                    "url": "<?php echo e(url('exportLeadsJson', '0')); ?>",
                    "dataType": "json",
                    "type": "POST",
                    "data":{ _token: "<?php echo e(csrf_token()); ?>"}
        },
        "lengthMenu": [
            [10, 25, 50, 100], [10, 25, 50, 100]
        ],
        "order":[[<?php echo e($orderColumn); ?>,"desc"]],
        "pageLength": 10,
        <?php if(Auth::user()->role == 'manager'): ?>
        'columnDefs': [
            {
                'targets': 0,
                'orderable': false,
                'checkboxes': {
                    'selectRow': true
                }
            },
            {
                'targets': [7, 8],
                'orderable': false
            }
        ],
        'select': {
            'style': 'multi'
        },
        "columns": [
            { "data": "id" },
            { "data": "id" },
            { "data": "agent_id" },
            { "data": "company_name" },
            { "data": "industry" },
            { "data": "company_state", "className": "text-center" },
            { "data": "updated_at", "className": "text-center" },
            { "data": "assign_agent", "className": "text-center" },
            { "data": "action", "className": "text-center" }
        ],
        <?php else: ?>
        "columns": [
            { "data": "id" },
            { "data": "agent_id" },
            { "data": "company_name" },
            { "data": "industry" },
            { "data": "company_state", "className": "text-center" },
            { "data": "updated_at", "className": "text-center" },
            { "data": "action", "className": "text-center" }
        ],
        <?php endif; ?>
        initComplete: function() {
            $('#loader2').delay(25).fadeOut();
            $('#parent2').removeClass('table-parent-hidden');

            var input = $("#parent2 .dataTables_filter input").unbind();
            var self = this.api();

            $("#parent2 .dataTables_filter input").keyup(function (e) {
                // Allows use of Enter key for searching
                if (e.keyCode == 13)
                    self.search(input.val().replace(/['"]+/g, '')).draw();
            }),
            ($searchButton = $(
                '<button class="btn btn-info btn-sm" style="margin-left: 10px;">'
            ).text("search")
            .click(function () {
                self.search(input.val().replace(/['"]+/g, '')).draw();
            }));
            $("#parent2 .dataTables_filter").append($searchButton);
        }
    });

    $("input[type='checkbox']").change(function() {
        var table = $(this).closest('table');

        if (table.data('type') == 'worked')
            var selected = worked.column(0).checkboxes.selected();
        else
            var selected = unworked.column(0).checkboxes.selected();

        var button = $('#' + table.data('export'));
        if (selected.length == 0)
            $(button).hide();
        else
            $(button).show();
    });

    $('.btn-selected-contacts').on('click', function(e) {
        if ($(this).attr('id') == 'worked-selected-export-contacts')
            var selected = worked.column(0).checkboxes.selected();
        else
            var selected = unworked.column(0).checkboxes.selected();

        if (selected.length == 0) {
            e.preventDefault();
        } else {
            swal.fire({
                title: "Are you sure?",
                text: "You are about to export a spreadsheet with contacts available from " + selected.length + " lead(s).",
                icon: "warning",
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: 'Export'
            }).then((willExport) => {
                if (willExport.value) {
                    postExport('<?php echo e(route('exportContacts')); ?>', selected);
                } else {
                    swal.fire(
                        "Cancelled",
                        "Not exporting the spreadsheet!",
                        "error"
                    );
                }
            });
        }
    });

    function postExport(path, selected) {
        $.LoadingOverlay('show');
        var form = $('<form></form>');
        form.append('<?php echo csrf_field(); ?>')

        form.attr("method", "post");
        form.attr("action", path);

        $.each(selected, function(index, rowId) {
            var field = $('<input></input>');

            field.attr("type", "hidden");
            field.attr("name", 'leads[]');
            field.attr("value", rowId);

            form.append(field);
        });

        $.post('<?php echo e(route("exportContacts")); ?>', form.serialize(), function(data, status) {
            if (status == 'success') {
                var fileName = data['fileName'];
                window.location.href = '/downloadExport/' + fileName;
                $.LoadingOverlay('hide');
            } else {
                swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                $.LoadingOverlay('hide');
            }
        });
    }

    $('.btn-selected').on('click', function(e) {
        if ($(this).attr('id') == 'worked-selected-assign')
            var selected = worked.column(0).checkboxes.selected();
        else
            var selected = unworked.column(0).checkboxes.selected();

        if (selected.length == 0) {
            e.preventDefault();
        } else {
            swal.fire({
                title: "Are you sure?",
                text: "You are about to choose an agent to assign " + selected.length + " lead(s) to.",
                icon: "warning",
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: 'Confirm'
            }).then((willAssign) => {
                if (willAssign.value) {

                    $.each(selected, function(index, rowId) {
                        $('#addAgentForm').append(
                            $('<input>')
                                .attr('type', 'hidden')
                                .attr('name', 'sales_lead_ids[]')
                                .val(rowId)
                        );
                    });

                    $('#addToAgent').modal('show');
                } else {
                    swal.fire(
                        "Cancelled",
                        "Not assigning the leads to an agent!",
                        "error"
                    );
                }
            });
        }
    });

    $('#addToAgent').on('show.bs.modal', function (e) {
        var opener = $(e.relatedTarget);
        var ids = $('#addAgentForm').find('[name="sales_lead_ids[]"]');

        if (ids.length == 0) {
            var idName = $(opener).attr('id-name');
            $('#addAgentForm').find('[name="sales_lead_id"]').val(idName);
        }
    });

    $('#addToAgent').on('hidden.bs.modal', function () {
        var ids = $('#addAgentForm').find('[name="sales_lead_id[]"]');
        ids.val('');
    });
});

function postExportAll(unworked) {
    window.location.href = '/exportAllContacts/' + unworked;
    swal.fire('Success', 'Contact export has been initiated. Your download should start shortly.', 'success');
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\sales_leads\showLeads.blade.php ENDPATH**/ ?>