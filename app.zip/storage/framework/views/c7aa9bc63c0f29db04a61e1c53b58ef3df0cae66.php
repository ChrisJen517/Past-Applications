<link href="<?php echo e(asset('css/workForm.css')); ?>" rel="stylesheet" />
<form action="<?php echo e(route('closeLead')); ?>" method="POST" enctype="multipart/form-data" id="Update">
    <?php echo csrf_field(); ?>
<div class="row" style="margin-left:0.2%; margin-right:0.2%;">
    <div class="col-lg-12" style="margin-top:10px;">
        <div class="card">
            <div class="card-header lead-header" style="border-radius: .2em .2em 0px 0px !important">
                <div class="row">
                    <div class="text-center" style="margin: 0px 10px 0px 5px;">
                        <i class="far fa-building" style="font-size: 30px; color: mediumpurple"></i>
                    </div>
                    <div class="col">
                        <div class="row">
                            <span class="small-text">Account</span>
                        </div>
                        <div class="row" style="width:98%;">
                            <span><?php echo e($lead->company_name); ?> (<?php echo e($lead->id); ?>)</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="mainBody">
                    <input type="hidden" name="lead_id" value="<?php echo e($lead->id); ?>">
                    <div class="row">
                        <div class="col-md-3">
                            <span class="small-text">
                                Phone
                            </span>
                            <p>
                                <?php echo e($lead->company_phone); ?>

                                <span>
                                    <i class="zmdi zmdi-phone phone-button" style="color: dodgerblue; font-size: 20px;" data-number="<?php echo e($lead->company_phone); ?>" aria-hidden="true" <?php if($lead->company_phone == null): ?> hidden <?php endif; ?>></i>
                                </span>
                            </p>
                        </div>
                        <div class="col-md-3">
                            <span class="small-text">Billing Address</span>
                            <p class="no-spacing"><?php echo e($lead->company_address); ?></p>
                            <p class="no-spacing"><?php echo e($lead->company_city); ?>, <?php echo e($lead->company_state); ?> <?php echo e($lead->company_zip); ?></p>
                            <p class="no-spacing"><?php echo e($lead->country); ?></p>
                        </div>
                        <div class="col-md-3">
                            <span class="small-text">Website</span>
                            <p><?php echo e($lead->company_url); ?></p>
                        </div>
                        <div class="col-md-3">
                            <span class="small-text">Account Owner</span>
                            <p><?php echo e($lead->sales_agent); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row" style="margin-left:0.2%">
    <div class="col-lg-6" style="margin-top:10px margin-right: 0px; padding-right: 0px;">
        <div class="card">
            <div class="card-header lead-header" style="border-radius: .2em .2em 0px 0px !important">
                <div class="row">
                    <div class="text-center" style="margin: 0px 10px 0px 5px;">
                        <i class="fas fa-list" style="font-size: 30px; color: mediumpurple"></i>
                    </div>
                    <div class="col-md-11">
                        <div class="row">
                            <span class="small-text">Lead</span>
                        </div>
                        <div class="row">
                            <p class="no-spacing">Information</p>
                        </div>
                    </div>
                </div>
                <div class="row" style="margin-bottom: 10px;">
                    <div class="col-md-12">
                        <div class="buttons ml-auto">
                            <button type="submit" name="submit" id="update" value="update" class="btn btn-success btn-lg float-right" style="margin-right: 15px;">Save</button>
                            <?php if($page): ?>
                                <button type="submit" name="submit" id="update_and_next" value="update_and_next" class="btn btn-success btn-lg float-right" style="margin-right: 15px;">Save and Get New Lead</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Account Name</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="company_name" id="company_name" value="<?php echo e($lead->company_name); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Account ID</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom always-disabled" name="id" id="id" value="<?php echo e($lead->id); ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Account Agent</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom always-disabled" name="sales_agent" id="sales_agent" value="<?php echo e($lead->sales_agent); ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Status</label>
                                </div>
                                <div class="col-md-8">
                                    <select type="text" class="form-control-custom readonly" name="status" id="status" style="background-color: transparent; color: #545454; color: black;">
                                        <?php for($i = 0; $i < count($statuses); $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php if($i == $lead->column_number): ?> selected <?php else: ?> disabled <?php endif; ?>>
                                            <?php echo e($statuses[$i]); ?>

                                        </option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Website</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="company_url" id="company_url" value="<?php echo e($lead->company_url); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Email</label>
                                </div>
                                <div class="col-md-7">
                                    <input type="text" class="form-control-custom email-target" name="email" id="email" value="<?php echo e($lead->company_email); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="zmdi zmdi-email email-button" data-targetclass="email-target" style="color: forestgreen; font-size: 20px; margin-left: 100%;" id="lead_info_email" <?php if($lead->company_email == null): ?> hidden <?php endif; ?>></i>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Phone</label>
                                </div>
                                <div class="col-md-7">
                                    <input type="text" class="form-control-custom phone-2-target" name="company_phone" id="company_phone" value="<?php echo e($lead->company_phone); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <span>
                                        <i class="zmdi zmdi-phone phone-button" style="color: dodgerblue; font-size: 20px; margin-left: 100%;" data-targetclass="phone-2-target" aria-hidden="true" id="lead_info_phone" <?php if($lead->company_phone == null): ?> hidden <?php endif; ?>></i>
                                    </span>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Address</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="address" id="address" value="<?php echo e($lead->company_address); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Address 2</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="address2" id="address2" value="<?php echo e($lead->company_address_2); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">City</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="city" id="city" value="<?php echo e($lead->company_city); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">State</label>
                                </div>
                                <div class="col-md-8">
                                    <select id="state" name="state" class="form-control-custom readonly" size="0" value="<?php echo e($lead->company_state); ?>" style="background-color: transparent; color: #545454; color: black;">
                                        <option disabled value="">State</option>
                                        <option disabled value="AL">Alabama</option>
                                        <option disabled value="AK">Alaska</option>
                                        <option disabled value="AZ">Arizona</option>
                                        <option disabled value="AR">Arkansas</option>
                                        <option disabled value="CA">California</option>
                                        <option disabled value="CO">Colorado</option>
                                        <option disabled value="CT">Connecticut</option>
                                        <option disabled value="DE">Delaware</option>
                                        <option disabled value="DC">District Of Columbia</option>
                                        <option disabled value="FL">Florida</option>
                                        <option disabled value="GA">Georgia</option>
                                        <option disabled value="HI">Hawaii</option>
                                        <option disabled value="ID">Idaho</option>
                                        <option disabled value="IL">Illinois</option>
                                        <option disabled value="IN">Indiana</option>
                                        <option disabled value="IA">Iowa</option>
                                        <option disabled value="KS">Kansas</option>
                                        <option disabled value="KY">Kentucky</option>
                                        <option disabled value="LA">Louisiana</option>
                                        <option disabled value="ME">Maine</option>
                                        <option disabled value="MD">Maryland</option>
                                        <option disabled value="MA">Massachusetts</option>
                                        <option disabled value="MI">Michigan</option>
                                        <option disabled value="MN">Minnesota</option>
                                        <option disabled value="MS">Mississippi</option>
                                        <option disabled value="MO">Missouri</option>
                                        <option disabled value="MT">Montana</option>
                                        <option disabled value="NE">Nebraska</option>
                                        <option disabled value="NV">Nevada</option>
                                        <option disabled value="NH">New Hampshire</option>
                                        <option disabled value="NJ">New Jersey</option>
                                        <option disabled value="NM">New Mexico</option>
                                        <option disabled value="NY">New York</option>
                                        <option disabled value="NC">North Carolina</option>
                                        <option disabled value="ND">North Dakota</option>
                                        <option disabled value="OH">Ohio</option>
                                        <option disabled value="OK">Oklahoma</option>
                                        <option disabled value="OR">Oregon</option>
                                        <option disabled value="PA">Pennsylvania</option>
                                        <option disabled value="PR">Puerto Rico</option>
                                        <option disabled value="RI">Rhode Island</option>
                                        <option disabled value="SC">South Carolina</option>
                                        <option disabled value="SD">South Dakota</option>
                                        <option disabled value="TN">Tennessee</option>
                                        <option disabled value="TX">Texas</option>
                                        <option disabled value="UT">Utah</option>
                                        <option disabled value="VT">Vermont</option>
                                        <option disabled value="VA">Virginia</option>
                                        <option disabled value="WA">Washington</option>
                                        <option disabled value="WV">West Virginia</option>
                                        <option disabled value="WI">Wisconsin</option>
                                        <option disabled value="WY">Wyoming</option>
                                    </select>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Zip</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="zip" id="zip" value="<?php echo e($lead->company_zip); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Country</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="country" id="country" value="<?php echo e($lead->country); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Industry</label>
                                </div>
                                <div class="col-md-8">
                                    <select id="industry" name="industry" class="form-control-custom readonly" size="0" value="<?php echo e($lead->industry); ?>" style="background-color: transparent; color: #545454; color: black;">
                                        <option disabled value="" selected disabled>Industry</option>
                                        <option disabled value="Bank: All Other">Bank: All Other</option>
                                        <option disabled value="Bank: Top 200">Bank: Top 200</option>
                                        <option disabled value="Bank Association">Bank Association</option>
                                        <option disabled value="Collection Agency">Collection Agency</option>
                                        <option disabled value="Collection Law Firm">Collection Law Firm</option>
                                        <option disabled value="Consulting Company">Consulting Company</option>
                                        <option disabled value="Credit Union">Credit Union</option>
                                        <option disabled value="Debt Buyer">Debt Buyer</option>
                                        <option disabled value="Financial Services">Financial Services</option>
                                        <option disabled value="Government: City">Government: City</option>
                                        <option disabled value="Government: County">Government: County</option>
                                        <option disabled value="Government: State">Government: State</option>
                                        <option disabled value="Government: Federal">Government: Federal</option>
                                        <option disabled value="Healthcare">Healthcare</option>
                                        <option disabled value="Loan Originator: Auto">Loan Originator: Auto</option>
                                        <option disabled value="Loan Originator: Credit Card">Loan Originator: Credit Card</option>
                                        <option disabled value="Loan Originator: FinTech">Loan Originator: FinTech</option>
                                        <option disabled value="Loan Originator: Mortgage">Loan Originator: Mortgage</option>
                                        <option disabled value="Loan Originator: Other">Loan Originator: Other</option>
                                        <option disabled value="Loan Originator: Student Loan">Loan Originator: Student Loan</option>
                                        <option disabled value="Private Equity Firm">Private Equity Firm</option>
                                        <option disabled value="Service Provider">Service Provider</option>
                                        <option disabled value="Software">Software</option>
                                        <option disabled value="University">University</option>
                                        <option disabled value="Vendor">Vendor</option>
                                        <option disabled value="Other">Other</option>
                                    </select>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">LinkedIn</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="company_linkedin" id="company_linkedin" value="<?php echo e($lead->company_linkedin); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Company Size</label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control-custom" name="employees_count" id="employees_count" value="<?php echo e($lead->employees_count); ?>" readonly>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label class="form-control-label">Description</label>
                                </div>
                                <div class="col-md-8">
                                    <textarea type="text" rows="5" class="form-control-custom" name="description" id="description" value="<?php echo e($lead->description); ?>" readonly><?php echo e($lead->description); ?></textarea>
                                </div>
                                <div class="col-md-1">
                                    <i class="fas fa-pen icon-custom"></i>
                                </div>
                            </div>
                        </div>
                        <hr class="no-spacing">
                    </div>
                </div>
                <br>
                <a class="btn btn-details collapsed" data-toggle="collapse" href="#qualifying-questions" role="button" aria-expanded="true" aria-controls="qualifying-questions">
                    <i class="fa fa-custom-drop float-left" style="font-size: 20px; color: mediumpurple;"></i>
                    Qualifying Questions
                </a>
                <div class="collapse" id="qualifying-questions">
                    Qualifying
                </div>

                <a class="btn btn-details collapsed" data-toggle="collapse" href="#debt-information" role="button" aria-expanded="true" aria-controls="debt-information">
                    <i class="fa fa-custom-drop float-left" style="font-size: 20px; color: mediumpurple;"></i>
                    Debt Information
                </a>
                <div class="collapse" id="debt-information">
                    Debt
                </div>
                <a class="btn btn-details collapsed" data-toggle="collapse" href="#address-information" role="button" aria-expanded="true" aria-controls="address-information">
                    <i class="fa fa-custom-drop float-left" style="font-size: 20px; color: mediumpurple;"></i>
                    Address Information
                </a>
                <div class="collapse" id="address-information">
                    Address
                </div>
                <a class="btn btn-details collapsed" data-toggle="collapse" href="#system-information" role="button" aria-expanded="true" aria-controls="system-information">
                    <i class="fa fa-custom-drop float-left" style="font-size: 20px; color: mediumpurple;"></i>
                    System Information
                </a>
                <div class="collapse" id="system-information">
                    System
                </div>
            </div>
            <div class="card-footer">
                <input hidden value="<?php echo e($page); ?>" name="page">
                <button type="submit" name="submit" id="update" value="update" class="btn btn-success btn-lg float-right">Save</button>
                <?php if($page): ?>
                    <button type="submit" name="submit" id="update_and_next" value="update_and_next" class="btn btn-success btn-lg float-right" style="margin-right: 15px;">Save and Get New Lead</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    </form>
    <div class="col-lg-6" style="margin-left: 0px; padding-left: 0px;">
        <div id="event-widget">
            <?php echo $__env->make('Includes.widgets.eventWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="loader my-5 ml-5" id="event-loader" style="display:none">
        </div>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header lead-header" style="border-radius: .2em .2em 0px 0px !important">
                <div class="row">
                    <div class="text-center" style="margin: 0px 10px 0px 5px;">
                        <i class="far fa-address-book" style="font-size: 30px; color: mediumpurple"></i>
                    </div>
                    <div class="col">
                        <div class="row">
                            <span class="small-text">Lead</span>
                        </div>
                        <div class="row">
                            <p class="no-spacing">Contacts</p>
                            <button type="button" class="btn btn-md ml-auto btn-primary btn-lg text-white" data-toggle="modal" style="position: absolute; bottom: 5px; right: 50px;" data-target="#ContactModal">
                                Add Contact
                            </button>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <table class="table table-striped" id="contacts_table">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 10%;" scope="col">Title</th>
                                <th class="text-center" style="width: 15%;" scope="col">First Name</th>
                                <th class="text-center" style="width: 15%;" scope="col">Last Name</th>
                                <th class="text-center" style="width: 20%;" scope="col">Email Address</th>
                                <th class="text-center" style="width: 10%;" scope="col">Phone Number</th>
                                <th class="text-center" style="width: 5%;" scope="col">Phone Ext</th>
                                <th class="text-center" style="width: 20%;" scope="col">Linked In</th>
                                <th class="text-center" style="width: 5%;" scope="col">Edit</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $lead_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr style="height:50px;">
                                <td id="contact_<?php echo e($item->id); ?>" class="text-center" value="<?php echo e($item->id); ?>"><?php echo e($item->lead_title); ?></td>
                                <td id="first_name_<?php echo e($item->id); ?>" class="text-center"><?php echo e($item->first_name); ?></td>
                                <td id="last_name_<?php echo e($item->id); ?>" class="text-center"><?php echo e($item->last_name); ?></td>
                                <td id="email_<?php echo e($item->id); ?>" class="text-center">
                                    <?php echo e($item->email); ?>

                                    <?php if($item->email != ''): ?>
                                    <span>
                                        <i class="zmdi zmdi-email email-button" style="color: forestgreen; font-size: 20px;" data-contact="<?php echo e($item->id); ?>" data-email="<?php echo e($item->email); ?>" aria-hidden="true"></i>
                                    </span>
                                    <?php endif; ?>
                                </td>
                                <td id="phone_<?php echo e($item->id); ?>" class="text-center">
                                    <?php echo e($item->phone); ?>

                                    <?php if($item->phone != ''): ?>
                                    <span>
                                        <i class="zmdi zmdi-phone phone-button" style="color: dodgerblue; font-size: 20px;" data-contact="<?php echo e($item->id); ?>" data-number="<?php echo e($item->phone); ?>" aria-hidden="true"></i>
                                    </span>
                                    <?php endif; ?>
                                </td>
                                <td id="phone_<?php echo e($item->id); ?>" class="text-center"><?php echo e($item->phone_ext); ?></td>

                                <td id="linked_in_<?php echo e($item->id); ?>" class="text-center"><?php echo e($item->linked_in); ?></td>
                                <td class="text-center"> <a data-toggle="modal" d-lead_id="<?php echo e($item->id); ?>" d-lead_title="<?php echo e($item->lead_title); ?>" d-lead_first_name="<?php echo e($item->first_name); ?>" d-lead_last_name="<?php echo e($item->last_name); ?>" d-lead_phone="<?php echo e($item->phone); ?>" d-lead_phone_ext="<?php echo e($item->phone_ext); ?>" d-lead_email="<?php echo e($item->email); ?>" d-lead_linked_in="<?php echo e($item->linked_in); ?>" data-target="#ContactModal" class="btn btn-primary btn-lg text-white">
                                        Edit
                                    </a> </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="loader my-5 ml-5" id="loader" style="display:none">
                    </div>
                </div>
            </div>
        </div>
        <br>
    </div>
</div>

<div id="ContactModal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" style="margin-top: 20px;" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Contact Info</h3>
            </div>
            <div class="modal-body">
                <form role="form" id="add_contact_form" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="lead_reference_id" value="<?php echo e($lead->id); ?>">
                    <input type="hidden" name="contact_id" value="">
                    <div class="form-group">
                        <label class="control-label">Select Contact Title<span class="required">*</span>:</label>
                        <div class="input-group mb-2">
                            <input class="form-control" name="lead_title" id="lead_title" style="height:35px; border-radius:5px;" type="text" list="positions" />
                            <datalist id="positions">
                                <option value="Collection Manager">Collection Manager</option>
                                <option value="Operations Manager">Operations Manager</option>
                                <option value="Financial Executive">Financial Executive</option>
                                <option value="CIO">Chief Information Officer</option>
                                <option value="CEO">Chief Executive Officer</option>
                                <option value="CFO">Chief Financial Officer</option>
                            </datalist>
                            <div class="input-google">
                                <i class="fas fa-search fa-2x" style="color:blue" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">First Name<span class="required">*</span>:</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_first_name" name="lead_first_name" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Last Name<span class="required">*</span>:</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_last_name" name="lead_last_name" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">E-Mail Address</label>
                        <div>
                            <input type="email" class="form-control input-lg" id="lead_email" name="lead_email" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Phone Number</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_phone" name="lead_phone" value="">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label">Phone Number Ext</label>
                        <div>
                            <input type="text" class="form-control input-lg" id="lead_phone_ext" name="lead_phone_ext" value="">
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label">Linked-In </label>
                        <div class="input-group mb-2">
                            <input type="text" class="form-control input-lg" id="contact_linked_in" name="contact_linked_in" value="">
                            <div class="input-google">
                                <i class="fas fa-search fa-2x" style="color:blue" aria-hidden="true"></i>
                            </div>
                        </div>
                    </div>

                </form>
                <div class="form-group">
                    <div>
                        <button id="save_update_contact" class="btn btn-success">
                            Save / Update
                        </button>
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script>
    //calls current phone number
    function callNumber() {
        var number = $('#company_phone').val();
        var link = "tel:" + number;
        window.location.href = link;
    }

    $(document).ready(function() {

        var industry = <?php echo json_encode($lead->industry); ?>;
        $('#industry').attr('value', industry);
        $('#industry option[value="' + industry + '"]').attr('selected', 'selected');
        $('#industry option[value="' + industry + '"]').attr('disabled', false);

        var state = <?php echo json_encode($lead->company_state); ?>;
        $('#state').attr('value', state);
        $('#state option[value="' + state + '"]').attr('selected', 'selected');
        $('#state option[value="' + state + '"]').attr('disabled', false);

        $("#add_contact_form").validate({
            rules: {
                lead_title: {
                    required: true
                },
                lead_first_name: {
                    required: true
                },
                lead_last_name: {
                    required: true
                }
            }
        });

        $('#ContactModal').on('show.bs.modal', function(e) {
            // get information to update quickly to modal view as loading begins
            var opener = e.relatedTarget; //this holds the element who called the modal
            //we get details from attributes
            var lead_id = $(opener).attr('d-lead_id');
            var lead_title = $(opener).attr('d-lead_title');
            var lead_first_name = $(opener).attr('d-lead_first_name');
            var lead_last_name = $(opener).attr('d-lead_last_name');
            var lead_email = $(opener).attr('d-lead_email');
            var lead_phone = $(opener).attr('d-lead_phone');
            var lead_phone_ext = $(opener).attr('d-lead_phone_ext');
            var lead_linked_in = $(opener).attr('d-lead_linked_in');


            //set what we got to our form
            $('#add_contact_form').find('[name="contact_id"]').val(lead_id);
            $('#add_contact_form').find('[name="lead_title"]').val(lead_title);
            $('#add_contact_form').find('[name="lead_first_name"]').val(lead_first_name);
            $('#add_contact_form').find('[name="lead_last_name"]').val(lead_last_name);
            $('#add_contact_form').find('[name="lead_email"]').val(lead_email);
            $('#add_contact_form').find('[name="lead_phone"]').val(lead_phone);
            $('#add_contact_form').find('[name="lead_phone_ext"]').val(lead_phone_ext);
            $('#add_contact_form').find('[name="contact_linked_in"]').val(lead_linked_in);

        });

        $("#save_update_contact").click(function(e) {

            if ($("#add_contact_form").valid() == false)
                return false;
            $('#contacts_table').delay(25).fadeOut();
            $('#loader').delay(25).fadeIn();

            var lead_title = stripHtml($("#lead_title").val());
            if (lead_title == null) lead_title = '';
            var first_name = stripHtml($("#lead_first_name").val());
            if (first_name == null) first_name = '';
            var last_name = stripHtml($("#lead_last_name").val());
            if (last_name == null) last_name = '';
            var email = stripHtml($("#lead_email").val());
            if (email == null) email = '';
            var phone = stripHtml($("#lead_phone").val());
            if (phone == null) phone = '';
            var phone_ext = stripHtml($("#lead_phone_ext").val());
            if (phone_ext == null) phone_ext = '';
            var linked_in = stripHtml($("#contact_linked_in").val());
            if (linked_in == null) linked_in = '';

            var existingcontact = !($('#add_contact_form').find('[name="contact_id"]').val() === "");

            var id = $('#add_contact_form').find('[name="contact_id"]').val();

            //$("#contacts_table").children('tbody').append(markup);

            var form = document.getElementById("add_contact_form");
            var formData = $(form).serialize();

            var markup = '<tr><td class="text-center" id="contact_' + id + '">' + lead_title + '</td>' +
                '<td class="text-center">' + first_name + '</td>' +
                '<td class="text-center">' + last_name + '</td>' +
                '<td class="text-center">' + email;
                if (email != null && email != ""){
                    markup = markup + '<i class="zmdi zmdi-email email-button" style="color: forestgreen; font-size: 20px;" data-contact="'+id+'" data-email="'+email+'" aria-hidden="true"></i>';
                }
                markup = markup + '</td>' +
                '<td class="text-center">' + phone;
                if (phone != null && phone != "") {
                    markup = markup + '<i class="zmdi zmdi-phone phone-button" style="color: dodgerblue; font-size: 20px;" data-contact="'+ id +'" data-number="'+ phone +'" aria-hidden="true"></i>';
                }
                markup = markup + '</td>' +
                '<td class="text-center">' + phone_ext + '</td>' +
                '<td class="text-center">' + linked_in + '</td>' +
                '<td class="text-center"><a data-toggle="modal"' +
                ' d-lead_id="' + id +
                '" d-lead_title="' + lead_title +
                '" d-lead_first_name="' + first_name +
                '" d-lead_last_name="' + last_name +
                '" d-lead_email="' + email +
                '" d-lead_phone="' + phone +
                '" d-lead_phone_ext="' + phone_ext +
                '" d-lead_linked_in="' + linked_in +
                '" data-target="#ContactModal" class="btn btn-primary btn-lg text-white"> Edit </a> </td>' +
                '</tr>';
            if (existingcontact)
                $("#contact_" + id).closest('tr').replaceWith(markup);


            $.ajax({
                type: 'POST',
                url: '/addLead',
                data: formData,
                success: function(text) {
                    $('#contacts_table').delay(450).fadeIn();
                    $('#loader').delay(25).fadeOut();

                    var markup = '<tr><td class="text-center" id="contact_' + text + '">' + lead_title + '</td>' +
                        '<td class="text-center">' + first_name + '</td>' +
                        '<td class="text-center">' + last_name + '</td>' +
                        (email != undefined && email != '' ?
                            '<td class="text-center">' + email + '<span><i class="zmdi zmdi-email email-button" style="color: forestgreen; font-size: 20px; margin-left: 5px;" data-contact="' + text + '" data-email="' + email + '" aria-hidden="true"></i></span></td>' :
                            '<td class="text-center">' + email + '</td>'
                        ) +
                        (phone != undefined && phone != '' ?
                            '<td class="text-center">' + phone + '<span><i class="zmdi zmdi-phone phone-button" style="color: dodgerblue; font-size: 20px; margin-left: 5px;" data-contact="' + text + '" data-number="' + phone + '" aria-hidden="true"></i></span></td>' :
                            '<td class="text-center">' + phone + '</td>'
                        ) +
                        '<td class="text-center">' + phone_ext + '</td>' +
                        '<td class="text-center">' + linked_in + '</td>' +
                        '<td class="text-center"><a data-toggle="modal"' +
                        ' d-lead_id="' + text +
                        '" d-lead_title="' + lead_title +
                        '" d-lead_first_name="' + first_name +
                        '" d-lead_last_name="' + last_name +
                        '" d-lead_email="' + email +
                        '" d-lead_phone="' + phone +
                        '" d-lead_phone_ext="' + phone_ext +
                        '" d-lead_linked_in="' + linked_in +
                        '" data-target="#ContactModal" class="btn btn-primary btn-lg text-white"> Edit </a> </td>' +
                        '</tr>';
                    if (!existingcontact)
                        $("#contacts_table").children('tbody').append(markup);

                    // get reference to the multi-select
                    var sel = document.getElementById('contacts[]');

                    // create new option element
                    var opt = document.createElement('option');
                    opt.appendChild( document.createTextNode('['+lead_title+'] '+first_name+' '+last_name) );
                    opt.value = text;

                    // add opt to end of the multi-select
                    sel.appendChild(opt);
                }
            });
            $('#ContactModal').modal('toggle');
        });

        $(document).on('click', '.email-button', function(e) {
            e.preventDefault();

            var link = 'mailto:';

            var formData = {
                    lead_reference_id: "<?php echo e($lead->id); ?>",
                    subject: "EMAIL",
                    assigned_to: "<?php echo e(Auth::user()->id); ?>",
                    related_to: "<?php echo e($lead->company_name); ?>"
            };

            if ($(this).data('email')) {
                link += $(this).data('email');

                if ($(this).data('contact')) {
                    formData.contacts = $(this).data('contact');
                }
            } else {
                var target = $('.' + $(this).data('targetclass'));
                link += target.val();
            }

            if (link == 'mailto:' || link == 'mailto:undefined')
                return;

            $.LoadingOverlay("show");
            $.post("/createNextStep/0", formData)
                .done(function(data) {
                    renderWidget(() => $('.notes-' + data['id']).click());
                });

            window.location.href = link;
        });

        $(document).on('click', '.phone-button', function(e) {
            e.preventDefault();

            var link = 'tel:';

            var formData = {
                    lead_reference_id: "<?php echo e($lead->id); ?>",
                    subject: "CALL",
                    assigned_to: "<?php echo e(Auth::user()->id); ?>",
                    related_to: "<?php echo e($lead->company_name); ?>"
            };

            if ($(this).data('number')) {
                link += $(this).data('number');

                if ($(this).data('contact')) {
                    formData.contacts = $(this).data('contact');
                }
            } else {
                var target = $('.' + $(this).data('targetclass'));
                link += target.val();
            }

            if (link == 'tel:' || link == 'tel:undefined')
                return;

            $.LoadingOverlay("show");
            $.post("/createNextStep/0", formData)
                .done(function(data) {
                    renderWidget(() => $('.notes-' + data['id']).click());
                });

            window.location.href = link;
        });

        $(document).on('click', '.icon-custom', function(e) {
            e.preventDefault();
            var input = $(this).parent().parent().find('.form-control-custom');
            if (!input.hasClass('always-disabled')) {
                if (input.is('select')) {
                    input.removeClass('readonly');
                    input.find('option').prop('disabled', false);
                } else {
                    input.prop('readonly', false);
                }

                input.focus();
            }
        });

        $('input').focusout(function(e) {
            if ($(this).hasClass('form-control-custom')) {
                $(this).prop('readonly', true);
            }
        });

        $('textarea').focusout(function(e) {
            if ($(this).hasClass('form-control-custom')) {
                $(this).prop('readonly', true);
            }
        });

        $('select').focusout(function(e) {
            if ($(this).hasClass('form-control-custom')) {
                $(this).addClass('readonly');
                $(this).find('option:not(:selected)').prop('disabled', true);
            }
        });
    });

    function renderWidget(_callback) {
        var $request = $.get('/getEventWidget/' + "<?php echo e($lead->id); ?>");
        var $container = $('#event-widget');

        $('#event-loader').delay(25).fadeIn();
        $('#event-widget').delay(25).fadeOut();

        $request.done(function(data) { // success
            $container.html(data.html);
            $.LoadingOverlay("hide");
            if (typeof _callback !== 'undefined') {
                _callback();
            }
        });

        $request.always(function() {
            $('#event-loader').delay(25).fadeOut();
            $('#event-widget').delay(25).fadeIn();
        });
    }

    $("#email").change(function(){
        if($("#email").val() != ""){
            document.getElementById("lead_info_email").hidden = false;
        }
        else{
            document.getElementById("lead_info_email").hidden = true;
        }
    });

    $("#company_phone").change(function(){
        if($("#company_phone").val() != ""){
            document.getElementById("lead_info_phone").hidden = false;
        }
        else{
            document.getElementById("lead_info_phone").hidden = true;
        }
    });

    $("#Update").on( "submit",function(){
        if($(this).valid())
            $.LoadingOverlay("show");
    });

    function stripHtml(html){
        // Create a new div element
        var temporalDivElement = document.createElement("div");
        // Set the HTML content with the providen
        temporalDivElement.innerHTML = html;
        // Retrieve the text property of the element (cross-browser support)
        return temporalDivElement.textContent || temporalDivElement.innerText || "";
    }
</script>

<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\sales_leads\workLeadForm.blade.php ENDPATH**/ ?>