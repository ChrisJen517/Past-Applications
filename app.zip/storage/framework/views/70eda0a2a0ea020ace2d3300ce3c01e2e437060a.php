<?php $__env->startSection('route'); ?>
<?php echo e(route('exportRedlineStart')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('companyInformation'); ?>
    <?php echo $__env->make('Includes.forms.companyInformation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name', 'Redline Start Contract'); ?>
<?php echo $__env->make('Includes.baseContract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\redline.blade.php ENDPATH**/ ?>