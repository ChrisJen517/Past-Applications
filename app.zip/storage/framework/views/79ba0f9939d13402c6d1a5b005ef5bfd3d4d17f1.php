<div class="loading-overlay">

<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet" />
<div class="card col-md-8 offset-md-2">
    <form action="<?php echo e(route('saveProductOrder')); ?>" method="POST" enctype="multipart/form-data" id="Update">
        <?php echo csrf_field(); ?>
        <div class="card-header">
            <h4 class="modal-title" id="myModalLabel">Update Product Order</h4>
        </div>
        <div class="col-md-6 offset-md-3 text-center">
            <div class="table-responsive">
                <table class="table table-hover table-striped table-bordered" id="product-order">
                    <thead>
                        <tr>
                            <th class="class-center">
                                ID
                            </th>
                            <th class="class-center">
                                Order
                            </th>
                            <th class="text-center">
                                Name
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-index="<?php echo e($item->id); ?>" data-position="<?php echo e($item->order); ?>" style="height:45px;">
                                <td style="width:10%;"><?php echo e($item->id); ?></td>
                                <td style="width:20%;" class="order"><?php echo e(empty($item->order) ? 'Unordered' : $item->order); ?></td>
                                <td style="width:70%;"><?php echo e($item->name); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <a class="btn btn-secondary float-left" href="/manageProductSheet">Back</a>
            <a class="btn btn-primary float-right" onclick="reorderProducts()" style="color: white;">Save Order</a>
        </div>
    </form>
</div>
</div>
    <script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
    <link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function() {

        var fixHelper = function(e, ui) {
            ui.children().each(function() {
                $(this).width($(this).width());
            });
            return ui;
        };

        $('#product-order tbody').sortable({
            revert: true,
            helper: fixHelper,
            placeholder: "my-ui-placeholder",
            update: function (event, ui) {
                $(this).children().each(function (index) {
                    if ($(this).attr('data-position') != (index+1)) {
                        $(this).attr('data-position', (index+1));
                        $(this).find('td.order').text(index+1);
                    }
                });
            }
        }).disableSelection();

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    function reorderProducts() {
        var positions = [];
        $('#product-order tbody').children().each(function (index) {
            positions.push(
                {
                    index: $(this).attr('data-index'),
                    position: $(this).attr('data-position')
                }
            );
        });
        swal.fire({
            title: "Are you sure?",
            text: "You are about to reorder the products.",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: 'Save'
        }).then((willSave) => {
            if (willSave.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post( "/saveProductOrder", { 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'), 'order': positions })
                    .done(function(data) {
                        $.LoadingOverlay("hide");
                            swal.fire(
                                "Success",
                                "Product order has been saved.",
                                "success"
                            );
                    });
                });
            } else {
                swal.fire(
                    "Cancelled",
                    "Product order was not saved!",
                    "error"
                );
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\productOrder.blade.php ENDPATH**/ ?>