<div class="loading-overlay">
    
    <?php $__env->startSection('content'); ?>

    <br/>
    <div class="container-fluid py-3">
        <form method="POST" action=<?php echo $__env->yieldContent('route'); ?> enctype="multipart/form-data" id="contract_information_form">
        <?php echo csrf_field(); ?>
            <div class="row">
                <div class="mx-auto col-md-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="row">
                                <div class="col-lg-6">
                                    <h3 class="mb-0"><?php echo $__env->yieldContent('name'); ?> Information</h3>
                                </div>
                                <div class="col-lg-6">
                                    <h3 class="mb-0">Account Management Information</h3>
                                </div>
                            </div>
                        </div>
                        <?php echo $__env->yieldContent('companyInformation'); ?>
                    </div>
                    <?php echo $__env->yieldContent('extra'); ?>
                    <div class="form-group row" style="display: flex; justify-content: center;">
                        <div class="col-lg-4">
                            <input id="submit-button-2" name="submit-form" type="submit"
                                class="btn btn-lg btn-primary btn-block" value="Generate <?php echo $__env->yieldContent('name'); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="<?php echo e(asset('js/contracts/contract.js?'.time())); ?>"></script>

<script>
$(document).ready(function() {
    $('#company-select').change(function() {
        var value = $(this).val();
        var _token = $('input[name="_token"]').val();
        $.ajax({
            url:"<?php echo e(route('fetchClientData')); ?>",
            method: "POST",
            data: {value:value, _token:_token},
            beforeSend: function(){
                $.LoadingOverlay("show");
            },
            success:function(result)
            {
                var data = $.parseJSON(result);
                $("#company_address").val(data['company_address']);
                $("#company_city").val(data['company_city']);
                $("#company_state").val(data['company_state']);
                $("#company_zip").val(data['company_zip']);
                $("#company_email").val(data['company_email']);
                $("#company_ein").val(data['company_ein']);
                $("#company_url").val(data['company_url']);
                $("#company_phone").val(data['company_phone']);
            },
            complete: function() {
                $.LoadingOverlay("hide", true);
            }
        })
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\baseContract.blade.php ENDPATH**/ ?>