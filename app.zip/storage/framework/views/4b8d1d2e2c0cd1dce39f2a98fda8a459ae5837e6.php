<?php $__env->startSection('content'); ?>
<br>

<section id="unworked-leads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Unworked Leads:</p>
            </div>
        </div>
    </div>
</section>

<section id="unworked-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="unworked-leads-div">
                <table class="table table-striped table-bordered" id="unworked-leads-table" style="display: none;">
                    <thead>
                        <tr>
                            <th class="text-center">Lead ID</th>
                            <th class="text-center">Assigned Agent</th>
                            <th class="text-center">Company Name</th>
                            <th class="text-center">Industry</th>
                            <th class="text-center">State</th>
                            <th class="text-center">Last Updated</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lead->capcode == ''): ?>
                        <tr>
                            <td class="text-center"><?php echo e($lead->id); ?></td>
                            <td class="text-center"><?php echo e($lead->agent_name); ?> (<?php echo e($lead->agent_id); ?>)</td>
                            <td class="text-center"><?php echo e($lead->company_name); ?></td>
                            <td class="text-center"><?php echo e($lead->industry); ?></td>
                            <td class="text-center"><?php echo e($lead->company_state); ?></td>
                            <td class="text-center">Unworked</td>
                            <td class="text-center">
                                <form action="<?php echo e(route('showLead')); ?>" method="GET" id="showLeadForm"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                        <input class="form-control" type="hidden" id="leadId" name="id"
                                            value="<?php echo e($lead->id); ?>">
                                        <button class="btn btn-info text-center" type="submit"
                                            style="width: 60%; color: white;">Work</button>

                                </form>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<hr>
<br>

<section id="worked-leads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Needs Additional Work:</p>
            </div>
        </div>
    </div>
</section>

<section id="worked-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="worked-leads-div">
                <table class="table table-striped table-bordered" id="worked-leads-table" style="display: none;">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Assigned Agent</th>
                            <th class="text-center">Company Name</th>
                            <th class="text-center">Industry</th>
                            <th class="text-center">State</th>
                            <th class="text-center">Last Updated</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lead->capcode == 2000): ?>
                        <tr>
                            <td class="text-center"><?php echo e($lead->id); ?></td>
                            <td class="text-center"><?php echo e($lead->agent_id); ?></td>
                            <td class="text-center"><?php echo e($lead->company_name); ?></td>
                            <td class="text-center"><?php echo e($lead->industry); ?></td>
                            <td class="text-center"><?php echo e($lead->company_state); ?></td>
                            <td class="text-center"><?php echo e($lead->last_worked); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(route('showLead')); ?>" method="GET" id="showLeadForm"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <input class="form-control" type="hidden" id="leadId" name="id"
                                            value="<?php echo e($lead->id); ?>">
                                        <button class="btn btn-info text-center" type="submit"
                                            style="width: 60%; color: white;">Work</button>
                                </form>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="loader my-5 ml-5" id="loader2" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<hr>
<br>

<section id="completed-leads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Completed Leads:</p>
            </div>
        </div>
    </div>
</section>

<section id="completed-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="completed-leads-div">
                <table class="table table-striped table-bordered" id="completed-leads-table" style="display: none;">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Assigned Agent</th>
                            <th class="text-center">Company Name</th>
                            <th class="text-center">Industry</th>
                            <th class="text-center">State</th>
                            <th class="text-center">Last Updated</th>
                            <th class="text-center">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($lead->capcode == 1000): ?>
                        <tr>
                            <td class="text-center"><?php echo e($lead->id); ?></td>
                            <td class="text-center"><?php echo e($lead->agent_id); ?></td>
                            <td class="text-center"><?php echo e($lead->company_name); ?></td>
                            <td class="text-center"><?php echo e($lead->industry); ?></td>
                            <td class="text-center"><?php echo e($lead->company_state); ?></td>
                            <td class="text-center"><?php echo e($lead->last_worked); ?></td>
                            <td class="text-center">
                                <form action="<?php echo e(route('showLead')); ?>" method="GET" id="showLeadForm"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                        <input class="form-control" type="hidden" id="<?php echo e($lead->id); ?>" name="id"
                                            value="<?php echo e($lead->id); ?>">
                                        <button class="btn btn-info text-center" type="submit"
                                            style="width: 60%; color: white;">View Lead</button>
                                </form>
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <div class="loader my-5 ml-5" id="loader3" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
    $(document).ready(function() {

    $('#unworked-leads-table').DataTable({
        "order":[[0,"asc"]],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#unworked-leads-table').delay(450).fadeIn();
        }
    });
    $('#worked-leads-table').DataTable({
        "order":[[0,"asc"]],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader2').delay(25).fadeOut();
            $('#worked-leads-table').delay(450).fadeIn();
        }
    });
    $('#completed-leads-table').DataTable({
        "order":[[0,"asc"]],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader3').delay(25).fadeOut();
            $('#completed-leads-table').delay(450).fadeIn();
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\salesLeads.blade.php ENDPATH**/ ?>