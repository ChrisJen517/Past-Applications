<?php $__env->startSection('content'); ?>
<?php echo e(csrf_field()); ?>

<div class="container-fluid">
    <div class="row">
            <!-- form user info -->
            <div class="card" style="width:100%;">
                <div class="card-header">
                    <h4>Contract Information</h4>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class='col-lg-6'>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Contract Number</label>
                                <div class="col-lg-8">
                                    <input class="form-control" name="firstname" type="text" value="<?php echo e($contract->id); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Company name</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="<?php echo e($contract->company_name); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Company Address</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="<?php echo e($address); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Creation date</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="<?php echo e($contract->created_at); ?>" readonly>
                                </div>
                            </div>
                        </div>
                        <div class='col-lg-6'>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Manager Email</label>
                                <div class="col-lg-8">
                                    <input autocomplete="off" class="form-control auto-complete-off" name="manager_email" type="email" value="<?php echo e(Auth::user()->manager_email); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Contract Type</label>
                                <div class="col-lg-8">
                                <input class="form-control" name="firstname" type="text" value="<?php echo e($contract->contract_type); ?>" readonly>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label class="col-lg-4 col-form-label form-control-label">Contract Status</label>
                                <div class="col-lg-8">
                                <?php if($contract->status == 'awaiting_jim_approval'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Manager Approval" readonly>
                                <?php elseif($contract->status == 'awaiting_manager_approval'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Manager Approval" readonly>
                                <?php elseif($contract->status == 'awaiting_final_upload'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Final Contract Upload" readonly>
                                <?php elseif($contract->status == 'complete'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Contract Complete" readonly>
                                <?php elseif($contract->status == 'awaiting_all_signature'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Contract awaiting signatures by client and RNN." readonly>
                                <?php elseif($contract->status == 'awaiting_client_signature'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Contract awaiting signature by client." readonly>
                                <?php elseif($contract->status == 'awaiting_jim_signature'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Contract awaiting signature by RNN." readonly>
                                <?php elseif($contract->status == 'awaiting_client_changes'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Client Changes" readonly>
                                <?php elseif($contract->status == 'awaiting_legal_approval'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Awaiting Legal Approval" readonly>
                                <?php elseif($contract->status == 'changes_requested'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Changes Requested" readonly>
                                <?php elseif($contract->status == 'void'): ?>
                                    <input class="form-control" name="firstname" type="text" value="Contract Voided" readonly>
                                <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-4">
                                    <a href="<?php echo e(route('agentDashboard')); ?>" class="btn btn-secondary float-left">Back</a>
                                </div>
                                <div class="col-lg-8">
                                    <?php if($contract->status == 'awaiting_client_changes'): ?>
                                        <a href="" data-toggle="modal" data-target="#clientChangesModal" class="btn btn-primary btn-sm float-right" role="button">Upload Client Changes</a>
                                    <?php elseif($contract->status == 'awaiting_legal_approval'): ?>
                                        <a href="" data-toggle="modal" data-target="#redlineChangesModal" class="btn btn-warning btn-sm" role="button">Upload Changes</a>   
                                        <span class="float-right">Awaiting Approval From Legal</span>
                                    <?php elseif($contract->status == 'changes_requested'): ?>
                                        <a href="" data-toggle="modal" data-target="#redlineChangesModal" class="btn btn-primary btn-sm float-right" role="button">Upload Changes</a>
                                    <?php elseif($contract->status == 'awaiting_product_selection'): ?>
                                        <a href="" data-toggle="modal" data-target="#redlineChangesModal" class="btn btn-warning btn-sm" role="button">Upload Changes</a>   
                                        <a href="<?php echo e(route('showRedlineProducts',$contract->id)); ?>" class="btn btn-primary btn-sm float-right" role="button">Select Final Products</a>
                                    <?php elseif($contract->status == 'complete'): ?>
                                        <a href="" data-toggle="modal" data-target="#contractChangesModal" class="btn btn-primary btn-sm float-right" role="button">Upload Contract Updates</a>
                                    <?php elseif($contract->status == 'awaiting_manager_approval'): ?>
                                        <span class="float-right">Awaiting Approval From Manager</span>
                                    <?php elseif($contract->status == 'awaiting_jim_approval'): ?>
                                        <span class="float-right">Awaiting Approval From Manager</span>
                                    <?php elseif($contract->status == 'void'): ?>
                                        <span class="float-right">Contract Voided</span>
                                    <?php else: ?>
                                        <a href="" data-toggle="modal" data-target="#clientSignatureModal" class="btn btn-primary btn-sm float-right" role="button">Upload Final Contract</a>
                                        <?php if($contract->status == 'awaiting_all_signature'): ?>
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;"  onclick="resendContract(<?php echo e($contract->id); ?>, 'jimv@rnngroup.com and ' + '<?php echo e($contract->docusign_email == null ? $contract->company_email : $contract->docusign_email); ?>')">
                                                Resend Contract
                                            </button>
                                        <?php elseif($contract->status == 'awaiting_client_signature'): ?>
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;" onclick="resendContract(<?php echo e($contract->id); ?>, '<?php echo e($contract->docusign_email == null ? $contract->company_email : $contract->docusign_email); ?>')">
                                                Resend Contract
                                            </button>
                                        <?php elseif($contract->status == 'awaiting_jim_signature'): ?>
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;" onclick="resendContract(<?php echo e($contract->id); ?>, 'jimv@rnngroup.com')">
                                                Resend Contract
                                            </button>
                                        <?php elseif($contract->contract_type != 'REDLINE'): ?>
                                            <button class="btn btn-primary btn-sm float-right" style="margin-right:100px;" onclick="sendContract(<?php echo e($contract->id); ?>, '<?php echo e($contract->company_email); ?>', '<?php echo e($name_options); ?>')">
                                            Send
                                            </button>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <section id="history">
        <div class="row">
            <h3>Contract History</h3>
        </div>
        <div class="row">
            <div class="table-responsive">
                <table class="table table-striped table-bordered" id="history">
                    <thead>
                        <tr>
                            <th class="text-center">Update Time</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Updated File</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $contractName = $item->file_name;
                            $contractName = "../".$contractName;
                            ?>
                        <tr class="item<?php echo e($item->id); ?>">
                            <td><?php echo e($item->created_at); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <?php if($contract->approval_needed == 1): ?>
                            <td class="text-center">Awaiting Approval</td>
                            <?php else: ?>
                            <td class="text-center">
                                <a href="<?php echo e(route('download', $item->file_name)); ?>">
                                    <div style="height:100%;width:100%">
                                        Download
                                    </div>
                                </a>
                            </td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </section>

    <?php if(!empty($products->first())): ?>
        <section id="product_history">
            <div class="row">
                <h3>Contract Product History</h3>
            </div>
            <div class="row">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered" id="products">
                        <thead>
                            <tr>
                                <th style="width: 50%" class="text-center">Product Name</th>
                                <th style="width: 50%" class="text-center">Price</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $total = 0 ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $total += (is_numeric($product->price) ? $product->price : 0) ?> 
                                <tr class="item<?php echo e($product->id); ?>">
                                    <td style="width: 50%" class="text-center"><?php echo e($product->product_name); ?></td>
                                    <td style="width: 50%" class="text-center">$<?php echo e($product->price); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th style="width: 50%" class="text-center">Total</th>
                                <th style="width: 50%" class="text-center">$<?php echo e($total); ?></th>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </section>
    <?php endif; ?>
</div>

<div class="modal fade" id="clientChangesModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Client Changes Upload (.docx or .pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('uploadCustomerChanges')); ?>" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="<?php echo e($contract->contract_name); ?>">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="<?php echo e($contract->id); ?>">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Signature Upload File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".docx, .pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="contractChangesModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Contract Changes Upload (.pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('uploadContractChanges')); ?>" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="<?php echo e($contract->contract_name); ?>">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="<?php echo e($contract->id); ?>">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Contract Updated File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="redlineChangesModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Redline Changes Upload (.docx only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('uploadRedlineChanges')); ?>" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="<?php echo e($contract->contract_name); ?>">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="<?php echo e($contract->id); ?>">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Contract Updated File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".docx"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="submit-button" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="clientSignatureModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Final Contract Upload (.pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('uploadCustomerSignature')); ?>" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="<?php echo e($contract->contract_name); ?>">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="<?php echo e($contract->id); ?>">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Contract Upload</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="managerSignatureModal">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content ">
            <div class="modal-header ">
                <h5 class="modal-title ">Manager Signature Upload (.pdf only)</h5>
                <button class="close" data-dismiss="modal">
                    <span>&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('uploadManagerSignature')); ?>" method="POST" class="manualUploadForm" id="manualUploadForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="fileName" name="fileName" value="<?php echo e($contract->contract_name); ?>">
                </div>
                <div class="form-group row">
                    <input class="form-control" type="hidden" id="contractID" name="contractID" value="<?php echo e($contract->id); ?>">
                </div>
                <div class="modal-body mx-auto">
                    <div class="form-group row">
                        <label class="col-lg-5 form-control-label" for="uploadFile">Signature Upload File</label>
                        <div class="col-lg-7">
                            <input type="file" accept=".pdf"  name="uploadFile" id="uploadFile" required>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="" value="upload" class="btn btn-primary btn-lg">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>
<script>
$(document).ready(function () {
    $("#clientSignatureModal").validate({
        rules: {
            uploadFile: "required"
        },
        messages: {
            uploadFile: "Please select a file to upload"
        }
    });
    $("#managerSignatureModal").validate({
        rules: {
            uploadFile2: "required"
        },
        messages: {
            uploadFile2: "Please select a file to upload"
        }
    });
});

$(".manualUploadForm").on( "submit",function(){
    $.LoadingOverlay("show");
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views/agent/manageContract.blade.php ENDPATH**/ ?>