<link href="<?php echo e(asset('plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
    type="text/css">
<link href="<?php echo e(asset('plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('plugins\bootstrap-datatable\css\rowReorder.dataTables.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css"
    integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="google" content="notranslate">
    <title>Contract Portal 2.0</title>

    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="<?php echo e(asset('css/datatable.css?'.time())); ?>" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="<?php echo e(asset('css/sidebar-top.css?'.time())); ?>" rel="stylesheet" />
    <!-- Icons CSS-->
    <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Styling CSS-->
    <link href="<?php echo e(asset('/css/style-test.css')); ?>" rel="stylesheet" />
</head>

<header class="topbar-nav">
    <nav class="navbar navbar-expand fixed-top bg-topbar" style="height:80px">
        <ul class="navbar-nav mr-auto align-items-left">
            <a href="<?php echo e(asset('/')); ?>">
                <img src="/images/RNN-Logo-Square.png" class="logo-icon rnn-logo" alt="logo icon" style="size: 60%">   
            </a>  
        </ul>
        <ul class="navbar-nav align-items-center right-nav-link" style="padding-right: 5%">
            <a href="<?php echo e(asset('/')); ?>">
                <?php if(empty(Auth::user())): ?>
                    Login 
                <?php else: ?>
                    Dashboard
                <?php endif; ?>
            </a> 
        </ul>
    </nav>
</header>

<!-- Main Content -->
<div class="content-wrapper" style="margin-left: 5px">
    <div class="container-fluid">
        <br>
        <br>
        <section id="previous-uploads-header">
            <div class="container-fluid">
                <div class="row text-left">
                    <div class="col text-left">
                        <p><?php echo e($response); ?></p>
                    </div>
                </div>
            </div>
        </section>
        <br>
    </div>
</div><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\basicEmailResponse.blade.php ENDPATH**/ ?>