<?php $__env->startSection('content'); ?>
<?php if($contract->approval_needed == 1): ?>
<div class="col-md-12 mx-auto">
    <br>
    <div class="card">
        <div class="card-header">
            A Contract Needs Your Approval
        </div>
        <div class="container">
            <form action="<?php echo e(route('approveContract')); ?>" method="POST" enctype="multipart/form-data" id="user_information_form">
                <?php echo e(csrf_field()); ?>

                <br>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label"><b>Agent Name:</b></label>
                    <div class="col-lg-9">
                        <a name="name"><?php echo e($agent->name_first); ?> <?php echo e($agent->name_last); ?></a>
                        <input name="id" value="<?php echo e($agent->id); ?>" hidden>
                        <input name="contractId" value="<?php echo e($contract->id); ?>" hidden>
                    </div>
                </div>
                <hr>
                <div class="form-group row">
                    <div class="col-lg-12">
                        <b>Company Name:</b> <a name="company"><?php echo e($contract->company_name); ?></a>
                        <br>
                        <br>
                        <b>Contract Type:</b> <a name="contract_type"><?php echo e($contract->contract_type); ?></a>
                        <br>

                    </div>
                </div>
                <hr>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label"><b>Needs Approval:</b></label>
                    <div class="col-lg-9">
                        <?php $__currentLoopData = $approval['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="hanging-indent"><?php echo e($item); ?></a><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="form-group row">
                    <input class="btn btn-primary float-right" type="submit" role="button" name="Approve" id="submit-button" value="Approve">
                </div>
            </form>
        </div>
    </div>
</div>
<?php else: ?>
Contract Has Already Been Approved. Thank You.
<?php endif; ?>
<style>
.hanging-indent {
    padding-left: 22px;
    text-indent: -22px;
}
</style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.emptyBasicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\approveContract.blade.php ENDPATH**/ ?>