<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="loading-overlay">
    <div class="modal fade" id="requestHistoryModal" tabindex="-1" role="dialog" aria-labelledby="editLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content border-0" id="myModalRequestBody">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLabel">Request History</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <table class="table table-striped table-bordered" id="history-table">
                        <thead>
                            <tr>
                                <th class="text-center">Created at</th>
                                <th class="text-center">History</th>
                                <th class="text-center">Comment</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                    <br>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        datatable = $('#history-table').DataTable({
            "order":[[0,"desc"]],
            autoWidth: false,
            "processing": true,
            "serverSide": true,
            "language": {
                'loadingRecords': '&nbsp;',
                processing: '<i class="fa fa-refresh fa-spin"></i>'
            },
            "ajax": {
                "url": "/RequestForm/getHistory/0",
                "dataType": "json",
                "type": "GET",
                "data": {
                    _token: "<?php echo e(csrf_token()); ?>",
                }
            },
            "columns": [
                { "data": "created_at" },
                { "data": "history" },
                { "data": "comment" },
            ],
            dom: 'Bfrtip',
            "pageLength": 5,
            buttons: [],
            "searching": false,
            initComplete: function() {
                var input = $("#parent4 .dataTables_filter input").unbind();
                var self = this.api();
            }
        });

        $('#requestHistoryModal').on('show.bs.modal', function(e) {
            var opener = e.relatedTarget;
            datatable.ajax.url('/RequestForm/getHistory/'+$(opener).attr('d-id')).load();
        })
    });
</script><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\requestForms\requestHistoryModal.blade.php ENDPATH**/ ?>