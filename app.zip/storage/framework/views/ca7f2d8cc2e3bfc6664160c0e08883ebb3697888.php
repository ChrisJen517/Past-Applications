<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Rocker - Bootstrap4  Admin Dashboard Template</title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet"/>
  <!-- Custom Style-->
  <link href="<?php echo e(asset('css/app-style.css')); ?>" rel="stylesheet"/>
  
</head>

<body class="bg-error">

<!-- Start wrapper-->
 <div id="wrapper">
 
    <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="text-center error-pages">
                        <h1 class="error-title text-danger"> Oh NO!</h1>
                        <h2 class="error-sub-title text-dark">Internal Error</h2>

                        <p class="error-message text-dark text-uppercase">Something went wrong on our end, sorry for the inconvenience</p>
                        
                        <div class="mt-4">
                          <a href="/" class="btn btn-danger btn-round shadow-danger m-1">Go To Home </a>
                        </div>

                        <div class="mt-4">
                            <p class="text-dark">Copyright © 2018  <span class="text-danger">Rocker </span>| All rights reserved.</p>
                        </div>
                           <hr class="w-50">
                    </div>
                </div>
            </div>
        </div>

 </div><!--wrapper-->
</body>
</html><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\errors\error.blade.php ENDPATH**/ ?>