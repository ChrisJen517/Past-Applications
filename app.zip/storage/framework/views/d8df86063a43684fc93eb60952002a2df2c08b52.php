<?php $__env->startSection('content'); ?>
<?php echo $__env->make('Includes.modal.requestForms.requestFormModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Includes.modal.requestForms.requestHistoryModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>

<link href="<?php echo e(asset('css/multiTableProcessing.css?'.time())); ?>" rel="stylesheet" />
<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Purchase Requests:</p>
            </div>
        </div>
    </div>
</section>

<section id="previous-requests">
    <div class="container-fluid">
        
        <button data-toggle="modal" data-target="#requestFormModal" d-type="create" class="btn btn-primary mb-3">
            Create New Request
        </button>

        <div class="row">
            <div class="table-responsive" id="previous-requests-div">
                <table class="table table-striped table-bordered" id="previous-requests-table">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Department</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Requested On</th>
                            <th class="text-center">Edit</th>
                            <th class="text-center">View History</th>
                            <th class="text-center">Archive</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $previousRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previousRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center" style="width: 8%"><?php echo e($previousRequest->id); ?></td>
                                <td class="text-center">$<?php echo e($previousRequest->amount); ?> <?php echo e($previousRequest->frequency); ?></td>
                                <td class="text-center"><?php echo e($previousRequest->department); ?></td>
                                <td class="text-center"><?php echo e($previousRequest->description); ?></td>
                                <td class="text-center">
                                    <?php if($previousRequest->status == 'approved'): ?>
                                        <span class="badge badge-success">Approved!</span>
                                    <?php elseif($previousRequest->status == 'awaiting_approval'): ?>
                                        <span class="badge badge-warning">Awaiting Manager</span>
                                    <?php elseif($previousRequest->status == 'awaiting_final_approval'): ?>
                                        <span class="badge badge-warning">Awaiting Final</span>
                                    <?php elseif($previousRequest->status == 'changes_requested'): ?>
                                        <span class="badge badge-danger">Changes Requested</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Denied!</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($previousRequest->created_at); ?></td>
                                <td class="text-center">
                                    <button data-toggle="modal" data-target="#requestFormModal" class="btn btn-info text-center" 
                                        d-type="edit" d-id="<?php echo e($previousRequest->id); ?>" d-amount="<?php echo e($previousRequest->amount); ?>" d-manager="<?php echo e($previousRequest->manager); ?>" d-approved="<?php echo e($previousRequest->approved); ?>"
                                        d-justification="<?php echo e($previousRequest->justification); ?>" d-department="<?php echo e($previousRequest->department); ?>" d-frequency="<?php echo e($previousRequest->frequency); ?>" d-other="<?php echo e($previousRequest->other); ?>"
                                        d-description="<?php echo e($previousRequest->description); ?>" d-username="<?php echo e($previousRequest->username); ?>" d-password="<?php echo e($previousRequest->password); ?>" d-website="<?php echo e($previousRequest->website); ?>">
                                        Edit
                                    </button>
                                </td>
                                <td>
                                    <button data-toggle="modal" data-target="#requestHistoryModal" class="btn btn-primary text-center" d-id="<?php echo e($previousRequest->id); ?>">History</button>
                                </td>
                                <td>
                                    <button class="btn btn-danger text-center" type="submit" onclick="archiveContract(<?php echo e($previousRequest->id); ?>)">Archive</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<section id="previous-uploads-header">
    <div class="container-fluid">
        <div class="row text-left">
            <div class="col text-left">
                <p>Archived Requests:</p>
            </div>
        </div>
    </div>
</section>

<section id="previous-requests">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="previous-requests-div">
                <table class="table table-striped table-bordered" id="archived-requests-table">
                    <thead>
                        <tr>
                            <th class="text-center">ID</th>
                            <th class="text-center">Amount</th>
                            <th class="text-center">Department</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Last Updated</th>
                            <th class="text-center">View</th>
                            <th class="text-center">View History</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $archivedRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $previousRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center" style="width: 8%"><?php echo e($previousRequest->id); ?></td>
                                <td class="text-center">$<?php echo e($previousRequest->amount); ?> <?php echo e($previousRequest->frequency); ?></td>
                                <td class="text-center"><?php echo e($previousRequest->department); ?></td>
                                <td class="text-center"><?php echo e($previousRequest->description); ?></td>
                                <td class="text-center">
                                    <?php if($previousRequest->status == 'approved'): ?>
                                        <span class="badge badge-success">Approved!</span>
                                    <?php elseif($previousRequest->status == 'awaiting_approval'): ?>
                                        <span class="badge badge-warning">Awaiting Manager</span>
                                    <?php elseif($previousRequest->status == 'awaiting_final_approval'): ?>
                                        <span class="badge badge-warning">Awaiting Final</span>
                                    <?php else: ?>
                                        <span class="badge badge-danger">Denied!</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center"><?php echo e($previousRequest->updated_at); ?></td>
                                <td class="text-center">
                                    <button data-toggle="modal" data-target="#requestFormModal" class="btn btn-info text-center" 
                                        d-type="view" d-id="<?php echo e($previousRequest->id); ?>" d-amount="<?php echo e($previousRequest->amount); ?>" d-manager="<?php echo e($previousRequest->manager); ?>" d-approved="<?php echo e($previousRequest->approved); ?>"
                                        d-justification="<?php echo e($previousRequest->justification); ?>" d-department="<?php echo e($previousRequest->department); ?>" d-frequency="<?php echo e($previousRequest->frequency); ?>" d-other="<?php echo e($previousRequest->other); ?>"
                                        d-description="<?php echo e($previousRequest->description); ?>" d-username="<?php echo e($previousRequest->username); ?>" d-password="<?php echo e($previousRequest->password); ?>" d-website="<?php echo e($previousRequest->website); ?>">
                                        View
                                    </button>
                                </td>
                                <td class="text-center">
                                    <button data-toggle="modal" data-target="#requestHistoryModal" class="btn btn-primary text-center" d-id="<?php echo e($previousRequest->id); ?>">History</button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {
        $('#previous-requests-table').DataTable({
            "order":[[0,"asc"]],
            dom: 'Bfrtip',
            "pageLength": 10,
            buttons: [
            ],
            initComplete: function() {
            }
        });

        $('#archived-requests-table').DataTable({
            "order":[[0,"asc"]],
            dom: 'Bfrtip',
            "pageLength": 10,
            buttons: [
            ],
            initComplete: function() {
            }
        });
    })

    function archiveContract(contractId) {
        urlLink = "/RequestForm/archive/" + contractId;
        swal.fire({
            title: "Are you sure?",
            text:
                "You are about to archive the request with id " + contractId + ".",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Archive"
        }).then(willArchive => {
            if (willArchive.value) {
                $.LoadingOverlay("show", {
                    zIndex: 2147483645
                });
                $(function() {
                    "use strict";
                    $.get(urlLink, function(data) {
                        swal.fire(
                            "Success",
                            "Request has been successfully archived.",
                            "success"
                        );
                        setTimeout(() => location.reload(true), 100);
                    });
                });
            } else {
                swal.fire("Cancelled", "Request was not archived!", "error");
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\requestForm.blade.php ENDPATH**/ ?>