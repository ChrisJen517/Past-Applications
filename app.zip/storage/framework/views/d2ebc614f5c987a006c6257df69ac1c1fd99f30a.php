<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="modal fade" id="addProductHeaderModal">
    <div class="modal-dialog modal-sm-6">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title">Create New Product Header</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="<?php echo e(route('addProductHeader')); ?>" method="POST" enctype="multipart/form-data" id="addProductHeader">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Header Name</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="add_name" name="name" style="width: 100%;" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description</label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="description" name="description" rows="5" cols="20"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Product Name Label</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="add_column_1" name="column_1" value="Pricing/Service Name" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description Label</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="add_column_2" name="column_2" value="Description" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Pricing Label</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="add_column_3" name="column_3" value="Cost" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-4">Display to Agents
                        <input class="form-check-input" name="show_in_list" id="show_in_list" value="1" type="checkbox" style="margin-left: 5px;" checked>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="submit_2" class="btn btn-primary float-right" value="Create">
                </div>
            </form>
        </div>
    </div>
</div>

<script src=<?php echo e(asset('js/validation/addProductHeader.js')); ?>></script><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\addProductHeader.blade.php ENDPATH**/ ?>