<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet" />

<div class="modal fade" id="myModalMod" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <form action="<?php echo e(route('updateProduct')); ?>" method="POST" enctype="multipart/form-data" id="Update"
            class="needsValidated">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">Update Product</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Product Header</label>
                        <div class="col-lg-9">
                            <select class="form-control" name='product_header_id' value="" placeholder=""
                                id="prod_head">
                                <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option name=<?php echo e($item->id); ?> value=<?php echo e($item->id); ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Name</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="name" value="" type="text" placeholder="name">
                        </div>
                    </div>
                    <input hidden class="form-control" name="idName" value="" placeholder="idName">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" type="textarea" class="textarea" rows="5" cols="20" value=""
                                name="description" id="description" placeholder="description">
                            </textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" id="Price_modal_2">Standard
                            Price</label>
                        <div class="col-lg-7">
                            <input class="form-control" type="text" name="price" id="price" placeholder="Price">
                            <input hidden class="form-control" type="text" name="quote" placeholder="Custom Quote">
                            <input hidden class="form-control" type="text" name="use_quote">
                        </div>
                        <div class="col-lg-2">
                            <button class="btn btn-primary fee">Custom Fee</button>
                        </div>
                    </div>
                    <div class="form-group row" id="price_name">
                        <label class="col-lg-3 col-form-label form-control-label">Price Name</label>
                        <div class="col-lg-9">
                            <select class="form-control" style="display: show" name='price_name' value=""
                                placeholder="">
                                <option value="per hit">per hit</option>
                                <option value="per input">per input</option>
                                <option value="one time fee">one time fee</option>
                                <option value="monthly minimum">monthly minimum</option>
                                <option value="monthly recurring">monthly recurring</option>
                                <option value="monthly recurring monitoring">monthly recurring monitoring</option>
                                <option value="annual fee">annual fee</option>
                                <option value="percent of dollars collected">% of dollars collected</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="batch_code">
                        <label class="col-lg-3 col-form-label form-control-label">Batch Code</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="batch_code" value="" type="text" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row" id="vast_code">
                        <label class="col-lg-3 col-form-label form-control-label">Vast Code</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="vast_code" value="" type="text" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row" id="sla">
                        <label class="col-lg-3 col-form-label form-control-label">SLA</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="sla" value="" type="text" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;"
                            data-toggle="tooltip" title="Price threshold set to be confirmed by a manager.">
                            Manager Approval
                        </label>
                        <div class="col-lg-9">
                            <input class="form-control" type="text" name="manager_price_1" id="manager_price_1">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;"
                            data-toggle="tooltip" title="Price threshold set to be confirmed by an executive.">
                            Executive Approval
                        </label>
                        <div class="col-lg-9">
                            <input class="form-control" type="text" name="manager_price_2" id="manager_price_2">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-4">Display to Agents
                            <input class="form-check-input" name="show_in_list" id="show_in_list" value="1"
                                type="checkbox" style="margin-left: 5px;">
                        </div>
                    </div>
                </div>
                <div class="modal-footer" style="display: inline-block;">
                    <div class="float-left" id="Delete" style='color:white; display:inline-block;'>
                        <a class="btn btn-danger">Delete</a>
                    </div>
                    <div class="float-right">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input id="submit-button-2" type="submit" name="submit" class="btn btn-primary"
                            value="Update Product">
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<div class="modal fade" id="myModalModAdd" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
    <div class="modal-dialog modal-lg" role="document">
        <form action="<?php echo e(route('addProduct')); ?>" method="POST" enctype="multipart/form-data" id="AddProduct"
            class="needsValidated">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">Add Product</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                            aria-hidden="true">&times;</span></button>
                </div>
                <div class="modal-body">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Product Header</label>
                        <div class="col-lg-9">
                            <select class="form-control" name='product_header_id' value="" placeholder=""
                                id="prod_head_add">
                                <?php $__currentLoopData = $product_info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option name=<?php echo e($item->id); ?> value=<?php echo e($item->id); ?>><?php echo e($item->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Name</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="name" value="" type="text">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description</label>
                        <div class="col-lg-9">
                            <textarea class="form-control" type="textarea" class="textarea" rows="5" cols="20" value=""
                                name="description" id="description"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" id="Price_modal_1">Standard
                            Price</label>
                        <div class="col-lg-7">
                            <input class="form-control" type="text" name="price" id="price" placeholder="Price">
                            <input hidden class="form-control" type="text" name="quote" placeholder="Custom Quote">
                            <input hidden class="form-control" type="text" name="use_quote">
                        </div>
                        <div class="col-lg-2">
                            <button class="btn btn-primary fee">Custom Fee</button>
                        </div>
                    </div>
                    <div class="form-group row" id="price_name_add">
                        <label class="col-lg-3 col-form-label form-control-label">Price Name</label>
                        <div class="col-lg-9">
                            <select class="form-control" style="display: show" name='price_name' value=""
                                placeholder="">
                                <option value="per hit">per hit</option>
                                <option value="per input">per input</option>
                                <option value="one time fee">one time fee</option>
                                <option value="monthly minimum">monthly minimum</option>
                                <option value="monthly recurring">monthly recurring</option>
                                <option value="monthly recurring monitoring">monthly recurring monitoring</option>
                                <option value="annual fee">annual fee</option>
                                <option value="percent of dollars collected">% of dollars collected</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row" id="batch_code">
                        <label class="col-lg-3 col-form-label form-control-label">Batch Code</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="batch_code" value="" type="text" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row" id="vast_code">
                        <label class="col-lg-3 col-form-label form-control-label">Vast Code</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="vast_code" value="" type="text" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row" id="sla">
                        <label class="col-lg-3 col-form-label form-control-label">SLA</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="sla" value="" type="text" placeholder="">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;"
                            data-toggle="tooltip" title="Price threshold set to be confirmed by a manager.">
                            Manager Approval
                        </label>
                        <div class="col-lg-9">
                            <input class="form-control" type="text" name="manager_price_1" id="manager_price_1">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;"
                            data-toggle="tooltip" title="Price threshold set to be confirmed by an executive.">
                            Executive Approval
                        </label>
                        <div class="col-lg-9">
                            <input class="form-control" type="text" name="manager_price_2" id="manager_price_2">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-4">Display to Agents
                            <input class="form-check-input" name="show_in_list" id="show_in_list" value="1"
                                type="checkbox" style="margin-left: 5px;" checked>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input id="submit-button-2" type="submit" name="submit" class="btn btn-primary float-right"
                        value="Add Product">
                </div>
            </div>
        </form>
    </div>
</div>

<script src="<?php echo e(asset('js/validation/manageProducts.js?'.time())); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>

<script>
    $(document).ready(function() {


    $(".fee").on('click', function(e) {
        e.preventDefault();
        var input = $(this).parent().prev("div").find("input[name='price']");
        var text = $(input).parent().find("input[name='quote']");
        var use_quote = $(input).parent().find("input[name='use_quote']");
        if($(input).prop("hidden") == true)
        {
            $(input).prop("hidden", false);
            $(text).attr("hidden", true);
            $(this).text("Custom Fee");
            $(use_quote).val(0);
        }
        else
        {
            $(input).prop("hidden", true);
            if($(input).val() == "")
            {
                $(input.val(0.00));
                var manager_1 = $(input).parent().parent().parent().find("input[name='manager_price_1']");
                if($(manager_1).val() == "")
                    $(manager_1).val(0.00);
                var manager_2 = $(input).parent().parent().parent().find("input[name='manager_price_2']");
                if($(manager_2).val() == "")
                    $(manager_2).val(0.00);
            }
            $(text).attr("hidden", false);
            $(this).text("Add Price");
            $(use_quote).val(1);
        }
    })


    $('[data-toggle="tooltip"]').tooltip();

    $('#myModalMod').on('show.bs.modal', function (e) {
        var opener = $(e.relatedTarget); // holds the element that called the modal
        var id = opener.data('id');

        $('#Update').find('[name="idName"]').val(id);
        $('#Update').find('[name="name"]').val(opener.data('name'));
        $('#Update').find('[name="description"]').val(opener.data('description'));
        $('#Update').find('[name="product_header_id"]').val(opener.data('product_header_id'));
        $('#Update').find('[name="price"]').val(opener.data('price'));
        $('#Update').find('[name="quote"]').val(opener.data('quote'));
        $('#Update').find('[name="price_name"]').val(opener.data('price_name'));
        $('#Update').find('[name="batch_code"]').val(opener.data('batch_code'));
        $('#Update').find('[name="vast_code"]').val(opener.data('vast_code'));
        $('#Update').find('[name="sla"]').val(opener.data('sla'));
        $('#Update').find('[name="manager_price_1"]').val(opener.data('manager_price_1'));
        $('#Update').find('[name="manager_price_2"]').val(opener.data('manager_price_2'));

        if(opener.data('use') == 1)//use quote
        {
            $('#Update').find('[name="price"]').attr("hidden", true);
            $('#Update').find('[name="quote"]').attr("hidden", false);
            $('#Update').find('[name="use_quote"]').val(1);
            $('.fee').text("Add Fee")
        }
        else // use price
        {
            $('#Update').find('[name="price"]').attr("hidden", false);
            $('#Update').find('[name="quote"]').attr("hidden", true);
            $('#Update').find('[name="use_quote"]').val(0);
            $('.fee').text("Custom Fee")
        }
        if($(e.relatedTarget).data('check') == 1)
        {
            $('#show_in_list').attr('checked', true);
        }
        else
        {
            $('#show_in_list').attr('checked', false);
        }
        // var url = '<?php echo e(route("deleteProduct", ":id")); ?>';
        // url = url.replace(':id', id);
        // $("#Delete a").attr("href");
        // $("#Delete a").attr("href", url);

        $("#Delete a").attr("onclick", "deleteProduct(" + id + ")");
    });

    $('.modal').on('keypress', function (event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if(keycode == '13') {
            if (!$(this).find('#description').is(":focus")) event.preventDefault();
        }
    });

    $('#prod_head').on('change', function () {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        if(valueSelected == 11)
        {
            $("#price_name").hide(500);
            $("#Price_modal_2").text("Records");
        }
        else
        {
            $("#price_name").show(500);
            $("#Price_modal_2").text("Price");
        }
    });

    $('#prod_head_add').on('change', function () {
        var optionSelected = $("option:selected", this);
        var valueSelected = this.value;
        if(valueSelected == 11)
        {
            $("#price_name_add").hide(500);
            $("#Price_modal_1").text("Records");
        }
        else
        {
            $("#price_name_add").show(500);
            $("#Price_modal_1").text("Price");
        }
    });
});

$("#Update").submit(function(){
    if($(this).valid())
        $.LoadingOverlay("show");
});
</script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\manageProductsModal.blade.php ENDPATH**/ ?>