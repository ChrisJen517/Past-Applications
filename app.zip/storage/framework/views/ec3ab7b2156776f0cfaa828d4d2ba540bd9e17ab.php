<div class="loading-overlay">
    
    <?php $__env->startSection('content'); ?>

    <div class="container-fluid">
        <div class="row">
                <!-- form user info -->
                <div class="container-fluid">
                    <form action="<?php echo e(route('exportRedlineWithProducts')); ?>" method="POST" enctype="multipart/form-data" id="contract_information_form">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-header">
                                        <div class="row">
                                            <div class="col-md-6"><h3 class="mb-0">Redline Contract Information</h3></div>
                                            <div class="col-md-6"><h3 class="mb-0">Account Management Information:</h3></div>
                                        </div>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6">
                                                <h5 class="mb-0">Custom contracts will be sent to your active manager for approval. Once
                                                    approved your manager will then be able to forward the contract back to you.</h4>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group row">
                                                    <label class="col-lg-3 col-form-label form-control-label">Agent Email</label>
                                                    <div class="col-lg-9">
                                                        <input class="form-control" name="email" type="email"
                                                            value="<?php echo e(Auth::user()->email); ?>" readonly>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-3 col-form-label form-control-label">Manager Email</label>
                                                    <div class="col-lg-9">
                                                        <input autocomplete="off" class="form-control auto-complete-off" name="email"
                                                            type="email" value="<?php echo e(Auth::user()->manager_email); ?>" readonly>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <hr>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <div class="form-group row" hidden>
                                                    <label class="col-lg-3 col-form-label form-control-label">Contract ID</label>
                                                    <div class="col-lg-9">
                                                        <input class="form-control" name="contract_ID" type="text" value="<?php echo e($contract->id); ?>" readonly hidden>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company Name <span style="color:red">&#10033;</span></label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" id="company-select" value="" data-company="<?php echo e($client->company_name); ?>" name="company_id" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company Address <span
                                                        style="color:red">&#10033;</span></label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-address="<?php echo e($client->company_address); ?>"
                                                            id="company_address" name="company_address" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company City <span
                                                        style="color:red">&#10033;</span></label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-city="<?php echo e($client->company_city); ?>"
                                                            id="company_city" name="company_city" type="text">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company State <span
                                                        style="color:red">&#10033;</span></label>
                                                    <div class="col-lg-6">
                                                        <select id="company_state" data-state="<?php echo e($client->company_state); ?>"
                                                            name="company_state" class="form-control" size="0" value="">
                                                            <option value="AL">Alabama</option>
                                                            <option value="AK">Alaska</option>
                                                            <option value="AZ">Arizona</option>
                                                            <option value="AR">Arkansas</option>
                                                            <option value="CA">California</option>
                                                            <option value="CAN">Canada</option>
                                                            <option value="CO">Colorado</option>
                                                            <option value="CT">Connecticut</option>
                                                            <option value="DE">Delaware</option>
                                                            <option value="DC">District Of Columbia</option>
                                                            <option value="FL">Florida</option>
                                                            <option value="GA">Georgia</option>
                                                            <option value="HI">Hawaii</option>
                                                            <option value="ID">Idaho</option>
                                                            <option value="IL">Illinois</option>
                                                            <option value="IN">Indiana</option>
                                                            <option value="IA">Iowa</option>
                                                            <option value="KS">Kansas</option>
                                                            <option value="KY">Kentucky</option>
                                                            <option value="LA">Louisiana</option>
                                                            <option value="ME">Maine</option>
                                                            <option value="MD">Maryland</option>
                                                            <option value="MA">Massachusetts</option>
                                                            <option value="MI">Michigan</option>
                                                            <option value="MN">Minnesota</option>
                                                            <option value="MS">Mississippi</option>
                                                            <option value="MO">Missouri</option>
                                                            <option value="MT">Montana</option>
                                                            <option value="NE">Nebraska</option>
                                                            <option value="NV">Nevada</option>
                                                            <option value="NH">New Hampshire</option>
                                                            <option value="NJ">New Jersey</option>
                                                            <option value="NM">New Mexico</option>
                                                            <option value="NY">New York</option>
                                                            <option value="NC">North Carolina</option>
                                                            <option value="ND">North Dakota</option>
                                                            <option value="OH">Ohio</option>
                                                            <option value="OK">Oklahoma</option>
                                                            <option value="OR">Oregon</option>
                                                            <option value="PA">Pennsylvania</option>
                                                            <option value="PR">Puerto Rico</option>
                                                            <option value="RI">Rhode Island</option>
                                                            <option value="SC">South Carolina</option>
                                                            <option value="SD">South Dakota</option>
                                                            <option value="TN">Tennessee</option>
                                                            <option value="TX">Texas</option>
                                                            <option value="UT">Utah</option>
                                                            <option value="VT">Vermont</option>
                                                            <option value="VA">Virginia</option>
                                                            <option value="WA">Washington</option>
                                                            <option value="WV">West Virginia</option>
                                                            <option value="WI">Wisconsin</option>
                                                            <option value="WY">Wyoming</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company Zip <span
                                                                    style="color:red">&#10033;</span></label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-zip="<?php echo e($client->company_zip); ?>" id="company_zip"
                                                                        name="company_zip" type="text">
                                                    </div>
                                                </div>

                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company Email <span
                                                                    style="color:red">&#10033;</span></label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-email="<?php echo e($client->company_email); ?>"
                                                                        id="company_email" name="company_email" type="email">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company EIN</label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-ein="<?php echo e($client->company_ein); ?>" id="company_ein"
                                                                        name="company_ein" type="text">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company Phone</label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-phone="<?php echo e($client->company_phone); ?>"
                                                                        id="company_phone" name="company_phone" type="phone">
                                                    </div>
                                                </div>
                                                <div class="form-group row">
                                                    <label class="col-lg-6 col-form-label form-control-label">Company URL</label>
                                                    <div class="col-lg-6">
                                                        <input class="form-control" data-url="<?php echo e($client->company_url); ?>" id="company_url"
                                                                        name="company_url" type="text">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php echo $__env->make('Includes.forms.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group row" style="display: flex; justify-content: center;">
                            <div class="col-lg-4">
                                <input id="submit-button-2" name="submit-form" type="submit"
                                    class="btn btn-lg btn-primary btn-block" value="Generate Redline Products">
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>


<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>
<script src="<?php echo e(asset('js/contracts/contract.js?'.time())); ?>"></script>

<script>

$(document).ready(function(){
     $('#company-select').change(function(){
         var value = $(this).val();
         var _token = $('input[name="_token"]').val();
         $.ajax({
             url:"<?php echo e(route('fetchClientData')); ?>",
             method: "POST",
             data: {value:value, _token:_token},
             beforeSend: function(){
                 $.LoadingOverlay("show");
             },
             success:function(result)
             {
                 var data = $.parseJSON(result);
                 $("#company_address").val(data['company_address']);
                 $("#company_city").val(data['company_city']);
                 $("#company_state").val(data['company_state']);
                 $("#company_zip").val(data['company_zip']);
                 $("#company_email").val(data['company_email']);
                 $("#company_ein").val(data['company_ein']);
                 $("#company_url").val(data['company_url']);
                 $("#company_phone").val(data['company_phone']);
                 $("#account_payable_name").val(data['account_payable_name']);
                 $("#account_payable_phone").val(data['account_payable_phone']);
                 $("#account_payable_email").val(data['account_payable_email']);
                 $("#invoice_approver_name").val(data['invoice_approver_name']);
                 $("#invoice_approver_phone").val(data['invoice_approver_phone']);
                 $("#invoice_approver_email").val(data['invoice_approver_email']);
                 $("#executive_contact_name").val(data['executive_contact_name']);
                 $("#executive_contact_phone").val(data['executive_contact_phone']);
                 $("#executive_contact_email").val(data['executive_contact_email']);
             },
             complete: function() {
                 $.LoadingOverlay("hide", true);

             }
         })
     });
});


</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\redlineProducts.blade.php ENDPATH**/ ?>