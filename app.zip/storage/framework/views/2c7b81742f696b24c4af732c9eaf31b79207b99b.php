<?php $__env->startSection('content'); ?>

<br />
<div class="container-fluid center">
    <div class="mx-auto card" style="width: 60%;">
        <div class="card-header">
            <h4 class="mb-0">User Information</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('updateUser')); ?>" method="POST" enctype="multipart/form-data"
                id="user_information_form">
                <?php echo csrf_field(); ?>
                <input class="form-control" name="id" value="<?php echo e($user->id); ?>" hidden>
                <div class="form-group row">
                    <label class="col-lg-3 col-form-label form-control-label">Avatar</label>
                    <div class="col-lg-3">
                        <span class="user-profile" style="margin-left:75px"><img id="userImage"
                                <?php if(asset('/ProfilePictures'.'/'.$user->id.'/avatar.png')): ?>
                                src="<?php echo e(asset('ProfilePictures/'.$user->id.'/avatar.png?'.time())); ?>" <?php else: ?>
                                src="https://via.placeholder.com/110x110" <?php endif; ?> class="img-circle"
                                alt="user avatar"></span>
                    </div>
                    <div class="col-lg-6">
                        <input autocomplete="off" class="form-control auto-complete-off custom-file-input"
                            id="customFileInput" name="avatar" id="avatar" type="file">
                        <label class="custom-file-label" for="customFileInput" style="margin: 0px 15px 0px 15px;">Choose
                            file...</label>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label form-control-label">First name</label>
                    <div class="col-lg-8">
                        <input class="form-control" name="name_first" type="text" value=<?php echo e($user->name_first); ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label form-control-label">Last name</label>
                    <div class="col-lg-8">
                        <input class="form-control" name="name_last" type="text" value=<?php echo e($user->name_last); ?>>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label form-control-label">Email</label>
                    <div class="col-lg-8">
                        <input autocomplete="off" class="form-control auto-complete-off" name="email" type="email"
                            value=<?php echo e($user->email); ?> readonly>
                    </div>
                </div>
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label form-control-label">Role</label>
                    <div class="col-lg-8">
                        <select class="form-control" name="role" type="text" id="role">
                            <option value="manager" <?php if(Auth::user($user)->role == 'manager'): ?> selected <?php endif; ?>>Manager
                            </option>
                            <option value="agent" <?php if($user->role == 'agent'): ?> selected <?php endif; ?>>Agent</option>
                        </select>
                    </div>
                </div>
                
                <input class="form-control" name="old_manager_email" id="old_manager_email"
                    value="<?php echo e($user->manager_email); ?>" hidden>

                <div class="form-group row" id="hiddenEmail" <?php if($user->role == 'manager'): ?> style="display:none;" <?php endif; ?>>
                    <label class="col-lg-4 col-form-label form-control-label">Manager Email</label>
                    <div class="col-lg-8">
                        <select class="form-control" name="manager_email" type="text">
                            <?php if(!empty($user->manager_email)): ?>
                            <option value="<?php echo e($user->manager_email); ?>"><?php echo e($user->manager_email); ?></option>
                            <?php else: ?>
                            <option value="">Select Manager</option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $managers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manager): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($manager->email); ?>"><?php echo e($manager->email); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <?php if(Auth::user()->is_admin == 1): ?>
                <div class="form-group row" id="admin_checkbox_div" <?php if($user->role == 'agent'): ?> hidden <?php endif; ?>>
                    <div class="col-lg-4">
                        Admin Account
                        <input class="form-check-input" name="is_admin" type="hidden" value="0">
                        <input class="form-check-input" name="is_admin" id="admin_checkbox_input" type="checkbox"
                            value="1" style="margin-left: 5px;" <?php if($user->is_admin == 1): ?> checked <?php endif; ?>>
                    </div>
                </div>
                <?php endif; ?>
                <div class="form-group row">
                    <div class="col-lg-12">
                        <a href="/manageUsers" type="text" class="btn btn-secondary float-left">Back</a>
                        <input id="submit-button-2" type="submit" class="btn btn-primary float-right"
                            value="Save Changes">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function () {
    // form front-end validation
    $('#user_information_form').validate({
        rules: {
            name_first: {
                required: true
            },
            name_last: {
                required: true
            },
            email: {
                required: true,
                email: true
            }
        }
    });

    $('input[name=newPassword]').keyup(function() {
        var pswd = $(this).val();

        //validate length
        if (pswd.length < 10 && pswd.length < 33) {
            $('#length').removeClass('valid').addClass('invalid');
        } else {
            $('#length').removeClass('invalid').addClass('valid');
        }

        //validate capital letter
        if (pswd.match(/[A-Z]/)) {
            $('#letter_upper').removeClass('invalid').addClass('valid');
        } else {
            $('#letter_upper').removeClass('valid').addClass('invalid');
        }

        //validate lowercase letter
        if (pswd.match(/[a-z]/)) {
            $('#letter_lower').removeClass('invalid').addClass('valid');
        } else {
            $('#letter_lower').removeClass('valid').addClass('invalid');
        }

        //validate number
        if (pswd.match(/\d/)) {
            $('#number').removeClass('invalid').addClass('valid');
        } else {
            $('#number').removeClass('valid').addClass('invalid');
        }

        //validate special character
        if (pswd.match(/^(?=.*?[#?!@$%^&*-])/)) {
            $('#special').removeClass('invalid').addClass('valid');
        } else {
            $('#special').removeClass('valid').addClass('invalid');
        }
    }).focus(function() {
        // Keep width static, change height when depending on focus on password.
        $('#pswd_info').parent().css({"visibility": "visible", "height": "100%"});
    }).blur(function() {
        $('#pswd_info').parent().css({"visibility": "hidden", "height": "0px"});
    });

    // Validate avatar file
    $(".custom-file-input").on("change", function() {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            if (fileSize > 51200) //check file size
            {
                swal.fire({
                    title: "File size too large!",
                    text: "Image size cannot exceed 50kb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }

            else if (ext != '.jpg' && ext != '.jpeg' && ext != '.png') //check file extension type
            {

                swal.fire({
                    title: "Wrong file type",
                    text: "Must be .jpg, .jpeg, or .png",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }

            if ($(this).val() != "") {
                var fileName = $(this).val().split("\\").pop();
                $(this).siblings(".custom-file-label").addClass("selected").html(fileName);
            }
        }
    });
});

$(document).ready(function () {

    $('#role').on('change', function(){
        if( $('#role').val() == 'agent')
        {
                $('#hiddenEmail').slideDown(500);
                if ($('#admin_checkbox_div').length) {
                    $('#admin_checkbox_div').attr('hidden', true);
                    $('#admin_checkbox_input').attr('disabled', true);
                }
                $('[name=manager_email]').val($('#old_manager_email').val());
        }
        if( $('#role').val() == 'manager')
        {
                $('#hiddenEmail').hide('slide', { direction: 'up' }, 500);
                if ($('#admin_checkbox_div').length) {
                    setTimeout(() => $('#admin_checkbox_div').attr('hidden', false), 510);
                    $('#admin_checkbox_input').attr('disabled', false);
                }
                $('[name=manager_email]').val('');
        }
    });
});

$("#user_information_form").on( "submit",function(){
    if($(this).valid())
        $.LoadingOverlay("show");
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\editUser.blade.php ENDPATH**/ ?>