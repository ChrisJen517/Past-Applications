<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="loading-overlay">
    <div class="modal fade" id="requestFormModal" tabindex="-1" role="dialog" aria-labelledby="editLabel">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content border-0" id="myModalRequestBody">
                <div class="modal-header">
                    <h5 class="modal-title" id="editLabel">Request Form</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                </div>
                <form method="POST" enctype="multipart/form-data" id="requestFormModalForm">
                    <div class="modal-body">
                        <?php echo csrf_field(); ?>
                        <input type="text" class="form-control" id="edit_id" name="id" value="" hidden>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Description <span style="color:red">*</span></label>
                            <div class="col-lg-9">
                                <textarea class="form-control" type="textarea" class="textarea" rows="5" cols="20" value=""
                                    name="description" id="edit_description" placeholder="Description" required>
                                </textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Amount <span style="color:red">*</span></label>
                            <div class="col-lg-4">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">$</span>
                                    </div>
                                    <input class="form-control" id="edit_amount" name="amount" value="" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" required>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <select id="edit_frequency" class="form-control" name="frequency" required>
                                    <option value="" selected>Select Payment Frequency</option>
                                    <option value="One time">One time</option>
                                    <option value="Monthly">Monthly</option>
                                    <option value="Quarterly">Quarterly</option>
                                    <option value="Annually">Annually</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row" id="amount_other" hidden>
                            <label class="col-lg-3 col-form-label form-control-label">Other Explained <span style="color:red">*</span></label>
                            <div class="col-lg-9">
                                <textarea class="form-control" type="textarea" class="textarea" rows="5" cols="20" value=""
                                    name="other" id="edit_other" placeholder="Other Explained" required>
                                </textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Website</label>
                            <div class="col-lg-9">
                                <div class="input-group">
                                    <input class="form-control" name="website" id="edit_website" placeholder="Website" value="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Username</label>
                            <div class="col-lg-9">
                                <div class="input-group">
                                    <input class="form-control" name="username" id="edit_username" placeholder="Username" value="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Password</label>
                            <div class="col-lg-9">
                                <div class="input-group">
                                    <input class="form-control" name="password" id="edit_password" placeholder="Password" value="">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Business Justification <span style="color:red">*</span></label>
                            <div class="col-lg-9">
                                <textarea class="form-control" type="textarea" class="textarea" rows="5" cols="20" value=""
                                    name="justification" id="edit_justification" placeholder="Business Justification" required>
                                </textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Department <span style="color:red">*</span></label>
                            <div class="col-lg-9">
                                <select id="edit_department" class="form-control" name="department" required>
                                    <option value="" selected>Select a Department</option>
                                    <option value="Technology, Development, Info Security">Technology, Development, Info Security</option>
                                    <option value="Accounting and Finance">Accounting and Finance</option>
                                    <option value="Human Resources">Human Resources</option>
                                    <option value="Operations">Operations</option>
                                    <option value="COE">COE</option>
                                    <option value="Sales">Sales</option>
                                    <option value="Marketing">Marketing</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Manager Approval</label>
                            <div class="col-lg-9">
                                <div class="input-group">
                                    <input class="form-control" name="manager" id="edit_manager" value="" readonly>
                                </div>
                            </div>
                        </div>
                    </div>
                    <input class="form-control" name="manager_email" id="edit_manager_email" value="" hidden readonly>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <input type="submit" id="submit" class="btn btn-primary float-right" value="Submit">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script>
    $(document).ready(function() {

        $('[data-toggle="tooltip"]').tooltip();

        $('#requestFormModal').on('show.bs.modal', function(e) {
            var fields = ['id', 'username', 'password', 'justification', 'ammount', 'department', 'submitter', 'frequency', 'other', 'website', 'description', 'amount' , 'manager'];
            var opener = e.relatedTarget;

            if( $(opener).attr('d-type') == 'edit' || $(opener).attr('d-type') == "view"){
                for(i = 0; i < fields.length; i++)
                    $("#edit_"+fields[i]).val( $(opener).attr('d-'+fields[i]));
            }
            else{
                for(i = 0; i < fields.length; i++)
                    $("#edit_"+fields[i]).val('');
            }

            if( $( "#edit_frequency option:selected" ).text() != 'Other')
                $("#amount_other").attr("hidden",true);
            else
                $("#amount_other").attr("hidden",false);

            var readonly = false;
            if($(opener).attr('d-type') == "view"){
                $("#submit").attr("hidden",true);
                readonly = true;
            }
            else
                $("#submit").attr("hidden",false);

            for(i = 0; i < fields.length - 1; i++){
                $("#edit_"+fields[i]).attr("readonly",readonly);
            }

            $('#requestFormModalForm').attr('action', '/RequestForm/submit');
        });

        $("#requestFormModalForm").submit(function () {
            $('#myModalRequestBody').LoadingOverlay("show");
        });

        // validate signup form on keyup and submit
        validator = $("#requestFormModalForm").validate({
            rules: {
                description: "required",
                amount: "required",
                justification: "required",
                department: "required",
            },
            messages: {
                description: "Enter a description of the purchase",
                amount: "Enter the cost of the purchase",
                justification: "Enter the buisness justification for the purchase",
                department: "Select a department",
            },
            invalidHandler: function (event, validator) {
                // 'this' refers to the form
                var errors = validator.numberOfInvalids();
                if (errors) {
                    $('#myModalRequestBody').LoadingOverlay("hide");
                } else {
                    $('#myModalRequestBody').LoadingOverlay("show");
                }
            }
        });

        $('#requestFormModal').on('hide.bs.modal', function(e) {
            validator.resetForm();
        });
    });

    $( "#edit_department" ).change(function () {
        selected = $( "#edit_department" ).val();

        manager = '';
        emails = '';
        switch(selected){
            case "Technology, Development, Info Security":
                manager ='Prateek Gupta';
                emails = 'prateekg@rnngroup.com';
            break;
            case "Accounting and Finance":
                manager ='Daniel Gardner';
                emails = 'DanielG@rnngroup.com';
            break;
            case "Human Resources":
                manager ='Shannon McLaughlin';
                emails = 'ShannonM@rnngroup.com';
            break;
            case "COE":
                manager = 'Eulicia Keyes';
                emails = 'EuliciaK@rnngroup.com';
            break;
            case 'Operations':
                manager = 'Jacob Buscaglia';
                emails = 'Jacobb@rnngroup.com';
            break;
            case "Marketing":
                manager ='Scott Mingus';
                emails = 'ScottM@rnngroup.com';
            break;
            case "Sales":
                manager ='Dennis Guetterman';
                emails = 'dennisg@rnngroup.com';
            break;
        }

        $( "#edit_manager" ).val(manager);
        $( "#edit_manager_email" ).val(emails);
    }).change();

    $('#edit_frequency').on('change', function(){
        if( $( "#edit_frequency option:selected" ).text() != 'Other')
            $("#amount_other").attr("hidden",true);
        else
            $("#amount_other").attr("hidden",false);
    });
</script><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\requestForms\requestFormModal.blade.php ENDPATH**/ ?>