<?php $__env->startSection('route'); ?>
<?php echo e(route('exportResellerAgreement')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('companyInformation'); ?>
<?php echo $__env->make('Includes.forms.companyInformation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <hr>
    <div class="card-body">
        <div class="row">
            <div class="col-lg-6">
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label form-control-label">State of Organization <span style="color:red">&#10033;</span></label>
                    <div class="col-lg-8">
                        <input class="form-control" id="organization" name="organization" type="text" required>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="form-group row">
                    <label class="col-lg-4 col-form-label form-control-label">Entity Type <span style="color:red">&#10033;</span></label>
                    <div class="col-lg-8">
                        <input class="form-control" id="entity" name="entity" type="text" required>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
<div class="mx-auto card w-75">
    <div class="card-body">
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                        Issued by
                    </div>
                    <div class="col-lg-4" style="margin-bottom: 10px;">
                        <select class="form-control float-right" id="issued_by" name="issued_by" type="text" required>
                            <option value="Reseller">Reseller</option>
                            <option value="RNN Group, Inc.">RNN Group, Inc.</option>
                        </select>
                    </div>
                </div>
            </div>  
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                        Products Included
                    </div>
                    <div class="col-lg-4" style="margin-bottom: 10px;">
                        <input class="form-control float-right" id="products" name="products" type="text" readonly value="YouNegotiate">
                    </div>
                </div>
            </div>
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                        Reseller Industry(s)
                    </div>
                    <div class="col-lg-4" style="margin-bottom: 10px;">
                        <select class="form-control float-right" id="industry" name="industry" type="text">
                            <option value="All Industries">All Industries</option>
                            <option value="Healthcare">Healthcare</option>
                            <option value="Loan Originators">Loan Originators</option>
                            <option value="Banks">Banks</option>
                            <option value="Universities">Universities</option>
                            <option value="3rd Party Collections">3rd Party Collections</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="col-lg-3" style="margin-bottom: 10px;">
                        <input class="form-control" id="industry_other" name="industry_other" type="text" hidden>
                    </div>
                </div>
            </div>
            
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                        End User Demos
                    </div>
                    <div class="col-lg-4" style="margin-bottom: 10px;">
                        <select class="form-control" id="demos" name="demos" type="text">
                            <option value="Reseller">Reseller</option>
                            <option value="RNN Group">RNN Group</option>
                            <option value="RNN Group and Reseller">RNN Group and Reseller</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                       % Minimum Fee
                    </div>
                    <div class="col-lg-4" style="margin-bottom: 10px;">
                        <input class="form-control float-right" id="min_fee" min="0" step="0.1" name="price[0]"
                            type="number" value="7">
                        <input hidden class="form-control" name="originalPrice[]" value="7"
                            placeholder="originalPrice">
                        <input hidden class="form-control" name="managerPrice[]" value="5" placeholder="managerPrice">
                        <input hidden class="form-control" name="jimPrice[]" value="0" placeholder="jimPrice">
                        <input hidden class="form-control" name="name[]" value="Minimum Fee (Collected Payments)"
                            placeholder="">
                        <input hidden class="form-control" name="prod_header_id[]" value="" placeholder="">
                        <input hidden class="form-control" name="reason[]" value="" placeholder="">
                        <textarea hidden class="form-control" name="description[]" value=""
                            placeholder=""></textarea>
                        <input hidden class="form-control" name="price_name[]" value="Minimum Fee (Collected Payments)"
                            placeholder="">
                    </div>
                </div>
            </div>
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                       Initiation & Setup Fee
                    </div>
                <div class="col-md-4" style="margin-bottom: 10px;">
                    <input class="form-control float-right" id="price" min="0" step="1" name="setup_fee" type="number"
                        value="3000" required>
                    <input hidden class="form-control" name="originalPrice[]" value="0" placeholder="originalPrice">
                    <input hidden class="form-control" name="managerPrice[]" value="1500" placeholder="managerPrice">
                    <input hidden class="form-control" name="jimPrice[]" value="3000" placeholder="jimPrice">
                    <input hidden class="form-control" name="name[]" value="Initiation & Setup Fee" placeholder="">
                    <input hidden class="form-control" name="prod_header_id[]" value="" placeholder="">
                    <input hidden class="form-control" name="reason[]" value="" placeholder="">
                    <textarea hidden class="form-control" name="description[]"
                        value="Applies for custom set ups for merchant account connections if not on the site"
                        placeholder="">Applies for custom set ups for merchant account connections if not on the site</textarea>
                    <input hidden class="form-control" name="price_name[]" value="One-Time Set Up" placeholder="">
                </div>
                </div>
            </div>
            <div class="form-check">
                <div class="row">
                    <div class="offset-md-1 col-md-4">
                        % of Commission on RNN collected payment and eLetter revenue
                    </div>
                        <div class="col-lg-4" style="margin-bottom: 10px;">
                        <input class="form-control float-right" id="min_fee" min="0" step="0.1" name="commission_fee"
                            type="number" value="20">
                        <input hidden class="form-control" name="originalPrice[]" value="20"
                            placeholder="originalPrice">
                        <input hidden class="form-control" name="managerPrice[]" value="25" placeholder="managerPrice">
                        <input hidden class="form-control" name="jimPrice[]" value="30" placeholder="jimPrice">
                        <input hidden class="form-control" name="name[]" value="% of Commission on RNN collected payment and eLetter revenue"
                            placeholder="">
                        <input hidden class="form-control" name="prod_header_id[]" value="" placeholder="">
                        <input hidden class="form-control" name="reason[]" value="" placeholder="">
                        <textarea hidden class="form-control" name="description[]" value=""
                            placeholder=""></textarea>
                        <input hidden class="form-control" name="price_name[]" value="% of Commission on RNN collected payment and eLetter revenue"
                        placeholder="">
                    </div>
                </div>
            </div>
    </div>
    <script>
        $(document).ready(function() {
            setTimeout(() => {
                $('[name^="price["]').each(function() {
                    $(this).rules("add", {
                        minimumPrice: true,
                        messages: {
                            min: "Invalid price"
                        }
                    });
                })
            }, 0);

            $("#industry").on("change", function(){
                if($(this).val() != "Other")
                {
                    $("#industry_other").attr("hidden", true);
                    $("#industry_other").prop("required", false);
                } else {
                    $("#industry_other").attr("hidden", false);
                    $("#industry_other").prop("required", true);
                }
            });

            $("#territory").on("change", function(){
                if($(this).val() == "National")
                {
                    $("#territory_other").attr("hidden", true);
                    $("#territory_other").prop("required", false);
                } else {
                    $("#territory_other").attr("hidden", false);
                    $("#territory_other").prop("required", true);
                }
            });
        });
    </script>
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('name'); ?>
    You-Negotiate Reseller Agreement
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.baseContract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\resellerAgreement.blade.php ENDPATH**/ ?>