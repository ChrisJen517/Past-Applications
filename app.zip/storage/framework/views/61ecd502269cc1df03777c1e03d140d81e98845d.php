<?php $__env->startSection('content'); ?>
<?php echo $__env->make('manager.tossAccountsModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<br>

<section id="unworked-leads-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <p class="float-left">Lead Queue: <?php echo e($total_unassigned); ?> Un-Assigned Leads</p>
            </div>
        <div class="col-md-2 offset-md-2">
                <a href="" data-toggle="modal" data-target="#tossAccountsModal" class="btn btn-primary btn-sm float-right" role="button">Toss Accounts</a>
            </div>
        </div>
    </div>
</section>

<section id="unworked-leads">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="unworked-leads-div">
                <div id="parent1" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="unworked-leads-table">
                        <thead>
                            <tr>
                                <th class="text-center">Agent ID</th>
                                <th class="text-center">Agent Name</th>
                                <th class="text-center">New Accounts</th>
                                <th class="text-center">Worked Accounts</th>
                                <th class="text-center">Total Accounts</th>
                                <th class="text-center">Un-Assign Queue</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <?php if(empty($lead->agent_id)): ?>
                                    <td class="text-center">Unassigned</td>
                                <?php else: ?>
                                    <td class="text-center"><?php echo e($lead->agent_id); ?></td>
                                <?php endif; ?>
                                <?php if(empty($lead->agent_name)): ?>
                                    <td class="text-center">Unassigned</td>
                                <?php else: ?>
                                    <td class="text-center"><?php echo e($lead->agent_name); ?></td>
                                <?php endif; ?>
                                <td class="text-center"><?php echo e($lead->new_accounts); ?></td>
                                <td class="text-center"><?php echo e($lead->worked_accounts); ?></td>
                                <td class="text-center"><?php echo e($lead->total_accounts); ?></td>

                                <?php if(empty($lead->agent_id)): ?>
                                    <td class="text-center">N/A</td>
                                <?php else: ?>
                                    <td class="text-center">
                                        <form action="<?php echo e(route('clearAgentLeads')); ?>" method="GET" id="showLeadForm"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <input class="form-control" type="hidden" id="leadId" name="id"
                                                value="<?php echo e($lead->agent_id); ?>">
                                            <button class="btn btn-danger" type="submit" style="color: white;">Un-Assign</button>
                                        </form>
                                    </td>
                                <?php endif; ?>

                                <td class="text-center">
                                    <form action="<?php echo e(route('showAgentLeads')); ?>" method="GET" id="showLeadForm"
                                        enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <input class="form-control" type="hidden" id="leadId" name="id"
                                            value="<?php echo e($lead->agent_id); ?>">
                                        <button class="btn btn-info" type="submit"  style="color: white;">Show
                                            Accounts</button>
                                    </form>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
$(document).ready(function() {

    $('#unworked-leads-table').DataTable({
        "order": [
            [3, "desc"],
            [1,"asc"]
        ],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#parent1').removeClass('table-parent-hidden');
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\salesLeadQueues.blade.php ENDPATH**/ ?>