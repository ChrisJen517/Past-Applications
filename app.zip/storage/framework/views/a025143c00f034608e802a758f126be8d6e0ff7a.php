<?php $__env->startSection('route'); ?>
<?php echo e(route('exportNameChangeAmendment')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('companyInformation'); ?>
<?php echo $__env->make('Includes.forms.amendmentCompanyInformation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <hr>
    <br>
    <div class="col-lg-6">
        <div class="form-group row">
            <label class="col-lg-4 col-form-label form-control-label">New Company Name <span style="color:red">&#10033;</span></label>
            <div class="col-lg-8">
                <input class="form-control" id="new_name" name="new_name" type="text">
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
    <script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
    <link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">

    <script>
    $(document).ready(function() {
        $(function() {
            $('#datepicker').datepicker({
                maxDate: new Date,
            });
        });
    });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name', 'Name Change Amendment'); ?>
<?php echo $__env->make('Includes.baseContract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\NameChangeAmendment.blade.php ENDPATH**/ ?>