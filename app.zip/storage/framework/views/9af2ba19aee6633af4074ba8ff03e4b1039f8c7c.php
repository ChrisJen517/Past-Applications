<link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/form.css?'.time())); ?>" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.css" rel="stylesheet">

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item">
                    <a class="nav-link custom-nav-link active" data-toggle="tab" href="#my-activity" style="border-radius: .2rem 0 0 0;">My Activity</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link custom-nav-link" data-toggle="tab" href="#new-task" style="border-radius: .2rem 0 0 0;">Next Step</a>
                </li>
            </ul>
        </div>
        <div class="card-body">
            <div class="tab-content">
                <div id="my-activity" class="container tab-pane active">
                    <div class="options" style="font-size: 12px;">
                        <span>  [  </span>
                        <a href="#" class="expand-all">Expand All</a>
                        <span>  |  </span>
                        <a href="#" class="view-all">View All</a>
                        <span>  |  </span>
                        <a href="#" class="hide-all">Hide All</a>
                        <span>  ]  </span>
                    </div>
                    <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity => $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a class="btn btn-activity" <?php if(empty($values)): ?> style="display: none;" <?php endif; ?> data-toggle="collapse" href="#<?php echo e(str_replace(' ', '_', $activity)); ?>" role="button" aria-expanded="true" aria-controls="<?php echo e(str_replace(' ', '_', $activity)); ?>"><i class="fa fa-custom-drop float-left" style="font-size: 20px; color: dodgerblue;"></i><?php echo e($activity); ?></a>
                        <div class="collapse show" id="<?php echo e(str_replace(' ', '_', $activity)); ?>" data-role="group">
                            <div class="events" style="padding:0px 10px 5px 10px;">
                                <?php $__currentLoopData = $values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="event" id="event-<?php echo e($value->id); ?>">
                                    <div class="row" style="margin-top: 5px;">
                                        <div class="col-md-1">
                                            <?php if($value->type != 'note'): ?>
                                            <a data-toggle="collapse" class="collapsed inner-collapse" href="#activity<?php echo e($value->id); ?>" role="button" aria-expanded="true" aria-controls="activity<?php echo e($value->id); ?>"><i class="fa fa-custom-note float-left" style="font-size: 20px; color: black;"></i></a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-1 text-center">

                                            <?php if($activity == 'Upcoming and Overdue'): ?>
                                                <?php ($color = "#cd5c5c"); ?>
                                                <?php if($value->type == 'task' && $value->is_complete == '0'): ?>
                                                    
                                                    <?php ($icon = "far fa-file-excel"); ?>
                                                <?php else: ?>
                                                    
                                                    <?php ($icon = "far fa-calendar-times"); ?>
                                                <?php endif; ?>
                                            <?php else: ?>
                                                <?php ($color = "#228b22"); ?>
                                                <?php if($value->type == 'task'): ?>
                                                    
                                                    <?php ($icon = "fas fa-tasks"); ?>
                                                <?php elseif($value->type == 'note'): ?>
                                                    <?php if(!empty($value->attachment)): ?>
                                                        <?php ($icon = "fas fa-paperclip"); ?>
                                                        <?php ($color = "#007bff"); ?>
                                                    <?php else: ?>
                                                        <?php ($icon = "far fa-sticky-note"); ?>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    
                                                    <?php ($icon = "far fa-calendar-check"); ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                            <?php if(!empty($value->attachment)): ?>
                                            <a href="<?php echo e(route('download', $value->attachment)); ?>">
                                                <i class="fas fa-paperclip" id="custom-icon-color" style="font-size: 15px; color: <?php echo e($color); ?>"></i>
                                            </a>
                                            <?php else: ?>
                                            <i class="<?php echo e($icon); ?>" id="custom-icon-color" style="font-size: 15px; color: <?php echo e($color); ?>"></i>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-7">
                                            <?php if((isset($value->description))): ?>
                                            <a tabindex="0" class="custom-popover" role="button" data-container="body" data-toggle="popover" data-placement="top" data-trigger="focus" data-title="Description" data-content="<?php echo e($value->description); ?>" style="font-size:14px; margin-bottom: 0px;">
                                            <?php endif; ?>
                                            <p <?php if(isset($value->description)): ?> class="float-left has-description" <?php else: ?> class="float-left" <?php endif; ?> style="font-size:14px; margin-bottom: 0px;">
                                            <?php if($value->type == 'task' && $value->is_complete == '0'): ?>
                                            <input type="checkbox" id="mark-completed" data-id="<?php echo e($value->id); ?>" title="Mark Complete">
                                            <?php endif; ?>
                                            <?php echo e($value->subject); ?>

                                            <?php if($value->attachment != ''): ?>
                                            <a href="<?php echo e(route('download', $value->attachment)); ?>">
                                                <i class="fas fa-paperclip"></i>
                                            </a>
                                            <?php endif; ?>
                                            </p>
                                            <?php if((isset($value->description))): ?>
                                            </a>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-3">
                                            <span class="float-right" style="font-size:10px;"><?php echo e(date_create_from_format('Y-m-d H:i:s', $value->dateDue)->format('M d Y')); ?></span>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-1 offset-md-1">
                                            <div class="line-vertical mx-auto" id="custom-bg-color" style="background-color: <?php echo e($color); ?>"></div>
                                        </div>
                                        <div class="col-md-10">
                                            <span class="float-left" style="font-size: 10px;">
                                                <?php echo e($value->agent_name); ?> created a next step.
                                            </span>
                                        </div>
                                    </div>
                                    <?php if($value->type != 'note'): ?>
                                    <div class="collapse" id="activity<?php echo e($value->id); ?>" data-role="notes">
                                        <div class="row">
                                            <div class="col-md-1 offset-md-1">
                                                <div class="line-vertical mx-auto" id="custom-bg-color" style="background-color: <?php echo e($color); ?>"></div>
                                            </div>
                                            <div class="col-md-10" style="margin-top: 10px;">
                                                <div class="card" style="background-color: #ebebeb;">
                                                    <div class="card-header note-header" style="background-color: #ebebeb;">
                                                        <span style="color: dodgerblue;">Notes</span>
                                                    </div>
                                                    <div class="card-body" style="padding: 0px 10px 10px 10px;">
                                                        <div class="row">
                                                            <div class="col-md-12" id="append-note">
                                                                <?php $__currentLoopData = $value->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <span style="font-size: 14px;"><?php echo e($note->note); ?></span>
                                                                <br>
                                                                <span style="font-size: 10px; color: dodgerblue;"><?php echo e($note->agent_name); ?> - <?php echo e(date_create_from_format('Y-m-d H:i:s', $note->created_at)->format('M d Y')); ?></span>
                                                                <br><br>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <button id="add-note-button" data-activityref="<?php echo e($value->id); ?>" data-agentref="<?php echo e(Auth::user()->id); ?>" class="btn btn-primary btn-sm float-right ml-auto notes-<?php echo e($value->id); ?>" style="margin: -20px 0px 20px 0px;">Add Note</button>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div id="new-task" class="container tab-pane"><br>
                    <form action="<?php echo e(route('createNextStep', '1')); ?>" method="POST" id="createNextStep" enctype="multipart/form-data">
                        <div class="form-group row">
                            <input type="text" id="lead_reference_id" name="lead_reference_id" value="<?php echo e($lead->id); ?>" hidden>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Subject<span class="required">*</span></span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-info form-icon"></i>
                                <select class="form-control input-field" id="subject" name="subject" value="<?php echo e(old('subject')); ?>" placeholder="" required>
                                    <option value="" selected disabled>Select a Subject</option>
                                    <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subject); ?>"><?php echo e($subject); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Agenda</span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container-area">
                                <i class="fas fa-comment form-icon"></i>
                                <textarea rows="5" style="resize: none;" class="form-control input-field" id="description" name="description" value="<?php echo e(old('description')); ?>" placeholder=""></textarea>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Date<span class="required">*</span></span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="far fa-calendar-plus form-icon"></i>
                                <input class="form-control input-field" id="datetimepicker3" name="date" value="<?php echo e(old('date')); ?>" placeholder="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Assigned To<span class="required">*</span></span>
                                <i class="fas fa-check form-icon-added" style="display: show;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-user-edit form-icon"></i>
                                <select class="form-control input-field multiple-select-agents" id="assigned_to[]" value="<?php echo e($lead->agent_id); ?>" name="assigned_to[]" multiple>
                                    <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($agent->id); ?>" <?php if($agent->id == $lead->agent_id): ?> selected readonly <?php endif; ?>><?php echo e($agent->name_first . ' ' . $agent->name_last); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Contact(s)</span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-user form-icon"></i>
                                <select class="form-control input-field multiple-select-contacts" id="contacts[]" name="contacts[]" data-width:"100%" multiple>
                                    <?php $__currentLoopData = $lead_contacts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($contact->id); ?>">[<?php echo e($contact->lead_title); ?>] <?php echo e($contact->first_name . ' ' . $contact->last_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row" style="display: none;">
                            <div class="form-label">
                                <span>Location</span>
                                <i class="fas fa-check form-icon-added hide-on-reset" style="display: none;"></i>
                            </div>
                            <div class="input-container">
                                <i class="fas fa-map-marked-alt form-icon"></i>
                                <input class="form-control input-field" id="location" name="location" value="<?php echo e(old('location')); ?>" placeholder="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="form-label">
                                <span>Related To</span>
                                <i class="fas fa-check form-icon-added" style="display: show;"></i>
                            </div>
                            <div class="input-container">
                                <i class="far fa-building form-icon"></i>
                                <input class="form-control input-field" id="related_to" name="related_to" value="<?php echo e($lead->company_name); ?>" placeholder="">
                            </div>
                        </div>
                        <div class="form-group row">
                            <button type="submit" name="submit" id="submit-button-1" value="submit" class="btn btn-success btn-lg ml-auto">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

    $('.multiple-select-agents').select2({
        placeholder: 'Select Agent(s)'
    });

    $('.multiple-select-contacts').select2({
        placeholder: 'Select Contact(s)'
    });

    var userId = "<?php echo e($lead->agent_id); ?>";
    var salesAgent = "<?php echo e($lead->sales_agent); ?>";

    var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
    $(selectItem).remove();

    $('.multiple-select-agents').on('select2:unselecting', function(event) {
        var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
        $(selectItem).remove();

        if (event.params.args.data.id == userId) {
            event.preventDefault();
        }
    });

    $('.multiple-select-agents').on('select2:unselect', function(event) {
        var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
        $(selectItem).remove();
    });

    $('.multiple-select-agents').on('select2:select', function(event) {
        var selectItem = '.select2-selection__choice[title="' + salesAgent +'"] > .select2-selection__choice__remove';
        $(selectItem).remove();
    });

    $('.custom-popover').popover({
        trigger: 'focus'
    });

    var dateToday = new Date();
    dateToday.setMinutes(dateToday.getMinutes() - 15);
    $('#datetimepicker3').datetimepicker({
        controlType: 'select',
        oneLine: true,
        timeFormat: 'HH:mm',
        minDate: dateToday
    });

    $('.input-field').change(function() {
        if ($(this).data('iconid'))
            var icon = $('#' + $(this).data('iconid'));
        else
            var icon = $(this).closest('.form-group').find('.form-icon-added');

        if (icon.length > 0) {
            if($.trim($(this).val())) $(icon).show();
            else $(icon).hide();
        }

        if ($(this).attr('id') == "subject") {
            if ($(this).val() == "ONSITE MEETING")
                $('#location').closest('.form-group').show();
            else
                $('#location').closest('.form-group').hide();
        }
    });

    $('#createNextStep').submit(function(e) {
        e.preventDefault();
        if(!$(this).valid()) return;
        var form = $(this);
        var form_data = new FormData(form[0]);
        var url = form.attr('action');
        swal.fire({
            title: "Are you sure?",
            text: "You are about to create a next step.",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Create"
        }).then(willCreate => {
            if (willCreate.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.ajax({
                        type: "POST",
                        url: url,
                        data: form_data,
                        processData: false,
                        contentType: false
                    }).then(function(data) {
                        form.trigger("reset");
                        $.LoadingOverlay('hide');
                        swal.fire(
                            "Success",
                            "Successfully created a next step.",
                            "success"
                        );
                        renderWidget();
                    });
                });
            } else {
                swal.fire("Cancelled", "Next step was not created!", "error");
            }
        });
    });

    $('#createNextStep').on('reset', function() {
        $(this).find('.hide-on-reset').hide();
    });

    $(".custom-file").on("change", function() {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index).toLowerCase();
            if (fileSize > 1502500) {
                swal.fire({
                    title: "File size too large!",
                    text: "Attachment size cannot exceed 1.5MB",
                    icon: "warning"
                })

                $(this).val("");
            }

            if ($(this).val() != "") {
                var fileName = $(this).val().split("\\").pop();
            }
        }
    });

    $.validator.setDefaults({
        errorPlacement: function(error, element) {
            if (element.hasClass("form-control")) {
                error.insertAfter(element.parent());
            }
        }
    });

    $.validator.addMethod("minDate", function (value, element) {
                    var minDate = new Date();
                    minDate.setMinutes(minDate.getMinutes() - 20);
                    var valueEntered = Date.parse(value);
                    if (valueEntered < minDate) return false;
                    return true;
                },
                "The date can not be set to a past value"
    );

    $.validator.addMethod("validDate", function (value, element) {
                    var valueEntered = Date.parse(value);
                    if (valueEntered == null || isNaN(valueEntered)) return false;
                    return true;
                },
                "Invalid date format"
    );

    $('#createNextStep').validate({
        rules: {
            subject: {
                required: true
            },
            date: {
                required: true,
                validDate: true,
                minDate: true
            }
        }
    });

    $(document).on('click', '#add-note-button', function(e) {
        e.preventDefault();
        var btn = $(this);
        var activity_reference_id = btn.data('activityref');
        var agent_reference_id = btn.data('agentref');
        var find = btn.parent().find('#append-note');
        var url = "/createNewEventNote";
        swal.fire({
                title: 'Submit a note:',
                input: 'textarea',
                inputAttributes: {
                    autocapitalize: 'off',
                    'aria-label': 'Type your message here'
                },
                inputPlaceholder: 'Type your message here...',
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: 'Add Note'
        }).then(note => {
            if (note.value) {
                note.value = note.value.replace(/<[^>]*>/g, '');
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post(url, {
                        activity_reference_id: activity_reference_id,
                        agent_reference_id: agent_reference_id,
                        note: note.value
                    }, function(data) {
                        $.LoadingOverlay('hide');
                        find.prepend(
                                `<span style="font-size: 14px;">${note.value}</span>
                                <br>
                                <span style="font-size: 10px; color: dodgerblue;">${data.agent_name} - ${data.date}</span>
                                <br><br>`
                            );
                        swal.fire(
                            "Success",
                            "Note has been successfully created.",
                            "success"
                        )
                    });
                });
            } else {
                swal.fire("Cancelled", "Note was not created!", "error");
            }
        });
    });

    $(document).on('click', '#mark-completed', function(e) {
        e.preventDefault();
        var btn = $(this);
        var id = btn.data('id');
        var url = "/setTaskComplete";
        swal.fire({
            title: "Are you sure?",
            text: "You are about to set this task as complete",
            icon: "warning",
            showCancelButton: true,
            showCloseButton: true,
            confirmButtonText: "Set Complete"
        }).then(completed => {
            if (completed.value) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post(url, {
                        id: id
                    }, function(data) {
                        $.LoadingOverlay('hide');
                        btn.hide();
                        var event = $('#event-' + id);
                        var group = $('#' + data.group);
                        setTaskComplete(event);
                        event.detach().prependTo(group.find('.events'));
                        group.parent().find('.btn-activity').show();
                        swal.fire(
                            "Success",
                            "Task has been successfully set to complete.",
                            "success"
                        )
                    });
                });
            } else {
                swal.fire("Cancelled", "Task was not set to complete!", "error");
            }
        });
    });

    $(window).keydown(function(event){
        if(event.keyCode == 13) {
            event.preventDefault();
            return false;
        }
    });

    function setTaskComplete(event) {
        var target = event.find('#custom-icon-color');
        target.css('color', '#228b22');
        target.removeClass();
        target.addClass('fas fa-tasks');
        event.find('#custom-bg-color').css('background-color', '#228b22')
    }

    $(document).on('click', '.expand-all', function(e) {
        e.preventDefault();
        $('.collapse').each(function() {
            if ($(this).data('role') == 'group') $(this).addClass('show');
        });
        $('.btn-activity').removeClass('collapsed');
        $('.btn-activity').attr('aria-expanded', true);
    });

    $(document).on('click', '.view-all', function(e) {
        e.preventDefault();
        $('.collapse').addClass('show');
        $('.btn-activity').removeClass('collapsed');
        $('.btn-activity').attr('aria-expanded', true);
        $('.inner-collapse').removeClass('collapsed');
        $('.inner-collapse').attr('aria-expanded', true);
    });

    $(document).on('click', '.hide-all', function(e) {
        e.preventDefault();
        $('.collapse').removeClass('show');
        $('.btn-activity').addClass('collapsed');
        $('.btn-activity').attr('aria-expanded', false);
        $('.inner-collapse').addClass('collapsed');
        $('.inner-collapse').attr('aria-expanded', false);
    });

});
</script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\widgets\eventWidget.blade.php ENDPATH**/ ?>