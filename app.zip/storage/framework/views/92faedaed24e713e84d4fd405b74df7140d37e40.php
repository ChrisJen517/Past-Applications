<?php $__env->startSection('route'); ?>
<?php echo e(route('exportMSA')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('companyInformation'); ?>
    <?php echo $__env->make('Includes.forms.companyInformation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('extra'); ?>
    <?php echo $__env->make('Includes.forms.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('name'); ?>
Standard FCRA MSA Contract
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.baseContract', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\MSA.blade.php ENDPATH**/ ?>