<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="modal fade" id="editProductHeader" tabindex="-1" role="dialog" aria-labelledby="editLabel">
    <div class="modal-dialog modal-lg-10" role="document">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="editLabel">Edit Product Header</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="editProductHeaderForm">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control" id="edit_id" name="id" value="<?php echo e(old('id')); ?>" required hidden>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Header Name</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_name" name="name" style="width: 100%;" required value="<?php echo e(old('name')); ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;" data-toggle="tooltip" title="This field must be changed by a developer.">Description</label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="edit_description" name="description" rows="5" cols="20" value="<?php echo e(old('description')); ?>" readonly></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Product Name Label</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_column_1" name="column_1" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Description Label</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_column_2" name="column_2" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Pricing Label</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="edit_column_3" name="column_3" required>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-4">Display to Agents
                        <input class="form-check-input" name="show_in_list" id="show_in_list" value="1" type="checkbox" style="margin-left: 5px;">
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="submit" class="btn btn-primary float-right" value="Submit">
                </div>
            </form>
        </div>
    </div>
</div>

<script src=<?php echo e(asset('js/validation/addProductHeader.js')); ?>></script>

<script>
$(document).ready(function() {

    $('[data-toggle="tooltip"]').tooltip();

    $('#editProductHeader').on('show.bs.modal', function(e) {
            $(this).find('#edit_id').val($(e.relatedTarget).data('id'));
            $(this).find('#edit_name').val($(e.relatedTarget).data('name'));
            $(this).find('#edit_description').val($(e.relatedTarget).data('description'));
            $(this).find('#edit_column_1').val($(e.relatedTarget).data('column_1'));
            $(this).find('#edit_column_2').val($(e.relatedTarget).data('column_2'));
            $(this).find('#edit_column_3').val($(e.relatedTarget).data('column_3'));
            if($(e.relatedTarget).data('check') == 1)
            {
                $('#show_in_list').attr('checked', true);
            }
            else
            {
                $('#show_in_list').attr('checked', false);
            }

            $('#editProductHeaderForm').attr('action', '/manageProductHeaders/edit/' + $(e.relatedTarget).data('id'));
        });
    });
</script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\editProductHeader.blade.php ENDPATH**/ ?>