<?php $__env->startSection('content'); ?>
<link href="<?php echo e(asset('css/board.css')); ?>" rel="stylesheet" />
<?php $headers = array('Unworked', 'In Progress', 'Lead Complete', 'Lead Followup');?>
<div class="row">
    <a onclick="reorderCards()" class="btn btn-primary ml-auto" style="color: white; margin-bottom: 10px; margin-right: 50px;">Save Leads</a>
</div>
<div class="container-fluid" id="mainBody" style="display: flex;
  flex-wrap: nowrap;
  height:80%;
  overflow-x: auto;
  overflow-y: auto;">
    <!-- Start the four cards board-->
    <?php for($i = 0; $i < 4; $i++): ?>
        <div class="col-lg-3" >
            <div class="card big">
                <?php $first = "first"?>
                <div class="card-header">
                    <?php echo e($headers[$i]); ?>

                </div>
                <div class="card-body connectedSortable main-body" id="<?php echo e($i); ?>Card" data-column="<?php echo e($i); ?>">
                    <?php $__currentLoopData = $agentCards[$i]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div id="id<?php echo e($card->id); ?>" class="card product" style="display: flex;" onmousedown="setInfo('<?php echo e($card->company_name); ?>', '<?php echo e($card->id); ?>')" data-id="<?php echo e($card->id); ?>" data-position="<?php echo e($card->column_position); ?>">
                            <div class="card-body" style="display: flex;">
                                <?php echo e($card->company_name); ?>

                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <textarea class="new-company-input" id="<?php echo e($i); ?>Text" cols="30" rows="2" placeholder="Add a new lead..." onkeydown="addCard('<?php echo e($i); ?>Card', '<?php echo e($i); ?>Text')"></textarea>
            </div>
        </div>
    <?php endfor; ?>
</div>

<!-- Start update lead modal-->
<div class="modal fade " id="cardInfo" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" >
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content border-0">
            <div class="modal-header bg-info">
                <h5 class="modal-title text-white" id="myModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body" id="showLeadDiv" style="min-height:20px; max-height:calc(100vh - 200px); overflow-y: auto;">
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/modal.js?'.time())); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

<script>
    var updated = false;

    $(window).bind('beforeunload', function() {
        if (updated) {
            return 'Are you sure you want to leave?';
        }
    });

    $(document).ready(function() {

        $('.new-company-input').focus(function() {
            $(this).attr('placeholder', 'Company Name');
        });

        $('.new-company-input').focusout(function() {
            $(this).attr('placeholder', 'Add a new lead...');
        });

        var fixHelper = function(e, ui) {
            ui.children().each(function() {
                $(this).width($(this).width());
            });
            return ui;
        };

        var start = function(e, ui) {
            ui.item.css({
            //    'border': '2px solid black',
            //    'background-color': '#f4f4f4',
                'opacity': 1.0
            });
        }

        var stop = function(e, ui) {
            ui.item.css({
            //    'border': '2px dashed #blue',
                'background-color': '',
                'opacity': ''
            });
        }

        $("div.connectedSortable").sortable({
            connectWith: ".connectedSortable",
            revert: true,
            helper: fixHelper,
            start: start,
            stop: stop,
            placeholder: "my-ui-placeholder",
            cursor: "move",
            update: function(event, ui) {
                for (var i = 0; i < event.target.children.length; i++) {
                    $(event.target.children[i]).data('position', i+1);
                }
                updated = true;
            }
        });
    });


    var cardTitle = null;
    var cardId = null;
    function setInfo(title, id){
        cardTitle = title;
        cardId = id;
    }

    var held;
    $("#mainBody").on('mousedown', 'div.product', function() {
        held = false;
        setTimeout(function() {
            held =  true;
        }, 500);
    }).on('mouseup',function(){
        if((!held) && (cardTitle != null)){
            $('#cardInfo').modal('show');
            $('#myModalLabel').html(cardTitle);

            var url = "<?php echo e(asset('/workLead/modal/:id')); ?>"
            url = url.replace(':id', cardId);

            $('#showLeadDiv').LoadingOverlay("show");

            $('#showLeadDiv').load(url, function(){
                $('#showLeadDiv').LoadingOverlay("hide", true);
            });
        }
    });

    function addCard(location, text) {
        if(event.keyCode == 13){
            event.preventDefault();

            var company_name = document.getElementById(text).value;
            var user_id = <?php echo e(Auth::user()-> id); ?>;

            swal.fire({
                title: "Are you sure?",
                text: "You are about to create a sales lead for the company " + company_name + ".",
                icon: "warning",
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: 'Create'
            }).then((willSave) => {
                if (willSave.value) {
                    $.LoadingOverlay("show");
                    $(function() {
                        "use strict";
                        $.post("/createSalesLead", {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                                company_name: company_name,
                                user_id: user_id
                            })
                            .done(function(data) {
                                updated = false;
                                $.LoadingOverlay("hide");
                                $("#"+location).append(
                                    '<div class="card product" style="display: flex;" onmousedown="setInfo(' + "'" + company_name + "', '" + data['lead_id'] + "'" + ')" data-id="' + data['lead_id'] + '" data-position="' + data['column_position'] + '">' +
                                        '<div class="card-body" style="display: flex;">' +
                                            company_name +
                                        '</div>' +
                                    '</div>'
                                );
                                swal.fire(
                                    "Success",
                                    "Lead has been created.",
                                    "success"
                                );
                            });
                    });
                } else {
                    swal.fire(
                        "Cancelled",
                        "Lead was not created!",
                        "error"
                    );
                }
            document.getElementById(text).value = "";
            });
        }
    }

    function reorderCards() {
            var ids = [];
            var orders = [];
            var columns = [];
            $("div.connectedSortable").each(function(){
                var column_id = $(this).data('column');
                $(this).find('.product').each(function(){
                    ids.push($(this).data('id'));
                    orders.push($(this).data('position'));
                    columns.push(column_id);
                });
            });

            swal.fire({
                title: "Are you sure?",
                text: "You are about to reorder the cards.",
                icon: "warning",
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: 'Save'
            }).then((willSave) => {
                if (willSave.value) {
                    $.LoadingOverlay("show");
                    $(function() {
                        "use strict";
                        $.post("/testBoard/save", {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                                ids: ids,
                                orders: orders,
                                columns: columns
                            })
                            .done(function(data) {
                                updated = false;
                                $.LoadingOverlay("hide");
                                swal.fire(
                                    "Success",
                                    "Card order has been saved.",
                                    "success"
                                );
                            });
                    });
                } else {
                    swal.fire(
                        "Cancelled",
                        "Card order was not saved!",
                        "error"
                    );
                }
            });
        }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\testBoard.blade.php ENDPATH**/ ?>