<!--catches the validation errors-->
<?php if(count($errors) > 0): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert alert-danger">
            <?php echo e($error); ?>

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<?php if(isset($success)): ?>
<div class="alert alert-success message">
            <?php echo e($success); ?>

        </div>
<?php endif; ?>

<!--catches the success messages-->
<?php if(session('success')): ?>
        <div class="alert alert-success message">
            <?php echo e(session('success')); ?>

        </div>
<?php endif; ?>

<!--catches the errors we create-->
<?php if(session('error')): ?>
    <div class="alert alert-danger message">
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>

<!--catches the messages-->
<?php if(session()->has('message')): ?>
    <div class="alert alert-success message">
        <?php echo e(session()->get('message')); ?>

    </div>
<?php endif; ?>

<?php if(session('information')): ?>
<script>
  $(document).ready(function() {
    $.toast({
        heading: 'Information',
        text: "<?php echo e(session('information')); ?>",
        showHideTransition: 'slide',
        icon: 'info',
        hideAfter: 30000,
        position: 'bottom-right'
    })
  });
</script>
<?php endif; ?>

<?php if(session('successToast')): ?>
<script>
  $(document).ready(function() {
    $.toast({
        heading: 'Success',
        text: "<?php echo e(session('successToast')); ?>",
        showHideTransition: 'slide',
        icon: 'success',
        hideAfter: 30000,
        position: 'bottom-right'
    })
  });
</script>
<?php endif; ?>

<?php if(session('errorToast')): ?>
<script>
  $(document).ready(function() {
    $.toast({
        heading: 'Error',
        text: "<?php echo e(session('errorToast')); ?>",
        showHideTransition: 'slide',
        icon: 'error',
        hideAfter: 30000,
        position: 'bottom-right'
    })
  });
</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\messages.blade.php ENDPATH**/ ?>