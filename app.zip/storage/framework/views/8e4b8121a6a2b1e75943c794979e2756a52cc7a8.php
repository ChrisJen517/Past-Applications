<?php $__env->startSection('content'); ?>
<br>

<section id="product-history-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <p class="float-left">Product History:</p>
            </div>
        </div>
    </div>
</section>

<div class="row">
    <div style="width: 100%;">
        <a href="<?php echo e(route('manageProductSheet')); ?>" class="btn btn-secondary float-right" style="margin: 0px 30px 15px 30px;">Back</a>
    </div>
</div>

<section id="product-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="product-history-div">
                <div id="parent1" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="product-history-table">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 5%;">ID</th>
                                <th class="text-center" style="width: 10%;">Product ID</th>
                                <th class="text-center" style="width: 15%;">Product Name</th>
                                <th class="text-center" style="width: 10%;">Date</th>
                                <th class="text-center" style="width: 10%;">User</th>
                                <th class="text-center" style="width: 50%;">Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($product->id); ?></td>
                                <td><?php echo e($product->product_id); ?></td>
                                <td><?php echo e($product->product_Name); ?></td>
                                <td><?php echo e($product->created_at); ?></td>
                                <td><?php echo e($product->user); ?></td>
                                <td><?php echo e($product->description); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>

<section id="product-header-history-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <p class="float-left">Product Header History:</p>
            </div>
        </div>
    </div>
</section>

<section id="header-history">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="header-history-div">
                <div id="parent2" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="header-history-table">
                        <thead>
                            <tr>
                                <th class="text-center" style="width: 5%;">ID</th>
                                <th class="text-center" style="width: 10%;">Header ID</th>
                                <th class="text-center" style="width: 15%;">Header Name</th>
                                <th class="text-center" style="width: 10%;">Date</th>
                                <th class="text-center" style="width: 10%;">User</th>
                                <th class="text-center" style="width: 50%;">Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $product_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $header): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($header->id); ?></td>
                                <td><?php echo e($header->header_id); ?></td>
                                <td><?php echo e($header->header_name); ?></td>
                                <td><?php echo e($header->created_at); ?></td>
                                <td><?php echo e($header->user); ?></td>
                                <td><?php echo e($header->description); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader2" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
$(document).ready(function() {
    $('#product-history-table').DataTable({
        "order": [
            [0, "desc"],
        ],
        columns: [
            null,
            null,
            null,
            null,
            null,
            {
                "render": function(data, type, row) {
                    return data.split("||").join("<br/>");
                }
            }
        ],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#parent1').removeClass('table-parent-hidden');
        }
    });

    $('#header-history-table').DataTable({
        "order": [
            [0, "desc"],
        ],
        columns: [
            null,
            null,
            null,
            null,
            null,
            {
                "render": function(data, type, row) {
                    return data.split("||").join("<br/>");
                }
            }
        ],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader2').delay(25).fadeOut();
            $('#parent2').removeClass('table-parent-hidden');
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\productHistory.blade.php ENDPATH**/ ?>