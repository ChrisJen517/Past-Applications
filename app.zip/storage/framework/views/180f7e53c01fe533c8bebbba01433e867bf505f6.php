<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('all.sales_leads.workLeadForm', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\sales_leads\workLeadFormPage.blade.php ENDPATH**/ ?>