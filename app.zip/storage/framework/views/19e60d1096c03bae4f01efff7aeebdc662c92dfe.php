<?php $__env->startSection('content'); ?>
<br>

<section id="lead-statistics-header">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-8">
                <p class="float-left">Manager Lead Statistics:</p>
            </div>
        </div>
    </div>
</section>

<section id="lead-statistics">
    <div class="container-fluid">
        <div class="row">
            <div class="table-responsive" id="lead-statistics-div">
                <div id="parent1" class="table-parent-hidden">
                    <table class="table table-striped table-bordered" id="lead-statistics-table">
                        <thead>
                            <tr>
                                <th class="text-center">Agent ID</th>
                                <th class="text-center">Agent Name</th>
                                <?php $__currentLoopData = $statuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th class="text-center"><?php echo e($status); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($lead->agent_id); ?></td>
                                <td class="text-center"><?php echo e($lead->agent_name); ?></td>
                                <?php for($i=0; $i<count($statuses); $i++): ?>
                                    <?php ($column_name = 'column' . $i); ?>

                                    <?php if($lead->$column_name > 5): ?> <?php ($color = '#CE321F'); ?>
                                    <?php elseif($lead->$column_name > 3): ?> <?php ($color = '#CD7D09'); ?>
                                    <?php elseif($lead->$column_name == 0): ?> <?php ($color = '#000000'); ?>
                                    <?php else: ?> <?php ($color = '#29AE12'); ?>
                                    <?php endif; ?>

                                    <td class="text-center" style="font-size: 20px; color: <?php echo e($color); ?>;">
                                        <?php echo e($lead->$column_name == 0 ? '-' : $lead->$column_name); ?>

                                    </th>
                                <?php endfor; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
                <div class="loader my-5 ml-5" id="loader1" style="display:show">
                </div>
            </div>
        </div>
    </div>
</section>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>

<script>
$(document).ready(function() {

    $('#lead-statistics-table').DataTable({
        "order": [
            <?php for($i=0; $i<count($statuses); $i++): ?>
            [<?php echo e(2 + $i); ?>, "desc"],
            <?php endfor; ?>
        ],
        dom: 'Bfrtip',
        "pageLength": 10,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#loader1').delay(25).fadeOut();
            $('#parent1').removeClass('table-parent-hidden');
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\salesLeadStats.blade.php ENDPATH**/ ?>