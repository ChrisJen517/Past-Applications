<link href="<?php echo e(asset('plugins/bootstrap-datatable/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
    type="text/css">
<link href="<?php echo e(asset('plugins/bootstrap-datatable/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet" type="text/css">
<link href="<?php echo e(asset('plugins\bootstrap-datatable\css\rowReorder.dataTables.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.4.2/css/all.css"
    integrity="sha384-/rXc/GQVaYpyDdyxK+ecHPVYJSN9bmVFBvjA/9eOB+pb3F2w2N6fc5qB9Ew5yIns" crossorigin="anonymous">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <meta name="description" content="" />
    <meta name="author" content="" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <meta name="google" content="notranslate">
    <title>Contract Portal 2.0</title>

    <!-- Bootstrap core CSS-->
    <link href="<?php echo e(asset('css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="<?php echo e(asset('css/datatable.css?'.time())); ?>" rel="stylesheet" />
    <!-- Icons CSS-->
    <link href="<?php echo e(asset('css/icons.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Sidebar CSS-->
    <link href="<?php echo e(asset('css/sidebar-menu.css')); ?>" rel="stylesheet" />
    <!-- Custom Style-->
    <link href="<?php echo e(asset('css/sidebar-top.css?'.time())); ?>" rel="stylesheet" />
    <!-- simplebar CSS-->
    <link href="<?php echo e(asset('plugins/simplebar/css/simplebar.css')); ?>" rel="stylesheet" />
    <!--multi select-->
    <link href="<?php echo e(asset('plugins/jquery-multi-select/multi-select.css')); ?>" rel="stylesheet" type="text/css" />

    <!-- Styling CSS-->
    <link href="<?php echo e(asset('/css/style-test.css')); ?>" rel="stylesheet" />

    <!-- SWAL Modals CSS -->
    <link href="<?php echo e(asset('/css/modal.css?'.time())); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/css/table-fixed.css')); ?>" rel="stylesheet" />

    <!-- Toast Notifications CSS-->
    <link href="<?php echo e(asset('/css/jquery.toast.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('/css/toast.css')); ?>" rel="stylesheet" />

    <link href="<?php echo e(asset('plugins/jquery-datatables-checkboxes/css/dataTables.checkboxes.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    

    
</head>

<body <?php if((file_exists(public_path('/BackgroundPictures'.'/'.Auth::user()->id.'/background.png'))) && Route::current()->
    getName() == "leadBoard"): ?>
    style="background-image: url(<?php echo e(asset('/BackgroundPictures'.'/'.Auth::user()->id.'/background.png')); ?>);"
    <?php elseif(Auth::user()->background_color != null && Route::current()->getName() == "leadBoard"): ?>
    style="background-color: <?php echo e(Auth::user()->background_color); ?>;"
    <?php endif; ?>>
    <!-- Start wrapper-->
    <div id="wrapper">
        <!-- Sidebar and Topbar -->
        <?php echo $__env->make('Includes.topBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php if(Auth::user()): ?>
        <?php if(Auth::user()->role=='manager'): ?>
        <?php echo $__env->make('Includes.manager.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
        <?php echo $__env->make('Includes.agent.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <?php endif; ?>

        <!-- Main Content -->
        <div class="content-wrapper">
            <div class="container-fluid">
                <?php echo $__env->make('Includes.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <br>
            </div>
        </div>
    </div>
    <script>
        $(document).ready(function() {
    var channel = window.Echo.private(`user.` + <?php echo e(Auth::user()->id); ?>);
    channel.listen('ContractUpdated', function (data) {
        var message = data.message;
        $.toast({
          heading: data.heading,
          text: message,
          showHideTransition: 'slide',
          icon: data.icon,
          hideAfter: 30000,
          position: 'bottom-right'
        });
        $('#origin').attr('href', window.location.origin + $('#origin').data('href'));
    });

  });
    </script>
</body>

<script src="<?php echo e(asset('js/app.js' )); ?>"></script>
<script src="<?php echo e(asset('js/jquery.toast.min.js' )); ?>"></script>
<script src="<?php echo e(asset('js/collapse.js?'.time())); ?>"></script>
<script src="<?php echo e(asset('js/app-script.js')); ?>"></script>
<script src="<?php echo e(asset('js/jquery-ui.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/dataTables.buttons.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/buttons.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/jszip.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/pdfmake.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/vfs_fonts.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/buttons.html5.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/buttons.print.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/buttons.colVis.min.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/jquery-multi-select/jquery.multi-select.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/jquery-multi-select/jquery.quicksearch.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/jquery-validation/js/jquery.validate.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.9.0/jquery.validate.js"></script>
<script src="<?php echo e(asset('plugins/bootstrap-datatable/js/dataTables.rowReorder.min.js')); ?>"></script>

<script src="<?php echo e(asset('plugins/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/jquery-datatables-checkboxes/js/dataTables.checkboxes.min.js')); ?>"></script>

<script src="https://cdn.jsdelivr.net/jquery.validation/1.16.0/additional-methods.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-ui-timepicker-addon/1.6.3/jquery-ui-timepicker-addon.min.js">
</script>




<script>
    $(document).ready(function() {

    $.fn.dataTable.ext.errMode = 'none';
    $(document).ajaxError(function(event, jqxhr, settings, thrownError) {
        if (jqxhr.status == 403 && jqxhr.responseJSON.message == 'Session expired') {
            swal.fire("Cancelled", "Your session has expired, you will be redirected to the login page!", "error");
            setTimeout(() => window.location = '/login', 2500);
        } else {
            console.log(`ERROR [${jqxhr.status}]: ${thrownError}`);
        }
    });

    $('.dropdown-menu').on("click.bs.dropdown", function (e) {
        e.stopPropagation();
    });

    var width = $(window).width();
    var sidebarWrapper = $("#sidebar-wrapper-icons");
    var sidebarMenu = $(".sidebar-menu");
    var contentWrapper = $(".content-wrapper");
    var currentlyShowing = sidebarMenu.css("display") != "none";

    if (width < 768) {
        $('#wrapper').toggleClass('toggled');
        $('#wrapper').toggleClass('toggled-icons');
        sidebarWrapper.css({
          "background-color": "transparent",
            "box-shadow": "none"
        });
        sidebarMenu.hide();
        contentWrapper.css("padding-left", "0px");
    }

    $(window).on('resize', function() {
        if ($(this).width() != width) {
            if ($(this).width() < 768) {
              sidebarWrapper.css("background-color", "transparent");
                sidebarWrapper.css("box-shadow", "none");
                $('#wrapper').toggleClass('toggled', true);
                $('#wrapper').toggleClass('toggled-icons', true);
            } else {
                sidebarWrapper.css("background-color", "#ffffff");
                sidebarWrapper.css(
                    "box-shadow",
                    "0 2px 6px 0 rgba(218, 218, 253, 0.65), 0 2px 6px 0 rgba(206, 206, 238, 0.54);"
                );
                sidebarMenu.show();
                contentWrapper.css("padding-left", "50px");
            }
        }
    });
  });
</script>
<!--Session Timeout Script-->

<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\basicLayout.blade.php ENDPATH**/ ?>