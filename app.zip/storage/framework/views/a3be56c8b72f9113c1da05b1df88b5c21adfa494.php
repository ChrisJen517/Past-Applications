<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="modal fade" id="sendEmailFormModal" tabindex="-1" role="dialog" aria-labelledby="createLabel">
    <div class="modal-dialog modal-lg" role="audit">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="createLabel">Contact Client</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form action="<?php echo e(route('sendEmailForm')); ?>" method="POST" enctype="multipart/form-data" id="sendEmailForm">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control" id="client_modal_id" name="id" value="<?php echo e(old('id')); ?>" required hidden>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client Email<span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <select class="form-control" name="client_email" type="text" value="<?php echo e(old('client_email')); ?>" style="text-transform: capitalize" required>
                                <option id="select_company_email" value="" style="text-transform: capitalize"></option>
                                <option id="select_payable_email" value="" style="text-transform: capitalize"></option>
                                <option id="select_approver_email" value="" style="text-transform: capitalize"></option>
                                <option id="select_contact_email" value="" style="text-transform: capitalize"></option>
                            </select>  
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Subject<span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="subject" name="subject" style="width: 100%;" value="<?php echo e(old('subject')); ?>"  maxlength="150">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Content<span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="body" name="body" value="<?php echo e(old('body')); ?>"rows="5" cols="20" maxlength="1000"></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">File</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="file" name="file[]" type="file">
                            <label class="custom-file-label" for="file[0]" style="margin: 0px 15px 0px 15px;">Choose file...</label>
                        </div>
                    </div>
                    <span id="files"></span>
                    <div class="form-group row">
                        <div class="offset-lg-3 col-lg-9">
                            <button class="btn btn-primary" id="addAnotherFile" type="button" >Add Another File</button>
                            <button class="btn btn-danger" id="removeFile" type="button"  hidden>Remove File</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <span style="float:left;"> <span style="color: red;">* </span> Denotes required field. </span>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <input type="submit" id="submit" class="btn btn-primary float-right" value="Send Email">
                </div>
            </form>
        </div>
    </div>
</div>


<link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">
<script>
    $(document).ready(function () {
        $("#sendEmailForm").validate({
            rules: {
                client_email: "required",
                subject: "required",
                body: "required",
            },
            messages: {
                client_email: "Please select an email",
                subject: "Please enter a subject",
                body: "Please enter a body for the email",
            }
        });

        $('#sendEmailFormModal').on('hide.bs.modal', function(e) {
            var validator = $( "#sendEmailForm" ).validate();
            validator.resetForm();
        });
    });

    $('#sendEmailFormModal').on('show.bs.modal', function(e) {
        $(this).find('#client_modal_id').val($(e.relatedTarget).data('id'));
        
        emails = ['company', 'payable', 'approver', 'contact'];
        for(i = 0; i < 4; i++){
            email = $(e.relatedTarget).data(emails[i]+'_email');
            console.log(emails[i]+': '+email)
            if(email){
                document.getElementById('select_'+emails[i]+'_email').hidden = false;
                $(this).find('#select_'+emails[i]+'_email').val(email);
                document.getElementById('select_'+emails[i]+'_email').innerHTML = emails[i]+' email: '+ email;
            }
            else{
                document.getElementById('select_'+emails[i]+'_email').hidden = true;
            }
        }
    });

    $('[data-toggle="tooltip"]').tooltip();

    $("#addAnotherFile").on("click", function(){
        $("#files").append('<div class="form-group row">' + 
                    '<label class="col-lg-3 col-form-label form-control-label">File</label>' + 
                        '<div class="col-lg-9">' + 
                            '<input autocomplete="off" class="form-control auto-complete-off custom-file-input" onchange="updateName(this)" id="file" name="file[]" type="file">' + 
                            '<label class="custom-file-label" for="file[]" style="margin: 0px 15px 0px 15px;">Choose file...</label>' +
                        '</div>' +
                    '</div>');
        $("#removeFile").attr("hidden", false);
    });

    $("#removeFile").on("click", function(){
        var list = document.getElementById("files");
        var count = list.childElementCount - 1;
        list.removeChild(list.childNodes[count]);
        if(count == 0)
            document.getElementById("removeFile").hidden = true;
    });

    $("#sendEmailForm").on( "submit",function(e){
        var totalSize = 0;
        $("input[name='file[]'").each(function() {
            if(this.files[0])
                totalSize += this.files[0].size/1024/1024;
        });
        if(totalSize > 55.0){
            e.preventDefault();
            swal.fire("Too large", "The files you uploaded were too large! Please don't exceed 55MB or 55,00KB in a single upload.", "error");
            return;
        }
        if($(this).valid())
            $.LoadingOverlay("show");
    });

    function updateName(element) {
        if ($(element).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(element).get(0).files[0].name;

            if ($(element).val() != "") {
                var fileName = $(element).val().split("\\").pop();
                $(element).siblings(".custom-file-label").addClass("selected").html(fileName);
            }
        }
    }

</script><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\manageClients\sendCompanyEmail.blade.php ENDPATH**/ ?>