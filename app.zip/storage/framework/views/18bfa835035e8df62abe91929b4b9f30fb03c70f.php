<?php $__env->startSection('content'); ?>

<?php if(Auth::user()->role == 'manager'): ?>
<?php echo $__env->make('Includes.modal.editDocumentModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<div class="container-fluid py-3">
    <div class="row">
        <div class="mx-auto col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4 class="mb-0">Document Information</h4>
                </div>
                <div class="card-body">
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document ID</label>
                        <div class="col-lg-9">
                            <input class="form-control" name="id" type="text" value="<?php echo e($document->id); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Name</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="document_name" type="text" value="<?php echo e($document->document_name); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Description</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="document_name" type="text" value="<?php echo e($document->description); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Created At</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="created_at" type="text" value="<?php echo e($document->created_at); ?>" readonly>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Updated At</label>
                        <div class="col-lg-9">
                        <input class="form-control" name="updated_at" type="text" value="<?php echo e($document->updated_at); ?>" readonly>
                        </div>
                    </div>
                    <a class="btn btn-secondary float-left" href="/supportDocuments">Back</a>   
                    <?php if(Auth::user()->role == 'manager'): ?>
                    <a class="btn btn-primary float-right" data-toggle="modal" data-target="#editDocument" style="color:white;"
                    data-id="<?php echo e($document->id); ?>" data-name="<?php echo e($document->document_name); ?>" data-description="<?php echo e($document->description); ?>">
                       Edit
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<section id="history">
    <div class="container-fluid">
        <div class="row">
        <h3>Document History</h3>
        </div>
        <div class="row">
            <div class="table-responsive" id="history-div" hidden>
                <table class="table table-striped table-bordered" id="history-table">
                    <thead>
                        <tr>
                            <th class="text-center">Update Time</th>
                            <th class="text-center">Description</th>
                            <th class="text-center">Updated File</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $contractName = $item->file_name;
                        ?>
                        <tr class="item<?php echo e($item->id); ?>">
                            <td><?php echo e($item->created_at); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('download', $contractName)); ?>" download>
                                    <div style="height:100%;width:100%">
                                        Download File
                                    </div>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<script>
$(document).ready(function() {
    $('#history-table').DataTable({
        "order":[[0,"desc"]],
        dom: 'Bfrtip',
        "pageLength": 5,
        buttons: [
            'excelHtml5',
            'pdfHtml5'
        ],
        initComplete: function() {
            $('#history-div').attr('hidden', false);
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\manageDocument.blade.php ENDPATH**/ ?>