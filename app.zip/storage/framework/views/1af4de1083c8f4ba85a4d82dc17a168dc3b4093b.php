<?php $__env->startSection('content'); ?>
<?php if($contract->approval_needed == 1): ?>
<div class="col-md-8 mx-auto">
    <br>
    <div class="card">
        <div class="card-header">
            A Contract Needs Your Approval
        </div>
        <div class="container">
            <div class="col-md-12 mx-auto">
                <form action="<?php echo e(route('approveLegalContract')); ?>" method="POST" enctype="multipart/form-data" id="user_information_form">
                    <?php echo e(csrf_field()); ?>

                    <br>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Agent Name:</label>
                        <div class="col-lg-9">
                            <a name="name"><?php echo e($agent->name_first); ?> <?php echo e($agent->name_last); ?></a>
                            <input name="id" value="<?php echo e($agent->id); ?>" hidden>
                            <input name="contractId" value="<?php echo e($contract->id); ?>" hidden>
                        </div>
                    </div>
                    <hr>
                   <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Contract:</label>
                        <div class="col-lg-9">
                            Company Name: <a name="company"><?php echo e($contract->company_name); ?></a>
                            <br>
                            Contract Type: <a name="contract_type"><?php echo e($contract->contract_type); ?></a>
                            <br>
                            Contract Name: <a name="contract_name"><?php echo e($contract->contract_name); ?></a>
                        </div>
                    </div>
                    <?php if($contract->contract_type == 'REDLINE'): ?>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Upload File:</label>
                            <div class="col-lg-9">
                                <input type="file" accept=".docx, .pdf"  name="uploadFile" id="uploadFile">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-3 col-form-label form-control-label">Comment:</label>
                            <div class="col-lg-9">
                                <textarea class="form-control" name="comment" type="text" placeholder="Reason is required to request changes"></textarea>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="form-group row">
                        <?php if($contract->contract_type == 'REDLINE'): ?>
                            <button class="btn btn-lg btn-danger float-middle" type="submit" name="submit" value="changes_requested" style="margin-right:10px;">Request Changes</button>
                        <?php endif; ?>
                        <input class="btn btn-lg btn-primary float-right" type="submit" name="submit" value="Approve">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php else: ?>
Contract Has Already Been Approved. Thank You.
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('Includes.emptyBasicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\manager\approveLegalContract.blade.php ENDPATH**/ ?>