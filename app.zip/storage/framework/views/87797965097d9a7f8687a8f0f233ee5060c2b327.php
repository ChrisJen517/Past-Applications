<div class="loading-overlay">


<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <!--Client Info-->
    <form action="<?php echo e(route('addClient')); ?>" method="post" enctype="multipart/form-data"
                id="client_information_form">
                <?php echo e(csrf_field()); ?>

        <div class="row">
                <div class="col-lg-6">
                    <div class="card">
                        <div class="card-header">
                            <h2 id="previous-uploads-header" class="mb-0 text-center">Company Information</h4>
                        </div>
                        <br>
                        <div class="form-group-row">
                                    <p class="text-center" style="font-weight: bold;"><span
                                            style="color:red">&#10033;</span>Denotes Required Field</p>
                                </div>
                        <div class="card-body">
                            <input class="form-control" name="id" value="-1" type="text" hidden>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Industry <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <select class="form-control" id="industry" value="" data-industry="<?php echo e(old('industry')); ?>" name="industry"
                                    required>
                                    <option value="Collection Agency">Collection Agency</option>
                                    <option value="Law Firm">Law Firm</option>
                                    <option value="Debt Buyer">Debt Buyer</option>
                                    <option value="Originator">Originator</option>
                                    <option value="Government">Government</option>
                                    <option value="Healthcare">Healthcare</option>
                                    <option value="Reseller">Reseller</option>
                                    <option value="Other">Other</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Name <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyName" type="text"
                                    value="<?php echo e(old('companyName')); ?>" maxlength="255" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Address <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyAddress" type="text"
                                    value="<?php echo e(old('companyAddress')); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company City <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyCity"
                                    type="text" value="<?php echo e(old('companyCity')); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company State <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                            <select class="form-control" id="companyState" value="" data-state="<?php echo e(old('companyState')); ?>" name="companyState"
                                    required>
                                    <option value="AL">Alabama</option>
                                    <option value="AK">Alaska</option>
                                    <option value="AZ">Arizona</option>
                                    <option value="AR">Arkansas</option>
                                    <option value="CA">California</option>
                                    <option value="CAN">Canada</option>
                                    <option value="CO">Colorado</option>
                                    <option value="CT">Connecticut</option>
                                    <option value="DE">Delaware</option>
                                    <option value="DC">District Of Columbia</option>
                                    <option value="FL">Florida</option>
                                    <option value="GA">Georgia</option>
                                    <option value="HI">Hawaii</option>
                                    <option value="ID">Idaho</option>
                                    <option value="IL">Illinois</option>
                                    <option value="IN">Indiana</option>
                                    <option value="IA">Iowa</option>
                                    <option value="KS">Kansas</option>
                                    <option value="KY">Kentucky</option>
                                    <option value="LA">Louisiana</option>
                                    <option value="ME">Maine</option>
                                    <option value="MD">Maryland</option>
                                    <option value="MA">Massachusetts</option>
                                    <option value="MI">Michigan</option>
                                    <option value="MN">Minnesota</option>
                                    <option value="MS">Mississippi</option>
                                    <option value="MO">Missouri</option>
                                    <option value="MT">Montana</option>
                                    <option value="NE">Nebraska</option>
                                    <option value="NV">Nevada</option>
                                    <option value="NH">New Hampshire</option>
                                    <option value="NJ">New Jersey</option>
                                    <option value="NM">New Mexico</option>
                                    <option value="NY">New York</option>
                                    <option value="NC">North Carolina</option>
                                    <option value="ND">North Dakota</option>
                                    <option value="OH">Ohio</option>
                                    <option value="OK">Oklahoma</option>
                                    <option value="OR">Oregon</option>
                                    <option value="PA">Pennsylvania</option>
                                    <option value="PR">Puerto Rico</option>
                                    <option value="RI">Rhode Island</option>
                                    <option value="SC">South Carolina</option>
                                    <option value="SD">South Dakota</option>
                                    <option value="TN">Tennessee</option>
                                    <option value="TX">Texas</option>
                                    <option value="UT">Utah</option>
                                    <option value="VT">Vermont</option>
                                    <option value="VA">Virginia</option>
                                    <option value="WA">Washington</option>
                                    <option value="WV">West Virginia</option>
                                    <option value="WI">Wisconsin</option>
                                    <option value="WY">Wyoming</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Zip <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyZip" type="text" value="<?php echo e(old('companyZip')); ?>"
                                    required>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Email <span
                                    style="color:red">&#10033;</span></label>
                            <div class="col-lg-8">
                                <input class="form-control" name="companyEmail" type="email"
                                    value="<?php echo e(old('companyEmail')); ?>" required>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company EIN</label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyEIN"
                                    type="text" value="<?php echo e(old('companyEIN')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company Phone</label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyPhone"
                                    type="phone" value="<?php echo e(old('companyPhone')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-4 col-form-label form-control-label">Company URL</label>
                            <div class="col-lg-8">
                                <input autocomplete="off" class="form-control auto-complete-off" name="companyURL"
                                    type="text" value="<?php echo e(old('companyURL')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                                    <div class="col-lg-12">
                                        <a href="<?php echo e(route('manageClients')); ?>" class="btn btn-secondary float-left">Back</a>
                                        <input type="submit" class="btn btn-primary float-right" value="Add Client">
                                    </div>
                        </div>
                    </div>
                    </div>
                    </div>
                    <div class="col-lg-6">
                            <div class="card">
                                <div class="card-body">
                                <h3 class="card-title text-center">Account Payable Contact Information:</h3>
                                <br>
                                <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Account Payable Name</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="accountPayableName" type="text"
                                    value="<?php echo e(old('accountPayableName')); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Account Payable Phone</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="accountPayablePhone" type="phone"
                                    value="<?php echo e(old('accountPayablePhone')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Account Payable Email</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="accountPayableEmail" type="email"
                                    value="<?php echo e(old('accountPayableEmail')); ?>">
                            </div>
                        </div>
                        <hr>
                        <br>
                        <h3 class="card-title text-center">Invoice Approver Information:</h3>
                        <br>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Invoice Approver Name</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="invoiceApproverName" type="text"
                                    value="<?php echo e(old('invoiceApproverName')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Invoice Approver Phone</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="invoiceApproverPhone" type="phone"
                                    value="<?php echo e(old('invoiceApproverPhone')); ?>">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Invoice Approver Email</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="invoiceApproverEmail" type="text"
                                    value="<?php echo e(old('invoiceApproverEmail')); ?>">
                            </div>
                        </div>
                        <hr>
                        <br>
                        <h3 class="card-title text-center">Executive Contact Information:</h3>
                        <br>
                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Executive Contact Name</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="executiveContactName" type="text"
                                    value="<?php echo e(old('executiveContactName')); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Executive Contact Phone</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="executiveContactPhone" type="phone"
                                    value="<?php echo e(old('executiveContactPhone')); ?>">
                            </div>
                        </div>

                        <div class="form-group row">
                            <label class="col-lg-5 col-form-label form-control-label">Executive Contact Email</label>
                            <div class="col-lg-7">
                                <input class="form-control" name="executiveContactEmail" type="email"
                                    value="<?php echo e(old('executiveContactEmail')); ?>">
                            </div>
                        </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js"></script>

<script>
    $(document).ready(function() {
       var state = $("#company-state").data('state');
       $("#company-state").val(state);
    });


    $().ready(function () {

    $("#client_information_form").submit(function () {
            $.LoadingOverlay("show");
    });

    $("#client_information_form").validate({ // initialize the plugin
        rules: {
            industry: {
                required: true,
            },
            companyName: {
                required: true,
                maxlength: 255
            },
            companyAddress: {
                required: true
            },
            companyState: {
                required: true
            },
            companyCity: {
                required: true
            },
            companyZip: {
                required: true
            },
            companyEmail: {
                required: true
            }
        },
        invalidHandler: function (event, validator) {
            // 'this' refers to the form
            var errors = validator.numberOfInvalids();
            if (errors) {
                $.LoadingOverlay("hide");
            } else {
                $.LoadingOverlay("show");

            }
        }
    });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\all\clients\addClient.blade.php ENDPATH**/ ?>