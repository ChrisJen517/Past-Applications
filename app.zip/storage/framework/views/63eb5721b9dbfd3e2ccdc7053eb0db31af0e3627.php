<div class="row">
    <?php $__currentLoopData = $product_headers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($item->name != 'Archived' && ($item->show_in_list == 1 || Auth::user()->role == 'manager')): ?>
    <div class="card" style="width:48%; margin:1%;">
        <div class="card-body">
            <div class="row">
                <div class="col-md-9">
                    <h4 class="mb-0"><?php echo e($item->name); ?></h4>
                </div>
                <div class="col-md-2">
                    <button href="#" class="btn btn-primary btn-sm product-button" type="text" id="pc-btn-<?php echo e($item->id); ?>"
                        data-enabled="true" value="<?php echo e($item->id); ?>" style="color: white; display:none;">Select
                        All</button>
                </div>
            </div>
            <hr>

            <div class="form-check">
                <input class="pc-box" type="checkbox" data-pc=<?php echo e($item->id); ?> name="parent" id="pc-<?php echo e($item->id); ?>">
                <?php echo e($item->name); ?>

                <ul style="list-style: none; padding-left: 0;" id="pc-ul-<?php echo e($item->id); ?>">
                    <?php ($i = 0); ?>
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($item->id == $product->product_header_id && ($product->show_in_list == 1 || Auth::user()->role
                    == 'manager')): ?>
                    <li id="pc-li-<?php echo e($item->id); ?>">
                        <div class="form-check">
                            <div class="row" id="pc-row-<?php echo e($item->id); ?>">
                                <div class="col-md-9">
                                    <input class="cc-box" type="checkbox" name="VPOE" id="<?php echo e($item->id); ?>"
                                        data-quote="<?php echo e($product->use_quote); ?>" disabled>
                                    <?php echo e($product->name); ?>

                                </div>
                                <div class="col-md-3">
                                    <?php
                                    $price = $product->price;
                                    $price = (float) $price;
                                    if ($price <= 10 || fmod($price, 1) !== 0.0) {
                                        if(strlen(substr(strrchr($price, "."), 1)) < 2) {
                                            $price = number_format($price, 2);
                                        }
                                    }
                                    ?>
                                    <?php if($product->use_quote == 1): ?>
                                    <input class="col float-right" id="price<?php echo e($product->id); ?>" name="price[<?php echo e($i); ?>]"
                                        type="text" value="<?php echo e($product->quote); ?>" disabled>
                                    <input hidden class="form-control" name="use_quote[]" id="use_quote" type="text"
                                        value="1" disabled>
                                    <?php else: ?>
                                    <input class="col float-right" id="price<?php echo e($product->id); ?>" step="0.01"
                                        name="price[<?php echo e($i); ?>]" type="number" value="<?php echo e($price); ?>" disabled>
                                    <input hidden class="form-control" name="use_quote[]" id="use_quote" type="text"
                                        value="0" disabled>
                                    <?php endif; ?>
                                    <input hidden class="form-control" name="originalPrice[]"
                                        value="<?php echo e($product->price); ?>" placeholder="originalPrice" disabled>
                                    <input hidden class="form-control" name="managerPrice[]"
                                        value="<?php echo e($product->manager_price_1); ?>" placeholder="managerPrice" disabled>
                                    <input hidden class="form-control" name="jimPrice[]"
                                        value="<?php echo e($product->manager_price_2); ?>" placeholder="jimPrice" disabled>
                                    <input hidden class="form-control" name="name[]" value="<?php echo e($product->name); ?>"
                                        placeholder="<?php echo e($product->name); ?>" disabled>
                                    <input hidden class="form-control" name="id[]" value="<?php echo e($product->id); ?>"
                                        placeholder="<?php echo e($product->id); ?>" disabled>
                                    <input hidden class="form-control" name="prod_header_id[]"
                                        value="<?php echo e($product->product_header_id); ?>"
                                        placeholder="<?php echo e($product->product_header_id); ?>" disabled>
                                    <input hidden class="form-control" name="reason[]" value="" placeholder="" disabled>
                                    <textarea hidden class="form-control" name="description[]"
                                        value="<?php echo e($product->description); ?>" placeholder="<?php echo e($product->description); ?>"
                                        disabled><?php echo e($product->description); ?></textarea>
                                    <input hidden class="form-control" name="price_name[]"
                                        value="<?php echo e($product->pricing_name); ?>" placeholder="<?php echo e($product->pricing_name); ?>"
                                        disabled>
                                    <input hidden class="form-control" name="batch_code[]"
                                        value="<?php echo e($product->batch_code); ?>" placeholder="<?php echo e($product->batch_code); ?>"
                                        disabled>
                                    <input hidden class="form-control" name="vast_code[]"
                                        value="<?php echo e($product->vast_code); ?>" placeholder="<?php echo e($product->vast_code); ?>" disabled>
                                    <input hidden class="form-control" name="sla[]" value="<?php echo e($product->sla); ?>"
                                        placeholder="<?php echo e($product->sla); ?>" disabled>
                                </div>
                            </div>
                        </div>
                    </li>
                    <?php endif; ?>
                    <?php ($i++); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        </ul>
    </div>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\forms\products.blade.php ENDPATH**/ ?>