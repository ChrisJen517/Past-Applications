<?php $__env->startSection('content'); ?>
<div class="loading-overlay">
    <div class="container-fluid">
        <div class="row">
            <!-- form user info -->
            <div class="container-fluid">
                <form action="<?php echo e(route('exportProductSheet')); ?>" class="no-loading product-sheet-form" method="POST"
                    enctype="multipart/form-data" id="contract_information_form">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header text-center">
                                    <h3 class="mb-0">Product Sheet Creation</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row" style="display: flex; justify-content: center;">
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-md-6">
                                    <input id="submit-button-2" name="submit" type="submit"
                                        class="btn btn-lg btn-primary btn-block btn-form-submit"
                                        value="Generate Product Sheet PDF">
                                </div>
                                <div class="col-md-6">
                                    <input id="submit-button-3" name="submit" type="submit"
                                        class="btn btn-lg btn-primary btn-block btn-form-submit"
                                        value="Generate Product Sheet Excel">
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php echo $__env->make('Includes.forms.products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="form-group row" style="display: flex; justify-content: center;">
                        <div class="col-lg-6">
                            <div class="row">
                                <div class="col-md-6">
                                    <input id="submit-button-2" name="submit" type="submit"
                                        class="btn btn-lg btn-primary btn-block btn-form-submit" style="margin:15px;"
                                        value="Generate Product Sheet PDF">
                                </div>
                                <div class="col-md-6">
                                    <input id="submit-button-3" name="submit" type="submit"
                                        class="btn btn-lg btn-primary btn-block btn-form-submit" style="margin:15px;"
                                        value="Generate Product Sheet Excel">
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/gasparesganga-jquery-loading-overlay@2.1.6/dist/loadingoverlay.min.js">
</script>
<script src="<?php echo e(asset('js/contracts/contract.js?'.time())); ?>"></script>
<script>
    $(document).ready(function() {
    $('form').submit(function(e) {
        if (!$(this).valid()) {
            return;
        }

        var form = $(this);
        form.find("[name^='price[']").attr("name", "price[]");

        var val = $("input[type=submit][clicked=true]").val();
        if (val == 'Generate Product Sheet Excel') {
            e.preventDefault();
            $.LoadingOverlay('show');
            var formData = $(this).serialize() + '&submit=' + val;
            $.post('<?php echo e(route("exportProductSheet")); ?>', formData, function(data, status) {
                $.LoadingOverlay('hide');
                if (data['error']) {
                    swal.fire('Cancelled', 'No products selected.', 'error');
                    return;
                }
                if (status == 'success') {
                    var fileName = data['fileName'];
                    window.location.href = '/downloadExport/' + fileName;
                } else {
                    swal.fire('Cancelled', 'There was an error while generating your excel file. Please contact a developer.', 'error');
                }
            });
        }
    });
    $("form input[type=submit]").click(function() {
        $("input[type=submit]", $(this).parents("form")).removeAttr("clicked");
        $(this).attr("clicked", "true");
    });
});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Includes.basicLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\contracts\productSheet.blade.php ENDPATH**/ ?>