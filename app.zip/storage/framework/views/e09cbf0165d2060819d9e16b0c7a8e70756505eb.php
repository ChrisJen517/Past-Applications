<header class="topbar-nav">
  <nav class="navbar navbar-expand fixed-top bg-topbar">
    <ul class="navbar-nav mr-auto align-items-center">
      <li class="nav-item">
        <a class="nav-link toggle-menu" href="javascript:void();">
          <i class="icon-menu menu-icon"></i>
        </a>
      </li>
    </ul>
    <ul class="navbar-nav align-items-center right-nav-link">
      <li class="nav-item">
        <a class="nav-link dropdown-toggle dropdown-toggle-nocaret dropdown-toggle-acc" data-toggle="dropdown" href="#">
          <span class="user-profile" style="margin-left:75px"><img id="userImage" <?php if(asset('/ProfilePictures'.'/'.Auth::user()->id.'/avatar.png')): ?> src="<?php echo e(asset('ProfilePictures/'.Auth::user()->id.'/avatar.png?'.time())); ?>"
               <?php else: ?> src="https://via.placeholder.com/110x110" <?php endif; ?> class="img-circle" alt="user avatar"></span>

        </a>
        <ul class="dropdown-menu dropdown-menu-right">
          <div class="no-click" style="pointer-events: none !important;">
            <li class="dropdown-item user-details">
              <div class="media">
                <div class="avatar"><img id="userImage" class="align-self-start mr-3" <?php if(asset('/ProfilePictures'.'/'.Auth::user()->id.'/avatar.png')): ?> src="<?php echo e(asset('ProfilePictures/'.Auth::user()->id.'/avatar.png?'.time())); ?>"
                    <?php else: ?> src="https://via.placeholder.com/110x110" <?php endif; ?> alt="user avatar"></div>
                <div class="media-body">
                  <h6 class="mt-2 user-title"><?php echo e(Auth::user()->first_name); ?> <?php echo e(Auth::user()->last_name); ?></h6>
                  <p class="user-subtitle"><?php echo e(Auth::user()->email); ?></p>
                </div>
              </div>
            </li>
          </div>
          <li class="dropdown-divider"></li>
          <a href="<?php echo e(asset('/manageAccount')); ?>"><li class="dropdown-item" style="color: inherit;"><i class="icon-wallet mr-2"></i>Account</li></a>
          <li class="dropdown-divider"></li>
          <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
            <li class="dropdown-item" style="color: inherit;"><i class="icon-power mr-2"></i><?php echo e(__('Logout')); ?></li>
          </a>
        </ul>
      </li>
      <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo csrf_field(); ?>
    </form>
    </ul>
  </nav>
</header>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\topBar.blade.php ENDPATH**/ ?>