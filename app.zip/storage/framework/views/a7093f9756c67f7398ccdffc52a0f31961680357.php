<link href="<?php echo e(asset('css/modal.css')); ?>" rel="stylesheet"/>

<div class="modal fade" id="editDocument" tabindex="-1" role="dialog" aria-labelledby="editLabel">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content border-0">
            <div class="modal-header">
                <h5 class="modal-title" id="editLabel">Edit Document</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            </div>
            <form method="POST" enctype="multipart/form-data" id="editDocumentForm">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <input type="text" class="form-control" id="id" name="id" value="<?php echo e(old('id')); ?>" hidden>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Document Name <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="document_name_edit" name="document_name" style="width: 100%;" value="<?php echo e(old('document_name')); ?>" maxlength="150">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Client or Vendor Name</label>
                        <div class="col-lg-9">
                            <select id="client_id" class="form-control" name="client_id">
                                <option value="" selected>N/A</option>
                                <?php $__currentLoopData = $clients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($client->id); ?>"><?php echo e($client->company_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Type <span style="color: red;">* </span></label>
                        <div class="col-lg-9">
                            <?php $types = array('Client FCRA MSA', 'Client Non FCRA MSA',
                            'Client Product Amendment', 'Client FCRA Amendment', 'MNDA/NDA',
                            'Data Vendor contract', 'Data Vendor NDA', 'Trend Source Audit','Trendsource Background Check',
                            'Verified vendor contract', 'Verified vendor NDA', 'Policy', 'Procedure',
                            'Marketing', 'Deck', 'Presentation', 'FAQs', 'Onboarding', 'Certificate', 'End User Audit', 'OTHER');?>
                            <select id="type_edit" name="type" class="form-control">
                                <?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($type); ?>"><?php echo e($type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Created Date</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="created_date_edit" name="created_date" autocomplete="off" disabled>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Expiration Date</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="expiration_date_edit" autocomplete="off" name="expiration_date">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">File</label>
                        <div class="col-lg-9">
                            <input autocomplete="off" class="form-control auto-complete-off custom-file-input" id="customFileInput" name="file_name" id="file_name" type="file">
                            <label class="custom-file-label" for="customFileInput" style="margin: 0px 15px 0px 15px;">Choose file...</label>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label" style="text-decoration: underline;" data-toggle="tooltip" title="Used to help search for the file, seperate the words by a comma">Key Words</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="key_words_edit" name="key_words">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-lg-3 col-form-label form-control-label">Notes</label>
                        <div class="col-lg-9">
                            <textarea type="textarea" class="form-control textarea" id="notes_edit" name="notes" value="<?php echo e(old('notes')); ?>"rows="5" cols="20" maxlength="250"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <span style="float:left;"> <span style="color: red;">* </span> Denotes required field. </span>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" id="archived_button" class="btn btn-danger" onclick="archiveDocument()">Delete</button>
                    <input type="submit" id="submit" class="btn btn-primary float-right" value="Save">
                </div>
            </form>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/validation/editDocument.js')); ?>"></script>
<link href="<?php echo e(asset('css/jquery-ui.theme.min.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/jquery-ui.structure.min.css')); ?>" rel="stylesheet">
<script src="<?php echo e(asset('js/editDocument.js?'.time())); ?>"></script>

<script>
$('[data-toggle="tooltip"]').tooltip();

function archiveDocument() {
    documentId = document.getElementById('id').value;

    documentName = document.getElementById('document_name_edit').value;

    if(archiveButton = document.getElementById("archived_button").innerHTML == "Archive"){
        urlLink = "/archiveDocument/" + documentId;
        action = "archive"
    }
    else{
        urlLink = "/unarchiveDocument/" + documentId;
        action = "unarchive"
    }

    swal.fire({
        title: "Are you sure?",
        text:
            "You are about to "+action+' the document "' + documentName + '".',
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Archive"
    }).then(willArchive => {
        if (willArchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Document has been successfully "+action+"d.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Document was not "+action+"d!", "error");
        }
    });
}
</script>
<?php /**PATH C:\xampp\htdocs\ContractPortal2\resources\views\Includes\modal\editDocumentModal.blade.php ENDPATH**/ ?>