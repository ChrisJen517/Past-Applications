<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware' => 'https'], function () {
    Route::get('/ExportProductData', 'Manager\ManageProductsController@ExportProductData')->name('ExportProductData');
    Route::get('/start_workers', function () {
        $exitCode = Artisan::call('queue:retry all');
        $exitCode = Artisan::call('queue:work --timeout=20 --stop-when-empty');

        return 'Workers Started';
    });
    Route::group(['middleware' => ['revalidate']], function () {
        Auth::routes();

        Route::get('/', function () {
            if (is_object(Auth::user()) == false) {
                return redirect('/login');
            }
            if (Auth::user()->password_valid == 0) {
                return view('login/changePassword');
            }
            if (Auth::user()->role == 'agent') {
                return redirect('/dashboard');
            }
            if (Auth::user()->role == 'manager') {
                return redirect('/manager/dashboard');
            }
        });

        Route::get('/success', function () {
            if (Auth::user()->password_valid == 0) {
                return view('login/changePassword');
            }
            if (Auth::user()->role == 'agent') {
                return redirect('/dashboard');
            }
            if (Auth::user()->role == 'manager') {
                return redirect('/manager/dashboard');
            }
        });

        Route::group(['middleware' => ['ajax-check', 'auth', 'valid_password']], function () {
            Route::get('/manageAccount', 'AllAccounts\ManageAccountController@manageAccount')->name('manageAccount');
            Route::post('/updateAccount', 'AllAccounts\ManageAccountController@update')->name('updateAccount');

            Route::get('/dashboard', 'Agent\DashboardController@showDashboard')->name('agentDashboard');
            Route::get('/dashboard/archive/{id}', 'Agent\DashboardController@archiveContract')->name('archiveContract');
            Route::get('/dashboard/getAgentTable/{archive}', 'Agent\DashboardController@archiveContract')->name('getAgentTable');

            Route::get('/findClient/{name}', 'AllAccounts\ManageClientsController@findClient')->name('findClient');

            //Route::get('/manageDocument/{id}', 'Manager\ManageDocumentController@manageDocument')->name('manageDocument');

            Route::get('/manageClients', 'AllAccounts\ManageClientsController@showClients')->name('manageClients');
            Route::get('/getClientTable', 'AllAccounts\ManageClientsController@getActiveClientsTable')->name('getClientTable');
            Route::get('/getArchivedClientTable', 'AllAccounts\ManageClientsController@getInactiveClientsTable')->name('getArchivedClientTable');
            Route::get('/manageClients/edit/{id}', 'AllAccounts\ManageClientsController@editClient')->name('editClient');
            Route::post('/manageClients/update', 'AllAccounts\ManageClientsController@updateClient')->name('updateClient');
            Route::get('/manageClients/addClient', 'AllAccounts\ManageClientsController@showAddClient')->name('showAddClient');
            Route::post('/manageClients/add', 'AllAccounts\ManageClientsController@addClient')->name('addClient');
            Route::get('/manageClients/archive/{id}', 'AllAccounts\ManageClientsController@archiveClient')->name('archiveClient');
            Route::post('/manageClients/sendEmail', 'AllAccounts\ManageClientsController@sendEmail')->name('sendEmailForm');
            Route::get('/manageClients/getEmailHistory/{id}', 'AllAccounts\ManageClientsController@getEmails')->name('getClientEmailHistory');
            Route::get('/manageClients/getFileNames/{id}/{type}', 'AllAccounts\ManageClientsController@getFileNames')->name('getEmailFileNames');
            Route::get('/manageClients/getEmailFiles/{id}/{type}/{file}', 'AllAccounts\ManageClientsController@getEmailFiles')->name('getClientEmailFiles');

            Route::get('/manageContract/{id}', 'Agent\ManageContractsController@manageContract')->name('manageContract');
            Route::post('/manageContract/customerChanges', 'Agent\ManageContractsController@uploadCustomerChanges')->name('uploadCustomerChanges');
            Route::post('/manageContract/contractChanges', 'Agent\ManageContractsController@uploadContractChanges')->name('uploadContractChanges');
            Route::post('/manageContract/redlineChanges', 'Agent\ManageContractsController@uploadRedlineChanges')->name('uploadRedlineChanges');
            Route::post('/manageContract/customerSignature', 'Agent\ManageContractsController@uploadCustomerSignature')->name('uploadCustomerSignature');
            Route::post('/manageContract/managerSignature', 'Agent\ManageContractsController@uploadManagerSignature')->name('uploadManagerSignature');

            Route::get('/supportDocuments', 'AllAccounts\SupportDocumentController@showSupportDocuments')->name('supportDocuments');
            Route::post('/getSupportDocumentTable', 'AllAccounts\SupportDocumentController@getSupportDocumentTable')->name('getSupportDocumentTable');
            Route::post('/getArchivedSupportDocumentTable', 'AllAccounts\SupportDocumentController@getArchivedSupportDocumentTable')->name('getArchivedSupportDocumentTable');

            //////////////     Contracts        ////////////////////
            Route::get('/MSA', 'Contracts\MSAController@showMSA')->name('showMSA');
            Route::post('/exportMSA', 'Contracts\MSAController@exportMSA')->name('exportMSA');

            Route::get('/MSA_No_FCRA', 'Contracts\NonFCRAMSAController@showNonFCRAMSA')->name('showNonFCRAMSA');
            Route::post('/exportNonFCRAMSA', 'Contracts\NonFCRAMSAController@exportNonFCRAMSA')->name('exportNonFCRAMSA');

            Route::get('/NDA', 'Contracts\NDAController@showNDA')->name('showNDA');
            Route::post('/exportNDA', 'Contracts\NDAController@exportNDA')->name('exportNDA');

            Route::get('/You-Negotiate', 'Contracts\YouNegotiateController@showYouNegotiate')->name('showYouNegotiate');
            Route::post('/exportYouNegotiate', 'Contracts\YouNegotiateController@exportYouNegotiate')->name('exportYouNegotiate');

            Route::get('/YNAmendment', 'Contracts\YouNegotiateAmendmentController@showYNAmendment')->name('showYNAmendment');
            Route::post('/exportYYNAmendment', 'Contracts\YouNegotiateAmendmentController@exportYNAmendment')->name('exportYNAmendment');

            Route::get('/MSA_Amendment', 'Contracts\MSAAmendmentController@showMSAAmendment')->name('showMSAAmendment');
            Route::post('/exportMSAAmendment', 'Contracts\MSAAmendmentController@exportMSAAmendment')->name('exportMSAAmendment');

            Route::get('/FCRA', 'Contracts\FCRAController@showFCRA')->name('showFCRA');
            Route::post('/exportFCRA', 'Contracts\FCRAController@exportFCRA')->name('exportFCRA');

            Route::get('/NVN', 'Contracts\NVNController@showNVN')->name('showNVN');
            Route::post('/exportNVN', 'Contracts\NVNController@exportNVN')->name('exportNVN');

            Route::get('/Name_Change_Amendment', 'Contracts\NameChangeAmendmentController@showAmendment')->name('showNameChangeAmendment');
            Route::post('/exportNameChangeAmendment', 'Contracts\NameChangeAmendmentController@exportNameChangeAmendment')->name('exportNameChangeAmendment');

            Route::get('/CertFCRA', 'Contracts\CertFCRAController@showCertFCRA')->name('showCertFCRA');
            Route::post('/exportCertFCRA', 'Contracts\CertFCRAController@exportCertFCRA')->name('exportCertFCRA');

            Route::get('/RedlineStart', 'Contracts\RedlineController@showRedlineStart')->name('showRedlineStart');
            Route::post('/exportRedlineStart', 'Contracts\RedlineController@exportRedlineStart')->name('exportRedlineStart');
            Route::get('/RedlineProducts/{id}', 'Contracts\RedlineController@showRedlineProducts')->name('showRedlineProducts');
            Route::post('/exportRedlineWithProducts', 'Contracts\RedlineController@exportRedlineWithProducts')->name('exportRedlineWithProducts');

            Route::get('/productSheet', 'Contracts\ProductSheetController@showProductSheet')->name('showProductSheet');
            Route::post('/exportProductSheet', 'Contracts\ProductSheetController@exportProductSheet')->name('exportProductSheet');

            Route::post('/Fetch_Client_Data', 'Contracts\MSAController@fetchClientData')->name('fetchClientData');
            //////////////----------------------////////////////////

            Route::get('/sendContract/{id}/{email}/{name}', 'AllAccounts\DocusignController@sendDocumentForSigning')->name('sendContract');
            Route::get('/resendContract/{id}', 'AllAccounts\DocusignController@resendContract')->name('resendContract');

            // Route::get('/salesLeads', 'AllAccounts\SalesLeadController@showSalesLeads')->name('showSalesLeads');
            // Route::get('/mySalesLeads', 'AllAccounts\SalesLeadController@showMySalesLeads')->name('showMyLeads');
            Route::get('/showLead/{id}', 'AllAccounts\SalesLeadController@showLead')->name('showLead');
            Route::post('/createNewLeadNote', 'AllAccounts\LeadActivityController@createNewLeadNote')->name('createNewLeadNote');
            Route::post('/createNextStep/{sendInvite}', 'AllAccounts\LeadActivityController@createNextStep')->name('createNextStep');
            // Route::post('/createNewTask', 'AllAccounts\LeadActivityController@createNewTask')->name('createNewTask');
            // Route::post('/createNewEvent', 'AllAccounts\LeadActivityController@createNewEvent')->name('createNewEvent');
            Route::post('/createNewEventNote', 'AllAccounts\LeadActivityController@createNewEventNote')->name('createNewEventNote');
            Route::post('/setTaskComplete', 'AllAccounts\LeadActivityController@setTaskComplete')->name('setTaskComplete');

            Route::get('/leadBoard', 'AllAccounts\LeadBoardController@showLeadsBoard')->name('leadBoard');
            Route::post('/leadBoard/add', 'AllAccounts\LeadBoardController@addToQueue')->name('addToAgentQueue');
            Route::post('/leadBoard/save', 'AllAccounts\LeadBoardController@saveCardOrder')->name('saveCardOrder');
            Route::post('/leadBoard/remove', 'LeadBoardController@removeFromBoard')->name('removeCard');
            Route::post('/createSalesLead', 'AllAccounts\LeadBoardController@createSalesLead')->name('createLead');

            Route::post('/addLead', 'AllAccounts\SalesLeadController@addLeadContact')->name('addLeadContact');
            Route::post('/updateLead', 'AllAccounts\SalesLeadController@updateLead')->name('updateLead');

            Route::get('/showLeads', 'AllAccounts\SalesLeadController@showLeads')->name('showLeads');
            Route::post('/exportLeadsJson/{unworked}', 'AllAccounts\SalesLeadController@exportLeadsJson')->name('exportLeadsJson');
            Route::get('/workLead/{id}', 'AllAccounts\SalesLeadController@workLead')->name('workLead');
            Route::get('/workNextLead', 'AllAccounts\SalesLeadController@workNextAvailable')->name('workNextLead');
            Route::post('/closeLead', 'AllAccounts\SalesLeadController@closeLead')->name('closeLead');

            Route::get('/getEventWidget/{id}', 'AllAccounts\SalesLeadController@getEventWidget')->name('workLeadModal');
            Route::get('/workLead/modal/{id}', 'AllAccounts\SalesLeadController@workLeadForm')->name('workLeadModal');

            Route::group(['prefix' => 'RequestForm'], function () {
                Route::get('/', 'AllAccounts\RequestFormController@requestForm')->name('requestForm');
                Route::get('/getHistory/{id}', 'AllAccounts\RequestFormController@historyTable')->name('requestHistoryForm');
                Route::post('/submit', 'AllAccounts\RequestFormController@submitForm')->name('submitRequestForm');
                Route::get('/archive/{id}', 'AllAccounts\RequestFormController@archiveForm')->name('archiveRequestForm');
            });

            Route::get('/audits', 'Audits\AuditController@showAudits')->name('showAudits');
            Route::post('/editAudit', 'Audits\AuditController@editAudit')->name('editAudit');
            Route::post('/archiveAudit', 'Audits\AuditController@archiveAudit')->name('archiveAudit');
            Route::post('/completeAudit', 'Audits\AuditController@completeAudit')->name('completeAudit');
            Route::post('/createAudit', 'Audits\AuditController@createAudit')->name('createAudit');
            Route::get('/getAuditFiles' , 'Audits\AuditController@getFiles')->name('auditFiles');
            Route::post('/uploadAuditFiles' , 'Audits\AuditController@uploadFiles')->name('auditUpload');
            Route::post('/deleteAuditFiles' , 'Audits\AuditController@deleteFile')->name('auditDelete');
            Route::get('/downloadAudit/{id}/{type}/{file}', array(
                'as' => 'download',
                'uses' => 'Audits\AuditController@downloadFile'
            ))->where('file', '.*');


            Route::get('/download/{file}', array(
                'as' => 'download',
                'uses' => 'AllAccounts\ManageContractsController@downloadContract'
            ))->where('file', '.*');

            Route::get('/downloadExport/{file}', array(
                'as' => 'downloadExport',
                'uses' => 'AllAccounts\ManageExportsController@downloadExport'
            ))->where('file', '.*');
        });

        Route::group(['middleware' => ['ajax-check', 'manager', 'valid_password']], function () {
            
            Route::get('/manager/dashboard', 'Manager\DashboardController@showDashboard')->name('managerDashboard');
            Route::post('/manager/getCompleteContracts', 'Manager\DashboardController@getCompleteContracts')->name('getCompleteContracts');
            Route::post('/manager/getArchivedContracts', 'Manager\DashboardController@getArchivedContracts')->name('getArchivedContracts');
            Route::post('/manager/getPendingContracts', 'Manager\DashboardController@getPendingContracts')->name('getPendingContracts');
            Route::post('/manager/getContractsNeedingApproval', 'Manager\DashboardController@getContractsNeedingApproval')->name('getContractsNeedingApproval');
            Route::post('/manager/getYouNegotiateContracts', 'Manager\DashboardController@getYouNegotiateContracts')->name('getYouNegotiateContracts');
            Route::post('/manager/exportContracts', 'Manager\DashboardController@exportContracts')->name('exportContracts');

            Route::get('/authorizeContract/{id}', 'Manager\ManageContractsController@authorizeContract')->name('authorizeContract');
            Route::get('/authorizeRedline/{id}', 'Manager\ManageContractsController@authorizeRedline')->name('authorizeRedline');

            Route::post('/editDocument/{id}', 'Manager\ManageDocumentController@editDocument')->name('editDocument');
            Route::post('/createDocument', 'Manager\ManageDocumentController@createDocument')->name('createDocument');
            Route::get('/archiveDocument/{id}', 'Manager\ManageDocumentController@archiveDocument')->name('archiveDocument');
            Route::get('/unarchiveDocument/{id}', 'Manager\ManageDocumentController@unarchiveDocument')->name('unarchiveDocument');

            Route::get('/manageUsers', 'Manager\ManageUsersController@showUsers')->name('showManageUsers');
            Route::post('/manageUsers/createUser', 'Manager\ManageUsersController@addNewUser')->name('addNewUser');
            Route::get('/manageUsers/archive/{id}', 'Manager\ManageUsersController@archiveUser')->name('archiveUser');
            Route::get('/manageUsers/unarchive/{id}', 'Manager\ManageUsersController@unarchiveUser')->name('unarchiveUser');
            Route::get('/resetPassword/{id}', 'Manager\ManageUsersController@resetPassword')->name('resetPasswordForced');
            Route::get('/editUser/{id}', 'Manager\ManageUsersController@editUser')->name('editUser');
            Route::post('/editUser/update', 'Manager\ManageUsersController@updateUser')->name('updateUser');

            Route::get('/ICA', 'Contracts\ICAController@showICA')->name('showICA');
            Route::post('/exportICA', 'Contracts\ICAController@exportICA')->name('exportICA');

            Route::get('/ResellerAgreement', 'Contracts\ResellerAgreementController@showResellerAgreement')->name('showResellerAgreement');
            Route::post('/exportResellerAgreement', 'Contracts\ResellerAgreementController@exportResellerAgreement')->name('exportResellerAgreement');

            Route::get('/manageProductSheet', 'Manager\ManageProductsController@manageProductSheet')->name('manageProductSheet');
            Route::get('/manageProductSheet/export', 'Manager\ManageProductsController@exportProductSheet')->name('exportProducts');
            Route::post('/updateProduct', 'Manager\ManageProductsController@updateProduct')->name('updateProduct');
            Route::post('/updateActive', 'Manager\ManageProductsController@updateActive')->name('updateActive');
            Route::post('/addProduct', 'Manager\ManageProductsController@addProduct')->name('addProduct');
            Route::get('/deleteProduct/{id}', 'Manager\ManageProductsController@deleteProduct')->name('deleteProduct');

            Route::get('/manageProductHeaders', 'Manager\ManageProductsController@showProductHeaders')->name('manageProductHeaders');
            Route::post('/manageProductHeaders/add', 'Manager\ManageProductsController@addProductHeader')->name('addProductHeader');
            Route::post('/manageProductHeaders/edit/{id}', 'Manager\ManageProductsController@editProductHeader')->name('editProductHeader');
            Route::get('/manageProductHeaders/delete/{id}', 'Manager\ManageProductsController@deleteProductHeader')->name('deleteProductHeader');
            Route::get('/getNumberOfProducts/{id}', 'Manager\ManageProductsController@getNumberOfProducts')->name('getNumberOfProducts');

            Route::get('/productHistory', 'Manager\ManageProductsController@showProductHistory')->name('showProductHistory');

            Route::get('/manageProductHeaderOrder', 'Manager\ManageProductsController@showProductHeaderOrder')->name('manageProductHeaderOrder');
            Route::post('/saveProductHeaderOrder', 'Manager\ManageProductsController@saveProductHeaderOrder')->name('saveProductHeaderOrder');
            Route::get('/manageProductOrder/{id}', 'Manager\ManageProductsController@manageProductOrder')->name('manageProductOrder');
            Route::post('/saveProductOrder', 'Manager\ManageProductsController@saveProductOrder')->name('saveProductOrder');

            Route::get('/salesLeadStats', 'AllAccounts\SalesLeadController@showSalesLeadStats')->name('showSalesLeadStats');
            Route::get('/salesLeadQueues', 'AllAccounts\SalesLeadController@showSalesLeadQueues')->name('showSalesLeadsQueues');
            Route::get('/showAgentLeads', 'AllAccounts\SalesLeadController@showAgentLeads')->name('showAgentLeads');
            Route::get('/clearAgentLeads', 'AllAccounts\SalesLeadController@clearAgentLeads')->name('clearAgentLeads');
            Route::post('/assignAgentLeads', 'AllAccounts\SalesLeadController@assignAgentLeads')->name('assignAgentLeads');

            Route::post('/exportContacts', 'AllAccounts\SalesLeadController@exportContacts')->name('exportContacts');
            Route::get('/exportAllContacts/{unworked}', 'AllAccounts\SalesLeadController@exportAllContacts')->name('exportAllContacts');
        });

        Route::get('/approve/{key1}/{key2}/{id}', 'Manager\ApproveController@showApprove')->name('showApprove');
        Route::post('/approved', 'Manager\ApproveController@approved')->name('approveContract');

        Route::get('/reviewPurchaseRequest/{key1}/{key2}/{id}/{type}', 'AllAccounts\RequestFormController@managerReviewPurchaseRequest')->name('managerReviewPurchaseRequest');
        Route::post('/reviewPurchaseRequest', 'AllAccounts\RequestFormController@managerSubmitPurchaseRequestReview')->name('reviewPurchaseRequest-submit');


        Route::get('/legalApprove/{key1}/{key2}/{id}', 'Manager\ApproveController@showLegalApprove')->name('showLegalApprove');
        Route::post('/legalApproved', 'Manager\ApproveController@legalApproved')->name('approveLegalContract');

        Route::get('/changePassword', 'Agent\AccountController@showChangePassword')->name('showChangePassword')->middleware('auth');
        Route::post('/changePassword/Change', 'Agent\AccountController@changePassword')->name('changePassword')->middleware('auth');
        Route::get('/login', 'Auth\LoginController@showLoginForm')->name('login');
        Route::post('/login', 'Auth\LoginController@login')->name('loginUser');
        Route::post('/logout', 'Auth\LoginController@logout')->name('logout');
        Route::get('/resetPassword', 'AllAccounts\ManageAccountController@resetPassword')->name('resetPassword');
        Route::post('/sendResetPassword', 'AllAccounts\ManageAccountController@sendResetPassword')->name('sendResetPassword');

        Route::get('/runExport', function () {
            return Artisan::call('command:WeeklyReportingContracts');
        });

        Route::get('/runAuditReport', function () {
            return Artisan::call('command:WeeklyAuditReport');
        });
        
        Route::get('/updateContract', 'AllAccounts\DocusignController@checkDocumentStatus')->name('updateContract');

        Route::get('/Client', 'Client\ClientUploadsController@showClientLogin')->name('showClientLogin');
        Route::get('/Client/login', 'Client\ClientUploadsController@checkClientLogin')->name('checkClientLogin');
        Route::post('/Client/upload', 'Client\ClientUploadsController@uploadDocument')->name('clientUploadDocument');
        Route::get('/Client/complete/{email}/{password}', 'Client\ClientUploadsController@completeUploading')->name('clientCompleteUploading');
        
        Route::get('/downloadClientDocument/{file_name}/{email}/{password}', array(
            'as' => 'downloadClientDocument',
            'uses' => 'Client\ClientUploadsController@downloadDocument'
        ))->where('file', '.*');

        Broadcast::routes();

    });
});