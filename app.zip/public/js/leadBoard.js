var updated = false;

$(window).bind("beforeunload", function() {
    if (updated) {
        return "Are you sure you want to leave?";
    }
});

$(document).ready(function() {
    $('ul[id^="sort"]')
        .sortable({
            connectWith: ".sortable",
            cursor: "move",
            update: function(event, ui) {
                updated = true;
                $(this)
                    .children()
                    .each(function(index) {
                        $(this).attr("data-position", index + 1);
                        $(this).data("position", index + 1);
                    });

                if (ui.sender != null) {
                    var ids = [];
                    var orders = [];
                    var columns = [];
                    $("ul.sortable").each(function() {
                        var column_id = $(this).data("column");
                        $(this)
                            .children()
                            .each(function() {
                                ids.push($(this).data("id"));
                                orders.push($(this).data("position"));
                                columns.push(column_id);
                            });
                    });

                    if (ids.length != 0) {
                        $.post("/leadBoard/save", {
                            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                                "content"
                            ),
                            ids: ids,
                            orders: orders,
                            columns: columns
                        }).done(function(data) {
                            updated = false;
                        });
                    }
                }
            }
        })
        .disableSelection();

    $(".new-company-input").focusout(function() {
        var id = $(this).data("id");
        var inputBox = $("#text-" + id);
        inputBox.val("");
        inputBox.hide();
        $("#text-placeholder-" + id).show();
    });
});

var cardTitle = null;
var cardId = null;
function setInfo(title, id) {
    cardTitle = title;
    cardId = id;
}

function reorderCards() {
    var ids = [];
    var orders = [];
    var columns = [];
    $("ul.sortable").each(function() {
        var column_id = $(this).data("column");
        $(this)
            .children()
            .each(function() {
                ids.push($(this).data("id"));
                orders.push($(this).data("position"));
                columns.push(column_id);
            });
    });

    swal.fire({
        title: "Are you sure?",
        text: "You are about to reorder the cards.",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Save"
    }).then(willSave => {
        if (willSave.value) {
            if (updated) {
                $.LoadingOverlay("show");
                $(function() {
                    "use strict";
                    $.post("/leadBoard/save", {
                        "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr(
                            "content"
                        ),
                        ids: ids,
                        orders: orders,
                        columns: columns
                    }).done(function(data) {
                        updated = false;
                        $.LoadingOverlay("hide");
                        swal.fire(
                            "Success",
                            "Card order has been saved.",
                            "success"
                        );
                    });
                });
            } else {
                swal.fire("Success", "Card order has been saved.", "success");
            }
        } else {
            swal.fire("Cancelled", "Card order was not saved!", "error");
        }
    });
}

function showInput(id) {
    var inputBox = $("#text-" + id);
    $("#text-placeholder-" + id).hide();
    inputBox.show();
    inputBox.focus();
}
