$(function() {
    "use strict";

    $(".dropdown-toggle-acc").on("click", function(e) {
        e.preventDefault();
        var width = $(window).width();
        if (width < 768) close();
    });

    $(".toggle-menu").on("click", function(e) {
        e.preventDefault();

        var width = $(window).width();
        console.log(width);
        if (width >= 768) {
            $("#wrapper").toggleClass("toggled");
            $("#wrapper").toggleClass("toggled-icons");

            var icon = $("#wrapper").find(
                "#sidebar-wrapper-icons .sidebar-menu .active .sidebar-submenu"
            );

            icon.slideUp(0, function() {
                icon.removeClass("menu-open");
            });
            icon.parent("li").removeClass("active");

            var interv = window.setInterval(function() {
                $("#main-stuff").width($("#info-cards").width());
                clearInterval(interv);
            }, 500);
        } else {
            toggle();
        }
    });

    function toggle() {
        var sidebarWrapper = $("#sidebar-wrapper-icons");
        var sidebarMenu = $(".sidebar-menu");
        var contentWrapper = $(".content-wrapper");
        var currentlyShowing = sidebarMenu.css("display") != "none";

        if (currentlyShowing) {
            sidebarWrapper.css({
                "box-shadow": "none"
            });
            sidebarMenu.hide();
            contentWrapper.css("padding-left", "0px");
        } else {
            sidebarWrapper.css(
                "box-shadow",
                "0 2px 6px 0 rgba(218, 218, 253, 0.65), 0 2px 6px 0 rgba(206, 206, 238, 0.54);"
            );
            sidebarMenu.show();
            contentWrapper.css("padding-left", "50px");
        }
    }

    function close() {
        var sidebarWrapper = $("#sidebar-wrapper-icons");
        var sidebarMenu = $(".sidebar-menu");
        var contentWrapper = $(".content-wrapper");
        sidebarWrapper.css({
            "box-shadow": "none"
        });
        sidebarMenu.hide();
        contentWrapper.css("padding-left", "0px");
    }
});
