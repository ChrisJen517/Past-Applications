
$(function() {
    "use strict";
     
	 
	//sidebar menu js
	$.sidebarMenu($('.sidebar-menu'));

	// === toggle-menu js

	$('#main-stuff').width($('#info-cards').width());
	$(function() {
		

		for (var i = window.location, o = $("#sidebar-wrapper .sidebar-menu a").filter(function() {
			return this.href == i;
		}).addClass("active").parent().addClass("active"); ;) {
			if (!o.is("li")) break;
			o = o.parent().addClass("in").parent().addClass("active");
		}
		
	}) 	   
   
	$(function()
	{
	var elem = document.getElementById('userImage');
	console.log(elem);
	if(elem.getAttribute('src') == "")
	{
		elem.attr('src', "https://via.placeholder.com/110x110")
	}
	console.log(elem);

	});


	//Clear modal forms on cancel
	$('.modal').on('hide.bs.modal', function(){
		$(this).find('form').trigger('reset');
	})


});