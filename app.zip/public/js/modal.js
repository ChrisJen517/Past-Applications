$(document).ready(function() {
    $.ajaxSetup({
        headers: {
            "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content")
        }
    });
});

// jquery extend function
$.extend({
    redirectPost: function(location, args) {
        var form = "";
        $.each(args, function(key, value) {
            value = value.split('"').join('"');
            form +=
                '<input type="hidden" name="' +
                key +
                '" value="' +
                value +
                '">';
        });
        $('<form action="' + location + '" method="POST">' + form + "</form>")
            .appendTo($(document.body))
            .submit();
    }
});

function resendContract(contractId, recipients) {
    urlLink = "/resendContract/" + contractId;
    swal.fire({
        title: "Are you sure?",
        text: "You are about to resend the contract to " + recipients,
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Resend"
    }).then(willSend => {
        if (willSend.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Contract has been successfully resent for signing.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Contract was not resent!", "error");
        }
    });
}

async function sendContract(contractId, clientEmail, nameOptions) {
    urlLink = "/sendContract/" + contractId + "/";
    const { value: email } = await swal.fire({
        title: "Client Email",
        icon: "info",
        html: "Please enter the email that will handle the client's signature",
        input: "email",
        inputPlaceholder: "Enter an email address",
        inputValue: clientEmail,
        showCancelButton: true,
        onOpen: () => swal.getCancelButton().focus()
    });
    if (email) {
        urlLink += encodeURIComponent(email);
        urlLink += "/";

        const { value: name } = await swal.fire({
            title: "Client Full Name",
            icon: "info",
            html: "Please enter the client's full name that will handle the client's signature" + nameOptions,
            input: "text",
            inputPlaceholder: "Enter client full name Ex) John Smith",
            showCancelButton: true,
            onOpen: () => swal.getCancelButton().focus()
        });
        if(name){
            urlLink += encodeURIComponent(name);
            swal.fire({
                title: "Are you sure?",
                text:
                    "You are about to send the contract for signing to jimv@rnngroup.com and " +
                    name + " at " + email +
                    ".",
                icon: "warning",
                showCancelButton: true,
                showCloseButton: true,
                confirmButtonText: "Send"
            }).then(willSend => {
                if (willSend.value) {
                    $.LoadingOverlay("show", {
                        zIndex: 2147483645
                    });
                    $(function() {
                        "use strict";
                        $.get(urlLink, function(data) {
                            swal.fire(
                                "Success",
                                "Contract has been successfully sent for signing.",
                                "success"
                            );
                            setTimeout(() => location.reload(true), 100);
                        });
                    });
                } else {
                    swal.fire("Cancelled", "Contract was not sent!", "error");
                }
            });
        } else {
            swal.fire("Cancelled", "Contract was not sent!", "error");
        }
    } else {
        swal.fire("Cancelled", "Contract was not sent!", "error");
    }
}


function archiveUser(userId) {
    urlLink = "/manageUsers/archive/" + userId;
    swal.fire({
        title: "Are you sure?",
        text: "You are about to archive the user with id " + userId + ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Archive"
    }).then(willArchive => {
        if (willArchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "User has been successfully archived.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "User was not archived!", "error");
        }
    });
}

function unarchiveUser(userId) {
    urlLink = "/manageUsers/unarchive/" + userId;
    swal.fire({
        title: "Are you sure?",
        text: "You are about to unarchive the user with id " + userId + ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Unarchive"
    }).then(willUnarchive => {
        if (willUnarchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "User has been successfully unarchived.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "User was not unarchived!", "error");
        }
    });
}

function archiveClient(clientId, clientName) {
    urlLink = "/manageClients/archive/" + clientId;
    swal.fire({
        title: "Are you sure?",
        text: "You are about to archive the client " + clientName + ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Archive"
    }).then(willArchive => {
        if (willArchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Client has been successfully archived.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Client was not archived!", "error");
        }
    });
}

function unarchiveClient(clientId, clientName) {
    urlLink = "/manageClients/archive/" + clientId;
    swal.fire({
        title: "Are you sure?",
        text: "You are about to unarchive the client " + clientName + ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Unarchive"
    }).then(willArchive => {
        if (willArchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Client has been successfully unarchived.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Client was not unarchived!", "error");
        }
    });
}

function archiveContract(contractId) {
    urlLink = "/dashboard/archive/" + contractId;
    swal.fire({
        title: "Are you sure?",
        text:
            "You are about to archive the contract with id " + contractId + ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Archive"
    }).then(willArchive => {
        if (willArchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Contract has been successfully archived.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Contract was not archived!", "error");
        }
    });
}

function unarchiveContract(contractId) {
    urlLink = "/dashboard/archive/" + contractId;
    swal.fire({
        title: "Are you sure?",
        text:
            "You are about to unarchive the contract with id " +
            contractId +
            ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Unarchive"
    }).then(willUnarchive => {
        if (willUnarchive.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Contract has been successfully unarchived.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Contract was not unarchived!", "error");
        }
    });
}

function passwordReset(userId) {
    urlLink = "/resetPassword/" + userId;
    swal.fire({
        title: "Are you sure?",
        text: "An email will be sent to reset password!",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Reset"
    }).then(willReset => {
        if (willReset.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    $.LoadingOverlay("hide");
                    swal.fire(
                        "Success",
                        "Password reset, an email has been sent to the user.",
                        "success"
                    );
                });
            });
        } else {
            swal.fire("Cancelled", "Password not reset!", "error");
        }
    });
}

function deleteProductHeader(productHeaderId) {
    urlLink = "/manageProductHeaders/delete/" + productHeaderId;
    swal.fire({
        title: "Are you sure?",
        text:
            "You are about to delete the product header with id " +
            productHeaderId +
            ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Delete"
    }).then(willDelete => {
        if (willDelete.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $.get("/getNumberOfProducts/" + productHeaderId, function(data) {
                if (data > 0) {
                    $.LoadingOverlay("hide");
                    swal.fire(
                        "Cancelled",
                        "Cannot delete a product header with active products!",
                        "error"
                    );
                } else {
                    $(function() {
                        "use strict";
                        $.get(urlLink, function(data) {
                            swal.fire(
                                "Success",
                                "Product Header has been successfully deleted.",
                                "success"
                            );
                            setTimeout(() => location.reload(true), 100);
                        });
                    });
                }
            });
        } else {
            swal.fire("Cancelled", "Product Header was not deleted!", "error");
        }
    });
}

function deleteProduct(productId) {
    urlLink = "/deleteProduct/" + productId;
    swal.fire({
        title: "Are you sure?",
        text: "You are about to delete the product with id " + productId + ".",
        icon: "warning",
        showCancelButton: true,
        showCloseButton: true,
        confirmButtonText: "Delete"
    }).then(willDelete => {
        if (willDelete.value) {
            $.LoadingOverlay("show", {
                zIndex: 2147483645
            });
            $(function() {
                "use strict";
                $.get(urlLink, function(data) {
                    swal.fire(
                        "Success",
                        "Product has been successfully deleted.",
                        "success"
                    );
                    setTimeout(() => location.reload(true), 100);
                });
            });
        } else {
            swal.fire("Cancelled", "Product was not deleted!", "error");
        }
    });
}
