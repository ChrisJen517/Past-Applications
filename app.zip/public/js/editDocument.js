 $(document).ready(function() {
 $('#editDocument').on('show.bs.modal', function(e) {
     $(this).find('#id').val($(e.relatedTarget).data('id'));
     $(this).find('#document_name_edit').val($(e.relatedTarget).data('name'));
     $(this).find('#notes_edit').val($(e.relatedTarget).data('notes'));
     $(this).find('#type_edit').val($(e.relatedTarget).data('type'));
     $(this).find('#client_vendor_name_edit').val($(e.relatedTarget).data('client_vendor_name'));
     $(this).find('#created_date_edit').val($(e.relatedTarget).data('created_date'));
     $(this).find('#expiration_date_edit').val($(e.relatedTarget).data('expiration_date'));
     $(this).find('#key_words_edit').val($(e.relatedTarget).data('key_words'));
     $(this).find('#client_id').val($(e.relatedTarget).data('client_id'));

     //changes the buttons name depending on if the document is archived
     archiveButton = document.getElementById("archived_button")
     if($(e.relatedTarget).data('archived') == 0){
         archiveButton.innerHTML = "Archive"
     }
     else{
         archiveButton.innerHTML = "Unarchive"
     }

     $('#editDocumentForm').attr('action', '/editDocument/' + $(e.relatedTarget).data('id'));
 });

 $('#editDocument').on('hide.bs.modal', function(e) {
     var validator = $( "#editDocumentForm" ).validate();
     validator.resetForm();
 });

 $(document).ready(function() {
     $(function() {
         $('#created_date_edit').datepicker({
             maxDate: new Date,
         });
     });
 });

 $(document).ready(function() {
     $(function() {
         $('#expiration_date_edit').datepicker({
             minDate: new Date,
         });
     });
 });

 $(document).ready(function() {
     // form front-end validation
     $('#editDocumentForm').validate({
         rules: {
             document_name: {
                 required: true
             },
             type: {
                 required: true
             },
         },
     });
 });

 $("#editDocumentForm").on( "submit",function(){
     if($(this).valid())
         $.LoadingOverlay("show");
 });
});