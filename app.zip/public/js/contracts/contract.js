$(document).ready(function () {
    $(".btn-sm").show();

    var company = $("#company-select").data("company");
    $("#company-select").val(company);

    var address = $("#company_address").data("address");
    $("#company_address").val(address);

    var city = $("#company_city").data("city");
    $("#company_city").val(city);

    var state = $("#company_state").data("state");
    $("#company_state").val(state);

    var zip = $("#company_zip").data("zip");
    $("#company_zip").val(zip);

    var email = $("#company_email").data("email");
    $("#company_email").val(email);

    var ein = $("#company_ein").data("ein");
    $("#company_ein").val(ein);

    var phone = $("#company_phone").data("phone");
    $("#company_phone").val(phone);

    var url = $("#company_url").data("url");
    $("#company_url").val(url);

    var payableName = $("#account_payable_name").data("payable-name");
    $("#account_payable_name").val(payableName);

    var payablePhone = $("#account_payable_phone").data("payable-phone");
    $("#account_payable_phone").val(payablePhone);

    var payableEmail = $("#account_payable_email").data("payable-email");
    $("#account_payable_email").val(payableEmail);

    var approverName = $("#invoice_approver_name").data("approver-name");
    $("#invoice_approver_name").val(approverName);

    var approverPhone = $("#invoice_approver_phone").data("approver-phone");
    $("#invoice_approver_phone").val(approverPhone);

    var approverEmail = $("#invoice_approver_email").data("approver-email");
    $("#invoice_approver_email").val(approverEmail);

    var executiveName = $("#executive_contact_name").data("executive-name");
    $("#executive_contact_name").val(executiveName);

    var executivePhone = $("#executive_contact_phone").data("executive-phone");
    $("#executive_contact_phone").val(executivePhone);

    var executiveEmail = $("#executive_contact_email").data("executive-email");
    $("#executive_contact_email").val(executiveEmail);
});

$(function () {
    $("input[type='checkbox']").change(function () {
        var check = $(this)
            .siblings("ul")
            .find("input[type='checkbox']")
            .prop("disabled");
        if (check == true) {
            $(this)
                .siblings("ul")
                .find("input[type='checkbox']")
                .prop("disabled", false)
                .change();
            //.prop('checked', true);

            $(this)
                .siblings("ul")
                .find("input[type='number']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[type='text']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='originalPrice[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='managerPrice[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='jimPrice[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='name[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='id[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='prod_header_id[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='reason[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("textarea[name='description[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='price_name[]']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='batch_code[]']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='vast_code[]']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='sla[]']")
                .prop("disabled", true);
        } else {
            $(this)
                .siblings("ul")
                .find("input[type='checkbox']")
                .prop("disabled", true)
                .prop("checked", false)
                .change();

            $(this)
                .siblings("ul")
                .find("input[type='number']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[type='text']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='originalPrice[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='managerPrice[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='jimPrice[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='name[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='id[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='prod_header_id[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='reason[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("textarea[name='description[]']")
                .prop("disabled", true);

            $(this)
                .siblings("ul")
                .find("input[name='price_name[]']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='batch_code[]']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='vast_code[]']")
                .prop("disabled", true);
            $(this)
                .siblings("ul")
                .find("input[name='sla[]']")
                .prop("disabled", true);
        }
    });

    $("input[class='cc-box']").change(function () {
        var disabled = $(this)
            .parent()
            .next("div")
            .find("input[name^='price[']")
            .prop("disabled");
        if (disabled == true) {
            $(this)
                .parent()
                .next("div")
                .find("input[name^='price[']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='use_quote[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='originalPrice[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='managerPrice[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='jimPrice[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='name[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='id[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='prod_header_id[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='reason[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("textarea[name='description[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='price_name[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='batch_code[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='vast_code[]']")
                .prop("disabled", false);
            $(this)
                .parent()
                .next("div")
                .find("input[name='sla[]']")
                .prop("disabled", false);
        } else {
            $(this)
                .parent()
                .next("div")
                .find("input[name^='price[']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='use_quote[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='originalPrice[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='managerPrice[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='jimPrice[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='name[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='id[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='prod_header_id[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='reason[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("textarea[name='description[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='price_name[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='batch_code[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='vast_code[]']")
                .prop("disabled", true);
            $(this)
                .parent()
                .next("div")
                .find("input[name='sla[]']")
                .prop("disabled", true);
        }
    });

    $.validator.addMethod(
        "decimal",
        function (value, element) {
            if (
                $(element)
                    .parent()
                    .parent()
                    .find("input[class='cc-box']")
                    .data("quote") == 1
            )
                return true;

            return /^((\d+(\\.\d{0,2})?)|((\d*(\.\d{1,6}))))$/.test(value);
        },
        "Please enter a correct number, format 0.000000"
    );

    $.validator.addMethod(
        "minimumPrice",
        function (value, element) {
            if (
                $(element)
                    .parent()
                    .parent()
                    .find("input[class='cc-box']")
                    .data("quote") == 1
            )
                return true;

            return value >= 0;
        },
        "Price can not be negative"
    );

    $("#contract_information_form").submit(function (e) {
        if (!$(this).hasClass("product-sheet-form")) {
            e.preventDefault();

            if (!$(this).valid()) {
                return;
            }

            let count = 0;
            let underThresholdItems = [];
            $("input[name='jimPrice[]']").each((i, priceInput) => {
                if ($(priceInput).is(":disabled")) return;

                let priceThreshold = parseFloat($(priceInput).val());
                let currentPrice = parseFloat(
                    $(priceInput).parent().find("[name^='price[']").val()
                );

                if (isNaN(currentPrice) || isNaN(priceThreshold)) return;
                if (priceThreshold == 0) return;

                let productHeaderId = $(priceInput)
                    .parent()
                    .find("[name='prod_header_id[]']")
                    .val();
                let name = $(priceInput).parent().find("[name='name[]']").val();

                if (
                    (productHeaderId === "11" &&
                        parseFloat(currentPrice.toFixed(4)) >
                            parseFloat(priceThreshold.toFixed(4))) ||
                    (productHeaderId !== "11" &&
                        parseFloat(currentPrice.toFixed(4)) <
                            parseFloat(priceThreshold.toFixed(4)))
                ) {
                    let entry = {
                        id: count++,
                        price: currentPrice,
                        threshold: priceThreshold,
                        name: name,
                    };

                    underThresholdItems.push(entry);
                }
            });

            if (underThresholdItems.length > 0) {
                let inputMarkup = `<p style="font-size: 14px;">We need some more information behind the pricing of the products on this contract.<br><br>Please follow the directions below:</p>`;
                underThresholdItems.forEach((entry) => {
                    inputMarkup += `<p style="font-size:13">Reason for pricing '<b>${entry.name}</b>' @ <b>${entry.price}</b>: <span style="color:red; font-size:10px">&#10033;</span></p> <input class="form-control reason" name="reason${entry.id}" type="text" placeholder="Reason..." />\n<br>\n`;
                });

                swal.fire({
                    title: "Price Reasoning",
                    html: inputMarkup,
                    showCloseButton: true,
                    showCancelButton: true,
                    focusConfirm: true,
                    confirmButtonText: '<i class="fa fa-thumbs-up"></i> Submit',
                    cancelButtonText: '<i class="fa fa-thumbs-down"></i>',
                    onOpen: () => {
                        $(swal.getConfirmButton()).prop("disabled", true);
                        $(".reason").unbind();
                        $(".reason").on("keyup", () => {
                            let toDisable = false;
                            $(".reason").each((i, input) => {
                                if ($(input).val() == "") {
                                    $(swal.getConfirmButton()).prop(
                                        "disabled",
                                        true
                                    );
                                    toDisable = true;
                                    return false;
                                }
                            });
                            if (!toDisable) {
                                $(swal.getConfirmButton()).prop(
                                    "disabled",
                                    false
                                );
                            }
                        });
                    },
                }).then((value) => {
                    if (value.isConfirmed) {
                        underThresholdItems.forEach((entry) => {
                            let selectedProduct = $(
                                `input[name='name[]'][value='${entry.name}']`
                            );
                            let reason = $(
                                `input[name='reason${entry.id}']`
                            ).val();

                            selectedProduct
                                .parent()
                                .find("input[name='reason[]']")
                                .val(reason);
                        });

                        if (!$(this).hasClass("no-loading"))
                            $.LoadingOverlay("show");
                        var form = $(this);
                        form.find("[name^='price[']").attr("name", "price[]");
                        $(this).unbind("submit").submit();
                        return;
                    } else {
                        swal.fire(
                            "Cancelled",
                            "Contract generation was cancelled!",
                            "error"
                        );
                        return;
                    }
                });
            } else {
                if (!$(this).hasClass("no-loading")) $.LoadingOverlay("show");
                var form = $(this);
                form.find("[name^='price[']").attr("name", "price[]");
                $(this).unbind("submit").submit();
            }
        }
    });

    $("#contract_information_form").validate({
        // initialize the plugin
        rules: {
            company_name: {
                required: true,
            },
            company_address: {
                required: true,
            },
            email: {
                required: true,
                email: true,
            },
            company_state: {
                required: true,
            },
            company_city: {
                required: true,
            },
            company_zip: {
                required: true,
            },
            company_email: {
                required: true,
            },
            original_date: {
                required: true,
            },
            new_name: {
                required: true,
            },
        },
        invalidHandler: function (event, validator) {
            var errors = validator.numberOfInvalids();
            if (errors) {
                $.LoadingOverlay("hide");
            } else {
                $.LoadingOverlay("show");
            }
        },
    });
});

$(function () {
    $(".product-button").on("click", function (event) {
        event.preventDefault();
        var isEnabled = $(this).data("enabled");
        var check = $("#pc-" + $(this).val());

        if (isEnabled == "true" || isEnabled == true) {
            $(check).prop("checked", true);

            $(check)
                .siblings("ul")
                .find("input[type='checkbox']")
                .prop("checked", true)
                .change();

            $("#pc-ul-" + $(this).val() + " li").each(function () {
                $(this).find(":input").prop("disabled", false);
            });

            $(this).data("enabled", "false");
            $(this).text("Deselect All");
        } else {
            $(check).prop("checked", false);

            $(check)
                .siblings("ul")
                .find("input[type='checkbox']")
                .prop("checked", false)
                .change();

            $("#pc-ul-" + $(this).val() + " li").each(function () {
                $(this).find(":input").prop("disabled", true);
            });

            $(this).data("enabled", "true");
            $(this).text("Select All");
        }
    });
});

$(function () {
    $(".pc-box").on("change", function (event) {
        event.preventDefault();
        var isEnabled = $(this).prop("checked");
        var btn = $("#pc-btn-" + $(this).data("pc"));

        if (isEnabled) {
            btn.text("Deselect All");
            btn.data("enabled", "false");
        } else {
            btn.text("Select All");
            btn.data("enabled", "true");
        }
    });

    $("input[name^='price[']").on("change", function () {
        $("#contract_information_form").validate().element($(this));
    });

    $(".cc-box").on("change", function () {
        // var time = new Date();
        var priceInput = $(this).parent().parent().find('[name^="price["]');
        if ($(this).prop("checked")) {
            if ($(this).data("quote") != "1") {
                $(priceInput).rules("add", {
                    required: true,
                    minimumPrice: true,
                    decimal: true,
                });
            }
        } else {
            $(priceInput).rules("remove");
        }

        $("#contract_information_form").validate().element(priceInput);

        if (!$(this).prop("checked")) {
            $(priceInput).removeClass("error");
            $(priceInput).removeClass("valid");
        }

        // var finished = new Date();
        // console.log(finished.getMilliseconds() - time.getMilliseconds());
        // 1-3 MS
    });
});
