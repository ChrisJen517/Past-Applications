$().ready(function () {
    $("#Update").submit(function () {
        $('#myModalUpdateBody').LoadingOverlay("show");
    });
    $("#personal-info").validate();
    // validate signup form on keyup and submit
    $("#Update").validate({

        rules: {
            name: "required",
            first_name: "required",
            last_name: "required",
            new_goal: "required",
            employer_name: 'required',
            c_password: {
            },
            email: {
                required: true,
                email: true
            },
        },
        messages: {
            name: "Please enter a firstname",
            first_name: "Please enter a First Name",
            last_name: "Please enter a Last Name",
            email: "Please enter a valid email address",
            new_goal: "Please enter a goal"
        },
        invalidHandler: function (event, validator) {
            // 'this' refers to the form
            var errors = validator.numberOfInvalids();
            if (errors) {
                $('#myModalUpdateBody').LoadingOverlay("hide");
            } else {
                $('#myModalUpdateBody').LoadingOverlay("show");
            }
        }
    });


    jQuery.validator.addMethod("passwordCorrectRules", function (value, element) {
        return this.optional(element) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,32}$/.test(value);
    }, "Must follow password rules");


    $('input[name=newPassword]').focus(function () {
        $('#pswd_info').show();
    });
});


//only show overlay if form is valid
$(document).ready(function (e) {
    $("#submit").click(function () {
        if ($("#Update").valid()) {
            $.LoadingOverlay("show");
        }
    })
})


$(document).ready(function (e) {
    $("#submit-button-2").click(function () {
        if ($("#Update").valid()) {
            $.LoadingOverlay("show");
        }
    })
})



$('#newPassword').keyup(function () {
    if ($(this).val() == '') {
        $('#pswd_info').hide();
    } else {
        $('#pswd_info').show();
    }
});
 
function showPassword() {
    var x = document.getElementById("newPassword");
    var y = document.getElementById("c_password");
    if (x.type === "password") {
        x.type = "text";
        y.type = "text";
    } else {
        x.type = "password";
        y.type = "password";
    }
}

function check_pass() {
    var pswd = document.getElementById('newPassword').value;
    document.getElementById("submit").disabled = false;

    if (pswd.length < 10 && pswd.length < 33) {
        $('#length').removeClass('valid').addClass('invalid');
        document.getElementById("submit").disabled = true;
    } else {
        $('#length').removeClass('invalid').addClass('valid');
    }
    //validate capital letter
    if (pswd.match(/[A-Z]/)) {
        $('#letter_upper').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_upper').removeClass('valid').addClass('invalid');
        document.getElementById("submit").disabled = true;
    }

    //validate lowercase letter
    if (pswd.match(/[a-z]/)) {
        $('#letter_lower').removeClass('invalid').addClass('valid');
    } else {
        $('#letter_lower').removeClass('valid').addClass('invalid');
        document.getElementById("submit").disabled = true;
    }

    //validate number
    if (pswd.match(/\d/)) {
        $('#number').removeClass('invalid').addClass('valid');
    } else {
        $('#number').removeClass('valid').addClass('invalid');
        document.getElementById("submit").disabled = true;
    }

    //validate special character
    if (pswd.match(/^(?=.*?[?!@$%^&*-])/)) {
        $('#special').removeClass('invalid').addClass('valid');
    } else {
        $('#special').removeClass('valid').addClass('invalid');
        document.getElementById("submit").disabled = true;
    }

    if(pswd == "")
        document.getElementById("submit").disabled = false;

    if (document.getElementById('newPassword').value ==
        document.getElementById('c_password').value) {
        document.getElementById('message').style.color = 'green';
        document.getElementById('message').innerHTML = 'Matching';
    } else {
        document.getElementById('submit').disabled = true;
        document.getElementById('message').style.color = 'red';
        document.getElementById('message').innerHTML = 'Not Same';
    }
}

//check file size and type for avatar upload
$(document).ready(function () {
    $('#avatar').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileSize = $(this).get(0).files[0].size;
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            if (fileSize > 51200) //check file size
            {
                swal({
                    title: "File size too large!",
                    text: "Image size cannot exceed 50kb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }

            else if (ext != '.jpg' && ext != '.jpeg' && ext != '.png') //check file extension type
            {

                swal({
                    title: "Wrong file type",
                    text: "Must be .jpg, .jpeg, or .png",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }
        }
    })
});


//validate csv file for account uploads
$(document).ready(function () {
    $('#accountUpload').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;


            if (ext != '.csv') //check file extension type
            {

                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }

            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "Image size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }

        }

    })
});

//confirm file exists for account upload
$("#submitAccountUpload").click(function (e) {
    if (($("#accountUpload").val() == "") || ($("#uploadUnactive").val() == "")) {
        e.preventDefault();
        swal({
            title: "Please select a file for uploading!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
    }
})

//validate csv file for test uploads
$(document).ready(function () {
    $('#testMappingFile').on('change', function () {
        if ($(this).get(0).files.length > 0) { // only if a file is selected
            var fileName = $(this).get(0).files[0].name;
            var index = fileName.lastIndexOf('.');
            var ext = fileName.substring(index);
            var fileSize = $(this).get(0).files[0].size;


            if (ext != '.csv') //check file extension type
            {

                swal({
                    title: "Wrong file type",
                    text: "Must be .csv",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                $(this).val("");

            }

            else if (fileSize > 52428800) //check file size
            {
                console.log(fileSize)
                swal({
                    title: "File size too large!",
                    text: "Image size cannot exceed 50mb",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })

                $(this).val("");
            }

        }

    })
});

//confirm file exists for test upload
$("#testMappingSubmit").click(function (e) {

    if ($("#testMappingFile").val() == "") {
        e.preventDefault();
        swal({
            title: "Please select a file for uploading!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
    }
})

