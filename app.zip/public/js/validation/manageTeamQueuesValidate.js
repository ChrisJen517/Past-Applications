$().ready(function () {

    $("#manage_queues_form").validate({

        rules: {
            agent_selected: "required",
            "send_to_agent[]": "required",
        },
        messages: {
            agent_selected: "Please Select an Agent",
            "send_to_agent[]": "Please Select an Agent to Send Accounts"
        },
    
    });
    
    $('#recall-submit').click(function(event){
        
        var case_number = $("select#case_number option:checked").val();
        var client_id = $( "select#client_id option:checked" ).val();
        var source_code = $( "select#source_code option:checked" ).val();
        var recall_score_select = $( "select#recall_score_select option:checked" ).val();

        if(case_number != '' || client_id != '' || source_code != '' || recall_score_select != '')
            recallSWAL(case_number, client_id, source_code, recall_score_select);
        else
            $('#need_one_recall').show();

    })

         
    function recallSWAL(case_number, client_id, source_code, recall_score_select) {
        var message = "You are unassigning all Active Accounts that are in ";
        var count = 0;
        if(client_id != ''){
            message = message+"Client ID: "+client_id;
            count = count + 1;
        }
        
        if(source_code != '')
        {
            if(count > 0)
                message = message+", Source Code: "+source_code;
            else{
                message = message+"Source Code: "+source_code;
                count = count + 1;
            }     
        }
        
        if(recall_score_select != '')
        {
            if(count > 0){
                message = message+", Score: "+recall_score_select;
            }
            else{
                message = message+"Score: "+recall_score_select;
                count = count + 1;
            }      
        }
        
        if(case_number != '')
        {
            if(count > 0){
                message = message+", Case Number: "+case_number+".";
            }
            else{
                message = message+"Case Number: "+case_number+".";
                count = count + 1;
            }      
        }

        swal({
          title: "Are you sure?",
          text: message,
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $('#recallForm').submit();

          } else {
            swal("Accounts not unassigned");
            return false;
        }
        });
        }

    $('#releaseButton').click(function(event){
        var release_option = $("input[name='recallOption']:checked").val();
        var case_select = $("select#case_num option:checked").val();
        var tier_value = $("select#tier_value option:checked").val();
        var score = $('#score option:selected').attr('id');
        var team_id = $('#team_id option:selected').attr('id');

        if(release_option == 'case')
        {
            if(case_select != '')
                releaseAccountsSWAL(release_option, case_select, tier_value, score, team_id);
            else
                $('#need_one_release').show();
        }
        else
            releaseAccountsSWAL(release_option, case_select, tier_value, score, team_id);
    })

    
         
function releaseAccountsSWAL(release_option, case_select, tier_value, score, team_id) {

    var message = "You will be distributing all Active Accounts to "+team_id+" that have a Score of "+score;
    if(release_option == 'case')
        message = message+" and have the Case Number: "+case_select+".";
    else if(release_option == 'tier')
        message = message+" and have Tier Value "+tier_value+" and Above.";
    
    swal({
      title: "Are you sure?",
      text: message,
      icon: "warning",
      buttons: true,
      dangerMode: true,
    })
    .then((willDelete) => {
      if (willDelete) {
        $('#releaseForm').submit();
      } else {
        swal("Accounts Not Distributed!");
      }
    });
    }

    function tossAgentsSwal(agent_selected) {

        var message = "You will be distributing Active Accounts of "+agent_selected+" to other Team Members";

        swal({
          title: "Are you sure?",
          text: message,
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            $("#accounts_submit").submit();
          } else {
            swal("Accounts Not Distributed!");
            return 'false';  
          }
        });
        }
    //only show overlay if form is valid
$(document).ready(function (e) {
    $("#accounts_submit").click(function (e) {
        if($("#manage_queues_form").valid()){
            e.preventDefault();
            var agent_selected = $('#agent_selected option:selected').attr('id');

            var message = "You will be distributing Active Accounts of "+agent_selected+" to other Team Members";

            swal({
                title: "Are you sure?",
                text: message,
                icon: "warning",
                buttons: true,
                dangerMode: true,
              })
              .then((willDelete) => {
                if (willDelete) {
                  $("#manage_queues_form").submit();
                } else {
                  swal("Accounts Not Distributed!");
                  return 'false';  
                }
              });            
            
        }
    })  
})


});