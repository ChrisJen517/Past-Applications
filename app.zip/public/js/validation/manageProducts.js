$(document).ready(function() {
    $.validator.addMethod(
        "decimal",
        function(value, element) {
            return (
                this.optional(element) ||
                /^((\d+(\\.\d{0,2})?)|((\d*(\.\d{1,4}))))$/.test(value)
            );
        },
        "Please enter a correct number, format 0.0000"
    );

    $(".needsValidated").each(function() {
        $(this).validate({
            rules: {
                name: {
                    required: true,
                    maxlength: 100
                },
                description: {
                    required: true,
                    maxlength: 1000
                },
                price: {
                    required: true,
                    decimal: true
                },
                manager_price_1: {
                    required: true,
                    decimal: true
                },
                manager_price_2: {
                    required: true,
                    decimal: true
                },
                batch_code: {
                    maxlength: 15
                },
                vast_code: {
                    maxlength: 5
                }
            }
        });
    });
});
