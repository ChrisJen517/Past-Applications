$().ready(function () {
    $("#add_capcode_form").validate({

        rules: {
            name: "required",
            capcode: {
                required: true,
              
            },
           
        },
        messages: {
            name: "Please enter a name",
            capcode: {
                required: "Please enter a unique capcode",
            },
            

        },
        invalidHandler: function (event, validator) {
            // 'this' refers to the form
            var errors = validator.numberOfInvalids();
            if (errors) {
                $('#myModalAddBody').LoadingOverlay("hide");
            } else {
                $('#myModalAddBody').LoadingOverlay("show");
            }
        }


    });

});