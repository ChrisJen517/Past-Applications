$().ready(function () {

    $("#corporationAddTeam").validate({

        rules: {
            teamName: "required",

        },
        messages: {
            teamName: "Please enter a unique team name",
        },

    });

    

});


//only show overlay if form is valid
$(document).ready(function (e) {
    $("#create-team-button").click(function () {
        if ($("#corporationAddTeam").valid()) {
            $.LoadingOverlay("show");
        }
    })
})