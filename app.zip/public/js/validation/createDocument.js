$().ready(function () {
    $("#createSupportDocumentForm").validate({
        rules: {
            document_name: "required",
            description: "required",
            file_name: "required",
        },
        messages: {
            document_name: "Please enter a document name",
            description: "Please enter a description",
            file_name: "Please upload a file",
        }
    });
});
