$("#supportRequestForm").validate({

    rules: {
        supportRequestTitle: "required",
        supportRequestMessage: "required",
       
    },
    messages: {
        supportRequestTitle: "Please enter a title",
        supportRequestMessage: "Please enter a message",
       
    },
    invalidHandler: function (event, validator) {
        // 'this' refers to the form
        var errors = validator.numberOfInvalids();
        if (errors) {
            $('#supportRequest').LoadingOverlay("hide");
        } else {
            $('#supportRequest').LoadingOverlay("show");
        }
    }
});    

$("#submitSupportRequest").click(function(){
    if($("#supportRequestForm").valid()){
        $.LoadingOverlay("show")
    }
})
    
    