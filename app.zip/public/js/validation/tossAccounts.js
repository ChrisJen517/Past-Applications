$().ready(function() {
    $("#tossAccounts").validate({
        rules: {
            id: {
                required: true,
                digits: true
            },
            accounts: {
                required: true,
                digits: true
            }
        },
        messages: {
            id: "Please enter an agent",
            accounts: "Please enter a number of accounts"
        }
    });
});
