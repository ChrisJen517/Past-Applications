$().ready(function () {
    $("#createProductHeader").validate({
        rules: {
            header_name: "required",
            column_1: "required",
            column_2: "required",
            column_3: "required"
        },
        messages: {
            header_name: "Please enter a header name",
        }
    });
});
