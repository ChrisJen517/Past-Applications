$().ready(function() {
    
   // validate signup form on keyup and submit
    $("#adminAddAccount").validate({

        rules: {
            first_name: "required",
            last_name: "required",
            email: {
                required: true,
                email: true
            },
            manager: "required",
            team: "required",
            corporation: "required"
        },
        messages: {
            name: "Please enter your name",
            first_name: "Please enter a name",
            last_name: "Please enter a last name",
            email: "Please enter a valid email address",
            },
            
    });

});

 
//only show overlay if form is valid
$(document).ready(function (e) {
    $("#addAccountButton").click(function () {
        if ($("#adminAddAccount").valid()) {
            $("#adminAddAccount").LoadingOverlay("show");
        }
    })
})