$().ready(function() {
    
    $("#personal-info").validate();

   // validate signup form on keyup and submit
    $("#Update").validate({
        rules: {
            first_name: "required",
            last_name: "required",
            name: "required",
            newPassword: {
                passwordCorrectRules: function(element) {
                    return $("#newPassword").val()!="";
                    }
            },
            host: {
                required: true,
            },
            port: {
                required: true,
            },

        },
        messages: {
            name: "Please enter your name",
            first_name: "Please enter your First Name",
            last_name: "Please enter your Last Name",
            newPassword: {
                minlength: "Your password must be at least 5 characters long"
            },
            },
    });

    jQuery.validator.addMethod("passwordCorrectRules", function(value, element) {
        return this.optional(element) || /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{10,32}$/.test(value);
    }, "Must follow password rules");

});
