$().ready(function () {

    $("#databaseMapping").validate({

        rules: {
            ACCT_DUE_DATE: "required",
            ACCT_SSN: "required",
            ACCT_ID: "required",

        },
        messages: {

            ACCT_DUE_DATE: "Please enter a header for Account Due Date",
            ACCT_SSN: "Please enter a header for Account SSN",
            ACCT_ID: "Please enter a header for Account ID",

        },
        errorPlacement: function (error, element) {

            var el = element.parent().parent();
            error.appendTo(el);

        }

    });



});


//only show overlay if form is valid
$(document).ready(function (e) {
    $("#mappingSubmit").click(function () {
        if ($("#databaseMapping").valid()) {
            $.LoadingOverlay("show");
        }
    })
})