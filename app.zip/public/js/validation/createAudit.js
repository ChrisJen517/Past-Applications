$().ready(function () {
    $("#createAuditForm").validate({
        rules: {
            audit_name: "required",
            account_manager: "required",
            client_id: "required",
            due_date: "required",
        },
        messages: {
            audit_name: "Please enter an audit name",
            account_manager: "Please enter an account manager",
            client_id: "Please select a client",
            due_date: "Please select a due date",
        }
    });

    $('#createAudit').on('hide.bs.modal', function(e) {
        var validator = $( "#createAuditForm" ).validate();
        validator.resetForm();
    });

});
