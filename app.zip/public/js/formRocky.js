$('#datetimepicker').datetimepicker({
    minDate: 0,
    inline: true,
    sideBySide: true,
    formatTime: 'g:iA',
    format: 'Y-m-d h:i',
    step: 30
});

//change value for save & open next
$("#saveOpenNext").click(function (e) {
    $("#open_next").val(1);
})



//change verification attempts color
$(document).ready(function () {
    var number = $("#countAttempts").data('count');
    if (number < 3)
        $('#attempts').css('color', 'green');
    else if (number > 4)
        $('#attempts').css('color', 'red');
    else
        $('#attempts').css('color', 'orange');
});

//stretch top bar text when sidebar collapsed
$(document).ready(function () {

    $('.toggle-menu').click(function () {
        $("#account_info").toggleClass('account_info');
        $("#rules_div").toggleClass('rules_div');

    });
});

//link capcode dropdowns
$("#CAPCODE").change(function () {
    $("#verified_capcode").val($(this).val());
});

$("#verified_capcode").change(function () {
    $("#CAPCODE").val($(this).val());
});

//toggle inputs for future verification field
$(document).ready(function () {
    $(".form-check-input").click(function () {
        var id = $(this).attr('id');
        $('#future_selection .form-control').each(function () {
            if (!$(this).parent().parent().parent().hasClass('future_selection')) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
            if ($(this).hasClass(id)) {
                $(this).parent().parent().parent().toggleClass('future_selection');
            }
        })
    })
})
//copy input fields to verified form
$(document).ready(function () {
    $('.input-clipboard').click(function () {

        var input = $(this).parent().find('.form-control');
        var inputVal = input.val();
        var inputId = input.attr('id');
        //split address and copy to verified column
        if (inputId == 'empl_addr1') {


            var address = $("#empl_addr1").data('address');
            var city = $("#empl_addr1").data('city');
            var state = $("#empl_addr1").data('state');
            var zip = $("#empl_addr1").data('zip');

            state = state.charAt(0).toUpperCase() +
                state.slice(1);

            //check if state is two words
            if (state.indexOf(' ') >= 0) {
                index = state.indexOf(' ');
                var cap = state.charAt(index + 1).toUpperCase() + state.slice(index + 2);
                var first = state.slice(0, index);
                state = first + " " + cap;
            }
            //convert state value if abbreviated
            if (state.length == 2) {

                state = convertState(state);
            }

            $("#empl_addr1_verified").val(address);
            $("#empl_city_verified").val(city);
            $("#company_state").val(state);
            $("#empl_zip_verified").val(zip);
        }
        else if (inputId != 'empl_addr1') {

            $("#verified_form .form-control").each(function () {
                if ($(this).hasClass(inputId + '_verified')) {
                    $(this).val(inputVal);
                }
            })
        }
    })

})

//google search buttons
$(document).ready(function () {
    $(".input-google").click(function () {
        var input = $(this).parent().find('.form-control').val();
        if (input != '') {
            window.open('https://www.google.com/search?q=' + input, '_blank');
        }
    })
})

//website link button
$(document).ready(function () {
    $(".input-link").click(function () {
        var input = $(this).parent().find('.form-control').val();
        if (input != '') {
            if (!input.includes("https://www."))
                input = "https://www." + input;

            window.open(input, '_blank');
        }
    })
});

//Update active account with verified data
$(document).ready(function () {

    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("#saveOpenNext").click(function () {
        if ($('#verified_capcode').val() == '') {
            swal('Please select a capcode!', {
                dangerMode: true
            });
            return
        }
        swal({
            title: "Are you sure?",
            text: "Please click OK to confirm changes",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willChange) => {
            if (willChange) {
                $.LoadingOverlay('show');
                $("#verified_form").submit();
            }
            else{
                swal("Lead not updated!");
            }
        });
    })
    $("#verified_submit, #saveUpdate").on('click', function (e) {
        if ($('#verified_capcode').val() == '') {
            swal('Please select a capcode!', {
                dangerMode: true
            });
            return

        }

        var account_id = $("#account_id").val();
        var empl_name_verified = $("#empl_name_verified").val();
        var empl_ph_nmbr_verified = $("#empl_ph_nmbr_verified").val();
        var empl_addr1_verified = $("#empl_addr1_verified").val();
        var empl_addr2_verified = $("#empl_addr2_verified").val();
        var empl_city_verified = $("#empl_city_verified").val();
        var company_state = $("#company_state").val();
        var empl_zip_verified = $("#empl_zip_verified").val();
        var empl_title_verified = $("#empl_title_verified").val();
        var empl_fax_verified = $("#empl_fax_verified").val();
        var empl_email_verified = $("#empl_email_verified").val();
        var empl_contact_verified = $("#empl_contact_verified").val();
        var empl_contact_title_verified = $("#empl_contact_title_verified").val();
        var verified_capcode = $("#verified_capcode").val();
        var type = $("#type").val();
        var open_next = $("#open_next").val();
        var corporation_id = $("#corporation_id").val();
        var note = $("#note").val();
        var time = $("#datetimepicker").val();
        swal({
            title: "Are you sure?",
            text: "Please click OK to confirm changes",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willChange) => {
            if (willChange) {

                $.LoadingOverlay('show');
                $.post("/agent/updateAccount", {
                    account_id: account_id,
                    empl_name_verified: empl_name_verified,
                    empl_ph_nmbr_verified: empl_ph_nmbr_verified,
                    empl_addr1_verified: empl_addr1_verified,
                    empl_addr2_verified: empl_addr2_verified,
                    empl_city_verified: empl_city_verified,
                    company_state: company_state,
                    empl_zip_verified: empl_zip_verified,
                    empl_title_verified: empl_title_verified,
                    empl_fax_verified: empl_fax_verified,
                    empl_email_verified: empl_email_verified,
                    empl_contact_verified: empl_contact_verified,
                    empl_contact_title_verified: empl_contact_title_verified,
                    verified_capcode: verified_capcode,
                    type: type,
                    open_next: open_next,
                    corporation_id: corporation_id,
                    note: note,
                    time: time
                }, function (data, status) {

                    var history = JSON.parse(data);
                    if (history['closed']) {
                        $.LoadingOverlay('hide');
                        swal("Lead Closed Successfully!", {
                            icon: "success",
                            allowOutsideClick: false
                        });
                        var message = 'account has been closed';
                        window.location.href = '/agent/showActiveAccountsAfterClose';
                    }
                    else {
                        var date = history['date'];
                        date = date.replace('T', ' ');
                        date = date.substring(0, date.lastIndexOf('.'));
                        var time = '';
                        var notes = '';
                        if (history['time'] != null) {
                            time = history['time'];
                        }
                        if (history['notes'] != null) {
                            notes = history['notes'];
                        }
                        $("<tr><td class='text-center date'>" + date + "</td><td class='text-center'>" + history['agent_id'] + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center phone'>" + notes + "<td class='text-center'>" + time + "</td></tr>").insertAfter('#work_history_table tr:eq(1)');
                        $.LoadingOverlay('hide');
                        //clear values on save
                        $("#verified_form").trigger('reset');

                        swal("Lead Updated Successfully!", {
                            icon: "success"
                        });
                    }

                })


            }
            else {
                swal("Lead not updated!");
            }
        });
    });
});

//auto-update worked history based on call/fax/email actions
$(document).ready(function () {

    $('.input-phone').click(function (e) {

        var phone = $(this).parent().find('.form-control').val();

        var type = $("#type").val();
        if (phone == '') {
            swal("Please enter a phone number");
            return;
        }


        var number = $("#count").html();
        var max_attempts = $("#max_attempts").val();

        if (number >= max_attempts) {
            swal("You have reached the limit of work attempts permitted for this account!",
                {
                    dangerMode: true
                })
            return;
        }

        checkCallAttempts(phone);


    });
    //increment attempts on page and change color accordingly
    function incrementAttempts() {
        $("#count").html(parseInt($('#count').html(), 10) + 1);
        var number = $("#count").html();
        var max_attempts = $("#max_attempts").val();
        if (number < 3)
            $('#attempts').css('color', 'green');
        else if (number > 4)
            $('#attempts').css('color', 'red');
        else
            $('#attempts').css('color', 'orange');

        if (number >= max_attempts) {
            $("#inactivate_form").submit();
        }
    }

    //check the number of attempts and give warning if greater than 0 in 24 hours
    function checkCallAttempts(newPhone) {
        var date = new Date();
        var count = 0;
        var result = '';
        
        $('.date').each(function () {
            var historyDate = $(this).html()
            historyDate = historyDate.substring(0, historyDate.lastIndexOf(' '));
            historyDate = historyDate.replace(/-/g, '/');
            var newDate = new Date(historyDate);
            var timeDiff = date.getTime() - newDate.getTime();
            var diffDays = timeDiff / (1000 * 3600 * 24);

            var capcode = $(this).parent().find('.capcode').html();
            var phone = $(this).parent().find('.phone').html();
            phone = phone.substring(phone.lastIndexOf(':') + 2);
            phone = phone.replace(/[^0-9]/g, '');
            newPhone = newPhone.replace(/[^0-9]/g, '');
            
            if (capcode == 2210 && diffDays <= 1 && phone == newPhone) {
                count++;
            }

        })
        if(count == 0){
            var note = "Called phone number: " + newPhone;
            $("#note").val(note);
        }

        if (count > 0) {
            swal({
                title: "Warning: You Have Called This Number " + count + " time(s) in the last 24 hours.",
                text: "Are You Sure You Want to Continue?",
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((willChange) => {
                if (willChange) {
                    //copy note to notes field
                    var note = "Called phone number: " + newPhone;
                    $("#note").val(note);

                    incrementAttempts();

                    var id = $("#account_history_id").val();
                    newPhone = newPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");
                    var note = 'Called phone number: ' + newPhone;
                    var type = $("#type").val();
                    $("#lead_data").LoadingOverlay('show', { zIndex: 0 });
                    $("#powerlead_data").LoadingOverlay('show', { zIndex: 0 });
                    $.post('/agent/incrementHistory',
                        {
                            phone: newPhone,
                            id: id,
                            note: note,
                            type: type
                        },
                        function (data, status) {
                            var history = JSON.parse(data);
                            var date = history['date'];
                            date = date.replace('T', ' ');
                            date = date.substring(0, date.lastIndexOf('.'));
                            $("<tr><td class='text-center date'>" + date + "</td><td class='text-center'>" + history['agent_id'] + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center phone'>" + history['notes'] + "</td><td class='text-center'></td><td class='text-center'></td></tr>").insertAfter('#work_history_table tr:eq(1)');
                            $("#lead_data").LoadingOverlay('hide');
                            $("#powerlead_data").LoadingOverlay('hide');
                        })

                }
                else {
                    swal("Call Cancelled");
                    result = false;
                }
            });
        } else {
            incrementAttempts();
            newPhone = newPhone.replace(/(\d{3})(\d{3})(\d{4})/, "$1-$2-$3");

            var id = $("#account_history_id").val();
            var note = 'Called phone number: ' + newPhone;

            $.post('/agent/incrementHistory',
                {
                    phone: newPhone,
                    id: id,
                    note: note
                },
                function (data, status) {
                    var history = JSON.parse(data);
                    var date = history['date'];
                    date = date.replace('T', ' ');
                    date = date.substring(0, date.lastIndexOf('.'));
                    $("<tr><td class='text-center date'>" + date + "</td><td class='text-center'>" + history['agent_id'] + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center phone'>" + history['notes'] + "</td><td class='text-center'></td><td class='text-center'></td></tr>").insertAfter('#work_history_table tr:eq(1)');
                })
        }
        return result;
    }
});




$(document).ready(function () {
    $('.input-fax').click(function () {
        var fax = $(this).parent().parent().find('.form-control').val();
        if (fax == '') {
            return;
        }
        //copy note to notes field
        var note = "Sent fax to: " + fax;
        $("#note").val(note);

        var id = $("#account_history_id").val();
        var note = 'Sent fax to: ' + fax;

        $.post('/agent/incrementHistory',
            {
                fax: fax,
                id: id,
                note: note
            },
            function (data, status) {
                var history = JSON.parse(data);
                var date = history['date'];
                date = date.replace('T', ' ');
                date = date.substring(0, date.lastIndexOf('.'));
                $("<tr><td class='text-center date'>" + date + "</td><td class='text-center'>" + history['agent_id'] + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center phone'>" + history['notes'] + "</td><td class='text-center'></td><td class='text-center'></td></tr>").insertAfter('#work_history_table tr:eq(1)');
            })
    })
})

$(document).ready(function () {

    $('.input-email').click(function () {
        var email = $(this).parent().find('.form-control').val();

        if (email == '') {
            return;
        }
        //copy note to notes field
        var note = "Sent email to: " + email;
        $("#note").val(note);

        var id = $("#account_history_id").val();
        var note = 'Sent email to: ' + email;

        $.post('/agent/incrementHistory',
            {
                email: email,
                id: id,
                note: note
            },
            function (data, status) {
                var history = JSON.parse(data);
                var date = history['date'];
                date = date.replace('T', ' ');
                date = date.substring(0, date.lastIndexOf('.'));
                $("<tr><td class='text-center date'>" + date + "</td><td class='text-center'>" + history['agent_id'] + "</td><td class='text-center capcode'>" + history['capcode'] + "</td><td class='text-center phone'>" + history['notes'] + "</td><td class='text-center'></td><td class='text-center'></td></tr>").insertAfter('#work_history_table tr:eq(1)');
            })
    })
});


function convertState(input) {

    var states = [
        ['Alabama', 'AL'],
        ['Alaska', 'AK'],
        ['American Samoa', 'AS'],
        ['Arizona', 'AZ'],
        ['Arkansas', 'AR'],
        ['Armed Forces Americas', 'AA'],
        ['Armed Forces Europe', 'AE'],
        ['Armed Forces Pacific', 'AP'],
        ['Canada', 'CAN'],
        ['California', 'CA'],
        ['Colorado', 'CO'],
        ['Connecticut', 'CT'],
        ['Delaware', 'DE'],
        ['District Of Columbia', 'DC'],
        ['Florida', 'FL'],
        ['Georgia', 'GA'],
        ['Guam', 'GU'],
        ['Hawaii', 'HI'],
        ['Idaho', 'ID'],
        ['Illinois', 'IL'],
        ['Indiana', 'IN'],
        ['Iowa', 'IA'],
        ['Kansas', 'KS'],
        ['Kentucky', 'KY'],
        ['Louisiana', 'LA'],
        ['Maine', 'ME'],
        ['Marshall Islands', 'MH'],
        ['Maryland', 'MD'],
        ['Massachusetts', 'MA'],
        ['Michigan', 'MI'],
        ['Minnesota', 'MN'],
        ['Mississippi', 'MS'],
        ['Missouri', 'MO'],
        ['Montana', 'MT'],
        ['Nebraska', 'NE'],
        ['Nevada', 'NV'],
        ['New Hampshire', 'NH'],
        ['New Jersey', 'NJ'],
        ['New Mexico', 'NM'],
        ['New York', 'NY'],
        ['North Carolina', 'NC'],
        ['North Dakota', 'ND'],
        ['Northern Mariana Islands', 'NP'],
        ['Ohio', 'OH'],
        ['Oklahoma', 'OK'],
        ['Oregon', 'OR'],
        ['Pennsylvania', 'PA'],
        ['Puerto Rico', 'PR'],
        ['Rhode Island', 'RI'],
        ['South Carolina', 'SC'],
        ['South Dakota', 'SD'],
        ['Tennessee', 'TN'],
        ['Texas', 'TX'],
        ['US Virgin Islands', 'VI'],
        ['Utah', 'UT'],
        ['Vermont', 'VT'],
        ['Virginia', 'VA'],
        ['Washington', 'WA'],
        ['West Virginia', 'WV'],
        ['Wisconsin', 'WI'],
        ['Wyoming', 'WY'],
    ];

    input = input.toUpperCase();
    for (i = 0; i < states.length; i++) {
        if (states[i][1] == input) {
            return (states[i][0]);
        }
    }

}

//fadeout error/success message
$(document).ready(function(){
    $(".message").delay(2500).fadeOut('slow');
})
