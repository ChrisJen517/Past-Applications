<?php

use App\Sales_Leads;
use Illuminate\Database\Seeder;

class SalesLeadsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(Sales_Leads::class, 150)->create();
    }
}
