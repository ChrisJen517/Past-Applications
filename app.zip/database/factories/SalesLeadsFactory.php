<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Model;
use App\Sales_Leads;
use Faker\Generator as Faker;
use Illuminate\Support\Str;

$factory->define(Sales_Leads::class, function (Faker $faker) {
    $industries = [
        'Bank: All Other',
        'Bank: Top 200',
        'Bank Association',
        'Collection Agency',
        'Collection Law Firm',
        'Consulting Company',
        'Credit Union',
        'Debt Buyer',
        'Financial Services',
        'Government: City',
        'Government: County',
        'Government: State',
        'Government: Federal',
        'Healthcare',
        'Loan Originator: Auto',
        'Loan Originator: Credit Card',
        'Loan Originator: FinTech',
        'Loan Originator: Mortgage',
        'Loan Originator: Other',
        'Loan Originator: Student Loan',
        'Other',
        'Private Equity Firm',
        'Service Provider',
        'Software',
        'University',
        'Vendor',
    ];

    return [
        'industry' => $faker->randomElement($industries, 1),
        'employees_count' => $faker->numberBetween(10, 500),
        'company_name' => $faker->company,
        'company_address' => $faker->streetAddress,
        'company_email' => $faker->companyEmail,
        'company_phone' => $faker->tollFreePhoneNumber,
        'company_fax' => $faker->tollFreePhoneNumber,
        'company_city' => $faker->city,
        'company_state' => $faker->stateAbbr,
        'company_zip' => $faker->postcode,
        'company_url' => $faker->url,
        'last_worked' => $faker->dateTimeThisMonth('now'),
        'capcode' => $faker->randomElement(array('', '1000', '2000'), 1),
    ];
});
